"""Artificial fixtures only: complete permutation, isolation and phase guards."""
import copy
import itertools
import json
import random
import unittest

from bound_request import build_bound_request
from input_contract import BASE_GENERATION, audit_ranking, canonical_sha256, validate_input_context
from permutation_core import ConstraintError, State, UniquePermutationLanguage
import protocol


def fixture(count=4):
    seq='ACDEFGHIKLMNPQRSTVWY'*4
    candidates=['A1C+'+seq[p-1]+str(p)+('A' if seq[p-1]!='A' else 'C') for p in range(2,count+2)]
    ctx={'case_id':'P21::artificial','wildtype_sequence':seq,'sequence_length':len(seq),
         'candidate_ids':candidates,'anchor_mutant':'A1C','anchor_DMS_score':'0.0'}
    text=('`'+seq+'`\n- **Anchor Mutant**: A1C\n- **Anchor DMS Score**: 0.0\n'
        +'4. CANDIDATE MUTATIONS TO RANK (Total Candidates: '+str(count)+')\n'+'\n'.join(candidates))
    return {'task_id':'P21','case_id':ctx['case_id'],'messages':[{'role':'user','content':text}]},ctx


class ContractTests(unittest.TestCase):
    def test_every_small_permutation_representable(self):
        _,ctx=fixture();lang=UniquePermutationLanguage(ctx['candidate_ids'])
        for order in itertools.permutations(ctx['candidate_ids']):
            state=lang.feed(State(),json.dumps({'ranking':order},separators=(',',':')).encode())
            self.assertEqual((state.phase,len(state.used)),('done',4))

    def test_all_large_orders_and_candidate_count_preserved(self):
        _,ctx=fixture(56);lang=UniquePermutationLanguage(ctx['candidate_ids']);rng=random.Random(19)
        for _ in range(100):
            order=rng.sample(ctx['candidate_ids'],56)
            self.assertEqual(lang.feed(State(),json.dumps({'ranking':order}).encode()).phase,'done')

    def test_duplicates_omissions_unknowns_and_extra_items_rejected(self):
        _,ctx=fixture();ids=ctx['candidate_ids'];lang=UniquePermutationLanguage(ids)
        for ranking in [ids[:-1],ids+[ids[0]],ids[:-1]+[ids[0]],ids[:-1]+['A1C+C2V']]:
            with self.assertRaises(ConstraintError):lang.feed(State(),json.dumps({'ranking':ranking}).encode())
            self.assertFalse(audit_ranking(ctx,json.dumps({'ranking':ranking}))['delivery_passed'])

    def test_common_prefix_does_not_allow_reused_candidate(self):
        lang=UniquePermutationLanguage(['A1C+C2A','A1C+C2D'])
        with self.assertRaises(ConstraintError):
            lang.feed(State(),b'{"ranking":["A1C+C2A","A1C+C2A"]}')

    def test_noncanonical_escapes_or_extra_JSON_members_rejected(self):
        _,ctx=fixture(1);lang=UniquePermutationLanguage(ctx['candidate_ids'])
        for raw in [b'{"ranking":["A1C+C2A"],"secret":1}',b'{"ranking":["A1C+\\u00432A"]}']:
            with self.assertRaises(ConstraintError):lang.feed(State(),raw)

    def test_native_context_integrity_failure_never_repaired(self):
        _,ctx=fixture()
        for change in [{'sequence_length':1},{'anchor_DMS_score':'NaN'}, {'anchor_mutant':'C2A'},
                       {'candidate_ids':['A1C+C2D','A1C+C2D']}, {'candidate_ids':['A1C+A2D']}]:
            value={**ctx,**change}
            with self.assertRaises(ValueError):validate_input_context(value)

    def test_outcome_score_payload_cannot_enter_context(self):
        _,ctx=fixture();ctx['DMS_score']='PRIVATE_TARGET_SENTINEL'
        with self.assertRaises(ValueError):validate_input_context(ctx)

    def test_request_preserves_native_prompt_and_sampling(self):
        case,ctx=fixture();pins={'case_sha256':canonical_sha256(case),'context_sha256':canonical_sha256(ctx),
            'base_generation_sha256':canonical_sha256(BASE_GENERATION)}
        out=build_bound_request(case,ctx,BASE_GENERATION,**pins)
        self.assertEqual(out['messages'],case['messages'])
        for k,v in BASE_GENERATION.items():
            if k!='structured_outputs':self.assertEqual(out[k],v)
        self.assertEqual(out['structured_outputs']['json']['properties']['ranking']['minItems'],4)
        self.assertEqual(json.loads(out['vllm_xargs']['p21_candidate_ids_json']),ctx['candidate_ids'])
        self.assertNotIn('uniqueItems',json.dumps(out))
        self.assertNotIn('PRIVATE_TARGET_SENTINEL',json.dumps(out))

    def test_changed_context_or_generation_fails_before_payload(self):
        case,ctx=fixture();pins={'case_sha256':canonical_sha256(case),'context_sha256':canonical_sha256(ctx),
            'base_generation_sha256':canonical_sha256(BASE_GENERATION)}
        other=copy.deepcopy(ctx);other['candidate_ids'].reverse()
        with self.assertRaises(ValueError):build_bound_request(case,other,BASE_GENERATION,**pins)
        other=copy.deepcopy(BASE_GENERATION);other['max_tokens']=10
        with self.assertRaises(ValueError):build_bound_request(case,ctx,other,**pins)

    def test_complete_prompt_binding_required_even_with_new_hash(self):
        case,ctx=fixture();case['messages'][0]['content']=case['messages'][0]['content'].replace(ctx['candidate_ids'][-1],'MISSING')
        with self.assertRaises(ValueError):build_bound_request(case,ctx,BASE_GENERATION,
            case_sha256=canonical_sha256(case),context_sha256=canonical_sha256(ctx),base_generation_sha256=canonical_sha256(BASE_GENERATION))

    def test_exact_final_audit_returns_full_fixed_denominator(self):
        _,ctx=fixture();audit=audit_ranking(ctx,json.dumps({'ranking':list(reversed(ctx['candidate_ids']))}))
        self.assertTrue(audit['delivery_passed']);self.assertEqual(audit['candidate_count'],4)

    def test_failed_development_blocks_benchmark_and_scorer(self):
        calls=[]
        with self.assertRaises(ValueError):protocol.run_order({'development_config_sha256':'d','generation':{}},
            lambda:{'task_id':'P21','config_sha256':'d','generation':{},'biological_correctness_assessed':False,'delivery_passed_all':False},
            lambda x:calls.append('benchmark'),lambda x:calls.append('score'))
        self.assertEqual(calls,[])

    def test_partial8_denominator_blocks_scoring(self):
        done={'task_id':'P21','config_sha256':'b','generation':{},'planned':8,'terminal':7,'prediction_lock_sha256':'lock'}
        with self.assertRaises(ValueError):protocol.require_complete_benchmark(done,'b',{})

    def test_root_admission_default_is_closed(self):
        with self.assertRaises(PermissionError):protocol.validate_admission_data({'admitted':False},'plan','scope')


if __name__=='__main__':unittest.main()
