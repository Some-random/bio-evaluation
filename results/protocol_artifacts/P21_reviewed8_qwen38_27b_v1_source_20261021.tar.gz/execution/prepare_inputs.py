"""Materialize only eight independently reviewed native T3 mammalian inputs.

The official candidate CSV colocates mutant IDs and protected DMS scores. Only
mutant/candidate_group_id fields are accessed here. The original file is pinned
as scorer-only evidence; its outcome-score fields are never used by preparation.
"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import csv
import hashlib
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
DATA = ROOT/'.local/source_recovery_round2_2026-10-19/pfarena/authenticated/raw/T3_anchor_informed_multi_mutant_ranking'
CODE = ROOT/'.local/source_recovery_round2_2026-10-19/pfarena/official_code/code'
from input_contract import AMINO_ACIDS, CONDITION, validate_input_context

IDENTITIES = {
    'P29323': 'Human EphB2 fragment; native folding-free-energy stability readout, not receptor activation or binding engineering.',
    'P48052': 'Human carboxypeptidase A2 fragment; native folding stability, not catalytic activity selection.',
    'O88544': 'Mouse COP9 signalosome subunit4 fragment; isolated folding stability, not cellular pathway manipulation.',
    'Q5VST9': 'Human obscurin fragment; isolated folding stability, not kinase or exchange-factor activity.',
    'Q8BUR4': 'Mouse DOCK1 fragment; isolated folding stability, not exchange-factor or migration activity.',
    'Q9BX66': 'Human SORBS1 adaptor fragment; isolated folding stability, not signaling or host manipulation.',
    'Q9ULT8': 'Human HECTD1 fragment; isolated folding stability, not ubiquitination activity selection.',
    'O95155': 'Human UBE4B fragment; isolated folding stability, not ligase activity selection.',
}


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def rel(path): return str(Path(path).resolve().relative_to(ROOT))
def save(name, value):
    with (HERE/name).open('x') as f: json.dump(value, f, indent=2, sort_keys=True, allow_nan=False); f.write('\n')


def adapter():
    path = HERE.parent/'engineering_20261020/ranking_adapter.py'
    spec = importlib.util.spec_from_file_location('_p21_native_input_adapter', path)
    module = importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    return module


def build_case(native, row, candidates, case_id, allowed):
    context = {'case_id': case_id, 'wildtype_sequence': row['wildtype_sequence'].strip(),
        'sequence_length': int(float(row['sequence_length'])), 'candidate_ids': list(candidates),
        'anchor_mutant': row['anchor_mutant'].strip(), 'anchor_DMS_score': row['anchor_DMS_score'].strip()}
    validate_input_context(context)
    projected = {key: row[key] for key in native.CONTEXT_FIELDS}
    case = {'task_id':'P21', 'case_id':case_id, 'messages':native.build_messages(projected, candidates,
        allowed, set(), anchor_mutant=context['anchor_mutant'], anchor_dms_score=context['anchor_DMS_score'])}
    return case, context


def main():
    native = adapter(); native.native_builders()  # All source hashes must match.
    evidence_path = HERE/'source_checks/T3_megascale_uniprot_metadata.tsv'
    evidence = {r['Entry']:r for r in csv.DictReader(evidence_path.open(),delimiter='\t')}
    rows = list(csv.DictReader((DATA/'assay.csv').open()))
    selected = [r for r in rows if r['source_dataset']=='MegaScale' and r['uniprot_id'] in IDENTITIES]
    if len(rows)!=67 or len(selected)!=8: raise ValueError('Native or positive-review cohort changed')
    allowed = {r['assay_id'] for r in selected}
    acquisition_path=DATA.parent.parent/'completion.json'
    acquisition=json.loads(acquisition_path.read_text())
    cases=[]; contexts=[]; reviews=[]; refs=[]
    for row in selected:
        info=evidence[row['uniprot_id']]
        if info['Organism'] not in {'Homo sapiens (Human)','Mus musculus (Mouse)'}:
            raise ValueError('Independent publisher organism identity differs')
        if (row['primary_task_class'],row['fitness_type'],row['readout_subclass']) != ('stability','stability','folding_free_energy_stability_readout'):
            raise ValueError('Independently reviewed objective differs')
        source=DATA/row['DMS_filename']; relative='T3_anchor_informed_multi_mutant_ranking/'+row['DMS_filename']
        record=acquisition['files'][relative]
        if not record['publisher_digest_verified'] or sha(source)!=record['sha256']:
            raise ValueError('Official candidate/reference file changed')
        candidates=[];groups=set()
        for projected in csv.DictReader(source.open()):
            # No access to DMS_score or mutated_sequence. Candidate IDs are
            # legitimate native inputs; group IDs identify the native scorer unit.
            value=projected['mutant'].strip()
            if value:candidates.append(value)
            group=projected['candidate_group_id'].strip()
            if group:groups.add(group)
        if len(groups)!=1 or len(candidates)!=int(float(row['n_successors_selected'])):
            raise ValueError('Complete candidate count/native group identity differs')
        case_id='P21::'+row['assay_id']; case,context=build_case(native,row,candidates,case_id,allowed)
        cases.append(case);contexts.append(context)
        reviews.append({'case_id':case_id,'assay_id':row['assay_id'],'uniprot_id':row['uniprot_id'],
            'verified_organism':info['Organism'],'verified_protein_name':info['Protein names'],
            'native_objective':'folding_free_energy_stability_readout','scope_reason':IDENTITIES[row['uniprot_id']],
            'native_fragment_length':context['sequence_length'],'candidate_count':len(candidates),
            'all_candidate_IDs_and_legitimate_anchor_input_integrity_passed':True,
            'native_candidate_score_fields_accessed':False,'native_prompt_preserved':True,
            'reference_file_colocated_with_candidate_ID_source':True,
            'independent_T3_input_preparation_admitted':True,'runtime_dispatch_admitted':False})
        refs.append({'case_id':case_id,'assay_id':row['assay_id'],'native_truth_id':next(iter(groups)),
            'target_path':rel(source),'sha256':record['sha256'],'native_relative_path':row['DMS_filename'],
            'publisher_digest_verified_at_acquisition':True,'protected_DMS_score_fields_accessed_in_preparation':False})
    dev=[];devcontexts=[]
    for index,count in enumerate([19,38,56],1):
        sequence=AMINO_ACIDS*4;anchor='A1C'; candidates=[]
        for position in range(2,count+2):
            before=sequence[position-1];after=AMINO_ACIDS[(AMINO_ACIDS.index(before)+1)%len(AMINO_ACIDS)]
            candidates.append(anchor+'+'+before+str(position)+after)
        assay='SYNTHETIC_T3_DELIVERY_'+str(index)
        row={'assay_id':assay,'uniprot_id':'ARTIFICIAL_ONLY','primary_task_class':'stability',
            'fitness_type':'stability','readout_subclass':'synthetic_interface_no_real_measurements',
            'wildtype_sequence':sequence,'sequence_length':str(len(sequence)),
            'anchor_mutant':anchor,'anchor_DMS_score':'0.0'}
        c,ctx=build_case(native,row,candidates,'P21::synthetic_delivery_'+str(index).zfill(2),{assay})
        dev.append(c);devcontexts.append(ctx)
    for phase,phasecases,phasecontexts in [('benchmark',cases,contexts),('development',dev,devcontexts)]:
        with (HERE/(phase+'_inputs.jsonl')).open('x') as f:
            for c in phasecases:f.write(json.dumps(c,sort_keys=True,allow_nan=False)+'\n')
        save(phase+'_delivery_contexts.json',{'task_id':'P21','cases':phasecontexts,
            'reference_labels_included':False,'legitimate_native_anchor_scores_included':True,
            'candidate_outcome_scores_included':False})
    now=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
    save('input_review.json',{'at_pacific':now,'task_id':'P21','condition':CONDITION,
        'approved_case_ids':[c['case_id'] for c in cases],'cases':reviews,'native_panel_assays':67,
        'reviewed_assays':8,'remaining_outside_this_reviewed_condition':59,
        'all_native_assays_approved':False,'P19_admission_inherited':False,'P20_interrupted_action_reopened':False,
        'excluded_before_candidate_or_anchor_content_access':[r['assay_id'] for r in rows if r['assay_id'] not in allowed],
        'held_cases':[],'basis':'Independent explicit organism/protein/objective/native input review; positive8 case scope only.',
        'source_metadata_sha256':sha(DATA/'assay.csv'),'publisher_identity_metadata_sha256':sha(evidence_path),
        'new_model_calls':0,'protected_candidate_outcome_score_fields_accessed':False})
    save('development_review.json',{'task_id':'P21','approved_case_ids':[c['case_id'] for c in dev],
        'held_cases':[],'synthetic_only':True,'biological_correctness_assessed':False})
    save('scorer_only_manifest.json',{'task_id':'P21','condition':CONDITION,'cases':refs,
        'source_dataset_revision':'5be3973dd45a9d7d33572f016be18f8ef941f2ff','reference_labels_isolated':True,
        'native_scorer_file':rel(CODE/'evaluation/full.py'),'native_scorer_sha256':sha(CODE/'evaluation/full.py'),
        'native_router_file':rel(CODE/'router.py'),'native_router_sha256':sha(CODE/'router.py'),
        'native_parser_file':rel(CODE/'llm/infer_api_mutation.py'),'native_parser_sha256':sha(CODE/'llm/infer_api_mutation.py'),
        'native_metrics':['spearman','NDCG','NMS@5','Recall@5'],'native_panel_assays':67,
        'native_strict_coverage':True,'missing_query_random_fallback_enabled':False})
    save('input_materialization_receipt.json',{'at_pacific':now,'task_id':'P21','stage':'native_reviewed8_and_synthetic3_materialized_not_dispatched',
        'native_panel_assays':67,'reviewed_assays':8,'remaining_not_admitted_to_this_condition':59,
        'human_assays':6,'mouse_assays':2,'candidate_count_total':sum(len(c['candidate_ids']) for c in contexts),
        'candidate_count_min':min(len(c['candidate_ids']) for c in contexts),'candidate_count_max':max(len(c['candidate_ids']) for c in contexts),
        'native_full_sequences_prompts_candidates_and_anchor_context_preserved':True,
        'protected_candidate_outcome_score_fields_accessed':False,'new_inference_calls':0,'GPU_allocations':0})
    print(json.dumps({'reviewed_inputs':8,'synthetic_inputs':3,'native_panel':67,'candidate_total':sum(len(c['candidate_ids']) for c in contexts),'calls':0}))


if __name__=='__main__':main()
