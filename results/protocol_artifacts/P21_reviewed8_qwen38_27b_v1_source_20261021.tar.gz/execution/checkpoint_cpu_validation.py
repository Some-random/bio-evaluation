"""Pinned tokenizer and verbatim V1 API checks; no model construction/forward."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import random
import sys
import time
import types
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))


def main():
    assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and os.environ.get('SLURM_JOB_ID')
    assert not os.environ.get('SLURM_GPUS')
    plan=json.loads((HERE/'CPU_plan.json').read_text())
    for name,digest in plan['file_sha256'].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
    import torch
    from tokenizers import Tokenizer
    from transformers import AutoTokenizer
    from permutation_core import ConstraintError, RequestConstraint, TokenVocabulary
    from input_contract import BASE_GENERATION, canonical_sha256, validate_input_context
    from bound_request import build_bound_request
    from source_api_harness import load_verbatim_adapter, import_production_adapter_with_source_base
    from test_contracts import fixture
    torch.set_num_threads(4);started=time.monotonic();checks={};panels=[]
    path=Path(plan['tokenizer'])
    vocabulary=TokenVocabulary.from_checkpoint_tokenizer(path,plan['tokenizer_sha256'],set(plan['EOS_ids']))
    tokenizer=Tokenizer.from_file(str(path))
    for token,piece in vocabulary.pieces.items():
        assert tokenizer.decode([token],skip_special_tokens=False).encode()==piece
    checks['every_usable_token_piece_matches_pinned_actual_decoder']=len(vocabulary.pieces)
    alphabet=set(b'{}[]":,+ranking0123456789 \t\n\rACDEFGHIKLMNPQRSTVWY')
    assert alphabet <= {p[0] for p in vocabulary.pieces.values() if len(p)==1}
    checks['every_accepted_character_has_lossless_single_byte_token']=len(alphabet)
    assert vocabulary.eos_ids.isdisjoint(vocabulary.pieces)
    checks['special_and_padded_tokens_not_ordinary_output']=True
    rng=random.Random(7121)
    for count in [19,38,56]:
        _,ctx=fixture(count);ranking=rng.sample(ctx['candidate_ids'],count)
        text=json.dumps({'ranking':ranking},separators=(',',':'));ids=tokenizer.encode(text,add_special_tokens=False).ids
        assert tokenizer.decode(ids,skip_special_tokens=False)==text
        constraint=RequestConstraint(ctx['candidate_ids'],vocabulary);output=[]
        for token in ids:
            logits=torch.zeros(plan['model_padded_vocabulary_size']);constraint(output,logits)
            assert torch.isfinite(logits[token]) and not torch.isfinite(logits[list(vocabulary.eos_ids)]).any()
            output.append(token)
        constraint(output,torch.zeros(plan['model_padded_vocabulary_size']))
        assert constraint.state.phase=='done' and len(constraint.state.used)==count
        output.append(min(vocabulary.eos_ids))
        for initial in [0.0,float('-inf'),float('nan')]:
            logits=torch.full((plan['model_padded_vocabulary_size'],),initial);constraint(output,logits)
            assert set(torch.where(torch.isfinite(logits))[0].tolist())==set(vocabulary.eos_ids)
            assert torch.equal(logits[list(vocabulary.eos_ids)],torch.zeros(len(vocabulary.eos_ids)))
        repeated=output+[min(vocabulary.eos_ids)]
        constraint.update(repeated)
        try:constraint.update(repeated+[next(iter(vocabulary.pieces))])
        except ConstraintError:pass
        else:raise AssertionError('Ordinary post-EOS output accepted')
        panels.append({'artificial_candidates':count,'actual_token_boundaries_checked':len(ids),'all_candidates_retained':True})
    checks['every_token_boundary_of_three_variable_length_permutations_checked']=True
    checks['late_terminal_callbacks_are_EOS_only_even_with_all_inf_or_NaN_upstream']=True
    checks['repeated_internal_EOS_allowed_ordinary_post_EOS_rejected']=True
    before=RequestConstraint(fixture()[1]['candidate_ids'],vocabulary)
    try:before.update([min(vocabulary.eos_ids)])
    except ConstraintError:pass
    else:raise AssertionError('Premature EOS accepted')
    checks['premature_EOS_rejected']=True
    scope=load_verbatim_adapter(Path(plan['pinned_V1_source_directory']),torch)
    module=import_production_adapter_with_source_base(scope)
    cfg=types.SimpleNamespace(speculative_config=None,model_config=types.SimpleNamespace(model=str(path.parent)))
    with patch.dict(os.environ,{'VLLM_USE_V2_MODEL_RUNNER':'0'}),patch.object(importlib.metadata,'version',return_value='0.32.0'):
        adapter=module.P21PermutationLogitsProcessor(cfg,torch.device('cpu'),False)
    assert not adapter.is_argmax_invariant()
    def params(count):
        case,ctx=fixture(count)
        request=build_bound_request(case,ctx,BASE_GENERATION,case_sha256=canonical_sha256(case),
            context_sha256=canonical_sha256(ctx),base_generation_sha256=canonical_sha256(BASE_GENERATION))
        return types.SimpleNamespace(extra_args=request['vllm_xargs'],n=1)
    a=[];b=[];BatchUpdate=scope['BatchUpdate'];direction=scope['MoveDirectionality']
    adapter.update_state(BatchUpdate(batch_size=2,removed=[],added=[(0,params(19),[],a),(1,params(56),[],b)],moved=[]))
    adapter.apply(torch.zeros((2,plan['model_padded_vocabulary_size'])))
    first=fixture(19)[1]['candidate_ids'][0]
    a.extend(tokenizer.encode('{"ranking":["'+first+'",',add_special_tokens=False).ids)
    adapter.update_state(None);adapter.apply(torch.zeros((2,plan['model_padded_vocabulary_size'])))
    assert adapter.req_info[0].func.state.used==frozenset({first}) and not adapter.req_info[1].func.state.used
    checks['verbatim_source_Adapter_keeps_live_history_and_separate_candidate_counts']=True
    aprocessor=adapter.req_info[0];bprocessor=adapter.req_info[1]
    adapter.update_state(BatchUpdate(batch_size=2,removed=[],added=[],moved=[(0,1,direction.SWAP)]))
    assert adapter.req_info[0] is bprocessor and adapter.req_info[1] is aprocessor
    adapter.apply(torch.zeros((2,plan['model_padded_vocabulary_size'])))
    adapter.update_state(BatchUpdate(batch_size=1,removed=[0],added=[],moved=[(1,0,direction.UNIDIRECTIONAL)]))
    assert set(adapter.req_info)=={0} and adapter.req_info[0] is aprocessor
    checks['verbatim_source_swap_remove_and_move_lifecycle']=True
    adapter.update_state(BatchUpdate(batch_size=0,removed=[0],added=[],moved=[]))
    adapter.update_state(BatchUpdate(batch_size=1,removed=[],added=[(0,params(38),[],[])],moved=[]))
    assert not adapter.req_info[0].func.state.used and adapter.req_info[0].func.language.count==38
    checks['slot_reuse_has_no_previous_candidate_or_used_state']=True
    for bad in [types.SimpleNamespace(extra_args={},n=1),params(19)]:
        if bad.extra_args:bad.extra_args['p21_candidate_ids_sha256']='0'*64
        try:module.P21PermutationLogitsProcessor.validate_params(bad)
        except ValueError:pass
        else:raise AssertionError('Missing or mismatched candidate binding accepted')
    checks['mandatory_request_binding_fails_closed']=True
    adapter.req_info.clear()
    try:adapter.apply(torch.zeros((1,plan['model_padded_vocabulary_size'])))
    except ValueError:pass
    else:raise AssertionError('Unconstrained active row accepted')
    try:RequestConstraint(fixture()[1]['candidate_ids'],vocabulary)([],torch.full((plan['model_padded_vocabulary_size'],),float('-inf')))
    except ConstraintError:pass
    else:raise AssertionError('All-inf output fell back unconstrained')
    checks['missing_active_state_and_all_nonfinite_logits_fail_without_fallback']=True
    native_tokenizer=AutoTokenizer.from_pretrained(path.parent,local_files_only=True)
    token_rows=[]
    for phase in ['development','benchmark']:
        cases=[json.loads(x) for x in (HERE/(phase+'_inputs.jsonl')).read_text().splitlines()]
        contexts={r['case_id']:r for r in json.loads((HERE/(phase+'_delivery_contexts.json')).read_text())['cases']}
        for case in cases:
            ctx=validate_input_context(contexts[case['case_id']])
            build_bound_request(case,ctx,BASE_GENERATION,case_sha256=canonical_sha256(case),
                context_sha256=canonical_sha256(ctx),base_generation_sha256=canonical_sha256(BASE_GENERATION))
            encoded=native_tokenizer.apply_chat_template(case['messages'],tokenize=True,add_generation_prompt=True,enable_thinking=False)
            ids=encoded['input_ids'] if hasattr(encoded,'keys') else encoded
            if ids and isinstance(ids[0],list):ids=ids[0]
            assert len(ids)+16384<=65536
            token_rows.append({'phase':phase,'case_id':case['case_id'],'prompt_tokens':len(ids),'candidate_count':len(ctx['candidate_ids'])})
    checks['all11_complete_native_or_artificial_requests_bound_and_fit_65536_with_uniform16K']=True
    result={'stage':'CPU_pinned_tokenizer_full_permutation_and_verbatim_API_checks_passed_not_model_delivery',
        'job_id':os.environ['SLURM_JOB_ID'],'checks':checks,'checks_passed':len(checks),'artificial_panels':panels,
        'tokenizer_sha256':plan['tokenizer_sha256'],'usable_exact_token_pieces':len(vocabulary.pieces),
        'input_token_counts':token_rows,'max_prompt_tokens':max(x['prompt_tokens'] for x in token_rows),
        'torch_version':importlib.metadata.version('torch'),'tokenizers_version':importlib.metadata.version('tokenizers'),
        'elapsed_seconds':time.monotonic()-started,'actual_installed_vllm_engine_imported':False,
        'verbatim_pinned_vllm_source_methods_executed':True,'real_input_prompt_CPU_tokenization_only':True,
        'actual_model_weights_loaded':False,'model_forwards':0,'model_calls':0,'protected_candidate_scores_accessed':False,
        'GPU_allocations':0,'runtime_adoption':False}
    with (HERE/'CPU_validation.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({'stage':result['stage'],'checks_passed':len(checks),'max_prompt_tokens':result['max_prompt_tokens'],'elapsed_seconds':result['elapsed_seconds']}))


if __name__=='__main__':main()
