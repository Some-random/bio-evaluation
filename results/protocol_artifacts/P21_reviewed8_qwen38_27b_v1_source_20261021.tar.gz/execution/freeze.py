"""Freeze one separately reviewed P21 condition; no admission or model calls."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import copy
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
sys.path.insert(0,str(HERE))
import protocol
import runner
import worker
from input_contract import BASE_GENERATION, canonical_sha256


def read(p):return json.loads(Path(p).read_text())


def main():
    if (HERE/'plan.json').exists():raise FileExistsError('Do not change or replace a frozen plan')
    prior=ROOT/'.local/catalog_execution_2026-10-20/tasks/P19/standalone_execution_v4'
    previous=read(prior/'plan.json');pins={}
    def pin(path,expected=None):
        path=Path(path);digest=worker.sha(path)
        if expected is not None and digest!=expected:raise ValueError('Pinned runtime/source changed: '+str(path))
        pins[str(path)]=digest
        return digest
    for name,digest in previous['frozen_files_sha256'].items():
        if (name.startswith(str(ROOT/'.local/litqa2_replay')) or name.endswith('/runtime_common.py')
                or name.startswith(str(ROOT/'.local/catalog_execution_2026-10-20/tasks/V06/local_execution_v2'))
                or name==previous['project_gpu_audit_helper'] or name.endswith('/scripts/serve_catalog_20261020.py')):
            pin(name,digest)
    pin(prior/'plan.json','de3f4c06cd13db6166d15b3b7a66371688f8b1cc4f01ec2d46bf19df54b291e8')
    for name in ['unique40_core.py','p19_unique40_logits.py']:
        pin(prior/name,previous['frozen_files_sha256'][str(prior/name)])
    for path in (prior/'sources').glob('*.py'):pin(path)
    for path in HERE.glob('*.py'):pin(path)
    for name in ['CPU_plan.json','CPU_validation.json','CPU_terminal.json','input_materialization_receipt.json',
                 'input_review.json','development_review.json','scorer_only_manifest.json',
                 'development_inputs.jsonl','benchmark_inputs.jsonl','development_delivery_contexts.json','benchmark_delivery_contexts.json',
                 'source_checks/T3_megascale_uniprot_metadata.tsv','source_checks/metadata_acquisition_receipt.json']:
        pin(HERE/name)
    source_manifest=read(HERE/'scorer_only_manifest.json')
    for kind in ['native_scorer','native_router','native_parser']:
        pin(ROOT/source_manifest[kind+'_file'],source_manifest[kind+'_sha256'])
    adapter=HERE.parent/'engineering_20261020/ranking_adapter.py';pin(adapter)
    scope_review=read(HERE/'input_review.json');cases=scope_review['cases']
    if (len(cases)!=8 or len(scope_review['approved_case_ids'])!=8
            or len(scope_review['excluded_before_candidate_or_anchor_content_access'])!=59):
        raise ValueError('Reviewed scope changed')
    organisms={name:sum(r['verified_organism']==name for r in cases) for name in ['Homo sapiens (Human)','Mus musculus (Mouse)']}
    if organisms!={'Homo sapiens (Human)':6,'Mus musculus (Mouse)':2}:raise ValueError('Organism scope changed')
    worker.save(HERE/'source_scope.json',{'task_id':'P21','condition':protocol.CONDITION,'approved':8,'native_panel':67,
        'remaining_unadmitted':59,'approved_case_ids':scope_review['approved_case_ids'],'approved_organism_counts':organisms,
        'independent_input_review_sha256':worker.sha(HERE/'input_review.json'),
        'no_P19_admission_inherited':True,'no_P20_interrupted_action_reopened':True,
        'all_candidate_IDs_full_native_sequences_and_legitimate_anchor_context_preserved':True,
        'protected_candidate_scores_in_solver_inputs':False,'new_head_training':False,
        'prospective_output_constraint':'Exact native candidate enum plus mandatory complete-permutation prefix mask; all orders remain possible; finite EOS-only terminal retirement.',
        'full_native_benchmark_complete':False,'full_catalog_complete':False})
    local_code={str(p):worker.sha(p) for p in HERE.glob('*.py')}
    for phase,count in [('development',3),('benchmark',8)]:
        case_rows=[json.loads(x) for x in (HERE/(phase+'_inputs.jsonl')).read_text().splitlines() if x]
        contexts=read(HERE/(phase+'_delivery_contexts.json'))['cases']
        if len(case_rows)!=count or [x['case_id'] for x in case_rows]!=[x['case_id'] for x in contexts]:
            raise ValueError('Phase input/context count or order changed')
        review=HERE/('input_review.json' if phase=='benchmark' else 'development_review.json')
        cfg={'schema_version':1,'task_id':'P21','condition':protocol.CONDITION,
            'model':previous['model'],'model_revision':previous['model_revision'],
            'run_id':'qwen38_27b_p21_'+('reviewed8' if phase=='benchmark' else 'synthetic3')+'_full_permutation16k_2026-10-21_v1',
            'generation':runner.GENERATION,'planned':count,
            'split':'reviewed_benchmark_subset' if phase=='benchmark' else 'synthetic_development',
            'input_file':str(HERE/(phase+'_inputs.jsonl')),'input_sha256':worker.sha(HERE/(phase+'_inputs.jsonl')),
            'review_file':str(review),'review_sha256':worker.sha(review),
            'delivery_context_file':str(HERE/(phase+'_delivery_contexts.json')),
            'delivery_context_sha256':worker.sha(HERE/(phase+'_delivery_contexts.json')),
            'files_sha256':local_code,'native_prompt_preserved':True,'all_original_sequences_preserved':True,
            'base_generation_sha256':canonical_sha256(BASE_GENERATION),
            'case_bindings':{case['case_id']:{'case_sha256':canonical_sha256(case),
                'context_sha256':canonical_sha256(context),'base_generation_sha256':canonical_sha256(BASE_GENERATION)}
                for case,context in zip(case_rows,contexts)},
            'material_differences':['8 independently reviewed mammalian domain-folding stability assays of67 native T3 assays',
                'Pinned BF16 local Qwen baseline; nonthinking uniform16K output; native prompt unchanged',
                'Dedicated legacyV1 runtime with source-supported mandatory full-permutation logits mask and native candidate enum',
                'Three artificial task-specific delivery checks; not benchmark correctness scores']}
        if phase=='benchmark':cfg.update(native_panel_assays=67,full_native_benchmark_complete=False,
            development_config_sha256=worker.sha(HERE/'development_config.json'),
            scorer_only_manifest_path=str(HERE/'scorer_only_manifest.json'),
            scorer_only_manifest_sha256=worker.sha(HERE/'scorer_only_manifest.json'))
        worker.save(HERE/(phase+'_config.json'),cfg)
        runner.load_contract(HERE/(phase+'_config.json'))
        pin(HERE/(phase+'_config.json'))
    pin(HERE/'source_scope.json')
    sbatch=f'''#!/bin/bash
#SBATCH --job-name=bio-p21-permutation-v1
#SBATCH --partition=il
#SBATCH --account=infolab
#SBATCH --gres=gpu:a100:1
#SBATCH --cpus-per-task=10
#SBATCH --mem=96G
#SBATCH --time=12:00:00
#SBATCH --chdir={ROOT}
#SBATCH --output={HERE}/slurm-%j.log
set -euo pipefail
umask 077
unset OPENAI_API_KEY ANTHROPIC_API_KEY GEMINI_API_KEY GOOGLE_API_KEY AZURE_OPENAI_API_KEY HF_TOKEN HUGGING_FACE_HUB_TOKEN
unset OPENAI_BASE_URL OPENAI_ORG_ID OPENAI_ORGANIZATION OPENAI_PROJECT_ID PYTHONPATH PYTHONHOME VIRTUAL_ENV SSH_AUTH_SOCK
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONNOUSERSITE=1
exec /usr/bin/python3 {HERE}/worker.py --plan {HERE}/plan.json --plan-sha256 "$1" --admission "$2" --admission-sha256 "$3"
'''
    (HERE/'worker.sbatch').write_text(sbatch);pin(HERE/'worker.sbatch')
    keep=['model','model_revision','model_directory','base_runtime','cuda_overlay','runtime_common','checkpoint_audit',
        'runtime_package_installation','vetted_V06_infrastructure_version','vetted_V06_plan_sha256','base_archive_contains_vllm',
        'pinned_install_before_private_exec_and_GPU_guard_required','runtime_version','vetted_V06_worker',
        'project_gpu_audit_helper','project_gpu_audit_helper_sha256','GPU_accounting_scope']
    plan={key:copy.deepcopy(previous[key]) for key in keep}
    plan.update(created_at_pacific=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),task_id='P21',
        scope=protocol.SCOPE,condition=protocol.CONDITION,planned=8,synthetic_development_planned=3,
        native_panel_assays=67,remaining_unadmitted_assays=59,source_scope_sha256=worker.sha(HERE/'source_scope.json'),
        generation=runner.GENERATION,endpoint='http://127.0.0.1:8421/v1',context_limit=65536,
        gpus_requested=1,tensor_parallel_size=1,dtype='bfloat16',total_project_gpu_ceiling=8,
        development_config=str(HERE/'development_config.json'),development_config_sha256=worker.sha(HERE/'development_config.json'),
        benchmark_config=str(HERE/'benchmark_config.json'),benchmark_config_sha256=worker.sha(HERE/'benchmark_config.json'),
        runner=str(HERE/'runner.py'),scorer=str(HERE/'scorer.py'),scorer_only_manifest=str(HERE/'scorer_only_manifest.json'),
        runtime_root=str(HERE/'runtime'),mandatory_model_runner='legacy_V1_explicit',
        custom_logits_processor='p21_permutation_logits:P21PermutationLogitsProcessor',plugin_sha256=worker.sha(HERE/'p21_permutation_logits.py'),
        phase_policy={'development_attempts':3,'benchmark_attempts_maximum':8,'concurrency':1,
            'uniform_output_tokens':16384,'development_must_pass_all':True,'benchmark_grant_after_passing_actual_development_lock':True,
            'native_scoring_after_complete8_prediction_lock_only':True,'sole_scoring_attempt':True,
            'automatic_or_selective_retries':False,'automatic_resume':False},
        reference_access='Only native candidate/group IDs projected before generation; colocated candidate DMS scores accessed only by unchanged native scorer after full immutable prediction lock. Native anchor score is legitimate supplied context.',
        full_native67_complete=False,full_catalog_complete=False,runtime_admission_granted=False,
        submission_by_preparation=False,new_model_calls=0,new_GPU_allocations=0,frozen_files_sha256=pins)
    worker.save(HERE/'plan.json',plan);digest=worker.sha(HERE/'plan.json');(HERE/'plan.sha256').write_text(digest+'\n')
    worker.validate_plan(HERE/'plan.json',digest)
    worker.save(HERE/'root_admission_NOT_GRANTED_template.json',{'admitted':False,'task_id':'P21','scope':protocol.SCOPE,
        'condition':protocol.CONDITION,'plan_sha256':digest,'source_scope_sha256':plan['source_scope_sha256'],
        'gpu_count':1,'project_gpu_ceiling':8,'allow_benchmark_only_after_development_gate':True,
        'gpu_audit_receipt':None,'gpu_audit_receipt_sha256':None})
    worker.save(HERE/'freeze_receipt.json',{'at_pacific':plan['created_at_pacific'],'plan_sha256':digest,
        'dependency_pins':len(pins),'reviewed_assays':8,'native_assays':67,'remaining_unadmitted':59,
        'native_prompts_full_sequences_candidates_anchor_and_scorer_formulas_preserved':True,
        'protected_candidate_outcome_score_fields_accessed':False,'root_admission':False,'model_calls':0,'GPU_allocations':0})
    print(json.dumps({'plan_sha256':digest,'pins':len(pins),'admitted':False,'model_calls':0,'GPU_allocations':0}))


if __name__=='__main__':main()
