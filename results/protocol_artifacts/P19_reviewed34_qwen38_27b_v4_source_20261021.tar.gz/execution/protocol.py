"""Fixed P19 phase order and denominator guards; no model/network operations."""
GENERATION_OUTPUT_TOKENS = 16384
SCOPE = 'synthetic3_then_reviewed_mammalian_stability34_unique40_V4_once_then_native_score'
CONDITION = 'PFARENA_T1_INPUT_VALID_UNIQUE40_TERMINAL_EOS_IDEMPOTENT_V4'


def require_development(done, config_sha, generation):
    if (done.get('task_id') != 'P19' or done.get('config_sha256') != config_sha or
            done.get('generation') != generation or done.get('biological_correctness_assessed') is not False):
        raise ValueError('Development completion differs from the fixed P19 condition')
    if not done.get('delivery_passed_all') or any(done.get(k) != 3 for k in ['planned','terminal','responses_saved','delivery_passed']):
        raise ValueError('Exactly three actual synthetic delivery cases must pass')
    for name in ['transport_errors','http_errors','response_errors','truncations','empty_finals','refusals','reasoning_present']:
        if done.get(name) != 0:
            raise ValueError('Development failure blocks every benchmark call')
    if not done.get('prediction_lock_sha256'):
        raise ValueError('Actual immutable development prediction lock is required')


def require_complete_benchmark(done, config_sha, generation):
    if (done.get('task_id') != 'P19' or done.get('config_sha256') != config_sha or
            done.get('generation') != generation or done.get('planned') != 34):
        raise ValueError('Benchmark completion differs from the exact34-case condition')
    if done.get('terminal') != 34 or not done.get('prediction_lock_sha256'):
        raise ValueError('Partial or ambiguous benchmark evidence cannot reach scoring')
    # Delivery failures remain in the complete denominator. The native scorer
    # decides whether strict native coverage makes the primary metric undefined.
    return {'score_may_be_attempted': True, 'full_native123_complete': False}


def run_order(plan, run_development, run_benchmark, run_score):
    dev = run_development()
    require_development(dev, plan['development_config_sha256'], plan['generation'])
    benchmark = run_benchmark(dev)
    require_complete_benchmark(benchmark, plan['benchmark_config_sha256'], plan['generation'])
    score = run_score(benchmark)
    if score.get('planned_assays') != 34 or score.get('native_panel_assays') != 123 or score.get('full_native_benchmark_complete') is not False:
        raise ValueError('Native score must retain reviewed34/123 subset qualification')
    if score.get('native_scoring_status') not in {'completed_native_scored_reviewed_subset','undefined_native_strict_coverage_failure'}:
        raise ValueError('Unexpected native scoring terminal state')
    return {'development': dev, 'benchmark': benchmark, 'score': score,
            'reviewed34_condition_terminal': True, 'full_native123_complete': False,
            'full_catalog_complete': False}


def validate_admission_data(admission, plan_sha, scope_sha):
    if (admission.get('admitted') is not True or admission.get('task_id') != 'P19' or
            admission.get('scope') != SCOPE or admission.get('condition') != CONDITION or admission.get('plan_sha256') != plan_sha or
            admission.get('source_scope_sha256') != scope_sha or admission.get('gpu_count') != 1 or
            admission.get('project_gpu_ceiling') != 8 or
            admission.get('allow_benchmark_only_after_development_gate') is not True):
        raise PermissionError('Exact separate root P19 admission is required before startup')
