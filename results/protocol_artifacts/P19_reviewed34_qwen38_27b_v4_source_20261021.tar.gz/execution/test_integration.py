"""Artificial only: exercise actual worker phases, bindings and identity stops."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import ast

import protocol
import worker
import runner
from bound_request import canonical_sha256


class IntegrationChecks(unittest.TestCase):
    def test_active_ranking_language_and_tokenizer_are_identical_to_preserved_V3(self):
        old=worker.HERE.parent/'standalone_execution_v3/unique40_core.py'
        new=worker.HERE/'unique40_core.py'
        def definitions(path):
            return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(path.read_text()).body if isinstance(x,(ast.ClassDef,ast.FunctionDef))}
        before,after=definitions(old),definitions(new)
        for name in ['State','Unique40Language','TokenVocabulary','bytelevel_inverse']:
            self.assertEqual(before[name],after[name])

    def test_project_GPU_helper_is_exactly_pinned_and_requires_own_allocation(self):
        path=worker.ROOT/'scripts/project_gpu_audit_20261021.py'
        plan={'project_gpu_audit_helper':str(path),'project_gpu_audit_helper_sha256':worker.sha(path)}
        calls=[]
        fake=SimpleNamespace(conservative_project_gpu_audit=lambda **kwargs:calls.append(kwargs) or {'project_requested_GPUs':2,'all_account_requested_GPUs':11})
        with patch.object(worker,'load_module',return_value=fake):
            result=worker.project_gpu_audit(plan)
        self.assertEqual(result['project_requested_GPUs'],2)
        self.assertEqual(calls,[{'require_own_job':True}])
        plan['project_gpu_audit_helper_sha256']='0'*64
        with patch.object(worker,'load_module') as loader:
            with self.assertRaises(ValueError):worker.project_gpu_audit(plan)
            loader.assert_not_called()

    def fixture(self,directory,dev_pass=True,benchmark_terminal=34):
        root=Path(directory);runtime=root/'runtime';runtime.mkdir()
        identity=root/'identity.json';identity.write_text('{}')
        admission=root/'admission.json';admission.write_text('{}')
        configs={}
        for phase,count in [('development',3),('benchmark',34)]:
            cfg={'task_id':'P19','run_id':'invented-'+phase,'planned':count}
            path=root/(phase+'.json');path.write_text(json.dumps(cfg));configs[phase]=path
        plan={'runtime_root':str(runtime),'development_config':str(configs['development']),
              'benchmark_config':str(configs['benchmark']),'development_config_sha256':worker.sha(configs['development']),
              'benchmark_config_sha256':worker.sha(configs['benchmark']),'runner':'invented-runner',
              'scorer':'invented-native-scorer','generation':runner.GENERATION,'endpoint':'http://127.0.0.1:8419/v1',
              'source_scope_sha256':'invented-scope','model_directory':'invented-model','scorer_only_manifest':'not-read'}
        calls=[]
        def run(command,check):
            calls.append(command)
            if command[1]=='invented-native-scorer':
                target=Path(command[command.index('--output')+1]);target.write_text(json.dumps({'planned_assays':34,'native_panel_assays':123,'full_native_benchmark_complete':False,'native_scoring_status':'completed_native_scored_reviewed_subset','native_metrics':{'artificial_metric':0}}));return
            phase='development' if command[command.index('--config')+1]==str(configs['development']) else 'benchmark'
            output=Path(command[command.index('--output')+1]);output.mkdir()
            count=3 if phase=='development' else 34
            done={'task_id':'P19','config_sha256':plan[phase+'_config_sha256'],'generation':runner.GENERATION,
                  'biological_correctness_assessed':False,'delivery_passed_all':dev_pass,'planned':count,
                  'terminal':count if phase=='development' else benchmark_terminal,'responses_saved':count,
                  'delivery_passed':count if dev_pass else 0,'prediction_lock_sha256':'invented-lock',
                  **{key:0 for key in ['transport_errors','http_errors','response_errors','truncations','empty_finals','refusals','reasoning_present']}}
            (output/'completion.json').write_text(json.dumps(done))
        return plan,identity,admission,calls,run

    def execute(self,fixture):
        plan,identity,admission,calls,run=fixture
        fake=SimpleNamespace(validate_development=lambda cfg,path:None)
        with patch.object(worker,'load_module',return_value=fake),patch.object(worker.subprocess,'run',side_effect=run),patch.dict(worker.os.environ,{'SLURM_JOB_ID':'invented-job'}):
            return worker.execute_phases(plan,'invented-python',identity,admission)

    def test_actual_failed_synthetic_phase_creates_no_benchmark_grant_or_scoring_attempt(self):
        with tempfile.TemporaryDirectory() as directory:
            f=self.fixture(directory,dev_pass=False)
            with self.assertRaises(ValueError):self.execute(f)
            runtime=Path(f[0]['runtime_root'])
            self.assertEqual(len(f[3]),1)
            self.assertFalse((runtime/'benchmark_runtime_grant.json').exists())
            self.assertFalse((runtime/'scoring_attempt.json').exists())

    def test_actual_partial34_phase_never_reaches_scorer(self):
        with tempfile.TemporaryDirectory() as directory:
            f=self.fixture(directory,benchmark_terminal=33)
            with self.assertRaises(ValueError):self.execute(f)
            self.assertEqual(len(f[3]),2)
            self.assertFalse((Path(f[0]['runtime_root'])/'scoring_attempt.json').exists())

    def test_actual_order_is_exact3_then34_then_sole_native_score(self):
        with tempfile.TemporaryDirectory() as directory:
            f=self.fixture(directory);result=self.execute(f)
            self.assertEqual(len(f[3]),3)
            self.assertEqual(f[3][-1][1],'invented-native-scorer')
            self.assertTrue((Path(f[0]['runtime_root'])/'scoring_attempt.json').exists())
            self.assertFalse(result['full_native123_complete'])
            with self.assertRaises(ValueError):self.execute(f)
            self.assertEqual(len(f[3]),3)  # Existing output blocks another call.

    def test_payload_uses_exact_bound_input_and_never_generation_template_as_HTTP_body(self):
        sequence='ACDEFGHIKLMNPQRSTVWY'*2
        case={'task_id':'P19','case_id':'P19::artificial','messages':[{'role':'user','content':'Invented native full sequence `'+sequence+'`'}]}
        context={'case_id':case['case_id'],'wildtype_sequence':sequence,'sequence_length':len(sequence)}
        cfg={'case_bindings':{case['case_id']:{'case_sha256':canonical_sha256(case),'context_sha256':canonical_sha256(context),'base_generation_sha256':canonical_sha256(runner.BASE_GENERATION)}}}
        value=runner.payload(case,{case['case_id']:sequence},cfg)
        self.assertEqual(value['messages'],case['messages'])
        self.assertIn('enum',value['structured_outputs']['json']['properties']['ranking']['items'])
        self.assertNotIn('per_case_input_valid_enum_and_mandatory_unique40_prefix_mask',value['structured_outputs'])
        self.assertEqual(value['vllm_xargs']['p19_unique40_condition'],protocol.CONDITION)
        changed=deepcopy(case);changed['messages'][0]['content']='changed'
        with self.assertRaises(ValueError):runner.payload(changed,{case['case_id']:sequence},cfg)

    def test_foreign_plugin_identity_is_rejected_even_with_correct_model(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);cfgpath=root/'config.json';cfgpath.write_text('{}')
            identity={'model':runner.MODEL,'revision':runner.REVISION,'dtype':'bfloat16','condition':protocol.CONDITION,'model_runner':'legacy_V1_explicit','custom_logits_processor':'foreign:Unconstrained','plugin_sha256':runner.sha(worker.HERE/'p19_unique40_logits.py')}
            ipath=root/'identity.json';ipath.write_text(json.dumps(identity))
            grant={'authorized':True,'task_id':'P19','run_id':'invented','config_sha256':runner.sha(cfgpath),'endpoint':'http://127.0.0.1:8419/v1','server_identity_file':str(ipath),'server_identity_sha256':runner.sha(ipath)}
            gpath=root/'grant.json';gpath.write_text(json.dumps(grant))
            with self.assertRaises(ValueError):runner.validate_grant(gpath,cfgpath,{'task_id':'P19','run_id':'invented'})


if __name__=='__main__':unittest.main(verbosity=2)
