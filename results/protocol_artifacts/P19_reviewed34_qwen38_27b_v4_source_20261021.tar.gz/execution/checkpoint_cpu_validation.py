"""Actual tokenizer/CPU logits/API tests. No model construction or forwards."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import random
import sys
import time
import types
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def main():
    assert os.environ.get("CUDA_VISIBLE_DEVICES") == ""
    assert os.environ.get("SLURM_JOB_ID"), "Use the ordinary CPU-only allocation"
    assert not os.environ.get("SLURM_GPUS")
    plan = json.loads((HERE / "CPU_plan.json").read_text())
    for name, digest in plan["file_sha256"].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
    import torch
    from tokenizers import Tokenizer
    from unique40_core import CONDITION, ConstraintError, RequestConstraint, State, TokenVocabulary, Unique40Language
    from source_api_harness import load_verbatim_adapter, import_production_adapter_with_source_base
    from request_contract import prospective_request

    torch.set_num_threads(4)
    started = time.monotonic()
    tokenizer_path = Path(plan["tokenizer"])
    vocabulary = TokenVocabulary.from_checkpoint_tokenizer(tokenizer_path, plan["tokenizer_sha256"], set(plan["EOS_ids"]))
    tokenizer = Tokenizer.from_file(str(tokenizer_path))
    checks = {}
    for token_id, piece in vocabulary.pieces.items():
        assert tokenizer.decode([token_id], skip_special_tokens=False).encode() == piece
    checks["every_usable_token_piece_matches_actual_pinned_decoder"] = len(vocabulary.pieces)
    alphabet = set(b'{}[]":,ranking0123456789 \t\n\rACDEFGHIKLMNPQRSTVWY')
    singles = {piece[0] for piece in vocabulary.pieces.values() if len(piece) == 1}
    assert alphabet <= singles
    checks["all_grammar_characters_have_lossless_single_byte_tokens"] = len(alphabet)
    assert vocabulary.eos_ids.isdisjoint(vocabulary.pieces)
    checks["special_EOS_and_padded_tokens_excluded_until_completion"] = True
    panel = []
    rng = random.Random(314701)
    for length in [40, 71, 100]:
        sequence = ("ACDEFGHIKLMNPQRSTVWY" * 5)[:length]
        language = Unique40Language(sequence)
        ranking = rng.sample(sorted(language.allowed), 40)
        text = json.dumps({"ranking": ranking}, separators=(",", ":"))
        ids = tokenizer.encode(text, add_special_tokens=False).ids
        assert tokenizer.decode(ids, skip_special_tokens=False) == text
        constraint = RequestConstraint(sequence, vocabulary)
        output_ids = []
        max_allowed = 0
        for next_id in ids:
            logits = torch.zeros(plan["model_padded_vocabulary_size"], dtype=torch.float32)
            result = constraint(output_ids, logits)
            assert result is logits and torch.isfinite(logits[next_id])
            assert not torch.isfinite(logits[list(vocabulary.eos_ids)]).any()
            max_allowed = max(max_allowed, int(torch.isfinite(logits).sum()))
            output_ids.append(next_id)
        logits = torch.zeros(plan["model_padded_vocabulary_size"])
        constraint(output_ids, logits)
        assert constraint.state.phase == "done" and len(constraint.state.used) == 40
        assert torch.isfinite(logits[list(vocabulary.eos_ids)]).all()
        # Only EOS and permitted trailing whitespace survive after the full JSON.
        for token_id in torch.where(torch.isfinite(logits))[0].tolist():
            if token_id not in vocabulary.eos_ids:
                assert set(vocabulary.pieces[token_id]) <= set(b" \t\n\r")
        constraint.update(output_ids + [min(vocabulary.eos_ids)])
        assert constraint.eos_seen
        panel.append({"invented_sequence_length":length,"valid_ID_space":len(language.allowed),"output_tokens_CPU_checked":len(ids),"unique_entries":40,"max_allowed_next_tokens":max_allowed})
    checks["three_artificial40_rankings_checked_at_every_actual_token_boundary"] = True
    checks["terminal_EOS_available_only_after_complete_valid40"] = True

    # Run the exact pinned Adapter/BatchUpdate/utility source methods on CPU,
    # with the concrete production subclass unchanged at the import boundary.
    scope = load_verbatim_adapter(HERE / "sources", torch)
    module = import_production_adapter_with_source_base(scope)
    config = types.SimpleNamespace(speculative_config=None, model_config=types.SimpleNamespace(model=str(tokenizer_path.parent)))
    with patch.dict(os.environ, {"VLLM_USE_V2_MODEL_RUNNER":"0"}), patch.object(importlib.metadata,"version",return_value="0.32.0"):
        adapter = module.P19Unique40LogitsProcessor(config, torch.device("cpu"), False)
    assert not adapter.is_argmax_invariant()
    def params(sequence):
        original = {"messages":[{"role":"user","content":"Invented native prompt"}],"n":1,"structured_outputs":{"json":{}}}
        request = prospective_request(original,sequence)
        return types.SimpleNamespace(extra_args=request["vllm_xargs"],n=1)
    sequence = "ACDEFGHIKLMNPQRSTVWY" * 2
    a_out, b_out = [], []
    BatchUpdate = scope["BatchUpdate"]
    direction = scope["MoveDirectionality"]
    adapter.update_state(BatchUpdate(batch_size=2,removed=[],added=[(0,params(sequence),[],a_out),(1,params("Y"*40),[],b_out)],moved=[]))
    logits = torch.zeros((2,plan["model_padded_vocabulary_size"]))
    adapter.apply(logits)
    assert torch.isfinite(logits).sum(1).min() > 0
    a_out.extend(tokenizer.encode('{"ranking":["A1C",',add_special_tokens=False).ids)
    adapter.update_state(None)  # Existing request holds a live output list.
    adapter.apply(torch.zeros_like(logits))
    assert adapter.req_info[0].func.state.used == frozenset({"A1C"})
    assert not adapter.req_info[1].func.state.used
    checks["verbatim_adapter_live_output_list_and_per_request_state"] = True
    a_processor = adapter.req_info[0]
    b_processor = adapter.req_info[1]
    adapter.update_state(BatchUpdate(batch_size=2,removed=[],added=[],moved=[(0,1,direction.SWAP)]))
    assert adapter.req_info[0] is b_processor and adapter.req_info[1] is a_processor
    adapter.apply(torch.zeros_like(logits))
    checks["verbatim_adapter_batch_swap"] = True
    adapter.update_state(BatchUpdate(batch_size=1,removed=[0],added=[],moved=[(1,0,direction.UNIDIRECTIONAL)]))
    assert set(adapter.req_info)=={0} and adapter.req_info[0] is a_processor
    adapter.apply(torch.zeros((1,plan["model_padded_vocabulary_size"])))
    checks["verbatim_adapter_removal_and_unidirectional_move"] = True
    adapter.update_state(BatchUpdate(batch_size=0,removed=[0],added=[],moved=[]))
    adapter.update_state(BatchUpdate(batch_size=1,removed=[],added=[(0,params(sequence),[],[])],moved=[]))
    assert not adapter.req_info[0].func.state.used
    checks["reused_slot_has_no_old_used_ID_state"] = True
    bad = types.SimpleNamespace(extra_args={},n=1)
    try: module.P19Unique40LogitsProcessor.validate_params(bad)
    except ValueError: pass
    else: raise AssertionError("missing constraint arguments accepted")
    modified = params(sequence); modified.extra_args["p19_unique40_sequence_sha256"] = "0"*64
    try: module.P19Unique40LogitsProcessor.validate_params(modified)
    except ValueError: pass
    else: raise AssertionError("wrong sequence binding accepted")
    checks["request_validation_rejects_missing_and_mismatched_binding"] = True
    adapter.req_info.clear()
    try: adapter.apply(torch.zeros((1,plan["model_padded_vocabulary_size"])))
    except ValueError: pass
    else: raise AssertionError("unconstrained active row accepted")
    checks["missing_lifecycle_row_fails_closed"] = True
    constraint = RequestConstraint(sequence, vocabulary)
    try: constraint([],torch.full((plan["model_padded_vocabulary_size"],),float("-inf")))
    except ConstraintError: pass
    else: raise AssertionError("all masked logits fell back unconstrained")
    checks["all_nonfinite_allowed_logits_fail_without_fallback"] = True
    from terminal_cpu_checks import check_terminal_callbacks
    checks.update(check_terminal_callbacks(HERE,vocabulary,tokenizer,torch,scope,adapter,params))
    result = {"stage":"CPU_tokenizer_prefix_mask_and_verbatim_API_lifecycle_passed_not_model_delivery","job_id":os.environ["SLURM_JOB_ID"],"checks":checks,"checks_passed":len(checks),"artificial_panels":panel,"tokenizer_sha256":plan["tokenizer_sha256"],"usable_exact_token_pieces":len(vocabulary.pieces),"vocabulary_size":vocabulary.vocab_size,"torch_version":importlib.metadata.version("torch"),"tokenizers_version":importlib.metadata.version("tokenizers"),"elapsed_seconds":time.monotonic()-started,"actual_installed_vllm_engine_imported":False,"verbatim_pinned_vllm_source_methods_executed":True,"actual_model_weights_loaded":False,"model_forwards":0,"model_calls":0,"target_measurements_opened":False,"real_assay_inputs_opened":False,"GPU_allocations":0,"runtime_adoption":False}
    (HERE / "CPU_validation.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"stage":result["stage"],"checks_passed":len(checks),"usable_token_pieces":len(vocabulary.pieces),"elapsed_seconds":result["elapsed_seconds"]}),flush=True)


if __name__ == "__main__": main()
