"""Replay the neutral V3 terminal failure and source lifecycle without inference."""
import importlib.util
import json
import hashlib
import sys


def check_terminal_callbacks(here, vocabulary, tokenizer, torch, scope, adapter, params):
    from unique40_core import ConstraintError, RequestConstraint
    old_run=here.parent/"standalone_execution_v3"
    spec=importlib.util.spec_from_file_location("p19_preserved_V3_terminal_core",old_run/"unique40_core.py")
    old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
    responses=list((old_run/"runtime/development/responses").glob("*.json"));assert len(responses)==1
    response=json.loads(responses[0].read_text());assert response["choices"][0]["finish_reason"]=="stop"
    contexts=json.loads((here.parent/"development_delivery_contexts.json").read_text())["cases"]
    rows=[x for x in contexts if hashlib.sha256(x["case_id"].encode()).hexdigest()==responses[0].stem]
    assert len(rows)==1 and "synthetic_delivery" in rows[0]["case_id"]
    sequence=rows[0]["wildtype_sequence"];final=response["choices"][0]["message"]["content"]
    ids=tokenizer.encode(final,add_special_tokens=False).ids
    assert tokenizer.decode(ids,skip_special_tokens=False)==final
    eos=min(vocabulary.eos_ids);history=ids+[eos]
    previous=old.RequestConstraint(sequence,vocabulary);previous.update(history)
    try:previous(history,torch.zeros(248320))
    except old.ConstraintError as error:assert str(error)=="sampler_called_after_EOS"
    else:raise AssertionError("preserved V3 failure did not reproduce")
    current=RequestConstraint(sequence,vocabulary);current.update(history)
    assert current.state.phase=="done" and len(current.state.used)==40
    for fill in [0.0,float("-inf"),float("nan")]:
        logits=torch.full((248320,),fill);current(history,logits)
        assert set(torch.where(torch.isfinite(logits))[0].tolist())==set(vocabulary.eos_ids)
    repeated=history+[eos,eos,max(vocabulary.eos_ids)];current.update(repeated)
    logits=torch.zeros(248320);current(repeated,logits)
    assert set(torch.where(torch.isfinite(logits))[0].tolist())==set(vocabulary.eos_ids)
    ordinary=next(k for k,v in vocabulary.pieces.items() if v==b"A")
    try:current.update(repeated+[ordinary])
    except ConstraintError:pass
    else:raise AssertionError("ordinary post-EOS bytes were permitted")
    premature=RequestConstraint(sequence,vocabulary)
    try:premature.update([eos])
    except ConstraintError:pass
    else:raise AssertionError("premature EOS was permitted")
    corrupt=RequestConstraint(sequence,vocabulary);corrupt.eos_seen=True
    try:corrupt([],torch.zeros(248320))
    except ConstraintError:pass
    else:raise AssertionError("invalid internal EOS state became unconstrained")
    BatchUpdate=scope["BatchUpdate"];direction=scope["MoveDirectionality"]
    adapter.req_info.clear();a_out=list(history);b_out=[]
    adapter.update_state(BatchUpdate(batch_size=2,removed=[],added=[(0,params(sequence),[],a_out),(1,params("Y"*40),[],b_out)],moved=[]))
    for _ in range(3):
        logits=torch.zeros((2,248320));logits[0].fill_(float("-inf"))
        adapter.update_state(None);adapter.apply(logits)
        assert set(torch.where(torch.isfinite(logits[0]))[0].tolist())==set(vocabulary.eos_ids)
        assert not torch.isfinite(logits[1,list(vocabulary.eos_ids)]).any()
    a_out.extend([eos,eos]);adapter.update_state(None);adapter.apply(torch.zeros((2,248320)))
    remaining=adapter.req_info[1]
    adapter.update_state(BatchUpdate(batch_size=1,removed=[0],added=[],moved=[(1,0,direction.UNIDIRECTIONAL)]))
    assert adapter.req_info[0] is remaining and not remaining.func.eos_seen
    adapter.apply(torch.zeros((1,248320)))
    return {
        "preserved_neutral_V3_sampler_after_EOS_failure_reproduced":True,
        "V4_exact_same_complete_neutral_response_late_callback_is_EOS_only":True,
        "terminal_EOS_mask_stays_finite_with_zero_allinf_or_NaN_upstream":True,
        "repeated_internal_EOS_accepted_without_new_ranking_content":True,
        "ordinary_postEOS_prematureEOS_and_corrupt_terminal_state_rejected":True,
        "verbatim_source_mixed_batch_late_callback_and_retirement_passed":True,
    }
