"""Freeze exact P19 V3 worker/configs; no admission, calls or allocation."""
import copy
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
ROOT = HERE.parents[4]
sys.path.insert(0,str(HERE));sys.path.insert(0,str(ROOT/'scripts'))
import protocol
import worker
import runner
import run_p19_available_20261020 as original
from bound_request import canonical_sha256


def read(path):return json.loads(Path(path).read_text())


def main():
    if (HERE/'plan.json').exists():raise FileExistsError('Frozen V3 plan already exists')
    old=TASK/'standalone_execution_v1';previous=read(old/'plan.json')
    pins={}
    def pin(path,expected=None):
        path=Path(path);path=path if path.is_absolute() else ROOT/path
        digest=worker.sha(path)
        if expected is not None and digest!=expected:raise ValueError('Original frozen source changed:'+str(path))
        pins[str(path)]=digest
        return digest
    for name,digest in previous['frozen_files_sha256'].items():pin(name,digest)
    pin(old/'plan.json','09ad72eb3026b1b99548341abe6f144b2e2e2c75ca288fd28154cd9a02b1e4c4')
    pin(old/'failure_closure.json','44bc0875d49ee2ea4e811a84a9d73363d1aadd4c58cc97fa6bcef293ed58d632')
    lock=old/'runtime/development/prediction_lock.json'
    pin(lock,'0fa103fbb1600700fed3a31e25122f5a293976a9a42ce0ceb3cf3f8866b6842a')
    for name,digest in read(lock)['files_sha256'].items():pin(lock.parent/name,digest)
    proposal=old/'unique_generation_proposal_v3'
    pin(proposal/'completion.json','4c1b587b0b14c506f832eda24fc0d3a9a434853c78d115abb3a8cdf774574a08')
    for name in ['p19_unique40_logits.py','request_contract.py','bound_request.py']:
        if worker.sha(HERE/name)!=worker.sha(proposal/name):raise ValueError('Production prefix contract differs from tested V3:'+name)
    failed_v3=TASK/'standalone_execution_v3'
    pin(failed_v3/'plan.json','54af6802e384d8a36b2c89fa2da912f87010ad5084bcad224052d49a766a02bd')
    pin(failed_v3/'failure_closure.json','f1bfcbdc7de8bc12de6d72c0cc66f4d6e1d0d2bbc63ff5b8a5c48214c1e60de2')
    v3_lock=failed_v3/'runtime/development/prediction_lock.json'
    pin(v3_lock,'8b7a09d6c2730bb2ec4151469f588e282f706e1f254296f0e080a36d53a2749c')
    for name,digest in read(v3_lock)['files_sha256'].items():pin(v3_lock.parent/name,digest)
    gpu_helper=ROOT/'scripts/project_gpu_audit_20261021.py'
    pin(gpu_helper,'9045eaf578e27dedcd5aba285b5a6253240244d70f52b7ad93e0dd7c0ecf9cc9')
    pin(HERE/'CPU_validation.json')
    pin(HERE/'CPU_terminal.json')
    source=read(old/'source_scope.json')
    if [source.get(x) for x in ['approved','native_panel','held','unreviewed']]!=[34,123,12,77]:raise ValueError('Scope changed')
    if source['approved_organism_counts']!={'Homo sapiens (Human)':33,'Bos taurus (Bovine)':1}:raise ValueError('Reviewed organism scope changed')
    source['condition']=protocol.CONDITION
    source['original_scope_sha256']=worker.sha(old/'source_scope.json')
    source['prospective_output_constraint']='mandatory source-supported V1 custom token-prefix mask; input-valid enum; no target filtering'
    worker.save(HERE/'source_scope.json',source)
    code_names=['worker.py','protocol.py','runner.py','unique40_core.py','p19_unique40_logits.py','request_contract.py','bound_request.py','freeze.py','test_worker.py','test_integration.py','prepare_publication.py']
    local_code={str(HERE/name):worker.sha(HERE/name) for name in code_names}
    for phase,expected in [('development',3),('benchmark',34)]:
        cfg,cases,contexts=original.load_contract(TASK/(phase+'_config.json'))
        if len(cases)!=expected or cfg['planned']!=expected:raise ValueError('Original ordered cohort changed')
        if phase=='benchmark' and [x['case_id'] for x in cases]!=source['approved_case_ids']:raise ValueError('Review join changed')
        cfg=copy.deepcopy(cfg)
        cfg['condition']=protocol.CONDITION
        cfg['run_id']='qwen38_27b_p19_'+('synthetic3' if phase=='development' else 'reviewed34')+'_unique40_eos16k_2026-10-21_v4'
        cfg['generation']=runner.GENERATION
        cfg['base_generation_sha256']=canonical_sha256(original.GENERATION)
        cfg['case_bindings']={}
        for case in cases:
            seq=contexts[case['case_id']]
            context={'case_id':case['case_id'],'wildtype_sequence':seq,'sequence_length':len(seq)}
            cfg['case_bindings'][case['case_id']]={'case_sha256':canonical_sha256(case),'context_sha256':canonical_sha256(context),'base_generation_sha256':canonical_sha256(original.GENERATION)}
        cfg['files_sha256'].update(local_code)
        cfg['material_differences']=list(cfg.get('material_differences',[]))+['V4 input-valid output enum plus mandatory byte-prefix uniqueness mask with idempotent already-EOS terminal state; explicit legacyV1 runner; all valid ranking orders retained. Original V1/V3 outputs preserved separately.']
        if phase=='benchmark':cfg['development_config_sha256']=worker.sha(HERE/'development_config.json')
        worker.save(HERE/(phase+'_config.json'),cfg)
        checked,newcases,_=runner.load_contract(HERE/(phase+'_config.json'))
        if [x['messages'] for x in newcases]!=[x['messages'] for x in cases]:raise ValueError('Native prompt changed')
    for name in code_names+['source_scope.json','development_config.json','benchmark_config.json']:pin(HERE/name)
    sbatch=f'''#!/bin/bash
#SBATCH --job-name=bio-p19-unique40-v4
#SBATCH --partition=il
#SBATCH --account=infolab
#SBATCH --gres=gpu:a100:1
#SBATCH --cpus-per-task=10
#SBATCH --mem=96G
#SBATCH --time=12:00:00
#SBATCH --chdir={ROOT}
#SBATCH --output={HERE}/slurm-%j.log
set -euo pipefail
umask 077
unset OPENAI_API_KEY ANTHROPIC_API_KEY GEMINI_API_KEY GOOGLE_API_KEY AZURE_OPENAI_API_KEY HF_TOKEN HUGGING_FACE_HUB_TOKEN
unset OPENAI_BASE_URL OPENAI_ORG_ID OPENAI_ORGANIZATION OPENAI_PROJECT_ID PYTHONPATH PYTHONHOME VIRTUAL_ENV SSH_AUTH_SOCK
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONNOUSERSITE=1
exec /usr/bin/python3 {HERE}/worker.py --plan {HERE}/plan.json --plan-sha256 "$1" --admission "$2" --admission-sha256 "$3"
'''
    (HERE/'worker.sbatch').write_text(sbatch);pin(HERE/'worker.sbatch')
    plan=copy.deepcopy(previous)
    plan.update(created_at_pacific=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),scope=protocol.SCOPE,condition=protocol.CONDITION,
        source_scope_sha256=worker.sha(HERE/'source_scope.json'),generation=runner.GENERATION,
        development_config=str(HERE/'development_config.json'),development_config_sha256=worker.sha(HERE/'development_config.json'),
        benchmark_config=str(HERE/'benchmark_config.json'),benchmark_config_sha256=worker.sha(HERE/'benchmark_config.json'),
        runner=str(HERE/'runner.py'),runtime_root=str(HERE/'runtime'),
        mandatory_model_runner='legacy_V1_explicit',custom_logits_processor='p19_unique40_logits:P19Unique40LogitsProcessor',
        plugin_sha256=worker.sha(HERE/'p19_unique40_logits.py'),
        project_gpu_audit_helper=str(gpu_helper),project_gpu_audit_helper_sha256=worker.sha(gpu_helper),
        GPU_accounting_scope='bio-evaluation project<=8; full account inventory private; exact root-verified unrelated identities excluded only by frozen helper',
        preserved_failed_V1_plan_sha256=worker.sha(old/'plan.json'),preserved_failed_V1_lock_sha256=worker.sha(lock),
        prefix_constraint_CPU_completion_sha256=worker.sha(proposal/'completion.json'),
        frozen_files_sha256=pins,runtime_admission_granted=False,submission_by_preparation=False,new_model_calls=0,new_GPU_allocations=0)
    worker.save(HERE/'plan.json',plan);digest=worker.sha(HERE/'plan.json');(HERE/'plan.sha256').write_text(digest+'\n')
    worker.save(HERE/'root_admission_NOT_GRANTED_template.json',{'admitted':False,'task_id':'P19','scope':protocol.SCOPE,'condition':protocol.CONDITION,
        'plan_sha256':digest,'source_scope_sha256':plan['source_scope_sha256'],'gpu_count':1,'project_gpu_ceiling':8,
        'allow_benchmark_only_after_development_gate':True,'gpu_audit_receipt':None,'gpu_audit_receipt_sha256':None})
    worker.save(HERE/'freeze_receipt.json',{'at_pacific':plan['created_at_pacific'],'plan_sha256':digest,'dependency_pins':len(pins),'scope':{'approved':34,'native':123,'held':12,'unreviewed':77,'human':33,'bovine':1},
        'native_prompts_source_inputs_and_scorer_unchanged':True,'original_failed_V1_outputs_preserved':True,
        'target_measurement_rows_parsed':False,'new_content_review':False,'root_admission':False,'model_calls':0,'GPU_allocations':0})
    print(json.dumps({'plan_sha256':digest,'pins':len(pins),'admitted':False,'model_calls':0,'GPU_allocations':0}))


if __name__=='__main__':main()
