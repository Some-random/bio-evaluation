"""Invented phase/count fixtures only; no model, source tables or real outputs."""
from copy import deepcopy
import ast
from pathlib import Path
import json
import tempfile
from types import SimpleNamespace
import unittest

import protocol
import worker


GENERATION = {'max_tokens':16384,'chat_template_kwargs':{'enable_thinking':False}}
PLAN = {'development_config_sha256':'invented-dev','benchmark_config_sha256':'invented-bench','generation':GENERATION}


def dev():
    return {'task_id':'P19','config_sha256':'invented-dev','generation':GENERATION,
        'biological_correctness_assessed':False,'delivery_passed_all':True,
        'planned':3,'terminal':3,'responses_saved':3,'delivery_passed':3,
        'transport_errors':0,'http_errors':0,'response_errors':0,'truncations':0,
        'empty_finals':0,'refusals':0,'reasoning_present':0,'prediction_lock_sha256':'invented-lock'}


def bench():
    return {'task_id':'P19','config_sha256':'invented-bench','generation':GENERATION,
        'planned':34,'terminal':34,'prediction_lock_sha256':'invented-benchmark-lock'}


def score(undefined=False):
    return {'planned_assays':34,'native_panel_assays':123,'full_native_benchmark_complete':False,
        'native_scoring_status':'undefined_native_strict_coverage_failure' if undefined else 'completed_native_scored_reviewed_subset',
        'native_metrics':None if undefined else {'invented_metric':0}}


class StandaloneChecks(unittest.TestCase):
    def test_exact_order_is_development_then34_then_scorer(self):
        seen=[]
        def d():seen.append('development');return dev()
        def b(_):seen.append('benchmark34');return bench()
        def s(_):seen.append('native-score');return score()
        result=protocol.run_order(PLAN,d,b,s)
        self.assertEqual(seen,['development','benchmark34','native-score'])
        self.assertFalse(result['full_native123_complete']);self.assertFalse(result['full_catalog_complete'])

    def test_each_development_failure_blocks_every_benchmark_and_score(self):
        for field in ['transport_errors','http_errors','response_errors','truncations','empty_finals','refusals','reasoning_present']:
            failed=dev();failed[field]=1;calls=[]
            with self.assertRaises(ValueError):protocol.run_order(PLAN,lambda:failed,lambda _:calls.append('benchmark'),lambda _:calls.append('score'))
            self.assertEqual(calls,[])

    def test_partial_or_unsealed_development_is_rejected(self):
        for field,value in [('terminal',2),('responses_saved',2),('delivery_passed',2),('prediction_lock_sha256',None),('config_sha256','foreign')]:
            failed=dev();failed[field]=value
            with self.assertRaises(ValueError):protocol.require_development(failed,'invented-dev',GENERATION)

    def test_no_scoring_after_partial_benchmark(self):
        failed=bench();failed['terminal']=33;calls=[]
        with self.assertRaises(ValueError):protocol.run_order(PLAN,dev,lambda _:failed,lambda _:calls.append('score'))
        self.assertEqual(calls,[])

    def test_complete34_with_native_undefined_metric_retains_denominator(self):
        result=protocol.run_order(PLAN,dev,lambda _:bench(),lambda _:score(True))
        self.assertEqual(result['score']['planned_assays'],34)
        self.assertIsNone(result['score']['native_metrics'])
        self.assertFalse(result['full_native123_complete'])

    def test_changed_generation_cannot_reuse_development(self):
        changed=deepcopy(GENERATION);changed['max_tokens']=4096
        with self.assertRaises(ValueError):protocol.require_development(dev(),'invented-dev',changed)

    def test_full123_completion_claim_is_rejected(self):
        wrong=score();wrong['full_native_benchmark_complete']=True
        with self.assertRaises(ValueError):protocol.run_order(PLAN,dev,lambda _:bench(),lambda _:wrong)

    def test_disabled_or_foreign_root_admission_is_rejected(self):
        admission={'admitted':True,'task_id':'P19','scope':protocol.SCOPE,'plan_sha256':'plan',
            'condition':protocol.CONDITION,'source_scope_sha256':'scope','gpu_count':1,'project_gpu_ceiling':8,
            'allow_benchmark_only_after_development_gate':True}
        protocol.validate_admission_data(admission,'plan','scope')
        for key,value in [('admitted',False),('task_id','P20'),('gpu_count',2),('plan_sha256','foreign'),('source_scope_sha256','foreign')]:
            changed={**admission,key:value}
            with self.assertRaises(PermissionError):protocol.validate_admission_data(changed,'plan','scope')

    def test_benchmark_grant_cannot_exist_without_actual_development(self):
        with tempfile.TemporaryDirectory() as directory:
            plan={'runtime_root':directory}
            with self.assertRaises(ValueError):worker.phase_grant(plan,{},None,None,'benchmark')

    def test_terminal_artifacts_are_exclusive(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'sole_attempt.json';worker.save(path,{'invented':True})
            with self.assertRaises(FileExistsError):worker.save(path,{'replacement':True})

    def test_extracted_archive_installs_pinned_packages_before_reexec_and_guard(self):
        helper_path=worker.ROOT/'.local/catalog_execution_2026-10-20/tasks/V06/local_execution_v2/worker.py'
        real=worker.load_module('p19_test_vetted_v06_installer',helper_path,helper_path.parent)
        events=[]
        with tempfile.TemporaryDirectory() as directory:
            runtime=Path(directory)/'output';runtime.mkdir()
            local=Path(directory)/'private-extracted-prefix';local.mkdir()
            common=SimpleNamespace(apply_overlay=lambda path:events.append('overlay') or {'base':'invented-base','overlay':'invented-overlay'},
                environment=lambda path:{'OPENAI_API_KEY':'invented-fixture-key','PATH':'invented-path'})
            def install(python,environment,output):
                self.assertEqual(events,['overlay'])
                self.assertNotIn('OPENAI_API_KEY',environment)
                self.assertEqual(python,local/'python/bin/python3.12')
                command=real.runtime_install_command(python,output/'pip_install_report.json')
                for name,version in real.PINNED_PACKAGES.items():self.assertIn(name+'=='+version,command)
                events.append('pinned-install-and-check')
            shared=SimpleNamespace(clean_environment=real.clean_environment,install_private_runtime=install)
            def reexec(python,command,environment):
                self.assertEqual(events,['overlay','pinned-install-and-check'])
                self.assertEqual(python,str(local/'python/bin/python3.12'))
                self.assertEqual(command[-2:],['--runtime-dir',str(local)])
                self.assertEqual(environment['VLLM_USE_V2_MODEL_RUNNER'],'0')
                self.assertEqual(environment['PYTHONPATH'],str(worker.HERE))
                events.append('private-exec')
                worker.verify_runtime_identity(real,{'packages':dict(real.PINNED_PACKAGES)},1)
                events.append('post-exec-package-and-GPU-guard')
            worker.activate_private_runtime(shared,common,local,runtime,['--invented-argument'],executor=reexec)
        self.assertEqual(events,['overlay','pinned-install-and-check','private-exec','post-exec-package-and-GPU-guard'])
        main=next(node for node in ast.parse(Path(worker.__file__).read_text()).body if isinstance(node,ast.FunctionDef) and node.name=='main')
        calls=[node for node in ast.walk(main) if isinstance(node,ast.Call)]
        extract=next(node.lineno for node in calls if isinstance(node.func,ast.Attribute) and node.func.attr=='extractall')
        activate=next(node.lineno for node in calls if isinstance(node.func,ast.Name) and node.func.id=='activate_private_runtime')
        guard=next(node.lineno for node in calls if isinstance(node.func,ast.Name) and node.func.id=='verify_runtime_identity')
        self.assertLess(extract,activate);self.assertLess(activate,guard)

    def test_vetted_guard_rejects_base031_or_any_wrong_package_and_GPU_count(self):
        helper_path=worker.ROOT/'.local/catalog_execution_2026-10-20/tasks/V06/local_execution_v2/worker.py'
        shared=worker.load_module('p19_test_vetted_package_guard',helper_path,helper_path.parent)
        good={'packages':dict(shared.PINNED_PACKAGES)}
        self.assertEqual(len(good['packages']),5)
        for name in shared.PINNED_PACKAGES:
            wrong=deepcopy(good);wrong['packages'][name]='0.31.0' if name=='vllm' else 'invented-wrong-version'
            with self.assertRaises(ValueError):worker.verify_runtime_identity(shared,wrong,1)
        for count in [0,2]:
            with self.assertRaises(ValueError):worker.verify_runtime_identity(shared,good,count)


if __name__=='__main__':unittest.main(verbosity=2)
