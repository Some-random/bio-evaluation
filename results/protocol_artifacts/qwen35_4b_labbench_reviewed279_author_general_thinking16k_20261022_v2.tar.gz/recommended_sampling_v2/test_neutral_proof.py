"""Synthetic proof/control checks. Never run a scheduler or model entrypoint."""
from pathlib import Path
from unittest import mock
import copy
import hashlib
import importlib.util
import json
import shutil
import tempfile
import unittest

import neutral_proof as proof

SOURCE = Path(__file__).resolve().parent


class ProofTests(unittest.TestCase):
    def write(self, path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, sort_keys=True) + '\n')
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / 'workspace' / 'comparison' / 'recommended'
        self.gate = self.root / 'neutral_validation'
        self.gate.mkdir(parents=True)
        for name in ['shared_runtime.py', 'neutral_validation/fixtures.py']:
            dest = self.root / name
            shutil.copyfile(SOURCE / name, dest)
        self.common = proof.module(self.root / 'shared_runtime.py', 'synthetic_proof_common')
        self.fixtures = proof.module(self.gate / 'fixtures.py', 'synthetic_proof_fixtures')
        self.contract = json.loads((SOURCE / 'shared_contract.json').read_text())
        self.contract['source_pins'] = {}
        self.contract['neutral_gate_receipt'] = str(self.gate / 'receipt.json')
        self.contract_sha = self.write(self.root / 'shared_contract.json', self.contract)
        self.plan = {'owner': '/root/owner', 'shared_contract': str(self.root / 'shared_contract.json'),
                     'shared_contract_sha256': self.contract_sha, 'biological_calls': 0,
                     'max_generations': 34, 'model_order': ['base', 'posttrained'],
                     'pins': {str(self.root / n): proof.sha(self.root / n)
                              for n in ['shared_runtime.py', 'neutral_validation/fixtures.py']}}
        self.plan_sha = self.write(self.gate / 'plan.json', self.plan)
        self.review = {'reviewer': '/root/peer', 'passed': True, 'plan_sha256': self.plan_sha}
        self.review_sha = self.write(self.root / 'independent_review.json', self.review)
        self.grant = {'issuer': '/root/peer', 'approved': True, 'plan_sha256': self.plan_sha,
                      'neutral_only': True, 'biological_dispatch_authorized': False,
                      'independent_review_path': str(self.root / 'independent_review.json'),
                      'independent_review_sha256': self.review_sha}
        self.grant_sha = self.write(self.root / 'neutral_grant.json', self.grant)
        self.decision = {'issuer': '/root', 'engineering_delegation': {'review_grant_issuers': ['/root/peer']}}
        self.decision_sha = self.write(self.root.parent / 'root_recommended_sampling_repair_decision_20261022.json', self.decision)
        self.patches = [mock.patch.object(proof, k, v) for k, v in {
            'HERE': self.root, 'GATE': self.gate, 'CONTRACT_SHA': self.contract_sha,
            'PLAN_SHA': self.plan_sha, 'GRANT_SHA': self.grant_sha, 'REVIEW_SHA': self.review_sha,
            'DECISION_SHA': self.decision_sha}.items()]
        for patch in self.patches:
            patch.start()
        self.addCleanup(lambda: [p.stop() for p in reversed(self.patches)])
        self.addCleanup(self.temp.cleanup)
        self.job = '999000'
        self.audit = {'own_job_id': self.job, 'project_GPU_ceiling': 8,
                      'additional_GPUs_reviewed': 0, 'model_calls': 0, 'unrelated_jobs_changed': False,
                      'project_requested_GPUs': 1, 'project_requested_GPUs_with_addition': 1,
                      'jobs': [{'job_id': self.job, 'gpus': 1, 'counted_toward_evaluation_project': True,
                                'state': 'RUNNING', 'command': str(self.gate / 'worker.sbatch'),
                                'workdir': str(self.root.parents[2])}]}
        self.write(self.gate / 'submission.json', {'job_id': self.job, 'plan_sha256': self.plan_sha,
                                                  'grant_sha256': self.grant_sha})
        self.write(self.gate / 'submission_attempt.json', {'plan_sha256': self.plan_sha, 'command': [
            'sbatch', '--parsable', str(self.gate / 'worker.sbatch'), '--plan', str(self.gate / 'plan.json'),
            '--plan-sha256', self.plan_sha, '--grant', str(self.root / 'neutral_grant.json'),
            '--grant-sha256', self.grant_sha]})
        self.write(self.gate / 'started.json', {'job_id': self.job, 'plan_sha256': self.plan_sha})
        self.write(self.gate / 'private_gpu_audit_start.json', self.audit)
        self.receipt = {'passed': True, 'shared_contract_sha256': self.contract_sha,
                        'plan_sha256': self.plan_sha, 'job_id': self.job, 'synthetic_only': True,
                        'biological_calls': 0, 'no_biological_scope_admission': True, 'models': {}}
        cases, expected = self.fixtures.fixtures()
        self.done = {}
        for key, (model, revision) in proof.MODELS.items():
            root = self.gate / key
            self.write(root / 'phase_claim.json', {'model_key': key, 'job_id': self.job, 'no_retry': True})
            self.write(root / 'private_gpu_audit.json', self.audit)
            self.write(root / 'runtime.json', {'model_key': key, 'GPU_count': 1, 'dtype': 'bfloat16',
                                              'packages': self.contract['runtime_expected']})
            self.write(root / 'effective_native_sampling.json', {'values': {n: self.contract['generation'][n]
                       for n in ('temperature', 'top_p', 'top_k', 'presence_penalty', 'max_tokens', 'seed')},
                       'native_class': 'SamplingParams'})
            self.write(root / 'native_render_parity.json', {'passed': True,
                       'template_sha256': self.contract['chat_template_sha256'],
                       'eos_token_id': 248044 if key == 'base' else 248046})
            requests = [self.request(c, key) for c in cases]
            outputs = [self.output(r, expected[r['case_id']]) for r in requests]
            self.write(root / 'parallel_requests.json', requests)
            self.write(root / 'parallel_outputs.json', outputs)
            long_request = self.request(self.fixtures.long_fixture(), key, 40001)
            long_output = [self.output(long_request, '5')]
            self.write(root / 'long_request.json', long_request)
            self.write(root / 'long_output.json', long_output)
            self.done[key] = {'passed': True, 'model_key': key, 'model': model, 'revision': revision,
                             'shared_contract_sha256': self.contract_sha, 'synthetic_only': True,
                             'parallel_cases': 16, 'concurrency': 16, 'reserved_output_tokens': 16384,
                             'context_limit': 65536, 'long_prompt_tokens': 40001,
                             'parallel_gate': self.common.validate_neutral_outputs(outputs, expected),
                             'long_gate': self.common.validate_neutral_outputs(long_output, {'long_context': '5'})}
            self.receipt['models'][key] = {'passed': True, 'completion': str(root / 'completion.json'),
                                          'model': model, 'revision': revision, 'long_prompt_tokens': 40001}
            self.reseal(key)
        self.write(self.gate / 'receipt.json', self.receipt)

    def request(self, case, key, tokens=2):
        prompt = case['messages'][0]['content']
        ids = [1] * tokens
        body = {'model': self.contract['models'][key]['name'], 'prompt': prompt,
                **self.contract['generation']}
        return {**case, 'model_key': key, 'prompt': prompt, 'prompt_token_ids': ids,
                'prompt_tokens': tokens, 'body': body, 'request_sha256': self.common.digest(body),
                'messages_sha256': self.common.digest(case['messages']),
                'prompt_token_ids_sha256': self.common.digest(ids)}

    def output(self, request, expected):
        return self.common.normalize_output(request, 'artificial reasoning</think>' + expected,
                                            [1, 2, 3], 'stop', self.contract)

    def reseal(self, key):
        root = self.gate / key
        self.done[key]['artifact_pins'] = {name: proof.sha(root / name) for name in proof.REQUIRED_ARTIFACTS}
        self.receipt['models'][key]['completion_sha256'] = self.write(root / 'completion.json', self.done[key])
        self.write(self.gate / 'receipt.json', self.receipt)

    def mutate(self, filename, function, seal=True):
        path = self.gate / filename
        value = json.loads(path.read_text())
        function(value)
        self.write(path, value)
        key = filename.split('/')[0]
        if seal and key in proof.MODELS and not filename.endswith('/completion.json'):
            self.reseal(key)

    def verify(self):
        return proof.verify_neutral_proof(self.contract_sha)

    def test_full_both_model_proof_passes_without_external_entrypoints(self):
        with mock.patch('subprocess.run', side_effect=AssertionError('No subprocess allowed')):
            result = self.verify()
        self.assertTrue(result['passed'])
        self.assertEqual(set(result['models']), {'base', 'posttrained'})
        self.assertEqual(result['models']['posttrained']['artifact_count'], 9)

    def test_missing_receipt_is_unknown_and_rejected(self):
        (self.gate / 'receipt.json').unlink()
        with self.assertRaises(FileNotFoundError): self.verify()

    def test_substitute_receipt_location_is_rejected(self):
        with self.assertRaises(ValueError): proof.verify_neutral_proof(self.contract_sha, self.gate / 'other.json')

    def test_symlink_artifact_is_rejected_even_with_same_bytes(self):
        path = self.gate / 'base/runtime.json'
        saved = path.with_name('runtime.saved.json'); path.rename(saved); path.symlink_to(saved)
        with self.assertRaises(ValueError): self.verify()

    def test_changed_pinned_source_is_rejected(self):
        with (self.root / 'shared_runtime.py').open('a') as handle: handle.write('\n')
        with self.assertRaises(ValueError): self.verify()

    def test_receipt_replaced_after_parsing_is_rejected(self):
        original = proof.verify_audit
        changed = False
        def replace_after_read(value, job):
            nonlocal changed
            original(value, job)
            if not changed:
                changed = True
                self.receipt['passed'] = False
                self.write(self.gate / 'receipt.json', self.receipt)
        with mock.patch.object(proof, 'verify_audit', side_effect=replace_after_read):
            with self.assertRaises(ValueError): self.verify()

    def test_missing_artifact_even_with_top_passed_is_rejected(self):
        self.done['base']['artifact_pins'].pop('effective_native_sampling.json')
        self.receipt['models']['base']['completion_sha256'] = self.write(self.gate / 'base/completion.json', self.done['base'])
        self.write(self.gate / 'receipt.json', self.receipt)
        with self.assertRaises(ValueError): self.verify()

    def test_changed_bytes_without_reseal_are_rejected(self):
        self.mutate('base/runtime.json', lambda d: d.update(GPU_name='changed'), seal=False)
        with self.assertRaises(ValueError): self.verify()

    def test_wrong_final_even_with_resealed_top_pass_is_rejected(self):
        self.mutate('base/parallel_outputs.json', lambda d: d[0].update(final='0', final_text='0'))
        with self.assertRaises(ValueError): self.verify()

    def test_raw_final_extraction_mismatch_is_rejected(self):
        self.mutate('base/parallel_outputs.json', lambda d: d[0].update(raw_text='unfinished reasoning'))
        with self.assertRaises(ValueError): self.verify()

    def test_truncation_with_correct_partial_answer_is_rejected(self):
        self.mutate('base/parallel_outputs.json', lambda d: d[0].update(finish_reason='length'))
        with self.assertRaises(ValueError): self.verify()

    def test_wrong_completion_summary_is_rejected(self):
        self.done['posttrained']['parallel_gate']['passed'] = False
        self.reseal('posttrained')
        with self.assertRaises(ValueError): self.verify()


def add_mutation_test(name, filename, function):
    def test(self):
        self.mutate(filename, function)
        with self.assertRaises((ValueError, KeyError, TypeError)):
            self.verify()
    setattr(ProofTests, 'test_reject_' + name, test)


for name, filename, mutation in [
    ('wrong_job', 'started.json', lambda d: d.update(job_id='100')),
    ('wrong_grant', 'submission.json', lambda d: d.update(grant_sha256='wrong')),
    ('wrong_submission_argv', 'submission_attempt.json', lambda d: d['command'].append('--retry')),
    ('receipt_one_model', 'receipt.json', lambda d: d['models'].pop('posttrained')),
    ('receipt_wrong_recipe', 'receipt.json', lambda d: d.update(shared_contract_sha256='wrong')),
    ('receipt_biological_calls', 'receipt.json', lambda d: d.update(biological_calls=1)),
    ('unpassed_receipt', 'receipt.json', lambda d: d.update(passed=False)),
    ('phase_other_model', 'base/phase_claim.json', lambda d: d.update(model_key='posttrained')),
    ('phase_retry', 'base/phase_claim.json', lambda d: d.update(no_retry=False)),
    ('runtime_precision', 'base/runtime.json', lambda d: d.update(dtype='float16')),
    ('runtime_GPU_count', 'base/runtime.json', lambda d: d.update(GPU_count=2)),
    ('runtime_version', 'base/runtime.json', lambda d: d['packages'].update(vllm='0.30')),
    ('native_temperature', 'base/effective_native_sampling.json', lambda d: d['values'].update(temperature=0.2)),
    ('native_class', 'base/effective_native_sampling.json', lambda d: d.update(native_class='FakeParams')),
    ('template', 'base/native_render_parity.json', lambda d: d.update(template_sha256='wrong')),
    ('native_eos', 'posttrained/native_render_parity.json', lambda d: d.update(eos_token_id=248044)),
    ('one_parallel_missing', 'base/parallel_requests.json', lambda d: d.pop()),
    ('request_order', 'base/parallel_requests.json', lambda d: d.reverse()),
    ('source_message', 'base/parallel_requests.json', lambda d: d[0]['messages'][0].update(content='changed')),
    ('request_sampling', 'base/parallel_requests.json', lambda d: d[0]['body'].update(temperature=0.2)),
    ('request_token_ids', 'base/parallel_requests.json', lambda d: d[0]['prompt_token_ids'].append(5)),
    ('wrong_output_association', 'base/parallel_outputs.json', lambda d: d[0].update(request_sha256='wrong')),
    ('empty_actual_tokens', 'base/parallel_outputs.json', lambda d: d[0].update(token_ids=[])),
    ('transport_error', 'base/parallel_outputs.json', lambda d: d[0].update(transport_error=True)),
    ('refusal', 'base/parallel_outputs.json', lambda d: d[0].update(refusal=True)),
    ('long_too_short', 'base/long_request.json', lambda d: d.update(prompt_tokens=30)),
    ('GPU_audit_ceiling', 'base/private_gpu_audit.json', lambda d: d.update(project_requested_GPUs=9)),
    ('GPU_audit_wrong_job', 'base/private_gpu_audit.json', lambda d: d.update(own_job_id='100')),
    ('GPU_audit_wrong_worker', 'base/private_gpu_audit.json', lambda d: d['jobs'][0].update(command='/unrelated')),
]:
    add_mutation_test(name, filename, mutation)


if __name__ == '__main__':
    unittest.main()
