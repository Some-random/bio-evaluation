"""Fixed artificial sequence/classification/scalar/QA delivery fixtures."""
import random


def fixtures():
    rng = random.Random(725184)
    cases, expected = [], {}
    for i, length in enumerate((128, 512, 2048, 8192)):
        sequence = ''.join(rng.choice('ABCDEFGHIJKLMNPQRSTUVWXYZ') for _ in range(length))
        prefix = 'Q' if i % 2 == 0 else 'B'
        sequence = prefix + sequence[1:]
        case_id = f'artificial_sequence_class_{i}'
        prompt = ('This is a synthetic delivery test, not a biological prediction.\n'
                  'Classify the artificial character string using this complete rule: '
                  'if its first character is Q, the class is 7; otherwise the class is 3. '
                  'Return only that single class integer.\nArtificial string:\n' + sequence)
        cases.append({'task_id': 'synthetic_neutral', 'case_id': case_id,
                      'messages': [{'role': 'user', 'content': prompt}]})
        expected[case_id] = '7' if prefix == 'Q' else '3'
    for i in range(4):
        sequence = ''.join(rng.choice('ABCD') for _ in range(256 * (i + 1)))
        case_id = f'artificial_sequence_scalar_{i}'
        score = (i + 1) * 2
        prompt = (f'This is a synthetic delivery test. The artificial string below has a '
                  f'supplied metadata value x={i+1}. Its synthetic score is 2*x; the '
                  'string is irrelevant to this explicit rule. Return only the integer score.\n'
                  'Artificial string:\n' + sequence)
        cases.append({'task_id': 'synthetic_neutral', 'case_id': case_id,
                      'messages': [{'role': 'user', 'content': prompt}]})
        expected[case_id] = str(score)
    for i in range(4):
        case_id = f'artificial_multiple_choice_{i}'
        prompt = (f'This fictional supplied-data question requires no external lookup. '
                  f'A fictional table reports item X={i+2} and item Y={i+5}. '
                  'What is Y-X?\nA. 1\nB. 2\nC. 3\nD. 4\n'
                  'Return only the choice letter.')
        cases.append({'task_id': 'synthetic_neutral', 'case_id': case_id,
                      'messages': [{'role': 'user', 'content': prompt}]})
        expected[case_id] = 'C'
    for i in range(4):
        case_id = f'artificial_grounded_text_qa_{i}'
        prompt = (f'Use only this fictional supplied source. Title: Synthetic Delivery {i}. '
                  f'Identifier: SYNTHETIC-{i}. The source states that the container holds '
                  f'{i+4} blue counters and {i+1} red counters. '
                  'Question: how many more blue counters than red counters are there? '
                  'Return only the integer.')
        cases.append({'task_id': 'synthetic_neutral', 'case_id': case_id,
                      'messages': [{'role': 'user', 'content': prompt}]})
        expected[case_id] = '3'
    return cases, expected


def long_fixture():
    return {'task_id': 'synthetic_neutral', 'case_id': 'long_context', 'messages': [
        {'role': 'user', 'content': 'This repeated word is artificial irrelevant padding.\n'
         + ' neutral' * 45000
         + '\nEnd of padding. What is 2 + 3? Return only the integer.'}]}
