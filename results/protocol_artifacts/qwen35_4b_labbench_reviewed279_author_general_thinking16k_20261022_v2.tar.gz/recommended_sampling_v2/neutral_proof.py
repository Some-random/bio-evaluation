"""Pure verification of the exact actual two-model artificial delivery gate.

No scheduler, tokenizer, checkpoint, network or model entrypoint is called.
Receipt bytes are observed at verification time, never predicted from preparation.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import stat

HERE = Path(__file__).resolve().parent
GATE = HERE / 'neutral_validation'
CONTRACT_SHA = '00f42f82e48d9dbb4cebcf8c2a5c8631c45092e80a94a12af9b0b58cf451a83d'
PLAN_SHA = 'e106b7b8ca3529f6b748dabec79a7271b4e1a6d6ac75d633d782890ac31bc4ad'
GRANT_SHA = '681dfa649d2e8ba14226d0cd381d6c9875a1c65adb2d9b252ec9b95b1e94b79d'
REVIEW_SHA = '853b32e157860b7b1c47eb737669ef4a2c538334168104f6134d3cbacd4b5288'
DECISION_SHA = 'a988b8972658cb27d4c0b0d9557da32ddf17d22e134cf4c1b69702f50af5a65f'
MODELS = {
    'base': ('Qwen/Qwen3.5-4B-Base', '1001bb4d826a52d1f399e183466143f4da7b741b'),
    'posttrained': ('Qwen/Qwen3.5-4B', '851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a'),
}
REQUIRED_ARTIFACTS = {
    'private_gpu_audit.json', 'phase_claim.json', 'runtime.json',
    'effective_native_sampling.json', 'native_render_parity.json',
    'parallel_requests.json', 'parallel_outputs.json', 'long_request.json',
    'long_output.json',
}


def regular_bytes(name):
    path = Path(name)
    if not path.is_absolute() or path != path.resolve():
        raise ValueError('Exact absolute nonsymlink neutral artifact required')
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError('Regular neutral artifact required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as handle:
        opened = os.fstat(handle.fileno())
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
            raise ValueError('Neutral artifact changed during opening')
        raw = handle.read()
        after = os.fstat(handle.fileno())
    current = path.lstat()
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    if identity(before) != identity(after) or identity(after) != identity(current):
        raise ValueError('Neutral artifact changed during reading')
    return raw


def sha(path):
    return hashlib.sha256(regular_bytes(path)).hexdigest()


def read(path):
    return json.loads(regular_bytes(path))


def pinned(path, expected):
    raw = regular_bytes(path)
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError('Pinned neutral prerequisite changed: ' + str(path))
    return json.loads(raw) if str(path).endswith('.json') else raw


def module(path, name):
    regular_bytes(path)
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def require(value, message):
    if not value:
        raise ValueError(message)


def verify_audit(value, job_id):
    require(value.get('own_job_id') == job_id and value.get('project_GPU_ceiling') == 8
            and value.get('additional_GPUs_reviewed') == 0
            and value.get('model_calls') == 0 and value.get('unrelated_jobs_changed') is False,
            'Actual own neutral GPU audit missing')
    rows = value.get('jobs', [])
    require(all(type(r.get('gpus')) is int and r['gpus'] > 0
                and type(r.get('counted_toward_evaluation_project')) is bool for r in rows),
            'Malformed actual GPU inventory')
    project = sum(r['gpus'] for r in rows if r['counted_toward_evaluation_project'])
    require(1 <= project <= 8 and value.get('project_requested_GPUs') == project
            and value.get('project_requested_GPUs_with_addition') == project,
            'Actual neutral GPU audit exceeds or misstates project ceiling')
    own = [r for r in rows if r.get('job_id') == job_id]
    require(len(own) == 1 and own[0]['gpus'] == 1
            and own[0]['counted_toward_evaluation_project']
            and own[0].get('state') in {'RUNNING', 'COMPLETING'}
            and own[0].get('command') == str(GATE / 'worker.sbatch')
            and own[0].get('workdir') == str(HERE.parents[2]),
            'Actual neutral allocation belongs to another worker')


def verify_request(row, case, key, contract, common):
    require(isinstance(row, dict), 'Prepared neutral request required')
    ids = row.get('prompt_token_ids')
    require(isinstance(ids, list) and bool(ids) and all(type(t) is int for t in ids),
            'Actual neutral prompt token IDs required')
    require(row.get('task_id') == 'synthetic_neutral' and row.get('case_id') == case['case_id']
            and row.get('model_key') == key and row.get('messages') == case['messages']
            and row.get('messages_sha256') == common.digest(case['messages'])
            and row.get('prompt_token_ids_sha256') == common.digest(ids)
            and row.get('prompt_tokens') == len(ids)
            and isinstance(row.get('prompt'), str) and bool(row['prompt'])
            and row.get('body') == {'model': contract['models'][key]['name'],
                                   'prompt': row['prompt'], **contract['generation']}
            and row.get('request_sha256') == common.digest(row['body'])
            and len(ids) + contract['generation']['max_tokens'] <= contract['context_limit'],
            'Neutral native inputs, recipe, tokenization or request identity differ')


def verify_output(row, request, expected, key, contract, common):
    require(isinstance(row, dict) and row.get('task_id') == 'synthetic_neutral'
            and row.get('case_id') == request['case_id'] and row.get('model_key') == key
            and row.get('request_sha256') == request['request_sha256']
            and row.get('finish_reason') == 'stop' and row.get('terminal') is True
            and row.get('transport_error') is False and row.get('http_error') is False
            and row.get('not_dispatched') is False and row.get('refusal', False) is False
            and isinstance(row.get('token_ids'), list) and bool(row['token_ids']),
            'Actual neutral response identity, delivery or stopping differs')
    normalized = common.normalize_output(request, row.get('raw_text'), row['token_ids'],
                                         row['finish_reason'], contract, row.get('usage'))
    require(all(row.get(k) == normalized[k] for k in normalized),
            'Neutral final extraction or raw response association changed')
    require(row.get('final') == str(expected) and row.get('final_text') == str(expected)
            and row.get('response_error') is False and row.get('truncated') is False
            and row.get('status') == 'completed' and row.get('extra_assistant_tail') is False
            and row.get('missing_think_close') is False,
            'Actual neutral final did not pass exact artificial expectation')


def verify_neutral_proof(expected_contract_sha256, receipt_path=None):
    """Validate exact immutable sources and every actual both-model gate artifact."""
    # Every parsed artifact is bound to the bytes actually read. Re-reading a
    # path must match that snapshot; verify the whole snapshot again at return.
    observed = {}

    def capture(path):
        path = Path(path)
        raw = regular_bytes(path)
        digest = hashlib.sha256(raw).hexdigest()
        require(path not in observed or observed[path] == digest,
                'Neutral artifact changed during proof verification')
        observed[path] = digest
        return raw

    def read(path):
        return json.loads(capture(path))

    def sha(path):
        return hashlib.sha256(capture(path)).hexdigest()

    def pinned(path, expected):
        raw = capture(path)
        require(hashlib.sha256(raw).hexdigest() == expected,
                'Pinned neutral prerequisite changed: ' + str(path))
        return json.loads(raw) if str(path).endswith('.json') else raw

    require(expected_contract_sha256 == CONTRACT_SHA, 'Different neutral contract requested')
    receipt_path = GATE / 'receipt.json' if receipt_path is None else Path(receipt_path)
    require(receipt_path == GATE / 'receipt.json', 'Substitute neutral receipt forbidden')
    contract = pinned(HERE / 'shared_contract.json', CONTRACT_SHA)
    plan = pinned(GATE / 'plan.json', PLAN_SHA)
    grant = pinned(HERE / 'neutral_grant.json', GRANT_SHA)
    review = pinned(HERE / 'independent_review.json', REVIEW_SHA)
    decision = pinned(HERE.parent / 'root_recommended_sampling_repair_decision_20261022.json', DECISION_SHA)
    require(decision.get('issuer') == '/root'
            and grant.get('issuer') in decision['engineering_delegation']['review_grant_issuers']
            and grant.get('issuer') != plan['owner'] and grant.get('approved') is True
            and grant.get('plan_sha256') == PLAN_SHA and grant.get('neutral_only') is True
            and grant.get('biological_dispatch_authorized') is False
            and grant.get('independent_review_path') == str(HERE / 'independent_review.json')
            and grant.get('independent_review_sha256') == REVIEW_SHA
            and review.get('reviewer') == grant['issuer'] and review.get('passed') is True
            and review.get('plan_sha256') == PLAN_SHA,
            'Independent exact neutral admission required')
    require(plan.get('shared_contract') == str(HERE / 'shared_contract.json')
            and plan.get('shared_contract_sha256') == CONTRACT_SHA
            and plan.get('biological_calls') == 0 and plan.get('max_generations') == 34
            and plan.get('model_order') == ['base', 'posttrained']
            and contract.get('neutral_gate_receipt') == str(receipt_path),
            'Wrong neutral scope or shared recipe')
    for path, digest in {**plan['pins'], **contract['source_pins']}.items():
        pinned(path, digest)
    common = module(HERE / 'shared_runtime.py', 'recommended_sampling_verified_common')
    fixture = module(GATE / 'fixtures.py', 'recommended_sampling_verified_fixtures')
    cases, expected = fixture.fixtures()
    require(len(cases) == 16 and len(expected) == 16, 'Exact fixed artificial cohort required')
    long_case = fixture.long_fixture()
    receipt = read(receipt_path)
    submission = read(GATE / 'submission.json')
    started = read(GATE / 'started.json')
    job_id = receipt.get('job_id')
    require(isinstance(job_id, str) and job_id.isdigit()
            and submission.get('job_id') == job_id and started.get('job_id') == job_id
            and submission.get('plan_sha256') == PLAN_SHA and started.get('plan_sha256') == PLAN_SHA
            and submission.get('grant_sha256') == GRANT_SHA,
            'Actual neutral submission/start/job proof differs')
    attempt = read(GATE / 'submission_attempt.json')
    require(attempt.get('plan_sha256') == PLAN_SHA and attempt.get('command') == [
        'sbatch', '--parsable', str(GATE / 'worker.sbatch'), '--plan', str(GATE / 'plan.json'),
        '--plan-sha256', PLAN_SHA, '--grant', str(HERE / 'neutral_grant.json'),
        '--grant-sha256', GRANT_SHA], 'Actual neutral submission claim differs')
    require(receipt.get('passed') is True and receipt.get('shared_contract_sha256') == CONTRACT_SHA
            and receipt.get('plan_sha256') == PLAN_SHA and receipt.get('synthetic_only') is True
            and receipt.get('biological_calls') == 0
            and receipt.get('no_biological_scope_admission') is True
            and set(receipt.get('models', {})) == set(MODELS),
            'Actual both-model neutral receipt incomplete or substituted')
    verify_audit(read(GATE / 'private_gpu_audit_start.json'), job_id)
    verified = {}
    for key, (model, revision) in MODELS.items():
        require((contract['models'][key]['name'], contract['models'][key]['revision']) == (model, revision),
                'Neutral contract model identity differs')
        root = GATE / key
        done_path = root / 'completion.json'
        done = read(done_path)
        summary = receipt['models'][key]
        require(summary.get('passed') is True and summary.get('completion') == str(done_path)
                and summary.get('completion_sha256') == sha(done_path)
                and (summary.get('model'), summary.get('revision')) == (model, revision),
                'Neutral completion hash or model identity differs')
        require(done.get('passed') is True and done.get('model_key') == key
                and (done.get('model'), done.get('revision')) == (model, revision)
                and done.get('shared_contract_sha256') == CONTRACT_SHA
                and done.get('synthetic_only') is True and done.get('parallel_cases') == 16
                and done.get('concurrency') == 16 and done.get('reserved_output_tokens') == 16384
                and done.get('context_limit') == 65536,
                'Exact actual neutral model completion required')
        pins = done.get('artifact_pins', {})
        require(set(pins) == REQUIRED_ARTIFACTS, 'Exact actual neutral artifact set required')
        for name, digest in pins.items():
            pinned(root / name, digest)
        phase = read(root / 'phase_claim.json')
        require(phase == {'model_key': key, 'job_id': job_id, 'no_retry': True},
                'Neutral phase belongs to another job/model or allows retry')
        verify_audit(read(root / 'private_gpu_audit.json'), job_id)
        runtime = read(root / 'runtime.json')
        require(runtime.get('model_key') == key and runtime.get('GPU_count') == 1
                and runtime.get('dtype') == 'bfloat16'
                and all((runtime.get('packages', {}).get(n) or '').split('+')[0] == v
                        for n, v in contract['runtime_expected'].items()),
                'Actual neutral runtime versions, precision or GPU count differ')
        effective = read(root / 'effective_native_sampling.json')
        require(effective == {'values': {n: contract['generation'][n] for n in
                         ('temperature', 'top_p', 'top_k', 'presence_penalty', 'max_tokens', 'seed')},
                              'native_class': 'SamplingParams'},
                'Actual native sampling settings differ')
        parity = read(root / 'native_render_parity.json')
        require(parity.get('passed') is True
                and parity.get('template_sha256') == contract['chat_template_sha256']
                and parity.get('eos_token_id') == (248044 if key == 'base' else 248046),
                'Actual native template/parity identity differs')
        requests = read(root / 'parallel_requests.json')
        outputs = read(root / 'parallel_outputs.json')
        require(isinstance(requests, list) and isinstance(outputs, list)
                and len(requests) == len(outputs) == 16, 'Exact actual sixteen parallel cases required')
        for request, output, case in zip(requests, outputs, cases):
            verify_request(request, case, key, contract, common)
            verify_output(output, request, expected[case['case_id']], key, contract, common)
        long_request = read(root / 'long_request.json')
        long_output = read(root / 'long_output.json')
        verify_request(long_request, long_case, key, contract, common)
        require(long_request['prompt_tokens'] >= 40000
                and done.get('long_prompt_tokens') == long_request['prompt_tokens']
                and summary.get('long_prompt_tokens') == long_request['prompt_tokens']
                and isinstance(long_output, list) and len(long_output) == 1,
                'Exact actual long-context reservation proof required')
        verify_output(long_output[0], long_request, '5', key, contract, common)
        require(done.get('parallel_gate') == common.validate_neutral_outputs(outputs, expected)
                and done.get('long_gate') == common.validate_neutral_outputs(long_output, {'long_context': '5'}),
                'Neutral gate summaries differ from actual outputs')
        verified[key] = {'completion': str(done_path), 'completion_sha256': sha(done_path),
                         'model': model, 'revision': revision, 'artifact_count': len(pins)}
    for path, digest in list(observed.items()):
        require(hashlib.sha256(regular_bytes(path)).hexdigest() == digest,
                'Neutral evidence changed before proof verification completed')
    return {'passed': True, 'receipt_path': str(receipt_path), 'receipt_sha256': observed[receipt_path],
            'job_id': job_id, 'plan_sha256': PLAN_SHA, 'shared_contract_sha256': CONTRACT_SHA,
            'neutral_grant_sha256': GRANT_SHA, 'models': verified,
            'synthetic_only': True, 'biological_dispatch_admitted_by_proof': False}
