"""One attempt per reviewed LAB-Bench case; never opens scorer references."""
from collections import Counter
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
import re

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stamp():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def write(path, value, once=False):
    path = Path(path)
    if once:
        with path.open('x') as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write('\n')
            handle.flush()
            os.fsync(handle.fileno())
        directory_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    else:
        tmp = path.with_suffix(path.suffix + '.tmp')
        tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
        tmp.replace(path)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def summarize(outputs, planned, attempted):
    """Saved raw outcomes count even when their final-answer format is invalid."""
    saved = sum(r.get('raw_response_saved', False) for r in outputs)
    return {'at_pacific': stamp(), 'role': 'direct_unsealed_progress_lower_bound',
            'planned': planned, 'request_claims': attempted,
            'attempted_confirmed': saved,
            'attempted_confirmed_basis': 'actual saved raw model responses only',
            'ambiguous_without_raw_response': attempted - saved,
            'responses_saved': saved,
            'terminal': len(outputs), 'in_flight_or_unresolved': attempted - len(outputs),
            'not_dispatched': planned - attempted,
            'empty_finals': sum(not (r.get('final_text') or '').strip() for r in outputs),
            'truncations': sum(r.get('finish_reason') == 'length' for r in outputs),
            'transport_errors': sum(bool(r.get('transport_error')) for r in outputs),
            'http_errors': sum(bool(r.get('http_error')) for r in outputs),
            'response_errors': sum(bool(r.get('response_error')) for r in outputs),
            'runtime_exceptions': sum(r.get('status') == 'generation_exception' for r in outputs),
            'refusals': sum(bool(r.get('refusal')) for r in outputs),
            'finish_reasons': dict(Counter(r.get('finish_reason') for r in outputs)),
            'biological_correctness_assessed': False,
            'native_scoring_status': 'not_started',
            'endpoint': 'in_process_vllm_no_http_endpoint'}


def stop_reason(output):
    if output.get('status') == 'generation_exception':
        return 'generation_exception'
    if output.get('refusal'):
        return 'explicit_refusal'
    if '<tool_call>' in output.get('raw_text', ''):
        return 'undeclared_tool_call'
    if output.get('extra_assistant_tail') or '<|im_start|>' in output.get('raw_text', ''):
        return 'extra_generated_role'
    # Unfinished reasoning and ordinary invalid/empty/truncated final answers are
    # model outcomes, retained without changing prompts, budgets, or case scope.
    return None


def classify_refusal(final, explicit=False):
    """Distinguish an actual refusal from native lack-of-information abstention."""
    inability = bool(re.search(
        r"\b(?:I cannot|I can't|I'm unable to) (?:assist|help|provide|answer)\b",
        final, re.I))
    direct_decline = bool(re.search(
        r"\b(?:I cannot|I can't|I'm unable to) (?:assist|help)(?: you)? with (?:this|that|your) request\b",
        final, re.I))
    safety_reason = bool(re.search(
        r'\b(?:unsafe|harmful|prohibited|biosafety|biosecurity|biological risk|safety policy)\b',
        final, re.I))
    return {'refusal': bool(explicit) or direct_decline or (inability and safety_reason),
            'possible_inability_text': inability}


def run_model(session, plan, plan_path, model_key):
    condition = plan['models'][model_key]
    source = Path(plan['inputs']['path'])
    if sha(source) != plan['inputs']['sha256']:
        raise ValueError('Complete input packet changed')
    inputs = [json.loads(line) for line in source.read_text().splitlines()]
    if len(inputs) != 279 or Counter(r['task_id'] for r in inputs) != {'B01': 197, 'B03': 82}:
        raise ValueError('Exact reviewed cohort changed')
    run = Path(condition['runtime'])
    run.mkdir(parents=True, exist_ok=True)
    with (run / 'run.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if (run / 'started.json').exists() or (run / 'cases').exists():
            raise ValueError('Namespace already attempted; no automatic re-execution')
        # Preflight every complete native input before creating any benchmark request.
        prepared_all = [session.prepare(row) for row in inputs]
        write(run / 'tokenizer_preflight.json', {
            'at_pacific': stamp(), 'all_fit': True, 'case_count': len(inputs),
            'prompt_token_min': min(r['prompt_tokens'] for r in prepared_all),
            'prompt_token_max': max(r['prompt_tokens'] for r in prepared_all),
            'context_limit': plan['context_limit'],
            'output_budget': plan['generation']['max_tokens'],
            'all_messages_sha256': [r['messages_sha256'] for r in prepared_all],
            'inputs_not_truncated': True, 'references_opened': False}, once=True)
        (run / 'cases').mkdir()
        identity = {'model': condition['name'], 'model_revision': condition['revision'],
                    'model_key': model_key, 'run_id': condition['run_id'],
                    'plan_sha256': sha(plan_path), 'job_id': os.environ['SLURM_JOB_ID']}
        write(run / 'started.json', {**identity, 'at_pacific': stamp(),
                                    'planned': len(inputs)}, once=True)
        outputs, attempted = [], 0
        write(run / 'progress.json', {**identity, **summarize(outputs, len(inputs), attempted)})
        for start in range(0, len(inputs), plan['batch_size']):
            batch = inputs[start:start + plan['batch_size']]
            prepared = prepared_all[start:start + plan['batch_size']]
            request_paths = []
            for offset, (case, item) in enumerate(zip(batch, prepared)):
                folder = run / 'cases' / f'{start + offset:06d}'
                folder.mkdir()
                path = folder / 'request.json'
                write(path, {**identity, 'task_id': case['task_id'],
                             'case_id': case['case_id'], 'messages': case['messages'],
                             'prepared': item, 'at_pacific': stamp()}, once=True)
                request_paths.append(path)
            attempted += len(batch)
            write(run / 'progress.json', {**identity, **summarize(outputs, len(inputs), attempted)})
            try:
                results = session.generate_prepared(prepared)
                if len(results) != len(batch):
                    raise ValueError('Common session returned wrong output count')
            except Exception as error:
                results = [{
                    'case_id': c['case_id'], 'task_id': c['task_id'],
                    'status': 'generation_exception', 'final_text': '', 'final': '',
                    'raw_text': '', 'token_ids': [], 'finish_reason': None,
                    'terminal': True, 'response_error': True,
                    'raw_response_saved': False, 'error_type': type(error).__name__,
                    'error': str(error)[:2000]} for c in batch]
            reasons = []
            for case, item, result, request_path in zip(batch, prepared, results, request_paths):
                if (result.get('case_id'), result.get('task_id')) != (case['case_id'], case['task_id']):
                    raise ValueError('Common session returned wrong case identity')
                if result.get('status') != 'generation_exception' and result.get('request_sha256') != item['request_sha256']:
                    raise ValueError('Response belongs to different prepared request')
                result['raw_response_saved'] = result.get('status') != 'generation_exception'
                result.update(classify_refusal(result.get('final_text', ''),
                                               result.get('refusal', False)))
                output = {**result, **identity, 'task_id': case['task_id'],
                          'prepared_request_sha256': result.get('request_sha256'),
                          'request_sha256': sha(request_path), 'at_pacific': stamp()}
                write(request_path.parent / 'response.json', output, once=True)
                outputs.append(output)
                reason = stop_reason(output)
                if reason:
                    reasons.append(reason)
            write(run / 'progress.json', {**identity, **summarize(outputs, len(inputs), attempted)})
            if reasons:
                write(run / 'stopped.json', {**identity, 'at_pacific': stamp(),
                        'reasons': sorted(set(reasons)), 'observed_terminal': len(outputs),
                        'attempts_preserved_no_retries': True}, once=True)
                raise RuntimeError('Delivery stop; preserve all attempted cases')
        rows = []
        for index, case in enumerate(inputs):
            folder = run / 'cases' / f'{index:06d}'
            rows.append({'task_id': case['task_id'], 'case_id': case['case_id'],
                         'request_path': str((folder / 'request.json').relative_to(run)),
                         'request_sha256': sha(folder / 'request.json'),
                         'response_path': str((folder / 'response.json').relative_to(run)),
                         'response_sha256': sha(folder / 'response.json')})
        write(run / 'prediction_lock.json', {**identity, 'at_pacific': stamp(),
                    'planned': len(inputs), 'rows': rows,
                    'all_planned_terminal': True, 'scoring_performed': False,
                    'references_not_opened': True}, once=True)
        completion = {**identity, **summarize(outputs, len(inputs), attempted),
                      'role': 'sealed_complete_reviewed_cohort_delivery',
                      'all_planned_terminal': True,
                      'prediction_lock_sha256': sha(run / 'prediction_lock.json')}
        write(run / 'completion.json', completion, once=True)
        return completion


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--model-key', choices=['base', 'posttrained'], required=True)
    args = parser.parse_args()
    if sha(args.plan) != args.plan_sha256:
        raise ValueError('Plan changed')
    plan = json.loads(args.plan.read_text())
    for path, expected in plan['pins'].items():
        if sha(path) != expected:
            raise ValueError('Plan pin changed')
    common = load(plan['shared_runtime']['path'], 'labbench_shared_qwen35_runtime')
    contract = common.load_contract(plan['shared_contract']['path'], plan['shared_contract']['sha256'])
    session = common.create_session(args.model_key, contract, max_num_seqs=plan['batch_size'])
    run_model(session, plan, args.plan, args.model_key)
    write(Path(plan['models'][args.model_key]['runtime']) / 'model_completed.json', {
        'at_pacific': stamp(), 'model_key': args.model_key,
        'plan_sha256': args.plan_sha256, 'all279_predictions_sealed': True,
        'native_scoring': 'wait_for_both_model_prediction_seals'}, once=True)
    if all((Path(model['runtime']) / 'completion.json').is_file()
           for model in plan['models'].values()):
        scorer = load(HERE / 'score.py', 'labbench_once_only_postseal_scorer')
        scorer.score(args.plan, args.plan_sha256)


if __name__ == '__main__':
    main()
