"""One new full279-case model condition, admitted independently before startup."""
from pathlib import Path
import argparse
import fcntl
import json
import os
import subprocess
import tempfile

from guards import HERE, ROOT, audit, load, neutral, predecessor_guard, sha, validate


def write(path, value):
    with Path(path).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
    fd = os.open(Path(path).parent, os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def main():
    parser = argparse.ArgumentParser()
    for name in ['plan', 'grant']:
        parser.add_argument('--' + name, type=Path, required=True)
    for name in ['plan-sha256', 'grant-sha256']:
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--model-key', choices=['base', 'posttrained'], required=True)
    args = parser.parse_args()
    plan = validate(args.plan, args.plan_sha256, args.grant, args.grant_sha256, args.model_key)
    if not os.environ.get('SLURM_JOB_ID'):
        raise ValueError('Actual one-GPU Slurm allocation required')
    runtime = Path(plan['models'][args.model_key]['runtime'])
    runtime.mkdir(parents=True, exist_ok=True)
    with (runtime / 'worker.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # Verify the original jobs are terminal and exclusively check their
        # output locks before starting either new model condition.
        with (ROOT / '.local/evaluation_GPU_submission.lock').open('a') as global_lock:
            fcntl.flock(global_lock, fcntl.LOCK_EX)
            with predecessor_guard(plan) as previous:
                gate = neutral(plan)
                write(runtime / 'worker_started.json', {'job_id': os.environ['SLURM_JOB_ID'],
                       'model_key': args.model_key, 'plan_sha256': args.plan_sha256,
                       'grant_sha256': args.grant_sha256})
                write(runtime / 'predecessor_observation.json', previous)
                write(runtime / 'shared_neutral_gate_observation.json', gate)
                write(runtime / 'gpu_audit.json', audit(plan, own=True))
        # Release old locks before the other matched model starts, after fresh
        # terminal evidence and immutable source pins have been recorded.
        common = load(plan['shared_runtime']['path'], 'labbench_recommended_runtime')
        contract = common.load_contract(plan['shared_contract']['path'], plan['shared_contract']['sha256'])
        local = Path(tempfile.mkdtemp(prefix='qwen35-labbench-recipe-v2-' + os.environ['SLURM_JOB_ID'] + '-'))
        python, env, extraction = common.restore_runtime(local, contract)
        env['PYTHONPATH'] = str(HERE)
        write(runtime / 'runtime_environment.json', {'private_runtime': str(local),
              'archive_verification': extraction, 'credentials_removed': True,
              'no_model_tools_or_external_endpoint': True})
        with (runtime / 'generation.log').open('x') as log:
            result = subprocess.run([str(python), str(HERE / 'driver.py'), '--plan', str(args.plan),
                                     '--plan-sha256', args.plan_sha256, '--model-key', args.model_key],
                                    env=env, cwd=local, stdout=log, stderr=subprocess.STDOUT)
        write(runtime / 'worker_terminal.json', {'job_id': os.environ['SLURM_JOB_ID'],
              'returncode': result.returncode, 'model_key': args.model_key, 'plan_sha256': args.plan_sha256})
        if result.returncode:
            raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
