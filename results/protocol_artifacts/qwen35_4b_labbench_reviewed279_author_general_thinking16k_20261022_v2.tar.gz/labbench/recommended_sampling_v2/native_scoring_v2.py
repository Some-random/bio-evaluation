"""Frozen native LAB-Bench deterministic answer parser and all-case metrics.

This module has no inference, retrieval, or label access at import time. The
coordinator opens the pinned reference archives only after prediction closure.
The parser is the original deterministic ChemBench port, without LLM fallback.
"""
import re
from collections import Counter

NATIVE_PATTERN = r'(?:\[ANSWER\]|\[ANS\]|<ANS>|<ANSWER>|<ans>)\s*([A-Z](?:,\s*[A-Z])*)\s*(?:\..*?|,.*?)?(?:\[/?ANSWER\]|\[/ANS\]|</ANS>|</ANSWER>|</ans>)'


def native_answer(text, choice_count):
    if not isinstance(text, str) or not 1 <= choice_count <= 26:
        raise ValueError('Invalid final text or choice count')
    alphabet = [chr(i) for i in range(65, 91)]
    matches = sorted(set(re.findall(NATIVE_PATTERN, text, re.DOTALL)))
    if matches:
        prepared = str(matches)
    elif text in alphabet:
        prepared = text
    elif ',' in text:
        split = text.split(',')
        prepared = ','.join(split) if all(x.strip() in alphabet for x in split) else ''
    elif ' ' in text:
        split = text.split(' ')
        prepared = ','.join(split) if all(x.strip() in alphabet for x in split) else ''
    else:
        prepared = ''
    found = re.search('[' + ''.join(alphabet[:choice_count]) + ']', prepared)
    return found.group(0) if found else None


def native_metrics(rows):
    if not rows:
        raise ValueError('Empty evaluation cohort')
    correct = sum(r['correct'] for r in rows)
    sure = sum(r['sure'] for r in rows)
    return {'accuracy': correct / len(rows),
            'precision': correct / sure if sure else 0.0,
            'coverage': sure / len(rows), 'n_total': len(rows),
            'n_correct': correct, 'n_sure': sure}


def score_closed_rows(inputs, predictions, references):
    """Accept ordered, already hash-verified terminal predictions only.

    Predictions contain task_id/case_id/final_text, plus transport and runtime
    diagnostics. Invalid, absent-final, and failed rows keep the full denominator.
    This function does not reopen source files or interpret model reasoning.
    """
    keys = [(r['task_id'], r['case_id']) for r in inputs]
    if not keys or len(keys) != len(set(keys)):
        raise ValueError('Duplicate or empty input roster')
    if [(r['task_id'], r['case_id']) for r in predictions] != keys:
        raise ValueError('Incomplete, reordered, or substituted predictions')
    per_case = []
    for item, pred in zip(inputs, predictions):
        key = (item['task_id'], item['case_id'])
        ref = references[key]
        if pred.get('terminal') is not True:
            raise ValueError('Unsealed prediction')
        failed = bool(pred.get('transport_error') or pred.get('http_error')
                      or pred.get('response_error') or pred.get('not_dispatched')
                      or pred.get('refusal'))
        final = pred.get('final_text', '')
        if not isinstance(final, str):
            raise ValueError('Nontext final')
        answer = None if failed else native_answer(final, ref['choice_count'])
        per_case.append({'task_id': key[0], 'case_id': key[1],
                         'answer': answer, 'parsed': answer is not None,
                         'correct': answer == ref['target_choice'],
                         'sure': answer != ref['unsure_choice'],
                         'empty_final': not final.strip(),
                         'truncated': bool(pred.get('truncated')),
                         'transport_error': bool(pred.get('transport_error')),
                         'http_error': bool(pred.get('http_error')),
                         'response_error': bool(pred.get('response_error')),
                         'not_dispatched': bool(pred.get('not_dispatched')),
                         'refusal': bool(pred.get('refusal'))})
    summaries = {}
    for task in sorted({r['task_id'] for r in per_case}):
        rows = [r for r in per_case if r['task_id'] == task]
        diagnostics = {k: sum(r[k] for r in rows) for k in
                       ['parsed', 'empty_final', 'truncated', 'transport_error',
                        'http_error', 'response_error', 'not_dispatched', 'refusal']}
        diagnostics['invalid_outputs'] = len(rows) - diagnostics['parsed']
        summaries[task] = {'metrics': native_metrics(rows),
                           'diagnostics': diagnostics,
                           'explanation_correctness_assessed': False}
    return {'per_task': summaries, 'per_case': per_case,
            'all_case_denominators_preserved': True,
            'optional_llm_fallback_used': False}
