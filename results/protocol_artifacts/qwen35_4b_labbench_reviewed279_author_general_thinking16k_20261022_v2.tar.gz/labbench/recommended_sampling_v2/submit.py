"""Exactly one new model allocation after actual gate, terminal and locked audit."""
from pathlib import Path
import argparse
import fcntl
import json
import os
import subprocess

from guards import HERE, ROOT, audit, neutral, predecessor_guard, validate
from worker import write


def main():
    parser = argparse.ArgumentParser()
    for name in ['plan', 'grant']:
        parser.add_argument('--' + name, type=Path, required=True)
    for name in ['plan-sha256', 'grant-sha256']:
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--model-key', choices=['base', 'posttrained'], required=True)
    args = parser.parse_args()
    plan = validate(args.plan, args.plan_sha256, args.grant, args.grant_sha256, args.model_key)
    runtime = Path(plan['models'][args.model_key]['runtime'])
    runtime.mkdir(parents=True, exist_ok=True)
    with (ROOT / '.local/evaluation_GPU_submission.lock').open('a') as global_lock:
        fcntl.flock(global_lock, fcntl.LOCK_EX)
        claim, receipt_path = runtime / 'submission_claim.json', runtime / 'submission_receipt.json'
        if os.path.lexists(claim) or os.path.lexists(receipt_path):
            raise ValueError('Submission already attempted; no retry')
        with predecessor_guard(plan) as previous:
            gate = neutral(plan)
            try:
                observation = audit(plan, additional=1)
            except ValueError as error:
                if str(error) == 'Evaluation project GPU requests exceed eight':
                    print(json.dumps({'stage': 'capacity_only_wait', 'sbatch_invoked': False,
                          'submission_attempt_started': False, 'claim_exists': False, 'receipt_exists': False}))
                    raise SystemExit(75)
                raise
            write(claim, {'model_key': args.model_key, 'plan_sha256': args.plan_sha256,
                  'grant_sha256': args.grant_sha256, 'gpu_audit': observation,
                  'actual_both_model_neutral_proof': gate, 'predecessors': previous, 'no_retry_after_claim': True})
            command = ['sbatch', '--parsable', '--job-name=qwen35-labbench-recipe-v2-' + args.model_key,
                       str(HERE / 'worker.sbatch'), '--plan', str(args.plan), '--plan-sha256', args.plan_sha256,
                       '--grant', str(args.grant), '--grant-sha256', args.grant_sha256, '--model-key', args.model_key]
            try:
                result = subprocess.run(command, capture_output=True, text=True, timeout=45)
            except Exception as error:
                write(receipt_path, {'stage': 'submission_uncertain_no_retry', 'model_key': args.model_key,
                      'error_type': type(error).__name__, 'error': str(error), 'sbatch_invoked': True})
                raise
            job_id = result.stdout.strip().split(';')[0]
            valid = result.returncode == 0 and job_id.isdigit()
            receipt = {'stage': 'submitted_not_model_dispatch_evidence' if valid else 'submission_failed_or_uncertain_no_retry',
                       'job_id': job_id if valid else None, 'model_key': args.model_key, 'plan_sha256': args.plan_sha256,
                       'grant_sha256': args.grant_sha256, 'requested_gpu_count': 1, 'sbatch_invoked': True,
                       'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
                       'gpu_audit': observation, 'actual_both_model_neutral_proof': gate, 'predecessors': previous}
            write(receipt_path, receipt)
            print(json.dumps(receipt))
            if not valid:
                raise SystemExit(1)


if __name__ == '__main__':
    main()
