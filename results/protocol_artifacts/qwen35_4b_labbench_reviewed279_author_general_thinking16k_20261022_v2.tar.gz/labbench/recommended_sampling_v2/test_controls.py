"""Synthetic admission, lock and once-only dispatch controls; no real calls."""
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
import copy
import fcntl
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest

import guards
import submit
import worker


class AdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.repair_path = self.root / 'decision.json'
        self.repair_path.write_text(json.dumps({'engineering_delegation': {
            'review_grant_issuers': ['/root/independent_review', '/root/qwen35_labbench']}}))
        self.plan = {'owner': '/root/qwen35_labbench', 'condition': 'separate_synthetic_condition',
                     'root_repair_decision': {'path': str(self.repair_path)}}
        self.review_path = self.root / 'review.json'
        self.review = {'passed': True, 'reviewer': '/root/independent_review', 'plan_sha256': 'exact_plan'}
        self.grant_path = self.root / 'grant.json'
        self.grant = {'issuer': '/root/independent_review', 'approved': True, 'plan_sha256': 'exact_plan',
                      'model_keys': ['base', 'posttrained'], 'root_repair_decision_sha256': guards.REPAIR_SHA,
                      'condition': self.plan['condition'], 'independent_review_path': str(self.review_path)}

    def verify(self):
        self.review_path.write_text(json.dumps(self.review))
        self.grant['independent_review_sha256'] = guards.sha(self.review_path)
        self.grant_path.write_text(json.dumps(self.grant))
        with mock.patch.object(guards, 'validate_sources', return_value=self.plan):
            return guards.validate(self.root / 'plan.json', 'exact_plan', self.grant_path,
                                   guards.sha(self.grant_path), 'base')

    def test_exact_independent_admission_is_accepted(self):
        self.assertEqual(self.verify(), self.plan)

    def test_self_approval_is_rejected_even_if_roster_contains_owner(self):
        self.grant['issuer'] = self.review['reviewer'] = '/root/qwen35_labbench'
        with self.assertRaises(ValueError): self.verify()

    def test_wrong_review_plan_is_rejected(self):
        self.review['plan_sha256'] = 'different'
        with self.assertRaises(ValueError): self.verify()

    def test_wrong_review_identity_is_rejected(self):
        self.review['reviewer'] = '/root/someone_else'
        with self.assertRaises(ValueError): self.verify()


def admission_mutation(name, field, value):
    def test(self):
        self.grant[field] = value
        with self.assertRaises(ValueError): self.verify()
    setattr(AdmissionTests, 'test_reject_' + name, test)


for name, field, value in [
    ('unissued_grant', 'approved', False), ('unapproved_issuer', 'issuer', '/root/unknown'),
    ('old_plan_grant', 'plan_sha256', guards.ORIGINAL_PLAN_SHA),
    ('one_model_only', 'model_keys', ['base']), ('extra_model', 'model_keys', ['base', 'posttrained', 'other']),
    ('wrong_root_decision', 'root_repair_decision_sha256', 'wrong'),
    ('wrong_condition', 'condition', 'historical_condition')]:
    admission_mutation(name, field, value)


class PredecessorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.plan = {'predecessors': {}}
        for key in ['base', 'posttrained']:
            root = self.root / key; root.mkdir()
            for name in ['worker.lock', 'run.lock']: (root / name).touch()
            self.plan['predecessors'][key] = {'runtime': str(root)}

    def result(self, text=None):
        return SimpleNamespace(stdout=text if text is not None else '246445|COMPLETED|0:0|\n246714|COMPLETED|0:0|\n')

    def test_exact_original_terminal_jobs_and_free_locks_pass(self):
        with mock.patch.object(guards.subprocess, 'run', return_value=self.result()) as run:
            with guards.predecessor_guard(self.plan) as proof:
                self.assertEqual(len(proof['held_old_output_locks']), 4)
                self.assertFalse(proof['old_submitted_jobs_repeated'])
            self.assertEqual(run.call_args.args[0][0], 'sacct')
            self.assertEqual(run.call_count, 1)

    def test_busy_original_output_lock_blocks_before_scheduler_or_dispatch(self):
        with (self.root / 'base/run.lock').open('r') as handle:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with mock.patch.object(guards.subprocess, 'run') as run:
                with self.assertRaises(BlockingIOError):
                    with guards.predecessor_guard(self.plan): pass
                run.assert_not_called()

    def test_original_output_symlink_is_rejected(self):
        path = self.root / 'base/run.lock'; path.unlink(); path.symlink_to(self.root / 'base/worker.lock')
        with self.assertRaises(ValueError):
            with guards.predecessor_guard(self.plan): pass

    def test_pending_predecessor_is_not_terminal(self):
        with mock.patch.object(guards.subprocess, 'run', return_value=self.result('246445|PENDING|0:0|\n246714|COMPLETED|0:0|\n')):
            with self.assertRaises(ValueError):
                with guards.predecessor_guard(self.plan): pass

    def test_missing_predecessor_is_unknown_not_terminal(self):
        with mock.patch.object(guards.subprocess, 'run', return_value=self.result('246445|COMPLETED|0:0|\n')):
            with self.assertRaises(ValueError):
                with guards.predecessor_guard(self.plan): pass

    def test_ambiguous_duplicate_scheduler_rows_are_rejected(self):
        with mock.patch.object(guards.subprocess, 'run', return_value=self.result('246445|COMPLETED|0:0|\n246445|COMPLETED|0:0|\n246714|COMPLETED|0:0|\n')):
            with self.assertRaises(ValueError):
                with guards.predecessor_guard(self.plan): pass


class SourceBoundaryTests(unittest.TestCase):
    def verify_changed_plan(self, edit):
        path = guards.HERE / 'plan.json'
        plan = guards.read(path)
        edit(plan)
        original_read, original_sha = guards.read, guards.sha
        def read(name): return plan if Path(name) == path else original_read(name)
        def sha(name): return 'synthetic_changed_plan' if Path(name) == path else original_sha(name)
        with mock.patch.object(guards, 'read', side_effect=read), mock.patch.object(guards, 'sha', side_effect=sha):
            return guards.validate_sources(path, 'synthetic_changed_plan')

    def test_exact_frozen_sources_and_predecessors_pass_read_only(self):
        path = guards.HERE / 'plan.json'
        plan = guards.validate_sources(path, guards.sha(path))
        self.assertEqual(plan['benchmark_calls_both_models'], 558)

    def test_locking_unrelated_directory_cannot_substitute_original_output_locks(self):
        with self.assertRaises(ValueError):
            self.verify_changed_plan(lambda p: p['predecessors']['base'].update(runtime='/tmp/unrelated'))

    def test_predecessor_metadata_cannot_come_from_another_namespace(self):
        with self.assertRaises(ValueError):
            self.verify_changed_plan(lambda p: p['predecessors']['base']['completion'].update(path=p['predecessors']['posttrained']['completion']['path']))

    def test_new_output_cannot_reuse_original_namespace(self):
        with self.assertRaises(ValueError):
            self.verify_changed_plan(lambda p: p['models']['base'].update(runtime=str(guards.LANE / 'runtime/base')))

    def test_selective_subset_is_not_the_full_new_condition(self):
        with self.assertRaises(ValueError):
            self.verify_changed_plan(lambda p: p.update(benchmark_calls_per_model=10))

    def test_original_sampling_cannot_substitute_new_recipe(self):
        with self.assertRaises(ValueError):
            self.verify_changed_plan(lambda p: p['generation'].update(temperature=0.2))


class StartupLockTests(unittest.TestCase):
    def test_worker_serializes_boundary_under_global_lock_and_releases_before_restore(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder); (root / '.local').mkdir()
            runtime = root / 'runtime/base'; global_path = root / '.local/evaluation_GPU_submission.lock'
            plan = {'models': {'base': {'runtime': str(runtime)}},
                    'shared_runtime': {'path': 'fake'}, 'shared_contract': {'path': 'fake', 'sha256': 'fake'}}
            def locked():
                with global_path.open('a') as handle:
                    with self.assertRaises(BlockingIOError): fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            @contextmanager
            def predecessor(_):
                locked(); yield {'old_conditions_changed': False}
            def audit(*_, **__):
                locked(); return {'synthetic_only': True}
            def restore(*_):
                with global_path.open('a') as handle:
                    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                raise RuntimeError('intentional synthetic stop before restore/model')
            common = SimpleNamespace(load_contract=lambda *_: {}, restore_runtime=restore)
            argv = ['worker.py', '--plan', 'fake', '--plan-sha256', 'fake', '--grant', 'fake',
                    '--grant-sha256', 'fake', '--model-key', 'base']
            with mock.patch.object(worker, 'ROOT', root), mock.patch.object(worker, 'validate', return_value=plan):
                with mock.patch.object(worker, 'predecessor_guard', predecessor), mock.patch.object(worker, 'neutral', return_value={'passed': True}):
                    with mock.patch.object(worker, 'audit', side_effect=audit), mock.patch.object(worker, 'load', return_value=common):
                        with mock.patch.object(sys, 'argv', argv), mock.patch.dict('os.environ', {'SLURM_JOB_ID': '900001'}):
                            with self.assertRaisesRegex(RuntimeError, 'intentional synthetic stop'): worker.main()
            self.assertTrue((runtime / 'predecessor_observation.json').is_file())
            self.assertFalse((runtime / 'generation.log').exists())


class SubmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name); (self.root / '.local').mkdir()
        self.runtime = self.root / 'new/runtime/base'
        self.plan = {'models': {'base': {'runtime': str(self.runtime)}}}
        self.argv = ['submit.py', '--plan', str(self.root / 'plan.json'), '--plan-sha256', 'new_plan',
                     '--grant', str(self.root / 'grant.json'), '--grant-sha256', 'grant', '--model-key', 'base']
        @contextmanager
        def predecessor(_):
            yield {'old_conditions_changed': False}
        self.patches = [mock.patch.object(submit, 'ROOT', self.root),
                        mock.patch.object(submit, 'validate', return_value=self.plan),
                        mock.patch.object(submit, 'predecessor_guard', predecessor),
                        mock.patch.object(submit, 'neutral', return_value={'passed': True, 'models': {'base': {}, 'posttrained': {}}}),
                        mock.patch.object(submit, 'audit', return_value={'project_requested_GPUs_with_addition': 8}),
                        mock.patch.object(sys, 'argv', self.argv)]
        for patch in self.patches: patch.start()
        self.addCleanup(lambda: [p.stop() for p in reversed(self.patches)])

    def test_missing_actual_neutral_proof_blocks_before_claim_and_submission(self):
        with mock.patch.object(submit, 'neutral', side_effect=FileNotFoundError('No actual receipt')):
            with mock.patch.object(submit.subprocess, 'run') as run:
                with self.assertRaises(FileNotFoundError): submit.main()
                run.assert_not_called()
        self.assertFalse((self.runtime / 'submission_claim.json').exists())

    def test_capacity_only_wait_does_not_claim_or_submit(self):
        with mock.patch.object(submit, 'audit', side_effect=ValueError('Evaluation project GPU requests exceed eight')):
            with mock.patch.object(submit.subprocess, 'run') as run:
                with self.assertRaises(SystemExit) as caught: submit.main()
                self.assertEqual(caught.exception.code, 75); run.assert_not_called()
        self.assertFalse((self.runtime / 'submission_claim.json').exists())
        self.assertFalse((self.runtime / 'submission_receipt.json').exists())

    def test_real_audit_propagates_queue_false_capacity_before_claim(self):
        helper = guards.load(guards.ROOT / 'scripts/project_gpu_audit_20261021.py', 'synthetic_real_GPU_inventory')
        controller = SimpleNamespace(capacity_audit=lambda **_: {
            'capacity_available': False,
            'jobs': [{'gpus': 8, 'counted_toward_evaluation_project': True}]})
        plan = {**self.plan, 'queue_controller': {'path': 'synthetic_controller'},
                'gpu_audit': {'path': 'synthetic_helper'}}
        def load(path, _):
            return controller if path == 'synthetic_controller' else helper
        with mock.patch.object(submit, 'validate', return_value=plan), mock.patch.object(submit, 'audit', guards.audit):
            with mock.patch.object(guards, 'load', side_effect=load), mock.patch.object(submit.subprocess, 'run') as run:
                with self.assertRaises(SystemExit) as caught: submit.main()
                self.assertEqual(caught.exception.code, 75); run.assert_not_called()
        self.assertFalse((self.runtime / 'submission_claim.json').exists())

    def test_claim_is_durable_before_single_sbatch_and_second_invocation_rejected(self):
        def schedule(command, **kwargs):
            claim = json.loads((self.runtime / 'submission_claim.json').read_text())
            self.assertTrue(claim['no_retry_after_claim'])
            self.assertEqual(set(claim['actual_both_model_neutral_proof']['models']), {'base', 'posttrained'})
            self.assertEqual(command[0], 'sbatch')
            return SimpleNamespace(returncode=0, stdout='999123\n', stderr='')
        with mock.patch.object(submit.subprocess, 'run', side_effect=schedule) as run:
            submit.main()
            with self.assertRaises(ValueError): submit.main()
            self.assertEqual(run.call_count, 1)

    def test_uncertain_sbatch_preserves_claim_and_never_retries(self):
        with mock.patch.object(submit.subprocess, 'run', side_effect=subprocess.TimeoutExpired('sbatch', 45)) as run:
            with self.assertRaises(subprocess.TimeoutExpired): submit.main()
            with self.assertRaises(ValueError): submit.main()
            self.assertEqual(run.call_count, 1)
        done = json.loads((self.runtime / 'submission_receipt.json').read_text())
        self.assertEqual(done['stage'], 'submission_uncertain_no_retry')

    def test_failed_sbatch_also_preserves_claim_without_retry(self):
        with mock.patch.object(submit.subprocess, 'run', return_value=SimpleNamespace(returncode=1, stdout='', stderr='synthetic failure')) as run:
            with self.assertRaises(SystemExit): submit.main()
            with self.assertRaises(ValueError): submit.main()
            self.assertEqual(run.call_count, 1)


if __name__ == '__main__':
    unittest.main()
