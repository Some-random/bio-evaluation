"""Artificial contract cases; no benchmark rows or labels are used."""
import unittest
from native_scoring_v2 import native_answer, score_closed_rows


class NativeScoringTests(unittest.TestCase):
    def test_native_answer_forms(self):
        for text in ['A', '[ANSWER]A[/ANSWER]', '[ANS]A[/ANS]',
                     '<ANSWER>A</ANSWER>', '<ans>A</ans>',
                     'Reasoning. [ANSWER]A[/ANSWER]']:
            self.assertEqual(native_answer(text, 5), 'A')

    def test_native_invalid_forms(self):
        for text in ['', 'answer is A', '[ANSWER]Z[/ANSWER]',
                     '[ANSWER]A', 'a']:
            self.assertIsNone(native_answer(text, 5))

    def test_preserves_native_multiple_match_behavior(self):
        self.assertEqual(native_answer('[ANSWER]B[/ANSWER] [ANSWER]A[/ANSWER]', 5), 'A')

    def fixture(self):
        inputs = [{'task_id': 'ARTIFICIAL', 'case_id': str(i)} for i in range(3)]
        predictions = [{**i, 'terminal': True, 'final_text': t}
                       for i, t in zip(inputs, ['[ANSWER]A[/ANSWER]', '[ANSWER]E[/ANSWER]', ''])]
        refs = {('ARTIFICIAL', str(i)): {'choice_count': 5, 'target_choice': 'A',
                                       'unsure_choice': 'E'} for i in range(3)}
        return inputs, predictions, refs

    def test_full_denominator_and_native_abstention(self):
        result = score_closed_rows(*self.fixture())['per_task']['ARTIFICIAL']
        self.assertEqual(result['metrics'], {'accuracy': 1/3, 'precision': 1/2,
                                           'coverage': 2/3, 'n_total': 3,
                                           'n_correct': 1, 'n_sure': 2})
        self.assertEqual(result['diagnostics']['invalid_outputs'], 1)

    def test_transport_cannot_supply_answer(self):
        inputs, preds, refs = self.fixture()
        preds[0]['transport_error'] = True
        self.assertEqual(score_closed_rows(inputs, preds, refs)['per_task']['ARTIFICIAL']['metrics']['n_correct'], 0)

    def test_refusal_cannot_supply_answer(self):
        inputs, preds, refs = self.fixture()
        preds[0]['refusal'] = True
        result = score_closed_rows(inputs, preds, refs)['per_task']['ARTIFICIAL']
        self.assertEqual(result['metrics']['n_correct'], 0)
        self.assertEqual(result['diagnostics']['refusal'], 1)
        self.assertEqual(result['diagnostics']['response_error'], 0)

    def test_rejects_incomplete_reordered_and_unsealed(self):
        inputs, preds, refs = self.fixture()
        for bad in [preds[:2], list(reversed(preds))]:
            with self.assertRaises(ValueError):
                score_closed_rows(inputs, bad, refs)
        preds[0]['terminal'] = False
        with self.assertRaises(ValueError):
            score_closed_rows(inputs, preds, refs)


if __name__ == '__main__':
    unittest.main()
