"""Admission and predecessor controls for a new complete LAB-Bench condition."""
from contextlib import ExitStack, contextmanager
from pathlib import Path
import fcntl
import hashlib
import importlib.util
import json
import os
import subprocess

HERE = Path(__file__).resolve().parent
LANE = HERE.parent
PAIR = LANE.parent
ROOT = PAIR.parents[1]
OWNER = '/root/qwen35_labbench'
REPAIR_SHA = 'a988b8972658cb27d4c0b0d9557da32ddf17d22e134cf4c1b69702f50af5a65f'
CONTRACT_SHA = '00f42f82e48d9dbb4cebcf8c2a5c8631c45092e80a94a12af9b0b58cf451a83d'
ORIGINAL_PLAN_SHA = '9926c00d14115a2cfad32b2680f93ef9080c105829ebbbf6292ccdd4e15b4c3f'
MODELS = {'base', 'posttrained'}
JOBS = {'base': '246445', 'posttrained': '246714'}


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def regular(path):
    path = Path(path)
    if not path.is_absolute() or path != path.resolve() or path.is_symlink() or not path.is_file():
        raise ValueError('Exact nonsymlink regular artifact required')
    return path


def sha(path):
    return hashlib.sha256(regular(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(regular(path).read_text())


def pin(row):
    if sha(row['path']) != row['sha256']:
        raise ValueError('Pinned artifact changed: ' + str(row['path']))
    return read(row['path']) if str(row['path']).endswith('.json') else None


def validate_sources(plan_path, expected):
    if Path(plan_path) != HERE / 'plan.json' or sha(plan_path) != expected:
        raise ValueError('Exact separate frozen prospective plan required')
    plan = read(plan_path)
    repair = pin(plan['root_repair_decision'])
    if (plan['owner'] != OWNER or plan['root_repair_decision']['sha256'] != REPAIR_SHA
            or repair.get('issuer') != '/root'
            or 'LAB-Bench reviewed197+82' not in repair.get('scopes', [])
            or plan['shared_contract']['sha256'] != CONTRACT_SHA
            or plan['benchmark_calls_per_model'] != 279
            or plan['benchmark_calls_both_models'] != 558
            or set(plan['models']) != MODELS):
        raise ValueError('Exact new full-cohort root scope required')
    contract = pin(plan['shared_contract'])
    if (plan['generation'] != contract['generation'] or plan['context_limit'] != 65536
            or contract['thinking'] is not True or plan['batch_size'] != 16):
        raise ValueError('Both models require exact root-adopted thinking recipe')
    for key in MODELS:
        row = plan['models'][key]
        if (row['runtime'] != str(HERE / 'runtime' / key)
                or Path(row['runtime']).resolve() != Path(row['runtime'])
                or (row['name'], row['revision']) !=
                   (contract['models'][key]['name'], contract['models'][key]['revision'])):
            raise ValueError('Separate exact model runtime namespace required')
    if (plan['score_runtime'] != str(HERE / 'runtime/scoring')
            or Path(plan['score_runtime']).resolve() != Path(plan['score_runtime'])):
        raise ValueError('Original scoring namespace must remain immutable')
    for path, digest in plan['pins'].items():
        if sha(path) != digest:
            raise ValueError('Frozen new condition source changed: ' + path)
    original = pin(plan['original_condition'])
    if plan['original_condition'] != {'path': str(LANE / 'plan_v3.json'), 'sha256': ORIGINAL_PLAN_SHA}:
        raise ValueError('Original scientific plan identity changed')
    for path, digest in original['pins'].items():
        if sha(path) != digest:
            raise ValueError('Original frozen source changed')
    if plan['inputs'] != original['inputs'] or plan['references_scorer_only'] != original['references_scorer_only']:
        raise ValueError('Exact original reviewed inputs and native scorer references required')
    for key in MODELS:
        prior = plan['predecessors'][key]
        prior_runtime = LANE / 'runtime' / key
        if prior.get('runtime') != str(prior_runtime):
            raise ValueError('Exact original predecessor output directory required')
        names = {'submission': 'submission_receipt.json', 'worker_terminal': 'worker_terminal.json',
                 'completion': 'completion.json', 'prediction_lock': 'prediction_lock.json'}
        for name in ['submission', 'worker_terminal', 'completion', 'prediction_lock']:
            if prior[name].get('path') != str(prior_runtime / names[name]):
                raise ValueError('Exact original predecessor artifact paths required')
            pin(prior[name])
        submission = read(prior['submission']['path'])
        terminal = read(prior['worker_terminal']['path'])
        if (prior['job_id'] != JOBS[key] or submission.get('job_id') != JOBS[key]
                or submission.get('plan_sha256') != ORIGINAL_PLAN_SHA
                or terminal.get('job_id') != JOBS[key] or terminal.get('returncode') != 0
                or terminal.get('plan_sha256') != ORIGINAL_PLAN_SHA):
            raise ValueError('Original actual predecessor identity or terminal bytes differ')
    return plan


def validate(plan_path, expected, grant_path, grant_sha, model_key):
    if model_key not in MODELS:
        raise ValueError('Unknown matched model')
    plan = validate_sources(plan_path, expected)
    if sha(grant_path) != grant_sha:
        raise ValueError('Independent runtime grant changed')
    grant = read(grant_path)
    repair = read(plan['root_repair_decision']['path'])
    allowed = repair['engineering_delegation']['review_grant_issuers']
    if (grant.get('issuer') not in allowed or grant.get('issuer') == plan['owner']
            or grant.get('approved') is not True or grant.get('plan_sha256') != expected
            or set(grant.get('model_keys', [])) != MODELS
            or grant.get('root_repair_decision_sha256') != REPAIR_SHA
            or grant.get('condition') != plan['condition']):
        raise ValueError('Independent exact new-condition pair grant required')
    review = pin({'path': grant['independent_review_path'], 'sha256': grant['independent_review_sha256']})
    if (review.get('passed') is not True or review.get('plan_sha256') != expected
            or review.get('reviewer') != grant['issuer'] or review.get('reviewer') not in allowed
            or review.get('reviewer') == OWNER):
        raise ValueError('Independent exact new-condition source review required')
    return plan


def neutral(plan):
    helper = load(plan['neutral_proof']['path'], 'labbench_recommended_actual_neutral_proof')
    result = helper.verify_neutral_proof(plan['shared_contract']['sha256'])
    if result['job_id'] != plan['neutral_validation']['job_id']:
        raise ValueError('Actual neutral job substituted')
    return result


@contextmanager
def predecessor_guard(plan):
    """Hold both old worker/run locks across a fresh exact terminal observation."""
    with ExitStack() as stack:
        locked = []
        for key in ['base', 'posttrained']:
            for name in ['worker.lock', 'run.lock']:
                path = Path(plan['predecessors'][key]['runtime']) / name
                regular(path)
                fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
                handle = stack.enter_context(os.fdopen(fd, 'rb'))
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked.append(str(path))
        ids = ','.join(JOBS[k] for k in ['base', 'posttrained'])
        result = subprocess.run(['sacct', '-j', ids, '--noheader', '--parsable2',
                                 '--format=JobIDRaw,State,ExitCode'],
                                capture_output=True, text=True, check=True, timeout=30)
        rows = {}
        for line in result.stdout.splitlines():
            fields = line.strip().split('|')
            if fields and fields[0] in JOBS.values():
                if len(fields) < 3 or fields[0] in rows:
                    raise ValueError('Ambiguous exact predecessor scheduler observation')
                rows[fields[0]] = {'job_id': fields[0], 'state': fields[1], 'exit_code': fields[2]}
        if (set(rows) != set(JOBS.values())
                or any(r['state'] != 'COMPLETED' or r['exit_code'] != '0:0' for r in rows.values())):
            raise ValueError('Both original submitted jobs must be freshly terminal without ambiguity')
        yield {'role': 'fresh_original_terminal_and_output_locks_free', 'jobs': rows,
               'held_old_output_locks': locked, 'old_conditions_changed': False,
               'old_submitted_jobs_repeated': False}


def audit(plan, own=False, additional=0):
    controller = load(plan['queue_controller']['path'], 'labbench_recommended_existing_queue_audit')
    result = controller.capacity_audit(additional=additional, override=False)
    helper = load(plan['gpu_audit']['path'], 'labbench_recommended_own_allocation_audit')
    # The unchanged queue observer returns capacity_available=False; the worker
    # helper enforces the ceiling with an exception for BOTH submission/startup.
    helper.evaluate_inventory(result['jobs'], os.environ.get('SLURM_JOB_ID') if own else None, additional)
    if own:
        own_rows = [r for r in result['jobs'] if r['job_id'] == os.environ.get('SLURM_JOB_ID')]
        if (len(own_rows) != 1 or own_rows[0]['command'] != str(HERE / 'worker.sbatch')
                or own_rows[0]['workdir'] != str(ROOT)):
            raise ValueError('Wrong exact new-condition GPU worker identity')
    return result
