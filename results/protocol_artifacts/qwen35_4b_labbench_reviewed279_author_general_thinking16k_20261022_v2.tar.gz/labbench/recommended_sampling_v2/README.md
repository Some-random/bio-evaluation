# LAB-Bench matched author general-thinking recipe

This is a separately named prospective condition with all 197 reviewed
LitQA2 questions and all 82 SuppQA questions for each exact original BF16
Qwen3.5-4B and Qwen3.5-4B-Base checkpoint. The original cohort, native prompts,
choice ordering and native accuracy/precision/coverage scorer are unchanged.
The two held LitQA2 questions remain excluded.

The pinned posttrained model card's general-thinking recipe is applied equally
to both models: temperature 1, top-p 0.95, top-k 20 and presence penalty 1.5.
This is not an independently documented Base recommendation. The output budget
remains 16,384 tokens, below the card's 32K recommendation; the context remains
65,536 tokens. There are no tools, retrieval, new paper contents or images.

The original plan `9926c00d...`, submitted jobs 246445 and 246714, saved outputs,
scores and publication remain separate and immutable. This full-cohort
condition does not selectively replace old failures or merge new answers into
the old result. Every new model uses a new runtime directory here.

The new common artificial gate must pass for both actual models under the
exact new recipe. The shared pure verifier checks all 17 outcomes per model,
the full native requests, effective sampling, raw/final associations, runtime,
model identities and every artifact hash. No gate receipt exists merely
because preparation or a scheduler submission exists.

Independent exact source/plan review and a plan-bound grant are required.
Only the existing central queue owner may admit the new request templates.
The once-only submitter checks the real gate and both original jobs' fresh
terminal status plus output locks, then audits all pending/running project GPU
requests under the global accounting lock. Unknown jobs stay counted. Each
condition has one durable submission claim and one attempt per case; uncertain
submission or delivery is preserved without retry.

The new driver synchronizes each once-only record and its parent directory
before returning, so request claims are durable before the model entrypoint.
This persistence-only engineering fix changes no prompt, generation or scoring
logic; the completed original driver and outputs remain unchanged.

After both complete 279-case prediction sets are sealed, the unchanged paired
scoring implementation validates every request/response association before its
one native scoring attempt. No labels are read by the generation worker.

The `.template.json` files are unissued preparation. Their placeholders and
false approval fields do not authorize grants, queue intake, allocations or
benchmark calls. The two primary reports remain root-owned and unchanged by
this preparation.
