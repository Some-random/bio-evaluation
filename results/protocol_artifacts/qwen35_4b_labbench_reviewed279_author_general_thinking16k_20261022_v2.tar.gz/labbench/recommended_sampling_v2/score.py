"""Once-only native scoring after both complete, provenance-verified seals."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import fcntl
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def inside(root, name):
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError('Locked artifact escapes run directory')
    return path


def validate_predictions(plan_path, plan, inputs, model_key, common, contract):
    model = plan['models'][model_key]
    root = Path(model['runtime'])
    done = json.loads((root / 'completion.json').read_text())
    path = root / 'prediction_lock.json'
    if (done.get('all_planned_terminal') is not True
            or done.get('prediction_lock_sha256') != sha(path)):
        raise ValueError('Require exact complete prediction seal')
    lock = json.loads(path.read_text())
    for item in [done, lock]:
        if (item['model'] != model['name'] or item['model_revision'] != model['revision']
                or item['model_key'] != model_key or item['run_id'] != model['run_id']
                or item['plan_sha256'] != sha(plan_path) or item['planned'] != 279):
            raise ValueError('Incorrect sealed model, plan, run, or denominator')
    if lock.get('scoring_performed') is not False or lock.get('references_not_opened') is not True:
        raise ValueError('Require prediction seal before reference access')
    rows = lock['rows']
    if [(r['task_id'], r['case_id']) for r in rows] != [(r['task_id'], r['case_id']) for r in inputs]:
        raise ValueError('Incorrect prediction case set or order')
    predictions = []
    for row, case in zip(rows, inputs):
        request_path = inside(root, row['request_path'])
        response_path = inside(root, row['response_path'])
        if sha(request_path) != row['request_sha256'] or sha(response_path) != row['response_sha256']:
            raise ValueError('Locked request or response bytes changed')
        request = json.loads(request_path.read_text())
        response = json.loads(response_path.read_text())
        for item in [request, response]:
            if (item['task_id'] != case['task_id'] or item['case_id'] != case['case_id']
                    or item['model'] != model['name'] or item['model_key'] != model_key
                    or item['model_revision'] != model['revision']
                    or item['run_id'] != model['run_id'] or item['plan_sha256'] != sha(plan_path)):
                raise ValueError('Request-response case/model association changed')
        prepared = request['prepared']
        if request['messages'] != case['messages'] or prepared['messages_sha256'] != digest(case['messages']):
            raise ValueError('Complete native messages changed')
        if (prepared['model_key'] != model_key or prepared['task_id'] != case['task_id']
                or prepared['case_id'] != case['case_id']
                or digest(prepared['body']) != prepared['request_sha256']
                or prepared['body'] != {'model': model['name'], 'prompt': prepared['prompt'], **plan['generation']}
                or response['prepared_request_sha256'] != prepared['request_sha256']
                or response['request_sha256'] != sha(request_path)):
            raise ValueError('Prepared generation request changed')
        if (response.get('terminal') is not True or response.get('raw_response_saved') is not True
                or response.get('status') not in ['completed', 'response_error']
                or not isinstance(response.get('token_ids'), list)):
            raise ValueError('Require actual raw, terminal model response')
        normalized = common.normalize_output(
            prepared, response['raw_text'], response['token_ids'],
            response['finish_reason'], contract, response.get('usage'))
        if any(response[key] != normalized[key] for key in
               ['final', 'final_text', 'reasoning', 'response_error', 'truncated', 'status']):
            raise ValueError('Final-channel extraction or truncation record changed')
        predictions.append(response)
    return predictions, {'path': str(path), 'sha256': sha(path),
                         'case_count': len(predictions)}


def score(plan_path, expected):
    if sha(plan_path) != expected:
        raise ValueError('Plan changed')
    plan = json.loads(Path(plan_path).read_text())
    for path, wanted in plan['pins'].items():
        if sha(path) != wanted:
            raise ValueError('Plan source changed')
    inputs_path = Path(plan['inputs']['path'])
    if sha(inputs_path) != plan['inputs']['sha256']:
        raise ValueError('Input packet changed')
    inputs = [json.loads(line) for line in inputs_path.read_text().splitlines()]
    common = load(plan['shared_runtime']['path'], 'labbench_common_for_sealed_scoring')
    contract = common.load_contract(plan['shared_contract']['path'], plan['shared_contract']['sha256'])
    predictions, seals = {}, {}
    # Both complete output sets and every actual request association validate
    # before the sole scoring attempt opens either source reference archive.
    for key in ['base', 'posttrained']:
        predictions[key], seals[key] = validate_predictions(plan_path, plan, inputs, key, common, contract)
    target = Path(plan['score_runtime'])
    target.mkdir(parents=True, exist_ok=True)
    with (target / 'scoring.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        attempt = target / 'attempt_001.json'
        if attempt.exists():
            # A simultaneous second finisher may observe the already completed
            # sole attempt; it may verify/read that result but must never rescore.
            complete = target / 'completion.json'
            if not complete.is_file():
                raise ValueError('Scoring attempt already exists without verified completion; no retry')
            done = json.loads(complete.read_text())
            if done.get('plan_sha256') != expected or done.get('scores_sha256') != sha(target / 'scores.json'):
                raise ValueError('Existing score completion changed')
            return json.loads((target / 'scores.json').read_text())
        with attempt.open('x') as handle:
            json.dump({'plan_sha256': expected, 'at_pacific': datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
                       'both_seals_verified_before_reference_read': True, 'seals': seals}, handle, indent=2)
        wanted = {(r['task_id'], r['case_id']) for r in inputs}
        references = {}
        for task, record in plan['references_scorer_only'].items():
            path = Path(record['path'])
            if sha(path) != record['sha256']:
                raise ValueError('Native source reference archive changed')
            for line in path.read_text().splitlines():
                row = json.loads(line)
                key = (row['task'], row['case_id'])
                if key in wanted and key[0] == task:
                    if key in references:
                        raise ValueError('Duplicate native reference')
                    references[key] = {k: row[k] for k in ['choice_count', 'target_choice', 'unsure_choice']}
        if set(references) != wanted:
            raise ValueError('Incomplete native references for fixed cohort')
        native = load(HERE / 'native_scoring_v2.py', 'labbench_native_v2_for_sealed_scoring')
        results = {key: native.score_closed_rows(inputs, predictions[key], references)
                   for key in ['base', 'posttrained']}
        summary = {'at_pacific': datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
                   'stage': 'scored_terminal', 'plan_sha256': expected,
                   'condition': plan['condition'], 'prediction_seals': seals,
                   'models': {key: {'model': plan['models'][key]['name'],
                                   'revision': plan['models'][key]['revision'],
                                   **{k: v for k, v in results[key].items() if k != 'per_case'}}
                              for key in ['base', 'posttrained']},
                   'reference_access_only_after_both_seals_verified': True,
                   'native_metrics': ['accuracy', 'precision', 'coverage'],
                   'all_case_denominators_preserved': True,
                   'optional_llm_extraction_used': False,
                   'biological_explanation_correctness_assessed': False,
                   'pretraining_exposure': 'unknown',
                   'scope': 'B01 reviewed197/199 plus B03 public82/82; closed-book without retrieval'}
        for key in ['base', 'posttrained']:
            path = target / f'{key}.per_case_scores.json'
            with path.open('x') as handle:
                json.dump(results[key]['per_case'], handle, indent=2)
        with (target / 'scores.json').open('x') as handle:
            json.dump(summary, handle, indent=2)
        with (target / 'completion.json').open('x') as handle:
            json.dump({'stage': 'scored_terminal', 'plan_sha256': expected,
                       'scores_sha256': sha(target / 'scores.json'),
                       'both_prediction_seals': seals}, handle, indent=2)
        return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(score(args.plan, args.plan_sha256)))
