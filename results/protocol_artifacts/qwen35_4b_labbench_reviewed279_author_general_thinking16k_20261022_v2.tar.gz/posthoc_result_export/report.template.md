# Qwen3.5-4B and 4B-Base on LAB-Bench: author general-thinking recipe

Native scoring completed at $scoring_completed_pacific. Both models received the same 197 reviewed LitQA2 questions and 82 SuppQA questions. Two previously held LitQA2 questions remain excluded.

| Evaluation, year and question | Qwen3.5-4B-Base | Qwen3.5-4B |
|---|---|---|
| LAB-Bench: LitQA2 (2024)<br>[Complete question and input](questions/B01.md) | $base_litqa_metrics | $posttrained_litqa_metrics |
| LAB-Bench: SuppQA (2024)<br>[Complete question and input](questions/B03.md) | $base_suppqa_metrics | $posttrained_suppqa_metrics |

These are closed-book text results using the complete released question fields and choices. SuppQA retains its released paper title and DOI. No additional papers, supplements, retrieval, model tools or images were supplied.

Both original BF16 checkpoints used thinking enabled, a 16,384-token output budget including reasoning and a 65,536-token context. The posttrained model card's general-thinking recipe was applied equally to both models: temperature 1, top-p 0.95, top-k 20 and presence penalty 1.5. This is not a separate author recommendation for Base, and the retained 16K output budget is below the card's 32K recommendation.

All 279 raw responses per model were saved and sealed before the one native scoring attempt. Invalid and truncated answers remain in the complete task denominators. Base had $base_truncations truncated answers and $base_empty_finals empty finals; posttrained 4B had $posttrained_truncations truncated answers and $posttrained_empty_finals empty finals. $delivery_errors_sentence

$task_diagnostics

This separately named full-cohort sampling condition preserves the [original 4B comparison](QWEN35_4B_LABBENCH_RESULTS_2026-10-22.md) and all earlier Qwen/GPT results. No failed cases were selectively retried or replaced, and these results do not reproduce the paper's full public/private evaluation. Outcome accuracy does not establish correctness of generated explanations; exposure to public benchmarks during pretraining is unknown.

The exact checkpoints are `Qwen/Qwen3.5-4B-Base@1001bb4d826a52d1f399e183466143f4da7b741b` and `Qwen/Qwen3.5-4B@851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a`. The new jobs were $base_job and $posttrained_job, under scientific plan `$plan_sha256`.

[Machine-readable metrics and diagnostics]($report_json_name) · [Sealed paired scores](../$scores_path) · [Read-only result audit](../$audit_path) · [Frozen protocol source archive](../$protocol_path)

[Base complete saved trajectories](../$base_trajectory_path) · [Archive manifest](../$base_manifest_path)

[Posttrained complete saved trajectories](../$posttrained_trajectory_path) · [Archive manifest](../$posttrained_manifest_path)
