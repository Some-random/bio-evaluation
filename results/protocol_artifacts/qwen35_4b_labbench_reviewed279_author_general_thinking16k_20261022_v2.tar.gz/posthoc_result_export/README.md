# Future export of the recommended-sampling LAB-Bench condition

This directory contains CPU-only packaging preparation. It is separate from
the original comparison's completed export and from the frozen inference
implementation. Preparation is not a result or publication admission.

The auditor requires scientific plan
`9bebb13605b9eddb34f97ea89961e8eff1d2a0a91df7974be315a6e1ab889192`,
the independently issued runtime grant, jobs 247045 and 247047, both complete
279-case seals, both normal worker terminals and the completed sole native
scoring attempt. It validates exact native inputs, raw-to-final normalization,
request/response/model associations and stored native per-case arithmetic.
It never invokes the scoring entrypoint or reads source reference rows.

When the owner has verified the actual closed score hash, the future local
commands are:

```bash
python3 audit_result.py --expected-scores-sha256 ACTUAL_COMPLETED_SCORE_SHA256
python3 build_package.py --expected-scores-sha256 ACTUAL_COMPLETED_SCORE_SHA256
```

The builder checks readiness before creating any final output. It preflights
the complete source allowlist and report fields, then creates separate
trajectories, protocol sources, native scores, a report and a package manifest.
Raw questions, model answers and token IDs are preserved. Public operational
records retain original hashes and exclude unrelated account inventories and
private runtime/environment files. No original report, score or archive is
overwritten. Local package creation performs no model/scoring/network calls.

Future publication uses the separate `publish.py`. It remains blocked until
the completed actual package and every payload hash are bound by a later exact
`publication_candidate.json` and an independent
`independent_result_publication_review.json`. The `.template.json` files are
unissued preparation and cannot satisfy those requirements. A runtime grant
or source-only review cannot substitute for completed-payload review.

The publisher rechecks the completed result, scans every plain file and archive,
verifies the exact public repository and push permission, acquires the shared
publication lock and works in an isolated sparse checkout. It permits only the
17 exact new-condition paths, rejects differing existing artifacts, records one
durable publication attempt, and verifies every uploaded byte against remote
`main`. Shared primary reports, old results, websites and schedules are excluded.
No publisher, scanner, Git or network operation has been run by preparation.
