"""Read-only closed-result audit; never invokes scoring or opens references."""
from collections import Counter
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import argparse
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
LANE = HERE.parent
PAIR = LANE.parents[1]
ROOT = PAIR.parents[1]
PLAN_SHA = '9bebb13605b9eddb34f97ea89961e8eff1d2a0a91df7974be315a6e1ab889192'
GRANT_SHA = 'eecb00098ec96b2f8f9e1fc52edd4877792f5f2e8c4afe618d3fb6cc39886510'
INPUT_SHA = '3b4972ca9ac7009c7e8f7628dd0a72f6654ac0e7e2e75cb224c11e1b253146ad'
NATIVE_SHA = '379a6fb42badfce0d0d4f599deb05859d19ceb0b2248199a57b8d9e7e25dc5b4'
CONTRACT_SHA = '00f42f82e48d9dbb4cebcf8c2a5c8631c45092e80a94a12af9b0b58cf451a83d'
JOBS = {'base': '247045', 'posttrained': '247047'}
TASKS = {'B01': 197, 'B03': 82}


class NotReadyError(RuntimeError):
    """Missing completion evidence is unknown, never a zero or completed result."""


def require(value, message):
    if not value:
        raise ValueError(message)


def regular(path):
    path = Path(path)
    require(path.is_absolute() and path == path.resolve() and not path.is_symlink()
            and path.is_file(), 'Expected exact nonsymlink regular result artifact: ' + str(path))
    return path


def sha(path):
    return hashlib.sha256(regular(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(regular(path).read_text())


def load(path, name):
    regular(path)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def pinned_module(path, expected, name):
    require(sha(path) == expected, 'Helper changed before import: ' + str(path))
    return load(path, name)


def require_ready(plan):
    """Check presence before importing runtime/scoring helpers or producing files."""
    paths = [Path(plan['score_runtime']) / name for name in
             ['attempt_001.json', 'completion.json', 'scores.json',
              'base.per_case_scores.json', 'posttrained.per_case_scores.json']]
    for model in plan['models'].values():
        paths.extend(Path(model['runtime']) / name for name in
                     ['prediction_lock.json', 'completion.json', 'worker_terminal.json',
                      'model_completed.json'])
    absent = [str(path) for path in paths if not path.exists()]
    if absent:
        raise NotReadyError('Both complete prediction seals, native score completion and worker terminals required; missing: '
                            + ', '.join(absent))


def check_per_case(inputs, predictions, per_case, stored, task_counts=TASKS):
    """Reconcile stored native scoring arithmetic, without references or rescoring."""
    require([(r['task_id'], r['case_id']) for r in per_case]
            == [(r['task_id'], r['case_id']) for r in inputs],
            'Stored per-case score order or complete cohort differs')
    for row, response in zip(per_case, predictions):
        require(all(type(row.get(name)) is bool for name in
                    ['correct', 'sure', 'parsed', 'empty_final', 'truncated', 'transport_error',
                     'http_error', 'response_error', 'not_dispatched', 'refusal']),
                'Native per-case boolean diagnostics required')
        require(row['parsed'] == (row.get('answer') is not None)
                and (row['parsed'] or row['correct'] is False),
                'Stored parsed/correct flags contradict native answer')
        require(row['empty_final'] == (not response['final_text'].strip())
                and all(row[name] == bool(response.get(name)) for name in
                        ['truncated', 'transport_error', 'http_error', 'response_error',
                         'not_dispatched', 'refusal']),
                'Stored diagnostics contradict sealed model response')
    tasks = {}
    for task, number in task_counts.items():
        rows = [r for r in per_case if r['task_id'] == task]
        require(len(rows) == number, 'Native task denominator changed')
        correct, sure = sum(r['correct'] for r in rows), sum(r['sure'] for r in rows)
        # Frozen native_metrics returns 0.0 when all answers abstain.
        metrics = {'accuracy': correct / number, 'precision': correct / sure if sure else 0.0,
                   'coverage': sure / number, 'n_total': number, 'n_correct': correct, 'n_sure': sure}
        diagnostics = {name: sum(r[name] for r in rows) for name in
                       ['parsed', 'empty_final', 'truncated', 'transport_error', 'http_error',
                        'response_error', 'not_dispatched', 'refusal']}
        diagnostics['invalid_outputs'] = number - diagnostics['parsed']
        require(stored[task]['metrics'] == metrics and stored[task]['diagnostics'] == diagnostics,
                'Stored native score summaries differ from their per-case arithmetic')
        tasks[task] = {'metrics': metrics, 'diagnostics': diagnostics}
    return tasks


def audit(expected_scores_sha256=None):
    observed = {}

    def capture(path):
        path = regular(path)
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        require(path not in observed or observed[path] == digest,
                'Result artifact changed while auditing')
        observed[path] = digest
        return raw

    def sha(path):
        return hashlib.sha256(capture(path)).hexdigest()

    def read(path):
        return json.loads(capture(path))

    plan_path, grant_path = LANE / 'plan.json', LANE / 'independent_grant.json'
    require(sha(plan_path) == PLAN_SHA and sha(grant_path) == GRANT_SHA,
            'Exact admitted recommended-sampling plan and grant required')
    plan = read(plan_path)
    require_ready(plan)
    guards = pinned_module(LANE / 'guards.py', plan['pins'][str(LANE / 'guards.py')],
                           'labbench_recommended_result_source_guards')
    guards.validate(plan_path, PLAN_SHA, grant_path, GRANT_SHA, 'base')
    require(plan['inputs']['sha256'] == INPUT_SHA and sha(plan['inputs']['path']) == INPUT_SHA
            and sha(LANE / 'native_scoring_v2.py') == NATIVE_SHA
            and plan['shared_contract']['sha256'] == CONTRACT_SHA,
            'Original reviewed inputs/native scorer or recommended contract changed')
    inputs = [json.loads(line) for line in capture(plan['inputs']['path']).decode().splitlines()]
    require(Counter(row['task_id'] for row in inputs) == TASKS
            and len({(r['task_id'], r['case_id']) for r in inputs}) == 279,
            'Exact unique reviewed197+82 cohort required')
    common = pinned_module(plan['shared_runtime']['path'], plan['shared_runtime']['sha256'],
                           'labbench_recommended_result_common')
    contract = common.load_contract(plan['shared_contract']['path'], CONTRACT_SHA)
    gate = guards.neutral(plan)  # Pure actual proof checks; no scheduler/model call.
    scorer = pinned_module(LANE / 'score.py', plan['pins'][str(LANE / 'score.py')],
                           'labbench_recommended_readonly_seal_validator')
    driver = pinned_module(LANE / 'driver.py', plan['pins'][str(LANE / 'driver.py')],
                           'labbench_recommended_readonly_telemetry')
    score_root = Path(plan['score_runtime'])
    scores, complete = read(score_root / 'scores.json'), read(score_root / 'completion.json')
    score_sha = sha(score_root / 'scores.json')
    require(expected_scores_sha256 is None or expected_scores_sha256 == score_sha,
            'Expected final native score hash differs')
    require(complete.get('stage') == scores.get('stage') == 'scored_terminal'
            and complete.get('scores_sha256') == score_sha
            and complete.get('plan_sha256') == scores.get('plan_sha256') == PLAN_SHA
            and scores.get('condition') == plan['condition']
            and scores.get('all_case_denominators_preserved') is True
            and scores.get('reference_access_only_after_both_seals_verified') is True
            and scores.get('optional_llm_extraction_used') is False
            and scores.get('native_metrics') == ['accuracy', 'precision', 'coverage'],
            'Require the completed sole full-denominator native score')
    require({p.name for p in score_root.glob('attempt_*.json')} == {'attempt_001.json'},
            'Unexpected extra scoring attempt')
    attempt = read(score_root / 'attempt_001.json')
    require(attempt.get('plan_sha256') == PLAN_SHA
            and attempt.get('both_seals_verified_before_reference_read') is True,
            'Native sole-attempt pre-reference seal proof differs')
    score_files = {str(path): sha(path) for path in [score_root / name for name in
                   ['scores.json', 'completion.json', 'attempt_001.json',
                    'base.per_case_scores.json', 'posttrained.per_case_scores.json']]}
    models, seals, export_pins = {}, {}, dict(score_files)
    for key, job in JOBS.items():
        predictions, seals[key] = scorer.validate_predictions(plan_path, plan, inputs, key, common, contract)
        run = Path(plan['models'][key]['runtime'])
        done, locked, submission = read(run / 'completion.json'), read(run / 'prediction_lock.json'), read(run / 'submission_receipt.json')
        names = ['started.json', 'completion.json', 'prediction_lock.json', 'tokenizer_preflight.json',
                 'worker_started.json', 'worker_terminal.json', 'shared_neutral_gate_observation.json',
                 'model_completed.json', 'submission_claim.json', 'submission_receipt.json',
                 'predecessor_observation.json', 'gpu_audit.json']
        for name in names:
            export_pins[str(run / name)] = sha(run / name)
        for record in [done, locked, submission, read(run / 'started.json'),
                       read(run / 'worker_started.json'), read(run / 'worker_terminal.json')]:
            require(record.get('job_id') == job and record.get('plan_sha256') == PLAN_SHA,
                    'New result belongs to another job or scientific condition')
        require(submission.get('grant_sha256') == GRANT_SHA and submission.get('model_key') == key
                and submission.get('requested_gpu_count') == 1 and submission.get('sbatch_invoked') is True
                and read(run / 'worker_terminal.json').get('returncode') == 0,
                'Exact once-submitted model job must terminate normally')
        worker_started = read(run / 'worker_started.json')
        model_completed = read(run / 'model_completed.json')
        claim = read(run / 'submission_claim.json')
        require(worker_started.get('grant_sha256') == GRANT_SHA and worker_started.get('model_key') == key
                and model_completed.get('plan_sha256') == PLAN_SHA
                and model_completed.get('model_key') == key
                and model_completed.get('all279_predictions_sealed') is True
                and claim.get('plan_sha256') == PLAN_SHA and claim.get('grant_sha256') == GRANT_SHA
                and claim.get('model_key') == key and claim.get('no_retry_after_claim') is True
                and claim.get('actual_both_model_neutral_proof') == gate,
                'Submission claim or model/worker completion provenance differs')
        for observation, additional in [(claim.get('gpu_audit', {}), 1),
                                        (submission.get('gpu_audit', {}), 1),
                                        (read(run / 'gpu_audit.json'), 0)]:
            require(observation.get('capacity_available') is True
                    and observation.get('project_GPU_ceiling') == 8
                    and observation.get('additional_GPUs') == additional
                    and type(observation.get('project_requested_GPUs')) is int
                    and 0 <= observation['project_requested_GPUs'] + additional <= 8
                    and observation.get('local_246310_override_enabled') is False,
                    'Recorded fresh locked GPU accounting differs or exceeds ceiling')
        require(read(run / 'shared_neutral_gate_observation.json') == gate,
                'Worker actual neutral observation differs from pinned both-model proof')
        prior = read(run / 'predecessor_observation.json')
        require(prior.get('old_conditions_changed') is False
                and prior.get('old_submitted_jobs_repeated') is False
                and set(prior.get('jobs', {})) == {'246445', '246714'}
                and all(row.get('state') == 'COMPLETED' and row.get('exit_code') == '0:0'
                        for row in prior['jobs'].values()),
                'Original condition preservation/terminal boundary differs')
        preflight = read(run / 'tokenizer_preflight.json')
        require(preflight.get('all_fit') is True and preflight.get('case_count') == 279
                and preflight.get('inputs_not_truncated') is True
                and preflight.get('output_budget') == 16384 and preflight.get('context_limit') == 65536,
                'Complete native-input tokenizer preflight missing')
        summary = driver.summarize(predictions, 279, 279)
        for name, value in summary.items():
            if name not in {'at_pacific', 'role'}:
                require(done.get(name) == value, 'Complete delivery telemetry differs from actual sealed responses')
        require(done['planned'] == done['request_claims'] == done['attempted_confirmed']
                == done['responses_saved'] == done['terminal'] == 279
                and done['ambiguous_without_raw_response'] == done['not_dispatched'] == 0,
                'Raw response delivery is not a complete 279-case model condition')
        for row, prediction in zip(locked['rows'], predictions):
            require(prediction.get('job_id') == job and read(run / row['request_path']).get('job_id') == job,
                    'Sealed case belongs to another model allocation')
            for field in ['request', 'response']:
                export_pins[str(run / row[field + '_path'])] = row[field + '_sha256']
        stored_model = scores['models'][key]
        require(stored_model.get('model') == plan['models'][key]['name']
                and stored_model.get('revision') == plan['models'][key]['revision'],
                'Native score model identity changed')
        per_case = read(score_root / (key + '.per_case_scores.json'))
        tasks = check_per_case(inputs, predictions, per_case, stored_model['per_task'])
        models[key] = {'name': plan['models'][key]['name'], 'revision': plan['models'][key]['revision'],
                       'run_id': plan['models'][key]['run_id'], 'job_id': job, 'planned': 279,
                       'responses_saved': 279, 'finished_at_pacific': done['at_pacific'],
                       **{name: done[name] for name in ['truncations', 'empty_finals', 'response_errors',
                          'transport_errors', 'http_errors', 'runtime_exceptions', 'refusals', 'finish_reasons']},
                       'completion_sha256': sha(run / 'completion.json'), 'tasks': tasks}
    require(seals == scores.get('prediction_seals') == complete.get('both_prediction_seals') == attempt.get('seals'),
            'Scoring completion/attempt and both actual prediction seals differ')
    for path, digest in {**plan['pins'], **export_pins}.items():
        require(sha(path) == digest, 'Source or sealed result changed during read-only audit')
    for path, digest in observed.items():
        require(hashlib.sha256(regular(path).read_bytes()).hexdigest() == digest,
                'Parsed result/source snapshot changed before audit completed')
    return {'role': 'read_only_recommended_sampling_full_LAB_Bench_pair_result_audit', 'passed': True,
            'at_pacific': datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
            'condition': plan['condition'], 'plan_sha256': PLAN_SHA, 'grant_sha256': GRANT_SHA,
            'scores_sha256': score_sha, 'scoring_completed_at_pacific': scores['at_pacific'],
            'prediction_seals': seals, 'models': models, 'export_source_pins': export_pins,
            'input_sha256': INPUT_SHA, 'native_scorer_sha256': NATIVE_SHA,
            'shared_contract_sha256': CONTRACT_SHA, 'actual_neutral_receipt_sha256': gate['receipt_sha256'],
            'recorded_GPU_audits_verified_without_public_inventory_export': True,
            'full_native_denominators_preserved': True, 'native_scoring_reexecuted': False,
            'correctness_from_completed_native_score_not_recomputed': True,
            'scorer_reference_rows_read_by_auditor': False, 'new_inference_calls': 0, 'model_forwards': 0,
            'original_condition_preserved': True, 'original_plan_sha256': plan['original_condition']['sha256'],
            'historical_catalog_denominator_changed': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-scores-sha256')
    args = parser.parse_args()
    print(json.dumps(audit(args.expected_scores_sha256), indent=2))
