"""Future local export of sealed new-condition results; no scoring/publication."""
from datetime import datetime
from pathlib import Path
from string import Template
from zoneinfo import ZoneInfo
import argparse
import gzip
import hashlib
import io
import json
import os
import tarfile

from audit_result import audit, HERE, LANE, PAIR, ROOT, PLAN_SHA, GRANT_SHA, require, regular, sha, read

GROUP = 'qwen35_4b_labbench_reviewed279_author_general_thinking16k_20261022_v2'
REPORT_STEM = 'QWEN35_4B_LABBENCH_RECOMMENDED_SAMPLING_RESULTS_2026-10-22'
MAX_FILE_BYTES = 95 * 1024 * 1024
SHARED_DOCS = {'README.md', 'reports/RESULTS_AND_REMAINING_WORK.md',
               'reports/ENGINEERING_PROGRESS.md', 'reports/ENGINEERING_PROGRESS.json'}


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()


def save_bytes(path, raw):
    path = Path(path)
    require(path == path.resolve() and not path.is_symlink(), 'Exact new export path required')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())


def save(path, value):
    save_bytes(path, encode(value))


def archive(path, files):
    """Deterministic allowlisted archive with hashes of the bytes actually added."""
    path = Path(path)
    require(not path.exists(), 'Preserve any prior package attempt')
    path.parent.mkdir(parents=True, exist_ok=True)
    members = {}
    with path.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|') as handle:
                for name, record in sorted(files.items()):
                    require(not Path(name).is_absolute() and '..' not in Path(name).parts
                            and Path(name).as_posix() == name,
                            'Archive member escapes explicit relative allowlist')
                    source = regular(record['path'])
                    raw = source.read_bytes()
                    digest = hashlib.sha256(raw).hexdigest()
                    require(digest == record['sha256'], 'Reviewed source bytes changed before archive addition')
                    info = tarfile.TarInfo(name)
                    info.size, info.mtime, info.mode = len(raw), 0, 0o644
                    handle.addfile(info, io.BytesIO(raw))
                    members[name] = {'sha256': digest, 'bytes': len(raw)}
        output.flush()
        os.fsync(output.fileno())
    require(path.stat().st_size < MAX_FILE_BYTES, 'Archive exceeds reviewed publication size limit')
    for name, record in files.items():
        require(sha(record['path']) == members[name]['sha256'], 'Source changed during archive construction')
    return members


def public_submission(source, source_sha):
    """Preserve provenance while excluding unrelated account inventory/environment."""
    raw = regular(source).read_bytes()
    require(hashlib.sha256(raw).hexdigest() == source_sha, 'Original private submission receipt changed')
    record = json.loads(raw)
    fields = ['stage', 'job_id', 'model_key', 'plan_sha256', 'grant_sha256', 'sbatch_invoked',
              'returncode', 'requested_gpu_count']
    result = {name: record[name] for name in fields if name in record}
    result.update(role='allowlisted_public_submission_provenance',
                  private_original_sha256=source_sha, public_redaction_applied=True,
                  unrelated_account_job_inventory_included=False,
                  private_stdout_stderr_included=False)
    audit_value = record.get('gpu_audit', {})
    result['GPU_accounting'] = {name: audit_value[name] for name in
                              ['project_GPU_ceiling', 'project_requested_GPUs',
                               'project_requested_GPUs_with_addition', 'additional_GPUs_reviewed']
                              if name in audit_value}
    result['actual_both_model_neutral_proof'] = record['actual_both_model_neutral_proof']
    result['predecessors'] = record['predecessors']
    return result


def metrics_cell(model, task):
    metrics = model['tasks'][task]['metrics']
    return (f"**{100 * metrics['accuracy']:.2f}%** accuracy ({metrics['n_correct']}/{metrics['n_total']})"
            f"<br>Precision {100 * metrics['precision']:.2f}%; coverage {100 * metrics['coverage']:.2f}%")


def render_report(checked, trajectories, protocol_path, scores_path, audit_path):
    base, post = checked['models']['base'], checked['models']['posttrained']
    moment = datetime.fromisoformat(checked['scoring_completed_at_pacific']).astimezone(ZoneInfo('America/Los_Angeles'))
    errors = ['transport_errors', 'http_errors', 'runtime_exceptions', 'refusals']
    labels = {'transport_errors': 'transport errors', 'http_errors': 'HTTP errors',
              'runtime_exceptions': 'runtime exceptions', 'refusals': 'recorded refusals'}
    if all(model[name] == 0 for model in [base, post] for name in errors):
        error_text = 'Transport errors, HTTP errors, runtime exceptions and recorded refusals were zero in both runs.'
    else:
        error_text = 'Delivery counts: ' + '; '.join(
            label + ': ' + ', '.join(f'{model_name} {model[name]}' for model_name, model in [('Base', base), ('posttrained', post)])
            for name, label in labels.items()) + '.'
    diagnostics = []
    for task, label in [('B01', 'LitQA2'), ('B03', 'SuppQA')]:
        fragments = []
        for name, model in [('Base', base), ('posttrained 4B', post)]:
            d = model['tasks'][task]['diagnostics']
            fragments.append(f"{name}: {d['parsed']}/{TASK_TOTALS[task]} parsed, {d['truncated']} truncated, {d['empty_final']} empty finals")
        diagnostics.append(label + ' — ' + '; '.join(fragments) + '.')
    values = {'scoring_completed_pacific': moment.strftime('%B %-d, %Y at %-I:%M %p %Z'),
              'base_litqa_metrics': metrics_cell(base, 'B01'), 'posttrained_litqa_metrics': metrics_cell(post, 'B01'),
              'base_suppqa_metrics': metrics_cell(base, 'B03'), 'posttrained_suppqa_metrics': metrics_cell(post, 'B03'),
              'base_truncations': base['truncations'], 'base_empty_finals': base['empty_finals'],
              'posttrained_truncations': post['truncations'], 'posttrained_empty_finals': post['empty_finals'],
              'delivery_errors_sentence': error_text, 'task_diagnostics': '\n\n'.join(diagnostics),
              'base_job': base['job_id'], 'posttrained_job': post['job_id'], 'plan_sha256': PLAN_SHA,
              'report_json_name': REPORT_STEM + '.json', 'scores_path': scores_path, 'audit_path': audit_path,
              'protocol_path': protocol_path,
              **{key + '_trajectory_path': value['path'] for key, value in trajectories.items()},
              **{key + '_manifest_path': value['manifest_path'] for key, value in trajectories.items()}}
    return Template((HERE / 'report.template.md').read_text()).substitute(values)


TASK_TOTALS = {'B01': 197, 'B03': 82}


def protocol_sources(plan):
    # This list intentionally excludes references, weights, runtime archives,
    # raw allocation inventories, legacy candidate trees and unrelated sources.
    protocol_files = {}
    neutral_record = plan['neutral_validation']['plan']
    require(sha(neutral_record['path']) == neutral_record['sha256'], 'Admitted artificial gate plan changed')
    neutral_plan = read(neutral_record['path'])
    transitive_pins = {**neutral_plan['pins'], **plan['pins']}
    grant = read(LANE / 'independent_grant.json')
    neutral_grant = read(PAIR / 'recommended_sampling_v2/neutral_grant.json')

    def protocol_record(source):
        path = str(source)
        fixed = {str(LANE / 'plan.json'): PLAN_SHA,
                 str(LANE / 'independent_grant.json'): GRANT_SHA,
                 str(LANE / 'independent_review.json'): grant['independent_review_sha256'],
                 str(PAIR / 'recommended_sampling_v2/independent_review.json'):
                     neutral_grant['independent_review_sha256']}
        digest = transitive_pins.get(path, fixed.get(path))
        require(digest is not None and sha(source) == digest,
                'Protocol source is not bound by the admitted scientific/gate provenance')
        return {'path': path, 'sha256': digest}

    for name in ['plan.json', 'independent_grant.json', 'independent_review.json', 'guards.py', 'worker.py',
                 'submit.py', 'worker.sbatch', 'driver.py', 'score.py', 'native_scoring_v2.py',
                 'test_controls.py', 'test_driver.py', 'test_native_scoring_v2.py', 'README.md']:
        source = LANE / name
        protocol_files['labbench/recommended_sampling_v2/' + name] = protocol_record(source)
    for name in ['shared_runtime.py', 'shared_contract.json', 'neutral_proof.py', 'test_neutral_proof.py',
                 'neutral_grant.json', 'independent_review.json', 'actual_neutral_proof.json',
                 'neutral_validation/plan.json', 'neutral_validation/receipt.json', 'neutral_validation/fixtures.py']:
        source = PAIR / 'recommended_sampling_v2' / name
        protocol_files['recommended_sampling_v2/' + name] = protocol_record(source)
    for name in ['root_scope.json', 'engineering_delegation.json', 'root_recommended_sampling_repair_decision_20261022.json',
                 'labbench/input_manifest.json', 'labbench/independent_preparation_review.json']:
        source = PAIR / name
        protocol_files[name] = protocol_record(source)
    for name in ['audit_result.py', 'build_package.py', 'publish.py', 'report.template.md', 'test_package.py', 'README.md']:
        source = HERE / name
        protocol_files['posthoc_result_export/' + name] = {'path': str(source), 'sha256': sha(source)}
    return protocol_files


def build(expected_scores_sha256):
    # This readiness audit is deliberately first: partial runtime evidence may
    # not create reports, final metrics, archive manifests or package claims.
    checked = audit(expected_scores_sha256)
    require(checked.get('passed') is True and checked['scores_sha256'] == expected_scores_sha256,
            'Exact read-only closed-result audit required')
    plan = read(LANE / 'plan.json')
    out = ROOT / 'results/runs' / GROUP
    report_json = ROOT / 'reports' / (REPORT_STEM + '.json')
    report_md = ROOT / 'reports' / (REPORT_STEM + '.md')
    require(not out.exists() and not report_json.exists() and not report_md.exists()
            and not (HERE / 'package_paths.json').exists(), 'Preserve previous package and original condition')
    source_pins = checked['export_source_pins']
    protocol_files = protocol_sources(plan)
    # Preflight all immutable sources and renderable report fields before the
    # first export write, so a missing transitive pin cannot leave half a package.
    for path, digest in source_pins.items():
        require(sha(path) == digest, 'Sealed result source changed before export')
    planned_trajectories = {key: {
        'path': 'results/trajectory_archives/' + plan['models'][key]['run_id'] + '.tar.gz',
        'manifest_path': 'results/trajectory_archives/' + plan['models'][key]['run_id'] + '.tar.manifest.json'}
        for key in ['base', 'posttrained']}
    render_report(checked, planned_trajectories,
                  'results/protocol_artifacts/' + GROUP + '.tar.gz',
                  (out / 'scores.json').relative_to(ROOT).as_posix(),
                  (out / 'result_audit.json').relative_to(ROOT).as_posix())
    public_records = {key: public_submission(Path(plan['models'][key]['runtime']) / 'submission_receipt.json',
                        source_pins[str(Path(plan['models'][key]['runtime']) / 'submission_receipt.json')])
                      for key in ['base', 'posttrained']}
    paths, trajectories = [], {}
    for key in ['base', 'posttrained']:
        run = Path(plan['models'][key]['runtime'])
        run_id = plan['models'][key]['run_id']
        allow = ['started.json', 'completion.json', 'prediction_lock.json', 'tokenizer_preflight.json',
                 'worker_started.json', 'worker_terminal.json', 'shared_neutral_gate_observation.json',
                 'model_completed.json', 'predecessor_observation.json']
        files = {name: {'path': str(run / name), 'sha256': source_pins[str(run / name)]} for name in allow}
        for row in read(run / 'prediction_lock.json')['rows']:
            for name in [row['request_path'], row['response_path']]:
                files[name] = {'path': str(run / name), 'sha256': source_pins[str(run / name)]}
        public = out / 'public_operational_records' / (key + '.submission_receipt.json')
        save(public, public_records[key])
        files['operational/submission_receipt.public.json'] = {'path': str(public), 'sha256': sha(public)}
        dest = ROOT / 'results/trajectory_archives' / (run_id + '.tar.gz')
        manifest = dest.with_suffix('.manifest.json')
        members = archive(dest, files)
        save(manifest, {'role': 'complete_approved_recommended_sampling_LAB_Bench_model_trajectory_archive',
             'model_key': key, 'run_id': run_id, 'model': plan['models'][key]['name'],
             'model_revision': plan['models'][key]['revision'], 'scientific_plan_sha256': PLAN_SHA,
             'planned': 279, 'responses_saved': 279, 'prediction_lock_sha256': checked['prediction_seals'][key]['sha256'],
             'archive_sha256': sha(dest), 'members': members, 'member_count': len(members),
             'scorer_references_included': False, 'model_weights_included': False, 'credentials_included': False,
             'private_runtime_environment_included': False, 'private_GPU_account_inventory_included': False,
             'held_cases_included': False, 'original_condition_changed': False})
        trajectories[key] = {'path': dest.relative_to(ROOT).as_posix(), 'sha256': sha(dest),
                             'manifest_path': manifest.relative_to(ROOT).as_posix(),
                             'manifest_sha256': sha(manifest), 'bytes': dest.stat().st_size}
        paths.extend([public.relative_to(ROOT).as_posix(), dest.relative_to(ROOT).as_posix(), manifest.relative_to(ROOT).as_posix()])
    score_root = Path(plan['score_runtime'])
    for name in ['scores.json', 'completion.json', 'attempt_001.json',
                 'base.per_case_scores.json', 'posttrained.per_case_scores.json']:
        source = score_root / name
        require(sha(source) == source_pins[str(source)], 'Native closed score bytes changed')
        save_bytes(out / name, source.read_bytes())
        paths.append((out / name).relative_to(ROOT).as_posix())
    save(out / 'result_audit.json', checked)
    paths.append((out / 'result_audit.json').relative_to(ROOT).as_posix())
    protocol = ROOT / 'results/protocol_artifacts' / (GROUP + '.tar.gz')
    protocol_manifest = protocol.with_suffix('.manifest.json')
    members = archive(protocol, protocol_files)
    save(protocol_manifest, {'role': 'frozen_recommended_sampling_protocol_and_native_scoring_source',
         'scientific_plan_sha256': PLAN_SHA, 'runtime_grant_sha256': GRANT_SHA, 'archive_sha256': sha(protocol),
         'members': members, 'member_count': len(members), 'scorer_reference_values_included': False,
         'model_weights_included': False, 'credentials_included': False, 'runtime_archives_included': False,
         'private_GPU_account_inventory_included': False, 'original_condition_changed': False})
    paths.extend([protocol.relative_to(ROOT).as_posix(), protocol_manifest.relative_to(ROOT).as_posix()])
    summary = {**checked, 'trajectories': trajectories, 'protocol_archive': {
               'path': protocol.relative_to(ROOT).as_posix(), 'sha256': sha(protocol),
               'manifest_path': protocol_manifest.relative_to(ROOT).as_posix()},
               'benchmark': 'LAB-Bench', 'release_year': 2024, 'input_modality': 'text',
               'generation_recipe': plan['generation'], 'recipe_qualification': plan['generation_recipe_qualification'],
               'held_LitQA2_cases_excluded': 2, 'biological_explanation_correctness_assessed': False}
    save(report_json, summary)
    save_bytes(report_md, render_report(checked, trajectories, protocol.relative_to(ROOT).as_posix(),
               (out / 'scores.json').relative_to(ROOT).as_posix(),
               (out / 'result_audit.json').relative_to(ROOT).as_posix()).encode())
    paths.extend([report_json.relative_to(ROOT).as_posix(), report_md.relative_to(ROOT).as_posix()])
    save_bytes(out / 'README.md', ('# Matched Qwen3.5-4B LAB-Bench author general-thinking recipe\n\n'
        '[Results and qualifications](../../../reports/' + REPORT_STEM + '.md) · [Native paired scores](scores.json)\n\n'
        'Complete reviewed set: 197 LitQA2 and 82 SuppQA questions per model. Both prediction sets sealed before one native scoring attempt. '
        'All invalid/truncated cases remain in the denominator. This export made no model or scoring calls and preserves the original condition.\n').encode())
    paths.append((out / 'README.md').relative_to(ROOT).as_posix())
    require(not SHARED_DOCS.intersection(paths), 'Shared documents excluded from narrow result export')
    for path, digest in source_pins.items():
        require(sha(path) == digest, 'Sealed source changed before package finished')
    require(sha(LANE / 'plan.json') == PLAN_SHA and sha(LANE / 'independent_grant.json') == GRANT_SHA,
            'Admitted scientific provenance changed during export')
    package = {'role': 'narrow_recommended_sampling_paired_LAB_Bench_result_package',
               'at_pacific': datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
               'paths_sha256': {name: sha(ROOT / name) for name in sorted(paths)},
               'trajectory_archives': trajectories, 'scientific_plan_sha256': PLAN_SHA,
               'scores_sha256': checked['scores_sha256'], 'new_model_calls': 0, 'new_scoring_attempts': 0,
               'publication_performed': False, 'shared_docs_included': False,
               'secret_and_archive_scan_status': 'required_by_independently_reviewed_publisher_before_upload',
               'credentials_or_weights_included': False, 'original_condition_changed': False}
    save(HERE / 'package_paths.json', package)
    return package


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-scores-sha256', required=True)
    args = parser.parse_args()
    result = build(args.expected_scores_sha256)
    print(json.dumps({'prepared_paths': len(result['paths_sha256']),
                      'package_paths_sha256': sha(HERE / 'package_paths.json'), 'publication_performed': False}))
