"""Artificial package/audit controls; no real scores, models or publication."""
from pathlib import Path
from unittest import mock
import ast
import copy
import hashlib
import json
import tarfile
import tempfile
import unittest

import audit_result as auditor
import build_package as builder
import publish as publisher


class ReadinessTests(unittest.TestCase):
    def test_altered_helper_cannot_execute_before_hash_check(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder); marker = root / 'executed'
            source = root / 'bad_helper.py'
            source.write_text('from pathlib import Path\nPath(' + repr(str(marker)) + ').touch()\n')
            with self.assertRaises(ValueError): auditor.pinned_module(source, 'wrong_sha', 'never_execute')
            self.assertFalse(marker.exists())

    def test_protocol_fixture_digest_follows_the_admitted_neutral_plan(self):
        plan = auditor.read(auditor.LANE / 'plan.json')
        sources = builder.protocol_sources(plan)
        fixture = sources['recommended_sampling_v2/neutral_validation/fixtures.py']
        neutral = auditor.read(plan['neutral_validation']['plan']['path'])
        self.assertEqual(fixture['sha256'], neutral['pins'][fixture['path']])

    def test_partial_model_responses_do_not_satisfy_complete_readiness(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for key in ['base', 'posttrained']:
                (root / key).mkdir()
                (root / key / 'progress.json').write_text('{"responses_saved":16}')
            plan = {'score_runtime': str(root / 'scores'),
                    'models': {k: {'runtime': str(root / k)} for k in ['base', 'posttrained']}}
            with self.assertRaises(auditor.NotReadyError): auditor.require_ready(plan)

    def test_builder_creates_no_final_artifact_before_closed_audit(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            with mock.patch.object(builder, 'ROOT', root), mock.patch.object(builder, 'HERE', root):
                with mock.patch.object(builder, 'audit', side_effect=auditor.NotReadyError('Artificial incomplete gate')):
                    with self.assertRaises(auditor.NotReadyError): builder.build('unknown_not_zero')
            self.assertEqual(list(root.iterdir()), [])

    def test_auditor_never_calls_score_entrypoint_or_external_process(self):
        for name in ['audit_result.py', 'build_package.py']:
            tree = ast.parse((Path(__file__).parent / name).read_text())
            forbidden = []
            for node in ast.walk(tree):
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                    if node.func.attr in {'score', 'create_session', 'generate_prepared', 'conservative_project_gpu_audit'}:
                        forbidden.append(node.func.attr)
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    modules = [a.name for a in node.names] if isinstance(node, ast.Import) else [node.module or '']
                    self.assertFalse(any(m.split('.')[0] in {'subprocess', 'requests', 'torch', 'vllm'} for m in modules))
            self.assertEqual(forbidden, [])


class NativeArithmeticTests(unittest.TestCase):
    def data(self, abstain=False):
        inputs, predictions, per_case = [], [], []
        for index in range(2):
            inputs.append({'task_id': 'B01', 'case_id': f'synthetic_{index}'})
            final = 'E' if abstain else ('A' if index == 0 else '')
            response = {'final_text': final, 'truncated': not abstain and index == 1,
                        'response_error': not abstain and index == 1,
                        'transport_error': False, 'http_error': False, 'not_dispatched': False, 'refusal': False}
            predictions.append(response)
            per_case.append({**inputs[-1], 'answer': 'E' if abstain else ('A' if index == 0 else None),
                             'correct': not abstain and index == 0, 'sure': not abstain,
                             'parsed': abstain or index == 0, 'empty_final': not final,
                             **{n: response[n] for n in ['truncated', 'response_error', 'transport_error',
                                'http_error', 'not_dispatched', 'refusal']}})
        metrics = {'accuracy': 0.0 if abstain else 0.5, 'precision': 0.0 if abstain else 0.5,
                   'coverage': 0.0 if abstain else 1.0, 'n_total': 2,
                   'n_correct': 0 if abstain else 1, 'n_sure': 0 if abstain else 2}
        diagnostics = {'parsed': 2 if abstain else 1, 'empty_final': 0 if abstain else 1,
                       'truncated': 0 if abstain else 1, 'transport_error': 0, 'http_error': 0,
                       'response_error': 0 if abstain else 1, 'not_dispatched': 0, 'refusal': 0,
                       'invalid_outputs': 0 if abstain else 1}
        return inputs, predictions, per_case, {'B01': {'metrics': metrics, 'diagnostics': diagnostics}}

    def test_invalid_case_remains_in_denominator_and_native_coverage(self):
        result = auditor.check_per_case(*self.data(), task_counts={'B01': 2})
        self.assertEqual(result['B01']['metrics']['coverage'], 1.0)
        self.assertEqual(result['B01']['metrics']['accuracy'], 0.5)

    def test_native_zero_sure_precision_is_zero_not_undefined(self):
        result = auditor.check_per_case(*self.data(abstain=True), task_counts={'B01': 2})
        self.assertEqual(result['B01']['metrics']['precision'], 0.0)

    def test_reordered_scoring_rows_are_rejected(self):
        inputs, predictions, rows, stored = self.data(); rows.reverse()
        with self.assertRaises(ValueError): auditor.check_per_case(inputs, predictions, rows, stored, {'B01': 2})

    def test_missing_invalid_case_cannot_raise_accuracy(self):
        inputs, predictions, rows, stored = self.data(); rows.pop()
        with self.assertRaises(ValueError): auditor.check_per_case(inputs, predictions, rows, stored, {'B01': 2})

    def test_favorable_aggregate_not_matching_stored_cases_is_rejected(self):
        data = self.data(); data[3]['B01']['metrics']['accuracy'] = 1.0
        with self.assertRaises(ValueError): auditor.check_per_case(*data, task_counts={'B01': 2})

    def test_truncation_diagnostic_cannot_be_removed(self):
        data = self.data(); data[2][1]['truncated'] = False
        with self.assertRaises(ValueError): auditor.check_per_case(*data, task_counts={'B01': 2})


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'raw.json'
        self.source.write_bytes(b'{"synthetic_raw":"complete bytes preserved"}\n')
        self.record = {'path': str(self.source), 'sha256': builder.sha(self.source)}

    def test_manifest_hashes_exact_archived_member_bytes(self):
        dest = self.root / 'trajectory.tar.gz'
        members = builder.archive(dest, {'cases/000000/response.json': self.record})
        with tarfile.open(dest) as archive:
            raw = archive.extractfile('cases/000000/response.json').read()
        self.assertEqual(raw, self.source.read_bytes())
        self.assertEqual(members['cases/000000/response.json']['sha256'], hashlib.sha256(raw).hexdigest())

    def test_archive_is_deterministic_for_identical_source_bytes(self):
        one, two = self.root / 'one.tar.gz', self.root / 'two.tar.gz'
        builder.archive(one, {'source.json': self.record}); builder.archive(two, {'source.json': self.record})
        self.assertEqual(one.read_bytes(), two.read_bytes())

    def test_changed_source_cannot_be_exported_under_old_hash(self):
        self.source.write_bytes(b'changed')
        with self.assertRaises(ValueError): builder.archive(self.root / 'bad.tar.gz', {'source.json': self.record})

    def test_source_mutation_during_archive_is_rejected(self):
        original = tarfile.TarFile.addfile
        def mutate(handle, info, fileobj=None):
            result = original(handle, info, fileobj)
            self.source.write_bytes(b'changed after capture')
            return result
        with mock.patch.object(tarfile.TarFile, 'addfile', mutate):
            with self.assertRaises(ValueError): builder.archive(self.root / 'bad.tar.gz', {'source.json': self.record})

    def test_symlink_source_is_rejected(self):
        alias = self.root / 'alias'; alias.symlink_to(self.source)
        with self.assertRaises(ValueError): builder.archive(self.root / 'bad.tar.gz', {'source.json': {**self.record, 'path': str(alias)}})

    def test_member_path_escape_is_rejected(self):
        for name in ['/absolute', '../escape', 'cases/../../escape']:
            with self.subTest(name=name):
                dest = self.root / (str(abs(hash(name))) + '.tar.gz')
                with self.assertRaises(ValueError): builder.archive(dest, {name: self.record})

    def test_previous_artifact_is_never_overwritten(self):
        dest = self.root / 'old.tar.gz'; dest.write_bytes(b'old immutable content')
        with self.assertRaises(ValueError): builder.archive(dest, {'source.json': self.record})
        self.assertEqual(dest.read_bytes(), b'old immutable content')

    def test_public_operational_provenance_excludes_private_account_inventory(self):
        record = {'stage': 'submitted_not_model_dispatch_evidence', 'job_id': '999000',
                  'model_key': 'base', 'plan_sha256': 'synthetic', 'grant_sha256': 'synthetic',
                  'requested_gpu_count': 1, 'sbatch_invoked': True, 'returncode': 0,
                  'stdout': 'PRIVATE_STDOUT_CANARY', 'stderr': 'PRIVATE_STDERR_CANARY',
                  'gpu_audit': {'jobs': ['PRIVATE_ACCOUNT_CANARY'], 'project_GPU_ceiling': 8,
                                'project_requested_GPUs': 2, 'project_requested_GPUs_with_addition': 3},
                  'environment': {'API_KEY': 'PRIVATE_SECRET_CANARY'},
                  'actual_both_model_neutral_proof': {'passed': True},
                  'predecessors': {'old_conditions_changed': False}}
        self.source.write_text(json.dumps(record))
        result = builder.public_submission(self.source, builder.sha(self.source))
        raw = builder.encode(result)
        for value in [b'PRIVATE_STDOUT_CANARY', b'PRIVATE_STDERR_CANARY', b'PRIVATE_ACCOUNT_CANARY', b'PRIVATE_SECRET_CANARY']:
            self.assertNotIn(value, raw)
        self.assertEqual(result['private_original_sha256'], builder.sha(self.source))
        self.assertEqual(result['job_id'], '999000')


class PublicationBoundaryTests(unittest.TestCase):
    def plan(self):
        return {'models': {key: {'run_id': 'synthetic_new_' + key} for key in ['base', 'posttrained']}}

    def test_only_exact_separate17_paths_are_accepted(self):
        paths = {name: 'synthetic_hash' for name in publisher.expected_paths(self.plan())}
        self.assertEqual(len(paths), 17)
        self.assertEqual(set(publisher.validate_paths({'paths_sha256': paths}, {'paths_sha256': paths}, self.plan())), set(paths))
        self.assertTrue(all('QWEN35_4B_LABBENCH_RESULTS_2026-10-22' not in name for name in paths))

    def test_git_credential_helper_source_is_explicitly_pinned(self):
        name = '.local/litqa2_replay/github_credential_helper.py'
        self.assertEqual(publisher.SUPPORT_PINS[name], auditor.sha(auditor.ROOT / name))

    def test_shared_document_injection_is_rejected(self):
        paths = {name: 'synthetic_hash' for name in publisher.expected_paths(self.plan())}
        paths['reports/RESULTS_AND_REMAINING_WORK.md'] = 'synthetic_hash'
        with self.assertRaises(ValueError): publisher.validate_paths({'paths_sha256': paths}, {'paths_sha256': paths}, self.plan())

    def test_original_result_path_injection_is_rejected(self):
        paths = {name: 'synthetic_hash' for name in publisher.expected_paths(self.plan())}
        paths['reports/QWEN35_4B_LABBENCH_RESULTS_2026-10-22.md'] = 'synthetic_hash'
        with self.assertRaises(ValueError): publisher.validate_paths({'paths_sha256': paths}, {'paths_sha256': paths}, self.plan())

    def test_no_candidate_or_review_cannot_reach_git_or_network(self):
        with tempfile.TemporaryDirectory() as folder:
            with mock.patch.object(publisher, 'HERE', Path(folder)), mock.patch.object(publisher, 'pinned_module') as load:
                with mock.patch.object(publisher.subprocess, 'run') as run:
                    with self.assertRaises(ValueError): publisher.main()
                    load.assert_not_called(); run.assert_not_called()

    def test_unissued_review_cannot_authorize_publication(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / 'publication_candidate.json').write_text(json.dumps({'scores_sha256': '0' * 64}))
            (root / 'independent_result_publication_review.json').write_text(json.dumps({
                'review_passed': False, 'reviewer': '/root/independent_review'}))
            with mock.patch.object(publisher, 'HERE', root), mock.patch.object(publisher, 'pinned_module') as load:
                with mock.patch.object(publisher.subprocess, 'run') as run:
                    with self.assertRaises(ValueError): publisher.main()
                    load.assert_not_called(); run.assert_not_called()

    def test_runtime_grant_cannot_substitute_artifact_publication_review(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / 'publication_candidate.json').write_text(json.dumps({'scores_sha256': '0' * 64}))
            grant = auditor.read(auditor.LANE / 'independent_grant.json')
            (root / 'independent_result_publication_review.json').write_text(json.dumps(grant))
            with mock.patch.object(publisher, 'HERE', root), mock.patch.object(publisher, 'pinned_module') as load:
                with mock.patch.object(publisher.subprocess, 'run') as run:
                    with self.assertRaises(ValueError): publisher.main()
                    load.assert_not_called(); run.assert_not_called()


if __name__ == '__main__':
    unittest.main()
