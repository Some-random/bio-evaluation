"""Future narrow publisher; requires exact completed payload and independent review."""
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import fcntl
import hashlib
import json
import os
import re
import subprocess
import tempfile

from audit_result import audit, HERE, LANE, ROOT, PLAN_SHA, GRANT_SHA, require, regular, sha, read, pinned_module
from build_package import GROUP, REPORT_STEM, MAX_FILE_BYTES, SHARED_DOCS

OWNER = '/root/qwen35_labbench'
SUPPORT_PINS = {
    '.local/litqa2_replay/incremental_upload.py': '194f143fa81d2409c3f72403c5664f7f9c64b9ca3cc46af9603de0d044cf0160',
    '.local/litqa2_replay/github_credential_helper.py': '45a94c6e738c987277f252bb5177e0d1b7b35ce8ea17d438b358f802442192cb',
    'scripts/daily_backup.py': '528735e220dd6a2b5ab3d5b6b51ec7143b5ffa891fdfcfc211d2a8099ce7093d',
    'scripts/publication_destination.py': '7af9309f3b860b69301abae590a6c9ac4f03c1d81a6b3269b86fc077b6a10f4a',
    'configs/publication_destination.json': '7e3e1cac0321a64aa9bd53daf0e47891f7ca0ce04d3df9c3764d99129f1680d0',
}


def write_once(path, value):
    with Path(path).open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
    fd = os.open(Path(path).parent, os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def expected_paths(plan):
    out = 'results/runs/' + GROUP + '/'
    paths = {'reports/' + REPORT_STEM + suffix for suffix in ['.md', '.json']}
    paths.update(out + name for name in ['README.md', 'scores.json', 'completion.json', 'attempt_001.json',
                 'base.per_case_scores.json', 'posttrained.per_case_scores.json', 'result_audit.json'])
    for key in ['base', 'posttrained']:
        paths.add(out + 'public_operational_records/' + key + '.submission_receipt.json')
        prefix = 'results/trajectory_archives/' + plan['models'][key]['run_id']
        paths.update(prefix + suffix for suffix in ['.tar.gz', '.tar.manifest.json'])
    prefix = 'results/protocol_artifacts/' + GROUP
    paths.update(prefix + suffix for suffix in ['.tar.gz', '.tar.manifest.json'])
    return paths


def validate_paths(candidate, package, plan):
    paths = set(package['paths_sha256'])
    require(paths == set(candidate['paths_sha256']) == expected_paths(plan),
            'Only the exact new-condition17-path result package may publish')
    require(not SHARED_DOCS.intersection(paths), 'Shared documents excluded')
    require(all(not Path(name).is_absolute() and '..' not in Path(name).parts
                and Path(name).as_posix() == name for name in paths), 'Exact relative payload paths required')
    return sorted(paths)


def validate_candidate():
    candidate_path = HERE / 'publication_candidate.json'
    review_path = HERE / 'independent_result_publication_review.json'
    candidate, review = read(candidate_path), read(review_path)
    require(sha(LANE / 'plan.json') == PLAN_SHA and sha(LANE / 'independent_grant.json') == GRANT_SHA,
            'Exact actual scientific plan and runtime grant required')
    plan = read(LANE / 'plan.json')
    decision_row = plan['root_repair_decision']
    require(sha(decision_row['path']) == decision_row['sha256'], 'Root decision changed')
    allowed = read(decision_row['path'])['engineering_delegation']['review_grant_issuers']
    require(review.get('review_passed') is True and review.get('reviewer') in allowed
            and review.get('reviewer') != OWNER
            and review.get('candidate_sha256') == sha(candidate_path)
            and review.get('plan_sha256') == PLAN_SHA
            and review.get('scores_sha256') == candidate.get('scores_sha256'),
            'Later independent exact completed-artifact review required; preparation is not authority')
    require(candidate.get('role') == 'review_candidate_completed_recommended_sampling_LAB_Bench_pair_narrow_publication'
            and candidate.get('scientific_plan_sha256') == PLAN_SHA
            and candidate.get('runtime_grant_sha256') == GRANT_SHA
            and re.fullmatch(r'[0-9a-f]{64}', candidate.get('scores_sha256', ''))
            and candidate.get('publisher_sha256') == sha(Path(__file__).resolve())
            and candidate.get('auditor_sha256') == sha(HERE / 'audit_result.py')
            and candidate.get('builder_sha256') == sha(HERE / 'build_package.py')
            and candidate.get('template_sha256') == sha(HERE / 'report.template.md')
            and candidate.get('support_pins') == SUPPORT_PINS,
            'Exact reviewed new-condition export implementation required')
    for name, digest in SUPPORT_PINS.items():
        require(sha(ROOT / name) == digest, 'Reviewed publication support changed')
    package_path = HERE / 'package_paths.json'
    require(sha(package_path) == candidate.get('package_sha256'), 'Completed package manifest differs')
    package = read(package_path)
    require(package.get('scientific_plan_sha256') == PLAN_SHA
            and package.get('scores_sha256') == candidate['scores_sha256']
            and package.get('original_condition_changed') is False
            and package.get('publication_performed') is False,
            'Exact newly completed local package required')
    paths = validate_paths(candidate, package, plan)
    observed = audit(candidate['scores_sha256'])
    require(observed.get('passed') is True and observed['scores_sha256'] == candidate['scores_sha256'],
            'Complete fresh read-only result audit required')
    scanner = pinned_module(ROOT / 'scripts/daily_backup.py', SUPPORT_PINS['scripts/daily_backup.py'],
                            'labbench_recommended_narrow_archive_secret_scanner')
    raw = {}
    for name in paths:
        path = regular(ROOT / name)
        content = path.read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        require(len(content) < MAX_FILE_BYTES
                and digest == package['paths_sha256'][name] == candidate['paths_sha256'][name],
                'Reviewed payload changed or exceeds size ceiling')
        scanner.scan_file(path)
        require(path.read_bytes() == content, 'Payload changed during secret/archive scan')
        raw[name] = content
    require(sha(candidate_path) == review['candidate_sha256'], 'Candidate changed during validation')
    require(not (HERE / 'publication_attempt.json').exists() and not (HERE / 'publication_receipt.json').exists(),
            'Preserve any prior or ambiguous publication attempt; no automatic retry')
    return candidate, package, review, raw, {
        'candidate_sha256': sha(candidate_path), 'review_sha256': sha(review_path),
        'package_sha256': sha(package_path), 'all_payloads_secret_and_archive_scanned': True}


def main():
    candidate, package, review, raw, verified = validate_candidate()
    helper = pinned_module(ROOT / '.local/litqa2_replay/incremental_upload.py',
                           SUPPORT_PINS['.local/litqa2_replay/incremental_upload.py'],
                           'labbench_recommended_narrow_publication_helper')
    paths = sorted(raw)
    with tempfile.TemporaryDirectory(prefix='bioeval-labbench-author-recipe-publication-') as folder:
        checkout = Path(folder)
        def git(*args): return helper.git(*args, cwd=checkout)
        git('init', '--quiet')
        git('remote', 'add', 'origin', helper.URL)
        git('config', 'remote.origin.promisor', 'true')
        git('config', 'remote.origin.partialclonefilter', 'blob:none')
        git('sparse-checkout', 'init', '--no-cone')
        git('sparse-checkout', 'set', '--no-cone', *('/' + name for name in paths))
        git('config', 'user.name', 'Codex')
        git('config', 'user.email', 'codex@localhost')
        with (ROOT / '.local/evaluation_publication.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            for name, digest in SUPPORT_PINS.items():
                require(sha(ROOT / name) == digest, 'Publication helper changed under shared lock')
            destination = helper.confirm_destination()
            require(destination.get('repository') == 'Some-random/bio-evaluation'
                    and destination.get('visibility') == 'public' and destination.get('push_permission') is True,
                    'Exact public repository identity and push permission required')
            require(sha(HERE / 'publication_candidate.json') == verified['candidate_sha256']
                    and sha(HERE / 'independent_result_publication_review.json') == verified['review_sha256']
                    and sha(HERE / 'package_paths.json') == verified['package_sha256'],
                    'Independent reviewed publication evidence changed')
            git('fetch', '--filter=blob:none', '--depth=1', 'origin', 'main')
            git('checkout', '--detach', 'FETCH_HEAD')
            before = git('rev-parse', 'HEAD').stdout.strip()
            for name, content in raw.items():
                require(regular(ROOT / name).read_bytes() == content, 'Reviewed local payload changed')
                target = checkout / name
                require(target.resolve() == target and target.resolve().is_relative_to(checkout.resolve()),
                        'Remote working-tree path contains a symlink or escape')
                if target.exists():
                    require(not target.is_symlink() and target.is_file() and target.read_bytes() == content,
                            'Existing immutable remote artifact differs; never overwrite')
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
            git('add', '-f', '--sparse', '--', *paths)
            changed = set(git('diff', '--cached', '--name-only').stdout.splitlines())
            require(changed <= set(paths), 'Unexpected staged path outside exact result package')
            git('diff', '--cached', '--check')
            write_once(HERE / 'publication_attempt.json', {
                **verified, 'previous_main_head': before, 'paths_sha256': candidate['paths_sha256'],
                'new_model_calls': 0, 'new_scoring_attempts': 0, 'shared_docs_changed': False,
                'no_automatic_retry_after_attempt': True})
            if changed:
                git('commit', '-m', 'Publish sealed Qwen3.5 4B LAB-Bench author-recipe results and trajectories')
                git('push', 'origin', 'HEAD:refs/heads/main')
            commit = git('rev-parse', 'HEAD').stdout.strip()
            git('fetch', '--filter=blob:none', 'origin', 'main')
            remote_head = git('rev-parse', 'FETCH_HEAD').stdout.strip()
            for name, content in raw.items():
                actual = subprocess.run(['git', 'show', 'FETCH_HEAD:' + name], cwd=checkout,
                                        capture_output=True, check=True).stdout
                require(actual == content, 'Remote published bytes differ: ' + name)
            receipt = {'stage': 'completed_recommended_sampling_LAB_Bench_pair_results_and_trajectories_published',
                       'verified_at_pacific': datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
                       'repository': destination['repository'], 'visibility': destination['visibility'],
                       'commit_sha': commit, 'verified_remote_main_head': remote_head, 'previous_main_head': before,
                       'published_path_count': len(paths), 'changed_path_count': len(changed),
                       'paths_sha256': candidate['paths_sha256'], 'remote_bytes_verified': True,
                       'secret_and_archive_scan_passed': True, 'scientific_plan_sha256': PLAN_SHA,
                       'scores_sha256': candidate['scores_sha256'], 'trajectory_archives': package['trajectory_archives'],
                       'report_url': 'https://github.com/Some-random/bio-evaluation/blob/main/reports/' + REPORT_STEM + '.md',
                       **verified, 'new_model_calls': 0, 'new_scoring_attempts': 0,
                       'shared_docs_changed': False, 'original_condition_changed': False,
                       'website_or_schedule_operations': False}
            write_once(HERE / 'publication_receipt.json', receipt)
            print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
