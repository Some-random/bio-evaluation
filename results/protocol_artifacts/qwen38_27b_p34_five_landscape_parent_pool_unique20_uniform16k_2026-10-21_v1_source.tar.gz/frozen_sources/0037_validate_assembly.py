"""CPU-only exact binding and artificial-token interface checks, no forwards."""
from pathlib import Path
import datetime
import hashlib
import importlib.metadata
import json
import os
import resource
import socket
import sys
import time
from zoneinfo import ZoneInfo

os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_DATASETS_OFFLINE"] = "1"
os.environ["OMP_NUM_THREADS"] = "2"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"
REPO = Path("/dfs/scratch0/dongweij/bio-evaluation")
HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
START = time.monotonic()


def now():
    return datetime.datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def status(stage, **extra):
    value = {"task_id": "P34", "role": "cpu_encoder_binding_not_model_delivery",
             "stage": stage, "updated_at_pacific": now(), "pid": os.getpid(),
             "slurm_job_id": os.environ.get("SLURM_JOB_ID"), "model_forwards": 0,
             "new_inference_calls": 0, "new_gpu_allocations": 0,
             "real_biological_inputs_read": False, "training": False,
             "benchmark_dispatch_ready": False, **extra}
    write_json(HERE / "status.json", value)
    return value


def main():
    started = now()
    status("starting_pinned_cpu_runtime_validation")
    def forbid(*args, **kwargs):
        raise RuntimeError("Network and model forward are forbidden in this preparation")
    socket.create_connection = forbid
    socket.socket.connect = forbid
    import torch
    import transformers
    from runtime_assembly import (assemble_released_runtime, file_sha256,
                                  tokenize_without_forward)
    torch.set_num_threads(2)
    assert str(torch.__version__) == "1.13.1+cpu"
    assert transformers.__version__ == "4.36.1"
    guard = torch.nn.modules.module.register_module_forward_pre_hook(forbid)
    status("verifying_pinned_assets_and_constructing_released_encoder")
    encoder, tokenizer, runtimes, loading, heads, metadata = assemble_released_runtime(
        torch, transformers, REPO, HERE)
    write_json(HERE / "checkpoint_loading_info.json", loading)
    status("comparing_all_bound_encoder_and_head_tensors")
    weight = REPO / ".local/source_acquisition_2026-10-19/evaluators/weights/esm1b_pytorch_model.bin"
    checkpoint = torch.load(weight, map_location="cpu")
    bound, unused_pooler = [], []
    # Transformers reports checkpoint-root names, while the bare EsmModel state
    # uses names relative to that root. Normalize metadata names only.
    missing_relative = {key.removeprefix("esm.") for key in loading["missing_keys"]}
    for key, value in encoder.state_dict().items():
        source_key = "esm." + key
        if source_key not in checkpoint:
            if key.startswith("pooler.") and key in missing_relative:
                unused_pooler.append(key)
                continue
            raise AssertionError("Unexpected encoder tensor absent from source checkpoint: " + key)
        if not torch.equal(value, checkpoint[source_key]):
            raise AssertionError("Encoder learned tensor mismatch: " + key)
        bound.append(key)
    assert bound
    assert missing_relative == set(unused_pooler) == {"pooler.dense.weight", "pooler.dense.bias"}
    assert all(key.startswith("lm_head.") for key in loading["unexpected_keys"])
    if loading["mismatched_keys"] or loading["error_msgs"]:
        raise AssertionError("Checkpoint loader reported schema errors")
    checks = ["pinned_encoder_and_tokenizer_assets_verified",
              "all_checkpoint_backed_encoder_tensor_values_exact",
              "unused_pooler_and_lm_head_keys_accounted_for"]
    head_results = []
    for row in heads:
        name = Path(row["path"]).parent.name
        model = runtimes[name]
        state = torch.load(row["path"], map_location="cpu")
        assert model.esm is encoder and model.esm_tokenizer is tokenizer
        assert all(torch.equal(tensor, state[key]) for key, tensor in model.decoder.state_dict().items())
        assert model.decoder.dense_1.in_features == encoder.config.hidden_size == 1280
        assert model.decoder.dense_4.out_features == 1
        assert model.device == torch.device("cpu")
        assert not model.training and not model.decoder.training and not model.esm.training
        head_results.append({"landscape": name, "bound_tensors": len(state),
                             "all_values_equal_checkpoint": True,
                             "shared_exact_encoder": True, "head_sha256": row["local_sha256"]})
    checks.append("all_five_released_combinations_share_exact_encoder_and_bound_heads")
    assert tokenizer.vocab_size == 33
    assert [tokenizer.cls_token_id, tokenizer.pad_token_id, tokenizer.eos_token_id,
            tokenizer.unk_token_id, tokenizer.mask_token_id] == [0, 1, 2, 3, 32]
    checks.append("native_vocabulary_and_special_token_ids_preserved")
    # Reserved symbols only: no biological sequence or starting-case file is read.
    placeholders = ["<mask>", "<mask> <unk> <mask>"]
    encoded = tokenize_without_forward(tokenizer, placeholders)
    assert encoded["input_ids"].shape == (2, 5)
    assert encoded["attention_mask"].sum(dim=1).tolist() == [3, 5]
    assert encoded["input_ids"][0].tolist() == [0, 32, 2, 1, 1]
    native = tokenizer(list(placeholders), add_special_tokens=True, truncation=True,
                       padding=True, max_length=1024, return_tensors="pt")
    assert set(native) == set(encoded)
    assert all(torch.equal(encoded[key], native[key]) for key in native)
    checks.append("synthetic_reserved_token_batch_matches_released_tokenizer_interface")
    boundary = tokenize_without_forward(tokenizer, [" ".join(["<mask>"] * 1022)])
    assert tuple(boundary["input_ids"].shape) == (1, 1024)
    try:
        tokenize_without_forward(tokenizer, [" ".join(["<mask>"] * 1023)])
    except ValueError:
        pass
    else:
        raise AssertionError("Oversized token input was silently truncated")
    checks.append("native_length_boundary_and_no_silent_truncation_gate")
    assert not torch.cuda.is_initialized()
    assert all(p.device.type == "cpu" for model in runtimes.values() for p in model.parameters())
    guard.remove()
    versions = {name: importlib.metadata.version(name) for name in
                ["torch", "transformers", "tokenizers", "numpy", "huggingface-hub"]}
    result = status("exact_encoder_tokenizer_and_five_heads_bound_synthetic_interface_passed",
                    started_at_pacific=started, finished_at_pacific=now(),
                    checkpoint_sha256=file_sha256(weight), encoder_bound_tensor_count=len(bound),
                    encoder_parameter_count=sum(p.numel() for p in encoder.parameters()),
                    unused_random_pooler_keys=unused_pooler,
                    unused_pooler_explanation="Released forward uses last_hidden_state; pooler parameters are not checkpoint backed and its pooled output does not feed the fitness head. No forward was executed.",
                    checkpoint_unused_keys=loading["unexpected_keys"],
                    head_bindings=head_results, synthetic_checks=checks,
                    synthetic_checks_passed=len(checks), versions=versions,
                    peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                    elapsed_seconds=round(time.monotonic()-START, 3),
                    source_code_sha256={str(path.relative_to(REPO)): file_sha256(path)
                                        for path in [HERE/"runtime_assembly.py", HERE/"validate_assembly.py"]},
                    remaining=["Actual evaluator forward/delivery has not been exercised by this binding-only milestone.",
                               "Permitted starting-case/objective review and real-case input preparation remain incomplete.",
                               "A separately declared Qwen proposal interface must be frozen and tested; chat output does not reproduce the released mutation-probability interface.",
                               "Task-specific admitted development checks and a separately frozen benchmark condition remain pending."],
                    next_action="Validate the prospective proposal interface independently using synthetic nonbiological fixtures, preserving all held scopes and dispatch gates.")
    write_json(HERE / "completion.json", result)
    previous_path = PARENT / "status.json"
    previous = json.loads(previous_path.read_text())
    updated = {**previous, "stage": result["stage"], "updated_at_pacific": now(),
               "encoder_runtime_assembly": result,
               "encoder_binding_completion_path": str((HERE/"completion.json").relative_to(REPO)),
               "encoder_binding_completion_sha256": file_sha256(HERE/"completion.json"),
               "remaining": result["remaining"], "next_action": result["next_action"]}
    write_json(previous_path, updated)
    task_path = PARENT.parent / "status.json"
    task_previous = json.loads(task_path.read_text())
    write_json(task_path, {**task_previous, **updated,
                          "engineering_status_path": str(previous_path.relative_to(REPO))})
    print(json.dumps({"stage": result["stage"], "encoder_bound_tensors": len(bound),
                      "heads": len(head_results), "synthetic_checks": len(checks),
                      "model_forwards": 0, "peak_rss_kib": result["peak_rss_kib"]}, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        import traceback
        status("cpu_runtime_assembly_failed_no_dispatch", error_type=type(exc).__name__, error=str(exc))
        traceback.print_exc()
        raise
