"""Recording clients only: complete native dimensions, invalid deliveries and no retries."""
import hashlib
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch
import p34_runner as r
from bound_request import payload,validate_payload
from unique20_core import AMINO_ACIDS
from worker import evaluator_environment,exact_prompt_token_count
HERE=Path(__file__).resolve().parent
PLAN={'model':{'served_model_name':'Qwen/Qwen3.8-27B'},'evaluator_adapter':str(HERE.parent/'engineering_20261020/evaluator_adapter.py')}


def action_list(parents):
    actions=[]
    for pi,sequence in enumerate(parents):
        for pos,before in enumerate(sequence,1):
            for after in AMINO_ACIDS:
                if before!=after:actions.append(f'P{pi}:{before}{pos}{after}')
                if len(actions)==20:return actions


def envelope(final,reason='stop'):
    return json.dumps({'choices':[{'finish_reason':reason,'message':{'role':'assistant','content':final}}]}).encode()


class RecordingTransport:
    def __init__(self,fail_at=None,failure='malformed'):self.calls=[];self.fail_at=fail_at;self.failure=failure
    def send(self,cid,request):
        index=len(self.calls);self.calls.append((cid,request))
        if index==self.fail_at:
            if self.failure=='transport':raise r.TransportError('artificial network failure')
            if self.failure=='http':raise r.TransportError('artificial HTTP failure',500,b'error')
            if self.failure=='guard':raise ValueError('artificial source-guard failure')
            if self.failure=='truncated':return envelope('nonempty unfinished proposal','length')
            if self.failure=='empty':return envelope(None)
            if self.failure=='invalid_action':return envelope(json.dumps({'proposals':['P0:A1A']*20},separators=(',',':')))
            return b'{not valid JSON'
        parents=json.loads(request['vllm_xargs']['p34_parents'])
        return envelope(json.dumps({'proposals':action_list(parents)},separators=(',',':')))


class RecordingEvaluator:
    def __init__(self,fail_at=None):self.calls=[];self.fail_at=fail_at
    def score(self,request):
        index=len(self.calls);self.calls.append(request)
        if index==self.fail_at:raise RuntimeError('artificial evaluator failure')
        return {'case_id':request['case_id'],'landscape':request['landscape'],'batch_size':4,'device':'artificial',
            'sequence_sha256':[hashlib.sha256(s.encode()).hexdigest() for s in request['sequences']],
            'scores':[float(index+j)/10 for j in range(len(request['sequences']))]}


def artificial_inputs():return [{'landscape':name,'function':'Invented neutral assay','target':'Artificial integration only','sequence':'ACDE'} for name in r.LANDSCAPES]


class ExecutionTests(unittest.TestCase):
    def test_payload_keeps_all_parents_and_exact_public_context_no_fitness(self):
        case={'landscape':'artificial','function':'Public function','target':'Public target'};parents=['ACD']*20
        request=payload(PLAN,case,parents,42);validate_payload(request,case,parents,42,PLAN)
        self.assertEqual(json.loads(request['vllm_xargs']['p34_parents']),parents)
        self.assertNotIn('scores',json.dumps(request));self.assertEqual(request['max_tokens'],16384)
        for field in ('messages','seed','top_k'):
            changed=json.loads(json.dumps(request));changed[field]=None
            with self.assertRaises(ValueError):validate_payload(changed,case,parents,42,PLAN)

    def test_development_is_two_artificial_deliveries_without_evaluator_or_benchmark(self):
        with tempfile.TemporaryDirectory() as d:
            t,e=RecordingTransport(),RecordingEvaluator();c=r.run(PLAN,Path(d)/'dev',[],t,e,True)
            self.assertTrue(c['all_delivered']);self.assertTrue(c['development_delivery_only']);self.assertEqual(len(t.calls),2);self.assertEqual(e.calls,[])
            self.assertEqual(len(json.loads(t.calls[1][1]['vllm_xargs']['p34_parents'])),20)

    def test_full_1000_rounds_keep_native_dimensions_and_all_parent_pools(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'benchmark';t,e=RecordingTransport(),RecordingEvaluator()
            c=r.run(PLAN,root,artificial_inputs(),t,e)
            self.assertTrue(c['all_delivered']);self.assertEqual(len(t.calls),1000);self.assertEqual(len(e.calls),1100)
            self.assertEqual(c['evaluator_values_saved'],20100)
            self.assertEqual(sum(x['phase']=='benchmark_round' for x in e.calls),1000)
            self.assertEqual(sum(x['phase']=='benchmark_start' for x in e.calls),100)
            self.assertEqual(len(json.loads(t.calls[0][1]['vllm_xargs']['p34_parents'])),1)
            for i in range(1,10):
                preceding=e.calls[i]['sequences']
                self.assertEqual(json.loads(t.calls[i][1]['vllm_xargs']['p34_parents']),preceding)
            self.assertEqual([cid for cid,_ in t.calls],r.planned_ids())
            score=r.aggregate(PLAN,root);self.assertTrue(score['full_primary_metric_defined']);self.assertEqual(set(score['landscapes']),set(r.LANDSCAPES))
            for name,landscape in score['landscapes'].items():
                self.assertEqual(len(landscape['starting_fitness']),20);self.assertEqual(len(landscape['native_round_curves']),10)
            locked=root/'evaluator'/t.calls[0][0]/'response.json';locked.write_text('{}')
            with self.assertRaises(ValueError):r.aggregate(PLAN,root)

    def test_actual_transport_error_stops_and_preserves_999_untouched_rounds(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'benchmark';t=RecordingTransport(0,'transport');c=r.run(PLAN,root,artificial_inputs(),t,RecordingEvaluator())
            self.assertEqual(c['transport_errors'],1);self.assertEqual(c['empty_finals'],0);self.assertEqual(c['final_status_unknown'],1)
            self.assertEqual(c['not_dispatched'],999);self.assertEqual(len(t.calls),1)
            self.assertEqual(r.read(root/'not_dispatched.json'),r.planned_ids()[1:]);self.assertFalse(r.aggregate(PLAN,root)['full_primary_metric_defined'])

    def test_malformed_envelope_is_response_error_with_unknown_final(self):
        record,candidates=r.decode_response(b'not JSON',['ACD'])
        self.assertEqual(record['status'],'response_error');self.assertEqual(record['final_status'],'unknown');self.assertIsNone(candidates)

    def test_observed_null_and_nonempty_truncated_final_have_separate_counters(self):
        empty,_=r.decode_response(envelope(None),['ACD']);trunc,_=r.decode_response(envelope('partial','length'),['ACD'])
        self.assertEqual(empty['status'],'empty_final');self.assertEqual(empty['final_status'],'observed_empty')
        self.assertEqual(trunc['status'],'truncated');self.assertEqual(trunc['final_status'],'observed_nonempty')

    def test_late_proposal_failure_retains_earlier_calls_and_stops_without_retry(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'benchmark';t=RecordingTransport(2,'invalid_action');c=r.run(PLAN,root,artificial_inputs(),t,RecordingEvaluator())
            self.assertEqual(c['delivered'],2);self.assertEqual(c['response_errors'],1);self.assertEqual(c['not_dispatched'],997);self.assertEqual(len(t.calls),3)
            self.assertEqual(len(r.read(root/'prediction_lock.json')['case_ids']),1000)

    def test_start_evaluator_failure_does_not_send_any_proposal(self):
        with tempfile.TemporaryDirectory() as d:
            t=RecordingTransport();c=r.run(PLAN,Path(d)/'b',artificial_inputs(),t,RecordingEvaluator(0))
            self.assertEqual(t.calls,[]);self.assertEqual(c['not_dispatched'],1000);self.assertEqual(c['evaluator_errors'],1)

    def test_round_evaluator_failure_keeps_raw_proposal_and_stops(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'b';t=RecordingTransport();c=r.run(PLAN,root,artificial_inputs(),t,RecordingEvaluator(1))
            self.assertEqual(len(t.calls),1);self.assertEqual(c['responses_saved'],1);self.assertEqual(c['evaluator_errors'],1);self.assertEqual(c['not_dispatched'],999)
            self.assertTrue((root/'requests'/r.planned_ids()[0]/'response.raw.json').is_file())

    def test_same_output_path_never_reopens_or_resends(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'dev';t=RecordingTransport();r.run(PLAN,root,[],t,RecordingEvaluator(),True)
            with self.assertRaises(FileExistsError):r.run(PLAN,root,[],t,RecordingEvaluator(),True)
            self.assertEqual(len(t.calls),2)

    def test_evaluator_response_requires_identity_full_count_and_finite_values(self):
        class Bad(RecordingEvaluator):
            def score(self,req):
                result=super().score(req);result['scores']=[float('nan')];return result
        with tempfile.TemporaryDirectory() as d:
            outcome,scores=r.score_once(Path(d),'neutral','AMIE',['ACD'],Bad(),'neutral_gate')
            self.assertEqual(outcome['status'],'evaluator_error');self.assertIsNone(scores)
        self.assertEqual(r.finite_scores([1.],1),[1.])
        for values in ([True],[1.,2.],None):
            with self.assertRaises(ValueError):r.finite_scores(values,1)

    def test_guard_exception_seals_unknown_final_not_empty_and_stops(self):
        with tempfile.TemporaryDirectory() as d:
            t=RecordingTransport(0,'guard');c=r.run(PLAN,Path(d)/'b',artificial_inputs(),t,RecordingEvaluator())
            self.assertEqual(c['client_or_guard_errors'],1);self.assertEqual(c['empty_finals'],0);self.assertEqual(c['not_dispatched'],999)

    def test_native_aggregation_keeps_best_so_far_and_population_variance(self):
        import importlib.util
        spec=importlib.util.spec_from_file_location('native_adapter',PLAN['evaluator_adapter']);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        histories=[[[1.,2.],[0.,.5]],[[3.,4.],[1.,1.]]]
        result=m.aggregate_complete_histories(histories,2,2,2)
        self.assertEqual(result[1]['native_best_fitness_mean'],3.);self.assertEqual(result[1]['native_best_fitness_population_variance'],1.)
        with self.assertRaises(ValueError):m.aggregate_complete_histories(histories,2,2,20)

    def test_evaluator_environment_strips_Qwen_compilers_credentials_and_keeps_site_tools(self):
        env=evaluator_environment(Path('/tmp/artificial'),{'CUDA_VISIBLE_DEVICES':'0','CUDA_HOME':'forbidden','CUDACXX':'forbidden','LD_PRELOAD':'forbidden','OPENAI_API_KEY':'not-a-key','LD_LIBRARY_PATH':'wrong','PATH':'wrong'})
        self.assertNotIn('CUDA_HOME',env);self.assertNotIn('CUDACXX',env);self.assertNotIn('LD_PRELOAD',env);self.assertNotIn('OPENAI_API_KEY',env)
        self.assertEqual(env['CUDA_VISIBLE_DEVICES'],'0');self.assertEqual(env['PATH'],'/usr/local/bin:/usr/bin:/bin')
        self.assertEqual(env['LD_LIBRARY_PATH'],'/tmp/artificial/python/lib:/tmp/artificial/site-packages/torch/lib')

    def test_neutral_resource_gate_requires_full_native_batch_at_maximum_length(self):
        from surrogate_service import validate_request
        request={'case_id':'P34-NEUTRAL-AMIE','landscape':'AMIE','sequences':r.neutral_evaluator_sequences(),'phase':'neutral_gate','batch_size':4}
        validate_request(request,{'AMIE':341},set())
        self.assertEqual(len(request['sequences']),4)
        self.assertEqual({len(s) for s in request['sequences']},{439})
        for sequences in ([request['sequences'][0]]*3,[request['sequences'][0]]*5,[request['sequences'][0][:-1]]*4,['ACDEFGHIKLMNPQRSTVWYACDEFGHIKLMNPQRSTV']):
            with self.assertRaises(ValueError):validate_request(dict(request,sequences=sequences),{'AMIE':341},set())
        with self.assertRaises(ValueError):validate_request(request,{'AMIE':341},{request['case_id']})

    def test_tokenizer_batch_encoding_and_plain_list_are_counted_losslessly(self):
        for value in ([1,2,3],{'input_ids':[1,2,3]},{'input_ids':[[1,2,3]]}):
            fake=types.SimpleNamespace(apply_chat_template=lambda *args,**kwargs:value)
            self.assertEqual(exact_prompt_token_count(fake,[]),3)
        fake=types.SimpleNamespace(apply_chat_template=lambda *args,**kwargs:{'input_ids':[[1],[2]]})
        with self.assertRaises(ValueError):exact_prompt_token_count(fake,[])


if __name__=='__main__':unittest.main()
