"""Neutral CPU language tests: no weights, biological cases or model calls."""
import itertools
import json
from pathlib import Path
import random
import sys
import time
import unittest

from unique20_core import (AMINO_ACIDS,COUNT,HEADER,ConstraintError,RequestConstraint,
                          State,TokenVocabulary,Unique20ActionLanguage,parse_proposals)


def document(values):
    return json.dumps({'proposals':values},separators=(',',':'))


def vocabulary():
    pieces = {value:bytes([value]) for value in range(32,127)}
    return TokenVocabulary(pieces,{127},128)


class ConstraintTests(unittest.TestCase):
    def test_full_action_space_includes_every_parent_position_and_replacement(self):
        parents = ['ACD','DEF']
        language = Unique20ActionLanguage(parents)
        self.assertEqual(len(language.allowed),2*3*19)
        for parent,sequence in enumerate(parents):
            for position,before in enumerate(sequence,1):
                for after in AMINO_ACIDS:
                    self.assertEqual(f'P{parent}:{before}{position}{after}' in language.allowed,after!=before)

    def test_every_order_remains_representable_and_exactly_twenty_are_required(self):
        parents = ['ACD','DEF'];language = Unique20ActionLanguage(parents)
        allowed = sorted(language.allowed)
        choices = [allowed[:20],list(reversed(allowed[-20:]))]
        rng = random.Random(27)
        choices += [rng.sample(allowed,20) for _ in range(20)]
        for values in choices:
            self.assertEqual(language.feed(State(),document(values).encode()).phase,'done')
            self.assertEqual([row['action_id'] for row in parse_proposals(document(values),parents)],values)
        for n in (0,1,19,21):
            with self.assertRaises(ConstraintError):language.feed(State(),document(allowed[:n]).encode())

    def test_duplicate_and_invalid_IDs_never_advance_to_completion(self):
        parents = ['ACD'];language = Unique20ActionLanguage(parents);values = sorted(language.allowed)[:20]
        for bad in ['P0:A1A','P0:X1V','P1:A1V','P0:A0V','P0:A01V','P0:A4V','P00:A1V','unrelated']:
            modified = [bad,*values[1:]]
            with self.assertRaises(ConstraintError):language.feed(State(),document(modified).encode())
            with self.assertRaises(ConstraintError):parse_proposals(document(modified),parents)
        with self.assertRaises(ConstraintError):language.feed(State(),document([values[0]]*20).encode())

    def test_parent_prefixed_distinct_actions_may_produce_the_same_sequence(self):
        parents = ['ACD','ACD'];values = ['P0:A1V','P1:A1V']
        rest = [v for v in sorted(Unique20ActionLanguage(parents).allowed) if v not in values][:18]
        rows = parse_proposals(document(values+rest),parents)
        self.assertEqual(rows[0]['sequence'],rows[1]['sequence'])
        self.assertNotEqual(rows[0]['action_id'],rows[1]['action_id'])

    def test_no_whitespace_or_extra_property_loop_and_compact_spelling_only(self):
        parents = ['ACD'];language = Unique20ActionLanguage(parents);raw = document(sorted(language.allowed)[:20])
        for modified in [' '+raw,raw+' ',raw.replace(':',': ',1),raw[:-1]+',"extra":1}',raw+raw]:
            with self.assertRaises(ConstraintError):language.feed(State(),modified.encode())
            with self.assertRaises(ConstraintError):parse_proposals(modified,parents)

    def test_EOS_requires_completion_then_remains_finite_and_absorbing(self):
        import torch
        parents = ['ACD'];vocab = vocabulary();constraint = RequestConstraint(parents,vocab)
        with self.assertRaisesRegex(ConstraintError,'premature_EOS'):constraint.update([127])
        raw = document(sorted(constraint.language.allowed)[:20]).encode()
        constraint = RequestConstraint(parents,vocab)
        constraint.update(list(raw))
        self.assertEqual(vocab.allowed_next_ids(constraint.language,constraint.state),[127])
        logits = torch.full((128,),float('-inf'))
        constraint([*raw,127,127],logits)
        self.assertEqual(torch.where(torch.isfinite(logits))[0].tolist(),[127])
        self.assertEqual(logits[127].item(),0.)
        with self.assertRaisesRegex(ConstraintError,'ordinary_tokens_after_EOS'):
            constraint([*raw,127,127,32],logits)

    def test_masks_invalid_tokens_and_fails_closed_without_finite_allowed_logits(self):
        import torch
        constraint = RequestConstraint(['ACD'],vocabulary())
        logits = torch.zeros(128);constraint([],logits)
        self.assertEqual(torch.where(torch.isfinite(logits))[0].tolist(),[ord('{')])
        with self.assertRaisesRegex(ConstraintError,'no_finite_allowed_logit'):
            constraint([],torch.full((128,),float('-inf')))
        with self.assertRaisesRegex(ConstraintError,'output_history_rewrite'):
            constraint.update([ord('{')]);constraint.update([])

    def test_complete_twenty_parent_439_residue_space_is_not_preselected(self):
        parent = ''.join(AMINO_ACIDS[i%20] for i in range(439));parents = [parent]*20
        language = Unique20ActionLanguage(parents)
        self.assertEqual(len(language.allowed),20*439*19)
        values = [f'P{i}:{parent[-1]}439A' for i in range(20)]
        if parent[-1]=='A':values = [value[:-1]+'C' for value in values]
        self.assertEqual(language.feed(State(),document(values).encode()).phase,'done')
        self.assertEqual(len(parse_proposals(document(values),parents)),20)


if __name__ == '__main__':
    unittest.main()
