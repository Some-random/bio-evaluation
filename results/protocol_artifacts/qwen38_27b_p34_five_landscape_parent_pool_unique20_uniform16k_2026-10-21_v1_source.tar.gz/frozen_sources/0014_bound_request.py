"""Exact public-input proposal contract; no learned target or fitness feedback."""
import hashlib
import json
from unique20_core import CONDITION, validate_parents

SYSTEM='You propose protein single-substitution actions for the stated property. Use only the supplied complete parent sequences and public objective. Return exactly the constrained compact JSON object and no explanation.'
PREFIX='P34 retained local adaptation. All provided parents remain available; parent selection is yours. A proposal ID is P<zero-based parent index>:<original amino acid><one-based position><replacement amino acid>. Select 20 distinct IDs from every canonical nonidentity single substitution across every parent. Preserve the supplied sequence lengths. The evaluator is withheld and no measured or surrogate fitness is supplied.\n'


def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True)
def digest(value):return hashlib.sha256(canonical(value).encode()).hexdigest()


def context(case,parents):
    validate_parents(parents)
    if set(case)!={'landscape','function','target'} or not all(isinstance(v,str) and v for v in case.values()):
        raise ValueError('Exact public landscape/function/target contract required')
    return {'condition_id':CONDITION,'landscape':case['landscape'],'function':case['function'],
            'target':case['target'],'parents':[{'parent_index':i,'complete_sequence':s} for i,s in enumerate(parents)]}


def messages(case,parents):
    return [{'role':'system','content':SYSTEM},{'role':'user','content':PREFIX+canonical(context(case,parents))}]


def payload(plan,case,parents,seed):
    ctx=context(case,parents)
    return {'model':plan['model']['served_model_name'],'messages':messages(case,parents),
        'temperature':1.0,'top_p':.95,'top_k':20,'seed':seed,'max_tokens':16384,'n':1,'stream':False,
        'chat_template_kwargs':{'enable_thinking':False},
        'vllm_xargs':{'p34_condition':CONDITION,'p34_parents':canonical(parents),
            'p34_parents_sha256':digest(parents),'p34_context_sha256':digest(ctx)}}


def validate_payload(request,case,parents,seed,plan):
    if request!=payload(plan,case,parents,seed):raise ValueError('Frozen prompt, full parent pool, seed or sampling changed')
    return digest(context(case,parents))
