"""P34 released landscape-head binding and score accounting, no proposals.

No generation, optimization, model forwards, real sequence inspection or
training occurs in these utilities.  The exact Qwen proposal interface is
still a prospective adaptation, not the released MutaPLM 33-token interface.
"""
from __future__ import annotations

import ast
import hashlib
import math
from pathlib import Path
from statistics import mean, pvariance


def selected_class(path, name, namespace):
    tree = ast.parse(Path(path).read_text())
    node = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == name)
    # Compile the complete unmodified class, excluding unrelated imports/setup.
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), "exec"), namespace)
    return namespace[name]


def decoder_class(torch, source_root, dependency_root):
    source_path = Path(source_root) / "model/esm_landscape.py"
    if hashlib.sha256(source_path.read_bytes()).hexdigest() != "facba5e317c71002cd9ff2bb97e6d2dd0f00aeee6c45915466b112a7047c8624":
        raise ValueError("Released decoder source changed after preparation")
    ns = {"nn": torch.nn, "torch": torch, "F": torch.nn.functional}
    selected_class(Path(dependency_root) / "sequence_models_convolutional.py", "MaskedConv1d", ns)
    selected_class(Path(dependency_root) / "sequence_models_structure.py", "Attention1d", ns)
    return selected_class(source_path, "Decoder", ns)


def bind_released_head(torch, decoder, path, expected_sha256):
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise ValueError("Released landscape-head digest mismatch")
    import io
    state = torch.load(io.BytesIO(raw), map_location="cpu")
    model = decoder()
    result = model.load_state_dict(state, strict=True)
    if result.missing_keys or result.unexpected_keys:
        raise ValueError("Landscape-head schema mismatch")
    if not all(torch.equal(tensor, state[key]) for key, tensor in model.state_dict().items()):
        raise ValueError("Landscape-head learned value mismatch")
    model.eval()
    return model


def aggregate_complete_histories(histories, num_runs=20, num_rounds=10, num_candidates=20):
    """Aggregate already-observed scalars with the native full denominators."""
    if len(histories) != num_runs:
        raise ValueError("A complete history must retain all independent runs")
    maxima, averages = [], []
    for run in histories:
        if len(run) != num_rounds:
            raise ValueError("A complete run must retain all native rounds")
        mx, avg = [], []
        for scores in run:
            if len(scores) != num_candidates:
                raise ValueError("Every round must retain its entire candidate set")
            if not all(isinstance(s, (int, float)) and not isinstance(s, bool) and math.isfinite(s) for s in scores):
                raise ValueError("Incomplete/invalid evaluator scores cannot be silently dropped")
            mx.append(max(max(scores), mx[-1]) if mx else max(scores))
            avg.append(mean(scores))
        maxima.append(mx)
        averages.append(avg)
    return [{"round": j + 1,
             "native_best_fitness_mean": mean(run[j] for run in maxima),
             "native_best_fitness_population_variance": pvariance(run[j] for run in maxima),
             "native_candidate_mean_fitness": mean(run[j] for run in averages),
             # Upstream's Avg-scores print line uses mx_scores variance too.
             "native_printed_average_curve_variance": pvariance(run[j] for run in maxima)}
            for j in range(num_rounds)]
