"""Offline construction of the released P34 evaluator; no forward or proposals.

The upstream complete classes are selected from their pinned source without
executing unrelated training imports. One exact encoder/tokenizer pair is shared
between the five already acquired nonheld heads. Inputs and dispatch stay outside
this assembly module.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

SOURCE_HASH = "facba5e317c71002cd9ff2bb97e6d2dd0f00aeee6c45915466b112a7047c8624"
WEIGHT_HASH = "ebb8a35768179581f91fc01b93cf78facba2821c3bab1452abb38ef2a7f6e7b1"


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_assets(repo, work):
    pins = json.loads((work / "runtime_input_pins.json").read_text())
    for record in pins["files"]:
        if file_sha256(repo / record["path"]) != record["sha256"]:
            raise ValueError("Frozen assembly input changed: " + record["path"])
    assets = repo / ".local/source_acquisition_2026-10-19/evaluators"
    records = json.loads((assets / "esm1b_metadata_manifest.json").read_text())["assets"]
    for row in records:
        path = repo / row["path"]
        if file_sha256(path) != row["local_sha256"]:
            raise ValueError("Pinned ESM1b metadata digest mismatch")
    weight = assets / "weights/esm1b_pytorch_model.bin"
    if file_sha256(weight) != WEIGHT_HASH:
        raise ValueError("Pinned ESM1b learned-weight digest mismatch")
    view = work / "local_checkpoint_view"
    view.mkdir(exist_ok=True)
    for name, target in [(Path(row["path"]).name, repo / row["path"]) for row in records] + [("pytorch_model.bin", weight)]:
        link = view / name
        if link.is_symlink():
            if link.resolve() != target.resolve():
                raise ValueError("Existing checkpoint-view link has another identity")
        elif link.exists():
            raise ValueError("Checkpoint view must use source links, not copied weights")
        else:
            link.symlink_to(target.resolve())
    return assets, view, records


def assemble_released_runtime(torch, transformers, repo, work):
    parent = work.parent
    sys.path.insert(0, str(parent))
    from evaluator_adapter import decoder_class, selected_class
    source = repo / ".local/source_acquisition_2026-10-19/mutadescribe_sources/source/mutaplm"
    source_file = source / "model/esm_landscape.py"
    if file_sha256(source_file) != SOURCE_HASH:
        raise ValueError("Released evaluator source changed")
    assets, view, records = verify_assets(repo, work)
    decoder = decoder_class(torch, source, parent)
    encoder, loading = transformers.EsmModel.from_pretrained(
        str(view), local_files_only=True, output_loading_info=True
    )
    tokenizer = transformers.EsmTokenizer.from_pretrained(str(view), local_files_only=True)
    encoder.eval()

    class BoundEncoderFactory:
        @classmethod
        def from_pretrained(cls, path):
            if Path(path).resolve() != view.resolve():
                raise ValueError("Encoder identity cannot change during assembly")
            return encoder

    class BoundTokenizerFactory:
        @classmethod
        def from_pretrained(cls, path):
            if Path(path).resolve() != view.resolve():
                raise ValueError("Tokenizer identity cannot change during assembly")
            return tokenizer

    namespace = {"nn": torch.nn, "torch": torch, "Decoder": decoder,
                 "EsmModel": BoundEncoderFactory, "EsmTokenizer": BoundTokenizerFactory}
    combined = selected_class(source_file, "EsmForLandscapeRegression", namespace)
    manifest = json.loads((assets / "p34_selected_heads_manifest.json").read_text())
    heads = [row for row in manifest["assets"] if Path(row["path"]).name == "decoder.pt"]
    if len(heads) != 5:
        raise ValueError("The existing five-head scope must remain unchanged")
    if {Path(row["path"]).parent.name for row in heads} != {"AMIE", "E4B", "LGK", "UBE2I", "avGFP"}:
        raise ValueError("The existing nonheld landscape scope changed")
    runtimes = {}
    for row in heads:
        if file_sha256(row["path"]) != row["local_sha256"]:
            raise ValueError("Released head digest mismatch")
        instance = combined(str(view), row["path"], torch.device("cpu"))
        instance.eval()
        runtimes[Path(row["path"]).parent.name] = instance
    return encoder, tokenizer, runtimes, loading, heads, records


def tokenize_without_forward(tokenizer, placeholders, max_length=1024):
    """Validate token dimensions without executing an encoder or scoring head.

    The upstream evaluator truncates at 1024 tokens. A prospective admission
    check must reject oversized inputs explicitly instead of silently losing
    content. This helper does not adopt a benchmark condition.
    """
    if not isinstance(placeholders, list) or not placeholders:
        raise ValueError("Expected a nonempty list of synthetic placeholders")
    full = tokenizer(placeholders, add_special_tokens=True, truncation=False,
                     padding=False, return_attention_mask=True)
    if any(len(tokens) > max_length for tokens in full["input_ids"]):
        raise ValueError("Input exceeds native token envelope; silent truncation forbidden")
    return tokenizer(placeholders, add_special_tokens=True, truncation=True,
                     padding=True, max_length=max_length, return_tensors="pt")
