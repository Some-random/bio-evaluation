"""CPU-only assembly of an isolated official Torch1.13.1/cu117 evaluator.

No learned weights are loaded, no module forward runs and no GPU is requested.
The earlier exact CPU artifact remains unchanged.
"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import html
import json
import os
import re
import subprocess
import tarfile
import tempfile
import urllib.parse
import urllib.request

HERE = Path(__file__).resolve().parent
OUT = HERE/'CUDA_evaluator_runtime_v1'
PYTHON = Path('/tmp/bio-p37-omegafold2-runtime-20261020/interpreters/cpython-3.10.18-linux-x86_64-gnu')
UV = HERE.parents[1]/'P37/runtime_preparation/tools/bin/uv'
LOCK = HERE.parent/'engineering_20261020/encoder_binding_v1/requirements-244177.lock'
INDEX = 'https://download.pytorch.org/whl/cu117/torch/'
WHEEL = 'torch-1.13.1+cu117-cp310-cp310-linux_x86_64.whl'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda:stream.read(8*1024*1024),b''):
            digest.update(data)
    return digest.hexdigest()


def main():
    OUT.mkdir(exist_ok=False)
    env = {key:value for key,value in os.environ.items()
        if not any(part in key.upper() for part in ('TOKEN','SECRET','PASSWORD','CREDENTIAL','API_KEY'))}
    env.update(CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',
               UV_CACHE_DIR='/tmp/bio-p34-cu117-uv-cache',HF_HUB_OFFLINE='1')
    request = urllib.request.Request(INDEX,headers={'User-Agent':'bio-evaluation-source-verifier/1'})
    with urllib.request.urlopen(request,timeout=60) as response:
        page = response.read(8*1024*1024+1)
    if len(page)>8*1024*1024:
        raise ValueError('Official wheel listing exceeded the bounded metadata guard')
    (OUT/'official_torch_index.html').write_bytes(page)
    links = [html.unescape(value) for value in re.findall(r'href="([^"]+)"',page.decode())]
    matches = [urllib.parse.urljoin(INDEX,value) for value in links
               if urllib.parse.unquote(urllib.parse.urlsplit(value).path).endswith('/'+WHEEL)]
    if len(matches)!=1:
        raise ValueError('Exact official cu117 CPython3.10 wheel is unavailable or ambiguous')
    wheel_url = matches[0]
    expected = urllib.parse.parse_qs(urllib.parse.urlsplit(wheel_url).fragment).get('sha256',[])
    if len(expected)!=1 or re.fullmatch('[a-f0-9]{64}',expected[0]) is None:
        raise ValueError('Official wheel listing lacks a unique publisher SHA256')
    source = {'index':INDEX,'index_sha256':sha(OUT/'official_torch_index.html'),
        'wheel_url':wheel_url,'publisher_wheel_sha256':expected[0],
        'exact_prior_dependency_lock_sha256':sha(LOCK),'new_training':False}
    (OUT/'official_source_receipt.json').write_text(json.dumps(source,indent=2)+'\n')
    local = Path(tempfile.mkdtemp(prefix='bio-p34-cu117-build-'))
    venv = local/'venv'
    requirements = OUT/'exact_dependencies_without_torch.txt'
    requirements.write_text('\n'.join(line for line in LOCK.read_text().splitlines()
                                     if line and not line.startswith('torch=='))+'\n')
    commands = [[str(UV),'venv','--python',str(PYTHON/'bin/python3.10'),str(venv)],
        [str(UV),'pip','install','--python',str(venv/'bin/python'),
         '--index-url','https://pypi.org/simple',wheel_url,'-r',str(requirements)],
        [str(UV),'pip','check','--python',str(venv/'bin/python')]]
    with (OUT/'installation.log').open('x') as log:
        for command in commands:
            subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1500)
    archive = OUT/'evaluator_runtime.tar'
    members = {}
    with tarfile.open(archive,'w',dereference=True) as tar:
        for prefix,root in {'python':PYTHON,'site-packages':venv/'lib/python3.10/site-packages'}.items():
            for path in sorted(root.rglob('*')):
                if path.is_file():
                    name = prefix+'/'+str(path.relative_to(root))
                    members[name] = {'bytes':path.stat().st_size,'sha256':sha(path)}
                    tar.add(path,arcname=name,recursive=False)
    proof = Path(tempfile.mkdtemp(prefix='p34-cu117-portability-proof-'))
    with tarfile.open(archive) as tar:
        tar.extractall(proof,filter='data')
    for key in ('PYTHONHOME','PYTHONPATH','VIRTUAL_ENV','LD_PRELOAD','CUDA_HOME','CUDACXX'):
        env.pop(key,None)
    env.update(PYTHONHOME=str(proof/'python'),PYTHONPATH=str(proof/'site-packages'),
        LD_LIBRARY_PATH=str(proof/'python/lib')+':'+str(proof/'site-packages/torch/lib'),
        PATH='/usr/local/bin:/usr/bin:/bin',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    code = '''import torch,transformers,numpy,json
def forbid(*args,**kwargs):raise RuntimeError("Model forwards forbidden during runtime assembly")
guard=torch.nn.modules.module.register_module_forward_pre_hook(forbid)
assert torch.__version__=="1.13.1+cu117" and transformers.__version__=="4.36.1"
assert numpy.__version__=="1.26.4" and not torch.cuda.is_initialized()
print(json.dumps({"torch":torch.__version__,"CUDA_build":torch.version.cuda,"transformers":transformers.__version__,"numpy":numpy.__version__,"torch_file":torch.__file__,"CUDA_initialized":False,"model_forwards":0}))
'''
    identity = json.loads(subprocess.check_output([str(proof/'python/bin/python3.10'),'-c',code],
                                                 env=env,text=True,timeout=120))
    if not Path(identity['torch_file']).is_relative_to(proof):
        raise ValueError('Import escaped the independent relocated runtime')
    record = {'stage':'official_cu117_runtime_packaged_CPU_import_verified_no_forward',
        'at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        'job_id':os.environ.get('SLURM_JOB_ID'),'archive':str(archive),
        'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
        'file_count':len(members),'source_bytes':sum(row['bytes'] for row in members.values()),
        'files':members,'identity':identity,'proof_extraction_root':str(proof),
        'official_source_receipt_sha256':sha(OUT/'official_source_receipt.json'),
        'model_forwards':0,'GPU_allocations':0,'source_CPU_environment_modified':False}
    (OUT/'runtime_manifest.json').write_text(json.dumps(record,indent=2)+'\n')
    summary = {k:v for k,v in record.items() if k!='files'}
    (OUT/'completion.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary))


if __name__=='__main__':
    main()
