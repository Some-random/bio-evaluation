"""Run complete artificial suite before pinned-tokenizer/API proof; zero model calls."""
from pathlib import Path
import json
import subprocess
import sys
import unittest
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from p34_runner import save,stamp
suite=unittest.defaultTestLoader.discover(str(HERE),pattern='test_*.py')
result=unittest.TextTestRunner(verbosity=2).run(suite)
if not result.wasSuccessful():raise SystemExit(1)
subprocess.run([sys.executable,str(HERE/'checkpoint_cpu_validation.py')],check=True)
save(HERE/'CPU_validation.json',{'stage':'full_once_only_loop_and_native_aggregation_artificial_tests_passed',
    'at_pacific':stamp(),'job_id':__import__('os').environ['SLURM_JOB_ID'],'tests_passed':result.testsRun,
    'tests_run':result.testsRun,'failures':0,'errors':0,'synthetic_round_requests_checked':1000,
    'synthetic_candidate_scores_checked':20000,'synthetic_initial_scores_checked':100,
    'model_calls':0,'model_forwards':0,'GPU_allocations':0})
