"""Actual pinned tokenizer and verbatim legacy API on artificial outputs; zero forwards."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import random
import sys
import time
import types
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))


def main():
    if os.environ.get('CUDA_VISIBLE_DEVICES')!='' or not os.environ.get('SLURM_JOB_ID') or os.environ.get('SLURM_GPUS'):
        raise ValueError('CPU-only allocated validation required')
    plan=json.loads((HERE/'CPU_plan.json').read_text())
    for name,digest in plan['files_sha256'].items():
        if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=digest:raise ValueError('CPU source identity changed: '+name)
    import torch
    from tokenizers import Tokenizer
    from transformers import AutoTokenizer
    from unique20_core import AMINO_ACIDS,ConstraintError,RequestConstraint,TokenVocabulary,Unique20ActionLanguage
    from bound_request import payload
    from p34_runner import normalized_inputs,save
    from source_api_harness import load_verbatim_adapter,import_production_adapter_with_source_base
    from worker import exact_prompt_token_count
    torch.set_num_threads(4);start=time.monotonic();checks={};panels=[]
    path=Path(plan['tokenizer']);vocab=TokenVocabulary.from_checkpoint_tokenizer(path,plan['tokenizer_sha256'],set(plan['EOS_ids']))
    tokenizer=Tokenizer.from_file(str(path));size=plan['padded_vocabulary_size']
    for token,piece in vocab.pieces.items():
        if tokenizer.decode([token],skip_special_tokens=False).encode()!=piece:raise ValueError('ByteLevel token piece mismatch')
    checks['every_usable_piece_matches_exact_checkpoint_decoder']=len(vocab.pieces)
    alphabet=set(b'{"proposals":[],P0123456789ACDEFGHIKLMNPQRSTVWY')
    if not alphabet<={p[0] for p in vocab.pieces.values() if len(p)==1}:raise ValueError('Accepted ASCII character lacks a lossless token')
    checks['all_language_bytes_losslessly_tokenizable']=True
    checks['EOS_special_tokens_not_ordinary_output']=vocab.eos_ids.isdisjoint(vocab.pieces)
    parent=('ACDEFGHIKLMNPQRSTVWY'*22)[:439]
    cases=[['ACDE'],[parent]*20]
    for parents in cases:
        actions=[f'P{pi}:{seq[-1]}{len(seq)}'+('C' if seq[-1]=='A' else 'A') for pi,seq in enumerate(parents)]
        language=Unique20ActionLanguage(parents)
        if len(actions)<20:actions=random.Random(34).sample(sorted(language.allowed),20)
        text=json.dumps({'proposals':list(reversed(actions))},separators=(',',':'))
        ids=tokenizer.encode(text,add_special_tokens=False).ids
        if tokenizer.decode(ids,skip_special_tokens=False)!=text:raise ValueError('Roundtrip mismatch')
        constraint=RequestConstraint(parents,vocab);output=[]
        for token in ids:
            logits=torch.zeros(size);constraint(output,logits)
            if not torch.isfinite(logits[token]) or torch.isfinite(logits[list(vocab.eos_ids)]).any():raise ValueError('Valid token excluded or premature EOS admitted')
            output.append(token)
        constraint(output,torch.zeros(size))
        if constraint.state.phase!='done' or len(constraint.state.used)!=20:raise ValueError('Incomplete unique20 state')
        output.append(min(vocab.eos_ids))
        for upstream in (0.,float('-inf'),float('nan')):
            logits=torch.full((size,),upstream);constraint(output,logits)
            if set(torch.where(torch.isfinite(logits))[0].tolist())!=set(vocab.eos_ids) or logits[list(vocab.eos_ids)].tolist()!=[0.,0.]:raise ValueError('Terminal finite EOS invariant failed')
        constraint.update(output+[min(vocab.eos_ids)])
        try:constraint.update(output+[min(vocab.eos_ids),next(iter(vocab.pieces))])
        except ConstraintError:pass
        else:raise ValueError('Ordinary post-EOS byte accepted')
        panels.append({'parent_count':len(parents),'sequence_length':len(parents[0]),'complete_action_count':len(language.allowed),'actual_token_boundaries':len(ids)})
    checks['arbitrary_order_unique20_actual_token_boundaries_for1_and20_parents']=True
    checks['full_166820_action_space_not_preselected']=panels[1]['complete_action_count']==166820
    checks['finite_absorbing_EOS_after_complete20_with_inf_and_nan_upstream']=True
    checks['ordinary_post_EOS_rejected']=True
    try:RequestConstraint(['ACD'],vocab).update([min(vocab.eos_ids)])
    except ConstraintError:pass
    else:raise ValueError('Premature EOS accepted')
    checks['premature_EOS_rejected']=True
    scope=load_verbatim_adapter(Path(plan['pinned_V1_source_directory']),torch)
    module=import_production_adapter_with_source_base(scope)
    cfg=types.SimpleNamespace(speculative_config=None,model_config=types.SimpleNamespace(model=str(path.parent)))
    with patch.dict(os.environ,{'VLLM_USE_V2_MODEL_RUNNER':'0'}),patch.object(importlib.metadata,'version',return_value='0.32.0'):
        adapter=module.P34Unique20LogitsProcessor(cfg,torch.device('cpu'),False)
    if adapter.is_argmax_invariant():raise ValueError('Hard constraint would be skipped for greedy')
    fakeplan={'model':{'served_model_name':'Qwen/Qwen3.8-27B'}}
    case={'landscape':'artificial','function':'Neutral artificial fixture','target':'No biological objective'}
    def params(parents):return types.SimpleNamespace(extra_args=payload(fakeplan,case,parents,42)['vllm_xargs'],n=1)
    a=[];b=[];B=scope['BatchUpdate'];direction=scope['MoveDirectionality']
    adapter.update_state(B(batch_size=2,removed=[],added=[(0,params(['ACD']),[],a),(1,params(['DEF','DEF']),[],b)],moved=[]))
    adapter.apply(torch.zeros((2,size)))
    a.extend(tokenizer.encode('{"proposals":["P0:A1V",',add_special_tokens=False).ids)
    adapter.update_state(None);adapter.apply(torch.zeros((2,size)))
    if adapter.req_info[0].func.state.used!=frozenset({'P0:A1V'}) or adapter.req_info[1].func.state.used:raise ValueError('Live history cross-talk')
    checks['verbatim_API_live_output_history_and_independent_parent_pools']=True
    first,second=adapter.req_info[0],adapter.req_info[1]
    adapter.update_state(B(batch_size=2,removed=[],added=[],moved=[(0,1,direction.SWAP)]))
    if adapter.req_info[0] is not second or adapter.req_info[1] is not first:raise ValueError('Swap identity failure')
    adapter.update_state(B(batch_size=1,removed=[0],added=[],moved=[(1,0,direction.UNIDIRECTIONAL)]))
    if set(adapter.req_info)!={0} or adapter.req_info[0] is not first:raise ValueError('Remove/move identity failure')
    adapter.update_state(B(batch_size=0,removed=[0],added=[],moved=[]))
    adapter.update_state(B(batch_size=1,removed=[],added=[(0,params(['ACD']),[],[])],moved=[]))
    if adapter.req_info[0].func.state.used:raise ValueError('Old used IDs leaked into new request')
    checks['verbatim_API_swap_remove_move_and_fresh_slot_reuse']=True
    bad=params(['ACD']);bad.extra_args['p34_parents_sha256']='0'*64
    for p in (bad,types.SimpleNamespace(extra_args={},n=1)):
        try:module.validate_request_params(p)
        except ValueError:pass
        else:raise ValueError('Bad mandatory parent binding accepted')
    adapter.req_info.clear()
    try:adapter.apply(torch.zeros((1,size)))
    except ValueError:pass
    else:raise ValueError('Unconstrained row accepted')
    checks['mandatory_bindings_and_all_active_rows_fail_closed']=True
    native=AutoTokenizer.from_pretrained(path.parent,local_files_only=True);input_rows=[]
    for row in normalized_inputs(plan['selected_inputs']):
        sourcecase={k:row[k] for k in ('landscape','function','target')}
        for parents in ([row['sequence']],[row['sequence']]*20):
            count=exact_prompt_token_count(native,payload(fakeplan,sourcecase,parents,42)['messages'])
            if count+16384>65536:raise ValueError('Full supplied prompt exceeds context')
            input_rows.append({'landscape':row['landscape'],'parent_count':len(parents),'complete_sequence_length':len(parents[0]),'prompt_tokens':count})
    checks['five_exact_starting_and20parent_prompt_sizing_CPU_only_passed']=True
    checks['no_model_or_surrogate_forward_during_preparation']=not torch.cuda.is_initialized()
    record={'stage':'CPU_unique20_full_parent_loop_tokenizer_verbatim_API_checks_passed_not_model_delivery',
        'at_pacific':__import__('p34_runner').stamp(),'job_id':os.environ['SLURM_JOB_ID'],'checks':checks,'checks_passed':len(checks),
        'panels':panels,'prompt_counts':input_rows,'max_observed_prompt_tokens':max(x['prompt_tokens'] for x in input_rows),
        'CPU_plan_sha256':hashlib.sha256((HERE/'CPU_plan.json').read_bytes()).hexdigest(),'elapsed_seconds':time.monotonic()-start,
        'actual_vllm_engine_imported':False,'verbatim_pinned_source_methods_executed':True,'real_inputs_CPU_tokenization_only':True,
        'futures_prompts_checked_before_each_request':True,'model_weights_loaded':False,'model_forwards':0,'model_calls':0,'GPU_allocations':0}
    save(HERE/'checkpoint_CPU_validation.json',record)
    print(json.dumps({k:record[k] for k in ('stage','checks_passed','max_observed_prompt_tokens','elapsed_seconds')}))


if __name__=='__main__':main()
