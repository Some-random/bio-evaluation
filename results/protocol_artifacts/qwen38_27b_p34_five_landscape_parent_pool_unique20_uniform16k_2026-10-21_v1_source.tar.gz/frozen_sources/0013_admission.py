"""Exact root admission and independently hashed runtime extraction; no calls."""
import os
from pathlib import Path
import tarfile
from p34_runner import read,sha,CONDITION,LANDSCAPES,planned_ids
HERE=Path(__file__).resolve().parent
SCOPE='five_nonheld_landscapes_20runs_10rounds_20actions_with_released_surrogate'


def validate(plan_path,plan_sha,admission_path,admission_sha,require_slurm=True):
    if sha(plan_path)!=plan_sha:raise ValueError('Frozen P34 plan mismatch')
    p=read(plan_path)
    exact={'max_tokens':16384,'temperature':1.0,'top_p':.95,'top_k':20,'enable_thinking':False,'n':1,'concurrency':1,'seed_base':42}
    if (p['condition_id']!=CONDITION or p['generation']!=exact or p['planned_case_ids']!=planned_ids() or
        p['landscapes']!=LANDSCAPES or p['runs_per_landscape']!=20 or p['rounds_per_run']!=10 or
        p['candidates_per_round']!=20 or p['gpus_requested']!=1 or p['evaluator_batch_size']!=4 or
        p['endpoint']!='http://127.0.0.1:8497/v1' or p['Qwen_gpu_memory_utilization']!=.85 or
        p['evaluator_device']!='cuda:0' or Path(p['output_root']).resolve()!=HERE/'runtime/run_v1'):
        raise ValueError('Exact complete P34 condition required')
    for name,digest in p['frozen_files_sha256'].items():
        if Path(name).is_symlink() or sha(name)!=digest:raise ValueError('Frozen source/input changed: '+name)
    if sha(admission_path)!=admission_sha:raise ValueError('Root admission hash mismatch')
    a=read(admission_path)
    if (a.get('admitted') is not True or a.get('task_id')!='P34' or a.get('condition_id')!=CONDITION or
        a.get('plan_sha256')!=plan_sha or a.get('gpu_count')!=1 or a.get('project_gpu_ceiling')!=8 or a.get('scope')!=SCOPE):
        raise ValueError('Separate exact P34 root admission required')
    if sha(a['gpu_audit_receipt'])!=a['gpu_audit_receipt_sha256']:raise ValueError('Root project GPU budget evidence changed')
    if require_slurm and not os.environ.get('SLURM_JOB_ID'):raise ValueError('Own Slurm allocation required')
    p['plan_sha256']=plan_sha
    return p


def verify_evaluator_runtime(plan,destination):
    m=read(plan['evaluator_runtime_manifest']);a=Path(m['archive'])
    if sha(a)!=m['archive_sha256'] or a.stat().st_size!=m['archive_bytes']:raise ValueError('Evaluator runtime archive changed')
    root=Path(destination);root.mkdir(exist_ok=False)
    with tarfile.open(a) as tar:
        members=tar.getmembers()
        if len(members)!=len(m['files']) or {r.name for r in members}!=set(m['files']) or any(not r.isfile() or Path(r.name).is_absolute() or '..' in Path(r.name).parts for r in members):
            raise ValueError('Unsafe or changed evaluator runtime members')
        tar.extractall(root,filter='data')
    for name,item in m['files'].items():
        p=root/name
        if p.is_symlink() or p.stat().st_size!=item['bytes'] or sha(p)!=item['sha256']:raise ValueError('Relocated evaluator runtime member mismatch')
    return root
