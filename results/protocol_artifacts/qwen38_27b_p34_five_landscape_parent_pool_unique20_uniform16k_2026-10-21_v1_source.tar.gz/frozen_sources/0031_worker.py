"""Dedicated one-GPU P34 proposal+released-surrogate execution; no shared queue writes."""
from __future__ import annotations
import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request
from admission import validate,verify_evaluator_runtime
from p34_runner import TransportError,aggregate,current,normalized_inputs,read,run,save,sha,stamp,score_once,LANDSCAPES,neutral_evaluator_sequences
from bound_request import payload
HERE=Path(__file__).resolve().parent
PACKAGES={'vllm':'0.32.0','torch':'2.13.0','transformers':'5.17.0','triton':'3.7.1','flashinfer-python':'0.7.0.post1'}


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def project_audit(plan):
    path=plan['project_gpu_audit_helper']
    if sha(path)!=plan['frozen_files_sha256'][path]:raise ValueError('Root GPU audit helper changed')
    return load('p34_root_project_GPU_audit',path).conservative_project_gpu_audit(require_own_job=True)


def environment(common,local):
    env=common.environment(local)
    for name in list(env):
        if re.search(r'API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL',name,re.I) or name in {'SSH_AUTH_SOCK','NETRC','KUBECONFIG','GOOGLE_APPLICATION_CREDENTIALS','PYTHONPATH','PYTHONHOME','VIRTUAL_ENV','OPENAI_BASE_URL','OPENAI_ORG_ID','OPENAI_PROJECT_ID'}:
            env.pop(name,None)
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',
        VLLM_USE_V2_MODEL_RUNNER='0',VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1',PIP_INDEX_URL='https://pypi.org/simple',
        PIP_EXTRA_INDEX_URL='',PIP_CONFIG_FILE='/dev/null',PYTHONPATH=str(HERE))
    return env


def evaluator_environment(root,inherited):
    env={k:v for k,v in inherited.items() if not re.search(r'API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL',k,re.I)}
    for name in ('CUDA_HOME','CUDA_PATH','CUDACXX','NVCC','CUDA_NVCC_EXECUTABLE','CMAKE_CUDA_COMPILER','TORCH_CUDA_ARCH_LIST','LD_PRELOAD','CC','CXX','PYTHONHOME','PYTHONPATH','VIRTUAL_ENV','PYTORCH_CUDA_ALLOC_CONF'):
        env.pop(name,None)
    env.update(PYTHONHOME=str(root/'python'),PYTHONPATH=str(root/'site-packages')+':'+str(HERE),
        LD_LIBRARY_PATH=str(root/'python/lib')+':'+str(root/'site-packages/torch/lib'),PATH='/usr/local/bin:/usr/bin:/bin',
        PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
        OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1')
    return env


def install_runtime(python,env,root):
    command=[str(python),'-m','pip','install','--index-url','https://pypi.org/simple','--only-binary=:all:',
        '--break-system-packages','--upgrade',*[k+'=='+v for k,v in PACKAGES.items()],
        '--report',str(root/'pip_install_report.json')]
    with (root/'runtime_install.log').open('x') as log:
        subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=2400)
    with (root/'pip_check.log').open('x') as log:
        subprocess.run([str(python),'-m','pip','check'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)


def stop_process(process):
    if process is not None and process.poll() is None:
        os.killpg(process.pid,signal.SIGTERM)
        try:process.wait(timeout=60)
        except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=10)


def exact_prompt_token_count(tokenizer,messages):
    tokens=tokenizer.apply_chat_template(messages,tokenize=True,add_generation_prompt=True,enable_thinking=False)
    if hasattr(tokens,'keys'):
        if 'input_ids' not in tokens:raise ValueError('Tokenizer omitted input IDs')
        tokens=tokens['input_ids']
    if tokens and isinstance(tokens[0],list):
        if len(tokens)!=1:raise ValueError('Single request tokenization must have one batch row')
        tokens=tokens[0]
    if not isinstance(tokens,list) or any(not isinstance(t,int) for t in tokens):raise ValueError('Unexpected tokenizer envelope')
    return len(tokens)


class LocalTransport:
    def __init__(self,plan,identity_path,common,tokenizer):
        self.plan=plan;self.identity_path=identity_path;self.identity_sha=sha(identity_path);self.common=common;self.tokenizer=tokenizer
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def send(self,case_id,request):
        if sha(self.identity_path)!=self.identity_sha:raise TransportError('Own server identity changed before dispatch')
        identity=read(self.identity_path)
        if (identity['job_id']!=os.environ['SLURM_JOB_ID'] or identity['hostname']!=socket.gethostname() or
            self.common.start_ticks(identity['pid'])!=identity['proc_start_ticks'] or
            request['model']!=self.plan['model']['served_model_name'] or request['max_tokens']!=16384):
            raise TransportError('Request does not match own admitted server')
        count=exact_prompt_token_count(self.tokenizer,request['messages'])
        if count+16384>65536:raise TransportError('Full untruncated prompt plus16384 exceeds65536; no request sent')
        save(self.identity_path.parent/'context_observations'/(case_id+'.json'),{'case_id':case_id,'prompt_tokens':count,'output_budget':16384,'server_context':65536,'silent_truncation':False})
        try:
            wire=urllib.request.Request(self.plan['endpoint']+'/chat/completions',data=json.dumps(request).encode(),headers={'Content-Type':'application/json'})
            with self.opener.open(wire,timeout=1800) as response:return response.read()
        except urllib.error.HTTPError as error:raise TransportError('HTTP error',error.code,error.read()) from error
        except (urllib.error.URLError,TimeoutError,OSError) as error:raise TransportError(type(error).__name__) from error


class SurrogateClient:
    def __init__(self,process):self.process=process;self.selector=selectors.DefaultSelector();self.selector.register(process.stdout,selectors.EVENT_READ)
    def receive(self,timeout):
        if not self.selector.select(timeout):raise TimeoutError('Own evaluator process response deadline')
        line=self.process.stdout.readline()
        if not line:raise RuntimeError('Own evaluator exited before delivery')
        result=json.loads(line)
        if 'error' in result:raise RuntimeError('Released evaluator failure: '+result['error'])
        return result
    def score(self,request):
        if self.process.poll() is not None:raise RuntimeError('Own evaluator is no longer running')
        self.process.stdin.write(json.dumps(request)+'\n');self.process.stdin.flush();return self.receive(600)


def main():
    parser=argparse.ArgumentParser()
    for n in ('plan','admission'):parser.add_argument('--'+n,type=Path,required=True)
    for n in ('plan-sha256','admission-sha256'):parser.add_argument('--'+n,required=True)
    parser.add_argument('--runtime-dir',type=Path)
    args=parser.parse_args();plan=validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256)
    runtime=HERE/'runtime';runtime.mkdir(exist_ok=True)
    common=load('p34_frozen_runtime_common',plan['runtime_common'])
    if args.runtime_dir is None:
        lock=(runtime/'allocation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (runtime/'allocation_started.json').exists():raise ValueError('Preserve once-only allocation boundary')
        save(runtime/'private_GPU_budget_audit.json',project_audit(plan))
        save(runtime/'allocation_started.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'plan_sha256':args.plan_sha256,'admission_sha256':args.admission_sha256})
        if shutil.disk_usage('/tmp').free<48*1024**3:raise ValueError('At least48GiB private runtime scratch required')
        local=Path(tempfile.mkdtemp(prefix='bio-p34-'+os.environ['SLURM_JOB_ID']+'-'))
        evaluator_root=verify_evaluator_runtime(plan,local/'evaluator')
        save(runtime/'evaluator_runtime_receipt.json',{'at_pacific':stamp(),'root':str(evaluator_root),'plan_sha256':args.plan_sha256,'job_id':os.environ['SLURM_JOB_ID']})
        for key in ('base_runtime','cuda_overlay'):
            if sha(plan[key]['path'])!=plan[key]['sha256']:raise ValueError('Pinned Qwen runtime archive changed')
        with tarfile.open(plan['base_runtime']['path']) as archive:archive.extractall(local,filter='data')
        save(runtime/'Qwen_runtime_archive_receipt.json',{'root':str(local),**common.apply_overlay(local)})
        env=environment(common,local);python=local/'python/bin/python3.12';install_runtime(python,env,runtime)
        argv=[str(python),str(Path(__file__).resolve()),*sys.argv[1:],'--runtime-dir',str(local)]
        os.execve(argv[0],argv,env)
    local=args.runtime_dir.resolve()
    if not local.name.startswith('bio-p34-'+os.environ['SLURM_JOB_ID']+'-'):raise ValueError('Private runtime ownership mismatch')
    lock=(runtime/'protocol.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    output=Path(plan['output_root'])
    if output.exists():raise FileExistsError('No output replacement or automatic model retries')
    import importlib.metadata as metadata
    import torch
    observed={k:metadata.version(k) for k in PACKAGES}
    if any(observed[k].split('+')[0]!=v for k,v in PACKAGES.items()) or torch.cuda.device_count()!=1:
        raise ValueError('Pinned packages and one visible GPU required')
    model_dir=common.validate_checkpoint(plan['model']['served_model_name'],plan['model']['revision'])
    from transformers import AutoTokenizer
    tokenizer=AutoTokenizer.from_pretrained(model_dir,local_files_only=True)
    inputs=normalized_inputs(plan['selected_inputs'])
    save(runtime/'environment.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'hostname':socket.gethostname(),
        'packages':observed,'visible_gpu_count':1,'model_revision':plan['model']['revision'],'dtype':'bfloat16','tensor_parallel_size':1})
    server=None;evaluator_process=None
    try:
        save(runtime/'private_GPU_audit_before_Qwen_start.json',project_audit(plan))
        with socket.socket() as probe:probe.bind(('127.0.0.1',8497))
        command=[str(local/'python/bin/python3.12'),'-m','vllm.entrypoints.cli.main','serve',str(model_dir),
            '--served-model-name',plan['model']['served_model_name'],'--host','127.0.0.1','--port','8497','--dtype','bfloat16',
            '--tensor-parallel-size','1','--gpu-memory-utilization','0.85','--max-model-len','65536','--max-num-seqs','1',
            '--max-num-batched-tokens','8192','--reasoning-parser','qwen3','--enable-prefix-caching',
            '--logits-processors','p34_unique20_logits:P34Unique20LogitsProcessor']
        current(runtime/'status.json',{'at_pacific':stamp(),'stage':'starting_independent_P34_server','job_id':os.environ['SLURM_JOB_ID']})
        with (runtime/'server.log').open('x') as log:
            server=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,cwd=local)
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));deadline=time.monotonic()+1800
        while time.monotonic()<deadline:
            if server.poll() is not None:raise RuntimeError('Own constrained server exited before readiness')
            try:
                with opener.open('http://127.0.0.1:8497/health',timeout=3) as response:
                    if response.status==200:break
            except (OSError,urllib.error.URLError):time.sleep(3)
        else:raise TimeoutError('Own Qwen readiness deadline')
        with opener.open(plan['endpoint']+'/models',timeout=5) as response:models=json.load(response)
        if [r['id'] for r in models['data']]!=[plan['model']['served_model_name']]:raise ValueError('Own Qwen model identity mismatch')
        identity=runtime/'server_identity.json';save(identity,{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'hostname':socket.gethostname(),
            'pid':server.pid,'proc_start_ticks':common.start_ticks(server.pid),'endpoint':plan['endpoint'],'model':plan['model'],
            'server_command':command,'plan_sha256':args.plan_sha256})
        save(runtime/'private_GPU_audit_before_evaluator.json',project_audit(plan))
        extracted=read(runtime/'evaluator_runtime_receipt.json')
        if extracted['job_id']!=os.environ['SLURM_JOB_ID'] or extracted['plan_sha256']!=args.plan_sha256:raise ValueError('Evaluator runtime belongs to another allocation')
        evaluator_root=Path(extracted['root']);env=evaluator_environment(evaluator_root,os.environ)
        ecommand=[str(evaluator_root/'python/bin/python3.10'),str(HERE/'surrogate_service.py'),
            '--plan',str(args.plan),'--plan-sha256',args.plan_sha256,'--admission',str(args.admission),
            '--admission-sha256',args.admission_sha256,'--work',str(local/'surrogate_work')]
        with (runtime/'evaluator.log').open('x') as log:
            evaluator_process=subprocess.Popen(ecommand,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,text=True,
                bufsize=1,env=env,start_new_session=True,cwd=local)
        evaluator=SurrogateClient(evaluator_process);ready=evaluator.receive(900)
        if ready.get('ready') is not True or ready['job_id']!=os.environ['SLURM_JOB_ID'] or ready['plan_sha256']!=args.plan_sha256:
            raise ValueError('Own released evaluator identity mismatch')
        save(runtime/'evaluator_ready.json',ready)
        gate=runtime/'neutral_evaluator_gate';gate.mkdir()
        gate_records=[]
        for name in LANDSCAPES:
            e,values=score_once(gate,'P34-NEUTRAL-'+name,name,neutral_evaluator_sequences(),evaluator,'neutral_gate')
            gate_records.append(e)
            if values is None:raise RuntimeError('Co-resident neutral released evaluator delivery gate failed')
        save(gate/'completion.json',{'at_pacific':stamp(),'passed':True,'records':gate_records,'benchmark_cases':0,'neutral_forward_batches':5,'neutral_sequences':20,'sequences_per_batch':4,'sequence_length':439,'Qwen_co_resident':True})
        output.mkdir();transport=LocalTransport(plan,identity,common,tokenizer)
        current(runtime/'status.json',{'at_pacific':stamp(),'stage':'P34_neutral_Qwen_delivery_gate','job_id':os.environ['SLURM_JOB_ID']})
        development=run(plan,output/'development',[],transport,evaluator,development=True)
        if not development['all_delivered']:raise RuntimeError('Neutral two-case proposal gate failed; no benchmark dispatch')
        save(runtime/'private_GPU_audit_before_benchmark.json',project_audit(plan))
        current(runtime/'status.json',{'at_pacific':stamp(),'stage':'P34_1000_round_parent_pool_loop_live','job_id':os.environ['SLURM_JOB_ID']})
        benchmark=run(plan,output/'benchmark',inputs,transport,evaluator)
        stop_process(evaluator_process);evaluator_process=None;stop_process(server);server=None
        score=aggregate(plan,output/'benchmark');score.update(at_pacific=stamp(),plan_sha256=args.plan_sha256,
            neutral_evaluator_gate_sha256=sha(gate/'completion.json'),development_prediction_lock_sha256=sha(output/'development/prediction_lock.json'))
        save(output/'scores.json',score)
        save(runtime/'terminal_receipt.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'full_primary_metric_defined':score['full_primary_metric_defined'],'score_sha256':sha(output/'scores.json')})
        current(runtime/'status.json',{'at_pacific':stamp(),'stage':'P34_terminal_defined_surrogate_scores' if score['full_primary_metric_defined'] else 'P34_terminal_undefined_full_metric',
            'job_id':os.environ['SLURM_JOB_ID'],'score_sha256':sha(output/'scores.json')})
    except Exception as error:
        current(runtime/'status.json',{'at_pacific':stamp(),'stage':'stopped_for_review','job_id':os.environ.get('SLURM_JOB_ID'),
            'error_type':type(error).__name__,'error':str(error),'no_automatic_retry':True})
        raise
    finally:
        stop_process(evaluator_process);stop_process(server)


if __name__=='__main__':main()
