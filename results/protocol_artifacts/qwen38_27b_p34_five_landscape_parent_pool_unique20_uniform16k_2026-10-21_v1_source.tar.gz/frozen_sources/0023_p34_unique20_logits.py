"""Dedicated pinned vLLM0.32 legacy API constraint; no model loading here."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
from vllm.v1.sample.logits_processor import AdapterLogitsProcessor
from unique20_core import CONDITION,RequestConstraint,TokenVocabulary,validate_parents
from bound_request import canonical,digest
TOKENIZER_PATH=Path('/dfs/scratch0/tchen/models/Qwen3.8-27B/tokenizer.json')
TOKENIZER_SHA256='0997f410c57a1f4e53b09e4be8f4a172d90edd9564368fb0847030937229b9f3'
EOS_IDS={248044,248046}
ARG_KEYS={'p34_condition','p34_parents','p34_parents_sha256','p34_context_sha256'}


def validate_request_params(params):
    args=params.extra_args
    if not isinstance(args,dict) or set(args)!=ARG_KEYS or args['p34_condition']!=CONDITION:
        raise ValueError('Dedicated P34 server requires exact constraint fields')
    parents=json.loads(args['p34_parents']);validate_parents(parents)
    if args['p34_parents']!=canonical(parents) or digest(parents)!=args['p34_parents_sha256']:
        raise ValueError('Full parent-pool identity mismatch')
    if (not isinstance(args['p34_context_sha256'],str) or len(args['p34_context_sha256'])!=64 or
        any(c not in '0123456789abcdef' for c in args['p34_context_sha256'])):
        raise ValueError('Public objective/prompt context binding required')
    if getattr(params,'n',1)!=1:raise ValueError('Exactly one output without selective retries')
    return parents


class P34Unique20LogitsProcessor(AdapterLogitsProcessor):
    @classmethod
    def validate_params(cls,params):validate_request_params(params)
    def __init__(self,vllm_config,device,is_pin_memory):
        if importlib.metadata.version('vllm')!='0.32.0' or os.environ.get('VLLM_USE_V2_MODEL_RUNNER')!='0':
            raise ValueError('Pinned legacy vLLM0.32 runner required')
        if vllm_config.speculative_config is not None:raise ValueError('Speculation disabled')
        if Path(vllm_config.model_config.model).resolve()!=TOKENIZER_PATH.parent.resolve():raise ValueError('Wrong model path')
        super().__init__(vllm_config,device,is_pin_memory)
        self.vocabulary=TokenVocabulary.from_checkpoint_tokenizer(TOKENIZER_PATH,TOKENIZER_SHA256,EOS_IDS)
    def is_argmax_invariant(self):return False
    def apply(self,logits):
        if set(self.req_info)!=set(range(logits.shape[0])):raise ValueError('Every active row requires P34 state')
        return super().apply(logits)
    def new_req_logits_processor(self,params):return RequestConstraint(validate_request_params(params),self.vocabulary)
