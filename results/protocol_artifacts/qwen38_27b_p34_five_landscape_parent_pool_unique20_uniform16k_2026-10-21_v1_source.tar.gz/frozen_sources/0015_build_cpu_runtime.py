"""Package the existing released P34 CPU environment; no model forward."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
import os
import subprocess
import tarfile
import tempfile

HERE = Path(__file__).resolve().parent
ROOTS = {
    'python': Path('/tmp/bio-p37-omegafold2-runtime-20261020/interpreters/cpython-3.10.18-linux-x86_64-gnu'),
    'site-packages': Path('/tmp/bio-p34-released-evaluator-cpu-20261020/lib/python3.10/site-packages'),
}


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    archive, manifest = HERE/'CPU_evaluator_runtime.tar', HERE/'CPU_evaluator_runtime_manifest.json'
    if archive.exists() or manifest.exists():
        raise FileExistsError('Preserve the prior runtime artifact')
    members = {}
    temporary = archive.with_suffix('.tmp')
    with tarfile.open(temporary,'w',dereference=True) as tar:
        for prefix, root in ROOTS.items():
            if not root.is_dir():
                raise ValueError('Existing pinned runtime is unavailable on this CPU host')
            for path in sorted(root.rglob('*')):
                if not path.is_file():
                    continue
                name = prefix+'/'+str(path.relative_to(root))
                members[name] = {'sha256':sha(path),'bytes':path.stat().st_size}
                tar.add(path,arcname=name,recursive=False)
    temporary.rename(archive)
    relocated = Path(tempfile.mkdtemp(prefix='p34-CPU-portability-proof-'))
    with tarfile.open(archive) as tar:
        tar.extractall(relocated,filter='data')
    env = {key:value for key,value in os.environ.items()
           if not any(part in key.upper() for part in ('TOKEN','SECRET','PASSWORD','CREDENTIAL','API_KEY'))}
    for key in ('CUDA_HOME','CUDA_PATH','CUDACXX','NVCC','CMAKE_CUDA_COMPILER',
                'LD_PRELOAD','CC','CXX','VIRTUAL_ENV'):
        env.pop(key,None)
    env.update(PYTHONHOME=str(relocated/'python'),PYTHONPATH=str(relocated/'site-packages'),
        LD_LIBRARY_PATH=str(relocated/'python/lib')+':'+str(relocated/'site-packages/torch/lib'),
        PATH='/usr/local/bin:/usr/bin:/bin',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',
        CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
        OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    probe = '''import torch,transformers,numpy,json,platform
def forbid(*args,**kwargs): raise RuntimeError("Model forwards forbidden in runtime assembly")
guard=torch.nn.modules.module.register_module_forward_pre_hook(forbid)
assert torch.__version__=="1.13.1+cpu" and transformers.__version__=="4.36.1"
assert numpy.__version__=="1.26.4" and not torch.cuda.is_initialized()
print(json.dumps({"python":platform.python_version(),"torch":torch.__version__,"transformers":transformers.__version__,"numpy":numpy.__version__,"torch_file":torch.__file__,"model_forwards":0,"CUDA_initialized":False}))
'''
    result = subprocess.run([str(relocated/'python/bin/python3.10'),'-c',probe],env=env,
                            capture_output=True,text=True,check=True,timeout=120)
    identity = json.loads(result.stdout)
    if not Path(identity['torch_file']).is_relative_to(relocated):
        raise ValueError('Evaluator import escaped the relocated runtime')
    record = {'at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        'stage':'portable_exact_CPU_evaluator_runtime_import_verified_no_forward',
        'job_id':os.environ.get('SLURM_JOB_ID'),'archive':str(archive),
        'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
        'file_count':len(members),'source_bytes':sum(row['bytes'] for row in members.values()),
        'files':members,'identity':identity,'proof_extraction_root':str(relocated),
        'source_environment_modified':False,'model_forwards':0,'GPU_allocations':0}
    with manifest.open('x') as stream:
        json.dump(record,stream,indent=2);stream.write('\n')
    with (HERE/'portable_CPU_runtime_validation.json').open('x') as stream:
        json.dump({k:v for k,v in record.items() if k!='files'},stream,indent=2);stream.write('\n')
    print(json.dumps({k:record[k] for k in ('stage','job_id','archive_sha256','file_count','source_bytes','model_forwards')}))


if __name__ == '__main__':
    main()
