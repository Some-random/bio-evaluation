"""Own-allocation isolated released ESM1b/head process, private stdin/stdout RPC."""
import argparse
import contextlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
from admission import validate
from p34_runner import read,sha,stamp,finite_scores,LANDSCAPES,neutral_evaluator_sequences
from unique20_core import validate_parents
HERE=Path(__file__).resolve().parent


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def validate_request(request,lengths,seen):
    if set(request)!={'case_id','landscape','sequences','phase','batch_size'} or request['batch_size']!=4:
        raise ValueError('Exact private evaluator request schema required')
    cid=request['case_id'];name=request['landscape'];sequences=request['sequences'];phase=request['phase']
    if not isinstance(cid,str) or cid in seen or name not in LANDSCAPES:raise ValueError('Unknown landscape or repeated evaluator attempt')
    validate_parents(sequences)
    if phase=='neutral_gate':
        if not cid.startswith('P34-NEUTRAL-') or sequences!=neutral_evaluator_sequences():
            raise ValueError('Neutral resource gate requires exact artificial batch4x439')
    elif phase in {'benchmark_start','benchmark_round'}:
        if len(sequences)!=(1 if phase=='benchmark_start' else 20) or any(len(s)!=lengths[name] for s in sequences):
            raise ValueError('Native complete candidate count and fixed source length required')
    else:raise ValueError('Unknown evaluator phase')


def main():
    parser=argparse.ArgumentParser()
    for n in ('plan','admission','work'):parser.add_argument('--'+n,type=Path,required=True)
    for n in ('plan-sha256','admission-sha256'):parser.add_argument('--'+n,required=True)
    args=parser.parse_args();p=validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256)
    import torch,transformers
    if torch.__version__!='1.13.1+cu117' or transformers.__version__!='4.36.1' or torch.cuda.device_count()!=1:
        raise ValueError('Exact portable evaluator and one allocation-visible GPU required')
    helper=load('p34_evaluator_GPU_budget',p['project_gpu_audit_helper']);helper.conservative_project_gpu_audit(require_own_job=True)
    torch.manual_seed(42);torch.set_num_threads(4)
    work=args.work;work.mkdir(exist_ok=False)
    parent=work/'binding';parent.mkdir();binding=parent/'work';binding.mkdir()
    for source in p['assembly_parent_sources']:
        shutil.copyfile(source,parent/Path(source).name)
    shutil.copyfile(p['assembly_input_pins'],binding/'runtime_input_pins.json')
    assembler=load('p34_released_runtime_assembly',p['runtime_assembly'])
    with contextlib.redirect_stdout(sys.stderr):
        encoder,tokenizer,models,loading,heads,metadata=assembler.assemble_released_runtime(torch,transformers,Path(p['repo_root']),binding)
        if set(models)!=set(LANDSCAPES):raise ValueError('Native selected five-head scope changed')
        for model in models.values():model.to(torch.device('cuda:0'));model.device=torch.device('cuda:0');model.eval()
    lengths={r['landscape']:len(r['starting_sequence']) for r in read(p['selected_inputs'])['cases']}
    print(json.dumps({'ready':True,'pid':os.getpid(),'job_id':os.environ['SLURM_JOB_ID'],'plan_sha256':args.plan_sha256,
        'device':'cuda:0','torch':torch.__version__,'transformers':transformers.__version__,
        'head_count':5,'initial_load_model_forwards':0,'loading_info':loading}),flush=True)
    seen=set();forward_batches=0
    for line in sys.stdin:
        try:
            request=json.loads(line)
            validate_request(request,lengths,seen)
            cid=request['case_id'];name=request['landscape'];sequences=request['sequences'];phase=request['phase']
            # Validate full token sizes before the unchanged native forward,
            # whose own tokenizer retains the released max_length1024 behavior.
            full=tokenizer(sequences,add_special_tokens=True,truncation=False,padding=False)
            if any(len(ids)>1024 for ids in full['input_ids']):raise ValueError('No silent native evaluator truncation')
            seen.add(cid);values=[]
            with torch.no_grad():
                for start in range(0,len(sequences),4):
                    scores=models[name](sequences[start:start+4]).detach().reshape(-1).cpu().tolist()
                    values.extend(scores);forward_batches+=1
            finite_scores(values,len(sequences))
            print(json.dumps({'case_id':cid,'landscape':name,'sequence_sha256':[__import__('hashlib').sha256(s.encode()).hexdigest() for s in sequences],
                'scores':values,'batch_size':4,'device':'cuda:0'},allow_nan=False),flush=True)
        except Exception as error:
            print(json.dumps({'error_type':type(error).__name__,'error':str(error),'stopped':True,'forward_batches_observed':forward_batches}),flush=True)
            raise


if __name__=='__main__':main()
