"""Freeze executable five-landscape candidate; this creates no model admission."""
from pathlib import Path
import json
from p34_runner import CONDITION,LANDSCAPES,planned_ids,read,save,sha,stamp
from admission import SCOPE
HERE=Path(__file__).resolve().parent
TASK=HERE.parent
ROOT=TASK.parents[3]


def path_from(value):
    p=Path(value);return p if p.is_absolute() else ROOT/p


def main():
    if (HERE/'plan.json').exists():raise FileExistsError('Preserve frozen candidate; review any revision separately')
    cpu=read(HERE/'CPU_validation.json');api=read(HERE/'checkpoint_CPU_validation.json')
    if cpu['tests_passed']!=24 or api['checks_passed']!=13 or any(cpu[k]!=0 for k in ('model_calls','model_forwards','GPU_allocations')):
        raise ValueError('Complete artificial-loop and exact tokenizer/API CPU proof required')
    proof=read(HERE/'CPU_plan.json')
    for name,digest in proof['files_sha256'].items():
        if sha(name)!=digest:raise ValueError('Source changed after CPU tests: '+name)
    scope=read(HERE/'input_scope_review.json');selected=read(HERE/'selected_starting_inputs.json')['cases']
    if scope['reviewed']!=5 or scope['admitted']!=5 or scope['held_unacquired_landscape_opened'] or scope['measurement_reference_files_opened']:
        raise ValueError('Exact five separately reviewed ordinary input scope required')
    if [r['landscape'] for r in selected]!=LANDSCAPES:raise ValueError('Five-landscape identity/order mismatch')
    assets=ROOT/'.local/source_acquisition_2026-10-19/evaluators'
    parent=TASK/'engineering_20261020'
    assembly=parent/'encoder_binding_v1'
    native=ROOT/'.local/source_acquisition_2026-10-19/mutadescribe_sources/source/mutaplm'
    helper=ROOT/'scripts/project_gpu_audit_20261021.py'
    if sha(helper)!='9045eaf578e27dedcd5aba285b5a6253240244d70f52b7ad93e0dd7c0ecf9cc9':raise ValueError('Root project GPU audit helper changed')
    v06=read(ROOT/'.local/catalog_execution_2026-10-20/tasks/V06/local_execution_v2/plan.json')
    runtime=HERE/'CUDA_evaluator_runtime_v1/runtime_manifest.json'
    m=read(runtime)
    if m['identity']['torch']!='1.13.1+cu117' or m['identity']['transformers']!='4.36.1' or m['model_forwards']!=0 or m['GPU_allocations']!=0:
        raise ValueError('Independent relocated native evaluator runtime import proof required')
    if sha(m['archive'])!=m['archive_sha256']:raise ValueError('Official evaluator runtime archive changed')
    files=[*HERE.glob('*.py'),HERE/'worker.sbatch',HERE/'README.md',HERE/'CPU_plan.json',HERE/'CPU_validation.json',
        HERE/'checkpoint_CPU_validation.json',HERE/'selected_starting_inputs.json',HERE/'input_scope_review.json',
        HERE/'constraint_source_provenance.json',runtime,HERE/'CUDA_evaluator_runtime_v1/completion.json',
        HERE/'CUDA_evaluator_runtime_v1/official_source_receipt.json',HERE/'CUDA_evaluator_runtime_v1/exact_dependencies_without_torch.txt',
        parent/'evaluator_adapter.py',parent/'sequence_models_structure.py',parent/'sequence_models_convolutional.py',
        assembly/'runtime_assembly.py',assembly/'runtime_input_pins.json',assembly/'completion.json',
        native/'evaluator.py',native/'model/esm_landscape.py',native/'model/modeling_esm.py',native/'model/mutaplm.py',
        native/'dataset/fitness_dataset.py',native/'scripts/optimize/mutaplm.sh',helper,
        Path(v06['runtime_common']),Path(v06['checkpoint_audit']),Path(proof['tokenizer'])]
    for row in read(assembly/'runtime_input_pins.json')['files']:files.append(ROOT/row['path'])
    for row in read(assets/'esm1b_metadata_manifest.json')['assets']:files.append(path_from(row['path']))
    weight=assets/'weights/esm1b_pytorch_model.bin';files.append(weight)
    if sha(weight)!='ebb8a35768179581f91fc01b93cf78facba2821c3bab1452abb38ef2a7f6e7b1':raise ValueError('Existing encoder weight changed')
    for row in selected:
        for key,hashkey in [('starting_sequence_source','starting_sequence_source_sha256'),('evaluator_head_source','evaluator_head_sha256')]:
            path=path_from(row[key]);files.append(path)
            if sha(path)!=row[hashkey]:raise ValueError('Exact selected input/head changed')
    files += [Path(p) for p in proof['files_sha256']]
    pins={str(p):sha(p) for p in sorted(set(files))}
    plan={'schema_version':1,'task_id':'P34','condition_id':CONDITION,'stage':'frozen_candidate_not_admitted','created_at_pacific':stamp(),
        'run_id':'qwen38_27b_p34_five_landscape_parent_pool_unique20_uniform16k_2026-10-21_v1',
        'landscapes':LANDSCAPES,'runs_per_landscape':20,'rounds_per_run':10,'candidates_per_round':20,
        'planned_case_ids':planned_ids(),'planned_round_requests':1000,'planned_candidate_scores':20000,'planned_starting_scores':100,
        'generation':{'max_tokens':16384,'temperature':1.0,'top_p':.95,'top_k':20,'enable_thinking':False,'n':1,'concurrency':1,'seed_base':42},
        'seed_formula':'42+landscape_index*100000+run_index*100+round_index; artificial development1000000,1000001',
        'gpus_requested':1,'project_gpu_ceiling':8,'tensor_parallel_size':1,'Qwen_gpu_memory_utilization':.85,
        'endpoint':'http://127.0.0.1:8497/v1','model':{'served_model_name':v06['model_configuration']['model'],'revision':v06['model_configuration']['revision'],'precision':'BF16'},'base_runtime':v06['base_runtime'],'cuda_overlay':v06['cuda_overlay'],
        'runtime_common':v06['runtime_common'],'checkpoint_audit':v06['checkpoint_audit'],'project_gpu_audit_helper':str(helper),
        'repo_root':str(ROOT),'selected_inputs':str(HERE/'selected_starting_inputs.json'),'output_root':str(HERE/'runtime/run_v1'),
        'runtime_assembly':str(assembly/'runtime_assembly.py'),'assembly_input_pins':str(assembly/'runtime_input_pins.json'),
        'assembly_parent_sources':[str(parent/n) for n in ('evaluator_adapter.py','sequence_models_structure.py','sequence_models_convolutional.py')],
        'evaluator_adapter':str(parent/'evaluator_adapter.py'),'evaluator_runtime_manifest':str(runtime),
        'evaluator_device':'cuda:0','evaluator_batch_size':4,'neutral_resource_gate':{'head_count':5,'batch_size':4,'sequence_length':439,'Qwen_co_resident':True,'artificial_only':True},'evaluator_weights_modified':False,'new_training':False,
        'input_scope_review_sha256':sha(HERE/'input_scope_review.json'),'full_paper_scope_reproduced':False,'measured_targets_in_solver_inputs':False,
        'surrogate_scores_in_solver_inputs':False,'starting_or_candidate_selection_by_surrogate':False,
        'parent_pool_evolution':'all20 candidate sequences become next round parents without deduplication or score feedback',
        'maximum_attempts_per_operation':1,'selective_retries':False,'frozen_files_sha256':pins,
        'mandatory_actual_gates':['own constrained Qwen readiness/identity','same-GPU artificial batch4x439 forward through each of five released heads while Qwen is co-resident',
            'two artificial Qwen proposal deliveries including full20x439 parents','all complete prompts checked before each request'],
        'native_preserved':['exact five existing starting sequences/function/objective strings','unchanged released ESM1b+five decoder weights',
            'native evaluator forward,batch4,1024token envelope with explicit no-truncation guard','20runs x10rounds x20candidates',
            'per-run best-so-far maximum curve,mean and population variance with released average-curve convention'],
        'material_differences':['five reviewed available landscapes only, not full paper coverage',
            'Qwen27B full-parent-pool20action proposal replaces learned MutaPLM mutation-probability sampler',
            'canonical nonidentity amino-acid substitutions omit WT and special-token actions from native33-token sampler',
            'single constrained ordered20action JSON generation replaces native without-replacement tensor multinomial',
            'uniform16K nonthinking Qwen baseline with declared T1.0/top-p.95/top-k20 fixed seeds, not native MutaPLM sampling',
            'same-GPU isolated Torch1.13.1/cu117 released evaluator and Qwen0.85memory cache are operational resource choices'],
        'allowed_claim':'Five-landscape available-condition local Qwen proposal adaptation with exact released learned surrogate/native aggregation; no matched native MutaPLM result or experimental validation.',
        'stop_policy':'Stop every future model/evaluator operation after first observed error/refusal/truncation/empty final; preserve raw artifacts and all1,000round/20,000candidate/100initial denominators without retries.',
        'private_operational_metadata':'Keep unrelated account GPU inventories and project helper whitelist private; publish project totals/audit hashes only.',
        'actual_model_calls_by_preparation':0,'dispatch_authorized_by_this_file':False}
    save(HERE/'plan.json',plan)
    save(HERE/'admission_NOT_GRANTED_template.json',{'admitted':False,'task_id':'P34','condition_id':CONDITION,'plan_sha256':sha(HERE/'plan.json'),
        'gpu_count':1,'project_gpu_ceiling':8,'scope':SCOPE,'gpu_audit_receipt':'ROOT_MUST_SUPPLY','gpu_audit_receipt_sha256':'ROOT_MUST_SUPPLY'})
    save(HERE/'freeze_receipt.json',{'at_pacific':stamp(),'plan_sha256':sha(HERE/'plan.json'),'frozen_source_count':len(pins),
        'CPU_tests_passed':24,'tokenizer_verbatim_API_checks_passed':13,'planned_round_requests':1000,'planned_candidate_scores':20000,
        'actual_model_calls':0,'root_admission_present':False,'GPU_submission_performed':False})
    print(json.dumps({'plan_sha256':sha(HERE/'plan.json'),'frozen_source_count':len(pins)}))


if __name__=='__main__':main()
