"""One-attempt full parent-pool optimization and complete-denominator native aggregation."""
from __future__ import annotations
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from bound_request import payload,validate_payload,canonical,digest
from unique20_core import parse_proposals,validate_parents,CONDITION

LANDSCAPES=['AMIE','avGFP','E4B','LGK','UBE2I']
RUNS=20
ROUNDS=10
CANDIDATES=20
NEUTRAL_EVALUATOR_SEQUENCE=('ACDEFGHIKLMNPQRSTVWY'*22)[:439]


def neutral_evaluator_sequences():return [NEUTRAL_EVALUATOR_SEQUENCE]*4


def normalized_inputs(path):
    rows=read(path)['cases']
    return [{'landscape':r['landscape'],'function':r['native_function_prompt'],'target':r['native_optimization_target'],'sequence':r['starting_sequence']} for r in rows]


def stamp():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def read(path):return json.loads(Path(path).read_text())
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as s:
        for block in iter(lambda:s.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as s:json.dump(value,s,indent=2,allow_nan=False);s.write('\n')
def current(path,value):
    path=Path(path);tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)


class TransportError(RuntimeError):
    def __init__(self,message,status=None,body=None):super().__init__(message);self.status=status;self.body=body


def decode_response(raw,parents):
    """Observed final status is distinct from missing/unparseable transport envelopes."""
    outcome={'status':'response_error','final_status':'unknown','truncation':False,'refusal':False}
    try:
        body=json.loads(raw)
        if not isinstance(body,dict) or len(body.get('choices',[]))!=1:raise ValueError('Exactly one response choice required')
        choice=body['choices'][0];msg=choice['message'];final=msg.get('content')
        outcome.update(finish_reason=choice.get('finish_reason'),usage=body.get('usage'))
        if final is None or final=='':outcome['final_status']='observed_empty'
        elif isinstance(final,str):outcome['final_status']='observed_nonempty'
        else:raise ValueError('Final content must be text/null')
        if choice.get('finish_reason')=='length':outcome['truncation']=True;outcome['status']='truncated';return outcome,None
        if msg.get('refusal'):outcome.update(status='refusal',refusal=True);return outcome,None
        if choice.get('finish_reason')!='stop':raise ValueError('Unexpected finish reason')
        if msg.get('reasoning_content') or msg.get('reasoning'):raise ValueError('Nonthinking condition received reasoning')
        if outcome['final_status']!='observed_nonempty':outcome['status']='empty_final';return outcome,None
        candidates=parse_proposals(final,parents)
        outcome.update(status='delivered',final_sha256=hashlib.sha256(final.encode()).hexdigest())
        return outcome,candidates
    except (ValueError,TypeError,KeyError,IndexError) as error:
        outcome.update(error_type=type(error).__name__,error=str(error));return outcome,None


def call_once(root,case_id,request,parents,transport):
    folder=Path(root)/'requests'/case_id;folder.mkdir(parents=True,exist_ok=False)
    save(folder/'request.json',request)
    save(folder/'attempt.json',{'case_id':case_id,'at_pacific':stamp(),'request_sha256':sha(folder/'request.json'),'maximum_attempts':1})
    raw=None;candidates=None
    try:
        raw=transport.send(case_id,request)
        if not isinstance(raw,bytes):raise TransportError('Transport did not return immutable bytes')
        (folder/'response.raw.json').write_bytes(raw)
        outcome,candidates=decode_response(raw,parents)
    except TransportError as error:
        if error.body is not None:(folder/'transport_error.raw').write_bytes(error.body)
        outcome={'status':'http_error' if error.status else 'transport_error','http_status':error.status,
            'error':str(error),'final_status':'unknown','truncation':False,'refusal':False}
    except Exception as error:
        outcome={'status':'client_or_guard_error','error_type':type(error).__name__,'error':str(error),
            'final_status':'unknown','truncation':False,'refusal':False}
    outcome.update(case_id=case_id,at_pacific=stamp(),response_saved=raw is not None)
    if candidates is not None:save(folder/'candidates.json',candidates)
    save(folder/'outcome.json',outcome)
    return outcome,candidates


def finite_scores(values,expected):
    if not isinstance(values,list) or len(values)!=expected or any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in values):
        raise ValueError('Exact complete finite evaluator score list required')
    return [float(v) for v in values]


def score_once(root,case_id,landscape,sequences,evaluator,phase):
    folder=Path(root)/'evaluator'/case_id;folder.mkdir(parents=True,exist_ok=False)
    req={'case_id':case_id,'landscape':landscape,'sequences':sequences,'phase':phase,'batch_size':4}
    save(folder/'request.json',req)
    save(folder/'attempt.json',{'case_id':case_id,'at_pacific':stamp(),'request_sha256':sha(folder/'request.json'),'maximum_attempts':1})
    try:
        result=evaluator.score(req)
        save(folder/'response.json',result)
        if (set(result)!={'case_id','landscape','sequence_sha256','scores','batch_size','device'} or
            result['case_id']!=case_id or result['landscape']!=landscape or result['batch_size']!=4 or
            result['sequence_sha256']!=[hashlib.sha256(s.encode()).hexdigest() for s in sequences]):
            raise ValueError('Evaluator response identity mismatch')
        values=finite_scores(result['scores'],len(sequences))
        status={'case_id':case_id,'status':'scored','at_pacific':stamp(),'count':len(values)}
    except Exception as error:
        values=None;status={'case_id':case_id,'status':'evaluator_error','at_pacific':stamp(),'error_type':type(error).__name__,'error':str(error)}
    save(folder/'outcome.json',status)
    return status,values


def planned_ids(development=False):
    if development:return ['P34-DEV-0000','P34-DEV-0001']
    return [f'P34-{name}-run{run:02d}-round{rnd:02d}' for name in LANDSCAPES for run in range(RUNS) for rnd in range(ROUNDS)]


def summarize(records,planned,evaluator_records):
    return {'planned':planned,'attempted_confirmed':len(records),'terminal':len(records),
        'responses_saved':sum(r['response_saved'] for r in records),'not_dispatched':planned-len(records),
        'delivered':sum(r['status']=='delivered' for r in records),
        'transport_errors':sum(r['status']=='transport_error' for r in records),
        'http_errors':sum(r['status']=='http_error' for r in records),
        'client_or_guard_errors':sum(r['status']=='client_or_guard_error' for r in records),
        'response_errors':sum(r['status']=='response_error' for r in records),
        'truncations':sum(r['truncation'] for r in records),
        'empty_finals':sum(r['final_status']=='observed_empty' for r in records),
        'final_status_unknown':sum(r['final_status']=='unknown' for r in records),
        'refusals':sum(r['refusal'] for r in records),
        'evaluator_errors':sum(r['status']=='evaluator_error' for r in evaluator_records),
        'evaluator_values_saved':sum(r.get('count',0) for r in evaluator_records if r['status']=='scored')}


def seal(root,records,evaluator_records,ids,stopped,development):
    root=Path(root);unattempted=ids[len(records):]
    save(root/'terminal_records.json',records);save(root/'evaluator_terminal_records.json',evaluator_records)
    save(root/'not_dispatched.json',unattempted)
    files={str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file() and p.name not in {'progress.json'}}
    save(root/'prediction_lock.json',{'condition_id':CONDITION,'case_ids':ids,'files_sha256':files,'selective_retries':False})
    summary=summarize(records,len(ids),evaluator_records)
    summary.update(at_pacific=stamp(),condition_id=CONDITION,development_delivery_only=development,
        all_delivered=len(records)==len(ids) and all(r['status']=='delivered' for r in records) and not stopped,
        stopped_reason=stopped,prediction_lock_sha256=sha(root/'prediction_lock.json'))
    save(root/'completion.json',summary);current(root/'progress.json',summary)
    return summary


def run(plan,root,inputs,transport,evaluator,development=False):
    root=Path(root);root.mkdir(parents=True,exist_ok=False)
    records=[];eval_records=[];ids=planned_ids(development);stopped=None
    if development:
        cases=[({'landscape':'artificial','function':'Artificial delivery fixture only','target':'Return valid actions without biological objective'},
                ['ACDEFGHIKLMNPQRSTVWYACDEFGHIKLMNPQRSTV'],1000000),
               ({'landscape':'artificial','function':'Artificial maximum-parent delivery fixture only','target':'Return valid actions without biological objective'},
                [('ACDEFGHIKLMNPQRSTVWY'*22)[:439]]*20,1000001)]
        for index,(case,parents,seed) in enumerate(cases):
            request=payload(plan,case,parents,seed);validate_payload(request,case,parents,seed,plan)
            record,candidates=call_once(root,ids[index],request,parents,transport);records.append(record)
            current(root/'progress.json',dict(at_pacific=stamp(),**summarize(records,len(ids),eval_records)))
            if record['status']!='delivered':stopped='development_'+record['status'];break
        return seal(root,records,eval_records,ids,stopped,True)
    if [r['landscape'] for r in inputs]!=LANDSCAPES:raise ValueError('Exact five-landscape order required')
    for li,row in enumerate(inputs):
        case={key:row[key] for key in ('landscape','function','target')}
        initial=row['sequence'];validate_parents([initial])
        for run_index in range(RUNS):
            parents=[initial]
            baseline_id=f'P34-{row["landscape"]}-run{run_index:02d}-initial'
            e,baseline=score_once(root,baseline_id,row['landscape'],parents,evaluator,'benchmark_start');eval_records.append(e)
            if baseline is None:stopped='starting_evaluator_error';break
            for round_index in range(ROUNDS):
                cid=ids[len(records)];seed=42+li*100000+run_index*100+round_index
                request=payload(plan,case,parents,seed);validate_payload(request,case,parents,seed,plan)
                record,candidates=call_once(root,cid,request,parents,transport);records.append(record)
                if record['status']!='delivered':stopped='proposal_'+record['status'];break
                sequences=[candidate['sequence'] for candidate in candidates]
                e,values=score_once(root,cid,row['landscape'],sequences,evaluator,'benchmark_round');eval_records.append(e)
                current(root/'progress.json',dict(at_pacific=stamp(),**summarize(records,len(ids),eval_records)))
                if values is None:stopped='round_evaluator_error';break
                # Match native pool evolution: all20 candidates, including any
                # repeated sequence from different parent-index actions; no fitness feedback.
                parents=sequences
            if stopped:break
        if stopped:break
    return seal(root,records,eval_records,ids,stopped,False)


def verified_records(root):
    root=Path(root);completion=read(root/'completion.json');lock_path=root/'prediction_lock.json'
    if completion['prediction_lock_sha256']!=sha(lock_path):raise ValueError('Completion lock mismatch')
    lock=read(lock_path)
    for name,digest_ in lock['files_sha256'].items():
        p=Path(name)
        if p.is_absolute() or '..' in p.parts or (root/p).is_symlink() or sha(root/p)!=digest_:raise ValueError('Locked outcome changed')
    if lock['case_ids']!=planned_ids(False):raise ValueError('Native denominator changed')
    records=read(root/'terminal_records.json');evaluations=read(root/'evaluator_terminal_records.json')
    if [r['case_id'] for r in records]!=planned_ids(False)[:len(records)]:raise ValueError('Terminal order or identity changed')
    expected=summarize(records,1000,evaluations)
    if any(completion.get(key)!=value for key,value in expected.items()):raise ValueError('Closure counts do not reconcile with locked outcomes')
    if read(root/'not_dispatched.json')!=planned_ids(False)[len(records):]:raise ValueError('Untouched full denominator changed')
    return completion,records,evaluations


def aggregate(plan,root):
    root=Path(root);complete,records,evaluations=verified_records(root)
    result={'condition_id':CONDITION,'full_primary_metric_defined':False,'planned_landscapes':5,'runs_per_landscape':20,
        'rounds_per_run':10,'candidates_per_round':20,'planned_round_requests':1000,'planned_candidate_scores':20000,
        'planned_initial_scores':100,'generation_completion':complete,'landscapes':{},
        'metric_qualification':'Released learned surrogate fitness only; not experimental activity or matched native MutaPLM proposal distribution.',
        'prediction_lock_sha256':sha(root/'prediction_lock.json')}
    if not complete['all_delivered'] or len(records)!=1000 or len(evaluations)!=1100 or any(r['status']!='scored' for r in evaluations):return result
    spec=importlib.util.spec_from_file_location('p34_native_aggregation',plan['evaluator_adapter']);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    for name in LANDSCAPES:
        histories=[];initial=[]
        for run_index in range(RUNS):
            initial_id=f'P34-{name}-run{run_index:02d}-initial'
            initial.extend(read(root/'evaluator'/initial_id/'response.json')['scores'])
            rounds=[]
            for rnd in range(ROUNDS):
                cid=f'P34-{name}-run{run_index:02d}-round{rnd:02d}'
                rounds.append(finite_scores(read(root/'evaluator'/cid/'response.json')['scores'],20))
            histories.append(rounds)
        result['landscapes'][name]={'starting_fitness':finite_scores(initial,20),'native_round_curves':module.aggregate_complete_histories(histories)}
    result['full_primary_metric_defined']=True
    return result
