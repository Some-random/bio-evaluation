"""Publication privacy/immutability tests, no actual result or model access."""
import io
from pathlib import Path
import tarfile
import tempfile
import types
import unittest
from verify_and_package import safe,package,sanitized_source_name,load,ROOT


class Tests(unittest.TestCase):
    def test_private_GPU_inventory_runtime_and_weight_members_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.json';p.write_text('{}')
            for name in ('../x','/abs','runtime/private_GPU_audit.json'):
                with self.assertRaises(ValueError):safe(name,p)
            for suffix in ('.pt','.bin','.safetensors','.tar','.whl'):
                w=Path(d)/('weight'+suffix);w.write_bytes(b'not a real asset')
                with self.assertRaises(ValueError):safe(w.name,w)

    def test_members_preserve_exact_bytes_and_existing_archive_never_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'response.json';p.write_bytes(b'{"final":"artificial"}\n')
            out=Path(d)/'archive.tar.gz';seen=[];scanner=types.SimpleNamespace(scan_file=lambda path:seen.append(Path(path)))
            receipt=package(out,{'raw/response.json':p},scanner)
            self.assertEqual(receipt['member_count'],1)
            with tarfile.open(out) as tar:self.assertEqual(tar.extractfile('raw/response.json').read(),p.read_bytes())
            self.assertIn(p,seen);self.assertIn(out,seen)
            original=out.read_bytes()
            with self.assertRaises(FileExistsError):package(out,{'raw/response.json':p},scanner)
            self.assertEqual(out.read_bytes(),original)

    def test_local_origin_source_uses_safe_alias_and_passes_actual_archive_scanner(self):
        scanner=load('p34_test_actual_secret_scanner',ROOT/'scripts/daily_backup.py')
        with tempfile.TemporaryDirectory() as d:
            origin=Path(d)/'.local'/'task'/'worker.py';origin.parent.mkdir(parents=True);origin.write_text('print("artificial fixture")\n')
            alias=sanitized_source_name(7,origin)
            self.assertNotIn('.local',Path(alias).parts)
            scanner.safe_archive_member(alias)
            archive=Path(d)/'safe_source.tar.gz';package(archive,{alias:origin},scanner)
            scanner.scan_file(archive)
            with self.assertRaises(scanner.BackupError):scanner.safe_archive_member('frozen_sources/.local/task/worker.py')

    def test_secret_scan_failure_prevents_archive_creation(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'response.json';p.write_text('artificial flagged fixture');out=Path(d)/'no.tar.gz'
            def reject(path):raise ValueError('artificial secret scanner rejection')
            with self.assertRaises(ValueError):package(out,{'raw.json':p},types.SimpleNamespace(scan_file=reject))
            self.assertFalse(out.exists())


if __name__=='__main__':unittest.main()
