"""Prepare exact seven-path result publication after complete offline replay."""
from pathlib import Path
import argparse
import json

import publish_complete as publisher
from verify_and_package import EXECUTION,PLAN_SHA,read,sha,verify

HERE=Path(__file__).resolve().parent


def main():
    p=argparse.ArgumentParser();p.add_argument('--stage',type=Path,required=True)
    p.add_argument('--package-receipt',type=Path,required=True);p.add_argument('--basis',type=Path,required=True)
    p.add_argument('--output-directory',type=Path,required=True);a=p.parse_args()
    admission=EXECUTION/'root_admission.json'
    plan,score,_,_,proof=verify(admission,sha(admission),EXECUTION/'submission_receipt.json')
    package=read(a.package_receipt);basis=read(a.basis);stage=a.stage.resolve()
    if package['plan_sha256']!=PLAN_SHA or package['score_sha256']!=sha(Path(plan['output_root'])/'scores.json'):
        raise ValueError('Exact complete local package/score required')
    if basis['repository']!=publisher.REPOSITORY or basis['visibility']!='public':raise ValueError('Exact public remote basis required')
    def new_text(relative,text):
        path=stage/relative;path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('x')as stream:stream.write(text)
    values={name:item['native_round_curves'][-1]for name,item in score['landscapes'].items()}
    rows=[]
    for name in plan['landscapes']:
        item=values[name]
        rows.append(f"| {name} | {item['native_best_fitness_mean']:.6f} | {item['native_best_fitness_population_variance']:.6f} |")
    report=('# MutaPLM: iterative protein optimization with Qwen\n\n'
        'This separately declared Qwen3.8-27B condition completed all five reviewed landscapes: '
        '20 independent runs per landscape, 10 rounds per run and 20 proposals per round. '
        'All 1,000 Qwen replies and 20,000 candidate predictions plus 100 starting predictions are retained.\n\n'
        '| Landscape | Final-round best surrogate fitness, mean of 20 runs | Population variance |\n'
        '|---|---:|---:|\n'+'\n'.join(rows)+'\n\n'
        'Scores use the released ESM1b landscape heads and native best-so-far aggregation. '
        'They are learned surrogate predictions, not experimentally validated function. '
        'Qwen selects 20 unique single-substitution actions from every supplied complete parent pool; '
        'all 20 candidates become the next parents, with no fitness feedback or fitness-based parent filtering. '
        'This proposal distribution differs from the paper’s native MutaPLM sampler.\n\n'
        'The evaluated condition covers five of the paper’s six landscapes. The held sixth landscape '
        'was not dispatched, and this result does not complete the full native paper scope or the retained catalog.\n\n'
        '[Complete evaluated starting questions](questions/P34.md) · '
        f'[Exact score](../{publisher.BASE}scores.json) · '
        f'[Raw trajectories](../results/trajectory_archives/{publisher.RUN}_trajectories.tar.gz) · '
        f'[Source and protocol](../results/protocol_artifacts/{publisher.RUN}_source.tar.gz) · '
        '[MutaPLM paper](https://arxiv.org/abs/2410.22949)\n')
    new_text('reports/P34_FIVE_LANDSCAPE_OPTIMIZATION_RESULT.md',report)
    new_text(publisher.BASE+'README.md',
        '# Complete five-landscape Qwen condition\n\n'
        'All 1,000 once-only requests and 20,100 released-head predictions are sealed and independently replayed offline. '
        'This is the complete frozen available five-landscape condition, with the held sixth untouched. '
        'It is neither full native paper coverage nor experimental function validation. '
        'No GPT result is inferred for this condition.\n\n'
        '[Results and qualifications](../../../reports/P34_FIVE_LANDSCAPE_OPTIMIZATION_RESULT.md)\n')
    artifacts={'task_id':'P34','run_id':publisher.RUN,'plan_sha256':PLAN_SHA,
        'score_sha256':sha(stage/(publisher.BASE+'scores.json')),'available_landscapes':5,'native_paper_landscapes':6,
        'complete_available_condition':True,'native_full_paper_scope_complete':False,'held_sixth_landscape_dispatched':False,
        'native_MutaPLM_sampler_reproduced':False,'experimental_function_assessed':False,
        'round_requests':1000,'candidate_values':20000,'starting_values':100,
        'source_archive':{'path':'results/protocol_artifacts/'+publisher.RUN+'_source.tar.gz',
            'sha256':package['archives']['source']['sha256']},
        'trajectory_archive':{'path':'results/trajectory_archives/'+publisher.RUN+'_trajectories.tar.gz',
            'sha256':package['archives']['trajectories']['sha256']},
        'offline_replay_rounds':proof['rounds_replayed_without_models'],
        'offline_replay_head_values':proof['score_values_verified'],'model_calls_by_publication':0}
    publisher.save(stage/(publisher.BASE+'artifact_manifest.json'),artifacts)
    files={name:sha(stage/name)for name in sorted(publisher.ALLOWED)}
    support=[HERE/name for name in ['verify_and_package.py','stage_result.py','publish_complete.py','assemble_complete.py']]
    support += [publisher.ROOT/'scripts/daily_backup.py',publisher.ROOT/'.local/litqa2_replay/incremental_upload.py']
    support += [publisher.ROOT/'.local/litqa2_replay/github_credential_helper.py',publisher.ROOT/'configs/publication_destination.json',
        publisher.ROOT/'scripts/publication_destination.py',
        publisher.ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review.json']
    evidence=[EXECUTION/'plan.json',admission,EXECUTION/'submission_receipt.json',
        EXECUTION/'runtime/terminal_receipt.json',a.package_receipt,a.basis]
    m={'at_pacific':publisher.stamp(),'task_id':'P34','repository':publisher.REPOSITORY,'visibility':'public',
        'plan_sha256':PLAN_SHA,'rounds':1000,'candidate_values':20000,'starting_values':100,
        'available_landscapes':5,'native_paper_landscapes':6,'native_full_paper_scope_complete':False,
        'experimental_function_assessed':False,'held_sixth_landscape_dispatched':False,
        'shared_aggregate_paths_modified':False,'website_or_schedule_changes':False,'model_calls':0,
        'stage_directory':str(stage),'score_source':str(Path(plan['output_root'])/'scores.json'),
        'package_receipt':{'path':str(a.package_receipt.resolve()),'sha256':sha(a.package_receipt)},
        'files_sha256':files,'expected_previous_sha256':basis['expected_previous_sha256'],
        'remote_main_basis':basis['remote_main_head'],
        'support_sha256':{str(path.resolve()):sha(path)for path in support},
        'private_evidence_sha256':{str(path.resolve()):sha(path)for path in evidence},
        'delegation_sha256':'f70edf39692d5915f05bd4869b2290d9a7576bd5a89906c004aec137d7e29717'}
    a.output_directory.mkdir(parents=True,exist_ok=False)
    publisher.save(a.output_directory/'manifest.json',m)
    print(json.dumps({'stage':'prepared_scoped_publication_not_uploaded','paths':len(files),
        'manifest_sha256':sha(a.output_directory/'manifest.json'),'model_calls':0}))


if __name__=='__main__':main()
