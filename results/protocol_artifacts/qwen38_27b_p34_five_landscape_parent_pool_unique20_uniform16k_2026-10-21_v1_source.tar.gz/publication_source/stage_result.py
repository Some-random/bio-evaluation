"""Stage complete verified local score/source/trajectory/table artifacts; no remote writes."""
import argparse
import json
from pathlib import Path
import shutil
from statistics import mean
from verify_and_package import EXECUTION,PLAN_SHA,read,sha,verify


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--package-receipt',type=Path,required=True);parser.add_argument('--output-directory',type=Path,required=True);args=parser.parse_args()
    admission=EXECUTION/'root_admission.json'
    plan,score,_,_,proof=verify(admission,sha(admission),EXECUTION/'submission_receipt.json')
    package=read(args.package_receipt)
    if package['plan_sha256']!=PLAN_SHA or package.get('published') is not False:raise ValueError('Exact locally verified package required')
    for item in package['archives'].values():
        if sha(item['path'])!=item['sha256']:raise ValueError('Staged archive bytes changed')
    output=args.output_directory;output.mkdir(parents=True,exist_ok=False);run=plan['run_id']
    public_score=Path('results/runs')/run/'scores.json';target=output/public_score;target.parent.mkdir(parents=True);shutil.copyfile(Path(plan['output_root'])/'scores.json',target)
    archives={}
    for label,item in package['archives'].items():
        folder='trajectory_archives' if label=='trajectories' else 'protocol_artifacts';relative=Path('results')/folder/Path(item['path']).name
        target=output/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(item['path'],target);archives[label]={'path':str(relative),'sha256':item['sha256']}
    values={name:record['native_round_curves'][-1]['native_best_fitness_mean'] for name,record in score['landscapes'].items()}
    row={'task_id':'P34','run_id':run,'protocol_variant':plan['condition_id'],
        'protocol_description':'Five-landscape Qwen full parent pool 20-action proposal adaptation with unchanged released ESM1b landscape heads',
        'new_complete_generation':True,'full_benchmark_complete':False,'available_condition_complete':True,
        'partial_scope_metric_defined':True,'completion_scope':'Complete frozen available five-landscape condition only; not full paper scope.',
        'full_primary_metric_defined':True,'native_full_paper_scope_reproduced':False,
        'counts':{'planned':1000,'completed':1000,'parsed':1000,'invalid_outputs':0,'missing_or_failed_outputs':0,
            'candidate_scores':20000,'starting_scores':100,'landscapes':5,'runs_per_landscape':20,'rounds_per_run':10,'candidates_per_round':20},
        'finish_reasons':{'stop':1000,'length':0},'generation':plan['generation'],
        'metrics':{'native_surrogate_final_round_best_fitness_mean_by_landscape':values},
        'source_scores':str(public_score),'scores_sha256':sha(output/public_score),'prediction_lock_sha256':score['prediction_lock_sha256'],
        'config_sha256':PLAN_SHA,'case_scope':'All 5 reviewed available landscapes, 20 independent runs, 10 rounds, 20 candidates per round; all complete source sequences retained.',
        'interpretation':plan['allowed_claim'],'material_differences':plan['material_differences'],
        'trajectory_archive':archives['trajectories'],'protocol_artifact_archive':archives['source'],'not_paper_native':True}
    (output/'completed_row.json').write_text(json.dumps(row,indent=2,allow_nan=False)+'\n')
    question=output/'reports/questions/P34.md';question.parent.mkdir(parents=True)
    parts=['# MutaPLM iterative optimization — complete evaluated starting questions\n\n',
        'The five exact first-round Qwen requests are shown below. Each landscape has 20 independent runs and 10 rounds. Later rounds preserve the public objective and supply all 20 preceding candidates as parents; no measured or surrogate fitness is shown to Qwen.\n\n']
    for name in plan['landscapes']:
        cid=f'P34-{name}-run00-round00';request=read(Path(plan['output_root'])/'benchmark/requests'/cid/'request.json')
        parts.append('## '+name+'\n\n')
        for message in request['messages']:parts.append('**'+message['role'].capitalize()+'**\n\n```text\n'+message['content']+'\n```\n\n')
    parts.append('These are a separately declared Qwen canonical-action adaptation, not native MutaPLM sampling. Scoring uses released pretrained surrogate heads; no experimental activity is established.\n\n[MutaPLM paper](https://arxiv.org/abs/2410.22949) · [Back to results](../RESULTS_AND_REMAINING_WORK.md)\n')
    question.write_text(''.join(parts))
    figures='<br>'.join(f'{name}: {values[name]:.4f}' for name in plan['landscapes'])
    presentation=('| MutaPLM: Iterative protein optimization | [2024](https://arxiv.org/abs/2410.22949) | '
        'Released objective: “Increase in activity.”<br>[All five complete evaluated starting questions](questions/P34.md) | '
        'Final-round best surrogate fitness (mean of 20 runs) | '+figures+' | — | — | '
        '[MutaPLM: fitness curves; no tabulated aggregate](https://arxiv.org/html/2410.22949v1)<br>'
        'Our five-landscape Qwen proposal adaptation uses the released surrogate heads; no experimental validation or matched paper sampler. | — |')
    (output/'presentation_row.md').write_text(presentation+'\n')
    (output/'README.md').write_text('Local staged score, source, exact raw trajectories and presentation row only. Root coordination is required before shared report/decision-source edits or secure repository publication. No website or recurring updater.\n')
    print(json.dumps({'stage':'complete_verified_local_publication_tree_not_uploaded','run_id':run,'output':str(output),'score_sha256':row['scores_sha256'],'model_calls':0}))


if __name__=='__main__':main()
