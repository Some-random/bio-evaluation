"""Offline replay/closure verification and explicitly selected P34 public artifacts.

No model calls, scoring-head forwards, report mutations or remote operations.
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tarfile
HERE=Path(__file__).resolve().parent
EXECUTION=HERE.parent/'available_execution_v1'
ROOT=HERE.parents[4]
PLAN_SHA='23cff4ce746e110645cc94b60803100aac1a6364de938a8b9eda2b6ec23ba919'


def read(path):return json.loads(Path(path).read_text())
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as s:
        for block in iter(lambda:s.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def safe(name,path):
    relative=Path(name)
    if relative.is_absolute() or '..' in relative.parts or path.is_symlink() or not path.is_file():raise ValueError('Unsafe publication member')
    if any(part.startswith('private_GPU_') for part in relative.parts) or path.suffix in {'.pt','.bin','.safetensors','.tar','.whl'} or path.stat().st_size>32*1024**2:
        raise ValueError('Weights,environments and private GPU inventories must remain local')
    return str(relative)


def sanitized_source_name(index,path):
    # Preserve a separate content manifest rather than exporting workspace
    # directory names excluded by the independently enforced archive scanner.
    return 'frozen_sources/'+str(index).zfill(4)+'_'+Path(path).name


def locked(folder):
    done=read(folder/'completion.json');lock=read(folder/'prediction_lock.json')
    if done['prediction_lock_sha256']!=sha(folder/'prediction_lock.json'):raise ValueError('Completion/lock binding mismatch')
    result={}
    for name,digest in lock['files_sha256'].items():
        path=folder/name;safe(name,path)
        if sha(path)!=digest:raise ValueError('Locked output bytes changed')
        result[name]=path
    result.update({name:folder/name for name in ('completion.json','prediction_lock.json')})
    return done,lock,result


def verify(admission_path,admission_sha,submission_path):
    if sha(EXECUTION/'plan.json')!=PLAN_SHA:raise ValueError('Exact admitted P34 plan required')
    sys.path.insert(0,str(EXECUTION))
    guard=load('p34_publication_admission',EXECUTION/'admission.py')
    runner=load('p34_publication_runner',EXECUTION/'p34_runner.py')
    bound=load('p34_publication_bound',EXECUTION/'bound_request.py')
    plan=guard.validate(EXECUTION/'plan.json',PLAN_SHA,admission_path,admission_sha,require_slurm=False)
    runtime=EXECUTION/'runtime';output=Path(plan['output_root']);terminal=read(runtime/'terminal_receipt.json');submission=read(submission_path)
    if (terminal['full_primary_metric_defined'] is not True or terminal['score_sha256']!=sha(output/'scores.json') or
        submission['plan_sha256']!=PLAN_SHA or submission['admission_sha256']!=admission_sha or
        str(terminal['job_id'])!=str(submission['job_id'])):raise ValueError('Root job and defined complete score binding required')
    dev,dev_lock,dev_files=locked(output/'development');done,lock,files=locked(output/'benchmark')
    if (dev['all_delivered'] is not True or dev['planned']!=2 or dev['responses_saved']!=2 or
        dev_lock['case_ids']!=runner.planned_ids(True) or done['all_delivered'] is not True or
        done['planned']!=1000 or done['responses_saved']!=1000 or done['evaluator_values_saved']!=20100):
        raise ValueError('Separate2development/1000round/20100score complete closure required')
    gate=read(runtime/'neutral_evaluator_gate/completion.json')
    if (gate.get('passed') is not True or gate.get('neutral_forward_batches')!=5 or gate.get('neutral_sequences')!=20 or
        gate.get('sequences_per_batch')!=4 or gate.get('sequence_length')!=439 or gate.get('Qwen_co_resident') is not True):
        raise ValueError('Actual co-resident artificial five-head batch4x439 resource gate required')
    inputs=runner.normalized_inputs(plan['selected_inputs'])
    # Reconstruct the complete no-feedback transition graph from exact saved
    # requests and response bytes; never regenerate candidates or head values.
    checked_rounds=0;checked_values=0
    for li,row in enumerate(inputs):
        case={k:row[k] for k in ('landscape','function','target')}
        for run_index in range(20):
            parents=[row['sequence']]
            initial=f'P34-{row["landscape"]}-run{run_index:02d}-initial'
            request=read(output/'benchmark/evaluator'/initial/'request.json')
            if request!={'case_id':initial,'landscape':row['landscape'],'sequences':parents,'phase':'benchmark_start','batch_size':4}:
                raise ValueError('Starting surrogate input differs')
            runner.finite_scores(read(output/'benchmark/evaluator'/initial/'response.json')['scores'],1);checked_values+=1
            for rnd in range(10):
                cid=f'P34-{row["landscape"]}-run{run_index:02d}-round{rnd:02d}';folder=output/'benchmark/requests'/cid
                request=read(folder/'request.json');bound.validate_payload(request,case,parents,42+li*100000+run_index*100+rnd,plan)
                observed,candidates=runner.decode_response((folder/'response.raw.json').read_bytes(),parents)
                stored=read(folder/'outcome.json')
                if observed['status']!='delivered' or any(stored.get(k)!=v for k,v in observed.items()) or read(folder/'candidates.json')!=candidates:
                    raise ValueError('Saved action mapping differs from immutable reply')
                parents=[c['sequence'] for c in candidates]
                ereq=read(output/'benchmark/evaluator'/cid/'request.json')
                if ereq!={'case_id':cid,'landscape':row['landscape'],'sequences':parents,'phase':'benchmark_round','batch_size':4}:
                    raise ValueError('Complete source-order candidate pool differs')
                response=read(output/'benchmark/evaluator'/cid/'response.json')
                if response['case_id']!=cid or response['landscape']!=row['landscape'] or response['sequence_sha256']!=[hashlib.sha256(s.encode()).hexdigest() for s in parents]:
                    raise ValueError('Candidate scores refer to different sequences')
                runner.finite_scores(response['scores'],20);checked_rounds+=1;checked_values+=20
    if checked_rounds!=1000 or checked_values!=20100:raise ValueError('Native denominator changed')
    score=read(output/'scores.json');again=runner.aggregate(plan,output/'benchmark')
    if score.get('full_primary_metric_defined') is not True or any(score.get(k)!=v for k,v in again.items()):raise ValueError('Pure native aggregation differs from locked scores')
    if score['plan_sha256']!=PLAN_SHA:raise ValueError('Score configuration differs')
    source={'execution/plan.json':EXECUTION/'plan.json','execution/root_admission.json':Path(admission_path),
        'execution/submission_receipt.json':Path(submission_path),'execution/freeze_receipt.json':EXECUTION/'freeze_receipt.json',
        'result/scores.json':output/'scores.json'}
    omissions=[];source_map={}
    for index,(name,digest) in enumerate(sorted(plan['frozen_files_sha256'].items())):
        path=Path(name)
        if name==plan['project_gpu_audit_helper'] or path.suffix in {'.pt','.bin','.safetensors'} or not path.is_relative_to(ROOT) or name==plan['evaluator_runtime_manifest']:
            omissions.append({'source':path.name,'sha256':digest,'reason':'Private operational source, checkpoint/reference-only asset, or environment-member inventory. Scientific proposal/evaluator source is retained.'});continue
        alias=sanitized_source_name(index,path);source[alias]=path
        source_map[alias]={'workspace_relative_path':str(path.relative_to(ROOT)),'sha256':digest,'bytes':path.stat().st_size}
    for path in sorted(HERE.glob('*.py')):source['publication_source/'+path.name]=path
    for name in ('terminal_receipt.json','environment.json','server_identity.json','evaluator_ready.json'):
        source['runtime/'+name]=runtime/name
    for path in sorted((runtime/'neutral_evaluator_gate').rglob('*')):
        if path.is_file():source['runtime/neutral_evaluator_gate/'+str(path.relative_to(runtime/'neutral_evaluator_gate'))]=path
    for path in sorted((runtime/'context_observations').glob('*.json')):source['runtime/context_observations/'+path.name]=path
    trajectories={'development/'+name:path for name,path in dev_files.items()}
    trajectories.update({'benchmark/'+name:path for name,path in files.items()})
    return plan,score,source,trajectories,{'rounds_replayed_without_models':checked_rounds,'score_values_verified':checked_values,'omissions':omissions,'public_source_map':source_map}


def package(output,members,scanner):
    if output.exists():raise FileExistsError('Preserve existing package')
    manifest={}
    for name,path in members.items():
        safe(name,path);scanner.scan_file(path);manifest[name]={'sha256':sha(path),'bytes':path.stat().st_size}
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
        for name,path in sorted(members.items()):
            value=path.read_bytes();item=tarfile.TarInfo(name);item.size=len(value);item.mode=0o600;tar.addfile(item,io.BytesIO(value))
        value=(json.dumps({'files':manifest},indent=2,sort_keys=True)+'\n').encode();item=tarfile.TarInfo('publication_manifest.json');item.size=len(value);item.mode=0o600;tar.addfile(item,io.BytesIO(value))
    scanner.scan_file(output)
    return {'path':str(output),'sha256':sha(output),'bytes':output.stat().st_size,'member_count':len(members)}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output-directory',type=Path,required=True);args=parser.parse_args()
    admission=EXECUTION/'root_admission.json';plan,score,source,trajectories,proof=verify(admission,sha(admission),EXECUTION/'submission_receipt.json')
    args.output_directory.mkdir(parents=True,exist_ok=False)
    source_map=args.output_directory/'public_source_map.json'
    source_map.write_text(json.dumps({'plan_sha256':PLAN_SHA,'files':proof['public_source_map']},indent=2)+'\n')
    source['public_source_map.json']=source_map
    scanner=load('p34_publication_sensitive_scan',ROOT/'scripts/daily_backup.py')
    archives={name:package(args.output_directory/(plan['run_id']+'_'+name+'.tar.gz'),members,scanner) for name,members in [('source',source),('trajectories',trajectories)]}
    receipt={'at_pacific':__import__('datetime').datetime.now(__import__('zoneinfo').ZoneInfo('America/Los_Angeles')).isoformat(),
        'stage':'complete_verified_local_packages_not_published','plan_sha256':PLAN_SHA,'score_sha256':sha(Path(plan['output_root'])/'scores.json'),
        'archives':archives,'verification':proof,'published':False,'model_calls':0,'model_forwards':0}
    (args.output_directory/'package_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))


if __name__=='__main__':main()
