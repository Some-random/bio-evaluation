"""Full artificial1000-round publication replay, no real cases or model calls."""
from pathlib import Path
from unittest.mock import patch
import importlib.util
import json
import shutil
import sys
import tempfile
import unittest

import verify_and_package as publication


class Replay(unittest.TestCase):
    def test_actual_runner_to_full_native_shape_publication_and_wrong_prompt_refusal(self):
        actual=publication.EXECUTION
        sys.path.insert(0,str(actual))
        spec=importlib.util.spec_from_file_location('p34_artificial_recording_sources',actual/'test_execution.py')
        fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
        runner=fixture.r
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/'artificial_project';execution=root/'execution';execution.mkdir(parents=True)
            for name in ['p34_runner.py','bound_request.py','unique20_core.py']:
                shutil.copy2(actual/name,execution/name)
            # Real runtime admissions are independently tested by the frozen
            # execution suite; this explicit artificial guard has no job/GPU.
            (execution/'admission.py').write_text('import json\nfrom pathlib import Path\ndef validate(plan,*args,**kwargs): return json.loads(Path(plan).read_text())\n')
            helper=execution/'fixture_GPU_helper.py';helper.write_text('ARTIFICIAL_PRIVATE_OPERATIONS = True\n')
            environment_manifest=execution/'fixture_environment_manifest.json'
            environment_manifest.write_text('{"artificial_environment_inventory":true}\n')
            inputs=fixture.artificial_inputs();selected=execution/'selected.json'
            runner.save(selected,{'cases':[{'landscape':row['landscape'],'native_function_prompt':row['function'],
                'native_optimization_target':row['target'],'starting_sequence':row['sequence']}for row in inputs]})
            output=execution/'runtime/run_v1'
            plan={**fixture.PLAN,'output_root':str(output),'selected_inputs':str(selected),
                'project_gpu_audit_helper':str(helper),'landscapes':runner.LANDSCAPES,
                'evaluator_runtime_manifest':str(environment_manifest),
                'frozen_files_sha256':{str(execution/name):publication.sha(execution/name)
                    for name in ['admission.py','p34_runner.py','bound_request.py','unique20_core.py','fixture_GPU_helper.py']}}
            runner.save(execution/'plan.json',plan);digest=publication.sha(execution/'plan.json')
            plan['plan_sha256']=digest
            admission=execution/'root_admission.json';runner.save(admission,{'artificial_only':True})
            submission=execution/'submission_receipt.json'
            runner.save(submission,{'plan_sha256':digest,'admission_sha256':publication.sha(admission),'job_id':'artificial'})
            runner.save(execution/'freeze_receipt.json',{'artificial_only':True})
            runner.run(plan,output/'development',[],fixture.RecordingTransport(),fixture.RecordingEvaluator(),True)
            transport=fixture.RecordingTransport();evaluator=fixture.RecordingEvaluator()
            completion=runner.run(plan,output/'benchmark',inputs,transport,evaluator)
            score=runner.aggregate(plan,output/'benchmark')
            # The actual allocation worker adds this immutable execution
            # binding after the pure native aggregation returns.
            score.update(plan_sha256=digest)
            runner.save(output/'scores.json',score)
            runtime=execution/'runtime'
            runner.save(runtime/'terminal_receipt.json',{'full_primary_metric_defined':True,
                'score_sha256':publication.sha(output/'scores.json'),'job_id':'artificial'})
            gate=runtime/'neutral_evaluator_gate/completion.json'
            runner.save(gate,{'passed':True,'neutral_forward_batches':5,'neutral_sequences':20,
                'sequences_per_batch':4,'sequence_length':439,'Qwen_co_resident':True,'artificial_only':True})
            for name in ['environment.json','server_identity.json','evaluator_ready.json']:
                runner.save(runtime/name,{'artificial_only':True})
            with patch.object(publication,'ROOT',root),patch.object(publication,'EXECUTION',execution),patch.object(publication,'PLAN_SHA',digest):
                _,verified,sources,trajectories,proof=publication.verify(admission,publication.sha(admission),submission)
                self.assertEqual(proof['rounds_replayed_without_models'],1000)
                self.assertEqual(proof['score_values_verified'],20100)
                self.assertEqual(len(transport.calls),1000);self.assertEqual(len(evaluator.calls),1100)
                self.assertTrue(verified['full_primary_metric_defined'])
                self.assertIn('benchmark/requests/'+runner.planned_ids()[0]+'/response.raw.json',trajectories)
                self.assertIn('benchmark/requests/'+runner.planned_ids()[-1]+'/response.raw.json',trajectories)
                self.assertNotIn(helper,sources.values())
                # A new seal does not make a foreign prompt scientifically
                # valid. Actual request equality is independently replayed.
                case_id=runner.planned_ids()[0]
                request_path=output/'benchmark/requests'/case_id/'request.json'
                request=json.loads(request_path.read_text());request['messages'][0]['content']='Foreign artificial prompt'
                request_path.write_text(json.dumps(request))
                lock_path=output/'benchmark/prediction_lock.json';lock=json.loads(lock_path.read_text())
                lock['files_sha256'][str(request_path.relative_to(output/'benchmark'))]=publication.sha(request_path)
                lock_path.write_text(json.dumps(lock))
                completion['prediction_lock_sha256']=publication.sha(lock_path)
                (output/'benchmark/completion.json').write_text(json.dumps(completion))
                with self.assertRaisesRegex(ValueError,'Frozen prompt'):
                    publication.verify(admission,publication.sha(admission),submission)


if __name__=='__main__':unittest.main()
