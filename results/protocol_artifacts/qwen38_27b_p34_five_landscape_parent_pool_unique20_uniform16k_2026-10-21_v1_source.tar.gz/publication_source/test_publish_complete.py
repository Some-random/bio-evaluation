"""Artificial publication authorization/conflict checks; no network or models."""
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
import json
import tempfile
import unittest
import publish_complete as p
import verify_and_package as packager


class PublicationGuards(unittest.TestCase):
    def artificial_archives(self,root):
        score=root/'score.json';score.write_text('{}\n')
        source=root/'source.py';source.write_text('# Artificial frozen source\n')
        trajectory=root/'response.json';trajectory.write_text('{"artificial": true}\n')
        sources={'source.py':source};trajectories={'response.json':trajectory}
        proof={'public_source_map':{},'rounds_replayed_without_models':1000,'score_values_verified':20100}
        source_map=root/'public_source_map.json'
        source_map.write_text(json.dumps({'plan_sha256':p.PLAN_SHA,'files':{}},indent=2)+'\n')
        stage=root/'stage';stage.mkdir();archives={};artifacts={'plan_sha256':p.PLAN_SHA,'score_sha256':p.sha(score)}
        scanner=SimpleNamespace(scan_file=lambda path:None)
        for role,members in [('source',{**sources,'public_source_map.json':source_map}),('trajectories',trajectories)]:
            relative=('results/protocol_artifacts/'if role=='source'else'results/trajectory_archives/')+p.RUN+'_'+role+'.tar.gz'
            archives[role]=packager.package(stage/relative,members,scanner)
            artifacts['source_archive'if role=='source'else'trajectory_archive']={'path':relative,'sha256':archives[role]['sha256']}
        artifact_path=stage/(p.BASE+'artifact_manifest.json');artifact_path.parent.mkdir(parents=True)
        p.save(artifact_path,artifacts)
        receipt=root/'package_receipt.json';p.save(receipt,{'stage':'complete_verified_local_packages_not_published',
            'plan_sha256':p.PLAN_SHA,'score_sha256':p.sha(score),'verification':proof,'archives':archives})
        m={'package_receipt':{'path':str(receipt),'sha256':p.sha(receipt)},
            'private_evidence_sha256':{str(receipt.resolve()):p.sha(receipt)},
            'files_sha256':{artifacts[key]['path']:artifacts[key]['sha256']for key in ['source_archive','trajectory_archive']}}
        return m,stage,score,sources,trajectories,proof

    def test_resealed_wrong_archive_stops_before_remote_helper(self):
        with tempfile.TemporaryDirectory()as td:
            args=self.artificial_archives(Path(td));m,stage,*_=args
            p.check_archive_bindings(*args)
            relative=next(name for name in m['files_sha256']if '/protocol_artifacts/'in name)
            (stage/relative).write_bytes(b'Artificial changed archive')
            # Simulate resealing the public manifest, leaving the separately
            # reviewed package receipt immutable.
            m['files_sha256'][relative]=p.sha(stage/relative)
            with patch.object(p,'helper')as remote:
                with self.assertRaisesRegex(ValueError,'Staged archive differs'):
                    p.check_archive_bindings(*args)
                remote.assert_not_called()

    def test_exact_package_hash_is_insufficient_for_wrong_member_content(self):
        with tempfile.TemporaryDirectory()as td:
            args=self.artificial_archives(Path(td));_,stage,_,sources,_,_=args
            source_archive=stage/('results/protocol_artifacts/'+p.RUN+'_source.tar.gz')
            sources['source.py'].write_text('# Artificial forged source\n')
            with self.assertRaisesRegex(ValueError,'Archive member content differs'):
                p.verify_archive_members(source_archive,sources,{'public_source_map.json':
                    (json.dumps({'plan_sha256':p.PLAN_SHA,'files':{}},indent=2)+'\n').encode()})

    def test_exact_seven_paths_exclude_shared_aggregates_and_website(self):
        self.assertEqual(len(p.ALLOWED),7)
        for path in p.ALLOWED:
            self.assertFalse(Path(path).is_absolute());self.assertNotIn('..',Path(path).parts)
            self.assertNotIn('docs',Path(path).parts);self.assertNotIn('.local',Path(path).parts)
            self.assertNotIn('ENGINEERING_PROGRESS',path);self.assertNotIn('CATALOG_STATUS',path)
            self.assertNotIn('EVALUATION_DECISION_TABLE',path);self.assertNotIn('RESULTS_AND_REMAINING_WORK',path)

    def test_owner_wrong_target_or_unreviewed_bytes_never_authorize_upload(self):
        with tempfile.TemporaryDirectory()as td:
            root=Path(td);m={'files_sha256':{name:'a'*64 for name in p.ALLOWED},
                'delegation_sha256':'f70edf39692d5915f05bd4869b2290d9a7576bd5a89906c004aec137d7e29717'}
            review={'task_id':'P34','reviewer':'/root/update_preparation_audit','approved':True,
                'manifest_sha256':'b'*64,'repository':p.REPOSITORY,'visibility':'public',
                'paths_sha256':m['files_sha256'],'secret_archive_scans_verified':True,'exclusions_verified':True,
                'delegation_sha256':m['delegation_sha256']}
            path=root/'review.json';path.write_text(json.dumps(review))
            p.review_guard(path,p.sha(path),m,'b'*64)
            for mutation in [{'reviewer':p.OWNER},{'repository':'other/repository'},{'visibility':'private'},
                             {'task_id':'P39'},{'paths_sha256':{}},{'secret_archive_scans_verified':False}]:
                path.write_text(json.dumps({**review,**mutation}))
                with self.subTest(mutation=mutation),self.assertRaises(PermissionError):
                    p.review_guard(path,p.sha(path),m,'b'*64)

    def test_changed_remote_question_stops_before_commit_push_or_attempt_marker(self):
        with tempfile.TemporaryDirectory()as td:
            root=Path(td);(root/'.local').mkdir();work=root/'work';work.mkdir();stage=root/'stage';stage.mkdir()
            for name in p.ALLOWED:
                file=stage/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_text('Artificial scoped output\n')
            m={'stage_directory':str(stage),'files_sha256':{name:p.sha(stage/name)for name in p.ALLOWED},
                'expected_previous_sha256':{name:None for name in p.ALLOWED}}
            calls=[]
            def initialize(checkout,helper):
                changed=checkout/'reports/questions/P34.md';changed.parent.mkdir(parents=True)
                changed.write_text('An independently changed artificial remote document\n')
                def git(*args):calls.append(args);return SimpleNamespace(stdout='')
                return git,'c'*40
            with patch.object(p,'ROOT',root),patch.object(p,'check',return_value=m),\
                 patch.object(p,'review_guard'),patch.object(p,'helper',return_value=SimpleNamespace()),\
                 patch.object(p,'initialize',side_effect=initialize):
                with self.assertRaisesRegex(ValueError,'Remote scoped path changed'):
                    p.publish(work/'manifest.json','b'*64,work/'review.json','d'*64)
            self.assertFalse((work/'attempt_started.json').exists())
            self.assertFalse(any(args and args[0]in {'commit','push'} for args in calls))


if __name__=='__main__':unittest.main()
