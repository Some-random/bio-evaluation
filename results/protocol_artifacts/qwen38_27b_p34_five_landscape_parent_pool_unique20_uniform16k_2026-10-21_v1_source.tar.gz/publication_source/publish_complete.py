"""Narrow P34 repository publication; offline checks by default, no model calls."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import fcntl
import hashlib
import importlib.util
import json
import shutil
import subprocess
import tempfile
import tarfile

ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
HERE=Path(__file__).resolve().parent
OWNER='/root/update_comparison_publication'
REPOSITORY='Some-random/bio-evaluation'
URL='https://github.com/'+REPOSITORY+'.git'
RUN='qwen38_27b_p34_five_landscape_parent_pool_unique20_uniform16k_2026-10-21_v1'
PLAN_SHA='23cff4ce746e110645cc94b60803100aac1a6364de938a8b9eda2b6ec23ba919'
BASE='results/runs/'+RUN+'/'
ALLOWED={BASE+'scores.json',BASE+'README.md',BASE+'artifact_manifest.json',
    'results/protocol_artifacts/'+RUN+'_source.tar.gz',
    'results/trajectory_archives/'+RUN+'_trajectories.tar.gz',
    'reports/questions/P34.md','reports/P34_FIVE_LANDSCAPE_OPTIMIZATION_RESULT.md'}
MUTABLE={'reports/questions/P34.md','reports/P34_FIVE_LANDSCAPE_OPTIMIZATION_RESULT.md'}


def stamp():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def read(path):return json.loads(Path(path).read_text())
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module
def save(path,value):
    with Path(path).open('x')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')


def helper():
    value=load('p34_existing_secure_git_helper',ROOT/'.local/litqa2_replay/incremental_upload.py')
    if value.URL!=URL or value.REPOSITORY!=REPOSITORY:raise ValueError('Exact authorized GitHub destination required')
    identity=value.confirm_destination()
    if identity['repository']!=REPOSITORY or identity['visibility']!='public' or identity['push_permission']is not True:
        raise ValueError('Actual public destination/permission differs')
    return value


def initialize(checkout,git_helper):
    def git(*args):return git_helper.git(*args,cwd=checkout)
    git('init','--quiet');git('remote','add','origin',URL)
    git('config','remote.origin.promisor','true');git('config','remote.origin.partialclonefilter','blob:none')
    git('sparse-checkout','init','--no-cone');git('sparse-checkout','set','--no-cone',*('/'+name for name in sorted(ALLOWED)))
    git('fetch','--filter=blob:none','--depth=1','origin','main');head=git('rev-parse','FETCH_HEAD').stdout.strip()
    git('checkout','--detach','FETCH_HEAD');return git,head


def capture_basis(output):
    # Read-only remote observation. No commit, push or tracked worktree changes.
    h=helper()
    with tempfile.TemporaryDirectory(prefix='p34-read-publication-basis-')as directory:
        checkout=Path(directory);git,head=initialize(checkout,h)
        previous={name:sha(checkout/name)if(checkout/name).is_file()else None for name in sorted(ALLOWED)}
    save(output,{'at_pacific':stamp(),'repository':REPOSITORY,'visibility':'public','remote_main_head':head,
        'expected_previous_sha256':previous,'remote_mutations':0,'model_calls':0})


def verify_archive_members(path,members,generated=None):
    """Bind every actual archive byte to the independently replayed inputs."""
    expected={name:{'sha256':sha(source),'bytes':source.stat().st_size}
              for name,source in members.items()}
    for name,value in (generated or {}).items():
        if name in expected:raise ValueError('Generated source member collision')
        expected[name]={'sha256':hashlib.sha256(value).hexdigest(),'bytes':len(value)}
    seen=set()
    with tarfile.open(path,'r:gz')as archive:
        for item in archive:
            name=item.name;relative=Path(name)
            if (not item.isfile()or relative.is_absolute()or '..'in relative.parts or
                    str(relative)!=name or name in seen):raise ValueError('Unsafe or duplicate archive member')
            seen.add(name)
            stream=archive.extractfile(item)
            if name=='publication_manifest.json':
                if item.size>8*1024**2:raise ValueError('Oversized archive member manifest')
                if json.loads(stream.read())!={'files':expected}:raise ValueError('Archive member manifest differs from replay')
                continue
            if name not in expected or item.size!=expected[name]['bytes']:
                raise ValueError('Archive member set/size differs from replay')
            digest=hashlib.sha256()
            for block in iter(lambda:stream.read(1048576),b''):digest.update(block)
            if digest.hexdigest()!=expected[name]['sha256']:
                raise ValueError('Archive member content differs from replay')
    if seen!=set(expected)|{'publication_manifest.json'}:
        raise ValueError('Archive omits exact replayed members')


def check_archive_bindings(m,stage,score_source,source,trajectories,proof):
    receipt_path=Path(m['package_receipt']['path']);receipt_sha=m['package_receipt']['sha256']
    if (receipt_path.is_symlink()or sha(receipt_path)!=receipt_sha or
            m['private_evidence_sha256'].get(str(receipt_path.resolve()))!=receipt_sha):
        raise ValueError('Exact pinned package receipt required')
    package=read(receipt_path);artifacts=read(stage/(BASE+'artifact_manifest.json'))
    if (package['stage']!='complete_verified_local_packages_not_published' or
            package['plan_sha256']!=PLAN_SHA or package['score_sha256']!=sha(score_source)or
            package['verification']!=proof or artifacts['plan_sha256']!=PLAN_SHA or
            artifacts['score_sha256']!=sha(score_source)):
        raise ValueError('Package, score and replay proof differ')
    source_map=(json.dumps({'plan_sha256':PLAN_SHA,'files':proof['public_source_map']},indent=2)+'\n').encode()
    for role,members,generated in [('source',source,{'public_source_map.json':source_map}),
                                    ('trajectories',trajectories,None)]:
        relative=('results/protocol_artifacts/'if role=='source'else'results/trajectory_archives/')+RUN+'_'+role+'.tar.gz'
        actual=stage/relative;locked=package['archives'][role]
        declared=artifacts['trajectory_archive'if role=='trajectories'else'source_archive']
        # The package receipt remains independently pinned even if somebody
        # reseals a changed staged file in the public-file manifest.
        if (declared!={'path':relative,'sha256':locked['sha256']}or
                sha(actual)!=locked['sha256']or actual.stat().st_size!=locked['bytes']or
                m['files_sha256'][relative]!=locked['sha256']):
            raise ValueError('Staged archive differs from pinned package receipt')
        verify_archive_members(actual,members,generated)


def check(manifest_path,digest):
    if sha(manifest_path)!=digest:raise ValueError('Exact reviewed publication manifest changed')
    m=read(manifest_path)
    if (m['task_id']!='P34' or m['repository']!=REPOSITORY or m['visibility']!='public' or
            m['plan_sha256']!=PLAN_SHA or m['rounds']!=1000 or m['candidate_values']!=20000 or
            m['starting_values']!=100 or m['available_landscapes']!=5 or m['native_paper_landscapes']!=6 or
            m['native_full_paper_scope_complete']is not False or m['experimental_function_assessed']is not False or
            m['held_sixth_landscape_dispatched']is not False or m['shared_aggregate_paths_modified']is not False or
            m['website_or_schedule_changes']is not False or m['model_calls']!=0):
        raise ValueError('Exact five-landscape surrogate result with unchanged hold required')
    if set(m['files_sha256'])!=ALLOWED or set(m['expected_previous_sha256'])!=ALLOWED:
        raise ValueError('Only seven exact scoped repository paths may be published')
    required_support={str(ROOT/name)for name in ['.local/litqa2_replay/github_credential_helper.py',
        'configs/publication_destination.json','scripts/publication_destination.py',
        '.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review.json']}
    if not required_support<=set(m['support_sha256']):raise ValueError('Exact publication destination/delegation leaf pins required')
    for group in ['support_sha256','private_evidence_sha256']:
        for name,expected in m[group].items():
            if Path(name).is_symlink()or sha(name)!=expected:raise ValueError('Reviewed publication support/evidence changed')
    scanner=load('p34_narrow_secret_scanner',ROOT/'scripts/daily_backup.py')
    stage=Path(m['stage_directory'])
    for name,expected in m['files_sha256'].items():
        path=stage/name
        if path.is_symlink()or not path.is_file()or path.stat().st_size>=90*1024**2 or sha(path)!=expected:
            raise ValueError('Frozen public artifact changed or exceeds Git boundary')
        scanner.scan_file(path)
    replay=load('p34_actual_complete_replay',HERE/'verify_and_package.py')
    admission=ROOT/'.local/catalog_execution_2026-10-20/tasks/P34/available_execution_v1/root_admission.json'
    _,score,source,trajectories,proof=replay.verify(admission,sha(admission),admission.parent/'submission_receipt.json')
    if (sha(stage/(BASE+'scores.json'))!=sha(Path(m['score_source']))or
            proof['rounds_replayed_without_models']!=1000 or proof['score_values_verified']!=20100 or
            score['full_primary_metric_defined']is not True):raise ValueError('Complete exact sealed result proof changed')
    check_archive_bindings(m,stage,Path(m['score_source']),source,trajectories,proof)
    return m


def review_guard(path,digest,m,manifest_sha):
    if path is None or digest is None or sha(path)!=digest:raise PermissionError('Concrete independent publication review required')
    review=read(path);policy_path=ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review.json'
    policy=read(policy_path);reviewer=review.get('reviewer')
    if (reviewer==OWNER or reviewer not in ['/root',*policy['authorized_reviewers']] or
            review.get('task_id')!='P34' or review.get('approved')is not True or review.get('manifest_sha256')!=manifest_sha or
            review.get('repository')!=REPOSITORY or review.get('visibility')!='public' or review.get('paths_sha256')!=m['files_sha256'] or
            review.get('secret_archive_scans_verified')is not True or review.get('exclusions_verified')is not True):
        raise PermissionError('Different authorized peer must approve the exact public artifacts')
    if reviewer!='/root' and (sha(policy_path)!=m['delegation_sha256']or
            review.get('delegation_sha256')!=m['delegation_sha256']or'P34'not in policy['authorized_task_ids']):
        raise PermissionError('Exact bounded publication delegation required')


def publish(manifest_path,manifest_sha,review_path,review_sha):
    m=check(manifest_path,manifest_sha);review_guard(review_path,review_sha,m,manifest_sha)
    work=Path(manifest_path).parent
    if(work/'attempt_started.json').exists()or(work/'publication_receipt.json').exists():
        raise FileExistsError('Preserve prior publication attempt; no ambiguous push retry')
    with(ROOT/'.local/catalog_report_generation.lock').open('a')as generation:
        fcntl.flock(generation,fcntl.LOCK_EX)
        with(ROOT/'.local/evaluation_publication.lock').open('a')as publication:
            fcntl.flock(publication,fcntl.LOCK_EX);check(manifest_path,manifest_sha)
            h=helper()
            with tempfile.TemporaryDirectory(prefix='p34-five-landscape-publication-')as directory:
                checkout=Path(directory);git,before=initialize(checkout,h);stage=Path(m['stage_directory'])
                for name in sorted(ALLOWED):
                    target=checkout/name;expected=m['expected_previous_sha256'][name]
                    actual=sha(target)if target.is_file()else None
                    if target.is_symlink()or actual!=expected:raise ValueError('Remote scoped path changed since independent review')
                    if name not in MUTABLE and actual is not None and actual!=m['files_sha256'][name]:
                        raise ValueError('An existing immutable result artifact cannot be overwritten')
                    if sha(stage/name)!=m['files_sha256'][name]:raise ValueError('Staged bytes changed')
                    target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(stage/name,target)
                git('config','user.name','Codex');git('config','user.email','codex@localhost')
                git('add','-f','--sparse','--',*sorted(ALLOWED))
                changed=set(git('diff','--cached','--name-only').stdout.splitlines())
                if not changed or not changed<=ALLOWED:raise ValueError('Unexpected or already identical publication requires review')
                # Catch exact upstream formatting problems before recording a
                # remote mutation attempt; raw artifacts are never rewritten.
                git('diff','--cached','--check','--',*sorted(ALLOWED))
                save(work/'attempt_started.json',{'at_pacific':stamp(),'manifest_sha256':manifest_sha,
                    'independent_review_sha256':review_sha,'remote_main_before':before,'model_calls':0})
                git('commit','-m','Publish complete five-landscape Qwen optimization condition and exact trajectories')
                h.confirm_destination();git('push','origin','HEAD:refs/heads/main')
                commit=git('rev-parse','HEAD').stdout.strip();git('fetch','--filter=blob:none','origin','main')
                head=git('rev-parse','FETCH_HEAD').stdout.strip()
                for name in sorted(ALLOWED):
                    data=subprocess.run(['git','show','FETCH_HEAD:'+name],cwd=checkout,capture_output=True,check=True).stdout
                    if hashlib.sha256(data).hexdigest()!=m['files_sha256'][name]:raise ValueError('Remote committed bytes differ')
                receipt={'at_pacific':stamp(),'stage':'published','repository':REPOSITORY,'visibility':'public',
                    'previous_main_head':before,'commit_sha':commit,'verified_remote_main_head':head,
                    'remote_bytes_verified':True,'published_path_count':len(ALLOWED),'paths_sha256':m['files_sha256'],
                    'manifest_sha256':manifest_sha,'independent_review_sha256':review_sha,'task_id':'P34',
                    'complete_available_landscapes':5,'native_paper_landscapes':6,'native_full_paper_scope_complete':False,
                    'native_MutaPLM_sampling_reproduced':False,'experimental_function_assessed':False,
                    'weights_environments_credentials_references_or_full_account_inventory_published':False,
                    'shared_aggregate_paths_modified':False,'website_or_schedule_changes':False,'model_calls':0}
                save(work/'publication_receipt.json',receipt)
                print(json.dumps({k:receipt[k]for k in ['stage','commit_sha','published_path_count','remote_bytes_verified']}))


def main():
    p=argparse.ArgumentParser();p.add_argument('--capture-basis',type=Path)
    p.add_argument('--manifest',type=Path);p.add_argument('--manifest-sha256');p.add_argument('--publish',action='store_true')
    p.add_argument('--review',type=Path);p.add_argument('--review-sha256');a=p.parse_args()
    if a.capture_basis:
        if a.publish or a.manifest:raise ValueError('Read-only basis capture is separate')
        capture_basis(a.capture_basis);return
    if a.publish:publish(a.manifest,a.manifest_sha256,a.review,a.review_sha256)
    else:
        check(a.manifest,a.manifest_sha256);print(json.dumps({'stage':'offline_narrow_P34_publication_check_passed','model_calls':0,'published':False}))


if __name__=='__main__':main()
