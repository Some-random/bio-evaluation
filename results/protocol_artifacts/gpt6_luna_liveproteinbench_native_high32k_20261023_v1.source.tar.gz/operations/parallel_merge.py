from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,sys,json,time,signal,argparse
import fcntl
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import transition as T
from runtime import create as original_create,canonical,sha
BASE_SHA=T.BASE_SHA;read=T.read;pin=T.pin
def create(path,value):
 path=Path(path);data=value if isinstance(value,bytes)else canonical(value)+b"\n"
 for parent in path.parents:
  if parent.is_symlink():raise ValueError('Symlinked derived destination')
  if parent==HERE:break
 if path.exists():
  if path.is_symlink()or path.read_bytes()!=data:raise ValueError("Partial-copy mismatch")
  return sha(data)
 return original_create(path,value)

def proc_state(pid):
 try:return Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
 except FileNotFoundError:return None

def stop_copy_parent():
 pid=2142166;ticks=801243640;api=read(HERE/'runtime/process_terminal.json')
 if api.get('plan_sha256')!='82f91edd0bde3ba4ded3d6a74b75950a5d2e3d5481fd04c6abe965db6fa95455'or api.get('returncode')!=0:raise ValueError('API not fully terminal')
 if proc_state(2142188):raise ValueError('API worker still exists; never signal it')
 state=proc_state(pid)
 if state is None:return {'parent_already_exited':True,'pid':pid}
 if int(state[19])!=ticks or Path('/proc',str(pid)).stat().st_uid!=os.getuid()or os.getuid()==0:raise ValueError('Parent owner/identity mismatch')
 if state[0]=='Z':return {'parent_already_exited':True,'pid':pid,'zombie_quiescent':True}
 pin(HERE/'launch_receipt.json','c91d21c538d311c0f3f9cb6f0e6bf882a8c0e3c0dfc5429f3b91fd46af35defb')
 command=[x.decode()for x in Path('/proc',str(pid),'cmdline').read_bytes().split(b'\0')if x]
 if command!=read(HERE/'launch_receipt.json')['command']:raise ValueError('Exact copy parent command differs')
 try:pidfd=os.pidfd_open(pid)
 except ProcessLookupError:return {'parent_already_exited':True,'pid':pid}
 try:
  end=time.monotonic()+40;combined=(HERE/'runtime/combined').resolve()
  while time.monotonic()<end:
   state=proc_state(pid)
   if state is None or state[0]=='Z':return {'parent_already_exited':True,'pid':pid}
   if int(state[19])!=ticks:raise ValueError('Copy parent identity changed')
   signal.pidfd_send_signal(pidfd,signal.SIGSTOP)
   try:
    wait=time.monotonic()+2
    while time.monotonic()<wait:
     state=proc_state(pid)
     if state is None:return {'parent_already_exited':True,'pid':pid}
     if state[0]in{'T','t'}:break
     time.sleep(.01)
    if state[0]not in{'T','t'}:continue
    writable=[]
    for fd in Path('/proc',str(pid),'fd').iterdir():
     try:
      target=fd.readlink();info=Path('/proc',str(pid),'fdinfo',fd.name).read_text()
      flags=int(next(x.split()[1]for x in info.splitlines()if x.startswith('flags:')),8)
      if (flags&os.O_ACCMODE)!=os.O_RDONLY and Path(target).is_relative_to(combined):writable.append(str(target))
     except FileNotFoundError:continue
     except OSError as error:raise ValueError('Cannot verify paused parent descriptors')from error
    if writable:continue
    evidence={'pid':pid,'start_ticks':ticks,'API_terminal':True,'API_worker_absent':True,'stopped_state':state[0],'open_combined_write_fds':writable,'only_CPU_copy_parent_signaled':True}
    original_create(HERE/'copy_parent_stop_intent.json',evidence)
    signal.pidfd_send_signal(pidfd,signal.SIGTERM);signal.pidfd_send_signal(pidfd,signal.SIGCONT)
    until=time.monotonic()+10
    while time.monotonic()<until:
     ending=proc_state(pid)
     if ending is None or ending[0]=='Z':break
     time.sleep(.05)
    ending=proc_state(pid)
    if ending is not None and ending[0]!='Z':raise ValueError('Copy parent did not exit')
    return evidence
   finally:
    state=proc_state(pid)
    if state and state[0]!='Z':
     try:signal.pidfd_send_signal(pidfd,signal.SIGCONT)
     except ProcessLookupError:pass
  raise ValueError('No safe copy boundary found; original parent preserved')
 finally:os.close(pidfd)

def merge_parallel(plan_sha):
    plan_path = HERE / 'bundle/plan.json'
    pin(plan_path, plan_sha)
    p = read(plan_path)
    boundary_path = HERE / 'boundary.json'
    pin(boundary_path, p['boundary_sha256'])
    b = read(boundary_path)
    newer = HERE / 'runtime'
    t = read(newer / 'process_terminal.json')
    if t.get('returncode') != 0 or t.get('plan_sha256') != plan_sha:
        raise ValueError('New API process not successful')
    lock_path = newer / 'prediction_lock.json'
    completion = read(newer / 'completion.json')
    new_lock = read(lock_path)
    expected_count = len(p['untouched_keys'])
    if completion.get('plan_sha256') != plan_sha or completion.get('planned') != expected_count or completion.get('attempted') != expected_count or (completion.get('all_planned_attempted') is not True) or (completion.get('prediction_lock_sha256') != sha(lock_path.read_bytes())) or (new_lock.get('plan_sha256') != plan_sha) or (new_lock.get('planned') != expected_count) or (len(new_lock.get('rows', [])) != expected_count):
        raise ValueError('New segment incomplete')
    new_records = {r['key']: r for r in new_lock['rows']}
    if set(new_records) != set(p['untouched_keys']):
        raise ValueError('New segment key mismatch')
    source = [json.loads(line) for line in (HERE / 'bundle/all_requests.jsonl').read_bytes().splitlines()]
    combined = newer / 'combined'
    combined.mkdir(exist_ok=True)
    merged = {}
    lineage = {}

    def copy_row(row):
        if row['cohort'] == 'development':
            return None
        key = row['key']
        old = b['attempted'].get(key)
        folder = combined / row['cohort'] / 'cases' / key
        folder.mkdir(parents=True, exist_ok=True)
        if old:
            origin = Path(old['folder'])
            files = old['files']
            for name, digest in files.items():
                pin(origin / name, digest)
            if old['complete_record']:
                record = read(origin / 'record.json')
            else:
                record = {'cohort': row['cohort'], 'key': key, 'case_id': row['case_id'], 'task_id': row['task_id'], 'model': 'gpt-6-luna', 'model_key': 'gpt6_luna', 'plan_sha256': BASE_SHA, 'input_row_sha256': row['input_row_sha256'], 'status': 'transport_error', 'attempted': True, 'final': '', 'truncated': False, 'empty_final': True, 'refused': False, 'http_status': None, 'ambiguous_preserved': True}
                from runtime import canonical
                raw = canonical({'local_transport_error_type': 'AmbiguousOriginalReservationPreservedWithoutRetry'})
                record['response_sha256'] = create(folder / 'response.json', raw)
                record['final_sha256'] = create(folder / 'final.txt', b'')
                create(folder / 'request.json', {'payload_without_private_safety_identifier': row['payload'], 'actual_dispatch_unknown': True})
                create(folder / 'dispatch_receipt.json', {'actual_dispatch_unknown': True, 'plan_sha256': BASE_SHA, 'attempt': 1})
            segment = 'original64'
        else:
            origin = newer / row['cohort'] / 'cases' / key
            record = new_records[key]
            files = {n: sha((origin / n).read_bytes()) for n in ['request.json', 'dispatch_receipt.json', 'response.json', 'final.txt', 'record.json']}
            segment = 'continuation128'
        if not record.get('ambiguous_preserved'):
            if record.get('attempted') is not True or record.get('plan_sha256') != (BASE_SHA if old else plan_sha) or any((record.get(k) != row[k] for k in ('key', 'case_id', 'task_id', 'cohort'))):
                raise ValueError('Source segment identity differs')
            for name in ['request.json', 'dispatch_receipt.json', 'response.json', 'final.txt']:
                data = (origin / name).read_bytes()
                if sha(data) != files[name]:
                    raise ValueError('Source changed during copy')
                create(folder / name, data)
        create(folder / 'record.json', record)
        return (key, record, {'segment': segment, 'source_folder': str(origin), 'source_files': files, 'ambiguous_preserved': bool(record.get('ambiguous_preserved'))})
    with ThreadPoolExecutor(max_workers=8) as pool:
        for item in pool.map(copy_row, source):
            if item is not None:
                key, record, origin = item
                merged[key] = record
                lineage[key] = origin
    manifest_sha = create(combined / 'merge_manifest.json', {'plan_sha256': plan_sha, 'original_plan_sha256': BASE_SHA, 'boundary_sha256': p['boundary_sha256'], 'new_prediction_lock_sha256': sha(lock_path.read_bytes()), 'cases': lineage})
    for cohort, count in [('liveproteinbench', 1736), ('labbench2', 542)]:
        rows = [merged[r['key']] for r in source if r['cohort'] == cohort]
        if len(rows) != count:
            raise ValueError('Combined cohort count mismatch')
        out = combined / cohort
        locksha = create(out / 'prediction_lock.json', {'plan_sha256': plan_sha, 'original_plan_sha256': BASE_SHA, 'planned': count, 'rows': rows, 'merge_manifest_sha256': manifest_sha})
        create(out / 'completion.json', {'plan_sha256': plan_sha, 'planned': count, 'attempted': count, 'terminal': count, 'all_planned_attempted': True, 'ambiguous_preserved_count': sum((bool(r.get('ambiguous_preserved')) for r in rows)), 'prediction_lock_sha256': locksha, 'merge_manifest_sha256': manifest_sha})
    create(combined / 'process_terminal.json', {'plan_sha256': plan_sha, 'returncode': 0, 'source_API_process_terminal_sha256': sha((newer / 'process_terminal.json').read_bytes()), 'merge_manifest_sha256': manifest_sha})
    return combined

def main():
 parser=argparse.ArgumentParser()
 for key in('review','review-sha256'):parser.add_argument('--'+key,required=True)
 args=parser.parse_args();pin(args.review,args.review_sha256);review=read(args.review)
 plan_sha='82f91edd0bde3ba4ded3d6a74b75950a5d2e3d5481fd04c6abe965db6fa95455'
 if review.get('approved')is not True or review.get('role')!='independent_parallel_merge_review'or review.get('plan_sha256')!=plan_sha or review.get('source_sha256')!=sha(Path(__file__).read_bytes()):raise ValueError('Exact CPU merge review required')
 for path,digest in review['files_sha256'].items():pin(path,digest)
 with(HERE/'merge_completion.lock').open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  final=HERE/'runtime/combined/process_terminal.json'
  if final.exists():return
  stopped=stop_copy_parent();original_create(HERE/'copy_parent_stopped.json',stopped)
  original_create(HERE/'parallel_merge_attempt.json',{'plan_sha256':plan_sha,'source_sha256':sha(Path(__file__).read_bytes()),'review_sha256':args.review_sha256,'model_calls':0})
  try:combined=merge_parallel(plan_sha)
  except Exception as e:
   original_create(HERE/'runtime/merge_failure.json',{'plan_sha256':plan_sha,'error_type':type(e).__name__,'model_calls':0});raise
  original_create(HERE/'parallel_merge_receipt.json',{'plan_sha256':plan_sha,'source_sha256':sha(Path(__file__).read_bytes()),'review_sha256':args.review_sha256,'combined_terminal_sha256':sha((combined/'process_terminal.json').read_bytes()),'model_calls':0,'copies_reused_only_when_identical':True})

if __name__=='__main__':main()
