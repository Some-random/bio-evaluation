"""Once-only LPB accuracy, opened only after the isolated solver terminates."""
import argparse,collections,importlib.util,json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from runtime import canonical,create,sha
ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
PARSER=ROOT/'.local/qwen35_4b_thinking_enabled_20261022/lpb_native_thinking32k_v3/implementation/answer_parser.py'
PARSER_SHA='31578f19b23eb6863113c5e0046f6f7f07ba841ab5913200fbaaff4b7b8111ee'
REFERENCES=ROOT/'.local/qwen35_4b_thinking_enabled_20261022/lpb_native_thinking32k_v3/references.private.jsonl'
REFERENCES_SHA='dab5185104e5ee504cbd96a3c978761530ecaf95dce7c9c6ad1c4f02bfd41bf7'

def read(p):return json.loads(Path(p).read_text())
def rows(p):return [json.loads(x)for x in Path(p).read_bytes().splitlines()if x.strip()]
def normalized_raw(raw,http_status,helper):
    result={'final':'','truncated':False,'refused':False,'status':'transport_error'}
    if http_status is not None:
        result['status']='http_error'
        if http_status==200:
            try:
                value=helper.parse_json(raw)
                if value.get('model')!='gpt-6-luna':raise ValueError('Wrong response model')
                final,refused=helper.extract_visible(value)
                truncated=value.get('status')=='incomplete'and value.get('incomplete_details',{}).get('reason')=='max_output_tokens'
                state='refusal'if refused else'truncated'if truncated else'completed'if value.get('status')=='completed'and final.strip()else'response_error'
                result.update(final=final,refused=refused,truncated=truncated,status=state)
            except(ValueError,TypeError,AttributeError):result['status']='response_error'
    result['empty_final']=not result['final'].strip()
    return result
def score(plan_path,plan_sha,runtime):
    plan_path=Path(plan_path);runtime=Path(runtime);out=runtime/'liveproteinbench'
    if sha(plan_path.read_bytes())!=plan_sha:raise ValueError('Plan mismatch')
    plan=read(plan_path)
    for name,digest in plan['bundle_files'].items():
        if sha((plan_path.parent/name).read_bytes())!=digest:raise ValueError('Frozen bundle changed')
    for path,digest in plan['source_pins'].items():
        if sha(Path(path).read_bytes())!=digest:raise ValueError('Original input source changed')
    spec=importlib.util.spec_from_file_location('frozen_response_extraction',plan_path.parent/'old_client.py')
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    terminal=read(runtime/'process_terminal.json');complete=read(out/'completion.json')
    if terminal.get('returncode')!=0 or terminal.get('plan_sha256')!=plan_sha:raise ValueError('API worker not terminal')
    if complete.get('plan_sha256')!=plan_sha or complete.get('planned')!=1736 or complete.get('attempted')!=1736 or complete.get('terminal')!=1736 or complete.get('all_planned_attempted')is not True:raise ValueError('Full1736 required')
    lock_path=out/'prediction_lock.json'
    if sha(lock_path.read_bytes())!=complete['prediction_lock_sha256']:raise ValueError('Prediction seal changed')
    lock=read(lock_path)
    source=[r for r in rows(plan_path.parent/plan.get('all_requests_file','requests.jsonl'))if r['cohort']=='liveproteinbench']
    if len(source)!=1736 or len(lock['rows'])!=1736 or lock.get('plan_sha256')!=plan_sha:raise ValueError('Exact whole cohort missing')
    merge=read(runtime/'merge_manifest.json')
    if sha((runtime/'merge_manifest.json').read_bytes())!=complete.get('merge_manifest_sha256') or merge.get('plan_sha256')!=plan_sha:raise ValueError('Combined provenance mismatch')
    boundary=read(plan['boundary_path'])
    if sha(Path(plan['boundary_path']).read_bytes())!=plan['boundary_sha256']:raise ValueError('Original boundary changed')
    if merge.get('boundary_sha256')!=plan['boundary_sha256']:raise ValueError('Wrong boundary in merge')
    new_lock_path=runtime.parent/'prediction_lock.json'
    if sha(new_lock_path.read_bytes())!=merge.get('new_prediction_lock_sha256'):raise ValueError('New segment seal changed')
    new_records={r['key']:r for r in read(new_lock_path)['rows']}
    for expected,record in zip(source,lock['rows']):
        old=boundary['attempted'].get(expected['key'])
        expected_plan=plan['original_plan_sha256'] if old else plan_sha
        if record.get('plan_sha256')!=expected_plan:raise ValueError('Wrong source-segment plan')
        if record.get('ambiguous_preserved') and (not old or not old['ambiguous']):raise ValueError('Invented ambiguity')
        lineage=merge['cases'][expected['key']]
        if old:
            if lineage['source_folder']!=old['folder']or lineage['source_files']!=old['files']:raise ValueError('Old lineage differs from frozen boundary')
        elif new_records.get(expected['key'])!=record:raise ValueError('New lineage differs from actual seal')
        for name,digest in lineage['source_files'].items():
            if sha((Path(lineage['source_folder'])/name).read_bytes())!=digest:raise ValueError('Source evidence changed')
        if not record.get('ambiguous_preserved'):
            for name in ['request.json','dispatch_receipt.json','response.json','final.txt','record.json']:
                if sha((runtime/'liveproteinbench'/'cases'/expected['key']/name).read_bytes())!=lineage['source_files'][name]:raise ValueError('Merged bytes differ from sealed source')
        elif record.get('status')!='transport_error'or record.get('final')!=''or record.get('empty_final')is not True:raise ValueError('Ambiguous preservation cannot become an answer')
        if any(expected[k]!=record[k]for k in('key','case_id','task_id'))or record.get('attempted')is not True:raise ValueError('Wrong case sequence')
        folder=out/'cases'/record['key']
        if read(folder/'record.json')!=record:raise ValueError('Record differs from seal')
        if sha((folder/'response.json').read_bytes())!=record['response_sha256']or sha((folder/'final.txt').read_bytes())!=record['final_sha256']:raise ValueError('Raw artifact changed')
        if (folder/'final.txt').read_text()!=record['final']:raise ValueError('Final differs')
        derived=normalized_raw((folder/'response.json').read_bytes(),record['http_status'],helper)
        if any(record.get(k)!=v for k,v in derived.items()):raise ValueError('Raw response contradicts derived outcome')
        request=read(folder/'request.json')
        if request['payload_without_private_safety_identifier']!=expected['payload']:raise ValueError('Actual request differs from frozen projection')
        receipt=read(folder/'dispatch_receipt.json')
        if receipt.get('actual_submitted_payload_sha256')!=request.get('actual_submitted_payload_sha256')or receipt.get('plan_sha256')!=expected_plan or receipt.get('attempt')!=1:raise ValueError('Actual dispatch proof differs')
    if sha(PARSER.read_bytes())!=PARSER_SHA:raise ValueError('Fixed extraction code changed')
    create(out/'scoring_attempt.json',{'plan_sha256':plan_sha,'prediction_lock_sha256':complete['prediction_lock_sha256'],'reference_sha256':REFERENCES_SHA,'parser_sha256':PARSER_SHA,'attempt':1})
    # No reference is opened until every sealed prediction is verified above.
    reference_bytes=REFERENCES.read_bytes()
    if sha(reference_bytes)!=REFERENCES_SHA:raise ValueError('Reference source changed')
    references=[json.loads(x)for x in reference_bytes.splitlines()if x.strip()]
    if len(references)!=1736 or any((r['case_id'],r['task_id'])!=(s['case_id'],s['task_id'])for r,s in zip(references,source)):raise ValueError('Reference identities differ')
    spec=importlib.util.spec_from_file_location('fixed_lpb_parser',PARSER);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    aggregate=collections.defaultdict(lambda:{'planned':0,'correct':0,'parsed':0,'invalid':0});details=[]
    for record,reference in zip(lock['rows'],references):
        prediction=module.parse_answer(record['final'])if record['status']=='completed'and not record.get('ambiguous_preserved')and not record['truncated']and not record['refused']and not record['empty_final']else None
        correct=prediction is not None and prediction==reference['answer'];item=aggregate[record['task_id']]
        item['planned']+=1;item['correct']+=int(correct);item['parsed']+=int(prediction is not None);item['invalid']+=int(prediction is None)
        details.append({'case_id':record['case_id'],'prediction':prediction,'correct':correct})
    for item in aggregate.values():item['accuracy']=item['correct']/item['planned']
    result={'benchmark':'LiveProteinBench','model':'gpt-6-luna','reasoning_effort':'high','max_output_tokens':32768,
            'planned':1736,'source_cases':1797,'excluded_cases':61,'per_task':dict(aggregate),
            'micro_accuracy':sum(x['correct']for x in aggregate.values())/1736,
            'macro_task_accuracy':sum(x['accuracy']for x in aggregate.values())/len(aggregate),
            'invalids_count_as_incorrect':True,'upstream_released_parser':False,'parser_sha256':PARSER_SHA,
            'plan_sha256':plan_sha,'prediction_lock_sha256':complete['prediction_lock_sha256'],'reference_sha256':REFERENCES_SHA,
            'explanation_correctness_scored':False}
    create(out/'per_case_scores.private.json',details);create(out/'scores.json',result)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for n in('plan','plan-sha256','runtime'):p.add_argument('--'+n,required=True)
    a=p.parse_args();score(a.plan,a.plan_sha256,a.runtime)
