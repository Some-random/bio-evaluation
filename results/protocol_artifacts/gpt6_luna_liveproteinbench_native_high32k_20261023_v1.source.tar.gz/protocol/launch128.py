"""One reviewed128 successor after original64 is closed; no request replay."""
import argparse,fcntl,json,os,re,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE.parent))
from runtime import create,sha,canonical
import transition as T
def read(p):return json.loads(Path(p).read_text())
def main():
    a=argparse.ArgumentParser()
    for n in('plan-sha256','admission','admission-sha256','grant','grant-sha256'):a.add_argument('--'+n,required=True)
    x=a.parse_args();p=HERE/'bundle/plan.json';T.pin(p,x.plan_sha256);plan=read(p)
    T.pin(x.admission,x.admission_sha256);review=read(x.admission)
    if review.get('approved')is not True or review.get('plan_sha256')!=x.plan_sha256 or review.get('role')!='independent_luna128_runtime_admission':raise ValueError('128runtime not independently admitted')
    for path,digest in review['files_sha256'].items():T.pin(path,digest)
    T.pin(x.grant,x.grant_sha256);grant=read(x.grant)
    if grant.get('authorized')is not True or grant.get('plan_sha256')!=x.plan_sha256 or grant.get('admission_sha256')!=x.admission_sha256 or grant.get('root128_authority_sha256')!=T.AUTH_SHA:raise ValueError('Wrong128grant')
    T.original();T.pin(HERE/'boundary.json',plan['boundary_sha256']);boundary=read(HERE/'boundary.json')
    if any(Path('/proc',str(pid)).exists()for pid in(2120376,2120395)):raise ValueError('Original64 still running')
    for name,digest in plan['bundle_files'].items():T.pin(HERE/'bundle'/name,digest)
    selected=[json.loads(line)for line in(HERE/'bundle/requests.jsonl').read_bytes().splitlines()]
    if [r['key']for r in selected]!=boundary['untouched_keys']or set(boundary['untouched_keys'])&set(boundary['attempted']):raise ValueError('Prior attempted key in continuation')
    with(HERE/'launch.lock').open('a')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        out=HERE/'runtime';out.mkdir(mode=0o700)
        create(out/'launch_attempt.json',{'plan_sha256':x.plan_sha256,'admission_sha256':x.admission_sha256,'grant_sha256':x.grant_sha256,'pid':os.getpid(),'automatic_retry':False})
        while time.time()<boundary['old_terminal_time']+60:time.sleep(min(60,boundary['old_terminal_time']+60-time.time()))
        key=(Path.home()/'.config/openai/api_key').read_text().strip()
        ident=read(Path.home()/'.config/openai/request_identity.json')['safety_identifier']
        if not key or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}',ident):raise ValueError('Missing stable private credentials')
        probe=HERE/'denial_probe';create(probe,b'neutral128isolationprobe\n')
        r,w=os.pipe();os.write(w,canonical({'key':key,'identifier':ident,'authorized_plan_sha256':x.plan_sha256,'denial_probe':str(probe)}));os.close(w)
        command=['/usr/bin/python3','-I','-B',str(HERE/'bundle/worker128.py'),'worker',str(out),x.plan_sha256,str(r)]
        try:
            with(out/'worker.log').open('wb')as log:child=subprocess.run(command,pass_fds=(r,),env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','HOME':'/nonexistent'},stdout=log,stderr=subprocess.STDOUT)
        finally:os.close(r)
        create(out/'process_terminal.json',{'returncode':child.returncode,'plan_sha256':x.plan_sha256,'automatic_retry':False})
        if child.returncode:raise SystemExit(child.returncode)
        try:T.merge(x.plan_sha256)
        except Exception as e:
            create(out/'merge_failure.json',{'error_type':type(e).__name__,'plan_sha256':x.plan_sha256,'no_retry':True});raise
if __name__=='__main__':main()
