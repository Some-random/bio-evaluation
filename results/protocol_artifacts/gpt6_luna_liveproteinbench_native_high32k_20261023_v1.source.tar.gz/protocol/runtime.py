"""Neutral pacing and durable once-only budget primitives."""
from collections import deque
import hashlib,json,os,re,threading,time
from email.utils import parsedate_to_datetime
from pathlib import Path

def canonical(x):
    return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
def syncdir(p):
    fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
def create(p,x):
    p=Path(p);b=x if isinstance(x,bytes)else canonical(x)+b'\n'
    with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
    syncdir(p.parent);return sha(b)
def update(p,x):
    p=Path(p);t=p.with_name(p.name+'.tmp')
    with t.open('wb')as f:f.write(canonical(x)+b'\n');f.flush();os.fsync(f.fileno())
    os.replace(t,p);syncdir(p.parent)

class Budget:
    def __init__(self,path,cap=50_000_000_000):
        self.path=Path(path);self.path.mkdir();syncdir(self.path.parent)
        self.cap=cap;self.used=0;self.lock=threading.Lock()
    def reserve(self,key,cost,metadata):
        with self.lock:
            if type(cost)is not int or cost<0 or self.used+cost>self.cap:raise ValueError('Worst-case budget exhausted')
            create(self.path/(key+'.json'),{**metadata,'reserved_nano_usd':cost,'total_reserved_nano_usd':self.used+cost,'attempt':1,'automatic_retry':False})
            self.used+=cost

def duration(x):
    if not isinstance(x,str):return None
    parts=re.findall(r'([0-9]+(?:\.[0-9]+)?)(ms|s|m|h)',x)
    if not parts or ''.join(a+b for a,b in parts)!=x:return None
    return sum(float(a)*{'ms':.001,'s':1,'m':60,'h':3600}[b]for a,b in parts)

class Pacer:
    def __init__(self,rpm=1000,tpm=1_600_000,clock=time.monotonic):
        self.rpm=rpm;self.tpm=tpm;self.project_tpm=None;self.retry_until=0;self.clock=clock;self.entries=deque();self.headers={};self.lock=threading.Lock();self.learned=set()
    def acquire(self,tokens):
        with self.lock:
            now=self.clock()
            if tokens>self.tpm or(self.project_tpm is not None and tokens>self.project_tpm):raise ValueError('One request exceeds observed token-per-minute capacity; no retry or cap reduction')
            if now<self.retry_until:return False
            while self.entries and self.entries[0][0]<=now-60:self.entries.popleft()
            for k in list(self.headers):
                if self.headers[k][1]<=now:del self.headers[k]
            r=self.headers.get('requests');t=self.headers.get('tokens');p=self.headers.get('project-tokens')
            total=sum(x[1]for x in self.entries)+tokens
            if len(self.entries)>=self.rpm or total>self.tpm or(self.project_tpm is not None and total>self.project_tpm)or(r and r[0]<1)or(t and t[0]<tokens)or(p and p[0]<tokens):return False
            self.entries.append((now,tokens))
            if r:self.headers['requests']=(r[0]-1,r[1])
            if t:self.headers['tokens']=(t[0]-tokens,t[1])
            if p:self.headers['project-tokens']=(p[0]-tokens,p[1])
            return True
    def observe(self,headers):
        headers={k.lower():v for k,v in headers.items()};now=self.clock()
        with self.lock:
            retry=headers.get('retry-after')
            if retry:
                try:seconds=float(retry)
                except ValueError:
                    try:seconds=max(0,parsedate_to_datetime(retry).timestamp()-time.time())
                    except (ValueError,TypeError,OverflowError):seconds=0
                self.retry_until=max(self.retry_until,now+max(0,seconds))
            for kind,attr in [('requests','rpm'),('tokens','tpm'),('project-tokens','project_tpm')]:
                limit=headers.get('x-ratelimit-limit-'+kind)
                if str(limit).isdigit()and int(limit)>0:
                    setattr(self,attr,max(1,int(int(limit)*.8)));self.learned.add(kind)
                remain=headers.get('x-ratelimit-remaining-'+kind);reset=duration(headers.get('x-ratelimit-reset-'+kind))
                if str(remain).isdigit()and reset is not None:
                    old=self.headers.get(kind)
                    self.headers[kind]=(min(int(remain),old[0])if old and old[1]>now else int(remain),max(now+reset,old[1])if old else now+reset)
