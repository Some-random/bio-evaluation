"""Reviewed reservation-boundary drain and untouched-only continuation freeze."""
import json,os,stat,time,importlib.util
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent;BASE=HERE.parent
sys.path.insert(0,str(BASE))
from runtime import create,sha
ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
AUTH=ROOT/'.local/priority_results_20261023/luna_concurrency_128_authorization.json'
AUTH_SHA='c1a1ad72f60c3ecf3ba721b9f40736d2bd28d2a62b3459f7c6d8fb59d79b92ba'
BASE_SHA='f575b876269d375f0fe9f1ef31da15056ab5297120b1f0c29bb9e576c8306a62'
def read(p):return json.loads(Path(p).read_text())
def pin(p,h):
    if Path(p).is_symlink()or sha(Path(p).read_bytes())!=h:raise ValueError('Pinned file changed: '+str(p))
def original():
    pin(AUTH,AUTH_SHA);pin(BASE/'bundle/plan.json',BASE_SHA)
    p=read(BASE/'bundle/plan.json')
    for n,h in p['bundle_files'].items():pin(BASE/'bundle'/n,h)
    return p
def drain(review_path,review_sha):
    original();pin(review_path,review_sha);review=read(review_path)
    if review.get('approved')is not True or review.get('role')!='independent_luna128_transition_admission':raise ValueError('Transition not admitted')
    for p,h in review['files_sha256'].items():pin(p,h)
    if not(BASE/'SCORE_STOP').exists()or Path('/proc/2125922').exists()or not(BASE/'notification/STOP').exists()or(BASE/'notification/notification_attempt.json').exists():raise ValueError('Old downstream workers not held')
    target=BASE/'runtime/reservations';s=target.stat()
    if target.is_symlink()or not stat.S_ISDIR(s.st_mode)or s.st_uid!=os.getuid()or os.getuid()==0 or s.st_mode&0o777 not in{0o700,0o755}:raise ValueError('Unexpected reservation directory')
    fd=os.open(target,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);opened=os.fstat(fd)
    if(opened.st_dev,opened.st_ino,opened.st_uid)!=(s.st_dev,s.st_ino,s.st_uid):os.close(fd);raise ValueError('Directory raced')
    create(HERE/'drain_intent.json',{'path':str(target),'dev':s.st_dev,'ino':s.st_ino,'uid':s.st_uid,'original_mode':s.st_mode&0o777,'restricted_mode':0o500,'review_sha256':review_sha,'authority_sha256':AUTH_SHA,'plan_sha256':BASE_SHA})
    try:os.fchmod(fd,0o500);after=os.fstat(fd)
    finally:os.close(fd)
    if(after.st_dev,after.st_ino,after.st_uid,after.st_mode&0o777)!=(s.st_dev,s.st_ino,s.st_uid,0o500):raise ValueError('Restriction did not bind exact directory')
    create(HERE/'drain_applied.json',{'applied':True,'path':str(target),'dev':s.st_dev,'ino':s.st_ino,'uid':s.st_uid,'mode':0o500,'intent_sha256':sha((HERE/'drain_intent.json').read_bytes()),'no_process_signal':True,'time':time.time()})

def freeze():
    p=original();runtime=BASE/'runtime'
    dev=read(runtime/'development_completion.json')
    if dev.get('passed')is not True or dev.get('planned')!=4:raise ValueError('Original actual delivery gate missing')
    if any(Path('/proc',str(pid)).exists()for pid in(2120376,2120395)):raise ValueError('Old API processes still present')
    t=read(runtime/'process_terminal.json');status=read(runtime/'status.json')
    if t.get('plan_sha256')!=BASE_SHA or(status.get('error_type')!='PermissionError'and t.get('returncode')!=0):raise ValueError('Old termination not explained by reviewed boundary')
    if status.get('stopped_after_policy_access_or_rate_limit'):raise ValueError('Original provider/rate stop must not be rerouted')
    spec=importlib.util.spec_from_file_location('original_provider_guard',BASE/'bundle/old_client.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
    applied=(HERE/'drain_applied.json').exists()and read(HERE/'drain_applied.json').get('applied')is True
    if applied and (runtime/'reservations').stat().st_mode&0o777!=0o500:raise ValueError('Restriction changed')
    if not applied and t.get('returncode')!=0:raise ValueError('Missing intentional drain receipt')
    source=[read_line for line in(BASE/'bundle/requests.jsonl').read_bytes().splitlines()if line.strip()for read_line in[json.loads(line)]]
    if {x.stem for x in(runtime/'reservations').glob('*.json')}-{r['key']for r in source}:raise ValueError('Unknown original reservation')
    attempted={};remaining=[];carry=0
    for row in source:
        f=runtime/row['cohort']/'cases'/row['key'];reservation=runtime/'reservations'/(row['key']+'.json')
        evidence=reservation.exists()or(f/'request.json').exists()or(f/'dispatch_receipt.json').exists()
        if row['cohort']=='development'and not evidence:raise ValueError('Original delivery gate incomplete')
        if not evidence:
            if row['cohort']!='development':remaining.append(row)
            continue
        carry+=row['max_cost_nano_usd']
        if reservation.exists():
            reserved=read(reservation)
            if reserved.get('reserved_nano_usd')!=row['max_cost_nano_usd']or reserved.get('plan_sha256')!=BASE_SHA:raise ValueError('Original budget receipt differs')
        files={x.name:sha(x.read_bytes())for x in f.iterdir()if x.is_file()}
        rec=read(f/'record.json')if'record.json'in files else{}
        raw=(f/'response.json').read_bytes()if(f/'response.json').exists()else b''
        scan_status=rec.get('http_status')if rec else 400
        if rec.get('http_status')==429 or guard.stop_for_provider_error(scan_status,raw,rec.get('status'))or any(word in raw.lower()for word in[b'"refusal"',b'rate_limit_exceeded',b'rate_limit_error']):raise ValueError('Original provider/rate stop must not be retried or rerouted')
        complete=reservation.exists()and {'record.json','response.json','final.txt','request.json','dispatch_receipt.json'}<=set(files)
        attempted[row['key']]={'cohort':row['cohort'],'case_id':row['case_id'],'task_id':row['task_id'],'folder':str(f),'files':files,'reservation_sha256':sha(reservation.read_bytes())if reservation.exists()else None,'complete_record':complete,'ambiguous':not complete}
    if not applied and remaining:raise ValueError('Natural completion with untouched cases is not a clean handoff')
    boundary={'base_plan_sha256':BASE_SHA,'authority_sha256':AUTH_SHA,'attempted':attempted,'untouched_keys':[r['key']for r in remaining],'initial_reserved_nano_usd':carry,'old_terminal_sha256':sha((runtime/'process_terminal.json').read_bytes()),'old_terminal_time':(runtime/'process_terminal.json').stat().st_mtime,'cooldown_seconds':60,'drain_applied_sha256':sha((HERE/'drain_applied.json').read_bytes())if applied else None}
    create(HERE/'boundary.json',boundary)
    return p,source,remaining,boundary

def build():
    p,source,remaining,boundary=freeze();bundle=HERE/'bundle';bundle.mkdir()
    for name,source_path in [('worker128.py',HERE/'worker128.py'),('original_dispatcher.py',BASE/'bundle/dispatcher.py'),('old_client.py',BASE/'bundle/old_client.py'),('runtime.py',BASE/'bundle/runtime.py')]:create(bundle/name,source_path.read_bytes())
    from runtime import canonical
    create(bundle/'requests.jsonl',b''.join(canonical(r)+b'\n'for r in remaining))
    create(bundle/'all_requests.jsonl',(BASE/'bundle/requests.jsonl').read_bytes())
    p={**p,'max_in_flight':128,'development_cases':0,'reused_actual_development_cases':4,
       'original_plan_sha256':BASE_SHA,'boundary_path':str(HERE/'boundary.json'),'boundary_sha256':sha((HERE/'boundary.json').read_bytes()),
       'initial_reserved_nano_usd':boundary['initial_reserved_nano_usd'],'untouched_keys':boundary['untouched_keys'],
       'remaining_benchmark_cases':len(remaining),'all_requests_file':'all_requests.jsonl',
       'operational_difference':'Only128concurrency, original attempts retained; no payload or reasoning/outputcap changes',
       'authority_pins':{**p['authority_pins'],str(AUTH):AUTH_SHA},
       'bundle_files':{x.name:sha(x.read_bytes())for x in bundle.iterdir()}}
    create(bundle/'plan.json',p)
    create(HERE/'frozen_handoff.json',{'plan_sha256':sha((bundle/'plan.json').read_bytes()),'boundary_sha256':p['boundary_sha256'],'remaining':len(remaining),'old_attempted':len(boundary['attempted']),'initial_reserved_nano_usd':p['initial_reserved_nano_usd']})
    return p

def merge(plan_sha):
    plan_path=HERE/'bundle/plan.json';pin(plan_path,plan_sha);p=read(plan_path)
    boundary_path=HERE/'boundary.json';pin(boundary_path,p['boundary_sha256']);b=read(boundary_path)
    newer=HERE/'runtime';t=read(newer/'process_terminal.json')
    if t.get('returncode')!=0 or t.get('plan_sha256')!=plan_sha:raise ValueError('New API process not successful')
    lock_path=newer/'prediction_lock.json';completion=read(newer/'completion.json')
    new_lock=read(lock_path);expected_count=len(p['untouched_keys'])
    if completion.get('plan_sha256')!=plan_sha or completion.get('planned')!=expected_count or completion.get('attempted')!=expected_count or completion.get('all_planned_attempted')is not True or completion.get('prediction_lock_sha256')!=sha(lock_path.read_bytes())or new_lock.get('plan_sha256')!=plan_sha or new_lock.get('planned')!=expected_count or len(new_lock.get('rows',[]))!=expected_count:raise ValueError('New segment incomplete')
    new_records={r['key']:r for r in new_lock['rows']}
    if set(new_records)!=set(p['untouched_keys']):raise ValueError('New segment key mismatch')
    source=[json.loads(line)for line in(HERE/'bundle/all_requests.jsonl').read_bytes().splitlines()]
    combined=newer/'combined';combined.mkdir();merged={};lineage={}
    for row in source:
        if row['cohort']=='development':continue
        key=row['key'];old=b['attempted'].get(key);folder=combined/row['cohort']/'cases'/key;folder.mkdir(parents=True)
        if old:
            origin=Path(old['folder']);files=old['files']
            for name,digest in files.items():pin(origin/name,digest)
            if old['complete_record']:record=read(origin/'record.json')
            else:
                record={'cohort':row['cohort'],'key':key,'case_id':row['case_id'],'task_id':row['task_id'],'model':'gpt-6-luna','model_key':'gpt6_luna','plan_sha256':BASE_SHA,'input_row_sha256':row['input_row_sha256'],'status':'transport_error','attempted':True,'final':'','truncated':False,'empty_final':True,'refused':False,'http_status':None,'ambiguous_preserved':True}
                from runtime import canonical
                raw=canonical({'local_transport_error_type':'AmbiguousOriginalReservationPreservedWithoutRetry'})
                record['response_sha256']=create(folder/'response.json',raw);record['final_sha256']=create(folder/'final.txt',b'')
                create(folder/'request.json',{'payload_without_private_safety_identifier':row['payload'],'actual_dispatch_unknown':True})
                create(folder/'dispatch_receipt.json',{'actual_dispatch_unknown':True,'plan_sha256':BASE_SHA,'attempt':1})
            segment='original64'
        else:
            origin=newer/row['cohort']/'cases'/key;record=new_records[key];files={n:sha((origin/n).read_bytes())for n in ['request.json','dispatch_receipt.json','response.json','final.txt','record.json']};segment='continuation128'
        if not record.get('ambiguous_preserved'):
            if record.get('attempted')is not True or record.get('plan_sha256')!=(BASE_SHA if old else plan_sha)or any(record.get(k)!=row[k]for k in('key','case_id','task_id','cohort')):raise ValueError('Source segment identity differs')
            for name in ['request.json','dispatch_receipt.json','response.json','final.txt']:
                data=(origin/name).read_bytes()
                if sha(data)!=files[name]:raise ValueError('Source changed during copy')
                create(folder/name,data)
        create(folder/'record.json',record);merged[key]=record
        lineage[key]={'segment':segment,'source_folder':str(origin),'source_files':files,'ambiguous_preserved':bool(record.get('ambiguous_preserved'))}
    manifest_sha=create(combined/'merge_manifest.json',{'plan_sha256':plan_sha,'original_plan_sha256':BASE_SHA,'boundary_sha256':p['boundary_sha256'],'new_prediction_lock_sha256':sha(lock_path.read_bytes()),'cases':lineage})
    for cohort,count in [('liveproteinbench',1736),('labbench2',542)]:
        rows=[merged[r['key']]for r in source if r['cohort']==cohort]
        if len(rows)!=count:raise ValueError('Combined cohort count mismatch')
        out=combined/cohort;locksha=create(out/'prediction_lock.json',{'plan_sha256':plan_sha,'original_plan_sha256':BASE_SHA,'planned':count,'rows':rows,'merge_manifest_sha256':manifest_sha})
        create(out/'completion.json',{'plan_sha256':plan_sha,'planned':count,'attempted':count,'terminal':count,'all_planned_attempted':True,'ambiguous_preserved_count':sum(bool(r.get('ambiguous_preserved'))for r in rows),'prediction_lock_sha256':locksha,'merge_manifest_sha256':manifest_sha})
    create(combined/'process_terminal.json',{'plan_sha256':plan_sha,'returncode':0,'source_API_process_terminal_sha256':sha((newer/'process_terminal.json').read_bytes()),'merge_manifest_sha256':manifest_sha})
    return combined
