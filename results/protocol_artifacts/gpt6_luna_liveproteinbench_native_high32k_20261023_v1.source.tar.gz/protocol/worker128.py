import os,sys,json,threading
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import original_dispatcher as D
from runtime import Budget,Pacer,canonical,create,sha,update
F=D.F;time=D.time;execute=D.execute;row_identity=D.row_identity;transport=D.transport
def run_phase(rows,out,plan_sha,secrets,budget,pacer,stop,guard,send=transport,max_workers=128):
    if not 1<=max_workers<=128:raise ValueError('Concurrency cap')
    records=[];index=0;pending={};peak=0
    with F.ThreadPoolExecutor(max_workers=max_workers)as pool:
        while pending or index<len(rows):
            while not stop.is_set()and index<len(rows)and len(pending)<max_workers:
                row=rows[index]
                try:available=pacer.acquire(row['rate_token_reservation'])
                except BaseException:
                    with guard:stop.set()
                    raise
                if not available:break
                future=pool.submit(execute,row,out,plan_sha,secrets['key'],secrets['identifier'],budget,stop,guard,send)
                pending[future]=row;index+=1;peak=max(peak,len(pending))
            if pending:
                done,_=F.wait(pending,timeout=1,return_when=F.FIRST_COMPLETED)
                for f in done:
                    pending.pop(f)
                    try:record,headers=f.result()
                    except BaseException:
                        with guard:stop.set()
                        raise
                    records.append(record);pacer.observe(headers)
            elif stop.is_set():break
            else:time.sleep(.25)
            update(out/'progress.json',{'phase':'generation','saved':sum(r['attempted']for r in records),'planned':len(rows),'in_flight':len(pending),'peak_in_flight':peak,'reserved_nano_usd':budget.used,'stopped':stop.is_set()})
    for row in rows[index:]:records.append({**row_identity(row),'status':'not_dispatched','attempted':False})
    return records

def worker():
    bundle=Path(__file__).resolve().parent;out=Path(sys.argv[2]);expected=sys.argv[3]
    raw=(bundle/'plan.json').read_bytes()
    if sha(raw)!=expected:raise ValueError('Continuation plan changed')
    plan=D.OLD.parse_json(raw)
    for name,digest in plan['bundle_files'].items():
        if sha((bundle/name).read_bytes())!=digest:raise ValueError('Bundle changed')
    with os.fdopen(int(sys.argv[4]),'rb')as f:secrets=D.OLD.parse_json(f.read(16384))
    if secrets.get('authorized_plan_sha256')!=expected:raise ValueError('Wrong authority')
    abi=D.OLD.restrict_filesystem(bundle,out)
    try:Path(secrets['denial_probe']).read_bytes()
    except PermissionError:pass
    else:raise ValueError('Isolation failed')
    create(out/'isolation.json',{'pid':os.getpid(),'Landlock_ABI':abi,'outside_probe_denied':True})
    rows=[D.OLD.parse_json(x)for x in(bundle/'requests.jsonl').read_bytes().splitlines()]
    if [r['key']for r in rows]!=plan['untouched_keys']or len(set(plan['untouched_keys']))!=len(rows):raise ValueError('Untouched roster differs')
    for r in rows:
        cap=32768 if r['cohort']=='liveproteinbench'else 16384
        D.validate_payload(r['payload'],cap);bound=len(canonical(r['payload']['input']))+2048
        if r['cohort']not in{'liveproteinbench','labbench2'}or bound>272000 or r['input_token_upper_bound']!=bound or r['rate_token_reservation']!=bound+cap or r['max_output_tokens']!=cap or r['max_cost_nano_usd']!=bound*125+cap*500 or r['payload_sha256']!=sha(canonical(r['payload'])):raise ValueError('Payload/budget changed')
    if type(plan['initial_reserved_nano_usd'])is not int or not 0<=plan['initial_reserved_nano_usd']<=50_000_000_000:raise ValueError('Invalid carried budget')
    budget=Budget(out/'reservations');budget.used=plan['initial_reserved_nano_usd']
    if budget.used+sum(r['max_cost_nano_usd']for r in rows)>50_000_000_000:raise ValueError('Combined budget exceeded')
    create(out/'inherited_budget.json',{'reserved_nano_usd':budget.used,'boundary_sha256':plan['boundary_sha256']})
    pacer=Pacer();stop=threading.Event();guard=threading.Lock()
    records=run_phase(rows[:1],out,expected,secrets,budget,pacer,stop,guard,max_workers=1)
    if rows and {'requests','tokens'}.issubset(pacer.learned)and not stop.is_set():
        records+=run_phase(rows[1:],out,expected,secrets,budget,pacer,stop,guard)
    else:
        records += [{**row_identity(r),'attempted':False,'status':'not_dispatched'}for r in rows[1:]]
    create(out/'prediction_lock.json',{'plan_sha256':expected,'rows':records,'planned':len(rows),'initial_reserved_nano_usd':plan['initial_reserved_nano_usd'],'final_reserved_nano_usd':budget.used})
    create(out/'completion.json',{'plan_sha256':expected,'planned':len(rows),'attempted':sum(r['attempted']for r in records),'all_planned_attempted':all(r['attempted']for r in records),'prediction_lock_sha256':sha((out/'prediction_lock.json').read_bytes())})
    update(out/'status.json',{'stage':'solver_terminal','plan_sha256':expected,'stopped':stop.is_set()})

if __name__=='__main__':
    try:worker()
    except BaseException as e:
        try:update(Path(sys.argv[2])/'status.json',{'stage':'worker_stopped_for_review','plan_sha256':sys.argv[3],'error_type':type(e).__name__})
        except Exception:pass
        raise
