"""Input-only isolated Responses API worker; no scorers or reference access."""
import concurrent.futures as F
import importlib.util,json,os,sys,threading,time,urllib.request,urllib.error
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from runtime import Budget,Pacer,canonical,create,sha,update,syncdir

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('old_client',HERE/'old_client.py')
OLD=importlib.util.module_from_spec(spec);spec.loader.exec_module(OLD)
ENDPOINT='https://api.openai.com/v1/responses'

def validate_payload(p,cap):
    if set(p)!={'model','input','reasoning','max_output_tokens','service_tier','store'}:raise ValueError('Unexpected API fields')
    if p['model']!='gpt-6-luna'or p['reasoning']!={'effort':'high'}or p['max_output_tokens']!=cap or p['service_tier']!='default'or p['store']is not False:raise ValueError('Generation differs from plan')
    for m in p['input']:
        if set(m)!={'role','content'}or m['role']not in{'system','user'}:raise ValueError('Non-native role')
        if not isinstance(m['content'],list)or not m['content']:raise ValueError('Missing text')
        for c in m['content']:
            if set(c)!={'type','text'}or c['type']!='input_text'or not isinstance(c['text'],str):raise ValueError('Non-text content')

def transport(body,key):
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    request=urllib.request.Request(ENDPOINT,data=body,method='POST',headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
    try:
        with opener.open(request,timeout=3600)as r:return r.status,r.read(),dict(r.headers)
    except urllib.error.HTTPError as e:return e.code,e.read(),dict(e.headers)

def execute(row,out,plan_sha,key,identifier,budget,stop,guard,send):
    folder=out/row['cohort']/'cases'/row['key'];folder.mkdir(parents=True);syncdir(folder.parent)
    p=row['payload'];validate_payload(p,row['max_output_tokens'])
    public=canonical(p)
    if sha(public)!=row['payload_sha256']:raise ValueError('Payload drift')
    actual=canonical({**p,'safety_identifier':identifier})
    with guard:
        if stop.is_set():return {**row_identity(row),'status':'not_dispatched','attempted':False},{}
        budget.reserve(row['key'],row['max_cost_nano_usd'],{'payload_sha256':row['payload_sha256'],'plan_sha256':plan_sha})
        create(folder/'request.json',{'payload_without_private_safety_identifier':p,'actual_submitted_payload_sha256':sha(actual)})
        create(folder/'dispatch_receipt.json',{**row_identity(row),'plan_sha256':plan_sha,'actual_submitted_payload_sha256':sha(actual),'attempt':1})
    begin=time.monotonic();status=None;headers={}
    try:status,raw,headers=send(actual,key)
    except Exception as e:raw=canonical({'local_transport_error_type':type(e).__name__})
    final='';truncated=False;refused=False;usage=None;state='transport_error';response_id=None
    if status is not None:
        state='http_error'
        if status==200:
            try:
                response=OLD.parse_json(raw)
                if response.get('model')!='gpt-6-luna':raise ValueError('Response model mismatch')
                final,refused=OLD.extract_visible(response);usage=response.get('usage');response_id=response.get('id')
                truncated=response.get('status')=='incomplete'and response.get('incomplete_details',{}).get('reason')=='max_output_tokens'
                state='refusal'if refused else'truncated'if truncated else'completed'if response.get('status')=='completed'and final.strip()else'response_error'
            except (ValueError,TypeError,AttributeError):state='response_error'
    if status==429 or OLD.stop_for_provider_error(status,raw,state):
        with guard:stop.set()
    response_sha=create(folder/'response.json',raw);final_sha=create(folder/'final.txt',final.encode())
    record={**row_identity(row),'model':'gpt-6-luna','model_key':'gpt6_luna','plan_sha256':plan_sha,
            'input_row_sha256':row['input_row_sha256'],'status':state,'attempted':True,'final':final,
            'truncated':truncated,'empty_final':not final.strip(),'refused':refused,'http_status':status,
            'usage':usage,'response_id':response_id,'latency_seconds':time.monotonic()-begin,
            'response_sha256':response_sha,'final_sha256':final_sha,'payload_sha256':row['payload_sha256'],
            'max_cost_nano_usd':row['max_cost_nano_usd'],'automatic_retry':False}
    create(folder/'record.json',record)
    return record,headers

def row_identity(r):return {k:r[k]for k in('cohort','key','case_id','task_id')}

def run_phase(rows,out,plan_sha,secrets,budget,pacer,stop,guard,send=transport,max_workers=64):
    if not 1<=max_workers<=64:raise ValueError('Concurrency cap')
    records=[];index=0;pending={};peak=0
    with F.ThreadPoolExecutor(max_workers=max_workers)as pool:
        while pending or index<len(rows):
            while not stop.is_set()and index<len(rows)and len(pending)<max_workers:
                row=rows[index]
                try:available=pacer.acquire(row['rate_token_reservation'])
                except BaseException:
                    with guard:stop.set()
                    raise
                if not available:break
                future=pool.submit(execute,row,out,plan_sha,secrets['key'],secrets['identifier'],budget,stop,guard,send)
                pending[future]=row;index+=1;peak=max(peak,len(pending))
            if pending:
                done,_=F.wait(pending,timeout=1,return_when=F.FIRST_COMPLETED)
                for f in done:
                    pending.pop(f)
                    try:record,headers=f.result()
                    except BaseException:
                        with guard:stop.set()
                        raise
                    records.append(record);pacer.observe(headers)
            elif stop.is_set():break
            else:time.sleep(.25)
            update(out/'progress.json',{'phase':'generation','saved':sum(r['attempted']for r in records),'planned':len(rows),'in_flight':len(pending),'peak_in_flight':peak,'reserved_nano_usd':budget.used,'stopped':stop.is_set()})
    for row in rows[index:]:records.append({**row_identity(row),'status':'not_dispatched','attempted':False})
    return records

def worker():
    bundle=HERE;out=Path(sys.argv[2]);expected=sys.argv[3];fd=int(sys.argv[4])
    plan_bytes=(bundle/'plan.json').read_bytes()
    if sha(plan_bytes)!=expected:raise ValueError('Frozen plan mismatch')
    plan=OLD.parse_json(plan_bytes)
    for name,digest in plan['bundle_files'].items():
        if sha((bundle/name).read_bytes())!=digest:raise ValueError('Frozen source/input mismatch')
    with os.fdopen(fd,'rb')as f:secrets=OLD.parse_json(f.read(16384))
    if secrets.get('authorized_plan_sha256')!=expected:raise ValueError('No exact plan authorization')
    abi=OLD.restrict_filesystem(bundle,out)
    try:Path(secrets['denial_probe']).read_bytes()
    except PermissionError:denied=True
    else:raise ValueError('Actual outside-bundle access was not denied')
    create(out/'isolation.json',{'pid':os.getpid(),'Landlock_ABI':abi,'repository_or_reference_access':False,'outside_probe_denied':denied})
    rows=[OLD.parse_json(x)for x in(bundle/'requests.jsonl').read_bytes().splitlines()]
    seen=set()
    for r in rows:
        if r['key']in seen:raise ValueError('Duplicate global case key')
        seen.add(r['key'])
        cap=16384 if r['cohort']=='labbench2' else r['max_output_tokens'] if r['cohort']=='development' else 32768
        if cap not in{16384,32768}:raise ValueError('Wrong cap')
        validate_payload(r['payload'],cap)
        bound=len(canonical(r['payload']['input']))+2048
        if bound>272000 or bound+cap>1_050_000 or r['input_token_upper_bound']!=bound or r['rate_token_reservation']!=bound+cap or r['max_cost_nano_usd']!=bound*125+cap*500 or r['payload_sha256']!=sha(canonical(r['payload'])):raise ValueError('Reservation/payload mismatch')
    dev=[r for r in rows if r['cohort']=='development'];benchmark=[r for r in rows if r['cohort']!='development']
    if len(dev)!=4 or len(benchmark)!=2278:raise ValueError('Exact phase count mismatch')
    if sum(r['cohort']=='liveproteinbench'for r in benchmark)!=1736 or sum(r['cohort']=='labbench2'for r in benchmark)!=542:raise ValueError('Exact cohort count mismatch')
    if sum(r['max_cost_nano_usd']for r in rows)>50_000_000_000:raise ValueError('Whole plan cost exceeds cap')
    budget=Budget(out/'reservations');pacer=Pacer();stop=threading.Event();guard=threading.Lock()
    controls=run_phase(dev[:1],out,expected,secrets,budget,pacer,stop,guard,max_workers=1)
    if len(controls)==1 and controls[0]['status']=='completed'and {'requests','tokens'}.issubset(pacer.learned):
        controls+=run_phase(dev[1:],out,expected,secrets,budget,pacer,stop,guard)
    create(out/'development_completion.json',{'plan_sha256':expected,'planned':4,'records':controls,
           'passed':len(controls)==4 and all(r['status']=='completed'for r in controls)})
    if len(controls)!=4 or any(r['status']!='completed'for r in controls):
        update(out/'status.json',{'stage':'development_failed_no_benchmark_dispatch','plan_sha256':expected});return
    records=run_phase(benchmark,out,expected,secrets,budget,pacer,stop,guard)
    bykey={r['key']:r for r in records}
    if len(bykey)!=2278 or set(bykey)!={r['key']for r in benchmark}:raise ValueError('Incomplete final record accounting')
    for source in benchmark:
        record=bykey[source['key']]
        if any(record[k]!=source[k]for k in('cohort','key','case_id','task_id')):raise ValueError('Final record identity drift')
        if record['attempted']:
            folder=out/record['cohort']/'cases'/record['key']
            if sha((folder/'response.json').read_bytes())!=record['response_sha256']or sha((folder/'final.txt').read_bytes())!=record['final_sha256']:raise ValueError('Final artifacts do not match sealed records')
    for cohort,count in [('liveproteinbench',1736),('labbench2',542)]:
        ordered=[bykey[r['key']]for r in benchmark if r['cohort']==cohort]
        folder=out/cohort
        lock={'schema_version':1,'cohort':cohort,'plan_sha256':expected,'model':'gpt-6-luna',
              'planned':count,'rows':ordered,'no_retries':True,'scoring_performed':False}
        locksha=create(folder/'prediction_lock.json',lock)
        create(folder/'completion.json',{'cohort':cohort,'plan_sha256':expected,'prediction_lock_sha256':locksha,
            'planned':count,'attempted':sum(r['attempted']for r in ordered),
            'terminal':sum(r['attempted']for r in ordered),'all_planned_attempted':all(r['attempted']for r in ordered),
            'valid_deliveries':sum(r['status']=='completed'for r in ordered),'scoring_performed':False})
    update(out/'status.json',{'stage':'solver_terminal','plan_sha256':expected,'reserved_nano_usd':budget.used,
                            'stopped_after_policy_access_or_rate_limit':stop.is_set(),'scoring_performed':False})

if __name__=='__main__':
    if len(sys.argv)!=5 or sys.argv[1]!='worker':raise SystemExit('Only explicit isolated worker invocation is supported')
    try:worker()
    except BaseException as e:
        try:update(Path(sys.argv[2])/'status.json',{'stage':'worker_stopped_for_review','plan_sha256':sys.argv[3],'error_type':type(e).__name__,'automatic_retry':False})
        except Exception:pass
        raise
