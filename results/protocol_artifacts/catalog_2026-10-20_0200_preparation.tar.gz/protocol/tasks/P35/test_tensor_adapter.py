"""Neutral tensor fixtures only. No pretrained model forward or real sequence."""
import types,unittest
import torch
import adapter

class TensorContractTests(unittest.TestCase):
    def test_normalized_native_similarity_and_topk(self):
        p=torch.zeros((3,512));p[0,0]=2;p[1,1]=3;p[2,0]=-1
        t=torch.zeros((1,512));t[0,0]=4
        out=adapter.retrieval_from_features(t,p,torch.tensor(0.),['A','B','C'],topk=2)
        self.assertEqual(out['indices'].tolist(),[[0,1]])
        self.assertTrue(torch.equal(out['scores'],torch.tensor([[1.,0.,-1.]])))
        self.assertIsNone(out['native_aggregate_metric'])
    def test_zero_norm_not_silently_normalized(self):
        with self.assertRaises(ValueError):adapter.retrieval_from_features(torch.zeros((1,512)),torch.ones((1,512)),torch.tensor(0.),['A'],topk=1)
    def test_nonfinite_feature(self):
        with self.assertRaises(ValueError):adapter.retrieval_from_features(torch.full((1,512),float('nan')),torch.ones((1,512)),torch.tensor(0.),['A'],topk=1)
    def test_modelled_residue_crop_boundary(self):
        class Alphabet:
            padding_idx=0;cls_idx=1;eos_idx=2
            def __len__(self):return 10
        class Recorder:
            def __init__(self):self.tokens=None
            def __call__(self,tokens,repr_layers):
                self.tokens=tokens;self.layers=repr_layers
                return {'representations':{33:tokens.float().unsqueeze(-1).repeat(1,1,512)}}
        model=Recorder();protein=types.SimpleNamespace(alphabet=Alphabet(),mapping=torch.arange(10),model=model,graph_mlp=lambda x:x)
        features,counts=adapter.encode_modelled_residue_batch({'torch':torch,'protein':protein},[[3]*1023,[4]*2])
        self.assertEqual(counts['source_modelled_lengths'],[1023,2]);self.assertEqual(counts['encoded_lengths'],[1022,2]);self.assertEqual(counts['native_1022_crop_count'],1)
        self.assertEqual(model.tokens.shape,(2,1024));self.assertEqual(model.tokens[0,-1].item(),2)
        self.assertTrue(torch.equal(features[:,0],torch.tensor([3.,4.])))
    def test_query_cls_without_sep_and_masked_mean(self):
        class Tokenizer:
            cls_token_id=1;sep_token_id=2;pad_token_id=0
            def encode(self,text,**kwargs):
                self.kwargs=kwargs;return [3,4]
        class FakeBert:
            def __call__(self,**kwargs):
                self.ids=kwargs['input_ids'];return types.SimpleNamespace(last_hidden_state=self.ids.float().unsqueeze(-1).repeat(1,1,512))
        tokenizer=Tokenizer();bert=FakeBert();text=types.SimpleNamespace(model=types.SimpleNamespace(bert=bert),text_mlp=lambda x:x)
        out=adapter.encode_retrieval_queries({'torch':torch,'text':text,'tokenizer':tokenizer},['neutral fixture'])
        self.assertEqual(bert.ids.tolist(),[[1,3,4]]);self.assertEqual(tokenizer.kwargs,{'max_length':128,'truncation':True,'add_special_tokens':False})
        self.assertAlmostEqual(out[0,0].item(),3.5,places=5)
if __name__=='__main__':unittest.main()
