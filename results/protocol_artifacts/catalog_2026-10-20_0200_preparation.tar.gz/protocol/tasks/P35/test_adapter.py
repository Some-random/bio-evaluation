import io,json,math,tempfile,unittest,zipfile
from pathlib import Path
import adapter

class Shape:
    def __init__(self,*s):self.shape=s

class ContractTests(unittest.TestCase):
    def test_metadata_only_order_and_cutoff(self):
        with tempfile.TemporaryDirectory()as d:
            path=Path(d)/'outer.zip'
            with zipfile.ZipFile(path,'w')as z:
                z.writestr('GeneOntology/nrPDB-GO_test.csv','id,a,b,c,d,e\nT0,1,1,1,1,0\nT1,1,1,1,1,1\n')
                z.writestr('GeneOntology/nrPDB-GO_annot.tsv','DO NOT READ')
                for split,names in [('train',['Z','A']),('valid',['V']),('test',['T1','T0'])]:
                    b=io.BytesIO()
                    with zipfile.ZipFile(b,'w')as inner:
                        for name in names:inner.writestr(f'{split}/{name}_fixture.pdb','NOT A VALID PDB; metadata only')
                    z.writestr(f'GeneOntology/{split}.zip',b.getvalue(),compress_type=zipfile.ZIP_STORED)
            rows,counts=adapter.inventory_archive(path)
            self.assertEqual([r['pdb_id']for r in rows],['A','Z','V','T1'])
            # Source identity follows basename.split('_')[0]; cutoff applies before parsing.
            self.assertEqual(counts['test']['cutoff_removed_entries'],1)
    def test_actual_source_identity_filter_with_underscore(self):
        raw=b'id,a,b,c,d,e\nT0,1,1,1,1,0\nT1,1,1,1,1,1\n'
        self.assertEqual(adapter.excluded_test_ids(raw),{'T0'})
    def test_duplicate_cutoff_metadata_rejected(self):
        with self.assertRaises(ValueError):adapter.excluded_test_ids(b'id,a,b,c,d,e\nA,1,1,1,1,1\nA,1,1,1,1,1\n')
    def test_unsafe_member(self):
        for name in ['../x','/x','a\\x']:
            with self.subTest(name=name),self.assertRaises(ValueError):adapter.safe_member(name)
    def test_corpus_rejection_accounting(self):
        x=[{'pdb_id':v}for v in ['A','B','C']]
        self.assertEqual(adapter.bind_retained_corpus(x,['A','C'],{'B':'parser failure'})['retained_count'],2)
    def test_missing_parse_accounting(self):
        with self.assertRaises(ValueError):adapter.bind_retained_corpus([{'pdb_id':'A'},{'pdb_id':'B'}],['A'],{})
    def test_reordered_corpus_rejected(self):
        with self.assertRaises(ValueError):adapter.bind_retained_corpus([{'pdb_id':'A'},{'pdb_id':'B'}],['B','A'],{})
    def test_changed_learned_shape_rejected(self):
        with self.assertRaises(ValueError):adapter.check_state_keys({'w':Shape(2,3)},{'w':Shape(3,2)})
    def test_missing_learned_key_rejected(self):
        with self.assertRaises(ValueError):adapter.check_state_keys({'w':Shape(2)},{})
    def test_only_explicit_unused_buffer_may_be_dropped(self):
        state,extras=adapter.check_state_keys({'w':Shape(2)},{'w':Shape(2),'position_ids':Shape(3)},allowed_recomputed=['position_ids'])
        self.assertEqual(extras,['position_ids']);self.assertEqual(list(state),['w'])
    def test_incomplete_ranking_rejected(self):
        with self.assertRaises(ValueError):adapter.validate_ranking_scores([[1]],1,['A','B'],1)
    def test_nonfinite_ranking_rejected(self):
        with self.assertRaises(ValueError):adapter.validate_ranking_scores([[math.nan]],1,['A'],1)
    def test_full_ranking_contract(self):adapter.validate_ranking_scores([[.1,.2],[.3,.4]],2,['A','B'],2)
    def test_missing_joint_branch_rejected(self):
        with self.assertRaises(ValueError):adapter.split_checkpoint_state({'protein_model.a':1,'logit_scale':1})

if __name__=='__main__':unittest.main()
