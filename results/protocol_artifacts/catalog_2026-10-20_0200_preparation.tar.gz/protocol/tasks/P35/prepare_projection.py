"""Dormant future source projection. No automatic corpus reads or model calls.

A root-reviewed frozen authorization must name the exact source inventory hash,
case IDs and RDKit projection condition before main() accepts any PDB payload.
The present task only tests its neutral injected-molecule contract.
"""
import argparse,io,json,hashlib,zipfile
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import adapter

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--grant',required=True);ap.add_argument('--inventory',required=True)
    ap.add_argument('--archive',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    grant=json.loads(Path(args.grant).read_text())
    expected='PROTST_RELEASED5Q_RDKIT_PROJECTION_V1'
    if grant.get('authorized')is not True or grant.get('task_id')!='P35' or grant.get('condition')!=expected:
        raise ValueError('no compatible frozen projection authorization')
    if adapter.sha256(args.inventory)!=grant.get('source_inventory_sha256'):
        raise ValueError('inventory identity mismatch')
    candidates=[json.loads(x)for x in Path(args.inventory).read_text().splitlines()]
    if [r['pdb_id']for r in candidates]!=grant.get('reviewed_case_ids'):
        raise ValueError('complete independently reviewed corpus IDs are required')
    if adapter.sha256(args.archive)!=adapter.CORPUS_SHA256:raise ValueError('archive identity mismatch')
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    if any(out.iterdir()):raise ValueError('refuse to overwrite any previous projection')
    from rdkit import Chem,rdBase
    if grant.get('rdkit_version')!=rdBase.rdkitVersion:raise ValueError('runtime version mismatch')
    retained=[];rejected={};results=[]
    with zipfile.ZipFile(args.archive)as outer:
        for split in ['train','valid','test']:
            info=outer.getinfo('GeneOntology/'+split+'.zip')
            with adapter.StoredMemberReader(args.archive,info)as view,zipfile.ZipFile(view)as inner:
                for record in candidates:
                    if record['split']!=split:continue
                    try:
                        b=inner.read(record['member'])
                        ids,qual=adapter.project_rdkit_modelled_residues(Chem.MolFromPDBBlock(b.decode('ascii')))
                        results.append({'pdb_id':record['pdb_id'],'modelled_residue_ids':ids,'source_pdb_sha256':hashlib.sha256(b).hexdigest(),'qualification':qual})
                        retained.append(record['pdb_id'])
                    except Exception as e:rejected[record['pdb_id']]=type(e).__name__+': '+str(e)
    binding=adapter.bind_retained_corpus(candidates,retained,rejected)
    file=out/'model_inputs.jsonl';file.write_text(''.join(json.dumps(x,sort_keys=True)+'\n'for x in results))
    receipt={'task_id':'P35','condition':expected,'stage':'qualified_projection_complete_not_inference',
        'updated_at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),'rdkit_version':rdBase.rdkitVersion,
        'retention':binding,'rejections':rejected,'model_inputs_sha256':adapter.sha256(file),
        'full_native_graph_validation':False,'new_inference_calls':0,'benchmark_score':None}
    (out/'completion.json').write_text(json.dumps(receipt,indent=2)+'\n')
if __name__=='__main__':main()
