import json,tempfile,types,unittest
from pathlib import Path
from unittest import mock
import torch,adapter

class RuntimeGuardTests(unittest.TestCase):
    def test_meta_index_buffers_regenerated_before_forward(self):
        emb=types.SimpleNamespace(position_ids=torch.empty((1,4),device='meta'),token_type_ids=torch.empty((1,4),device='meta'))
        module=types.SimpleNamespace(model=types.SimpleNamespace(bert=types.SimpleNamespace(embeddings=emb),config=types.SimpleNamespace(max_position_embeddings=4)))
        names=adapter.regenerate_bert_index_buffers(module,torch)
        self.assertEqual(len(names),2);self.assertEqual(emb.position_ids.device.type,'cpu')
        self.assertEqual(emb.position_ids.tolist(),[[0,1,2,3]]);self.assertEqual(emb.token_type_ids.tolist(),[[0,0,0,0]])
    def fixture(self,p):
        file=p/'checkpoint';file.write_bytes(b'neutral checkpoint fixture')
        anchor=p/'anchor.json';anchor.write_text('{}')
        digest=adapter.sha256(file);cache=p/'cache.json'
        cache.write_text(json.dumps({'sha256':digest,'file_identity':adapter.checkpoint_file_identity(file),'full_hash_receipt':str(anchor),'full_hash_receipt_sha256':adapter.sha256(anchor)}))
        return file,anchor,cache,digest
    def test_unchanged_verified_file_reuses_only_hash_anchor(self):
        with tempfile.TemporaryDirectory()as d:
            file,anchor,cache,digest=self.fixture(Path(d));original=adapter.sha256
            def guarded(p):
                if Path(p)==file:raise AssertionError('unchanged exact inode need not be re-read')
                return original(p)
            with mock.patch.object(adapter,'CHECKPOINT_CACHE_PATH',cache),mock.patch.object(adapter,'CHECKPOINT_SHA256',digest),mock.patch.object(adapter,'sha256',guarded):
                self.assertEqual(adapter.verify_checkpoint_identity(file),digest)
    def test_changed_checkpoint_is_not_cache_verified(self):
        with tempfile.TemporaryDirectory()as d:
            file,anchor,cache,digest=self.fixture(Path(d));file.write_bytes(b'changed fixture')
            with mock.patch.object(adapter,'CHECKPOINT_CACHE_PATH',cache),mock.patch.object(adapter,'CHECKPOINT_SHA256',digest),self.assertRaises(ValueError):adapter.verify_checkpoint_identity(file)
    def test_modified_hash_receipt_forces_full_file_hash(self):
        with tempfile.TemporaryDirectory()as d:
            file,anchor,cache,digest=self.fixture(Path(d));anchor.write_text('{"changed":true}')
            with mock.patch.object(adapter,'CHECKPOINT_CACHE_PATH',cache),mock.patch.object(adapter,'CHECKPOINT_SHA256',digest),mock.patch.object(adapter,'sha256',wraps=adapter.sha256)as wrapped:
                self.assertEqual(adapter.verify_checkpoint_identity(file),digest);self.assertIn(mock.call(file),wrapped.call_args_list)
if __name__=='__main__':unittest.main()
