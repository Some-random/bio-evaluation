"""Compare consumed residue fields with pinned native source on synthetic objects."""
import ast,types,unittest,warnings
from pathlib import Path
import torch,adapter

class Info:
    def __init__(self,num,name,chain='A',code=' '):self.num,self.name,self.chain,self.code=num,name,chain,code
    def GetResidueNumber(self):return self.num
    def GetInsertionCode(self):return self.code
    def GetResidueName(self):return self.name
    def GetChainId(self):return self.chain
    def GetName(self):return 'CA'
    def GetIsHeteroAtom(self):return False
    def GetOccupancy(self):return 1.
    def GetTempFactor(self):return 0.
class Atom:
    def __init__(self,info):self.info=info
    def GetPDBResidueInfo(self):return self.info
class Mol:
    def __init__(self,infos):self.atoms=[Atom(x)for x in infos]
    def GetNumAtoms(self):return len(self.atoms)
    def GetAtoms(self):return self.atoms
    def GetAtomWithIdx(self,i):return self.atoms[i]

def source_function():
    file=Path(__file__).parent/'upstream_runtime_source/torchdrug__data__protein.py'
    tree=ast.parse(file.read_text());cls=next(x for x in tree.body if isinstance(x,ast.ClassDef)and x.name=='Protein')
    f=next(x for x in cls.body if isinstance(x,ast.FunctionDef)and x.name=='from_molecule');f.decorator_list=[]
    module=ast.Module(body=[f],type_ignores=[]);ast.fix_missing_locations(module)
    class Molecule:
        @staticmethod
        def from_molecule(mol,**kwargs):return types.SimpleNamespace(edge_list=[],num_node=mol.GetNumAtoms(),meta_dict={},data_dict={})
    ns={'torch':torch,'warnings':warnings,'Molecule':Molecule}
    exec(compile(module,str(file),'exec'),ns);return ns['from_molecule']

class NativeCapture:
    residue2id=adapter.NATIVE_RESIDUE_IDS;alphabet2id={x:i for i,x in enumerate(adapter.NATIVE_PDB_ALPHABET)}
    atom_name2id={'CA':1,'UNK':37};dummy_atom=Atom(Info(1,'GLY'))
    _standarize_option=staticmethod(lambda x:[])
    def __init__(self,*args,**kwargs):self.fields=kwargs

class ProjectionTests(unittest.TestCase):
    def compare(self,infos):
        mol=Mol(infos);native=source_function()(NativeCapture,mol,atom_feature=None,bond_feature=None,residue_feature=None)
        projected,report=adapter.project_rdkit_modelled_residues(mol,dummy_atom=NativeCapture.dummy_atom)
        self.assertEqual(projected,native.fields['residue_type'].tolist());self.assertTrue(report['projection_only'])
        return projected
    def test_boundary_and_unknown_conversion(self):
        self.assertEqual(self.compare([Info(2,'ALA'),Info(2,'ALA'),Info(3,'ZZZ'),Info(4,'SER')]),[1,0,2])
    def test_native_canonical_boundary_ignores_chain(self):
        self.assertEqual(self.compare([Info(2,'ALA','A'),Info(2,'ALA','B'),Info(3,'VAL')]),[1,4])
    def test_native_dummy_tail_semantics_preserved(self):
        self.assertEqual(self.compare([Info(2,'ALA'),Info(1,'GLY')]),[1])
    def test_invalid_chain_rejected(self):
        mol=Mol([Info(2,'ALA',chain='?')])
        with self.assertRaises(ValueError):adapter.project_rdkit_modelled_residues(mol,dummy_atom=NativeCapture.dummy_atom)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore');self.assertIsNone(source_function()(NativeCapture,mol,residue_feature=None))
if __name__=='__main__':unittest.main()
