"""Reproducible metadata-only corpus inventory; no PDB/annotation payload reads."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,adapter,zipfile,csv,io
ROOT=Path(__file__).resolve().parents[4]
TASK=Path(__file__).resolve().parent
ASSETS=ROOT/'.local/source_acquisition_2026-10-19/evaluators'
if __name__=='__main__':
    archive=ASSETS/'data/GeneOntology.zip'
    if adapter.sha256(archive)!=adapter.CORPUS_SHA256:raise ValueError('corpus hash mismatch')
    records,counts=adapter.inventory_archive(archive)
    with zipfile.ZipFile(archive)as z:csvrows=list(csv.reader(io.StringIO(z.read('GeneOntology/nrPDB-GO_test.csv').decode())))
    csv_ids={r[0]for r in csvrows[1:]};file_ids={r['pdb_id']for r in records if r['split']=='test'}
    ids=TASK/'candidate_inventory.jsonl'
    ids.write_text(''.join(json.dumps(r,sort_keys=True)+'\n'for r in records))
    now=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
    manifest={'task_id':'P35','stage':'metadata_candidate_inventory_complete_not_graph_retention',
        'updated_at_pacific':now,'protocol_variant':'PROTST_RELEASED_FIVE_QUERY_TOP20_OFFLINE_ADAPTER_V1',
        'source_revision':adapter.PROTST_REVISION,'corpus_sha256':adapter.CORPUS_SHA256,
        'archive_bytes':archive.stat().st_size,'test_cutoff_csv_metadata_rows':len(csvrows)-1,
        'cutoff95_excluded_ids':sum(r[5]=='0'for r in csvrows[1:]),'csv_test_identities_without_pdb_member':sorted(csv_ids-file_ids),
        'pdb_test_identities_without_csv_row':sorted(file_ids-csv_ids),
        'archive_candidate_order':'train, valid, test; sorted PDB paths; 0.95 filtering; graph retention unexecuted','candidate_count':len(records),'split_counts':counts,
        'ordered_candidate_id_sha256':adapter.ordered_id_sha256(records),
        'candidate_inventory_sha256':adapter.sha256(ids),'graph_parser_executed':False,
        'runtime_retained_count':None,'pdb_payloads_read':0,'annotations_read':False,
        'sequences_read':False,'query_count':5,'topk':20,'new_inference_calls':0,
        'inventory_is_not_parsed_case_count':True,'benchmark_dispatch_ready':False,
        'native_aggregate_metric':None,
        'native_aggregate_metric_reason':'Released retrieval command has no per-query relevance gold or aggregate accuracy/Recall@K evaluator.',
        'next_action':'Run the pinned graph parser in an isolated CPU runtime after corpus scope review; record each retained or rejected ID, bind complete native order, then freeze any inference grant.'}
    (TASK/'source_inventory.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({k:v for k,v in manifest.items()if k not in ('next_action',)},indent=2))
