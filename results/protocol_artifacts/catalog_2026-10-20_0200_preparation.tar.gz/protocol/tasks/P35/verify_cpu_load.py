"""Load exact frozen existing parameters on CPU; makes zero model forward calls."""
import adapter,json,time,os,importlib.metadata,socket
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
TASK=Path(__file__).resolve().parent;ROOT=TASK.parents[3]
if __name__=='__main__':
    # Reject an accidental GPU wheel. This verification is CPU assembly only.
    import torch
    if torch.version.cuda is not None:raise ValueError('CPU-only verification requires the pinned CPU Torch wheel')
    before=socket.socket.connect
    def no_network(*args,**kwargs):raise RuntimeError('offline checkpoint assembly attempted network access')
    socket.socket.connect=no_network
    start=time.time();cp=ROOT/'.local/source_acquisition_2026-10-19/evaluators/weights/protst_esm1b.pth'
    models=adapter.construct_checkpoint_models(cp,TASK/'pubmedbert_metadata')
    x={'task_id':'P35','stage':'cpu_checkpoint_load_passed_no_forward','updated_at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        'checkpoint_sha256':adapter.CHECKPOINT_SHA256,'bytes':cp.stat().st_size,'elapsed_seconds':time.time()-start,
        'adapter_sha256':adapter.sha256(TASK/'adapter.py'),'load_report':models['load_report'],
        'devices':sorted({str(t.device)for m in [models['protein'],models['text']]for t in m.state_dict().values()}),
        'model_forward_calls':0,'new_inference_calls':0,'training':False,'network_disabled':True,
        'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES'),'tokenizer_vocab_size':models['tokenizer'].vocab_size,
        'packages':{k:importlib.metadata.version(k)for k in ['torch','fair-esm','transformers','tokenizers','rdkit']}}
    (TASK/'cpu_checkpoint_load_receipt.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x,indent=2))
