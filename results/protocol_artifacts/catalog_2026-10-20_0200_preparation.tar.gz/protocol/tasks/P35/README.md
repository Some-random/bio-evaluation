# P35 separate retrieval preparation

The 1,691,808,865-byte GO archive and 8,531,223,409-byte ProtST joint checkpoint are downloaded. The later multipart-ETag completion receipt supersedes the original acquisition manifest's stale `failed_resumable` checkpoint entry. This preparation does not dispatch a solver, execute a pretrained model forward, train a head, allocate a GPU or score biological correctness.

`source_inventory.json` and `candidate_inventory.jsonl` reconstruct the complete released PDB-member order using only archive directories and the source test-cutoff metadata. There are 36,635 candidate members: 29,898 train, 3,322 validation and 3,415 test. These are candidates before graph parsing. The cutoff table contains 3,416 test IDs and excludes none at 0.95. Its ID `5JM5-A` has no corresponding PDB member in the publisher-verified archive. The source retrieval loader searches files actually retained from the entire configured corpus; a test-only search would change the task.

The released command returns the top 20 PDB paths for each of five fixed, previously reviewed queries. It defines no per-query relevance gold or aggregate accuracy/Recall@K evaluation. Ranked outputs can be delivered without inventing a benchmark score. The paper's qualitative structural/docking illustration is separate evidence. The retrieval task and its released checkpoint are available; an aggregate benchmark metric is not supplied by this release.

`adapter.py` provides:

- A memory-mapped, `weights_only=True` CPU loader that constructs ESM-1b/BERT architectures on the meta device and loads the exact existing joint checkpoint tensors. Missing learned keys or changed shapes fail. No redundant pretrained backbone weights are downloaded; no new head is trained.
- The source's query tokenization, masked mean, 512-dimensional projections, normalization, learned logit scale and global `torch.topk` interface.
- An explicit complete-corpus retention ledger. Every rejected parser input must have a reason; unknown omissions, duplicate IDs or changed order fail.
- A separately named RDKit projection adaptation for source PDB-modelled residue IDs. Synthetic checks compare the consumed residue fields against pinned native source, including its unusual boundary/sentinel behavior. Full native graph validation and historical retained-case equivalence remain unverified.

The prospective adaptation is `PROTST_RELEASED5Q_RDKIT_PROJECTION_V1`. Material source/runtime differences are in `source_availability.json`. It preserves complete PDB-modelled residues and the native ESM 1,022-residue encoding limit, rather than substituting complete FASTA or imposing the annotation task's 550-residue crop. Runtime package versions and native top-k tie behavior must accompany any future ranking. Historical numerical/rank equivalence is not asserted.

`prepare_projection.py` is dormant. It requires a separate frozen root grant naming the condition, inventory hash, exact independently reviewed corpus IDs and RDKit version before reading any real PDB payload. It produces no model forward or score. No such grant is created by this worker.

The CPU library environment is isolated under `/tmp/bio-p35-cpu-runtime-20261020` and `/tmp/bio-p35-cpu-runtime-extra-20261020`. `runtime_env.sh` sets its paths and disables CUDA/Hugging Face network access; it runs nothing. `runtime_requirements.lock` records installed versions. The two environment directories are local library caches, excluded from publication. Original checkpoint and corpus files are referenced without duplication.

To repeat neutral checks, source `runtime_env.sh`, then run:

```bash
python3 -m unittest discover -s .local/catalog_execution_2026-10-20/tasks/P35 -p 'test_*.py' -v
```

`verify_cpu_load.py` rehashes the original checkpoint, blocks network connections, constructs and binds CPU models and writes a no-forward receipt. It does not encode queries or proteins. The completed `cpu_checkpoint_load_receipt.json` verifies 551 protein keys and 212 text keys on CPU with network disabled and zero pretrained forwards. The two nonpersistent BERT index buffers are explicitly rebuilt on CPU after meta construction. A cache reuses the completed full-file hash only while the exact inode, device, size, nanosecond mtime/ctime and sealed hash-receipt bytes remain unchanged.

The next actual execution step is to adopt/freeze the qualified corpus-processing condition, complete its independent corpus scope review and retained-ID ledger, then pass a neutral task-specific delivery check before any root-authorized retrieval inference. None of the 36,635 inventory entries is a saved prediction or benchmark score.
