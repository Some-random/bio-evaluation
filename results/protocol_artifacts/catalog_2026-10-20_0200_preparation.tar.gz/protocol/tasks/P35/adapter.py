"""Offline ProtST retrieval preparation. No CLI or model forward is implicit.

Runtime assembly uses the released ESM/BERT architectures with learned tensors
from the single joint checkpoint. Graph parsing and a per-case execution grant
remain independent gates. Synthetic tests never use biological rows.
"""
from __future__ import annotations
import csv, hashlib, io, json, math, struct, zipfile
from pathlib import Path, PurePosixPath

PROTST_REVISION = 'db53a76ed2430eb66dd9c8134ace99fd60980fb3'
CHECKPOINT_SHA256 = 'c972afbf81cfcf978403b35a3b55c3cf6c82776fb6b629583bdc04c587c91b62'
CORPUS_SHA256 = 'a17214e8fab669b21945d778de0f50053b0275233f236c326bb3cf9dddbafae1'
CHECKPOINT_CACHE_PATH = Path(__file__).parent/'checkpoint_hash_cache.json'

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()

def safe_member(name):
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or '\\' in name:
        raise ValueError('unsafe archive member')
    return name

class StoredMemberReader(io.RawIOBase):
    """Seek a stored nested ZIP without copying or reading PDB payloads."""
    def __init__(self, outer_path, info):
        if info.compress_type != zipfile.ZIP_STORED or info.flag_bits & 1:
            raise ValueError('nested archive must be stored and unencrypted')
        self.f=open(outer_path,'rb'); self.f.seek(info.header_offset)
        header=self.f.read(30)
        if header[:4]!=b'PK\x03\x04': raise ValueError('invalid ZIP local header')
        n,e=struct.unpack_from('<HH',header,26)
        self.start=info.header_offset+30+n+e; self.size=info.file_size; self.pos=0
    def seekable(self): return True
    def readable(self): return True
    def tell(self): return self.pos
    def seek(self, offset, whence=0):
        p=offset if whence==0 else self.pos+offset if whence==1 else self.size+offset
        if p<0: raise ValueError('negative offset')
        self.pos=p; return p
    def read(self,n=-1):
        if n<0:n=self.size-self.pos
        n=max(0,min(n,self.size-self.pos)); self.f.seek(self.start+self.pos)
        b=self.f.read(n); self.pos+=len(b);return b
    def close(self):
        if hasattr(self,'f'):self.f.close()
        super().close()

def excluded_test_ids(csv_bytes, cutoff=0.95):
    cutoffs=[.3,.4,.5,.7,.95]
    if cutoff not in cutoffs: raise ValueError('unsupported cutoff')
    col=cutoffs.index(cutoff)+1; reader=csv.reader(io.StringIO(csv_bytes.decode()))
    header=next(reader)
    if len(header)!=6: raise ValueError('unexpected cutoff table width')
    seen=set();excluded=set()
    for row in reader:
        if len(row)!=6 or row[0] in seen or any(v not in ('0','1') for v in row[1:]):
            raise ValueError('invalid or duplicate cutoff metadata')
        seen.add(row[0])
        if row[col]=='0':excluded.add(row[0])
    return excluded

def inventory_archive(archive):
    """Inspect identifiers, ZIP metadata and cutoff flags only, never annotations/PDBs."""
    records=[];counts={};source_index=0
    with zipfile.ZipFile(archive) as outer:
        excluded=excluded_test_ids(outer.read('GeneOntology/nrPDB-GO_test.csv'))
        for split in ('train','valid','test'):
            info=outer.getinfo(f'GeneOntology/{split}.zip')
            with StoredMemberReader(archive,info) as view,zipfile.ZipFile(view) as inner:
                candidates=[]
                for item in inner.infolist():
                    safe_member(item.filename)
                    p=PurePosixPath(item.filename)
                    if len(p.parts)==2 and p.parts[0]==split and p.suffix=='.pdb':
                        candidates.append(item)
                candidates.sort(key=lambda x:x.filename)
                counts[split]={'archive_pdb_entries':len(candidates),'cutoff_removed_entries':0,'candidate_entries':0}
                for item in candidates:
                    pdb_id=PurePosixPath(item.filename).name.split('_')[0]
                    if pdb_id in excluded:
                        counts[split]['cutoff_removed_entries']+=1; continue
                    records.append({'source_index':source_index,'split':split,'pdb_id':pdb_id,
                        'inner_archive':info.filename,'member':item.filename,'bytes':item.file_size,
                        'crc32':f'{item.CRC:08x}','graph_parse_status':'not_run'})
                    source_index+=1;counts[split]['candidate_entries']+=1
    if len({r['pdb_id'] for r in records})!=len(records):raise ValueError('duplicate candidate identifier')
    return records,counts

def ordered_id_sha256(records):
    return hashlib.sha256(('\n'.join(r['pdb_id'] for r in records)+'\n').encode()).hexdigest()

def bind_retained_corpus(candidates, retained_ids, rejected):
    """A runtime may drop parse failures only with one explicit rejection per missing ID."""
    ids=[r['pdb_id']for r in candidates]
    if len(set(retained_ids))!=len(retained_ids) or set(retained_ids)&set(rejected):
        raise ValueError('duplicate or contradictory retention')
    if set(retained_ids)|set(rejected)!=set(ids):raise ValueError('unaccounted or foreign IDs')
    if any(not reason for reason in rejected.values()):raise ValueError('missing parse failure reason')
    if retained_ids!=[p for p in ids if p not in rejected]:raise ValueError('retained order changed')
    return {'candidate_count':len(ids),'retained_count':len(retained_ids),'rejected_count':len(rejected),
            'retained_order_sha256':hashlib.sha256(('\n'.join(retained_ids)+'\n').encode()).hexdigest()}

def split_checkpoint_state(state):
    branches={name:{k[len(name)+1:]:v for k,v in state.items()if k.startswith(name+'.')}
              for name in ('protein_model','text_model')}
    for name,b in branches.items():
        if not b:raise ValueError('missing checkpoint branch '+name)
    if 'logit_scale'not in state:raise ValueError('missing learned logit_scale')
    return branches,state['logit_scale']

def check_state_keys(expected, supplied, *, allowed_recomputed=()):
    # Recent Transformers marks these non-learned BERT index buffers nonpersistent; the loader recreates them on CPU.
    unexpected=set(supplied)-set(expected);allowed=set(allowed_recomputed)
    if set(expected)-set(supplied) or unexpected-allowed:
        raise ValueError('checkpoint parameter key mismatch')
    for k in expected:
        if tuple(expected[k].shape)!=tuple(supplied[k].shape):raise ValueError('checkpoint shape mismatch '+k)
    return {k:v for k,v in supplied.items()if k in expected},sorted(unexpected)

def validate_ranking_scores(scores, n_queries, corpus_ids, topk=20):
    if len(set(corpus_ids))!=len(corpus_ids)or not 1<=topk<=len(corpus_ids):raise ValueError('invalid corpus or k')
    if len(scores)!=n_queries:raise ValueError('missing query row')
    for row in scores:
        if len(row)!=len(corpus_ids)or any(not math.isfinite(float(v))for v in row):
            raise ValueError('incomplete or nonfinite scores')


def checkpoint_file_identity(path):
    p=Path(path).resolve();st=p.stat()
    return {'path':str(p),'size':st.st_size,'inode':st.st_ino,'device':st.st_dev,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}

def verify_checkpoint_identity(path):
    """Reuse a prior full hash only for the unchanged exact inode/stat identity."""
    cache_path=CHECKPOINT_CACHE_PATH
    identity=checkpoint_file_identity(path)
    if cache_path.exists():
        cache=json.loads(cache_path.read_text())
        if cache.get('file_identity')==identity and cache.get('sha256')==CHECKPOINT_SHA256:
            anchor=Path(cache['full_hash_receipt'])
            if anchor.exists()and sha256(anchor)==cache.get('full_hash_receipt_sha256'):
                return CHECKPOINT_SHA256
    digest=sha256(path)
    if checkpoint_file_identity(path)!=identity:raise ValueError('checkpoint changed during hashing')
    if digest!=CHECKPOINT_SHA256:raise ValueError('checkpoint hash mismatch')
    return digest

def regenerate_bert_index_buffers(module,torch):
    # Meta constructors leave nonpersistent buffers on meta: replace both before
    # any forward. The positions are source-standard deterministic integer IDs.
    emb=module.model.bert.embeddings
    n=module.model.config.max_position_embeddings
    emb.position_ids=torch.arange(n,dtype=torch.long,device='cpu').expand((1,-1))
    emb.token_type_ids=torch.zeros((1,n),dtype=torch.long,device='cpu')
    return ['model.bert.embeddings.position_ids','model.bert.embeddings.token_type_ids']

def construct_checkpoint_models(checkpoint, metadata_dir):
    """CPU mmap + meta architecture assembly, no forward, no downloads, no TorchDrug.

    Architecture replaces download-only constructors. Learned parameter names and
    shapes must match the released joint checkpoint exactly. No parameters are fit.
    """
    verify_checkpoint_identity(checkpoint)
    import torch
    import esm
    from argparse import Namespace
    from torch import nn
    from transformers import BertConfig,BertForMaskedLM,BertTokenizer
    md=Path(metadata_dir)
    metadata_hashes={'config.json':'56bab767c02bc792897638feb8addc06d483d9c73769a5f554bbabea1f5507a1','vocab.txt':'7b36651908a88bc38bda41b728b2a598191e0d3b553cbacf7b1e5f026d5b5b9f'}
    if any(sha256(md/name)!=digest for name,digest in metadata_hashes.items()):raise ValueError('tokenizer/config identity mismatch')
    config=BertConfig.from_json_file(str(md/'config.json'))
    tokenizer=BertTokenizer(vocab_file=str(md/'vocab.txt'),do_lower_case=True)
    checkpoint_object=torch.load(checkpoint,map_location='cpu',weights_only=True,mmap=True)
    branches,scale=split_checkpoint_state(checkpoint_object['model'])
    class Projection(nn.Module):
        def __init__(self,width):
            super().__init__(); self.layers=nn.ModuleList([nn.Linear(width,width),nn.Linear(width,512)])
        def forward(self,x):return self.layers[1](torch.relu(self.layers[0](x)))
    class Protein(nn.Module):
        def __init__(self):
            super().__init__();self.alphabet=esm.data.Alphabet.from_architecture('ESM-1b')
            args=Namespace(arch='roberta_large',layers=33,embed_dim=1280,ffn_embed_dim=5120,
                attention_heads=20,max_positions=1024,emb_layer_norm_before=True,token_dropout=True)
            self.model=esm.model.esm1.ProteinBertModel(args,self.alphabet)
            self.register_buffer('mapping',torch.empty_like(branches['protein_model']['mapping'],device='meta'))
            self.graph_mlp=Projection(1280);self.residue_mlp=Projection(1280)
    class Text(nn.Module):
        def __init__(self):
            super().__init__();self.model=BertForMaskedLM(config)
            self.text_mlp=Projection(768);self.word_mlp=Projection(768)
    with torch.device('meta'):
        protein=Protein();text=Text()
    compatibility={}
    for name,module in [('protein_model',protein),('text_model',text)]:
        allowed=('model.bert.embeddings.position_ids','model.bert.embeddings.token_type_ids')if name=='text_model'else ()
        chosen,dropped=check_state_keys(module.state_dict(),branches[name],allowed_recomputed=allowed)
        module.load_state_dict(chosen,strict=True,assign=True)
        regenerated=[]
        if name=='text_model':regenerated=regenerate_bert_index_buffers(module,torch)
        module.requires_grad_(False);module.eval()
        compatibility[name]={'parameter_or_buffer_keys_loaded':len(chosen),'checkpoint_index_buffers_replaced_by_exact_deterministic_indices':dropped,'nonpersistent_buffers_regenerated_on_cpu':regenerated}
        if any(v.device.type!='cpu' for v in list(module.parameters())+list(module.buffers())):raise ValueError('non-CPU or unresolved meta tensor')
    if scale.numel()!=1 or not torch.isfinite(scale).all():raise ValueError('invalid learned logit scale')
    return {'protein':protein,'text':text,'tokenizer':tokenizer,'logit_scale':scale.detach(),
            'load_report':compatibility,'torch':torch}


def retrieval_from_features(text_features,protein_features,logit_scale,corpus_ids,*,topk=20):
    """Authorized callers only: exact released normalized dot product and torch.topk.

    Accepts existing features. This function neither parses corpus rows nor runs a
    model. The caller freezes the complete retained corpus before any encoding.
    """
    import torch
    if text_features.ndim!=2 or protein_features.ndim!=2 or text_features.shape[1]!=512 or protein_features.shape[1]!=512:
        raise ValueError('invalid 512-dimensional feature arrays')
    if protein_features.shape[0]!=len(corpus_ids):raise ValueError('corpus feature order/size mismatch')
    for feature in (text_features,protein_features):
        if not torch.isfinite(feature).all()or (feature.norm(dim=-1)==0).any():raise ValueError('invalid feature')
    scores=logit_scale.exp()*(text_features/text_features.norm(dim=-1,keepdim=True))@(protein_features/protein_features.norm(dim=-1,keepdim=True)).t()
    validate_ranking_scores(scores.tolist(),text_features.shape[0],corpus_ids,topk)
    values,indices=torch.topk(scores,topk,dim=-1)
    return {'indices':indices,'scores':scores,'topk_scores':values,'corpus_ids':corpus_ids,
            'native_aggregate_metric':None,'claim':'ranked retrieval outputs only; correctness unassessed',
            'ties':'native torch.topk; device/version recorded by caller'}


def encode_modelled_residue_batch(models, residue_id_sequences):
    """Prospective native-equivalent encoder bridge for parser-produced residue IDs.

    Caller supplies complete PDB-modelled residue IDs from the pinned parser,
    preserving their source order. Native ESM first-1,022 cropping is explicit;
    no full FASTA or annotation is accepted by this interface.
    """
    torch=models['torch'];protein=models['protein'];alphabet=protein.alphabet
    if not residue_id_sequences or any(not s for s in residue_id_sequences):raise ValueError('empty modelled residue input')
    lengths=[min(len(s),1022)for s in residue_id_sequences]
    tokens=torch.full((len(lengths),max(lengths)+2),alphabet.padding_idx,dtype=torch.long)
    for i,seq in enumerate(residue_id_sequences):
        ids=torch.tensor(seq[:1022],dtype=torch.long)
        if (ids<0).any() or (ids>=len(protein.mapping)).any():raise ValueError('invalid native residue ID')
        mapped=protein.mapping[ids]
        if (mapped<0).any() or (mapped>=len(alphabet)).any():raise ValueError('unmapped native residue ID')
        tokens[i,0]=alphabet.cls_idx;tokens[i,1:lengths[i]+1]=mapped;tokens[i,lengths[i]+1]=alphabet.eos_idx
    with torch.inference_mode():
        out=protein.model(tokens,repr_layers=[33])['representations'][33]
        pooled=torch.stack([out[i,1:n+1].mean(dim=0)for i,n in enumerate(lengths)])
        features=protein.graph_mlp(pooled)
    return features,{'source_modelled_lengths':[len(s)for s in residue_id_sequences],
        'encoded_lengths':lengths,'native_1022_crop_count':sum(len(s)>1022 for s in residue_id_sequences),
        'full_modelled_sequences_preserved_by_caller':True}


def encode_retrieval_queries(models,queries):
    """Released query tokenization and masked mean; only reviewed frozen inputs."""
    torch=models['torch'];text=models['text'];tok=models['tokenizer'];features=[]
    if not queries or any(not isinstance(q,str)or not q.strip()for q in queries):raise ValueError('empty retrieval query')
    with torch.inference_mode():
        for query in queries:
            ids=tok.encode(query,max_length=128,truncation=True,add_special_tokens=False)
            ids=torch.tensor([[tok.cls_token_id]+ids],dtype=torch.long)
            mask=ids!=tok.pad_token_id
            out=text.model.bert(input_ids=ids,token_type_ids=torch.zeros_like(ids),attention_mask=mask)
            is_special=(ids==tok.cls_token_id)|(ids==tok.sep_token_id)|(ids==tok.pad_token_id)
            weights=(~is_special).to(torch.float32).unsqueeze(-1)
            pooled=(out.last_hidden_state*weights).sum(1)/(weights.sum(1)+1e-6)
            features.append(text.text_mlp(pooled))
    return torch.cat(features,dim=0)


NATIVE_RESIDUE_IDS={'GLY':0,'ALA':1,'SER':2,'PRO':3,'VAL':4,'THR':5,'CYS':6,'ILE':7,'LEU':8,
    'ASN':9,'ASP':10,'GLN':11,'LYS':12,'GLU':13,'MET':14,'HIS':15,'PHE':16,'ARG':17,'TYR':18,'TRP':19}
NATIVE_PDB_ALPHABET=' ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'

def project_rdkit_modelled_residues(mol, *, dummy_atom=None):
    """Named adaptation: native consumed fields without constructing the full graph.

    Mirrors pinned Protein.from_molecule's residue boundary, unknown->GLY and
    insertion/chain checks. This does not claim full graph-construction equivalence
    or historical parser retention; those remain separately qualified.
    """
    if mol is None:raise ValueError('RDKit molecule parse failed')
    if dummy_atom is None:
        from rdkit import Chem
        dummy_atom=Chem.MolFromSequence('G').GetAtomWithIdx(0)
    result=[];last=None;unknown=0
    for atom in list(mol.GetAtoms())+[dummy_atom]:
        info=atom.GetPDBResidueInfo()
        if info is None:raise ValueError('missing atom PDB residue metadata')
        name=info.GetResidueName().strip()
        canonical=(info.GetResidueNumber(),info.GetInsertionCode(),name)
        if canonical==last:continue
        last=canonical
        if info.GetInsertionCode()not in NATIVE_PDB_ALPHABET:raise ValueError('unknown insertion code')
        if info.GetChainId()not in NATIVE_PDB_ALPHABET:raise ValueError('unknown chain identifier')
        unknown+=name not in NATIVE_RESIDUE_IDS
        result.append(NATIVE_RESIDUE_IDS.get(name,0))
    result=result[:-1]  # Preserve the pinned native dummy-residue sentinel behavior.
    if not result:raise ValueError('empty modelled residue projection')
    return result,{'unknown_residues_mapped_to_glycine':unknown,
        'projection_only':True,'full_native_graph_validation_executed':False}
