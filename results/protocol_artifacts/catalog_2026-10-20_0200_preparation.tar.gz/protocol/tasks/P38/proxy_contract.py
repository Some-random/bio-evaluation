"""Pure P38 proxy-output contract. No learned model imports or model execution."""
import csv,hashlib,json,math,pathlib,re
CANONICAL=set('ACDEFGHIKLMNPQRSTVWY')
REQUIRED={'case_id','property_group','predicted_solubility'}

def validate_sequence(text):
    """Strict complete output, before any optional external predictor call."""
    if not isinstance(text,str) or not text:return {'valid':False,'reason':'empty_or_not_text'}
    if any(c not in CANONICAL for c in text):return {'valid':False,'reason':'not_one_bare_canonical_sequence'}
    if len(text)>1022:return {'valid':False,'reason':'exceeds_released_netsolp_complete_sequence_limit'}
    return {'valid':True,'reason':None,'length':len(text),'sequence_sha256':hashlib.sha256(text.encode()).hexdigest()}

def verified_csv(path,expected_sha256):
    p=pathlib.Path(path);data=p.read_bytes()
    if hashlib.sha256(data).hexdigest()!=expected_sha256:raise ValueError('prediction_csv_hash_mismatch')
    reader=csv.DictReader(data.decode('utf-8').splitlines())
    if set(reader.fieldnames or [])!=REQUIRED or len(reader.fieldnames or [])!=len(REQUIRED):raise ValueError('unexpected_csv_schema')
    return list(reader)

def summarize(expected_cases,rows):
    """Accept only exact planned IDs/groups. Never silently drop or add cases."""
    planned={}
    for case in expected_cases:
        cid,group=case['case_id'],case['property_group']
        if cid in planned:raise ValueError('duplicate_planned_id')
        if group not in ('soluble','insoluble'):raise ValueError('unsupported_endpoint')
        planned[cid]=group
    found={};invalid={}
    for row in rows:
        cid=row.get('case_id')
        if cid not in planned:raise ValueError('foreign_case_id')
        if cid in found or cid in invalid:raise ValueError('duplicate_prediction_id')
        if row.get('property_group')!=planned[cid]:raise ValueError('property_group_mismatch')
        value=row.get('predicted_solubility')
        try:
            if isinstance(value,bool):raise ValueError('boolean_is_not_a_probability')
            score=float(value)
            if not math.isfinite(score) or not 0<=score<=1:raise ValueError('invalid_probability')
        except (TypeError,ValueError):invalid[cid]='invalid_probability';continue
        found[cid]=score
    groups={}
    for group in ('soluble','insoluble'):
        ids=[cid for cid,g in planned.items() if g==group]
        desired=[found[cid] if group=='soluble' else 1-found[cid] for cid in ids if cid in found]
        n=len(ids);v=len(desired);total=sum(desired)
        groups[group]={'planned':n,'evaluable':v,'invalid':sum(cid in invalid for cid in ids),'missing':sum(cid not in found and cid not in invalid for cid in ids),'full_group_mean_desired_proxy':total/n if n and v==n else None,'delivered_only_mean_desired_proxy':total/v if v else None,'all_planned_mean_lower_bound':total/n if n else None,'all_planned_mean_upper_bound':(total+n-v)/n if n else None}
    return {'condition':'P38_NETSOLP_D_ECOLI_SOLUBILITY_PROXY_V1','planned':len(planned),'evaluable':len(found),'invalid':len(invalid),'missing':len(planned)-len(found)-len(invalid),'per_group':groups,'full_condition_complete':len(found)==len(planned) and len(planned)>0,'native_naturelm_metric':False,'experimental_biological_validation':False,'reference_comparison_available':False}

def thermal_payload(case_id,sequence):
    """Released API payload, under a separately declared hypothetical context."""
    if not isinstance(sequence,str) or not sequence or any(c not in CANONICAL for c in sequence):raise ValueError('not_one_bare_canonical_sequence')
    return {'growth_temp':37,'mt_mode':'Lysate','fasta':[{'header':case_id,'sequence':' '.join(sequence)}]}

def summarize_thermal(expected_ids,rows):
    ids=list(expected_ids)
    if len(ids)!=len(set(ids)):raise ValueError('duplicate_planned_id')
    found={};invalid=set()
    for row in rows:
        cid=row.get('case_id')
        if cid not in ids:raise ValueError('foreign_case_id')
        if cid in found or cid in invalid:raise ValueError('duplicate_prediction_id')
        try:
            value=row['predicted_tm_c']
            if isinstance(value,bool):raise ValueError('boolean')
            value=float(value)
            if not math.isfinite(value):raise ValueError('not_finite')
        except (KeyError,ValueError,TypeError):invalid.add(cid);continue
        found[cid]=value
    return {'condition':'P38_DEEPSTABP_TM37_LYSATE_PROXY_V1','planned':len(ids),'evaluable':len(found),'invalid':len(invalid),'missing':len(ids)-len(found)-len(invalid),'full_cohort_mean_predicted_tm_c':sum(found.values())/len(ids) if len(ids) and len(found)==len(ids) else None,'delivered_only_mean_predicted_tm_c':sum(found.values())/len(found) if found else None,'hypothetical_growth_temperature_c':37,'assumed_measurement_context':'Lysate','native_stability_class_probability':False,'native_naturelm_metric':False,'experimental_biological_validation':False}


def convert_netsolp_rows(expected_cases,native_rows):
    """Map released CSV outputs only after matching complete locked output hashes."""
    expected={c['case_id']:c for c in expected_cases}
    if len(expected)!=len(expected_cases):raise ValueError('duplicate_planned_id')
    seen=set();rows=[]
    for row in native_rows:
        if set(row)!={'sid','fasta','predicted_solubility'}:raise ValueError('unexpected_native_csv_schema')
        cid=row['sid']
        if cid not in expected:raise ValueError('foreign_case_id')
        if cid in seen:raise ValueError('duplicate_prediction_id')
        seen.add(cid)
        parsed=validate_sequence(row['fasta'])
        if not parsed['valid']:raise ValueError('invalid_evaluator_sequence')
        if parsed['sequence_sha256']!=expected[cid]['output_sequence_sha256']:raise ValueError('full_sequence_hash_mismatch')
        rows.append({'case_id':cid,'property_group':expected[cid]['property_group'],'predicted_solubility':row['predicted_solubility']})
    return rows
