import hashlib,pathlib,tempfile,unittest
from proxy_contract import summarize,validate_sequence,verified_csv
class ContractTests(unittest.TestCase):
 def setUp(self):self.plan=[{'case_id':'fake-sol','property_group':'soluble'},{'case_id':'fake-insol','property_group':'insoluble'}]
 def row(self,cid,group,p):return {'case_id':cid,'property_group':group,'predicted_solubility':p}
 def test_direction(self):
  s=summarize(self.plan,[self.row('fake-sol','soluble',.8),self.row('fake-insol','insoluble',.1)])
  self.assertAlmostEqual(s['per_group']['insoluble']['full_group_mean_desired_proxy'],.9);self.assertTrue(s['full_condition_complete'])
 def test_no_thresholding(self):self.assertEqual(summarize(self.plan,[self.row('fake-sol','soluble',.5001)])['per_group']['soluble']['full_group_mean_desired_proxy'],.5001)
 def test_missing_not_zero(self):
  s=summarize(self.plan,[]);self.assertIsNone(s['per_group']['soluble']['full_group_mean_desired_proxy']);self.assertEqual(s['missing'],2);self.assertEqual(s['per_group']['soluble']['all_planned_mean_upper_bound'],1)
 def test_invalid_counts(self):
  for value in ['NaN','Infinity','-0.01','1.01',None,True,'garbage']:
   with self.subTest(value=value):self.assertEqual(summarize(self.plan,[self.row('fake-sol','soluble',value)])['invalid'],1)
 def test_duplicate(self):
  with self.assertRaisesRegex(ValueError,'duplicate_prediction'):summarize(self.plan,[self.row('fake-sol','soluble',.3)]*2)
 def test_foreign(self):
  with self.assertRaisesRegex(ValueError,'foreign'):summarize(self.plan,[self.row('foreign','soluble',.3)])
 def test_group_mismatch(self):
  with self.assertRaisesRegex(ValueError,'group_mismatch'):summarize(self.plan,[self.row('fake-sol','insoluble',.3)])
 def test_stability_is_distinct(self):
  with self.assertRaisesRegex(ValueError,'unsupported_endpoint'):summarize([{'case_id':'fake','property_group':'stable'}],[])
 def test_duplicate_plan(self):
  with self.assertRaisesRegex(ValueError,'duplicate_planned'):summarize(self.plan*2,[])
 def test_full_short_synthetic(self):self.assertTrue(validate_sequence('ACDEFGHIKLMNPQRSTVWY')['valid'])
 def test_never_crop(self):self.assertEqual(validate_sequence('A'*1023)['reason'],'exceeds_released_netsolp_complete_sequence_limit')
 def test_prose_fasta_whitespace_ambiguity_invalid(self):
  for value in ['>toy\nACD','ACD\n','acd','ACX','AC D','',None]:
   with self.subTest(value=value):self.assertFalse(validate_sequence(value)['valid'])
 def test_csv_hash(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'toy.csv';p.write_text('case_id,property_group,predicted_solubility\nfake-sol,soluble,0.8\n');h=hashlib.sha256(p.read_bytes()).hexdigest();self.assertEqual(len(verified_csv(p,h)),1)
   with self.assertRaisesRegex(ValueError,'hash_mismatch'):verified_csv(p,'0'*64)
 def test_schema(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'toy.csv';p.write_text('case_id,property_group,predicted_solubility,gold_label\n');h=hashlib.sha256(p.read_bytes()).hexdigest()
   with self.assertRaisesRegex(ValueError,'schema'):verified_csv(p,h)

class ThermalContractTests(unittest.TestCase):
 def test_explicit_context_and_spacing(self):
  from proxy_contract import thermal_payload
  p=thermal_payload('toy','ACD');self.assertEqual(p['growth_temp'],37);self.assertEqual(p['mt_mode'],'Lysate');self.assertEqual(p['fasta'][0]['sequence'],'A C D')
 def test_distinct_celsius_endpoint(self):
  from proxy_contract import summarize_thermal
  p=summarize_thermal(['toy'],[{'case_id':'toy','predicted_tm_c':63.4}]);self.assertEqual(p['full_cohort_mean_predicted_tm_c'],63.4);self.assertFalse(p['native_stability_class_probability'])
 def test_missing_kept_in_denominator(self):
  from proxy_contract import summarize_thermal
  p=summarize_thermal(['toy1','toy2'],[{'case_id':'toy1','predicted_tm_c':63.4}]);self.assertEqual(p['planned'],2);self.assertIsNone(p['full_cohort_mean_predicted_tm_c'])
 def test_probabilities_not_silently_thermal(self):
  from proxy_contract import summarize_thermal
  p=summarize_thermal(['toy'],[{'case_id':'toy','predicted_solubility':.7}]);self.assertEqual(p['invalid'],1);self.assertIsNone(p['full_cohort_mean_predicted_tm_c'])


class ReleasedCsvAdapterTests(unittest.TestCase):
 def setUp(self):self.plan=[{'case_id':'toy','property_group':'soluble','output_sequence_sha256':hashlib.sha256(b'ACD').hexdigest()}];self.row={'sid':'toy','fasta':'ACD','predicted_solubility':'.7'}
 def test_native_mapping(self):
  from proxy_contract import convert_netsolp_rows
  r=convert_netsolp_rows(self.plan,[self.row]);self.assertEqual(r,[{'case_id':'toy','property_group':'soluble','predicted_solubility':'.7'}]);self.assertNotIn('fasta',r[0])
 def test_full_original_sequence_hash_required(self):
  from proxy_contract import convert_netsolp_rows
  with self.assertRaisesRegex(ValueError,'full_sequence_hash_mismatch'):convert_netsolp_rows(self.plan,[dict(self.row,fasta='AC')])
 def test_duplicate_native_rows(self):
  from proxy_contract import convert_netsolp_rows
  with self.assertRaisesRegex(ValueError,'duplicate_prediction_id'):convert_netsolp_rows(self.plan,[self.row,self.row])
 def test_duplicate_headers_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'toy.csv';p.write_text('case_id,property_group,predicted_solubility,predicted_solubility\n');h=hashlib.sha256(p.read_bytes()).hexdigest()
   with self.assertRaisesRegex(ValueError,'schema'):verified_csv(p,h)
if __name__=='__main__':unittest.main(verbosity=2)
