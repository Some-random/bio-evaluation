#!/usr/bin/env python3
"""One-attempt, full-deck local solver; needs a separate root-frozen grant."""
import argparse
import json
import urllib.error
import urllib.request
from collections import Counter
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

from slidevqa_adapter import build_messages, digest, parse_final, read_jsonl, validate_input, write_json


def now():
    return datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()


def validate_config(path):
    config = json.loads(path.read_text())
    if config["task_id"] != "V07" or config["phase"] not in ("benchmark_generation", "development"):
        raise ValueError("Wrong task/phase")
    for key in ("model_inputs", "case_review"):
        if digest(config[key]["path"]) != config[key]["sha256"]:
            raise ValueError("Frozen task file changed: " + key)
    rows = read_jsonl(config["model_inputs"]["path"])
    if len(rows) != config["planned"] or len({r["case_id"] for r in rows}) != len(rows):
        raise ValueError("Wrong or duplicate cohort")
    for row in rows:
        validate_input(row)
    return config, rows


def validate_gates(config, config_path, rows, grant_path, preflight_path, development_path):
    grant = json.loads(grant_path.read_text())
    expected = {"authorized": True, "task_id": "V07", "run_id": config["run_id"], "config_sha256": digest(config_path)}
    if any(grant.get(k) != v for k, v in expected.items()):
        raise ValueError("No exact root grant")
    if grant.get("runner_sha256") != digest(__file__) or grant.get("adapter_sha256") != digest(Path(__file__).with_name("slidevqa_adapter.py")):
        raise ValueError("Frozen execution code changed")
    if digest(grant["server_identity_file"]) != grant["server_identity_sha256"]:
        raise ValueError("Server identity changed")
    identity = json.loads(Path(grant["server_identity_file"]).read_text())
    if identity.get("model_revision") != config["model_revision"] or identity.get("dtype") not in ("bfloat16", "torch.bfloat16"):
        raise ValueError("Wrong checkpoint or precision")
    if identity.get("limit_mm_per_prompt", {}).get("image", 0) < 20 or identity.get("context_limit", 0) < config["required_server"]["context_limit"]:
        raise ValueError("Server cannot accept full native deck/context")
    endpoint = grant["endpoint"].rstrip("/")
    if urlparse(endpoint).hostname not in ("127.0.0.1", "localhost", "::1"):
        raise ValueError("Only the authorized loopback local server is supported")
    reviews = read_jsonl(config["case_review"]["path"])
    if {r["case_id"] for r in reviews} != {r["case_id"] for r in rows}:
        raise ValueError("Review IDs mismatch")
    for r in reviews:
        if not all(r.get(k) is True for k in ("dispatch_approved", "question_content_reviewed", "image_content_reviewed")):
            raise ValueError("Independent full input content review remains unfinished")
    if digest(preflight_path) != grant["processor_preflight_sha256"]:
        raise ValueError("Processor gate hash mismatch")
    preflight = json.loads(preflight_path.read_text())
    if not preflight.get("all_fit") or not preflight.get("all20_images_expanded") or preflight.get("config_sha256") != digest(config_path) or preflight.get("cases") != len(rows):
        raise ValueError("Actual expanded context gate not passed for complete cohort")
    case_observations = preflight_path.parent / "cases.jsonl"
    if digest(case_observations) != preflight["case_observations_sha256"]:
        raise ValueError("Processor observations changed")
    for filename, expected_hash in preflight["processor_files_sha256"].items():
        if digest(Path(config["model_path"]) / filename) != expected_hash:
            raise ValueError("Pinned processor files changed")
    if config["phase"] == "development":
        if config.get("synthetic_only") is not True or any(r.get("synthetic_only") is not True for r in reviews):
            raise ValueError("Only separately frozen synthetic delivery development is supported by this launcher")
        return endpoint, identity
    if digest(development_path) != grant["development_completion_sha256"]:
        raise ValueError("Development receipt changed")
    dev = json.loads(development_path.read_text())
    if not dev.get("all_passed") or dev.get("protocol_id") != config["protocol_id"] or dev.get("biological_correctness_assessed") is not False:
        raise ValueError("Separate unscored multimodal delivery gate not passed")
    if not isinstance(dev.get("planned"), int) or dev["planned"] < 1 or dev.get("delivery_passed") != dev["planned"]:
        raise ValueError("Development gate did not deliver its full frozen plan")
    if any(dev.get(k) != 0 for k in ("transport_errors", "http_errors", "response_errors", "truncations", "empty_finals", "refusals")):
        raise ValueError("Development gate contains failures")
    if dev.get("generation") != config["generation"] or dev.get("model_revision") != config["model_revision"] or dev.get("images_per_case") != 20:
        raise ValueError("Development condition differs from frozen benchmark")
    dev_lock = json.loads(Path(dev["prediction_lock_path"]).read_text())
    if digest(dev["prediction_lock_path"]) != dev["prediction_lock_sha256"]:
        raise ValueError("Development lock changed")
    for file in dev_lock["files"]:
        if digest(Path(dev["prediction_lock_path"]).parent / file["path"]) != file["sha256"]:
            raise ValueError("Development evidence changed")
    return endpoint, identity


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--output", type=Path)
    p.add_argument("--grant", type=Path)
    p.add_argument("--processor-preflight", type=Path)
    p.add_argument("--development-completion", type=Path)
    p.add_argument("--check-only", action="store_true")
    args = p.parse_args()
    config, rows = validate_config(args.config)
    if args.check_only:
        print(json.dumps({"planned": len(rows), "input_contract_valid": True,
                          "review_approved": sum(r.get("dispatch_approved") is True for r in read_jsonl(config["case_review"]["path"])),
                          "is_dispatch_evidence": False, "new_inference_calls": 0}))
        return
    if not all((args.output, args.grant, args.processor_preflight)) or (config["phase"] != "development" and not args.development_completion):
        raise ValueError("Exact grant, context and delivery receipts required")
    endpoint, identity = validate_gates(config, args.config, rows, args.grant, args.processor_preflight, args.development_completion)
    if args.output.exists() and any(args.output.iterdir()):
        raise ValueError("Fresh output directory required; ambiguous old attempts are never retried")
    for sub in ("requests", "responses", "outcomes", "errors"):
        (args.output / sub).mkdir(parents=True, exist_ok=True)
    write_json(args.output / "run_manifest.json", {
        "started_at_pacific": now(), "task_id": "V07", "run_id": config["run_id"],
        "phase": config["phase"], "protocol_id": config["protocol_id"], "planned": len(rows), "config_sha256": digest(args.config),
        "input_sha256": config["model_inputs"]["sha256"], "generation": config["generation"],
        "grant_sha256": digest(args.grant), "server_identity": identity, "reference_files_read": False,
    })
    counts = Counter({k: 0 for k in ("attempted_confirmed", "responses_saved", "delivery_passed", "transport_errors", "http_errors", "response_errors", "truncations", "empty_finals", "refusals", "not_dispatched")})
    outcomes = []
    stopped = False
    for row in rows:
        case_id = row["case_id"]
        outcome = {"case_id": case_id, "delivery_passed": False, "attempted": False,
                   "final": None, "finish_reason": None}
        if stopped:
            outcome["status"] = "not_dispatched_after_first_failure"
            counts["not_dispatched"] += 1
        else:
            request = {"model": config["model"], "messages": build_messages(row, data_urls=True), **config["generation"]}
            write_json(args.output / "requests" / (case_id + ".json"), request)
            outcome["attempted"] = True
            counts["attempted_confirmed"] += 1
            try:
                http_request = urllib.request.Request(endpoint + "/chat/completions", data=json.dumps(request).encode(), headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(http_request, timeout=3600) as response:
                    raw = response.read()
                (args.output / "responses" / (case_id + ".json")).write_bytes(raw)
                counts["responses_saved"] += 1
                body = json.loads(raw)
                choice = body["choices"][0]
                message = choice["message"]
                final = message.get("content")
                outcome.update({"final": final, "finish_reason": choice.get("finish_reason")})
                if choice.get("finish_reason") == "length":
                    counts["truncations"] += 1
                if not isinstance(final, str) or not final.strip():
                    counts["empty_finals"] += 1
                if message.get("refusal"):
                    counts["refusals"] += 1
                    raise ValueError("Explicit refusal, stop without retry")
                parse_final(final)
                if choice.get("finish_reason") != "stop":
                    raise ValueError("Non-normal finish")
                outcome.update({"delivery_passed": True, "status": "delivered"})
                counts["delivery_passed"] += 1
            except urllib.error.HTTPError as exc:
                counts["http_errors"] += 1
                (args.output / "errors" / (case_id + ".http")).write_bytes(exc.read())
                outcome["status"] = "http_error"
                stopped = True
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                counts["transport_errors"] += 1
                outcome["status"] = "transport_error"
                write_json(args.output / "errors" / (case_id + ".json"), {"type": type(exc).__name__, "message": str(exc)})
                stopped = True
            except (ValueError, KeyError, IndexError, TypeError) as exc:
                counts["response_errors"] += 1
                outcome["status"] = "invalid_response"
                write_json(args.output / "errors" / (case_id + ".json"), {"type": type(exc).__name__, "message": str(exc)})
                stopped = True
        path = args.output / "outcomes" / (case_id + ".json")
        write_json(path, outcome)
        outcomes.append({"case_id": case_id, "path": str(path.relative_to(args.output))})
        write_json(args.output / "progress.json", {"updated_at_pacific": now(), "planned": len(rows), "terminal_case_dispositions": len(outcomes), "observed_attempted_terminal": counts["attempted_confirmed"], **counts})
    files = [{"path": str(p.relative_to(args.output)), "sha256": digest(p)}
             for sub in ("requests", "responses", "outcomes", "errors") for p in sorted((args.output / sub).iterdir())]
    files.append({"path": "run_manifest.json", "sha256": digest(args.output / "run_manifest.json")})
    write_json(args.output / "prediction_lock.json", {"terminal": True, "planned": len(rows), "all_planned_attempted": counts["attempted_confirmed"] == len(rows), "files": files, "outcomes": outcomes})
    write_json(args.output / "completion.json", {"finished_at_pacific": now(), "planned": len(rows), "terminal_case_dispositions": len(outcomes), "observed_attempted_terminal": counts["attempted_confirmed"],
               **counts, "all_passed": counts["delivery_passed"] == len(rows),
               "phase": config["phase"], "protocol_id": config["protocol_id"], "generation": config["generation"],
               "model_revision": config["model_revision"], "images_per_case": 20,
               "prediction_lock_path": str((args.output / "prediction_lock.json").resolve()),
               "prediction_lock_sha256": digest(args.output / "prediction_lock.json"), "biological_correctness_assessed": False,
               "catalog_complete": False})


if __name__ == "__main__":
    main()
