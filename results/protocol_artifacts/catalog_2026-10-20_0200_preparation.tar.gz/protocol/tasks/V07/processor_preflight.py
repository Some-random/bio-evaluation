#!/usr/bin/env python3
"""Actual CPU image-processor expansion. Does not instantiate or call a model."""
import argparse
import hashlib
import json
import os
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from slidevqa_adapter import build_messages, digest, read_jsonl, write_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    inputs = config["model_inputs"]
    if digest(inputs["path"]) != inputs["sha256"]:
        raise ValueError("Input manifest changed")
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    os.environ["HF_HUB_OFFLINE"] = "1"
    from transformers import AutoProcessor, __version__ as transformers_version
    import torch
    processor = AutoProcessor.from_pretrained(config["model_path"], local_files_only=True)
    rows = read_jsonl(inputs["path"])
    if len(rows) != config["planned"]:
        raise ValueError("Planned count differs")
    model_config = json.loads((Path(config["model_path"]) / "config.json").read_text())
    image_token_id = model_config["image_token_id"]
    summaries = []
    max_tokens = config["generation"]["max_tokens"]
    limit = config["required_server"]["context_limit"]
    processor_files = {p.name: digest(p) for p in Path(config["model_path"]).iterdir()
                       if p.is_file() and p.suffix in (".json", ".jinja", ".txt")}
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "cases.jsonl").open("w") as out:
        for row in rows:
            messages = build_messages(row, data_urls=False)
            expanded = processor.apply_chat_template(
                messages, tokenize=True, add_generation_prompt=True, return_dict=True,
                return_tensors="pt", **config["generation"]["chat_template_kwargs"])
            input_ids = expanded["input_ids"][0]
            grid = expanded.get("image_grid_thw")
            if grid is None or grid.shape[0] != 20:
                raise ValueError("Processor did not expand all twenty page images")
            image_tokens = int((input_ids == image_token_id).sum().item())
            if image_tokens <= 20:
                raise ValueError("Only image placeholders observed, not expanded vision tokens")
            tokens = int(input_ids.numel())
            result = {"case_id": row["case_id"], "input_tokens": tokens, "image_tokens": image_tokens,
                      "image_grid_thw": grid.tolist(), "output_budget": max_tokens,
                      "context_limit": limit, "fits": tokens + max_tokens <= limit,
                      "input_row_sha256": hashlib.sha256(json.dumps(row, ensure_ascii=False, sort_keys=True).encode()).hexdigest()}
            out.write(json.dumps(result, sort_keys=True) + "\n")
            out.flush()
            summaries.append(result)
            del expanded, input_ids
    write_json(args.output / "completion.json", {
        "finished_at_pacific": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "role": "actual_cpu_processor_expansion_not_model_inference",
        "protocol_id": config["protocol_id"], "config_sha256": digest(args.config),
        "input_sha256": inputs["sha256"], "cases": len(summaries),
        "all_fit": all(x["fits"] for x in summaries), "all20_images_expanded": True,
        "max_input_tokens": max(x["input_tokens"] for x in summaries),
        "transformers_version": transformers_version, "torch_version": torch.__version__,
        "processor_files_sha256": processor_files,
        "case_observations_sha256": digest(args.output / "cases.jsonl"),
        "new_inference_calls": 0, "trained_model_loaded": False,
    })


if __name__ == "__main__":
    main()
