#!/usr/bin/env python3
"""Durably resume the existing local image copy; never dispatch a solver."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from datetime import datetime
from zoneinfo import ZoneInfo

TASK = Path(__file__).resolve().parent
ROOT = TASK.parents[3]
RUN = TASK / "materialization_resume_20261020_v1"
EXPECTED_SCRIPT = "1b52b354d62f44766ba7548f7467482390d95e52ac35710c49782a6b9a6d4efc"
EXPECTED_ADAPTER = "6eaf1e32e4a211b9d548e0224f96fa7f9961354bdb4b13cfc8e42768174a659f"
INVENTORY = ROOT / ".local/source_recovery_round2_2026-10-19/slidevqa/native_preflight/prospective_page_inventory.private.jsonl"
PREFLIGHT = INVENTORY.with_name("source_preflight.json")
PRESERVE = [
    "readiness.json", "status.json", "condition_config.json", "development_config.json",
    "case_review.private.jsonl", "model_inputs.private.jsonl", "scorer_config.private.json",
    "source_manifest.json", "synthetic_contract_checks.json", "materializer_process.json",
    "scorer_only/references.private.jsonl",
]
DETERMINISTIC = [
    "condition_config.json", "development_config.json", "case_review.private.jsonl",
    "model_inputs.private.jsonl", "scorer_config.private.json", "scorer_only/references.private.jsonl",
]


def now():
    return datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp." + str(os.getpid()))
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def ticks(pid):
    try:
        return Path(f"/proc/{pid}/stat").read_text().rsplit(") ", 1)[1].split()[19]
    except FileNotFoundError:
        return None


def pending_reviews():
    counts = {"pending": 0, "approved": 0}
    with (TASK / "case_review.private.jsonl").open() as f:
        for line in f:
            row = json.loads(line)
            if row.get("dispatch_approved") or row.get("question_content_reviewed") or row.get("image_content_reviewed"):
                counts["approved"] += 1
            elif row.get("disposition") == "prepared_pending_independent_question_and_full_deck_image_review":
                counts["pending"] += 1
            else:
                raise RuntimeError("Unexpected review disposition; no review edits authorized")
    if counts != {"pending": 2215, "approved": 0}:
        raise RuntimeError("Case-review state changed; preserve it and stop materializer")
    return counts


def observation(child, stage, old_status, verified=None):
    record = {
        "task_id": "V07", "role": "existing_local_image_copy_and_hash_verification_only",
        "updated_at_pacific": now(), "stage": stage,
        "wrapper_pid": os.getpid(), "wrapper_proc_start_ticks": ticks(os.getpid()),
        "pid": child.pid if child else None,
        "proc_start_ticks": ticks(child.pid) if child else None,
        "process_exists": child is not None and child.poll() is None,
        "command": "python3 .local/catalog_execution_2026-10-20/tasks/V07/prepare.py --materialize-images",
        "stdout_stderr_log": str(RUN / "prepare.stdout_stderr.log"),
        "completion_receipt": str(RUN / "completion.json"),
        "new_downloads": 0, "new_inference_calls": 0, "model_forwards": 0,
        "benchmark_dispatch_authorized": False, "case_content_reviews_pending": 2215,
        "case_content_reviews_approved": 0, "materialization_complete": verified == 8000,
        "verified_image_files": verified,
        "filename_counts_are_not_verification": True,
    }
    save(RUN / "heartbeat.json", record)
    save(TASK / "materializer_process.json", record)
    status = dict(old_status)
    status.update({
        "updated_at_pacific": now(), "stage": stage,
        "materializer_pid": record["pid"], "materializer_still_running": record["process_exists"],
        "materialization_receipt": str(RUN / "completion.json"),
        "materialization_heartbeat": str(RUN / "heartbeat.json"),
        "materialized_image_files": verified,
        "runtime_status": "not_dispatched", "responses_saved": None,
        "new_inference_calls_by_worker": 0, "model_forwards": 0,
        "case_content_reviews_pending": 2215, "case_content_reviews_approved": 0,
        "benchmark_dispatch_authorized": False,
    })
    save(TASK / "status.json", status)


def main():
    RUN.mkdir(parents=True, exist_ok=True)
    lock = (RUN / "wrapper.lock").open("a+")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if (RUN / "launch_receipt.json").exists():
        raise RuntimeError("This resume attempt already launched; no duplicate child")
    if digest(TASK / "prepare.py") != EXPECTED_SCRIPT or digest(TASK / "slidevqa_adapter.py") != EXPECTED_ADAPTER:
        raise RuntimeError("Existing preparer or adapter changed")
    if (TASK / "runtime").exists() or list(TASK.glob("*.grant.json")):
        raise RuntimeError("Execution artifacts appeared; do not overwrite anything")
    old_process = json.loads((TASK / "materializer_process.json").read_text())
    previous_pid = old_process.get("pid")
    if previous_pid and ticks(previous_pid) == old_process.get("proc_start_ticks"):
        raise RuntimeError("Existing materializer still alive")
    review_counts = pending_reviews()
    if json.loads((TASK / "condition_config.json").read_text()).get("dispatch_authorized") is not False:
        raise RuntimeError("Preparation config no longer has dispatch disabled")
    preflight = json.loads(PREFLIGHT.read_text())
    inventory_sha = digest(INVENTORY)
    if inventory_sha != preflight["private_prospective_page_inventory_sha256"]:
        raise RuntimeError("Image inventory hash changed")
    preserved = {}
    for relative in PRESERVE:
        source = TASK / relative
        destination = RUN / "preserved_before_resume" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            raise RuntimeError("Preservation destination already exists")
        shutil.copy2(source, destination)
        sha = digest(source)
        if digest(destination) != sha:
            raise RuntimeError("Preservation copy hash mismatch")
        preserved[relative] = {"sha256": sha, "bytes": source.stat().st_size, "copy": str(destination)}
    old_status = json.loads((TASK / "status.json").read_text())
    save(RUN / "preservation_receipt.json", {
        "task_id": "V07", "created_at_pacific": now(), "files": preserved,
        "review_counts": review_counts, "prepare_sha256": EXPECTED_SCRIPT,
        "adapter_sha256": EXPECTED_ADAPTER, "inventory_sha256": inventory_sha,
        "new_downloads": 0, "new_inference_calls": 0,
    })
    argv = ["python3", str((TASK / "prepare.py").relative_to(ROOT)), "--materialize-images"]
    with (RUN / "prepare.stdout_stderr.log").open("ab", buffering=0) as log:
        child = subprocess.Popen(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
        save(RUN / "launch_receipt.json", {
            "task_id": "V07", "launched_at_pacific": now(), "argv": argv, "cwd": str(ROOT),
            "wrapper_pid": os.getpid(), "wrapper_proc_start_ticks": ticks(os.getpid()),
            "child_pid": child.pid, "child_proc_start_ticks": ticks(child.pid),
            "script_sha256": EXPECTED_SCRIPT, "adapter_sha256": EXPECTED_ADAPTER,
            "purpose": "Resume previously authorized local image materialization and hash verification only",
            "new_downloads": 0, "new_inference_calls": 0, "model_forwards": 0,
        })
        while child.poll() is None:
            observation(child, "local_image_materialization_running_not_benchmark_execution", old_status)
            time.sleep(20)
        exit_code = child.returncode
    changed = []
    for relative in DETERMINISTIC:
        actual = digest(TASK / relative)
        if actual != preserved[relative]["sha256"]:
            target = RUN / "unexpected_rewrites" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(TASK / relative, target)
            changed.append({"path": relative, "before_sha256": preserved[relative]["sha256"], "after_sha256": actual, "preserved_after": str(target)})
    pending_reviews()
    verified = 0
    failures = []
    if exit_code == 0 and not changed:
        if digest(INVENTORY) != inventory_sha:
            raise RuntimeError("Image inventory changed during copy")
        with INVENTORY.open() as f:
            inventory = [json.loads(line) for line in f]
        if len(inventory) != 8000 or len({x["original_file_key"] for x in inventory}) != 8000:
            raise RuntimeError("Unexpected or duplicate inventory identities")
        for index, row in enumerate(inventory, 1):
            file = TASK / "private_images" / row["original_file_key"]
            if file.is_file() and file.stat().st_size == row["bytes"] and digest(file) == row["sha256"]:
                verified += 1
            else:
                failures.append(row["original_file_key"])
            if index % 200 == 0:
                observation(child, "independent_all_image_hash_verification_not_benchmark_execution", old_status)
                save(RUN / "verification_progress.json", {"updated_at_pacific": now(), "inventory_planned": 8000, "inventory_processed": index, "verified_hashes": verified, "failed_hashes": len(failures), "new_inference_calls": 0})
    success = exit_code == 0 and not changed and verified == 8000 and not failures
    stage = "local_image_materialization_complete_verified_not_benchmark_execution" if success else "local_image_materialization_failed_or_discrepant_not_benchmark_execution"
    receipt = {
        "task_id": "V07", "finished_at_pacific": now(), "stage": stage,
        "child_exit_code": exit_code, "planned_image_identities": 8000,
        "independently_hash_verified_images": verified, "failed_image_identities": failures,
        "unexpected_frozen_file_changes": changed, "materialization_complete": success,
        "inventory_sha256": inventory_sha, "log_sha256": digest(RUN / "prepare.stdout_stderr.log"),
        "preserved_before_receipt_sha256": digest(RUN / "preservation_receipt.json"),
        "case_content_reviews_pending": 2215, "case_content_reviews_approved": 0,
        "benchmark_dispatch_authorized": False, "benchmark_responses_saved": None,
        "new_downloads": 0, "new_inference_calls": 0, "model_forwards": 0,
        "processor_expansion_performed": False, "raw_images_viewed": False,
    }
    save(RUN / "completion.json", receipt)
    observation(child, stage, old_status, verified if success else None)
    return 0 if success else 2


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        save(RUN / "wrapper_failure.json", {"at_pacific": now(), "stage": "materialization_wrapper_failed_no_automatic_retry", "error_type": type(exc).__name__, "error": str(exc), "new_inference_calls": 0})
        raise
