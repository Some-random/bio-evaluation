V07 now has a concrete available SlideVQA condition. It uses the released 2,215-case test split, all 20 pages in source order for every case, local Qwen3.8-27B BF16, and the unchanged published SlideVQA QA, evidence-selection and joint F1/EM functions. This is an explicitly different condition from the unrecovered Ryze Table 3 run.

The image pool contains 7,700 first-round author-linked image files and 300 separately identified processed 1024px copies from the pinned DocRAG corpus. Together these cover all 8,000 original deck/page identities and all 44,300 ordered case/page links. Processed copies are not claimed to be historical image bytes. No image was selected using reference evidence pages. Images, source annotations and question/reference projections remain private.

`prepare.py` validates pinned official source files and the sealed image/ID inventories, verifies both archives and each materialized image digest, writes a strict question/image-only solver input projection, and stores answers/evidence only under `scorer_only/`. It creates a separate disposition for each case. Source coverage is complete; independent question and complete-deck image review is still pending. Dataset membership and absence of a keyword are not content approval.

The original `evaluate.py` CLI is broken: it replaces the parsed ground-truth lines with an empty dictionary, iterates over that empty object, refers to an undefined `pred`, and eventually names an undefined joint scoring function. `score.py` avoids that CLI by AST-loading the four unchanged published pure metric bodies and their number map from a SHA256-pinned original file. Native normalization, precision/recall, F1 and exact-match formulas are unchanged. Invalid/missing predictions remain empty answers/evidence under the full frozen denominator, with delivery failures reported separately. Native evidence exact match is order-sensitive; the solver requests unique ascending 1-based page numbers. The wrapper does not introduce a numerical-tolerance metric or an external judge.

The local runner attempts each frozen case once. It keeps raw request/response/error artifacts and never resumes an ambiguous output directory. It stops submitting new calls after the first transport, HTTP, refusal or invalid-response failure; remaining cases get explicit not-dispatched dispositions. Every artifact is sealed before the scorer reads references. Generation closure and saved responses do not establish a score or finish the catalog.

The separately generated two-case development plan uses only white backgrounds, blue/red squares and neutral questions. Its 20-image requests and the benchmark share the model, output schema, generation parameters and image count. It checks delivery, not biological or benchmark correctness. No development or benchmark inference has been dispatched by this preparation.

The exact Ryze Table 3 condition is unavailable in the inspected current author releases and available source history. The retained proof is linked in `source_manifest.json`: case selection/aggregation, exact GLM extraction/cleansing/checkpoint configuration, solver modality/entrypoint, and ChartQA loader/scorer are unrecovered. This is not a claim that author-private artifacts can never exist. The isolated many-question-per-figure ArxivQA fan-out patch is preserved in the recovery workspace; it is not needed for this SlideVQA case-ID adapter and does not establish Ryze pipeline completion.

Remaining actions are specific:

1. Complete independent case question/full-deck image review and freeze its exact dispositions. A source inventory check is not that review.
2. Run actual processor expansion using the pinned model's processor for the entire frozen cohort. `processor_preflight.py` loads no trained model and performs no forward passes. It requires 20 expanded image grids per case and verifies actual input token length plus 16,384 output tokens fits 65,536. Estimates or image placeholders do not satisfy it. Processor settings and every supporting JSON/Jinja/text file digest are recorded.
3. Use an authorized local vision server with at least 20 images per prompt. First freeze a root grant for the neutral development plan, binding the runner/adapter, config, server identity and processor receipt hashes. Pass its unscored full-plan delivery gate.
4. Freeze the reviewed full condition and an independent root grant. After generation, rehash the sealed prediction lock and invoke the native scorer once. No selective retries, gold page selection, OCR substitution, new training, or paid judge is part of this condition.

Prepared commands, from the repository root:

```bash
python3 .local/catalog_execution_2026-10-20/tasks/V07/prepare.py --materialize-images
python3 .local/catalog_execution_2026-10-20/tasks/V07/prepare_synthetic_development.py
python3 .local/catalog_execution_2026-10-20/tasks/V07/run.py --config .local/catalog_execution_2026-10-20/tasks/V07/condition_config.json --check-only
python3 -m unittest discover -s .local/catalog_execution_2026-10-20/tasks/V07 -p test_contract.py -v
```

In the pinned local serving runtime, with CPU-only visibility for preflight:

```bash
python3 .local/catalog_execution_2026-10-20/tasks/V07/processor_preflight.py --config .local/catalog_execution_2026-10-20/tasks/V07/development_config.json --output .local/catalog_execution_2026-10-20/tasks/V07/synthetic_development/processor_preflight
python3 .local/catalog_execution_2026-10-20/tasks/V07/processor_preflight.py --config .local/catalog_execution_2026-10-20/tasks/V07/condition_config.json --output .local/catalog_execution_2026-10-20/tasks/V07/processor_preflight
```

`run.py` requires `--output`, `--grant` and `--processor-preflight`; the benchmark phase also requires `--development-completion`. The grant must carry `authorized`, `task_id`, `run_id`, `config_sha256`, `runner_sha256`, `adapter_sha256`, `endpoint`, `server_identity_file`, `server_identity_sha256`, `processor_preflight_sha256`, and (for benchmark) `development_completion_sha256`. Server identity must establish checkpoint revision, BF16, 65,536 context, and image capacity >=20. No calls follow from merely creating these files.

After a verified terminal generation lock:

```bash
python3 .local/catalog_execution_2026-10-20/tasks/V07/score.py --config .local/catalog_execution_2026-10-20/tasks/V07/scorer_config.private.json --run PATH_TO_FRESH_BENCHMARK_RUN --output PATH_TO_FRESH_BENCHMARK_RUN/scores.json
```
