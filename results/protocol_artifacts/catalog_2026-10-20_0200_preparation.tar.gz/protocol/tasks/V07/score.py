#!/usr/bin/env python3
"""Hash-lock predictions before opening isolated references; native formulas."""
import argparse
import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from slidevqa_adapter import digest, native_metric_functions, parse_final, read_jsonl, write_json


def score_predictions(native, references, predictions):
    if set(predictions) - {r["case_id"] for r in references}:
        raise ValueError("Foreign prediction IDs")
    gts, preds = {}, {}
    invalid = missing = 0
    for row in references:
        key = row["case_id"]
        gts[key] = {"question": row["question"], "answer": row["answer"], "evidence_pages": row["evidence_pages"]}
        value = predictions.get(key)
        if value is None:
            missing += 1
        try:
            parsed = parse_final(value) if isinstance(value, str) else None
            if parsed is None:
                raise ValueError("No usable final")
        except (ValueError, TypeError, json.JSONDecodeError):
            invalid += 1
            parsed = {"answer": "", "evidence_pages": []}
        preds[key] = parsed
    qa = native["evaluate_f1_em_qa"](gts, preds)
    es = native["evaluate_f1_em_es"](gts, preds)
    joint = native["evaluate_f1_em_main"](qa, es)
    return {"planned": len(references), "missing_finals": missing, "invalid_or_missing_finals": invalid,
            "QA": {k: qa[k] for k in ("F1", "EM")}, "ES": {k: es[k] for k in ("F1", "EM")}, "Main": joint}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--run", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    config = json.loads(args.config.read_text())
    lock_path = args.run / "prediction_lock.json"
    lock = json.loads(lock_path.read_text())
    if not lock.get("terminal") or lock.get("planned") != config["planned"]:
        raise ValueError("Generation has no complete terminal lock")
    for entry in lock["files"]:
        path = (args.run / entry["path"]).resolve()
        if not path.is_relative_to(args.run.resolve()) or digest(path) != entry["sha256"]:
            raise ValueError("Prediction lock file mismatch")
    manifest = json.loads((args.run / "run_manifest.json").read_text())
    if manifest["protocol_id"] != config["protocol_id"] or manifest["input_sha256"] != config["model_inputs"]["sha256"]:
        raise ValueError("Prediction/input protocol mismatch")
    predictions = {}
    for entry in lock["outcomes"]:
        row = json.loads((args.run / entry["path"]).read_text())
        if row["case_id"] in predictions:
            raise ValueError("Duplicate terminal record")
        predictions[row["case_id"]] = row.get("final") if row.get("delivery_passed") else None
    if len(predictions) != config["planned"]:
        raise ValueError("Unsealed/missing terminal outcomes")
    # Reference access starts only after every frozen prediction artifact is verified.
    if digest(config["references"]["path"]) != config["references"]["sha256"]:
        raise ValueError("Reference file changed")
    references = read_jsonl(config["references"]["path"])
    native = native_metric_functions(config["native_scorer"]["path"], config["native_scorer"]["sha256"])
    result = score_predictions(native, references, predictions)
    result.update({"task_id": "V07", "protocol_id": config["protocol_id"],
                   "scored_at_pacific": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
                   "prediction_lock_sha256": digest(lock_path), "scorer_config_sha256": digest(args.config),
                   "native_scorer_sha256": config["native_scorer"]["sha256"],
                   "formula_changes": False, "full_denominator_metric": True,
                   "all_planned_attempted": lock.get("all_planned_attempted", False),
                   "benchmark_generation_complete": lock.get("all_planned_attempted", False),
                   "comparison": "Released SlideVQA test adaptation; not exact Ryze Table3 reproduction",
                   "raw_licensed_content_publishable": False})
    write_json(args.output, result)


if __name__ == "__main__":
    main()
