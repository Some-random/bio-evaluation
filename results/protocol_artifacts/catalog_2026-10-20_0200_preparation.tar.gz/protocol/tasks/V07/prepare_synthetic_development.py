#!/usr/bin/env python3
"""Create neutral 20-image delivery fixtures; no real rows or labels."""
import json
import struct
import zlib
from pathlib import Path

from slidevqa_adapter import digest, write_json


def chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)


def synthetic_png(width, height, square_color):
    rows = []
    white = bytes((255, 255, 255))
    color = bytes(square_color)
    for y in range(height):
        if height // 4 <= y < 3 * height // 4:
            pixels = white * (width // 4) + color * (width // 2) + white * (width - 3 * width // 4)
        else:
            pixels = white * width
        rows.append(b"\0" + pixels)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(b"".join(rows))) + chunk(b"IEND", b"")


def main():
    task = Path(__file__).resolve().parent
    config = json.loads((task / "condition_config.json").read_text())
    folder = task / "synthetic_development"
    folder.mkdir(exist_ok=True)
    pages = []
    for i in range(1, 21):
        path = folder / f"page_{i:02d}.png"
        path.write_bytes(synthetic_png(1024, 768, (0, 0, 255) if i % 2 else (255, 0, 0)))
        pages.append({"page_number": i, "image_path": str(path), "sha256": digest(path), "source_variant": "synthetic_geometric_fixture"})
    rows = [{"case_id": f"V07_synthetic_dev_{i:02d}", "question": question,
             "deck_name": "synthetic-geometric-fixture-not-a-real-slide-deck", "pages": pages}
            for i, question in enumerate([
                "What colored geometric shape appears on page 1?",
                "What colored geometric shape appears on page 20?",
            ])]
    reviews = [{"case_id": row["case_id"], "disposition": "approved_neutral_synthetic_geometric_fixture",
                "synthetic_only": True, "question_content_reviewed": True, "image_content_reviewed": True,
                "dispatch_approved": True, "review_basis": "Constructed from fixed white backgrounds and blue/red squares; no biological, human, document or benchmark payload."} for row in rows]
    for filename, value in (("model_inputs.jsonl", rows), ("review.jsonl", reviews)):
        (folder / filename).write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in value))
    config.update({"phase": "development", "run_id": "qwen38_27b_slidevqa_synthetic20image_delivery_20261020_v1",
                   "planned": len(rows), "synthetic_only": True,
                   "model_inputs": {"path": str(folder / "model_inputs.jsonl"), "sha256": digest(folder / "model_inputs.jsonl"), "count": len(rows)},
                   "case_review": {"path": str(folder / "review.jsonl"), "sha256": digest(folder / "review.jsonl")},
                   "condition_kind": "unscored_synthetic_multimodal_delivery_only",
                   "correctness_scoring": False, "biological_correctness_assessed": False,
                   "gates": ["fixed geometric synthetic content review complete", "actual pinned processor-expanded context check", "root-frozen grant bound to server identity and config hash"],
                   "dispatch_authorized": False})
    write_json(task / "development_config.json", config)
    print(json.dumps({"planned": len(rows), "images_per_case": 20, "new_inference_calls": 0,
                      "development_config_sha256": digest(task / "development_config.json")}))


if __name__ == "__main__":
    main()
