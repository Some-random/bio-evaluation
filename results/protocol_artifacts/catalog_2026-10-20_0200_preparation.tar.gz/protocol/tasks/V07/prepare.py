#!/usr/bin/env python3
"""Prepare one explicitly adapted SlideVQA condition without model requests."""
import argparse
import hashlib
import json
import tarfile
from collections import Counter
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from slidevqa_adapter import PROTOCOL_ID, OUTPUT_SCHEMA, digest, read_jsonl, validate_input, write_json

ROOT = Path(__file__).resolve().parents[4]
TASK = Path(__file__).resolve().parent
ROUND1 = ROOT / ".local/source_acquisition_2026-10-19/vision/slidevqa"
ROUND2 = ROOT / ".local/source_recovery_round2_2026-10-19/slidevqa"
RYZE = ROOT / ".local/source_recovery_round2_2026-10-19/ryze_protocol"


def now():
    return datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()


def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def extract_exact_inventory(inventory, archives, target):
    target.mkdir(parents=True, exist_ok=True)
    for label, spec in archives.items():
        path = Path(spec["path"])
        if digest(path) != spec["sha256"]:
            raise ValueError("Archive checksum changed: " + label)
        needed = {r["archive_member"]: r for r in inventory if r["archive_label"] == label}
        verified = set()
        with tarfile.open(path, "r|*") as archive:
            for member in archive:
                if member.name not in needed:
                    continue
                row = needed[member.name]
                if not member.isfile() or member.size != row["bytes"] or member.name in verified:
                    raise ValueError("Invalid or duplicate image archive member")
                data = archive.extractfile(member).read()
                if hashlib.sha256(data).hexdigest() != row["sha256"]:
                    raise ValueError("Image hash mismatch")
                destination = target / row["original_file_key"]
                if destination.name != row["original_file_key"]:
                    raise ValueError("Invalid file key")
                if not destination.exists() or digest(destination) != row["sha256"]:
                    destination.write_bytes(data)
                verified.add(member.name)
        if verified != set(needed):
            raise ValueError("Archive missing required members")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--materialize-images", action="store_true")
    args = parser.parse_args()
    started = now()
    source_manifest = json.loads((ROUND1 / "verified_source_manifest.json").read_text())
    for item in source_manifest["files"]:
        if digest(ROOT / item["path"]) != item["sha256"]:
            raise ValueError("Pinned source file changed")
    annotation_path = ROUND1 / "source/annotations/qa/test.jsonl"
    annotation = read_jsonl(annotation_path)
    page_inventory_path = ROUND2 / "native_preflight/prospective_page_inventory.private.jsonl"
    roster_path = ROUND2 / "native_preflight/question_page_roster.private.jsonl"
    inventory = read_jsonl(page_inventory_path)
    roster = read_jsonl(roster_path)
    source_preflight = json.loads((ROUND2 / "native_preflight/source_preflight.json").read_text())
    if digest(page_inventory_path) != source_preflight["private_prospective_page_inventory_sha256"]:
        raise ValueError("Page inventory not sealed")
    if digest(roster_path) != source_preflight["private_projected_question_roster_sha256"]:
        raise ValueError("Question roster not sealed")
    if len(annotation) != 2215 or len(roster) != 2215 or len(inventory) != 8000:
        raise ValueError("Unexpected native denominator")
    pages = {p["original_file_key"]: p for p in inventory}
    roster_map = {r["qa_id"]: r for r in roster}
    if len(pages) != 8000 or len(roster_map) != 2215:
        raise ValueError("Duplicate identities")
    archives = {
        "first_round_original7700": {
            "path": str(ROUND1 / "slidevqa_test_public_originals_internal.tar.gz"),
            "sha256": "3115628085e5ff94762e3945337267356c25dfa643c91ef67c2673b2543ec8fb",
        },
        "round2_docrag_processed300": {
            "path": str(ROUND2 / "docrag_missing_original_page_copies_internal.tar"),
            "sha256": "ea540808c37b0ac3e873e683114d79cf6cf1a41af29dedd51d76d197e66a0218",
        },
    }
    if args.materialize_images:
        extract_exact_inventory(inventory, archives, TASK / "private_images")
    inputs, references, reviews = [], [], []
    for row in annotation:
        qa_id = row["qa_id"]
        mapping = roster_map[qa_id]
        if row["deck_name"] != mapping["deck_name"] or len(row["image_urls"]) != 20:
            raise ValueError("Source/mapping identity mismatch")
        ordered = []
        for page_number, file_key in enumerate(mapping["ordered_page_file_keys"], 1):
            page = pages[file_key]
            if page["deck_name"] != row["deck_name"] or page["page_number"] != page_number:
                raise ValueError("Cross-deck or reordered page")
            ordered.append({"page_number": page_number, "image_path": str(TASK / "private_images" / file_key),
                            "sha256": page["sha256"], "source_variant": page["source_variant"]})
        case_id = f"V07_slidevqa_test_{qa_id:05d}"
        inputs.append(validate_input({"case_id": case_id, "question": row["question"],
                                      "deck_name": row["deck_name"], "pages": ordered}))
        references.append({"case_id": case_id, "qa_id": qa_id, "question": row["question"],
                           "answer": row["answer"], "evidence_pages": row["evidence_pages"]})
        reviews.append({"case_id": case_id, "qa_id": qa_id, "deck_name": row["deck_name"],
                        "disposition": "prepared_pending_independent_question_and_full_deck_image_review",
                        "source_fields_allowlisted": True, "all20_page_identities_verified": True,
                        "question_content_reviewed": False, "image_content_reviewed": False,
                        "dispatch_approved": False,
                        "reason": "Source availability and reference isolation are verified; no case-level content approval is inferred from dataset identity or absent keywords."})
    input_path = TASK / "model_inputs.private.jsonl"
    reference_path = TASK / "scorer_only/references.private.jsonl"
    review_path = TASK / "case_review.private.jsonl"
    write_jsonl(input_path, inputs)
    write_jsonl(reference_path, references)
    write_jsonl(review_path, reviews)
    input_file = {"path": str(input_path), "sha256": digest(input_path), "count": len(inputs)}
    review_file = {"path": str(review_path), "sha256": digest(review_path)}
    config = {
        "task_id": "V07", "run_id": "qwen38_27b_slidevqa_test2215_full_deck_mixed_images_20261020_v1",
        "protocol_id": PROTOCOL_ID, "condition_kind": "explicitly_adapted_zero_shot_full_deck_solver",
        "phase": "benchmark_generation", "planned": 2215,
        "model": "Qwen/Qwen3.8-27B", "model_revision": "1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0",
        "model_path": "/dfs/scratch0/tchen/models/Qwen3.8-27B", "dtype": "bfloat16",
        "model_inputs": input_file, "case_review": review_file,
        "generation": {"temperature": 1.0, "top_p": 0.95, "top_k": 20, "seed": 42, "n": 1,
                       "max_tokens": 16384, "chat_template_kwargs": {"enable_thinking": True},
                       "structured_outputs": {"json": OUTPUT_SCHEMA}},
        "required_server": {"context_limit": 65536, "limit_mm_per_prompt": {"image": 20}, "vision_enabled": True},
        "processor": {"pretrained_default_image_processor_unchanged": True,
                      "image_resizing_before_processor": False,
                      "actual_processor_expanded_context_check_required": True},
        "dispatch_authorized": False,
        "gates": ["independent per-case question and complete deck image review", "actual pinned processor-expanded context check for every case", "synthetic multimodal delivery check and separate unscored development gate", "root-frozen grant bound to server identity and config hash"],
        "adaptations": ["Full released 2215-case test split; exact Ryze Table3 IDs/aggregation unavailable in inspected author distributions", "Local Qwen3.8-27B zero-shot solver, no trained SlideVQA heads", "All 20 ordered original page identities supplied, no gold evidence-page selection", "7700 first-round author-linked image files and 300 DocRAG processed1024 copies; not historically byte-identical", "No OCR augmentation/GLM cleansing, no native Ryze OCR condition or paper-matched claim", "Structured answer plus evidence pages; unchanged official SlideVQA QA/evidence/joint F1 and EM pure functions"],
        "new_inference_calls": 0, "biological_labels_scored": False,
    }
    write_json(TASK / "condition_config.json", config)
    scorer = ROUND1 / "source/evaluate.py"
    write_json(TASK / "scorer_config.private.json", {
        "task_id": "V07", "protocol_id": PROTOCOL_ID, "planned": 2215,
        "model_inputs": input_file,
        "references": {"path": str(reference_path), "sha256": digest(reference_path)},
        "native_scorer": {"path": str(scorer), "sha256": digest(scorer)},
        "prediction_lock_required_before_reference_read": True,
        "unusable_prediction_policy": "empty answer and empty evidence, retained denominator; delivery diagnostics remain separate",
    })
    write_json(TASK / "source_manifest.json", {
        "task_id": "V07", "created_at_pacific": now(), "protocol_id": PROTOCOL_ID,
        "slidevqa_repository": source_manifest["repository"], "slidevqa_revision": source_manifest["revision"],
        "source_files": source_manifest["files"],
        "source_preflight": {"path": str(ROUND2 / "native_preflight/source_preflight.json"), "sha256": digest(ROUND2 / "native_preflight/source_preflight.json")},
        "page_inventory": {"path": str(page_inventory_path), "sha256": digest(page_inventory_path)},
        "question_roster": {"path": str(roster_path), "sha256": digest(roster_path)},
        "image_archives": archives, "images_materialized_and_each_hash_verified": args.materialize_images,
        "image_variant_counts": dict(Counter(x["source_variant"] for x in inventory)),
        "ryze_exact_condition_availability": {
            "status": "unavailable_in_inspected_current_author_release_and_available_history",
            "required_missing_artifacts": ["identifiable Table3 cohort and aggregation", "full GLM extraction/cleansing configuration and model revisions", "specific image/OCR solver entrypoint", "ChartQA component loader/scorer"],
            "evidence": [{"path": str(RYZE / p), "sha256": digest(RYZE / p)} for p in ["source_protocol_contract.json", "PUBLIC_SUMMARY.json", "history_content_search_receipt.json"]],
            "not_a_claim_artifacts_never_exist": True,
        },
        "reference_isolation": {"request_fields": ["question", "20 ordered images", "1-based page labels"],
                                "scorer_only": ["answer", "arithmetic_expression", "evidence_pages", "reasoning_type", "answer_type"],
                                "gold_evidence_pages_used_for_image_selection": False},
        "publication": "Aggregate/code only. Source annotations, question/reference projections and slide images remain private under existing source restrictions.",
        "new_model_calls": 0,
    })
    status = {
        "task_id": "V07", "started_at_pacific": started, "updated_at_pacific": now(),
        "stage": "full_split_input_adapter_prepared_content_review_and_processor_gates_pending",
        "planned": 2215, "prepared_inputs": 2215, "prepared_references_isolated": 2215,
        "distinct_decks": 400, "page_identities": 8000, "ordered_case_page_links": 44300,
        "materialized_image_files": 8000 if args.materialize_images else None,
        "case_content_reviews_approved": 0, "case_content_reviews_pending": 2215,
        "runtime_status": "not_dispatched", "responses_saved": None, "new_inference_calls_by_worker": 0,
        "exact_ryze_table3_condition_available": False,
        "closest_available_condition": PROTOCOL_ID,
        "config_sha256": digest(TASK / "condition_config.json"),
        "native_scorer_formula_changes": False,
        "next_action": "Complete independent question/full-deck content review, run processor_preflight.py using pinned model/runtime and >=20-image server support, then freeze an unscored development plan/grant before any benchmark dispatch.",
    }
    write_json(TASK / "status.json", status)
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()
