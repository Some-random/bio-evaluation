def UPG_postprocess(text):
    if not isinstance(text, str):
        return ''
    matches = re.findall('<protein>(.*?)</protein>', text, re.DOTALL)
    if matches:
        s = matches[-1].strip()
        s = s.replace(';', '')
        s = s.replace(' ', '')

        def clean_prediction(seq: str) -> str:
            valid = set('ACDEFGHIKLMNPQRSTVWY-')
            return ''.join([aa for aa in seq.upper() if aa in valid])
        s = clean_prediction(s)
        return s
    else:
        return ''

class UPG_Evaluator(BaseEvaluator):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def _calculate_sequence_identity(self, seq1, seq2):
        """
        Calculate sequence identity between two sequences.
        This is a simplified implementation for sequences of equal length,
        computed by direct position-wise comparison.
        More accurate methods may require alignment algorithms (e.g., Smith-Waterman).
        """
        if len(seq1) != len(seq2) or not seq1:
            return 0
        matches = sum((1 for a, b in zip(seq1, seq2) if a == b))
        return matches / len(seq1)

    def score(self, predictions, references=None):
        """
        Evaluate the generated protein sequences.

        Args:
            predictions (list[str]): List of model-generated protein sequences.
            references (list[str], optional): Reference sequences; ignored here.

        Returns:
            dict: Dictionary containing evaluation metrics.
        """
        if not predictions:
            return {'average_length': 0, 'diversity': 0, 'average_plddt': 0, 'info': 'Input predictions list is empty.'}
        ori_len = len(predictions)
        predictions = [pred for pred in predictions if len(pred) > 0]
        predictions = [pred for pred in predictions if not pred.strip() == '']
        valid_rate = len(predictions) / ori_len
        total_length = sum((len(seq) for seq in predictions))
        avg_length = total_length / len(predictions)
        clusters_representatives = []
        for seq in predictions:
            is_in_existing_cluster = False
            for representative in clusters_representatives:
                if abs(len(seq) - len(representative)) < 20:
                    if self._calculate_sequence_identity(seq, representative) >= 0.99:
                        is_in_existing_cluster = True
                        break
            if not is_in_existing_cluster:
                clusters_representatives.append(seq)
        num_clusters = len(clusters_representatives)
        diversity = num_clusters / len(predictions)
        plddt_scores = []
        sequences_for_plddt = [seq for seq in predictions if len(seq) < 100 and len(seq) > 0]
        for s in sequences_for_plddt:
            print(s)
        if sequences_for_plddt:
            from .omegafold.__main__ import main as plddt_main
            plddt_scores = plddt_main(sequences_for_plddt)
            avg_plddt = sum(plddt_scores) / len(plddt_scores)
        else:
            avg_plddt = 0.0
        return {'num_length_less_100': len(sequences_for_plddt), 'valid_rate': round(valid_rate, 4), 'average_length': round(avg_length, 2), 'diversity': round(diversity, 4), 'average_plddt': round(avg_plddt, 2)}
