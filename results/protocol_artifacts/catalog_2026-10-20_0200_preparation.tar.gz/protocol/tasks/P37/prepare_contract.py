"""Freeze P37 metadata and pure-code tests; never inspect a biological corpus."""
from __future__ import annotations
import ast
import hashlib
import importlib.util
import json
import subprocess
import sys
import tarfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import contract_adapter as adapter

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
RECOVERY = ROOT / '.local/source_recovery_round2_2026-10-19/paper_artifacts'
PREFIX = 'SciReason/opencompass/datasets/unconditional_protein_generation/'
REVISION = '92814ce45c36b691c19dc606bc1e4a50364eac51'


def stamp():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def write(name, value):
    p = HERE / name
    t = p.with_suffix(p.suffix + '.tmp')
    t.write_text(json.dumps(value, indent=2) + '\n')
    t.replace(p)
    return adapter.sha256_file(p)


def main():
    receipts = json.loads((RECOVERY / 'reproduction_acquisition_receipt.json').read_text())
    selected = [r for r in receipts['files'] if r['name'].startswith(PREFIX) and r['name'].endswith('.py')]
    config_name = 'SciReason/opencompass/configs/datasets/unconditional_protein_generation/UPG.py'
    selected += [r for r in receipts['files'] if r['name'] == config_name]
    frozen = []
    for r in selected:
        p = Path(r['path'])
        b = p.read_bytes()
        digest = hashlib.sha256(b).hexdigest()
        blob = hashlib.sha1(f'blob {len(b)}\0'.encode() + b).hexdigest()
        if digest != r['sha256'] or blob != r['expected_git_blob']:
            raise ValueError(f'Pinned publisher source mismatch: {p.name}')
        # Parse code without executing imports, examples, checkpoint code or forwards.
        ast.parse(b)
        frozen.append({'path': str(p.relative_to(ROOT)), 'bytes': len(b), 'sha256': digest,
                       'publisher_git_blob': blob, 'publisher_git_blob_verified': True,
                       'url': r['url']})
    upg = RECOVERY / 'reproduction' / PREFIX / 'UPG.py'
    tree = ast.parse(upg.read_text())
    logic = [n for n in tree.body if (isinstance(n, ast.FunctionDef) and n.name == 'UPG_postprocess')
             or (isinstance(n, ast.ClassDef) and n.name == 'UPG_Evaluator')]
    # No dataset loader, examples, source references or raw sequences are copied.
    for n in logic:
        n.decorator_list = []
    (HERE / 'upstream_logic_ast_snapshot.py').write_text(ast.unparse(ast.Module(body=logic, type_ignores=[])) + '\n')
    protocol_source = RECOVERY / 'naturelm_source/chapters/protein.tex'
    acquisition = json.loads((HERE / 'release2_acquisition_status.json').read_text())
    completed = acquisition.get('stage') == 'complete_verified'
    weights = Path(acquisition.get('path', ROOT / '.local/source_acquisition_2026-10-19/evaluators/weights/omegafold_release2.pt'))
    present = weights.is_file() and weights.stat().st_size == acquisition['expected_bytes']
    if not completed or not present:
        write('status.json', {'task_id': 'P37', 'stage': 'contract_ready_official_omegafold2_acquisition_in_progress',
                             'updated_at_pacific': stamp(), 'planned': 1000, 'responses_saved': None,
                             'new_inference_calls': 0, 'model_forwards': 0, 'training': False,
                             'asset_acquisition_stage': acquisition['stage'], 'benchmark_dispatch_ready': False})
        return
    mirror_path = HERE / 'scireason_release2_mirror_metadata.json'
    mirror = json.loads(mirror_path.read_text())
    mirror_lfs = mirror['files'][0]['lfs']
    if mirror.get('status') != 200 or mirror_lfs['size'] != weights.stat().st_size or mirror_lfs['sha256'] != acquisition['local_sha256']:
        raise ValueError('Official release2 bytes do not match the inspected SciReason mirror LFS object')
    # Reuses the completed byte-stream SHA256 plus publisher multipart verification.
    # The weights are not deserialized or freshly hashed a second time here.
    source_manifest = {'task_id': 'P37', 'created_at_pacific': stamp(),
                       'source_revision': REVISION, 'files': frozen,
                       'paper_source': {'path': str(protocol_source.relative_to(ROOT)),
                                        'sha256': adapter.sha256_file(protocol_source)},
                       'official_omegafold_revision': '313c873ad190b64506a497c926649e15fcd88fcd',
                       'weights': {'path': str(weights.relative_to(ROOT)), 'bytes': weights.stat().st_size,
                                   'sha256': acquisition['local_sha256'],
                                   'sha256_source': 'Full newly downloaded object hashed during assembly',
                                   'publisher_multipart_etag': acquisition['publisher_s3_multipart_etag'],
                                   'publisher_multipart_etag_verified': True,
                                   'publisher_independent_sha256_available': False,
                                   'url': acquisition['url'],
                                   'scireason_mirror_revision': mirror['revision'],
                                   'scireason_mirror_lfs_sha256': mirror_lfs['sha256'],
                                   'scireason_mirror_bytes_match': True,
                                   'scireason_mirror_metadata_path': str(mirror_path.relative_to(ROOT)),
                                   'scireason_mirror_metadata_sha256': adapter.sha256_file(mirror_path)}}
    source_hash = write('source_manifest.json', source_manifest)
    config = {'task_id': 'P37', 'protocol_variant': adapter.VARIANT,
              'status': 'frozen_preparation_not_dispatched', 'created_at_pacific': stamp(),
              'source_manifest_sha256': source_hash,
              'model': {'served_model_name': 'Qwen/Qwen3.8-27B',
                        'revision': '1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0', 'precision': 'BF16'},
              'planned_case_ids': adapter.case_ids(),
              'generation': {'prompt': adapter.GENERATION_PROMPT, 'num_return_sequences': 1,
                             'do_sample': True, 'temperature': .9, 'top_p': .9, 'top_k': 50,
                             'max_output_tokens': 2048, 'seed_base': 42, 'enable_thinking': False,
                             'shots': 0, 'maximum_attempts_per_case': 1, 'selective_retries': False},
              'postprocessing': 'Exact released last protein tag, whitespace/semicolon removal, uppercase ACDEFGHIKLMNPQRSTVWY- filter',
              'diversity': {'threshold': .99, 'method': 'source-order greedy equal-length positional identity',
                            'denominator': 'nonempty postprocessed outputs'},
              'folding': {'model': 2, 'checkpoint': source_manifest['weights'], 'num_cycle': 10,
                          'subbatch_size': 448, 'num_pseudo_msa': 15, 'pseudo_msa_mask_rate': .12,
                          'allow_tf32': True, 'eligible_lengths': {'min_inclusive': 1, 'max_exclusive': 100},
                          'confidence': 'mean residue confidence multiplied by 100',
                          'failure_policy': 'record all failures; full confidence metric remains null until all eligible outputs have verified successful scores'},
              'dispatch_authorized_by_this_preparation': False,
              'reference_sequences_or_targets_in_request': False,
              'raw_biological_sequences_inspected_by_preparation': False,
              'material_differences': [
                  'NatureLM paper reports 50% sequence-identity clustering; released SciReason implementation uses 99% equal-length positional clustering.',
                  'NatureLM paper-native sample count, complete sampling/stopping setup and exact evaluator version remain unrecovered; 1000 and generation settings here come from SciReason code.',
                  'Qwen chat request wrapper replaces the upstream OpenCompass prompt-template boundary marker; zero demonstrations are used.',
                  'Qwen thinking is explicitly disabled, and per-slot seed42+index is frozen; these details are not specified by the retrieved SciReason task config.',
                  'Official OmegaFold release2 is downloaded from Helixon S3 and its full SHA256 matches the pinned SciReason mirror LFS object; the SciReason fork runtime source is preserved.',
                  'Upstream all-invalid divide-by-zero is reported as undefined; failed folds retain full eligibility coverage rather than silently disappearing from the complete metric.'
              ],
              'allowed_claim': 'Separately labelled released-code unconditional-generation format/diversity/predictor-confidence proxy; not matched NatureLM replication or biological validation.'}
    config_hash = write('frozen_contract.json', config)
    runtime = {'checked_at_pacific': stamp(), 'python': sys.version,
               'module_specs_present': {m: bool(importlib.util.find_spec(m)) for m in ('torch', 'numpy', 'Bio', 'omegafold')},
               'imports_executed': False, 'model_forward_executed': False,
               'upstream_install_contract': 'Official OmegaFold setup supports CPython3.8/3.9/3.10 and pins Torch1.12.0+cu113; current CPU interpreter is not a certified folding runtime.'}
    write('runtime_preflight.json', runtime)
    check = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', str(HERE),
                            '-p', 'test_contract_adapter.py', '-v'], capture_output=True, text=True)
    (HERE / 'synthetic_tests.log').write_text(check.stdout + check.stderr)
    if check.returncode:
        raise RuntimeError('Synthetic contract test failed')
    test_hash = write('synthetic_test_receipt.json', {'task_id': 'P37', 'finished_at_pacific': stamp(),
                      'tests_run': 21, 'tests_passed': 21, 'test_command_exit_code': check.returncode,
                      'test_code_sha256': adapter.sha256_file(HERE/'test_contract_adapter.py'),
                      'adapter_sha256': adapter.sha256_file(HERE/'contract_adapter.py'),
                      'log_sha256': adapter.sha256_file(HERE/'synthetic_tests.log'),
                      'source_manifest_sha256': source_hash, 'real_cases_checked': 0,
                      'new_inference_calls': 0, 'model_forwards': 0,
                      'upstream_folding_substituted_by_recording_stub_for_tests_only': True})
    availability = {'task_id': 'P37', 'updated_at_pacific': stamp(),
                    'original_paper_condition': {'status': 'exact_protocol_unavailable_in_inspected_releases',
                     'known': ['Unconditional protein-start-token generation', '50% cluster-count diversity', 'OmegaFold pLDDT on length<100'],
                     'unrecovered': ['Absolute generated sample count', 'Full generation sampling/stopping configuration',
                                     'Exact clustering command/alignment implementation', 'Exact OmegaFold checkpoint/settings and aggregation failure policy'],
                     'evidence': [str((RECOVERY/'status.json').relative_to(ROOT)), str(protocol_source.relative_to(ROOT))],
                     'qualification': 'Inspected-release unavailability; no assertion that author-private artifacts do not exist.'},
                    'available_adaptation': {'status': 'pure_contract_implemented_and_tested',
                     'protocol_variant': adapter.VARIANT, 'source_code_publisher_hashes_reverified': True,
                     'official_omegafold_model2_acquired_and_publisher_verified': True,
                     'source_sampling_count': 1000, 'frozen_contract_sha256': config_hash,
                     'synthetic_test_receipt_sha256': test_hash},
                    'implementation_and_runtime_gaps': [
                        'A compatible isolated OmegaFold2 environment must be assembled and its real loading/forward interface validated without a benchmark generation run.',
                        'The generic Qwen request contract still needs a separately reviewed frozen runtime dispatch wrapper and independent development-delivery check.',
                        'No benchmark generations, sealed prediction lock or folding scores exist for this new condition.'
                    ],
                    'asset_transfer_blocked': False, 'new_inference_calls': 0, 'training': False}
    availability_hash = write('availability_manifest.json', availability)
    write('readiness.json', {'task_id': 'P37', 'created_at_pacific': stamp(),
                            'stage': 'released_code_contract_ready_runtime_validation_pending',
                            'protocol_variant': adapter.VARIANT, 'planned': 1000,
                            'frozen_contract_sha256': config_hash, 'source_manifest_sha256': source_hash,
                            'availability_manifest_sha256': availability_hash,
                            'adapter_sha256': adapter.sha256_file(HERE/'contract_adapter.py'),
                            'tests_passed': 21, 'native_primary_metric_available': False,
                            'benchmark_dispatch_ready': False, 'new_inference_calls': 0,
                            'next_action': 'Assemble an isolated OmegaFold2-compatible runtime, validate pinned checkpoint loading and synthetic folding interface; independently freeze and gate any later Qwen dispatch.'})
    write('status.json', {'task_id': 'P37', 'updated_at_pacific': stamp(),
                         'stage': 'released_code_contract_ready_runtime_validation_pending',
                         'planned': 1000, 'responses_saved': None, 'terminal_records': None,
                         'new_inference_calls': 0, 'model_forwards': 0, 'training': False,
                         'source_asset_state': 'official_omegafold2_complete_publisher_multipart_verified',
                         'tests_passed': 21, 'native_protocol_unavailable_in_inspected_releases': True,
                         'benchmark_dispatch_ready': False,
                         'evidence_note': 'Preparation and acquired assets are not runtime dispatch or completed benchmark scores.',
                         'next_action': 'Isolated evaluator runtime validation followed by an independent per-task development gate before any prospective benchmark dispatch.'})
    print(json.dumps({'stage': 'prepared', 'frozen_contract_sha256': config_hash,
                      'source_manifest_sha256': source_hash, 'tests_passed': 21}))


if __name__ == '__main__':
    main()
