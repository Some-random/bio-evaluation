"""Artificial strings and fake confidences only; no model imports or forwards."""
import ast
import contextlib
import hashlib
import io
import json
import tempfile
import unittest
from pathlib import Path

import contract_adapter as c

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
SOURCE = ROOT / '.local/source_recovery_round2_2026-10-19/paper_artifacts/reproduction/SciReason/opencompass/datasets/unconditional_protein_generation/UPG.py'


def response(ident, text, finish='stop'):
    return {'case_id': ident, 'status': 'response', 'final_text': text, 'finish_reason': finish}


def artificial(text):
    return '<protein>' + text + '</protein>'


def folded(ident, text, value=57.25, status='success'):
    return {'case_id': ident, 'status': status, 'mean_plddt': value,
            'postprocessed_sequence_sha256': hashlib.sha256(text.encode()).hexdigest(),
            'folding_protocol': 'SCIREASON_OMEGAFOLD_MODEL2_10CYCLE_V1'}


def upstream_evaluator():
    tree = ast.parse(SOURCE.read_text())
    cls = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == 'UPG_Evaluator')

    class RemoveFoldingImport(ast.NodeTransformer):
        def visit_ImportFrom(self, node):
            if node.module == 'omegafold.__main__':
                return ast.Assign(targets=[ast.Name('plddt_main', ast.Store())],
                                  value=ast.Name('fake_folding', ast.Load()))
            raise AssertionError('Unexpected source import in selected pure evaluator')

    pure = ast.fix_missing_locations(RemoveFoldingImport().visit(ast.Module(body=[cls], type_ignores=[])))
    namespace = {'BaseEvaluator': object, 'fake_folding': lambda xs: [57.25] * len(xs)}
    exec(compile(pure, str(SOURCE), 'exec'), namespace)
    return namespace['UPG_Evaluator']()


class ContractTests(unittest.TestCase):
    def test_frozen_contract_matches_released_source_constants(self):
        cfg = SOURCE.parents[2] / 'configs/datasets/unconditional_protein_generation/UPG.py'
        config_ast = ast.parse(cfg.read_text())
        g = next(n.value for n in config_ast.body if isinstance(n, ast.Assign)
                 and any(isinstance(x, ast.Name) and x.id == 'generation_kwargs' for x in n.targets))
        values = {kw.arg: ast.literal_eval(kw.value) for kw in g.keywords}
        self.assertEqual(values, {'num_return_sequences': 1, 'do_sample': True, 'top_p': .9, 'temperature': .9, 'top_k': 50})
        self.assertTrue(any(isinstance(n, ast.keyword) and n.arg == 'max_out_len'
                            and isinstance(n.value, ast.Constant) and n.value.value == 2048 for n in ast.walk(config_ast)))
        data_ast = ast.parse(SOURCE.read_text())
        count = [n.value.value for n in ast.walk(data_ast) if isinstance(n, ast.Assign)
                 and any(isinstance(x, ast.Name) and x.id == 'len_test_data' for x in n.targets)
                 and isinstance(n.value, ast.Constant)]
        self.assertEqual(count, [1000])
        pipeline = ast.parse((SOURCE.parent/'omegafold/pipeline.py').read_text())
        fn = next(n for n in pipeline.body if isinstance(n, ast.FunctionDef) and n.name == 'get_args')
        attrs = {n.targets[0].attr: n.value.value for n in fn.body if isinstance(n, ast.Assign)
                 and isinstance(n.targets[0], ast.Attribute) and isinstance(n.value, ast.Constant)}
        for k, v in {'model': 2, 'num_cycle': 10, 'subbatch_size': 448, 'num_pseudo_msa': 15,
                     'pseudo_msa_mask_rate': .12, 'allow_tf32': True}.items():
            self.assertEqual(attrs[k], v)

    def test_case_slots(self):
        self.assertEqual(len(c.case_ids()), 1000)
        self.assertEqual(c.case_ids(1), ['P37-UPG-0000'])
        for n in (0, -1, 1001, True, 1.2):
            with self.assertRaises(ValueError): c.case_ids(n)

    def test_postprocessor_last_tag(self):
        self.assertEqual(c.postprocess(artificial('CC') + artificial('AA')), 'AA')

    def test_postprocessor_missing_or_nonstring(self):
        for s in (None, 4, 'AA', '<protein>AA'):
            self.assertEqual(c.postprocess(s), '')

    def test_source_cleaning_gap_and_noncanonical(self):
        self.assertEqual(c.postprocess(artificial(' a; c\nD!?x- ')), 'ACD-')

    def test_exact_99_threshold(self):
        a, b = 'A' * 100, 'A' * 99 + 'C'
        self.assertEqual(c.positional_identity(a, b), .99)
        self.assertEqual(c.positional_clusters([a, b]), [0, 0])

    def test_different_length_is_zero_identity(self):
        self.assertEqual(c.positional_identity('A' * 100, 'A' * 99), 0)
        self.assertEqual(c.positional_clusters(['A' * 100, 'A' * 99]), [0, 1])

    def test_greedy_original_order(self):
        a, b, d = 'A' * 100, 'A' * 99 + 'C', 'A' * 98 + 'CC'
        self.assertEqual(c.positional_clusters([a, b, d]), [0, 0, 1])
        self.assertEqual(c.positional_clusters([b, a, d]), [0, 0, 0])

    def test_missing_runtime_is_unknown(self):
        out = c.evaluate([], ['x'])
        self.assertEqual(out['counts']['runtime_unobserved'], 1)
        self.assertIsNone(out['complete_generation_metrics'])

    def test_all_invalid_not_software_division_error(self):
        out = c.evaluate([response('x', '')], ['x'])
        self.assertTrue(out['generation_terminal'])
        self.assertIsNone(out['complete_generation_metrics'])

    def test_duplicates_or_foreign_rejected(self):
        for rs in ([response('x', '')] * 2, [response('y', '')]):
            with self.assertRaises(ValueError): c.evaluate(rs, ['x'])

    def test_errors_and_truncation_retained(self):
        out = c.evaluate([response('a', '', 'length'), {'case_id': 'b', 'status': 'transport_error'}], ['a', 'b'])
        self.assertEqual(out['counts']['transport_errors'], 1)
        self.assertEqual(out['counts']['truncations'], 1)
        self.assertEqual(out['counts']['empty_finals'], 1)
        self.assertFalse(out['full_delivery'])

    def test_folding_boundary(self):
        out = c.fold_request_manifest([response('a', artificial('A' * 99)), response('b', artificial('A' * 100))], ['a', 'b'])
        self.assertEqual([r['case_id'] for r in out], ['a'])
        self.assertNotIn('sequence', out[0])

    def test_failure_does_not_disappear_from_fold_denominator(self):
        rs = [response('a', artificial('AA')), response('b', artificial('CC'))]
        out = c.evaluate(rs, ['a', 'b'], [folded('a', 'AA'), folded('b', 'CC', status='error')])
        self.assertIsNone(out['complete_generation_metrics']['average_plddt'])
        self.assertEqual(out['folding']['observed_success_average_plddt'], 57.25)
        self.assertEqual(out['folding']['errors'], 1)

    def test_missing_folding_not_zero_confidence(self):
        out = c.evaluate([response('a', artificial('AA'))], ['a'])
        self.assertEqual(out['folding']['unobserved'], 1)
        self.assertIsNone(out['complete_generation_metrics']['average_plddt'])

    def test_folding_confidence_validation(self):
        for value in (float('nan'), float('inf'), -1, 101, True):
            with self.assertRaises(ValueError):
                c.evaluate([response('a', artificial('AA'))], ['a'], [folded('a', 'AA', value)])

    def test_folding_sequence_hash_is_mandatory(self):
        with self.assertRaises(ValueError):
            c.evaluate([response('a', artificial('AA'))], ['a'], [folded('a', 'CC')])

    def test_no_fold_eligible_source_zero_retained(self):
        out = c.evaluate([response('a', artificial('A' * 100))], ['a'])
        self.assertEqual(out['complete_generation_metrics']['average_plddt'], 0)

    def test_upstream_equivalence_with_recording_folding(self):
        examples = ['', 'AA', 'AA', 'C' * 100, 'C' * 99, 'C' * 98 + 'A']
        ids = [str(i) for i in range(len(examples))]
        rs = [response(i, artificial(s) if s else '') for i, s in zip(ids, examples)]
        folds = [folded(i, s) for i, s in zip(ids, examples) if 0 < len(s) < 100]
        with contextlib.redirect_stdout(io.StringIO()):
            expected = upstream_evaluator().score(examples)
        self.assertEqual(c.evaluate(rs, ids, folds)['complete_generation_metrics'], expected)

    def test_lock_detects_change(self):
        with tempfile.TemporaryDirectory() as td:
            p, l = Path(td) / 'records.json', Path(td) / 'lock.json'
            p.write_text(json.dumps([response('a', '')]))
            l.write_text(json.dumps({'task_id': 'P37', 'protocol_variant': c.VARIANT,
                                    'terminal_records_sha256': c.sha256_file(p), 'planned_case_ids': ['a']}))
            c.verify_prediction_lock(l, p)
            p.write_text('[]')
            with self.assertRaises(ValueError): c.verify_prediction_lock(l, p)

    def test_generation_request_no_demonstrations_or_refs(self):
        d = {'task_id': 'P37', 'protocol_variant': c.VARIANT, 'planned_case_ids': ['a'],
             'model': {'served_model_name': 'Qwen/Qwen3.8-27B'},
             'generation': {'prompt': c.GENERATION_PROMPT, 'temperature': .9, 'top_p': .9,
                            'top_k': 50, 'max_output_tokens': 2048, 'seed_base': 42, 'enable_thinking': False}}
        req = c.build_generation_request(0, d)
        self.assertEqual(len(req['messages']), 1)
        self.assertNotIn('reference', json.dumps(req))
        d['generation']['prompt'] = 'changed'
        with self.assertRaises(ValueError): c.build_generation_request(0, d)


if __name__ == '__main__':
    unittest.main(verbosity=2)
