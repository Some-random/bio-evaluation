"""Pure P37 released-code contract; this module performs no model calls.

Retains SciReason's last-tag cleaning, ordered 99% positional clustering,
and <100-residue OmegaFold eligibility. Complete-delivery diagnostics are
separate from the upstream metrics, which are conditional on nonempty outputs.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any

VARIANT = 'SCIREASON_RELEASED_UPG_ZERO_SHOT_POSITIONAL99_OMEGAFOLD2_LOCAL_QWEN_V1'
GENERATION_PROMPT = 'Generate a protein sequence with <protein> </protein>.'


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def case_ids(count: int = 1000) -> list[str]:
    if isinstance(count, bool) or not isinstance(count, int) or not 1 <= count <= 1000:
        raise ValueError('Count must be a positive integer at most the released 1000 cases')
    return [f'P37-UPG-{i:04d}' for i in range(count)]


def build_generation_request(index: int, contract: dict[str, Any]) -> dict[str, Any]:
    """Render a request dictionary only; never send it to an endpoint."""
    ids = contract['planned_case_ids']
    if isinstance(index, bool) or not isinstance(index, int) or index < 0 or index >= len(ids):
        raise ValueError('Invalid frozen generation slot')
    if contract['task_id'] != 'P37' or contract['protocol_variant'] != VARIANT:
        raise ValueError('Wrong task or protocol')
    if contract['generation']['prompt'] != GENERATION_PROMPT:
        raise ValueError('No functional, pathogen or other conditioned prompt is permitted here')
    g = contract['generation']
    return {'model': contract['model']['served_model_name'],
            'messages': [{'role': 'user', 'content': GENERATION_PROMPT}],
            'n': 1, 'temperature': g['temperature'], 'top_p': g['top_p'],
            'top_k': g['top_k'], 'max_tokens': g['max_output_tokens'],
            'seed': g['seed_base'] + index,
            'chat_template_kwargs': {'enable_thinking': g['enable_thinking']}}


def postprocess(text: Any) -> str:
    """Exactly the released UPG_postprocess string transformation."""
    if not isinstance(text, str):
        return ''
    matches = re.findall(r'<protein>(.*?)</protein>', text, re.DOTALL)
    if not matches:
        return ''
    s = matches[-1].strip().replace(';', '').replace(' ', '')
    valid = set('ACDEFGHIKLMNPQRSTVWY-')
    return ''.join(aa for aa in s.upper() if aa in valid)


def positional_identity(a: str, b: str) -> float:
    if len(a) != len(b) or not a:
        return 0
    return sum(x == y for x, y in zip(a, b)) / len(a)


def positional_clusters(predictions: list[str]) -> list[int]:
    """Source-order greedy clustering; this is not alignment-based clustering."""
    representatives: list[str] = []
    assignments: list[int] = []
    for seq in predictions:
        found = None
        for i, rep in enumerate(representatives):
            if abs(len(seq) - len(rep)) < 20 and positional_identity(seq, rep) >= .99:
                found = i
                break
        if found is None:
            found = len(representatives)
            representatives.append(seq)
        assignments.append(found)
    return assignments


def validate_records(records: list[dict], planned: list[str]) -> dict[str, dict]:
    if not planned or len(set(planned)) != len(planned):
        raise ValueError('Planned IDs must be nonempty and unique')
    seen = {}
    for r in records:
        ident = r['case_id']
        if ident not in planned or ident in seen:
            raise ValueError('Foreign or duplicate terminal case ID')
        if r.get('status') not in {'response', 'transport_error', 'http_error', 'response_error'}:
            raise ValueError('Records must be observed terminal outcomes')
        if r['status'] == 'response':
            if not isinstance(r.get('final_text'), (str, type(None))):
                raise ValueError('Final content must be text or absent')
            if not isinstance(r.get('finish_reason'), (str, type(None))):
                raise ValueError('Invalid finish reason')
        seen[ident] = r
    return seen


def evaluate(records: list[dict], planned: list[str], fold_records: list[dict] | None = None) -> dict:
    """Aggregate frozen terminals and independently produced OmegaFold scores.

    Missing progress/records remain unknown, and no missing record establishes
    zero requests. No sequence or raw output is included in this result.
    """
    seen = validate_records(records, planned)
    ordered = [seen[i] for i in planned if i in seen]
    delivered = [r for r in ordered if r['status'] == 'response']
    clean = {r['case_id']: postprocess(r.get('final_text')) for r in delivered}
    valid = [(i, clean[i]) for i in planned if clean.get(i)]
    eligible = [(i, s) for i, s in valid if len(s) < 100]
    counts = {'planned': len(planned), 'terminal_observed': len(ordered),
              'runtime_unobserved': len(planned)-len(ordered),
              'responses_saved': len(delivered),
              'transport_errors': sum(r['status'] == 'transport_error' for r in ordered),
              'http_errors': sum(r['status'] == 'http_error' for r in ordered),
              'response_errors': sum(r['status'] == 'response_error' for r in ordered),
              'empty_finals': sum(not (r.get('final_text') or '').strip() for r in delivered),
              'truncations': sum(r.get('finish_reason') == 'length' for r in delivered),
              'nonempty_postprocessed_outputs': len(valid), 'fold_eligible': len(eligible)}
    fold_map = {}
    eligible_ids = {i for i, _ in eligible}
    for r in fold_records or []:
        i = r['case_id']
        if i not in eligible_ids or i in fold_map:
            raise ValueError('Foreign, duplicate or ineligible folding result')
        if r.get('postprocessed_sequence_sha256') != hashlib.sha256(clean[i].encode()).hexdigest():
            raise ValueError('Folding result does not match the locked generated output')
        if r.get('folding_protocol') != 'SCIREASON_OMEGAFOLD_MODEL2_10CYCLE_V1':
            raise ValueError('Wrong folding condition')
        if r.get('status') == 'success':
            v = r.get('mean_plddt')
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not 0 <= v <= 100:
                raise ValueError('Expected finite OmegaFold mean confidence on the 0..100 scale')
        elif r.get('status') != 'error':
            raise ValueError('Folding status must be success or error')
        fold_map[i] = r
    scores = [r['mean_plddt'] for r in fold_map.values() if r['status'] == 'success']
    fold_complete = len(scores) == len(eligible)
    generation_terminal = len(ordered) == len(planned)
    observed = None
    if valid:
        cluster_ids = positional_clusters([s for _, s in valid])
        observed = {'valid_rate': round(len(valid)/len(planned), 4),
                    'average_length': round(sum(len(s) for _, s in valid)/len(valid), 2),
                    'diversity': round(len(set(cluster_ids))/len(valid), 4),
                    'num_length_less_100': len(eligible)}
    complete_metrics = dict(observed) if observed is not None and generation_terminal else None
    if complete_metrics is not None:
        complete_metrics['average_plddt'] = round(sum(scores)/len(scores), 2) if scores and fold_complete else (0.0 if not eligible else None)
    return {'task_id': 'P37', 'protocol_variant': VARIANT, 'counts': counts,
            'generation_terminal': generation_terminal,
            'full_delivery': generation_terminal and len(delivered) == len(planned) and len(valid) == len(planned)
                             and not counts['empty_finals'] and not counts['truncations'],
            'observed_output_metrics': observed, 'complete_generation_metrics': complete_metrics,
            'folding': {'results_observed': len(fold_map), 'successes': len(scores),
                        'errors': sum(r['status'] == 'error' for r in fold_map.values()),
                        'unobserved': len(eligible)-len(fold_map), 'complete': fold_complete,
                        'observed_success_average_plddt': round(sum(scores)/len(scores), 2) if scores else None},
            'all_invalid_metric_policy': 'Undefined average length/diversity when no nonempty parsed outputs; upstream would divide by zero.',
            'not_paper_native': True, 'biological_correctness_assessed': False,
            'result_claim': 'Released-code sequence-format, diversity and predictor-confidence proxies only; no experimental or functional validation.'}


def fold_request_manifest(records: list[dict], planned: list[str]) -> list[dict]:
    """Metadata only; no raw sequence is returned or sent to a model."""
    seen = validate_records(records, planned)
    out = []
    for ident in planned:
        r = seen.get(ident)
        if r and r['status'] == 'response':
            s = postprocess(r.get('final_text'))
            if 0 < len(s) < 100:
                out.append({'case_id': ident, 'length': len(s),
                            'postprocessed_sequence_sha256': hashlib.sha256(s.encode()).hexdigest(),
                            'folding_protocol': 'SCIREASON_OMEGAFOLD_MODEL2_10CYCLE_V1'})
    return out


def verify_prediction_lock(lock_path: str | Path, records_path: str | Path) -> dict:
    lock = json.loads(Path(lock_path).read_text())
    if lock.get('task_id') != 'P37' or lock.get('protocol_variant') != VARIANT:
        raise ValueError('Wrong prediction lock condition')
    if lock['terminal_records_sha256'] != sha256_file(records_path):
        raise ValueError('Terminal records changed after lock')
    planned = lock['planned_case_ids']
    validate_records(json.loads(Path(records_path).read_text()), planned)
    return lock
