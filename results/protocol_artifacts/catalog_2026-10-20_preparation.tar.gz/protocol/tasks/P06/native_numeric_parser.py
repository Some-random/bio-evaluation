"""P06 exact finite-scalar syntax from scripts/catalog_metric_helpers.py; no labels."""
import math
import re


def parse_number(text):
    if not isinstance(text, str):
        return None
    match = re.fullmatch(r"\s*(?:Answer\s*:\s*)?([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)\s*", text, re.IGNORECASE)
    if not match:
        return None
    value = float(match.group(1))
    return value if math.isfinite(value) else None
