"""Freeze prepared P13 contracts once common code and token preflight are final.
Requires explicit expected common source hashes; cannot edit a dispatched config.
"""
from pathlib import Path
import argparse
import hashlib
import json
from datetime import datetime
from zoneinfo import ZoneInfo

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
def sha(path):
 d=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):d.update(b)
 return d.hexdigest()
def rel(p):return str(p.relative_to(ROOT))
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
 a=argparse.ArgumentParser(description=__doc__)
 a.add_argument('--runner-sha256',required=True);a.add_argument('--scorer-sha256',required=True)
 args=a.parse_args()
 runner=ROOT/'scripts/run_deepfri_catalog_20261020.py';scorer=ROOT/'scripts/score_deepfri_catalog_20261020.py'
 if sha(runner)!=args.runner_sha256 or sha(scorer)!=args.scorer_sha256:raise ValueError('Common code is not the explicit final reviewed snapshot')
 for pattern in ['runtime*/requests/*.json','development*/requests/*.json','benchmark*/requests/*.json']:
  if list(HERE.glob(pattern)):raise ValueError('P13 dispatch artifacts exist; frozen config is immutable')
 preflight=json.loads((HERE/'tokenizer_preflight.json').read_text())
 if not all(x['all_fit'] for x in preflight['input_preflight'].values()) or not preflight['entire_permitted_serialization_fits_output_budget']:raise ValueError('Token preflight failed')
 common=[runner,HERE/'prepare_p13.py',HERE/'freeze_p13.py',HERE/'test_p13_preparation.py',HERE/'tokenizer_preflight.py',HERE/'tokenizer_preflight.json',HERE/'source_manifest.json',HERE/'source/nrPDB-GO_sequences.fasta',HERE/'source/nrPDB-GO_valid.txt']
 for name in ['development','test']:
  p=HERE/(name+'_config.json');d=json.loads(p.read_text())
  d['files_sha256']={rel(x):sha(x) for x in common}
  d['tokenizer_preflight_file']=rel(HERE/'tokenizer_preflight.json')
  d['case_scope']='exact reviewed complete released test95 source-order cohort' if name=='test' else '12 length-stratified official validation cases; delivery only'
  d['paper_comparison']='Zero-shot Qwen full-FASTA adaptation; exact native source-global BP classes and AP/Fmax formulas. Dense bounded-precision nonthinking serialization is a separately named prospective interface. Not matched trained DeepFRI/ProtST nor original PDB/cropped input experiment.'
  d['scoring_runtime_policy']={'device':'cpu','dtype':'torch.float32','num_threads':1,'num_interop_threads':1,'runtime_recorded_in_score':True,'native_functions':['area_under_prc','f1_max'],'no_score_propagation':True}
  if name=='test':
   d['scorer']='scripts/score_deepfri_catalog_20261020.py'
   d['files_sha256'][rel(scorer)]=sha(scorer)
   metric=ROOT/d['metric_source_file'];d['files_sha256'][rel(metric)]=sha(metric)
   d['development_config_sha256']=sha(HERE/'development_config.json')
  write(p,d)
 status={'task_id':'P13','state':'offline_ready_awaiting_central_development_delivery_gate','updated_at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),'planned_test_cases':3416,'class_count':1943,'development_panel_planned':12,'preparation_tests_passed':6,'preparation_tests_run':6,'historical_outputs_unchanged':True,'source_test_cohort_verified':True,'references_separate':True,'biological_labels_read':False,'new_inference_calls':0,'runtime_started':False,'responses_saved':None,'actual_generation_counts_unknown_without_runtime':True,'task_specific_delivery_gate_passed':False,'native_metrics_scored':False,'input_tokenizer_all_fit':True,'maximum_test_prompt_tokens':preflight['input_preflight']['test']['max_prompt_tokens'],'maximum_prompt_plus_output_tokens':preflight['input_preflight']['test']['max_prompt_plus_reserved_output_tokens'],'context_limit':65536,'output_token_budget':16384,'conservative_serialization_token_upper_bound_plus_eos':preflight['conservative_byte_bpe_output_token_upper_bound_plus_eos'],'development_config_sha256':sha(HERE/'development_config.json'),'test_config_sha256':sha(HERE/'test_config.json'),'runner_sha256':sha(runner),'scorer_sha256':sha(scorer),'remaining':['Central root exact grant and 12-case official-validation delivery gate, with no correctness scoring.','Full3,416-case newcohort dispatch only after gate passes.','Native AP/Fmax scoring only after entire prediction/output lock sealed.'],'gpu_dispatch_owner':'root','user_authorized_new_complete_local_condition':True}
 write(HERE/'status.json',status)
 print(json.dumps(status))
if __name__=='__main__':main()
