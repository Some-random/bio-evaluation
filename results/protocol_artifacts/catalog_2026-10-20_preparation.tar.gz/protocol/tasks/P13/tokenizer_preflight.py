"""Token-only input/output size preflight; no weights, labels or inference."""
from pathlib import Path
import hashlib
import json
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
sys.path.insert(0,str(ROOT/'scripts'))
import run_deepfri_catalog_20261020 as common
from transformers import AutoTokenizer

MODEL=Path('/dfs/scratch0/tchen/models/Qwen3.8-27B')
tokenizer=AutoTokenizer.from_pretrained(MODEL,local_files_only=True)
limits={}
for split in ['development','test']:
 config=json.loads((HERE/(split+'_config.json')).read_text())
 counts=[]
 with (HERE/(split+'_inputs.jsonl')).open() as f:
  for line in f:
   case=json.loads(line)
   value=tokenizer.apply_chat_template(case['messages'],tokenize=True,add_generation_prompt=True,enable_thinking=False)
   ids=value['input_ids'] if hasattr(value,'keys') else value
   if ids and isinstance(ids[0],list):ids=ids[0]
   count=len(ids)
   if count+16384>65536:raise ValueError('Prompt/output exceeds context '+case['case_id'])
   counts.append({'case_id':case['case_id'],'prompt_tokens':count})
 if len(counts)!=config['planned']:raise ValueError('incomplete tokenizer cohort')
 limits[split]={'planned':len(counts),'min_prompt_tokens':min(r['prompt_tokens'] for r in counts),'max_prompt_tokens':max(r['prompt_tokens'] for r in counts),'max_prompt_plus_reserved_output_tokens':max(r['prompt_tokens'] for r in counts)+16384,'all_fit':True,'counts':counts}
 print(split,len(counts),limits[split]['max_prompt_tokens'],flush=True)
examples={}
for name,values in [('all_zero',['0']*1943),('all_maximum_width',['0.999']*1943),('all_one_maxwidth',['1.000']*1943),('cycling_3dp',[format((i%1001)/1000,'.3f') for i in range(1943)])]:
 text='{"scores":['+','.join(values)+']}'
 common.parse_vector(text,1943)
 ids=tokenizer.encode(text,add_special_tokens=False)
 examples[name]={'characters':len(text),'utf8_bytes':len(text.encode()),'tokens':len(ids),'tokens_plus_end_marker_reserve':len(ids)+1}
 if len(ids)+1>16384:raise ValueError('Serialization exceeds budget')
chars=set('{"scores":[],.0123456789}')
ascii_coverage={c:len(tokenizer.encode(c,add_special_tokens=False)) for c in sorted(chars)}
# Qwen byte-level BPE normalizes no ASCII numeric bytes. Once byte alphabet
# coverage is verified, merges can only reduce its ordinary token count.
backend=json.loads(tokenizer.backend_tokenizer.to_str())
if backend['model']['type']!='BPE' or backend.get('normalizer') not in (None, {'type':'NFC'}) or any(n!=1 for n in ascii_coverage.values()):
 raise ValueError('Cannot certify compact ASCII BPE upper bound')
max_ascii=len('{"scores":['+','.join(['1.000']*1943)+']}')
result={'task_id':'P13','at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),'tokenizer_model_path':str(MODEL),'model_revision':common.REVISION,'class_count':1943,'full_sequences_preserved':True,'global_classes_preserved':True,'context_limit':65536,'output_token_budget':16384,'input_preflight':limits,'output_exemplars':examples,'output_alphabet_single_byte_token_counts':ascii_coverage,'bpe_model_type':backend['model']['type'],'normalizer':backend.get('normalizer'),'compact_output_max_ascii_bytes':max_ascii,'conservative_byte_bpe_output_token_upper_bound_plus_eos':max_ascii+1,'entire_permitted_serialization_fits_output_budget':max_ascii+1<=16384,'source_files_sha256':{str(p.relative_to(MODEL)):hashlib.sha256(p.read_bytes()).hexdigest() for p in MODEL.iterdir() if p.name in ['tokenizer.json','tokenizer_config.json','chat_template.jinja','vocab.json','merges.txt']},'biological_labels_read':False,'model_weights_loaded':False,'new_inference_calls':0,'note':'Input token counts use exact pinned chat template with thinking disabled. Byte-BPE upper bound applies only to the fixed ASCII compact output grammar, not an unconstrained natural-language response. Actual validation delivery remains a separate required gate.'}
(HERE/'tokenizer_preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_fit':True,'max_test_prompt_tokens':limits['test']['max_prompt_tokens'],'output_exemplars':examples,'max_serialization_token_upper_bound_plus_eos':max_ascii+1}),flush=True)
