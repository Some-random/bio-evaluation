"""Seal P13 full source cohort and an independent label-blind delivery panel.

No inference, target reads, model-weight loads or scorer execution is performed.
"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import run_deepfri_catalog_20261020 as common

RESTORED = ROOT / '.local/evaluation_revision_2026-10-18/scoring/null_equivalence_recovery_v1/prepared_v2/p13/project'
OLD = RESTORED / 'data/catalog_deepfri_tasks/P13'
SOURCE_HASHES = {
 'model_inputs.jsonl':'e48f5741b057ef4c7b6625c91b373121fb150a1965a026e72e08f071e22e3f97',
 'input_provenance.jsonl':'f37590aec1c1c33e3cfaa42bbca2b0fd2b17fe1ea35e0af6a4a26948b71cbde4',
 'class_vocabulary.json':'9ca8839a9b674292a4585185c91a2bf2475d0ae3b6226c662d1a108ef5701e1b',
 'scorer_references.jsonl':'9fa3ca3c827ff47e5cbf80c988e1154e4dd4164fa512ec2d873e4f7121e1b452',
}
GO_HASHES = {
 'nrPDB-GO_valid.txt':'d72bf584d50ae1dd215fad031ccdada0399a32659ea753c2679756dba3fa1bf1',
 'nrPDB-GO_test.txt':'753e6741bf8c9b178b0b15eb293daaa32c0036fb13ae3bca43352f66579a19ec',
 'nrPDB-GO_test_sequences.fasta':'1f48b7265fdc540df77f3bb3d4f0fec0e68d0b301d7487c569efbf8333bd607e',
 'nrPDB-GO_sequences.fasta':'4cabd881a5dac1594726f8f5d0bf952978e732ec2599a60ab940a4314fe7d1be',
}

def sha(path):
 d=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''): d.update(block)
 return d.hexdigest()

def rel(path): return str(Path(path).relative_to(ROOT))
def write(path,value):
 raw=(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
 if path.exists() and path.read_bytes()!=raw:
  path.write_bytes(raw)
 elif not path.exists(): path.write_bytes(raw)

def rows(path):
 with path.open() as f:
  for line in f:
   if line.strip():yield json.loads(line)

def fasta(path):
 values={};key=None
 with path.open() as f:
  for line in f:
   line=line.strip()
   if not line:continue
   if line.startswith('>'):
    key=line[1:].split()[0]
    if key in values:raise ValueError('duplicate FASTA ID')
    values[key]=''
   else:
    if key is None:raise ValueError('FASTA sequence before header')
    values[key]+=line
 return values

def select_panel(ordered, seqs, n=12):
 ranked=sorted(enumerate(ordered),key=lambda x:(len(seqs[x[1]]),x[0]))
 selected={ranked[round(i*(len(ranked)-1)/(n-1))][1] for i in range(n)}
 if len(selected)!=n:raise ValueError('quantile panel failed distinctness')
 return [x for x in ordered if x in selected]

def main():
 for name,want in SOURCE_HASHES.items():
  if sha(OLD/name)!=want:raise ValueError('restored source differs:'+name)
 for name,want in GO_HASHES.items():
  if sha(HERE/'source'/name)!=want:raise ValueError('GO member differs:'+name)
 vocab=json.loads((OLD/'class_vocabulary.json').read_text())
 if len(vocab['classes'])!=1943 or vocab['branch']!='BP':raise ValueError('wrong BP vocabulary')
 write(HERE/'class_vocabulary.json',vocab)
 seqs=fasta(HERE/'source/nrPDB-GO_sequences.fasta')
 test_seqs=fasta(HERE/'source/nrPDB-GO_test_sequences.fasta')
 test_ids=(HERE/'source/nrPDB-GO_test.txt').read_text().split()
 val_ids=(HERE/'source/nrPDB-GO_valid.txt').read_text().split()
 if len(set(val_ids))!=len(val_ids) or set(val_ids)&set(test_ids):raise ValueError('validation overlaps test')
 panel=select_panel(val_ids,seqs)
 oldreview=json.loads((ROOT/'configs/local_deepfri_p13_review.json').read_text())
 legacy=list(rows(OLD/'model_inputs.jsonl'));provs=list(rows(OLD/'input_provenance.jsonl'))
 if len(legacy)!=3416 or [r['case_id'] for r in legacy]!=oldreview['approved_case_ids']:raise ValueError('test reviewed cohort differs')
 if [r['case_id'] for r in legacy]!=test_ids or [r['case_id'] for r in provs]!=test_ids:raise ValueError('source-order mismatch')
 allseqs={}
 for case,prov in zip(legacy,provs):
  text=case['messages'][0]['content']
  sequence=text.split('\n\nComplete amino acid sequence:\n',1)[1].split('\n\nFixed global class vocabulary',1)[0]
  if sequence!=test_seqs[case['case_id']] or len(sequence)!=prov['sequence_length'] or hashlib.sha256(sequence.encode()).hexdigest()!=prov['full_sequence_sha256']:raise ValueError('full sequence differs')
  allseqs[case['case_id']]=sequence
 for split,ids,source in [('official_test',test_ids,allseqs),('official_validation',panel,seqs)]:
  name='test' if split=='official_test' else 'development'
  input_path=HERE/(name+'_inputs.jsonl')
  with input_path.open('w') as f:
   for cid in ids:
    value={'task_id':'P13','case_id':cid,'messages':[{'role':'user','content':common.dense_prompt('P13',source[cid],vocab['classes'])}]}
    f.write(json.dumps(value,ensure_ascii=False)+'\n')
  review={'task_id':'P13','input_review_only':True,'approved_case_ids':ids,'held_cases':[],
   'basis':'Same natural sequence-to-biological-process annotation goal as approved historical complete cohort; complete global vocabulary; no fitness/engineering objectives. Development uses the official disjoint validation split, selected on input length only. No case target labels or prediction outcomes were read.',
   'source_review_file':'configs/local_deepfri_p13_review.json','source_review_sha256':sha(ROOT/'configs/local_deepfri_p13_review.json'),
   'case_identifiers_supplied_to_model':False,'reference_labels_supplied_to_model':False,'split':split}
  write(HERE/(name+'_review.json'),review)
  config={'schema_version':1,'task_id':'P13','class_count':1943,'branch':'BP','planned':len(ids),'split':split,
   'run_id':'qwen38_27b_p13_dense_confidence_'+name+'_2026-10-20_v1',
   'variant':common.VARIANT,'model':common.MODEL,'model_revision':common.REVISION,'generation':common.generation_for(1943),
   'input_file':rel(input_path),'input_sha256':sha(input_path),'review_file':rel(HERE/(name+'_review.json')),
   'review_sha256':sha(HERE/(name+'_review.json')),'vocabulary_file':rel(HERE/'class_vocabulary.json'),
   'vocabulary_sha256':sha(HERE/'class_vocabulary.json'),'files_sha256':{},
   'runner':'scripts/run_deepfri_catalog_20261020.py','reporting_protocol_kind':'adapted',
   'material_differences':['Dense all-class vector replaces historical sparse class-ID map; no missing-position imputation.','Nonthinking final-only constrained serialization with 3 decimal places and uniform 16,384-token output budget.','Preserves reviewed 3,416-case complete released FASTA test95 cohort, source-global class order and native AP/Fmax formulas.','Complete FASTA inputs differ from paper PDB-modeled/first-550-residue inputs; prompted zero-shot Qwen is not a trained DeepFRI/ProtST model.'],
   'historical_calls_immutable':True,'native_score_gate':'Full AP/Fmax require one valid vector per entire planned test cohort; incomplete/invalid remains null; report coverage separately.',
   'no_selective_old_retries':True,'reference_labels_read_during_preparation':False,
   'task_preparer':rel(Path(__file__))}
  if split=='official_test':
   config.update(scorer_reference_file=rel(OLD/'scorer_references.jsonl'),scorer_reference_sha256=SOURCE_HASHES['scorer_references.jsonl'],
      metric_source_file=rel(RESTORED/'sources/deepfri_contract_audit_2026-10-15/torchdrug__torchdrug__metrics__metric.py'),metric_source_sha256='760f376d4125ab2cc9332c9e83b944d4464da51aea577d75266d9247aca81776',
      development_config_sha256='PENDING_COMMON_CODE_FREEZE')
  write(HERE/(name+'_config.json'),config)
 audit={'task_id':'P13','reference_labels_read':False,'new_inference_calls':0,'historical_source_files':{rel(OLD/n):h for n,h in SOURCE_HASHES.items()},'extracted_go_source_files':{rel(HERE/'source'/n):h for n,h in GO_HASHES.items()},
  'parent_archive':'.local/source_acquisition_2026-10-19/evaluators/data/GeneOntology.zip','parent_archive_publisher_md5':'376be1f088cd1fe720e1eaafb701b5cb','parent_archive_sha256':'a17214e8fab669b21945d778de0f50053b0275233f236c326bb3cf9dddbafae1','parent_archive_bytes':1691808865,'extracted_members_crc_verified':True,
  'test_cases':len(test_ids),'class_count':1943,'development_source_cases':len(val_ids),'development_cases':len(panel),'development_panel_selection':'12 even quantiles of full sequence length; source-order tie break; preserve original source order for dispatch; no labels/outcomes read',
  'development_case_ids':panel,'development_sequence_lengths':[len(seqs[x]) for x in panel],
  'test_sequence_min_length':min(map(len,allseqs.values())),'test_sequence_max_length':max(map(len,allseqs.values())),
  'development_disjoint_case_ids':True,'labels_retained_separately':True,'test_cohort_exact_historical_review':True,
  'prepared_at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()}
 write(HERE/'source_manifest.json',audit)
 print(json.dumps({k:v for k,v in audit.items() if k not in ('historical_source_files','extracted_go_source_files')}))
if __name__=='__main__':main()
