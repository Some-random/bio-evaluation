"""Synthetic protocol/join/reference-isolation checks; no real targets opened."""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

TASK = Path(__file__).resolve().parent
sys.path.insert(0, str(TASK))
import prepare
import score


class ForbiddenReferences(dict):
    def __getitem__(self, key):
        if key in ("output", "meta_data"):
            raise AssertionError("Preparation accessed references")
        return super().__getitem__(key)


def sample(sequence="ACDE", index=0):
    case_id = f"stability:test:{index}"
    source = ForbiddenReferences(input=f"<protein>{sequence}</protein> Predict stability.", output="secret", meta_data={"label": 1.25})
    case = {"task_id": "P08", "case_id": case_id, "messages": [{"role": "user", "content": "Predict the numeric stability.\n" + sequence}]}
    review = {"approved_case_ids": [case_id], "held_cases": []}
    return source, case, review


class P09Tests(unittest.TestCase):
    def test_declared_boundary(self):
        self.assertEqual([score.binary(x) for x in [-5, -2.0, 0, 1, 1.0, 1.00001, 2]], ["No", "No", "No", "No", "No", "Yes", "Yes"])

    def test_nonfinite_references_rejected(self):
        for value in [float("nan"), float("inf"), -float("inf"), True, "2"]:
            with self.assertRaises(ValueError):
                score.binary(value)

    def test_all_planned_denominator(self):
        result = score.metrics([0, 2, 2, 0], [0, 2, None, 2])
        self.assertEqual((result["correct"], result["invalid_or_missing"], result["accuracy_percent"]), (2, 1, 50.0))

    def test_all_invalid_still_full_denominator(self):
        result = score.metrics([0, 2], [None, None])
        self.assertEqual(result["accuracy_percent"], 0)
        self.assertEqual(result["invalid_or_missing"], 2)

    def test_reference_fields_inaccessible_to_builder(self):
        source, case, review = sample()
        inputs, joins = prepare.build_join([source], [case], review)
        self.assertEqual(inputs[0]["messages"], case["messages"])
        self.assertEqual(set(inputs[0]), {"task_id", "case_id", "messages"})
        self.assertEqual(joins[0]["sequence_sha256"], prepare.sha(b"ACDE"))

    def test_sequence_mismatch_rejected(self):
        source, case, review = sample()
        source["input"] = "<protein>ACDF</protein> Predict stability."
        with self.assertRaises(ValueError):
            prepare.build_join([source], [case], review)

    def test_source_order_mismatch_rejected(self):
        source, case, review = sample(index=1)
        with self.assertRaises(ValueError):
            prepare.build_join([source], [case], review)

    def test_unapproved_case_rejected(self):
        source, case, review = sample()
        review["approved_case_ids"] = []
        with self.assertRaises(ValueError):
            prepare.build_join([source], [case], review)

    def test_held_case_rejected(self):
        source, case, review = sample()
        review["held_cases"] = [case["case_id"]]
        with self.assertRaises(ValueError):
            prepare.build_join([source], [case], review)

    def test_extra_protein_rejected(self):
        with self.assertRaises(ValueError):
            prepare.extract_sequence("<protein>ACDE</protein> <protein>FGHI</protein>")

    def test_duplicate_sequences_rejected(self):
        source, case, _ = sample()
        source2, case2, _ = sample(index=1)
        review = {"approved_case_ids": [case["case_id"], case2["case_id"]], "held_cases": []}
        with self.assertRaises(ValueError):
            prepare.build_join([source, source2], [case, case2], review)

    def test_failed_seal_never_opens_reference(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            reference = base / "forbidden.json"
            cfg = {"p08_config": "config.json", "reference_file": str(reference)}
            with mock.patch.object(score, "verify_config", return_value=cfg), mock.patch.object(score, "load_p08_verifier", return_value=mock.Mock(side_effect=ValueError("unsealed"))):
                with self.assertRaisesRegex(ValueError, "unsealed"):
                    score.score(base, base / "config.json", "expected", base / "scores.json")
            self.assertFalse(reference.exists())

    def test_sealed_reference_join_and_score_integration(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            rows = []
            cases = []
            joins = []
            for i, sequence in enumerate(["ACDE", "FGHI"]):
                source, case, _ = sample(sequence=sequence, index=i)
                source = dict(source)
                source["meta_data"]["label"] = [1.0, 1.25][i]
                rows.append(source)
                cases.append(case)
                joins.append({"p08_case_id": case["case_id"], "scireason_source_index": i,
                              "sequence_sha256": prepare.sha(sequence.encode()),
                              "p08_messages_sha256": prepare.sha(prepare.encode(case["messages"]))})
            reference = base / "references.json"
            reference.write_bytes(prepare.encode(rows))
            join = base / "join.json"
            join.write_bytes(prepare.encode({"cases": joins}))
            lock = base / "prediction_lock.json"
            lock.write_bytes(b"synthetic already-verified seal")
            cfg = {"task_id": "P09", "run_id": "synthetic", "p08_config": "p08.json",
                   "p08_config_sha256": "synthetic", "sequence_join_file": str(join),
                   "sequence_join_sha256": prepare.sha(join.read_bytes()),
                   "reference_file": str(reference), "reference_sha256": prepare.sha(reference.read_bytes()),
                   "material_differences": ["synthetic"]}
            seal = ({"run_id": "synthetic_p08"}, {}, {}, cases, [1.0, None], [])
            with mock.patch.object(score, "verify_config", return_value=cfg), mock.patch.object(score, "load_p08_verifier", return_value=mock.Mock(return_value=seal)), mock.patch("builtins.print"):
                result = score.score(base, base / "config.json", "synthetic", base / "scores.json")
            self.assertEqual(result["metrics"]["accuracy_percent"], 50)
            self.assertEqual(json.loads((base / "scores.json").read_text())["metrics"]["prediction_class_counts"], {"No": 1, "invalid": 1})
            self.assertEqual(result["external_judge_calls"], 0)


if __name__ == "__main__":
    unittest.main()
