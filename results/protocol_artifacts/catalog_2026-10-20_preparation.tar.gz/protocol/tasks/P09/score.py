"""One offline P09 threshold-derived score after the complete P08 lock verifies."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime
import importlib.util
import json
import math
from pathlib import Path
import sys
from zoneinfo import ZoneInfo

from prepare import TASK, VARIANT, encode, extract_sequence, immutable, sha


def binary(value):
    if type(value) not in (int, float) or not math.isfinite(value):
        raise ValueError("Threshold requires a finite numeric value")
    return "Yes" if value > 1.0 else "No"


def metrics(targets, predictions):
    if not targets or len(targets) != len(predictions):
        raise ValueError("Full aligned nonempty denominator required")
    gold = [binary(value) for value in targets]
    pred = [None if value is None else binary(value) for value in predictions]
    correct = sum(a == b for a, b in zip(gold, pred))
    invalid = sum(value is None for value in pred)
    return {"planned": len(gold), "valid_predictions": len(gold) - invalid,
            "invalid_or_missing": invalid, "correct": correct,
            "accuracy_percent": correct / len(gold) * 100,
            "gold_class_counts": dict(Counter(gold)), "prediction_class_counts": dict(Counter("invalid" if p is None else p for p in pred)),
            "invalid_policy": "Every missing, malformed, empty, truncated or failed P08 prediction is incorrect; all planned cases remain in denominator."}


def verify_config(path, expected_sha):
    raw = path.read_bytes()
    if sha(raw) != expected_sha:
        raise ValueError("Frozen P09 configuration hash differs")
    cfg = json.loads(raw)
    if (cfg["task_id"] != "P09" or cfg["protocol_variant"] != VARIANT
            or cfg["planned"] != 12851 or cfg["new_model_calls_required"] != 0):
        raise ValueError("Require separately named complete P09 adaptation")
    if cfg["rule"] != {"operator": ">", "threshold": 1.0, "positive": "Yes", "negative": "No", "equality": "No", "nonfinite_reference": "abort_scoring", "invalid_prediction": "incorrect_in_full_denominator"}:
        raise ValueError("Frozen threshold or denominator policy differs")
    for name, expected in cfg["files_sha256"].items():
        if sha(Path(name).read_bytes()) != expected:
            raise ValueError("Frozen P09 dependency differs: " + name)
    for key, hash_key in [("p08_config", "p08_config_sha256"), ("p08_scorer", "p08_scorer_sha256"),
                          ("input_file", "input_sha256"), ("sequence_join_file", "sequence_join_sha256")]:
        if sha(Path(cfg[key]).read_bytes()) != cfg[hash_key]:
            raise ValueError("Frozen input dependency differs: " + key)
    return cfg


def load_p08_verifier(cfg):
    # No target file is opened by loading this verified module or verify_seal.
    source = Path(cfg["p08_scorer"])
    sys.path.insert(0, str(source.parent))
    spec = importlib.util.spec_from_file_location("p09_p08_seal_verifier", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.verify_seal


def score(p08_run, config_path, expected_sha, output_path):
    if output_path.exists():
        raise ValueError("Score already exists; no overwrite or second implicit attempt")
    cfg = verify_config(config_path, expected_sha)
    p08_cfg, lock, completion, cases, predictions, outcomes = load_p08_verifier(cfg)(p08_run, Path(cfg["p08_config"]))
    joins = json.loads(Path(cfg["sequence_join_file"]).read_text())["cases"]
    if len(cases) != len(joins) or any(case["case_id"] != join["p08_case_id"] for case, join in zip(cases, joins)):
        raise ValueError("Exact P08 source identity join differs")
    for case, join in zip(cases, joins):
        if (sha(encode(case["messages"])) != join["p08_messages_sha256"]
                or sha(case["messages"][0]["content"].rsplit("\n", 1)[-1].encode()) != join["sequence_sha256"]):
            raise ValueError("Sealed P08 exact sequence/message join differs")
    # First access to outcome-bearing reference values occurs after full sealing.
    reference_raw = Path(cfg["reference_file"]).read_bytes()
    if sha(reference_raw) != cfg["reference_sha256"]:
        raise ValueError("Scorer-only source reference hash differs")
    refs = json.loads(reference_raw)
    if len(refs) != len(joins):
        raise ValueError("Reference cohort size differs")
    targets = []
    for index, (row, join) in enumerate(zip(refs, joins)):
        if index != join["scireason_source_index"] or sha(extract_sequence(row["input"]).encode()) != join["sequence_sha256"]:
            raise ValueError("Scorer reference sequence/source-order join differs")
        targets.append(row["meta_data"]["label"])
    result = {"task_id": "P09", "run_id": cfg["run_id"], "protocol_variant": VARIANT,
        "scored_at_pacific": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "configuration_sha256": expected_sha, "prediction_source_task_id": "P08", "prediction_source_run_id": p08_cfg["run_id"],
        "prediction_lock_sha256": sha((p08_run / "prediction_lock.json").read_bytes()),
        "prediction_source_config_sha256": cfg["p08_config_sha256"], "reference_sha256": cfg["reference_sha256"],
        "sequence_join_sha256": cfg["sequence_join_sha256"], "metrics": metrics(targets, predictions),
        "transport_or_response_errors": completion.get("transport_or_response_errors"),
        "truncations": completion.get("truncations"), "empty_finals": completion.get("empty_finals"),
        "historical_runs_modified": False, "new_model_calls_by_scorer": 0, "external_judge_calls": 0,
        "interpretation": "Declared >1.0 stability rule-derived binary accuracy from the complete new P08 scalar prediction condition. An explicitly labelled available-code adaptation, not certification of original NatureLM binary labels, original training regime or execution of SciReason's released cascade. No mechanistic/rationale or contamination-free claim.",
        "material_differences": cfg["material_differences"]}
    immutable(output_path, encode(result))
    print(json.dumps(result, sort_keys=True))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--p08-run", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=TASK / "adaptation_config.json")
    parser.add_argument("--expected-config-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    score(args.p08_run, args.config, args.expected_config_sha256, args.output)
