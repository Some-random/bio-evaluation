"""Prepare an explicitly rule-derived stability adaptation without model calls.

This module reads released question inputs and prior approved P08 solver inputs.
It never accesses `output` or `meta_data` values. Targets remain in the separately
retained release and may only be opened by score.py after prediction sealing.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[4]
TASK = Path(__file__).resolve().parent
RECOVERY = ROOT / ".local/source_recovery_round2_2026-10-19/paper_artifacts"
P08 = ROOT / ".local/catalog_execution_2026-10-20/tasks/P08"
VARIANT = "SCIREASON_DECLARED_GT1_RULE_DERIVED_FROM_QWEN_P08_NONTHINKING_SCALAR_20261020_V1"
PINS = {
    "test": (RECOVERY / "reproduction/SciReason_PEER_scorer_only/stability/test/data.json", "0c072b38c8f9a5064c57ba45ae32239509ecd68db1f85636e8a7ce30b0138b28"),
    "source_config": (RECOVERY / "reproduction/SciReason/opencompass/configs/datasets/PEER/peer.py", "8d60197b44c11347f93419aae931187a88c359403ff1a6a9c7bdc9585d0f5d0b"),
    "source_evaluator": (RECOVERY / "reproduction/SciReason/opencompass/datasets/PEER/evaluator.py", "1c728dba667f8f9ee342d4a9f32933ad0e189dcaab2b7be2bb962815d159cfab"),
    "p08_config": (P08 / "full_test_config.json", "e1ef7893a8b366f75d0c39782b6f10d35c19c054f1cfb365b359a6e087a6dc3f"),
    "p08_inputs": (P08 / "full_test_inputs.jsonl", "8f371005d3307e779e35e9e7b05a268cded8bf8ca2fc303fa7808a3f0359a67d"),
    "p08_review": (P08 / "full_test_review.json", "8f902e0fe9b1a26e0ce19b19c092d90f4c5c8fa575fff4562c1cdb0589682c3c"),
    "p08_scorer": (ROOT / "scripts/score_p08_regeneration_20261020.py", "f237854ec41e9d452c276d9fb35b050a4c85d03b770be048d02b72b6778c66be"),
    "p08_preparation": (ROOT / "scripts/prepare_p08_regeneration_20261020.py", "2c5d54a110e191363bd0fb4bd43acc21456d2a9666a6c8a01ac852e5f2ac3a67"),
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()


def immutable(path, raw):
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError("Frozen preparation differs: " + str(path))
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(raw)
    path.chmod(0o600)


def extract_sequence(question):
    if not isinstance(question, str):
        raise ValueError("Question input must be text")
    matches = list(re.finditer(r"<protein>([A-Z]+)</protein>", question))
    if len(matches) != 1:
        raise ValueError("Exactly one complete released protein required")
    return matches[0].group(1)


def build_join(released_rows, p08_cases, review):
    """Join complete sequences one-to-one, in original order; no labels read."""
    if len(released_rows) != len(p08_cases) or not released_rows:
        raise ValueError("Released/P08 cohort sizes differ")
    ids = [case["case_id"] for case in p08_cases]
    if review["approved_case_ids"] != ids or review["held_cases"]:
        raise ValueError("P08 independently approved exact cohort required")
    inputs, joins, seen = [], [], set()
    for index, (released, p08) in enumerate(zip(released_rows, p08_cases)):
        case_id = f"stability:test:{index}"
        if p08["task_id"] != "P08" or p08["case_id"] != case_id:
            raise ValueError("P08 source order/identity differs")
        messages = p08["messages"]
        if len(messages) != 1 or messages[0]["role"] != "user":
            raise ValueError("Only the approved single P08 user message is reused")
        sequence = extract_sequence(released["input"])
        source_sequence = messages[0]["content"].rsplit("\n", 1)[-1]
        if sequence != source_sequence or sequence in seen:
            raise ValueError("Exact unique source-order sequence join failed")
        seen.add(sequence)
        inputs.append({"task_id": "P09", "case_id": case_id, "messages": messages})
        joins.append({"case_id": case_id, "p08_case_id": p08["case_id"],
                      "scireason_source_index": index, "sequence_sha256": sha(sequence.encode()),
                      "sequence_length": len(sequence),
                      "p08_messages_sha256": sha(encode(messages))})
    return inputs, joins


def prepare(task_dir=TASK):
    for name, (path, expected) in PINS.items():
        if sha(path.read_bytes()) != expected:
            raise ValueError("Pinned source differs: " + name)
    # Parsing the container does not inspect or export outcome fields.
    released = json.loads(PINS["test"][0].read_text())
    p08_cases = [json.loads(line) for line in PINS["p08_inputs"][0].read_text().splitlines()]
    review = json.loads(PINS["p08_review"][0].read_text())
    if len(released) != 12851:
        raise ValueError("Exact released 12851-row test required")
    inputs, joins = build_join(released, p08_cases, review)
    immutable(task_dir / "p08_prediction_join_inputs.jsonl", b"".join((json.dumps(row, sort_keys=True) + "\n").encode() for row in inputs))
    immutable(task_dir / "exact_sequence_join.json", encode({"task_id": "P09", "planned": len(joins),
        "all_sequences_exact_in_source_order": True, "unique_sequences": len(joins),
        "reference_values_accessed": False, "output_fields_accessed": False, "cases": joins}))
    evidence = [ROOT / "reports/P09_PROTOCOL_RECOVERY_2026-10-19.json",
                RECOVERY / "reproduction_contract_diagnostic.json",
                RECOVERY / "sfm_all_available_history_inventory.json",
                RECOVERY / "reproduction_acquisition_receipt.json"]
    immutable(task_dir / "source_manifest.json", encode({
        "task_id": "P09", "code_repository": "https://github.com/open-sciencelab/SciReason",
        "code_revision": "92814ce45c36b691c19dc606bc1e4a50364eac51",
        "dataset_repository": "https://huggingface.co/datasets/SciReason/PEER-test",
        "dataset_revision": "0221348a7009c76bc6b5ff3a5db4b6593b35ddf3",
        "declared_rule_source": {"config_lines": [107, 110], "evaluator_lines": [140, 156],
            "rule": "numeric stability > 1.0 gives Yes; <=1.0 gives No"},
        "source_files": {name: {"path": str(path), "sha256": expected} for name, (path, expected) in PINS.items()},
        "availability_evidence": [{"path": str(path), "sha256": sha(path.read_bytes())} for path in evidence],
        "exact_native_condition": {"status": "unavailable_in_audited_author_releases",
            "missing": ["NatureLM stability measurement-to-binary conversion including equality/missing rules", "processed original binary test ID/label manifest"],
            "scope_of_finding": "Bounded recovery of author paper/supplements, all 20 available SFM revisions, project Resources, publisher HF metadata and public reproductions; not proof authors/backups lack the artifact."},
        "released_code_caveat": "eval_stability_cfg declares >1.0, but the released task loop selects an OpenAI cascade evaluator. This adaptation adopts the declared rule; it does not assert that rule ran in the published experiment.",
        "raw_upstream_source_publication": "Private acquisition includes a credential-shaped comment; publish only scanned derived code/metadata.",
        "test_reference_values_accessed": False, "new_inference_calls": 0}))
    config = {"schema_version": 1, "task_id": "P09", "protocol_variant": VARIANT,
        "run_id": "qwen38_27b_p09_scireason_gt1_from_p08_2026-10-20_v1", "planned": len(inputs),
        "execution_mode": "offline_rule_derived_from_exact_frozen_p08_generation",
        "benchmark_dispatch_authorized": False, "new_model_calls_required": 0,
        "model": "Qwen/Qwen3.8-27B", "model_revision": "1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0",
        "p08_config": str(PINS["p08_config"][0]), "p08_config_sha256": PINS["p08_config"][1],
        "p08_expected_run": str(P08 / "runtime/benchmark"),
        "p08_scorer": str(PINS["p08_scorer"][0]), "p08_scorer_sha256": PINS["p08_scorer"][1],
        "input_file": str(task_dir / "p08_prediction_join_inputs.jsonl"),
        "input_sha256": sha((task_dir / "p08_prediction_join_inputs.jsonl").read_bytes()),
        "sequence_join_file": str(task_dir / "exact_sequence_join.json"),
        "sequence_join_sha256": sha((task_dir / "exact_sequence_join.json").read_bytes()),
        "reference_file": str(PINS["test"][0]), "reference_sha256": PINS["test"][1],
        "reference_value_field": "meta_data.label", "reference_access_gate": "Verify complete P08 prediction lock and every sealed file first; no reference values opened during preparation.",
        "rule": {"operator": ">", "threshold": 1.0, "positive": "Yes", "negative": "No", "equality": "No", "nonfinite_reference": "abort_scoring", "invalid_prediction": "incorrect_in_full_denominator"},
        "primary_metric": "accuracy_percent_all_12851_planned_cases",
        "solver_input": "Exact new frozen P08 numeric-stability question/full sequence, not the variable SciReason prompts or NatureLM binary prompt.",
        "material_differences": ["Uses declared SciReason numeric threshold; original NatureLM binary mapping remains unverified", "Reuses one independently frozen P08 scalar prediction per exact matching complete sequence", "P08 prompt and constrained nonthinking scalar delivery differ from original binary prompts and SciReason variable prompts", "Uses finite numeric comparison directly; does not reproduce SciReason first-number regex bugs", "No external cascade judge, few-shot examples, new heads or training", "Released12851 test differs from historical TAPE paper12839; no historical paper split identity claimed"],
        "historical_runs_modified": False, "reference_values_opened": False,
        "files_sha256": {str(path): sha(path.read_bytes()) for path in [Path(__file__), TASK / "score.py", TASK / "test_p09.py", task_dir / "source_manifest.json"]}}
    immutable(task_dir / "adaptation_config.json", encode(config))
    return config


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=TASK)
    args = parser.parse_args()
    cfg = prepare(args.output)
    print(json.dumps({"task_id": "P09", "planned": cfg["planned"], "reference_values_accessed": False,
                      "new_inference_calls": 0, "config_sha256": sha((args.output / "adaptation_config.json").read_bytes())}))
