#!/usr/bin/env python3
"""Score sealed P07 predictions once, after rehashing all linked evidence.

Uses the exact pre-existing native outcome_metrics function and SciPy Spearman.
No network, inference, prediction replacement or subset promotion is performed.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(HERE / "scoring_packages"))
NATIVE_SHA = "71701e33509f5f7b1ad041ce66ad1a28193ae8675e13eb37a22ed7c1fd38d3d0"
REGEX = r"[+-]?[0-9]{1,12}(\.[0-9]{1,12})?([eE][+-]?[0-9]{1,2})?"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def resolve(path):
    value = Path(path)
    return value if value.is_absolute() else ROOT / value


def require_hash(path, expected):
    if sha(path) != expected:
        raise ValueError("Frozen artifact hash mismatch: " + str(path))


def verify_lock(folder, config_path, completion):
    lock_path = folder / "prediction_lock.json"
    require_hash(lock_path, completion["prediction_lock_sha256"])
    lock = json.loads(lock_path.read_text())
    if lock["config_sha256"] != sha(config_path) or lock["reference_labels_opened"] is not False:
        raise ValueError("Wrong condition or pre-lock label access")
    for name, expected in lock["files_sha256"].items():
        rel = Path(name)
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError("Unsafe lock path")
        require_hash(folder / rel, expected)
    for category in ("requests", "responses", "outcomes", "errors"):
        disk = {str(item.relative_to(folder)) for item in (folder / category).glob("*") if item.is_file()}
        recorded = {name for name in lock["files_sha256"] if name.startswith(category + "/")}
        if disk != recorded:
            raise ValueError("Unsealed evidence in " + category)
    return lock


def strict_final(body, parse_number):
    choices = body.get("choices", [])
    if len(choices) != 1:
        return None
    choice = choices[0]
    msg = choice.get("message", {})
    text = msg.get("content")
    reasoning = msg.get("reasoning", msg.get("reasoning_content"))
    if (choice.get("finish_reason") != "stop" or reasoning or msg.get("refusal") or msg.get("tool_calls")
            or not isinstance(text, str) or re.fullmatch(REGEX, text) is None):
        return None
    return text if parse_number(text) is not None else None


def score(config_path, folder):
    config_path, folder = Path(config_path).resolve(), Path(folder).resolve()
    if (folder / "scores.json").exists():
        raise ValueError("Scoring record already exists; preserve its bytes")
    config = json.loads(config_path.read_text())
    if config["task_id"] != "P07" or config["split"] != "official_test":
        raise ValueError("Only sealed P07 benchmark predictions can be scored")
    completion = json.loads((folder / "completion.json").read_text())
    if completion["config_sha256"] != sha(config_path) or completion["phase"] != "benchmark_generation":
        raise ValueError("Completion does not seal the configured benchmark condition")
    lock = verify_lock(folder, config_path, completion)
    manifest = json.loads((folder / "run_manifest.json").read_text())
    if manifest["config_sha256"] != sha(config_path) or manifest["configuration"] != config:
        raise ValueError("Run configuration differs from the sealed scorer condition")
    require_hash(resolve(config["input_file"]), config["input_sha256"])
    require_hash(resolve(config["native_numeric_parser_file"]), config["native_numeric_parser_sha256"])
    native_path = HERE / "native_scorer_snapshot.py"
    require_hash(native_path, NATIVE_SHA)
    native = load_module("p07_frozen_native_scorer", native_path)
    parser = load_module("p07_frozen_native_parser", resolve(config["native_numeric_parser_file"])).parse_number
    cases = [json.loads(line) for line in resolve(config["input_file"]).read_text().splitlines()]
    ids = [r["case_id"] for r in cases]
    if len(ids) != config["planned"] or len(set(ids)) != len(ids):
        raise ValueError("Frozen cohort is incomplete or duplicated")
    outcomes, texts, statuses = [], [], Counter()
    for case in cases:
        key = hashlib.sha256(case["case_id"].encode()).hexdigest()
        outcome_path = folder / "outcomes" / (key + ".json")
        text = None
        outcome = json.loads(outcome_path.read_text()) if outcome_path.exists() else {"case_id": case["case_id"], "status": "not_dispatched", "delivery_passed": False}
        if outcome["case_id"] != case["case_id"]:
            raise ValueError("Outcome identity mismatch")
        if outcome.get("response_saved"):
            response_path = folder / "responses" / (key + ".json")
            require_hash(response_path, outcome["response_sha256"])
            request_path = folder / "requests" / (key + ".json")
            require_hash(request_path, outcome["request_sha256"])
            request = json.loads(request_path.read_text())
            if request != {"model": config["model"], "messages": case["messages"], **config["generation"]}:
                raise ValueError("Dispatched request differs from frozen inputs/settings")
            text = strict_final(json.loads(response_path.read_text()), parser)
            if (text is not None) != outcome["delivery_passed"]:
                raise ValueError("Raw response disagrees with recorded delivery result")
            if text is not None and parser(text) != outcome["prediction"]:
                raise ValueError("Raw response differs from recorded numerical prediction")
        elif outcome.get("delivery_passed"):
            raise ValueError("A delivered prediction requires a saved raw response")
        statuses[outcome["status"]] += 1
        texts.append(text)
        outcomes.append(outcome)
    # References are opened only after the full prediction lock, complete
    # requests and raw responses have been independently checked above.
    reference_path = resolve(config["scorer_reference_file"])
    require_hash(reference_path, config["scorer_reference_sha256"])
    references = [json.loads(line) for line in reference_path.read_text().splitlines()]
    if [r["case_id"] for r in references] != ids or any(r["task"] != "P07" for r in references):
        raise ValueError("References differ from the fixed ordered full cohort")
    targets = [r["target"] for r in references]
    if any(type(x) not in (int, float) or not math.isfinite(x) for x in targets):
        raise ValueError("Invalid native target")
    metrics = native.outcome_metrics("P07", targets, texts)
    import scipy
    result = {"task_id": "P07", "run_id": config["run_id"], "protocol_variant": config["protocol_variant"],
              "scored_at_pacific": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
              "config_sha256": sha(config_path), "prediction_lock_sha256": sha(folder / "prediction_lock.json"),
              "reference_sha256": config["scorer_reference_sha256"], "native_scorer_sha256": NATIVE_SHA,
              "scipy_version": scipy.__version__, "planned": len(cases), "terminal": len(cases) - statuses["not_dispatched"],
              "metrics": metrics, "statuses": dict(statuses),
              "counts": {key: completion.get(key) for key in ("responses_saved", "delivery_passed", "transport_errors", "http_errors", "response_errors", "truncations", "empty_finals", "refusals", "not_dispatched")},
              "primary_metric": "global native Spearman", "primary_metric_value": metrics["spearman"],
              "full_benchmark_score_defined": metrics["spearman"] is not None,
              "subset_diagnostic_is_full_score": False,
              "failures_retried_or_imputed": False, "historical_run_changed": False,
              "meaning": "Experimental fluorescence outcome agreement for a separately named zero-shot full-sequence Qwen nonthinking scalar condition; no trained head, mechanistic or contamination-free claim"}
    with (folder / "scores.json").open("x") as handle:
        json.dump(result, handle, indent=2, allow_nan=False)
        handle.write("\n")
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    args = ap.parse_args()
    print(json.dumps(score(args.config, args.output), indent=2, allow_nan=False))
