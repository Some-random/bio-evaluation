"""Sealed artificial-score fixtures; no benchmark labels or calls."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("p07_offline_score", HERE / "score.py")
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)


def dump(path, value):
    path.write_text(json.dumps(value, sort_keys=True) + "\n")


class ScoringTests(unittest.TestCase):
    def fixture(self, folder, invalid=False, constant=False):
        for category in ("requests", "responses", "outcomes", "errors"):
            (folder / category).mkdir()
        cases = [{"task_id": "P07", "case_id": "synthetic:" + str(i),
                  "messages": [{"role": "user", "content": "Artificial numeric fixture " + str(i)}]} for i in range(3)]
        inputs = folder / "inputs.jsonl"
        inputs.write_text("".join(json.dumps(r) + "\n" for r in cases))
        refs = folder / "references.jsonl"
        refs.write_text("".join(json.dumps({"task": "P07", "case_id": r["case_id"], "target": i+1}) + "\n" for i, r in enumerate(cases)))
        config = {"task_id": "P07", "split": "official_test", "model": "Qwen/Qwen3.8-27B",
                  "run_id": "synthetic-unit-fixture", "protocol_variant": "SYNTHETIC_ONLY",
                  "planned": 3, "generation": {"synthetic": True}, "input_file": str(inputs), "input_sha256": s.sha(inputs),
                  "native_numeric_parser_file": str(HERE / "native_numeric_parser.py"),
                  "native_numeric_parser_sha256": s.sha(HERE / "native_numeric_parser.py"),
                  "scorer_reference_file": str(refs), "scorer_reference_sha256": s.sha(refs)}
        config_path = folder / "config.json"
        dump(config_path, config)
        dump(folder / "run_manifest.json", {"configuration": config, "config_sha256": s.sha(config_path)})
        for i, case in enumerate(cases):
            key = hashlib.sha256(case["case_id"].encode()).hexdigest()
            req = folder / "requests" / (key + ".json")
            response = folder / "responses" / (key + ".json")
            dump(req, {"model": config["model"], "messages": case["messages"], **config["generation"]})
            valid = not (invalid and i == 2)
            prediction = 4 if constant else (i+1)*2
            dump(response, {"choices": [{"finish_reason": "stop" if valid else "length",
                                        "message": {"content": str(prediction) if valid else ""}}]})
            dump(folder / "outcomes" / (key + ".json"), {"case_id": case["case_id"], "status": "response_saved",
                 "response_saved": True, "response_sha256": s.sha(response), "request_sha256": s.sha(req),
                 "delivery_passed": valid, "prediction": prediction if valid else None})
        files = {str(item.relative_to(folder)): s.sha(item) for category in ("requests", "responses", "outcomes", "errors")
                 for item in (folder / category).iterdir()}
        files["run_manifest.json"] = s.sha(folder / "run_manifest.json")
        dump(folder / "prediction_lock.json", {"files_sha256": files, "config_sha256": s.sha(config_path), "reference_labels_opened": False})
        dump(folder / "completion.json", {"config_sha256": s.sha(config_path), "phase": "benchmark_generation",
             "prediction_lock_sha256": s.sha(folder / "prediction_lock.json")})
        return config_path

    def test_complete_native_spearman(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            result = s.score(self.fixture(folder), folder)
            self.assertEqual(result["primary_metric_value"], 1.0)
            self.assertEqual(result["metrics"]["planned"], 3)
            self.assertTrue(result["full_benchmark_score_defined"])

    def test_failed_slot_never_imputed_or_dropped_from_primary(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            result = s.score(self.fixture(folder, invalid=True), folder)
            self.assertIsNone(result["primary_metric_value"])
            self.assertEqual(result["metrics"]["planned"], 3)
            self.assertEqual(result["metrics"]["parsed"], 2)
            self.assertAlmostEqual(result["metrics"]["spearman_parsed_only"], 1.0)
            self.assertFalse(result["failures_retried_or_imputed"])

    def test_constant_predictions_undefined(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            result = s.score(self.fixture(folder, constant=True), folder)
            self.assertIsNone(result["primary_metric_value"])
            self.assertTrue(result["metrics"]["undefined_constant_or_insufficient"])

    def test_tampered_evidence_rejected_before_reference_open(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            config = self.fixture(folder)
            (folder / "references.jsonl").unlink()
            item = next((folder / "responses").iterdir())
            item.write_text("{}");
            with self.assertRaisesRegex(ValueError, "artifact hash mismatch"):
                s.score(config, folder)

    def test_unsealed_output_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            config = self.fixture(folder)
            (folder / "outcomes" / "extra.json").write_text("{}")
            with self.assertRaisesRegex(ValueError, "Unsealed evidence"):
                s.score(config, folder)

    def test_scores_are_write_once(self):
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            config = self.fixture(folder)
            s.score(config, folder)
            with self.assertRaisesRegex(ValueError, "already exists"):
                s.score(config, folder)

    def test_nonfinite_truncated_reasoning_refusal_and_extra_text_rejected(self):
        parser = s.load_module("test_scalar_parser", HERE / "native_numeric_parser.py").parse_number
        def body(content="1", reason="stop", **message):
            return {"choices": [{"finish_reason": reason, "message": {"content": content, **message}}]}
        self.assertEqual(s.strict_final(body("-1.25e-2"), parser), "-1.25e-2")
        for response in (body("nan"), body(""), body("1", "length"), body("1", reasoning="hidden"),
                         body("1", refusal="declined"), body("Answer: 1"), body("1 and2")):
            self.assertIsNone(s.strict_final(response, parser))


if __name__ == "__main__":
    unittest.main()
