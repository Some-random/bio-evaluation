"""Artificial fixtures test contracts, not biological accuracy."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("p07_prepare", HERE / "prepare.py")
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)


class PreparationTests(unittest.TestCase):
    def row(self):
        seq = "ACDEFGHIKL" * 24
        prompt = p.prompt_for(seq)
        return {"task": "P07", "case_id": "fluorescence:test:0", "source_index": 0,
                "split": "official_released_test", "system": "", "fields": {"sequence": seq, "objective": p.OBJECTIVE},
                "prompt": prompt, "prompt_sha256": p.digest(prompt.encode())}

    def test_full_sequence_and_objective_preserved(self):
        source = self.row()
        result = p.from_test_row(source, 0)
        self.assertEqual(result["messages"][0]["content"], source["prompt"])
        self.assertTrue(result["messages"][0]["content"].endswith("ACDEFGHIKL" * 24))
        self.assertEqual(set(result), {"task_id", "case_id", "messages"})

    def test_extra_target_reference_and_outputs_cannot_enter_request(self):
        source = self.row()
        expected = p.encoded(p.from_test_row(source, 0))
        source.update(target=1234.5, log_fluorescence=-789.0, prior_model_output="MUST NOT ENTER")
        source["fields"].update(target=-34, reference="MUST NOT ENTER")
        self.assertEqual(expected, p.encoded(p.from_test_row(source, 0)))

    def test_missing_sequence_never_reconstructed(self):
        source = self.row()
        del source["fields"]["sequence"]
        with self.assertRaises(KeyError):
            p.from_test_row(source, 0)

    def test_prompt_truncation_detected(self):
        source = self.row()
        source["prompt"] = source["prompt"][:-1]
        with self.assertRaises(ValueError):
            p.from_test_row(source, 0)

    def test_sequence_changes_detected(self):
        source = self.row()
        source["fields"]["sequence"] = source["fields"]["sequence"][:-1]
        with self.assertRaises(ValueError):
            p.from_test_row(source, 0)

    def test_objective_changes_detected(self):
        source = self.row()
        source["fields"]["objective"] += " invented context"
        with self.assertRaises(ValueError):
            p.from_test_row(source, 0)

    def test_source_order_and_identity_required(self):
        with self.assertRaises(ValueError):
            p.from_test_row(self.row(), 1)

    def test_invalid_sequence_not_silently_cleaned(self):
        for seq in (None, "", "AC D", "AcD", "ACD\n", "ACD*", "ACD-123"):
            with self.subTest(seq=seq), self.assertRaises(ValueError):
                p.prompt_for(seq)

    def test_freeze_cannot_overwrite(self):
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp) / "frozen"
            p.freeze(target, b"one")
            p.freeze(target, b"one")
            with self.assertRaises(ValueError):
                p.freeze(target, b"two")
            self.assertEqual(target.read_bytes(), b"one")

    def test_grammar_finite_with_no_unbounded_loop(self):
        import math
        for value in ("0", "-1", "+12", "0.001", "-1.2e+99", "999999999999.999999999999E99"):
            self.assertIsNotNone(re.fullmatch(p.REGEX, value))
            self.assertTrue(math.isfinite(float(value)))
        for value in ("", "nan", "inf", "1e999", "1.2.3", "2 3", "Answer: 2", "1\n", "1." * 300):
            self.assertIsNone(re.fullmatch(p.REGEX, value))

    def test_non_thinking_selected_without_sampling_tuning(self):
        self.assertEqual(p.GENERATION["chat_template_kwargs"], {"enable_thinking": False})
        self.assertEqual({k: p.GENERATION[k] for k in ("temperature", "top_p", "top_k", "seed", "n")},
                         {"temperature": 1.0, "top_p": 0.95, "top_k": 20, "seed": 42, "n": 1})

    def test_pinned_publisher_template_closes_thinking_before_generation(self):
        import jinja2
        template_path = Path("/dfs/scratch0/tchen/models/Qwen3.8-27B/chat_template.jinja")
        raw = template_path.read_bytes()
        self.assertEqual(p.digest(raw), "c3cf9e34abf4f9e36c2d72165aa9c132d3e2a725b6c2586aaa3a8af9d7a81041")
        template = jinja2.Environment().from_string(raw.decode())
        rendered = template.render(messages=[{"role": "user", "content": "Synthetic numeric interface fixture."}],
                                   enable_thinking=False, add_generation_prompt=True)
        # Published source spells separators as escaped newlines. Both raw
        # rendering and an eventual tokenizer preserve close-think ordering.
        self.assertIn("<think>", rendered)
        self.assertIn("</think>", rendered)
        self.assertLess(rendered.rfind("<think>"), rendered.rfind("</think>"))
        self.assertNotIn("Reasoning effort", rendered)


if __name__ == "__main__":
    unittest.main()
