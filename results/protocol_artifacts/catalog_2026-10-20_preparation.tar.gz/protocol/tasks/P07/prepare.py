#!/usr/bin/env python3
"""Freeze a new P07 nonthinking scalar-delivery condition; never dispatch or score.

Only existing, reviewed P07 full-test solver inputs and the official GFP
validation split are used. The interrupted P18 candidate preparation is unrelated.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import pickle
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
MODEL = "Qwen/Qwen3.8-27B"
REVISION = "1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0"
VARIANT = "QWEN_P07_FULL_SEQUENCE_NONTHINKING_FINITE_SCALAR_256_V1"
OBJECTIVE = "Predict the log-fluorescence intensity of this green fluorescent protein variant on the original TAPE/Sarkisyan experimental scale (the log_fluorescence target). Return only one finite numerical value."
REGEX = r"[+-]?[0-9]{1,12}(\.[0-9]{1,12})?([eE][+-]?[0-9]{1,2})?"
GENERATION = {
    "max_tokens": 256, "temperature": 1.0, "top_p": 0.95, "top_k": 20,
    "seed": 42, "n": 1, "chat_template_kwargs": {"enable_thinking": False},
    "structured_outputs": {"regex": REGEX},
}
TEST_INPUTS = ROOT / ".local/remaining_evaluations/extended/data/catalog_extended/P07/model_inputs.jsonl"
TEST_SHA = "d0a9983ffe8d08fd5bb681e1e09defd26e2915947cc4e1a399d5f230d60fd7a4"
TEST_REVIEW = ROOT / "configs/local_extended_p07_review.json"
TEST_REVIEW_SHA = "a15996a5764bfe5f33f84bcec2149624c6fa1ff501d8ca3155667151b3f286fa"
REFERENCES = ROOT / ".local/remaining_evaluations/extended/data/catalog_extended/P07/scorer_references.jsonl"
REFERENCES_SHA = "6646734617ba389e58607a5b3d8e7c03340f8915b6330bdc9f082352ab34d8a3"
VALID_DB = ROOT / ".local/catalog_resume_2026-10-19/development/source/fluorescence_valid.lmdb/data.mdb"
VALID_SHA = "11e17d40cac03f1ecdf297d5e52a164ef61cb69aa673b576d444a4d66740c491"
SELECTION_PREFIX = "p07-nonthinking-finite-scalar-validation-2026-10-20-v1:"
DEVELOPMENT_N = 64
NATIVE_PARSER = ROOT / ".local/catalog_resume_2026-10-19/development/native_numeric_parser.py"
NATIVE_PARSER_SHA = "317c8260921fbe3646c22bf61ee90b188a7f2e63319f2e88dde65ac01a173035"


def stamp():
    return datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def check_file(path, expected):
    raw = Path(path).read_bytes()
    if digest(raw) != expected:
        raise ValueError("Frozen input changed: " + str(path))
    return raw


def encoded(obj):
    return (json.dumps(obj, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()


def freeze(path, raw):
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError("Refusing to overwrite frozen plan file: " + str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as out:
            out.write(raw)
        path.chmod(0o600)


def prompt_for(sequence):
    if not isinstance(sequence, str) or not sequence or any(not "A" <= c <= "Z" for c in sequence):
        raise ValueError("Complete uppercase amino-acid representation required")
    return OBJECTIVE + "\n\nComplete protein sequence:\n" + sequence


def solver_row(case_id, sequence):
    return {"task_id": "P07", "case_id": case_id,
            "messages": [{"role": "user", "content": prompt_for(sequence)}]}


def from_test_row(source, ordinal):
    case_id = "fluorescence:test:" + str(ordinal)
    if (source["task"] != "P07" or source["case_id"] != case_id
            or source["source_index"] != ordinal or source["split"] != "official_released_test"
            or source["system"] != "" or source["fields"]["objective"] != OBJECTIVE):
        raise ValueError("Frozen full-test input contract mismatch")
    seq = source["fields"]["sequence"]
    row = solver_row(case_id, seq)
    prompt = row["messages"][0]["content"]
    if prompt != source["prompt"] or digest(prompt.encode()) != source["prompt_sha256"]:
        raise ValueError("Historical reviewed complete prompt changed")
    return row


def validation_rows():
    # The prior pilot's database is the exact member extracted from the verified
    # official source archive. No test LMDB is opened or extracted here.
    check_file(VALID_DB, VALID_SHA)
    sys.path.insert(0, str(ROOT / ".local/catalog_resume_2026-10-19/development/packages"))
    import lmdb
    env = lmdb.open(str(VALID_DB.parent), readonly=True, lock=False, readahead=False, meminit=False)
    try:
        with env.begin() as tx:
            total = pickle.loads(tx.get(b"num_examples"))
            if total != 5362:
                raise ValueError("Official validation split count changed")
            # Select indices before deserializing any record. No fluorescence,
            # sequence identity, previous output or previous failure informs it.
            chosen = sorted(sorted(range(total), key=lambda i: digest((SELECTION_PREFIX + str(i)).encode()))[:DEVELOPMENT_N])
            selection = {"split": "official_validation", "count": DEVELOPMENT_N,
                         "source_split_count": total, "prefix": SELECTION_PREFIX,
                         "source_indices": chosen, "rule": "Lowest SHA256(prefix + source index), then source order",
                         "sequences_used_for_selection": False, "labels_used_for_selection": False,
                         "model_outputs_used_for_selection": False}
            freeze(HERE / "development_selection.json", encoded(selection))
            rows, lengths = [], []
            for index in chosen:
                obj = pickle.loads(tx.get(str(index).encode()))
                # Access only primary; scorer-only array is neither inspected
                # nor exported. Pickle container deserialization is disclosed.
                sequence = obj["primary"]
                rows.append(solver_row("fluorescence:valid:" + str(index), sequence))
                lengths.append(len(sequence))
            return rows, lengths, selection
    finally:
        env.close()


def make_config(split, rows, review, deps):
    development = split == "official_validation"
    slug = "development" if development else "full_test"
    inputs = HERE / (slug + "_inputs.jsonl")
    freeze(inputs, b"".join(encoded(row) for row in rows))
    review_path = HERE / (slug + "_review.json")
    freeze(review_path, encoded(review))
    parser_path = HERE / "native_numeric_parser.py"
    config = {
        "schema_version": 1, "task_id": "P07", "run_id": "qwen38_27b_p07_" + slug + "_nonthinking_scalar_2026-10-20_v1",
        "protocol_variant": VARIANT, "model": MODEL, "model_revision": REVISION,
        "checkpoint_precision": "bfloat16", "input_file": str(inputs), "input_sha256": digest(inputs.read_bytes()),
        "planned": len(rows), "split": split, "generation": GENERATION,
        "review_file": str(review_path), "review_sha256": digest(review_path.read_bytes()),
        "native_numeric_parser_file": str(parser_path), "native_numeric_parser_sha256": NATIVE_PARSER_SHA,
        "native_numeric_parser_function": "parse_number",
        "files_sha256": {**deps, str(inputs): digest(inputs.read_bytes()), str(review_path): digest(review_path.read_bytes())},
        "development_delivery_only": development, "biological_correctness_scoring": not development,
        "solver_fields": ["native_objective", "complete_sequence"], "solver_tools": [],
        "concurrency": 4, "no_automatic_retries": True,
        "delivery_acceptance": "Every planned development request: one normal stop, one finite native-parsed scalar final, no separate reasoning, no refusal/error/truncation. Entire gate must pass before full test.",
        "changes_from_historical": ["Explicitly disable thinking in the publisher chat template", "Constrain decoding to bounded finite-decimal/exponent grammar", "256 total output tokens instead of old4K or16K reasoning allowance"],
        "unchanged": ["Pinned BF16 checkpoint", "Complete source sequences and exact native objective", "Temperature1/top_p0.95/top_k20/seed42/n1", "One source-order attempt per case", "Native global Spearman target scale"],
        "residual_failure_policy": "Preserve every outcome without retries or imputation. Report all-case valid/invalid/transport/length/empty counts. Full-test primary Spearman only if every planned prediction is finite and nonconstant; paired valid-only Spearman is a separately labelled diagnostic, never a replacement.",
        "test_outcome_tuning": False, "old_runs_replaced": False,
        "runtime_authorization": "Requires separate exact config-hash root grant and pinned shared server identity; preparation is not dispatch evidence",
    }
    if not development:
        config.update(scorer_reference_file=str(REFERENCES), scorer_reference_sha256=REFERENCES_SHA,
                      development_config_file=str(HERE / "development_config.json"),
                      development_config_sha256=digest((HERE / "development_config.json").read_bytes()),
                      native_metric="One global Spearman correlation; no shard-correlation averaging")
    freeze(HERE / (slug + "_config.json"), encoded(config))
    return config


def main():
    raw = check_file(TEST_INPUTS, TEST_SHA)
    prior_review = json.loads(check_file(TEST_REVIEW, TEST_REVIEW_SHA))
    parser_bytes = check_file(NATIVE_PARSER, NATIVE_PARSER_SHA)
    freeze(HERE / "native_numeric_parser.py", parser_bytes)
    rows = [from_test_row(json.loads(line), i) for i, line in enumerate(raw.splitlines())]
    ids = [r["case_id"] for r in rows]
    if len(rows) != 27217 or ids != prior_review["approved_case_ids"] or prior_review["held_cases"]:
        raise ValueError("Full reviewed test cohort changed")
    dev, dev_lengths, selection = validation_rows()
    deps = {str(HERE / "prepare.py"): digest(Path(__file__).read_bytes()),
            str(HERE / "native_numeric_parser.py"): NATIVE_PARSER_SHA,
            str(TEST_INPUTS): TEST_SHA, str(TEST_REVIEW): TEST_REVIEW_SHA, str(VALID_DB): VALID_SHA}
    basis = {"task_id": "P07", "input_review_only": True,
             "basis": "P07 permissible official GFP fluorescence outcome-prediction scope; exact objective and complete sequences. The P18 interrupted candidate review is unrelated and remains held.",
             "reference_fields_supplied": False, "selection_based_on_model_outputs": False}
    dev_cfg = make_config("official_validation", dev, {**basis, "approved_case_ids": [r["case_id"] for r in dev], "held_cases": [], "development_delivery_only": True}, deps)
    full_cfg = make_config("official_test", rows, {**basis, "approved_case_ids": ids, "held_cases": [],
                                                  "historical_review_file": str(TEST_REVIEW), "historical_review_sha256": TEST_REVIEW_SHA}, deps)
    receipt = {"updated_at_pacific": stamp(), "stage": "frozen_prepared_waiting_central_endpoint_authorization",
               "task_id": "P07", "new_inference_calls": 0, "planned_full_test": len(rows), "planned_development": len(dev),
               "validation_sequence_lengths": {"min": min(dev_lengths), "max": max(dev_lengths)},
               "full_test_sequence_lengths": {"min": min(len(r["messages"][0]["content"].split("\n")[-1]) for r in rows),
                                              "max": max(len(r["messages"][0]["content"].split("\n")[-1]) for r in rows)},
               "validation_fields_accessed": ["primary"], "validation_container_deserialization": "Official pickle records include scorer-only fields in memory; only primary is accessed/exported, targets never enter requests or gate scoring",
               "validation_source_member_sha256": VALID_SHA, "source_archive_sha256": "20c9d114234a5136c4087920480e7fa2d586a653061f0cd141f626a984ede8bd",
               "development_selection_sha256": digest((HERE / "development_selection.json").read_bytes()),
               "development_config_sha256": digest((HERE / "development_config.json").read_bytes()),
               "full_test_config_sha256": digest((HERE / "full_test_config.json").read_bytes()),
               "historical_generations_preserved": True, "previous_failed_twelve_case_pilot_preserved": True,
               "biological_correctness_not_assessed": True, "benchmark_ready": False,
               "next_action": "Run synthetic decoder checks and64fixed official-validation delivery requests only after exact centralized endpoint authorization; fulltest remains gated"}
    # This status is a current planning record, not live execution evidence.
    (HERE / "preparation_status.json").write_bytes(encoded(receipt))
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
