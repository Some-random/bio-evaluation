"""Materialize exact five reviewed T3 inputs and opaque isolated scorer copies."""
import csv
from datetime import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
REVIEW = HERE.parent / 'remaining_scope_review_v2'
DATA = ROOT / '.local/source_recovery_round2_2026-10-19/pfarena/authenticated/raw/T3_anchor_informed_multi_mutant_ranking'
CODE = ROOT / '.local/source_recovery_round2_2026-10-19/pfarena/official_code/code'
from input_contract import AMINO_ACIDS, CONDITION, validate_input_context


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def rel(path): return str(Path(path).resolve().relative_to(ROOT))
def require(ok, message):
    if not ok: raise ValueError(message)
def save(name, value):
    with (HERE/name).open('x') as stream: json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False);stream.write('\n')


def main():
    require(sha(REVIEW/'input_review.json') == '1255896ad57e97dc1ae01f7c8384fef280152f8d37f565783d173d668df81699', 'Independent exact5 review changed')
    evidence = json.loads((REVIEW/'input_review.json').read_text())
    require(sha(REVIEW/'reviewed5_input_projection.jsonl') == evidence['reviewed5_input_projection_sha256'], 'Reviewed input projection changed')
    contexts = [json.loads(line) for line in (REVIEW/'reviewed5_input_projection.jsonl').read_text().splitlines()]
    allowed_ids = [row['case_id'] for row in contexts]
    expected_pdbs = {'2AMI','2KXD','2M8U','2ROT','2RRT'}
    require(len(contexts) == 5 and {row['PDB_id'] for row in evidence['cases']} == expected_pdbs, 'Exact5 cohort differs')
    reviews = {row['case_id']: row for row in evidence['cases']}
    old_review = json.loads((HERE.parent/'execution_preparation_v1/input_review.json').read_text())
    require(not set(allowed_ids) & set(old_review['approved_case_ids']), 'Completed8 overlap')
    adapter_path = HERE.parent/'engineering_20261020/ranking_adapter.py'
    require(sha(adapter_path) == '2bed8056656837c637a9a34f25fdce05b75b29ca874a8d3e0a5e3e5804914654', 'Native adapter changed')
    spec=importlib.util.spec_from_file_location('_p21_native_stability5_input_adapter', adapter_path)
    native=importlib.util.module_from_spec(spec);sys.modules[spec.name]=native;spec.loader.exec_module(native)
    native.native_builders()
    metadata_path = DATA/'assay.csv'
    require(sha(metadata_path) == old_review['source_metadata_sha256'], 'Native metadata changed')
    metadata = {row['assay_id']: row for row in csv.DictReader(metadata_path.open()) if 'P21::'+row['assay_id'] in set(allowed_ids)}
    require(len(metadata) == 5, 'Selected source metadata count differs')
    cases=[]; references=[]
    reference_root=HERE/'scorer_only/reference_tables';reference_root.mkdir(parents=True, mode=0o700)
    allowed_assays={case_id.removeprefix('P21::') for case_id in allowed_ids}
    for context in contexts:
        validate_input_context(context)
        case_id=context['case_id']; review=reviews[case_id]; row=metadata[review['assay_id']]
        require(context['wildtype_sequence'] == row['wildtype_sequence'].strip() and context['anchor_mutant'] == row['anchor_mutant'].strip() and context['anchor_DMS_score'] == row['anchor_DMS_score'].strip(), 'Native full sequence or legitimate anchor changed')
        require((row['primary_task_class'],row['fitness_type'],row['readout_subclass']) == ('stability','stability','folding_free_energy_stability_readout'), 'Native objective changed')
        projected = {key: row[key] for key in native.CONTEXT_FIELDS}
        messages = native.build_messages(projected, context['candidate_ids'], allowed_assays, set(), anchor_mutant=context['anchor_mutant'], anchor_dms_score=context['anchor_DMS_score'])
        cases.append({'task_id':'P21','case_id':case_id,'messages':messages})
        source=ROOT/review['reference_file'];require(sha(source)==review['reference_sha256'],'Reference source changed')
        # Opaque exact-byte copy: no candidate DMS_score value is accessed,
        # parsed numerically, compared or exposed during preparation.
        destination=reference_root/review['assay_id']/'anchor_successor.csv';destination.parent.mkdir(mode=0o700)
        shutil.copyfile(source,destination);destination.chmod(0o400)
        require(sha(destination)==sha(source),'Opaque scorer copy differs')
        identifiers=[(record['mutant'].strip(),record['candidate_group_id'].strip()) for record in csv.DictReader(destination.open())]
        require([value for value,_ in identifiers] == context['candidate_ids'], 'Native candidate ordering differs')
        groups={group for _,group in identifiers if group};require(len(groups)==1,'Native group differs')
        references.append({'case_id':case_id,'assay_id':review['assay_id'],'native_truth_id':next(iter(groups)),
            'target_path':rel(destination),'sha256':sha(destination),'original_source_path':rel(source),
            'original_source_sha256':sha(source),'publisher_digest_verified_at_acquisition':True,
            'protected_DMS_score_fields_accessed_in_preparation':False})
    synthetic=[]; synthetic_contexts=[]
    for index,count in enumerate([19,38,56],1):
        sequence=AMINO_ACIDS*4;anchor='A1C'; candidates=[]
        for position in range(2,count+2):
            before=sequence[position-1];after=AMINO_ACIDS[(AMINO_ACIDS.index(before)+1)%len(AMINO_ACIDS)]
            candidates.append(anchor+'+'+before+str(position)+after)
        context={'case_id':'P21::stability5_synthetic_delivery_'+str(index).zfill(2),'wildtype_sequence':sequence,'sequence_length':len(sequence),'candidate_ids':candidates,'anchor_mutant':anchor,'anchor_DMS_score':'0.0'}
        validate_input_context(context)
        assay='SYNTHETIC_T3_STABILITY5_DELIVERY_'+str(index)
        row={'assay_id':assay,'uniprot_id':'ARTIFICIAL_ONLY','primary_task_class':'stability','fitness_type':'stability','readout_subclass':'synthetic_interface_no_real_measurements','wildtype_sequence':sequence,'sequence_length':str(len(sequence))}
        synthetic.append({'task_id':'P21','case_id':context['case_id'],'messages':native.build_messages(row,candidates,{assay},set(),anchor_mutant=anchor,anchor_dms_score='0.0')})
        synthetic_contexts.append(context)
    for phase,phase_cases,phase_contexts in [('benchmark',cases,contexts),('development',synthetic,synthetic_contexts)]:
        with (HERE/(phase+'_inputs.jsonl')).open('x') as stream:
            for case in phase_cases:stream.write(json.dumps(case,sort_keys=True,allow_nan=False)+'\n')
        save(phase+'_delivery_contexts.json',{'task_id':'P21','cases':phase_contexts,'reference_labels_included':False,'legitimate_native_anchor_scores_included':True,'candidate_outcome_scores_included':False})
    save('input_review.json',{'task_id':'P21','condition':CONDITION,'approved_case_ids':allowed_ids,'cases':evidence['cases'],'held_cases':[],
        'native_panel_assays':67,'reviewed_assays':5,'remaining_input_unreviewed':54,'completed8_excluded':old_review['approved_case_ids'],
        'independent_review_path':rel(REVIEW/'input_review.json'),'independent_review_sha256':sha(REVIEW/'input_review.json'),
        'no_P19_admission_inherited':True,'P20_interrupted_action_reopened':False,'all_native_assays_approved':False,
        'candidate_outcomes_in_inputs':False,'native_messages_preserved':True})
    save('development_review.json',{'task_id':'P21','approved_case_ids':[case['case_id'] for case in synthetic],'held_cases':[],'synthetic_only':True,'biological_correctness_assessed':False})
    save('scorer_only_manifest.json',{'task_id':'P21','condition':CONDITION,'cases':references,'source_dataset_revision':'5be3973dd45a9d7d33572f016be18f8ef941f2ff','reference_labels_isolated':True,'opaque_reference_copies_physically_separate_from_solver_projection':True,
        'native_scorer_file':rel(CODE/'evaluation/full.py'),'native_scorer_sha256':sha(CODE/'evaluation/full.py'),
        'native_router_file':rel(CODE/'router.py'),'native_router_sha256':sha(CODE/'router.py'),
        'native_parser_file':rel(CODE/'llm/infer_api_mutation.py'),'native_parser_sha256':sha(CODE/'llm/infer_api_mutation.py'),
        'native_metrics':['spearman','NDCG','NMS@5','Recall@5'],'native_panel_assays':67,'native_strict_coverage':True,'missing_query_random_fallback_enabled':False})
    save('input_materialization_receipt.json',{'at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),'task_id':'P21','condition':CONDITION,'stage':'separate5_native_messages_and_synthetic3_prepared_no_dispatch','reviewed_assays':5,'candidate_count_total':sum(len(row['candidate_ids']) for row in contexts),'candidate_counts':[len(row['candidate_ids']) for row in contexts],
        'native_fragment_lengths':[row['sequence_length'] for row in contexts],
        'opaque_scorer_copies_physically_separate':True,'candidate_outcome_fields_accessed':False,'model_calls':0,'GPU_allocations':0})
    print(json.dumps({'native_messages':5,'synthetic_messages':3,'native_candidates':114,'model_calls':0,'GPU_allocations':0}))


if __name__=='__main__':main()
