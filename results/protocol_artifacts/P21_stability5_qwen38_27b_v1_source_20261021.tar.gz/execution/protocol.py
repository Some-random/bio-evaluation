"""Separate exact5 P21 phase order, scope and denominator guards."""
GENERATION_OUTPUT_TOKENS = 16384
SCOPE = 'synthetic3_then_reviewed_eukaryote_stability5_full_permutation_once_then_native_T3_score'
CONDITION = 'PFARENA_T3_REVIEWED_EUKARYOTE_DOMAIN_STABILITY5_FULL_PERMUTATION_V1'


def require_development(done, config_sha, generation):
    if (done.get('task_id') != 'P21' or done.get('config_sha256') != config_sha or
            done.get('generation') != generation or done.get('biological_correctness_assessed') is not False):
        raise ValueError('Development differs from the separate stability5 condition')
    if not done.get('delivery_passed_all') or any(done.get(key) != 3 for key in ['planned','terminal','responses_saved','delivery_passed']):
        raise ValueError('Exactly three actual synthetic delivery cases must pass')
    for key in ['transport_errors','http_errors','response_errors','truncations','empty_finals','refusals','reasoning_present']:
        if done.get(key) != 0:
            raise ValueError('Development failure blocks every benchmark call')
    if not done.get('prediction_lock_sha256'):
        raise ValueError('Actual immutable development prediction lock required')


def require_complete_benchmark(done, config_sha, generation):
    if (done.get('task_id') != 'P21' or done.get('config_sha256') != config_sha or
            done.get('generation') != generation or done.get('planned') != 5 or
            done.get('terminal') != 5 or not done.get('prediction_lock_sha256')):
        raise ValueError('Only a complete sealed exact5-case condition may reach scoring')
    return {'score_may_be_attempted': True, 'full_native67_complete': False}


def run_order(plan, run_development, run_benchmark, run_score):
    development = run_development()
    require_development(development, plan['development_config_sha256'], plan['generation'])
    benchmark = run_benchmark(development)
    require_complete_benchmark(benchmark, plan['benchmark_config_sha256'], plan['generation'])
    score = run_score(benchmark)
    if (score.get('planned_assays') != 5 or score.get('native_panel_assays') != 67 or
            score.get('full_native_benchmark_complete') is not False or
            score.get('native_scoring_status') not in {'completed_native_scored_reviewed_subset','undefined_native_strict_coverage_failure'}):
        raise ValueError('Native score must retain the separate5/67 subset qualification')
    return {'development':development,'benchmark':benchmark,'score':score,
            'reviewed5_condition_terminal':True,'full_native67_complete':False,'full_catalog_complete':False}


def validate_admission_data(admission, plan_sha, scope_sha):
    if (admission.get('admitted') is not True or admission.get('task_id') != 'P21' or
            admission.get('scope') != SCOPE or admission.get('condition') != CONDITION or
            admission.get('plan_sha256') != plan_sha or admission.get('source_scope_sha256') != scope_sha or
            admission.get('gpu_count') != 1 or admission.get('project_gpu_ceiling') != 8 or
            admission.get('allow_benchmark_only_after_development_gate') is not True):
        raise PermissionError('Exact independent plan-bound P21 admission required')
