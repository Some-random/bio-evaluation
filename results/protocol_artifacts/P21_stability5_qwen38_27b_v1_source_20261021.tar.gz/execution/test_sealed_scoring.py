"""Complete artificial five-assay scorer integration and no-repeat boundary."""
import csv
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from input_contract import CONDITION
from test_contracts import fixture
import scorer


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True) + '\n')


class SealedScoring(unittest.TestCase):
    def synthetic_run(self, root):
        run=root/'run';run.mkdir()
        native=scorer.ROOT/'.local/source_recovery_round2_2026-10-19/pfarena/official_code/code'
        cases=[];contexts=[];refs=[];locks={}
        for index in range(5):
            case,context=fixture(6)
            case_id='P21::ARTIFICIAL_SCORER_'+str(index)
            case['case_id']=context['case_id']=case_id
            cases.append(case);contexts.append(context)
            outcome=run/'outcomes'/(hashlib.sha256(case_id.encode()).hexdigest()+'.json')
            response=run/'responses'/outcome.name
            write(outcome,{'case_id':case_id,'status':'response_saved','delivery_passed':True})
            write(response,{'choices':[{'message':{'content':json.dumps({'ranking':context['candidate_ids']})},'finish_reason':'stop'}]})
            for path in [outcome,response]:locks[str(path.relative_to(run))]=scorer.sha(path)
            target=root/'artificial_references'/str(index)/'anchor_successor.csv';target.parent.mkdir(parents=True)
            with target.open('w') as handle:
                writer=csv.DictWriter(handle,fieldnames=['mutant','DMS_score','candidate_group_id']);writer.writeheader()
                for rank,mutant in enumerate(context['candidate_ids']):writer.writerow({'mutant':mutant,'DMS_score':6-rank,'candidate_group_id':'artificial-group-'+str(index)})
            refs.append({'case_id':case_id,'assay_id':'artificial-'+str(index),'native_truth_id':'artificial-group-'+str(index),'target_path':str(target),'sha256':scorer.sha(target)})
        input_path=root/'inputs.jsonl';input_path.write_text(''.join(json.dumps(case)+'\n' for case in cases))
        context_path=root/'contexts.json';write(context_path,{'cases':contexts})
        review_path=root/'review.json';write(review_path,{'approved_case_ids':[case['case_id'] for case in cases]})
        reference=root/'references.json'
        manifest={'task_id':'P21','condition':CONDITION,'missing_query_random_fallback_enabled':False,
            'opaque_reference_copies_physically_separate_from_solver_projection':True,'cases':refs}
        for kind,path in [('native_scorer',native/'evaluation/full.py'),('native_router',native/'router.py'),('native_parser',native/'llm/infer_api_mutation.py')]:manifest.update({kind+'_file':str(path),kind+'_sha256':scorer.sha(path)})
        write(reference,manifest)
        config=root/'config.json';write(config,{'task_id':'P21','condition':CONDITION,'split':'reviewed_benchmark_subset','planned':5,
            'files_sha256':{},'input_file':str(input_path),'input_sha256':scorer.sha(input_path),
            'delivery_context_file':str(context_path),'delivery_context_sha256':scorer.sha(context_path),
            'review_file':str(review_path),'review_sha256':scorer.sha(review_path),'scorer_only_manifest_sha256':scorer.sha(reference)})
        lock_path=run/'prediction_lock.json';write(lock_path,{'config_sha256':scorer.sha(config),'reference_labels_opened':False,'files_sha256':locks})
        completion=run/'completion.json';write(completion,{'task_id':'P21','config_sha256':scorer.sha(config),'planned':5,'terminal':5,
            'prediction_lock_sha256':scorer.sha(lock_path),'transport_or_response_errors':0,'empty_finals':0,'truncations':0})
        return run,config,reference,completion

    def test_complete_artificial_five_score_once_then_second_attempt_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);run,config,reference,_=self.synthetic_run(root)
            output=run/'scores.json';scorer.score(run,config,reference,output)
            result=json.loads(output.read_text())
            self.assertEqual(result['planned_assays'],5)
            self.assertEqual(result['strict_delivery_passed'],5)
            for metric in ['spearman','NDCG','NMS@5','Recall@5']:self.assertAlmostEqual(result['native_metrics'][metric],1.0)
            self.assertFalse(result['full_native_benchmark_complete'])
            with self.assertRaises(FileExistsError):scorer.score(run,config,reference,run/'replacement_score.json')
            self.assertFalse((run/'replacement_score.json').exists())

    def test_partial_seal_blocks_before_any_reference_or_attempt_access(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);run,config,reference,completion=self.synthetic_run(root)
            data=json.loads(completion.read_text());data['terminal']=4;write(completion,data)
            reference.unlink()
            with self.assertRaises(ValueError):scorer.score(run,config,reference,run/'scores.json')
            self.assertFalse((run/'native_scoring_attempt.json').exists())


if __name__=='__main__':unittest.main()
