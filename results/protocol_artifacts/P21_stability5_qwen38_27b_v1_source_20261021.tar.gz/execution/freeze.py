"""Freeze separate exact5 T3 condition; no model calls or runtime admission."""
import copy
from datetime import datetime
import json
from pathlib import Path
import sys
from zoneinfo import ZoneInfo

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
sys.path.insert(0,str(HERE))
import protocol
import runner
import worker
from input_contract import BASE_GENERATION, canonical_sha256


def read(path):return json.loads(Path(path).read_text())


def main():
    if (HERE/'plan.json').exists():raise FileExistsError('Frozen plans cannot be overwritten')
    old=HERE.parent/'execution_preparation_v1'
    previous=read(old/'plan.json')
    if worker.sha(old/'plan.json')!='d2332d4d29c9bce721f7ef630abf8cf1ff8e70a736acf3adfd188fd9a02bf9dc':raise ValueError('Completed8 plan changed')
    cpu=read(HERE/'CPU_validation.json');terminal=read(HERE/'CPU_terminal.json')
    if cpu.get('checks_passed')!=13 or cpu.get('model_calls')!=0 or cpu.get('GPU_allocations')!=0 or terminal.get('State')!='COMPLETED' or terminal.get('ExitCode')!='0:0':raise ValueError('Actual separate5 CPU validation is not complete')
    pins={}
    def pin(path,expected=None):
        path=Path(path);digest=worker.sha(path)
        if expected is not None and digest!=expected:raise ValueError('Pinned source/runtime changed: '+str(path))
        pins[str(path)]=digest
        return digest
    for name,digest in previous['frozen_files_sha256'].items():
        if not name.startswith(str(old)):pin(name,digest)
    pin(old/'plan.json')
    for path in HERE.glob('*.py'):pin(path)
    for name in ['CPU_plan.json','CPU_validation.json','CPU_terminal.json','CPU.sbatch','CPU_submission_receipt.json',
                 'input_materialization_receipt.json','input_review.json','development_review.json','scorer_only_manifest.json',
                 'development_inputs.jsonl','benchmark_inputs.jsonl','development_delivery_contexts.json','benchmark_delivery_contexts.json']:
        pin(HERE/name)
    independent=HERE.parent/'remaining_scope_review_v2'
    for name in ['input_review.json','scope_before_input_access.json','all67_coverage_ledger.json','independent_metadata_code_review_p05_scope_20261021.json','source_checks/rcsb_6_entry_metadata.json','source_checks/rcsb_acquisition_receipt.json']:
        pin(independent/name)
    manifest=read(HERE/'scorer_only_manifest.json')
    for row in manifest['cases']:pin(ROOT/row['target_path'],row['sha256'])
    for kind in ['native_scorer','native_router','native_parser']:pin(ROOT/manifest[kind+'_file'],manifest[kind+'_sha256'])
    review=read(HERE/'input_review.json');cases=review['cases']
    if (len(cases)!=5 or len(review['approved_case_ids'])!=5 or len(review['completed8_excluded'])!=8 or
            review['remaining_input_unreviewed']!=54 or {row['PDB_id'] for row in cases}!={'2AMI','2KXD','2M8U','2ROT','2RRT'}):raise ValueError('Exact independent5 source scope differs')
    scope={'task_id':'P21','condition':protocol.CONDITION,'approved':5,'native_panel':67,'remaining_unadmitted':54,
        'completed8_excluded':8,'outside_this_condition':62,'approved_case_ids':review['approved_case_ids'],
        'independent_input_review_sha256':worker.sha(independent/'input_review.json'),
        'no_P19_admission_inherited':True,'no_P20_interrupted_action_reopened':True,
        'all_candidate_IDs_full_native_sequences_and_legitimate_anchor_context_preserved':True,
        'protected_candidate_scores_in_solver_inputs':False,'opaque_scorer_copies_physically_separate':True,
        'new_head_training':False,'full_native_benchmark_complete':False,'full_catalog_complete':False,
        'source_backgrounds':'Algal centrin, social amoeba MlcC, frog calmodulin and two chicken-spectrin-derived chimeric domains. Native fragments retained; not asserted complete unmodified PDB chains.',
        'prospective_output_constraint':'Exact native candidate enum and mandatory full-permutation prefix mask; every ranking order retained; finite EOS-only terminal retirement.'}
    worker.save(HERE/'source_scope.json',scope);pin(HERE/'source_scope.json')
    differences=['Separate independent5/67 eukaryote isolated-domain stability subset; excludes completed8 and all54 unreviewed inputs',
        'Native source backgrounds include two chicken-spectrin-derived chimeras and a calmodulin background; native65-72-like short fragments are preserved exactly (actual lengths67-72)',
        'Pinned BF16 Qwen3.8-27B; nonthinking uniform16384 output; one seeded response per case; unchanged native prompts and T3 metrics',
        'Dedicated vLLM0.32 legacyV1 runtime; exact candidate enum plus mandatory full-permutation mask; all ranking orders remain possible',
        'Three artificial task-specific delivery checks; no development biological correctness scoring',
        'Opaque official reference copies physically separated from solver inputs; exclusive native-scoring receipt after complete immutable prediction seal']
    local_code={str(path):worker.sha(path) for path in HERE.glob('*.py')}
    for phase,count in [('development',3),('benchmark',5)]:
        rows=[json.loads(line) for line in (HERE/(phase+'_inputs.jsonl')).read_text().splitlines()]
        contexts=read(HERE/(phase+'_delivery_contexts.json'))['cases']
        if len(rows)!=count or [row['case_id'] for row in rows]!=[row['case_id'] for row in contexts]:raise ValueError('Input/context count/order differs')
        review_path=HERE/('input_review.json' if phase=='benchmark' else 'development_review.json')
        config={'schema_version':1,'task_id':'P21','condition':protocol.CONDITION,'model':previous['model'],'model_revision':previous['model_revision'],
            'run_id':'qwen38_27b_p21_'+('stability5' if phase=='benchmark' else 'stability5_synthetic3')+'_full_permutation16k_2026-10-21_v1',
            'generation':runner.GENERATION,'planned':count,'split':'reviewed_benchmark_subset' if phase=='benchmark' else 'synthetic_development',
            'input_file':str(HERE/(phase+'_inputs.jsonl')),'input_sha256':worker.sha(HERE/(phase+'_inputs.jsonl')),
            'review_file':str(review_path),'review_sha256':worker.sha(review_path),
            'delivery_context_file':str(HERE/(phase+'_delivery_contexts.json')),'delivery_context_sha256':worker.sha(HERE/(phase+'_delivery_contexts.json')),
            'files_sha256':local_code,'native_prompt_preserved':True,'all_original_sequences_preserved':True,
            'base_generation_sha256':canonical_sha256(BASE_GENERATION),
            'case_bindings':{case['case_id']:{'case_sha256':canonical_sha256(case),'context_sha256':canonical_sha256(context),'base_generation_sha256':canonical_sha256(BASE_GENERATION)} for case,context in zip(rows,contexts)},
            'material_differences':differences}
        if phase=='benchmark':config.update(native_panel_assays=67,full_native_benchmark_complete=False,
            development_config_sha256=worker.sha(HERE/'development_config.json'),
            scorer_only_manifest_path=str(HERE/'scorer_only_manifest.json'),scorer_only_manifest_sha256=worker.sha(HERE/'scorer_only_manifest.json'))
        worker.save(HERE/(phase+'_config.json'),config);runner.load_contract(HERE/(phase+'_config.json'));pin(HERE/(phase+'_config.json'))
    batch=(old/'worker.sbatch').read_text().replace(str(old),str(HERE)).replace('bio-p21-permutation-v1','bio-p21-stability5-v1')
    (HERE/'worker.sbatch').write_text(batch);pin(HERE/'worker.sbatch')
    keep=['model','model_revision','model_directory','base_runtime','cuda_overlay','runtime_common','checkpoint_audit',
        'runtime_package_installation','vetted_V06_infrastructure_version','vetted_V06_plan_sha256','base_archive_contains_vllm',
        'pinned_install_before_private_exec_and_GPU_guard_required','runtime_version','vetted_V06_worker',
        'project_gpu_audit_helper','project_gpu_audit_helper_sha256','GPU_accounting_scope']
    plan={key:copy.deepcopy(previous[key]) for key in keep}
    delegation=ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review_resume_v2.json';pin(delegation)
    plan.update(created_at_pacific=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),task_id='P21',owner='/root/p21_remaining_review',
        scope=protocol.SCOPE,condition=protocol.CONDITION,planned=5,synthetic_development_planned=3,native_panel_assays=67,
        remaining_unadmitted_assays=54,completed8_excluded=8,outside_this_condition=62,source_scope_sha256=worker.sha(HERE/'source_scope.json'),
        delegation_path=str(delegation),delegation_sha256=worker.sha(delegation),material_differences=differences,
        generation=runner.GENERATION,endpoint='http://127.0.0.1:8425/v1',context_limit=65536,gpus_requested=1,tensor_parallel_size=1,dtype='bfloat16',total_project_gpu_ceiling=8,
        development_config=str(HERE/'development_config.json'),development_config_sha256=worker.sha(HERE/'development_config.json'),
        benchmark_config=str(HERE/'benchmark_config.json'),benchmark_config_sha256=worker.sha(HERE/'benchmark_config.json'),
        runner=str(HERE/'runner.py'),scorer=str(HERE/'scorer.py'),scorer_only_manifest=str(HERE/'scorer_only_manifest.json'),runtime_root=str(HERE/'runtime'),
        mandatory_model_runner='legacy_V1_explicit',custom_logits_processor='p21_permutation_logits:P21PermutationLogitsProcessor',plugin_sha256=worker.sha(HERE/'p21_permutation_logits.py'),
        phase_policy={'development_attempts':3,'benchmark_attempts_maximum':5,'concurrency':1,'uniform_output_tokens':16384,'development_must_pass_all':True,
            'benchmark_grant_after_passing_actual_development_lock':True,'native_scoring_after_complete5_prediction_lock_only':True,'sole_scoring_attempt':True,'automatic_or_selective_retries':False,'automatic_resume':False},
        reference_access='No target scores in solver projections. Isolated official reference bytes are copied and hashed opaquely before generation; numerical native candidate score access only after a complete sealed exact5 prediction lock and an exclusive scorer-attempt receipt. Native anchor score is legitimate T3 input.',
        full_native67_complete=False,full_catalog_complete=False,runtime_admission_granted=False,submission_by_preparation=False,new_model_calls=0,new_GPU_allocations=0,frozen_files_sha256=pins)
    worker.save(HERE/'plan.json',plan);digest=worker.sha(HERE/'plan.json');(HERE/'plan.sha256').write_text(digest+'\n');worker.validate_plan(HERE/'plan.json',digest)
    worker.save(HERE/'admission_NOT_GRANTED_template.json',{'admitted':False,'task_id':'P21','scope':protocol.SCOPE,'condition':protocol.CONDITION,'plan_sha256':digest,'source_scope_sha256':plan['source_scope_sha256'],
        'gpu_count':1,'project_gpu_ceiling':8,'allow_benchmark_only_after_development_gate':True,'issuer':None,'delegation_sha256':plan['delegation_sha256'],'gpu_audit_receipt':None,'gpu_audit_receipt_sha256':None})
    worker.save(HERE/'freeze_receipt.json',{'at_pacific':plan['created_at_pacific'],'plan_sha256':digest,'dependency_pins':len(pins),'reviewed_assays':5,'completed8_excluded':8,'native_assays':67,'remaining_input_unreviewed':54,
        'complete_native_messages_sequences_candidates_anchors_and_metric_formulas_preserved':True,'candidate_outcome_fields_accessed':False,'runtime_admission':False,'model_calls':0,'GPU_allocations':0})
    print(json.dumps({'plan_sha256':digest,'pins':len(pins),'admitted':False,'model_calls':0,'GPU_allocations':0}))


if __name__=='__main__':main()
