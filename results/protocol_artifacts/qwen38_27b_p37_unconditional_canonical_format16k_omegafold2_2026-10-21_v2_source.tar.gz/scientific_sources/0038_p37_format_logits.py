"""Dedicated source-supported legacy vLLM0.32 adapter; no model loading."""
import importlib.metadata
import os
from pathlib import Path

from vllm.v1.sample.logits_processor import AdapterLogitsProcessor
from bound_request import PROMPTS, digest
from protein_language import CONDITION, RequestConstraint, TokenVocabulary

TOKENIZER = Path('/dfs/scratch0/tchen/models/Qwen3.8-27B/tokenizer.json')
TOKENIZER_SHA256 = '0997f410c57a1f4e53b09e4be8f4a172d90edd9564368fb0847030937229b9f3'
EOS_IDS = {248044, 248046}
ARG_KEYS = {'p37_format_condition', 'p37_phase', 'p37_prompt_sha256', 'p37_output_tokens'}


def validate_request_params(params):
    args = params.extra_args
    if (not isinstance(args, dict) or set(args) != ARG_KEYS
            or args['p37_format_condition'] != CONDITION
            or args['p37_phase'] not in PROMPTS
            or args['p37_prompt_sha256'] not in {digest(p) for p in PROMPTS[args['p37_phase']]}
            or args['p37_output_tokens'] != 16384
            or getattr(params, 'max_tokens', None) != 16384
            or getattr(params, 'n', 1) != 1):
        raise ValueError('Exact dedicated P37 prompt, phase and uniform16K budget required')
    return 16384


class P37FormatLogitsProcessor(AdapterLogitsProcessor):
    @classmethod
    def validate_params(cls, params):
        validate_request_params(params)

    def __init__(self, vllm_config, device, is_pin_memory):
        if (importlib.metadata.version('vllm') != '0.32.0'
                or os.environ.get('VLLM_USE_V2_MODEL_RUNNER') != '0'
                or vllm_config.speculative_config is not None
                or Path(vllm_config.model_config.model).resolve() != TOKENIZER.parent.resolve()):
            raise ValueError('Pinned checkpoint and explicit nonspeculative legacy V1 required')
        super().__init__(vllm_config, device, is_pin_memory)
        self.vocabulary = TokenVocabulary.from_checkpoint_tokenizer(TOKENIZER, TOKENIZER_SHA256, EOS_IDS)

    def is_argmax_invariant(self):
        return False

    def apply(self, logits):
        if set(self.req_info) != set(range(logits.shape[0])):
            raise ValueError('Every active P37 row requires independent constrained state')
        return super().apply(logits)

    def new_req_logits_processor(self, params):
        return RequestConstraint(self.vocabulary, validate_request_params(params))
