"""Neutral finite-language/budget tests; no biological cases or model calls."""
import itertools
import unittest

from protein_language import (AMINO_ACIDS, CLOSE, OPEN, ConstraintError,
                              ProteinLanguage, RequestConstraint, State,
                              TokenVocabulary, parse_final)


def vocabulary(extra=()):
    pieces = {byte: bytes([byte]) for byte in sorted(set(OPEN + CLOSE + AMINO_ACIDS.encode()))}
    pieces.update({300 + i: piece for i, piece in enumerate(extra)})
    return TokenVocabulary(pieces, {500, 501}, 512)


def segmentation(text, pieces):
    """All tokenizations for short neutral fixtures, not just canonical BPE."""
    if not text:
        yield []
    for token, piece in pieces.items():
        if text.startswith(piece):
            for tail in segmentation(text[len(piece):], pieces):
                yield [token, *tail]


class LanguageChecks(unittest.TestCase):
    def test_exact_nonempty_language_and_no_noise(self):
        self.assertEqual(parse_final('<protein>AC</protein>'), 'AC')
        for text in ['<protein></protein>', '<protein>AX</protein>', '<protein>Ac</protein>',
                     ' <protein>AC</protein>', '<protein>AC</protein>\n',
                     '<protein>AC</protein><protein>AC</protein>']:
            with self.assertRaises(ConstraintError):
                parse_final(text)

    def test_closing_distance_includes_all_tag_bytes(self):
        v = vocabulary()
        self.assertEqual(v.distance[State()], len(OPEN) + 1 + len(CLOSE))
        self.assertEqual(v.distance[State('body')], len(CLOSE))
        with self.assertRaises(ConstraintError):
            RequestConstraint(v, 20)

    def test_all_feasible_tokenizations_preserved_at_exact_budget(self):
        v = vocabulary([OPEN, CLOSE, b'AC', b'A</protein>', b'<protein>A'])
        count = 0
        for length in range(1, 4):
            for letters in itertools.product(b'AC', repeat=length):
                text = OPEN + bytes(letters) + CLOSE
                for path in segmentation(text, v.pieces):
                    constraint = RequestConstraint(v, len(path) + 1)
                    prefix = []
                    for token in path:
                        self.assertIn(token, v.allowed_next_ids(constraint.state, len(path) + 1 - len(prefix)))
                        prefix.append(token)
                        constraint.update(prefix)
                    constraint.update(prefix + [500])
                    self.assertTrue(constraint.eos_seen)
                    count += 1
        self.assertGreater(count, 100)

    def test_no_residue_count_cutoff_merged_tokens_allow_long_bodies(self):
        v = vocabulary([OPEN, CLOSE, b'A' * 1000])
        constraint = RequestConstraint(v, 5)
        constraint.update([300, 302, 302, 301, 500])
        self.assertTrue(constraint.eos_seen)  # 2,000 residues in the five-token fixture.

    def test_deadline_forces_closure_without_early_AA_cutoff(self):
        v = vocabulary()
        prefix = list(OPEN + b'AA')
        constraint = RequestConstraint(v, len(OPEN) + 2 + len(CLOSE) + 1)
        constraint.update(prefix)
        allowed = v.allowed_next_ids(constraint.state, constraint.max_tokens - len(prefix))
        self.assertEqual(allowed, [ord('<')])
        with self.assertRaises(ConstraintError):
            constraint.update(prefix + [ord('A')])

    def test_every_admitted_path_has_a_budget_feasible_completion(self):
        v = vocabulary([OPEN, CLOSE, b'AC', b'C</protein>'])
        for state in ProteinLanguage.states:
            for budget in range(1, 24):
                for token in v.allowed_next_ids(state, budget):
                    if token not in v.eos_ids:
                        self.assertLessEqual(1 + v.distance[v.transitions[state][token]] + 1, budget)

    def test_premature_and_ordinary_post_EOS_rejected(self):
        v = vocabulary()
        with self.assertRaises(ConstraintError):
            RequestConstraint(v).update([500])
        c = RequestConstraint(v)
        path = list(OPEN + b'AC' + CLOSE) + [500]
        c.update(path)
        c.update(path + [501, 500])
        with self.assertRaises(ConstraintError):
            c.update(path + [501, 500, ord('A')])

    def test_history_rewrite_and_special_padding_rejected(self):
        c = RequestConstraint(vocabulary())
        c.update([ord('<')])
        with self.assertRaises(ConstraintError):
            c.update([ord('A')])
        with self.assertRaises(ConstraintError):
            RequestConstraint(vocabulary()).update([511])

    def test_unclosable_token_rejected_even_if_language_prefix_valid(self):
        v = vocabulary([OPEN, CLOSE])
        c = RequestConstraint(v, 4)
        c.update([300, ord('A')])
        with self.assertRaises(ConstraintError):
            c.update([300, ord('A'), ord('C')])

    def test_nonfinite_mask_and_finite_absorbing_EOS(self):
        import torch
        v = vocabulary()
        c = RequestConstraint(v)
        with self.assertRaises(ConstraintError):
            c([], torch.full((512,), float('-inf')))
        logits = torch.zeros(512)
        logits[ord('<')] = float('nan')
        with self.assertRaises(ConstraintError):
            c([], logits)
        path = list(OPEN + b'AC' + CLOSE) + [500]
        for fill in [0., float('-inf'), float('nan')]:
            result = c(path, torch.full((512,), fill))
            self.assertEqual(set(torch.where(torch.isfinite(result))[0].tolist()), {500, 501})
            self.assertEqual(result[[500, 501]].tolist(), [0., 0.])

    def test_wrong_logit_width_fails_closed(self):
        import torch
        with self.assertRaises(ConstraintError):
            RequestConstraint(vocabulary())([], torch.zeros(3))


if __name__ == '__main__':
    unittest.main()
