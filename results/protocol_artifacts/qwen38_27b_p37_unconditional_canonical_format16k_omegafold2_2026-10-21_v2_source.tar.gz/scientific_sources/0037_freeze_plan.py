"""Freeze separately named CPU-verified P37 repair; never submit or call models."""
from pathlib import Path
import copy
import json
from p37_runner import read,save,sha,stamp,CONDITION

HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'available_execution_v1'
ROOT=HERE.parents[4]


def main():
    if (HERE/'plan.json').exists():raise FileExistsError('Frozen proposal must remain immutable')
    prior=read(OLD/'plan.json')
    if sha(OLD/'plan.json')!='2e117964f78144a40eaa031a6e0d1a77b27be4e790714bb20baf4f1c12668f06':
        raise ValueError('Original failed condition source changed')
    cpu=read(HERE/'CPU_validation.json');checkpoint=read(HERE/'checkpoint_CPU_validation.json')
    if cpu['tests_passed']!=38 or checkpoint['checks_passed']!=9:
        raise ValueError('Complete neutral recording/native-I/O and exact-tokenizer/API proofs required')
    for name,expected in cpu['tested_source_sha256'].items():
        if sha(name)!=expected:raise ValueError('Tested prospective repair source changed: '+name)
    if checkpoint['source_sha256']!=sha(HERE/'protein_language.py'):
        raise ValueError('Finite-language code changed after exact-tokenizer check')
    pins=copy.deepcopy(prior['frozen_files_sha256'])
    for path,expected in pins.items():
        if sha(path)!=expected:raise ValueError('Preserved original source pin changed: '+path)
    previous_paths=[OLD/'plan.json',OLD/'root_admission.json',OLD/'submission_receipt.json',
        OLD/'runtime/development_failure_audit_20261021.json',OLD/'runtime/observed_allocation_terminal_20261021.json',
        OLD/'runtime/run_v1/development/completion.json',OLD/'runtime/run_v1/development/prediction_lock.json']
    original=read(OLD/'runtime/run_v1/development/prediction_lock.json')
    previous_paths += [OLD/'runtime/run_v1/development'/p for p in original['files_sha256']]
    previous={str(p):sha(p) for p in previous_paths}
    plan=copy.deepcopy(prior)
    plan.update(condition_id=CONDITION,created_at_pacific=stamp(),stage='frozen_format_repair_candidate_not_admitted',
        run_id='qwen38_27b_p37_unconditional_canonical_format16k_omegafold2_2026-10-21_v2',
        output_root=str(HERE/'runtime/run_v1'),development_case_ids=['P37-BOUNDED-DEV-0000','P37-BOUNDED-DEV-0001'],
        format_validity_is_imposed_not_a_capability_score=True,residue_count_cutoff=None,
        mandatory_model_runner='legacy_V1_explicit',custom_logits_processor='p37_format_logits:P37FormatLogitsProcessor',
        preserved_failed_condition={'job_id':'245226','runtime_root':str(OLD/'runtime'),
            'development_failure_audit':str(OLD/'runtime/development_failure_audit_20261021.json'),
            'allocation_terminal_receipt':str(OLD/'runtime/observed_allocation_terminal_20261021.json'),
            'files_sha256':previous},
        allowed_claim='Declared format-constrained released-code length/diversity and predictor-confidence proxies; imposed format validity is not model capability or paper-native equivalence.')
    differences=[x for x in prior['material_differences'] if 'two unconditional Qwen development deliveries' not in x]
    differences += [
        'A dedicated finite-token decoder imposes one nonempty canonical tagged sequence. Format validity is imposed, preserved only as a source diagnostic and omitted from primary capability metrics.',
        'The constrained alphabet uses20canonical amino-acid letters and one exact tag pair, excluding gaps/dashes, alternate case and surrounding prose that the original last-tag cleaning could retain or normalize.',
        'The decoder changes the output sampling distribution while retaining original prompt/sampling settings, every token-feasible canonical sequence, and the uniform16384 output cap; there is no residue-count cutoff.',
        'Two new artificial formatting prompts with seeds200042/200043 replace neither failed original pilot reply; the1000 original benchmark slots/seeds remain untouched before this condition.',
        'Exact pinned legacyV1 logits processor plus finite EOS-only terminal state is mandatory. Any envelope, constraint, transport, refusal or truncation failure stops new sends and drains outstanding requests without retries.']
    plan['material_differences']=differences
    plan['phase_order']=[x.replace('two_unconditional_development_deliveries','two_fresh_neutral_format_development_deliveries') for x in prior['phase_order']]
    plan['stop_policy']='Stop new sends on any transport/HTTP/envelope/refusal/empty/reasoning/truncation or canonical-format violation; drain already-issued calls, seal every1000slot and never retry.'
    script=f'''#!/bin/bash
#SBATCH --job-name=bio-p37-format-v2
#SBATCH --partition=il
#SBATCH --account=infolab
#SBATCH --gres=gpu:a100:1
#SBATCH --cpus-per-task=10
#SBATCH --mem=96G
#SBATCH --time=48:00:00
#SBATCH --chdir={ROOT}
#SBATCH --output={HERE}/slurm-%j.log
set -euo pipefail
umask 077
unset OPENAI_API_KEY ANTHROPIC_API_KEY GEMINI_API_KEY GOOGLE_API_KEY AZURE_OPENAI_API_KEY HF_TOKEN HUGGING_FACE_HUB_TOKEN SSH_AUTH_SOCK
unset OPENAI_BASE_URL OPENAI_ORG_ID OPENAI_PROJECT_ID PYTHONPATH PYTHONHOME VIRTUAL_ENV
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1
exec /usr/bin/python3 {HERE}/worker.py --plan {HERE}/plan.json --plan-sha256 "$1" --admission "$2" --admission-sha256 "$3"
'''
    (HERE/'worker.sbatch').write_text(script)
    for path in [*HERE.glob('*.py'),*HERE.glob('sources/*.py'),HERE/'stop_order_source_receipt.json',HERE/'worker.sbatch',HERE/'README.md',HERE/'CPU_validation.json',
                 HERE/'checkpoint_CPU_validation.json',*map(Path,previous)]:
        pins[str(path)]=sha(path)
    source_api=ROOT/'.local/catalog_execution_2026-10-20/tasks/P34/available_execution_v1/source_api_harness.py'
    pins[str(source_api)]=sha(source_api)
    plan['frozen_files_sha256']=pins
    save(HERE/'plan.json',plan)
    save(HERE/'admission_NOT_GRANTED_template.json',{'admitted':False,'task_id':'P37','condition_id':CONDITION,
        'plan_sha256':sha(HERE/'plan.json'),'gpu_count':1,'project_gpu_ceiling':8,
        'scope':'neutral_gates_then1000_unconditional_canonical_format_once_then_locked_OmegaFold2',
        'gpu_audit_receipt':'INDEPENDENT_REVIEWER_MUST_SUPPLY','gpu_audit_receipt_sha256':'INDEPENDENT_REVIEWER_MUST_SUPPLY'})
    save(HERE/'freeze_receipt.json',{'at_pacific':stamp(),'plan_sha256':sha(HERE/'plan.json'),
        'frozen_source_count':len(pins),'tests_passed':38,'checkpoint_checks_passed':9,
        'prior_failed_condition_preserved':True,'planned':1000,'model_calls':0,'GPU_submission':False})
    print(json.dumps({'plan_sha256':sha(HERE/'plan.json'),'frozen_sources':len(pins),'model_calls':0}))


if __name__=='__main__':main()
