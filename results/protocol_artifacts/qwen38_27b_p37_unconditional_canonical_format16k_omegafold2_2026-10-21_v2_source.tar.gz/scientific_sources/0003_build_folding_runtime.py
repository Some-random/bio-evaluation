"""Package existing evaluator runtime and verify relocation; zero forwards."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import tarfile
import tempfile
from zoneinfo import ZoneInfo
HERE=Path(__file__).resolve().parent
SOURCE=Path('/tmp/bio-p37-omegafold2-runtime-20261020')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
def main():
 archive=HERE/'folding_runtime.tar';receipt=HERE/'folding_runtime_manifest.json'
 if archive.exists() or receipt.exists():raise FileExistsError('Preserve existing runtime artifact')
 roots={'python':SOURCE/'interpreters/cpython-3.10.18-linux-x86_64-gnu',
  'site-packages':SOURCE/'venv/lib/python3.10/site-packages','source':SOURCE/'source'}
 files={}
 temporary=archive.with_suffix('.tmp')
 with tarfile.open(temporary,'w',dereference=True) as tar:
  for prefix,root in roots.items():
   for p in sorted(root.rglob('*')):
    if not p.is_file():continue
    name=prefix+'/'+str(p.relative_to(root))
    files[name]={'sha256':sha(p),'bytes':p.stat().st_size}
    tar.add(p,arcname=name,recursive=False)
 temporary.rename(archive)
 proof=Path(tempfile.mkdtemp(prefix='p37-portability-proof-'))
 with tarfile.open(archive) as tar:tar.extractall(proof,filter='data')
 env={k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ('TOKEN','KEY','SECRET','PASSWORD','CREDENTIAL'))}
 env.update(PYTHONHOME=str(proof/'python'),PYTHONPATH=str(proof/'site-packages')+':'+str(proof/'source'),
  PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
 code=('import torch,omegafold,importlib.metadata as m,json,platform;'
  'assert torch.__version__=="1.12.0+cu113";assert not torch.cuda.is_initialized();'
  'print(json.dumps({"python":platform.python_version(),"torch":torch.__version__,"numpy":m.version("numpy"),'
  '"biopython":m.version("biopython"),"huggingface-hub":m.version("huggingface-hub"),"omegafold_file":omegafold.__file__,"model_forwards":0}))')
 identity=json.loads(subprocess.check_output([str(proof/'python/bin/python3.10'),'-c',code],env=env,text=True,timeout=180))
 if not Path(identity['omegafold_file']).resolve().is_relative_to(proof/'source'):raise ValueError('Runtime source relocation failed')
 record={'stage':'portable_OmegaFold_archive_relocation_import_verified_no_forward',
  'at_pacific':datetime.datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),'job_id':os.environ.get('SLURM_JOB_ID'),
  'archive':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
  'identity':identity,'files':files,'file_count':len(files),'bytes':sum(x['bytes'] for x in files.values()),
  'proof_extraction_root':str(proof),'model_forwards':0,'CUDA_initialized':False,'GPU_allocations':0,'source_runtime_modified':False}
 with receipt.open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
 (HERE/'portable_runtime_validation.json').write_text(json.dumps({k:record[k] for k in record if k!='files'},indent=2)+'\n')
 print(json.dumps({k:record[k] for k in ['stage','job_id','file_count','bytes','archive_sha256','model_forwards']}))
if __name__=='__main__':main()
