"""Original unconditional benchmark prompt; separate neutral delivery fixtures."""
import hashlib

from protein_language import CONDITION

PROMPT = 'Generate a protein sequence with <protein> </protein>.'
DEVELOPMENT_PROMPTS = (
    'Return exactly this artificial formatting fixture: <protein>ACDE</protein>.',
    'Return exactly this second artificial formatting fixture: <protein>FGHIK</protein>.',
)
PROMPTS = {'benchmark': (PROMPT,), 'development': DEVELOPMENT_PROMPTS}


def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


def payload(plan, index, development=False):
    generation = plan['generation']
    if (generation['prompt'] != PROMPT or generation['max_tokens'] != 16384
            or generation['temperature'] != .9 or generation['top_p'] != .9
            or generation['top_k'] != 50 or generation['seed_base'] != 42
            or generation['enable_thinking'] is not False):
        raise ValueError('Original unconditional sampling and uniform16K required')
    if not isinstance(index, int) or isinstance(index, bool) or index < 0:
        raise ValueError('Exact nonnegative slot index required')
    phase = 'development' if development else 'benchmark'
    if index >= (2 if development else 1000):
        raise ValueError('Foreign generation slot')
    text = DEVELOPMENT_PROMPTS[index] if development else PROMPT
    return {'model': plan['model']['served_model_name'],
            'messages': [{'role': 'user', 'content': text}], 'n': 1,
            'temperature': .9, 'top_p': .9, 'top_k': 50, 'max_tokens': 16384,
            'seed': 200042 + index if development else 42 + index,
            'chat_template_kwargs': {'enable_thinking': False},
            'vllm_xargs': {'p37_format_condition': CONDITION, 'p37_phase': phase,
                           'p37_prompt_sha256': digest(text), 'p37_output_tokens': 16384}}
