"""Freeze a concrete P37 execution candidate; creates no root admission."""
from pathlib import Path
import hashlib
import json
import os
from p37_runner import CONDITION,PROMPT,read,save,sha,stamp

HERE=Path(__file__).resolve().parent
TASK=HERE.parent
ROOT=TASK.parents[3]


def main():
    output=HERE/'plan.json'
    if output.exists():raise FileExistsError('Preserve frozen candidate; revise separately after review')
    old=read(TASK/'frozen_contract.json')
    if sha(TASK/'frozen_contract.json')!='3f1eb1bf8cbffbcebf09fba0f7376ca69054e7f83aeb4d4a6ffce8d0a6a0eb29':
        raise ValueError('Original preparation contract changed')
    if not (HERE/'folding_runtime_manifest.json').is_file() or not (HERE/'portable_runtime_validation.json').is_file():
        raise ValueError('Portable runtime must have terminal import proof before freeze')
    cpu=read(HERE/'CPU_validation.json')
    if cpu['tests_passed']!=23 or cpu['actual_model_calls']!=0 or cpu['GPU_jobs']!=0:
        raise ValueError('Recording-client/native-I/O CPU tests required')
    v06=read(ROOT/'.local/catalog_execution_2026-10-20/tasks/V06/local_execution_v2/plan.json')
    gpu_helper=ROOT/'scripts/project_gpu_audit_20261021.py'
    if sha(gpu_helper)!='9045eaf578e27dedcd5aba285b5a6253240244d70f52b7ad93e0dd7c0ecf9cc9':
        raise ValueError('Root project-GPU audit helper changed')
    source=read(TASK/'source_manifest.json')
    if sha(TASK/'source_manifest.json')!=old['source_manifest_sha256']:
        raise ValueError('Frozen released source manifest changed')
    files=[*HERE.glob('*.py'),HERE/'worker.sbatch',HERE/'folding_runtime_manifest.json',
        HERE/'portable_runtime_validation.json',HERE/'CPU_validation.json',
        TASK/'frozen_contract.json',TASK/'contract_adapter.py',TASK/'source_manifest.json',
        TASK/'engineering_20261020/runtime_adapter.py',TASK/'engineering_20261020/combined_validation.json',
        Path(v06['runtime_common']),Path(v06['checkpoint_audit']),gpu_helper]
    files += [ROOT/r['path'] for r in source['files']]
    pins={str(p):sha(p) for p in sorted(set(files))}
    checkpoint=old['folding']['checkpoint']
    differences=old['material_differences']+[
        'Prospective retained-task output cap is uniformly16384 instead of the earlier preparation/SciReason2048; all other released sampling settings retained.',
        'A separate artificial20-residue OmegaFold delivery gate and two unconditional Qwen development deliveries precede the1000 benchmark slots; they are never benchmark scores.',
        'Per-case evaluator identity and errors are preserved; source silent fold skipping is replaced by undefined full confidence when any eligible output lacks a successful score.',
        'Native PDB/confidence files are retained as delivery artifacts; pLDDT remains predictor confidence, not experimental validity.']
    plan={'schema_version':1,'task_id':'P37','condition_id':CONDITION,'stage':'frozen_candidate_not_admitted',
        'created_at_pacific':stamp(),'run_id':'qwen38_27b_p37_unconditional_uniform16k_omegafold2_2026-10-21_v1',
        'planned':1000,'planned_case_ids':old['planned_case_ids'],
        'development_case_ids':['P37-DEV-0000','P37-DEV-0001'],
        'model':old['model'],'generation':{'prompt':PROMPT,'temperature':.9,'top_p':.9,'top_k':50,
            'max_tokens':16384,'seed_base':42,'enable_thinking':False,'concurrency':4,
            'maximum_attempts_per_case':1,'selective_retries':False},
        'gpus_requested':1,'project_gpu_ceiling':8,'tensor_parallel_size':1,'endpoint':'http://127.0.0.1:8477/v1',
        'output_root':str(HERE/'runtime/run_v1'),'contract_adapter':str(TASK/'contract_adapter.py'),
        'folding_adapter':str(TASK/'engineering_20261020/runtime_adapter.py'),
        'folding_runtime_manifest':str(HERE/'folding_runtime_manifest.json'),
        'folding_checkpoint':{'path':str(ROOT/checkpoint['path']),'sha256':checkpoint['sha256'],'bytes':checkpoint['bytes']},
        'folding_timeout_seconds':86400,'folding_settings':old['folding'],
        'base_runtime':v06['base_runtime'],'cuda_overlay':v06['cuda_overlay'],
        'runtime_common':v06['runtime_common'],'checkpoint_audit':v06['checkpoint_audit'],
        'project_gpu_audit_helper':str(gpu_helper),
        'operational_GPU_account_inventory_publication':'Private only; publish project totals and receipt hashes, never full unrelated-job metadata.',
        'frozen_files_sha256':pins,'reference_targets_present':False,'new_training':False,
        'input_scope':{'unique_prompt_count':1,'unconditional':True,'reference_or_demonstration_sequences_in_requests':False,
            'independent_question_review':'Exact sole unconditional generation prompt has no requested function/organism, experimental procedure or biological material context. All1000 slots reuse that same question; no held case is imported.'},
        'material_differences':differences,'paper_native_condition_available':False,
        'allowed_claim':'Separately declared released-code format/diversity/predictor-confidence proxies only; no matched NatureLM replication or experimental validation.',
        'stop_policy':'On transport/HTTP/malformed envelope, explicit refusal, observed empty final, reasoning or truncation: stop new sends, drain outstanding calls, preserve all unattempted slots. Ordinary nonempty text with no parsed protein remains a format-invalid benchmark response, never selectively replaced.',
        'phase_order':['neutral_artificial_OmegaFold_delivery_gate','own_Qwen_server_start',
            'two_unconditional_development_deliveries','1000_once_only_unconditional_slots',
            'seal_all_generation_outputs','stop_own_Qwen_server','one_OmegaFold_forward_per_eligible_locked_output',
            'seal_folding_outputs','released_code_proxy_aggregation'],
        'actual_model_calls_by_preparation':0,'dispatch_authorized_by_this_file':False}
    save(output,plan)
    save(HERE/'admission_NOT_GRANTED_template.json',{'admitted':False,'task_id':'P37','condition_id':CONDITION,
        'plan_sha256':sha(output),'gpu_count':1,'project_gpu_ceiling':8,
        'scope':'neutral_folding_gate_and1000_unconditional_once_then_locked_OmegaFold2',
        'gpu_audit_receipt':'ROOT_MUST_SUPPLY','gpu_audit_receipt_sha256':'ROOT_MUST_SUPPLY'})
    save(HERE/'freeze_receipt.json',{'at_pacific':stamp(),'plan_sha256':sha(output),
        'frozen_source_count':len(pins),'planned':1000,'CPU_tests_passed':23,'actual_model_calls':0,
        'root_admission_present':False,'GPU_submission_performed':False})
    print(json.dumps({'plan_sha256':sha(output),'frozen_source_count':len(pins),'planned':1000}))


if __name__=='__main__':main()
