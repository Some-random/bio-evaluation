# P37 prospective format-constrained delivery repair

This separate, unadmitted condition preserves the original failed development
run and its two replies. Its 1,000 unconditional benchmark slots were never
entered, as established by the frozen worker branch and sealed failure audit;
missing directories alone are not the basis for that conclusion. No old pilot
request is retried. Two new artificial formatting prompts and fresh seeds are
delivery checks only.

The benchmark prompt, temperature 0.9, top-p 0.9, top-k 50, nonthinking mode,
seeds 42–1041, 1,000-slot denominator and uniform 16,384-token output budget stay
the same. A dedicated decoder now imposes exactly one nonempty canonical protein
between the original tags. **Format validity is imposed and is not reported as
a capability score.** This intervention changes the sampling distribution and
is separately named; it is not an unconstrained or paper-matched reproduction.
The accepted output alphabet is the 20 canonical amino acids, excluding gaps,
alternate case and surrounding prose that the source cleaning could normalize
or retain. This restriction is part of the declared output intervention.

There is no residue-count cutoff. A finite-state minimum remaining-token
distance reserves only the exact tokenizer-supported closure and EOS inside
the same output-token cap. Every base-BPE token path spelling a complete
canonical tagged sequence within that cap remains representable. The final
length distribution is an observed result, not a preselected short-sequence
cohort. Premature EOS, special/padding tokens, unclosable continuations, history
rewrites and ordinary bytes after EOS fail closed. Late internal asynchronous
callbacks use the proven finite EOS-only terminal state.

The existing released SciReason positional-99% diversity and average-length
calculations, and OmegaFold2 confidence on **all generated outputs shorter than
100 residues**, are retained. All eligibility and errors remain in the complete
denominator. The source zero convention when no output is eligible remains
explicit and is not a measured confidence. The released format diagnostic is
preserved in a separate source-output field, omitted from the primary metric
object. Predictor confidence is not experimental functionality.

The same pinned independent Qwen and OmegaFold runtimes are used sequentially
on one allocation; the folding subprocess retains its own Python/Torch library
paths and strips inherited Qwen CUDA compiler settings. The existing neutral
OmegaFold check runs before Qwen; the two fresh neutral delivery checks precede
the untouched 1,000 once-only slots. The own Qwen server stops before folding.
No active P34 or DeepFRI setting, GPU or output is changed.

Current CPU evidence proves the finite-language and artificial recording-client
interfaces only. Independent exact-plan review/admission and a fresh project
GPU audit under the shared submission lock are required before any real call.
The original condition and all historical scores remain unchanged.
