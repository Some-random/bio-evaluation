"""Exact prospective P37 admission guards; no model or endpoint operations."""
import os
from pathlib import Path
import tarfile
from p37_runner import CONDITION,read,sha

HERE=Path(__file__).resolve().parent


def validate(plan_path,plan_sha,admission_path,admission_sha,require_slurm=True):
    if sha(plan_path)!=plan_sha:raise ValueError('P37 plan hash changed')
    plan=read(plan_path)
    if (plan['condition_id']!=CONDITION or plan['planned']!=1000
            or plan['planned_case_ids']!=[f'P37-UPG-{i:04d}' for i in range(1000)]
            or plan['gpus_requested']!=1 or plan['generation']['max_tokens']!=16384
            or plan['generation']['prompt']!='Generate a protein sequence with <protein> </protein>.'
            or plan['generation']['enable_thinking'] is not False
            or plan['endpoint']!='http://127.0.0.1:8477/v1'
            or Path(plan['output_root']).resolve()!=HERE/'runtime/run_v1'):
        raise ValueError('Exact1000-slot uniform16K one-GPU P37 condition required')
    for name,digest in plan['frozen_files_sha256'].items():
        if Path(name).is_symlink() or sha(name)!=digest:raise ValueError('Frozen source or input changed: '+name)
    if sha(admission_path)!=admission_sha:raise ValueError('Root admission changed')
    admitted=read(admission_path)
    if (admitted.get('admitted') is not True or admitted.get('task_id')!='P37'
        or admitted.get('condition_id')!=CONDITION or admitted.get('plan_sha256')!=plan_sha
        or admitted.get('gpu_count')!=1 or admitted.get('project_gpu_ceiling')!=8
        or admitted.get('scope')!='neutral_folding_gate_and1000_unconditional_once_then_locked_OmegaFold2'):
        raise ValueError('Separate exact root admission required before any model startup/forward')
    if sha(admitted['gpu_audit_receipt'])!=admitted['gpu_audit_receipt_sha256']:
        raise ValueError('Root GPU audit binding changed')
    if require_slurm and not os.environ.get('SLURM_JOB_ID'):raise ValueError('Slurm allocation required')
    plan['plan_sha256']=plan_sha
    return plan


def verify_folding_runtime(plan,destination):
    manifest=read(plan['folding_runtime_manifest'])
    archive=Path(manifest['archive'])
    if archive.stat().st_size!=manifest['archive_bytes'] or sha(archive)!=manifest['archive_sha256']:
        raise ValueError('Pinned portable evaluator archive changed')
    root=Path(destination)
    root.mkdir(exist_ok=False)
    with tarfile.open(archive) as tar:
        members=tar.getmembers()
        if (len(members)!=len(manifest['files']) or {m.name for m in members}!=set(manifest['files'])
            or any(not m.isfile() or Path(m.name).is_absolute() or '..' in Path(m.name).parts for m in members)):
            raise ValueError('Unexpected portable runtime members')
        tar.extractall(root,filter='data')
    for name,item in manifest['files'].items():
        path=root/name
        if (Path(name).is_absolute() or '..' in Path(name).parts or path.is_symlink()
            or not path.is_file() or path.stat().st_size!=item['bytes'] or sha(path)!=item['sha256']):
            raise ValueError('Pinned portable evaluator runtime changed')
    return root
