"""Unadmitted CPU proposal: canonical tags, with the original token budget.

This is a formatting intervention, not a measurement of format-following skill.
It imposes no residue-count cutoff. Every ordinary-token path spelling a valid
tagged canonical sequence and EOS within the configured output budget remains
representable. The finite-state shortest completion distance only removes
choices that cannot finish inside that same budget.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re

AMINO_ACIDS = "ACDEFGHIKLMNPQRSTVWY"
OPEN = b"<protein>"
CLOSE = b"</protein>"
CONDITION = "SCIREASON_UPG_QWEN_CANONICAL_TAGGED_TOKEN_BOUNDED_PROPOSAL_V2"


class ConstraintError(ValueError):
    pass


@dataclass(frozen=True)
class State:
    phase: str = "open"
    index: int = 0


class ProteinLanguage:
    """Finite states; body-positive state has an AA loop, not a length cap."""
    states = tuple([State("open", i) for i in range(len(OPEN))]
                   + [State("empty_body"), State("body")]
                   + [State("close", i) for i in range(1, len(CLOSE))]
                   + [State("done")])

    @staticmethod
    def step(state: State, byte: int) -> State:
        if state.phase == "open":
            if byte != OPEN[state.index]:
                raise ConstraintError("wrong_open_tag")
            return (State("empty_body") if state.index + 1 == len(OPEN)
                    else State("open", state.index + 1))
        if state.phase in {"empty_body", "body"}:
            if byte in AMINO_ACIDS.encode():
                return State("body")
            if state.phase == "body" and byte == CLOSE[0]:
                return State("close", 1)
            raise ConstraintError("canonical_nonempty_body_required")
        if state.phase == "close":
            if byte != CLOSE[state.index]:
                raise ConstraintError("wrong_close_tag")
            return (State("done") if state.index + 1 == len(CLOSE)
                    else State("close", state.index + 1))
        raise ConstraintError("ordinary_bytes_after_complete_protein")

    @classmethod
    def feed(cls, state: State, data: bytes) -> State:
        for byte in data:
            state = cls.step(state, byte)
        return state


def parse_final(final: str) -> str:
    if not isinstance(final, str) or not re.fullmatch(
            r"<protein>([ACDEFGHIKLMNPQRSTVWY]+)</protein>", final):
        raise ConstraintError("exact_nonempty_canonical_tagged_final_required")
    return final[len(OPEN):-len(CLOSE)]


def bytelevel_inverse():
    direct = list(range(33, 127)) + list(range(161, 173)) + list(range(174, 256))
    chars = direct.copy()
    next_codepoint = 256
    for byte in range(256):
        if byte not in direct:
            direct.append(byte)
            chars.append(next_codepoint)
            next_codepoint += 1
    return {chr(c): b for b, c in zip(direct, chars)}


class TokenVocabulary:
    def __init__(self, pieces: dict[int, bytes], eos_ids: set[int], vocab_size: int):
        if (not eos_ids or not pieces or min([*pieces, *eos_ids]) < 0
                or max([*pieces, *eos_ids]) >= vocab_size):
            raise ConstraintError("invalid_vocabulary_bounds")
        self.pieces = pieces
        self.eos_ids = frozenset(eos_ids)
        self.vocab_size = vocab_size
        self.transitions = {}
        self.distance = {State("done"): 0}
        reverse = {state: set() for state in ProteinLanguage.states}
        for state in ProteinLanguage.states:
            edges = {}
            for token, piece in pieces.items():
                if not piece or token in eos_ids:
                    raise ConstraintError("empty_or_special_ordinary_piece")
                try:
                    following = ProteinLanguage.feed(state, piece)
                except ConstraintError:
                    continue
                edges[token] = following
                reverse[following].add(state)
            self.transitions[state] = edges
        queue = deque([State("done")])
        while queue:
            following = queue.popleft()
            for previous in reverse[following]:
                if previous not in self.distance:
                    self.distance[previous] = self.distance[following] + 1
                    queue.append(previous)
        if len(self.distance) != len(ProteinLanguage.states):
            raise ConstraintError("vocabulary_cannot_close_every_language_state")

    @classmethod
    def from_checkpoint_tokenizer(cls, path: Path, expected_sha256: str, eos_ids: set[int]):
        raw = Path(path).read_bytes()
        if hashlib.sha256(raw).hexdigest() != expected_sha256:
            raise ConstraintError("checkpoint_tokenizer_hash_mismatch")
        config = json.loads(raw)
        if (config.get("decoder", {}).get("type") != "ByteLevel"
                or config["decoder"].get("add_prefix_space") is not False
                or config.get("model", {}).get("type") != "BPE"):
            raise ConstraintError("literal_ByteLevel_BPE_required")
        special = {x["id"] for x in config.get("added_tokens", []) if x.get("special")}
        if not eos_ids <= special:
            raise ConstraintError("EOS_must_match_checkpoint_special_tokens")
        inverse = bytelevel_inverse()
        alphabet = set(OPEN + CLOSE + AMINO_ACIDS.encode())
        pieces = {}
        vocab = config["model"]["vocab"]
        for text, token_id in vocab.items():
            if token_id in special:
                continue
            try:
                piece = bytes(inverse[c] for c in text)
            except KeyError as error:
                raise ConstraintError("unexpected_BPE_alphabet") from error
            if piece and set(piece) <= alphabet:
                pieces[token_id] = piece
        # A one-byte path for each accepted character proves no accepted byte
        # string is lost merely because irrelevant token pieces are masked.
        singles = {piece for piece in pieces.values() if len(piece) == 1}
        if not {bytes([byte]) for byte in alphabet} <= singles:
            raise ConstraintError("complete_canonical_ASCII_byte_basis_required")
        size = max([*vocab.values(), *(x["id"] for x in config.get("added_tokens", []))]) + 1
        return cls(pieces, eos_ids, size)

    def allowed_next_ids(self, state: State, remaining_tokens: int):
        if remaining_tokens < 1:
            return []
        if state.phase == "done":
            return sorted(self.eos_ids)
        # One token for this edge, exact shortest closure, one EOS token.
        return [token for token, following in self.transitions[state].items()
                if 1 + self.distance[following] + 1 <= remaining_tokens]


class RequestConstraint:
    def __init__(self, vocabulary: TokenVocabulary, max_tokens=16384):
        if not isinstance(max_tokens, int) or isinstance(max_tokens, bool):
            raise ConstraintError("integer_output_token_budget_required")
        if max_tokens < vocabulary.distance[State()] + 1:
            raise ConstraintError("budget_cannot_hold_one_complete_protein_and_EOS")
        self.vocabulary = vocabulary
        self.max_tokens = max_tokens
        self.state = State()
        self.output_ids = []
        self.eos_seen = False

    def update(self, output_ids):
        if output_ids[:len(self.output_ids)] != self.output_ids:
            raise ConstraintError("output_history_rewrite_or_speculation_not_supported")
        for offset, token in enumerate(output_ids[len(self.output_ids):], len(self.output_ids)):
            if self.eos_seen:
                if token not in self.vocabulary.eos_ids:
                    raise ConstraintError("ordinary_token_after_EOS")
                continue  # Late internal asynchronous callbacks only.
            if token not in self.vocabulary.allowed_next_ids(self.state, self.max_tokens - offset):
                raise ConstraintError("invalid_or_budget_unclosable_generated_token")
            if token in self.vocabulary.eos_ids:
                self.eos_seen = True
            else:
                self.state = self.vocabulary.transitions[self.state][token]
        self.output_ids = list(output_ids)

    def __call__(self, output_ids, logits):
        import torch
        self.update(output_ids)
        allowed = (sorted(self.vocabulary.eos_ids) if self.eos_seen
                   else self.vocabulary.allowed_next_ids(self.state, self.max_tokens - len(output_ids)))
        if logits.ndim != 1 or not allowed or max(allowed) >= logits.shape[0]:
            raise ConstraintError("no_budget_feasible_complete_protein_path")
        index = torch.tensor(allowed, dtype=torch.long, device=logits.device)
        selected = logits.index_select(0, index)
        if self.eos_seen:
            logits.fill_(float("-inf"))
            logits[index] = 0.0
            return logits
        if not torch.isfinite(selected).any():
            raise ConstraintError("all_allowed_logits_nonfinite")
        selected = torch.where(torch.isfinite(selected), selected, float("-inf"))
        logits.fill_(float("-inf"))
        logits[index] = selected
        return logits
