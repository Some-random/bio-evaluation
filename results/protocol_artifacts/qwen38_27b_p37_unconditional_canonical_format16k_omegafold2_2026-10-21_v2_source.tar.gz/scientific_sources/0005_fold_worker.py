"""Explicitly admitted OmegaFold2 delivery/locked-output evaluation subprocess."""
from __future__ import annotations
import argparse
import gc
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import types

from admission import validate
from p37_runner import adapter,current,fold_manifest,read,save,sha,stamp,verify_generation

HERE=Path(__file__).resolve().parent
NEUTRAL_SEQUENCE='ACDEFGHIKLMNPQRSTVWY'


def fold_once(case_id,sequence,folder,model,pipeline,runtime_adapter,torch,device):
    """One native forward, preserving identity/errors; no retry or case drop."""
    folder.mkdir(parents=True,exist_ok=False)
    save(folder/'attempt.json',{'case_id':case_id,'at_pacific':stamp(),
        'postprocessed_sequence_sha256':hashlib.sha256(sequence.encode()).hexdigest()})
    forward_attempted=False
    try:
        inputs=runtime_adapter.build_single_case_inputs(sequence,pipeline,folder)
        inputs=[{k:v.to(device) for k,v in cycle.items()} for cycle in inputs]
        with torch.no_grad():
            forward_attempted=True
            output=model(inputs,predict_with_confidence=True,
                fwd_cfg=types.SimpleNamespace(subbatch_size=448,num_recycle=10))
        record=runtime_adapter.confidence_to_record(case_id,sequence,output)
        confidence=output['confidence'].detach().cpu()
        save(folder/'residue_confidence.json',{'values':confidence.tolist(),'native_mean_times100':record['mean_plddt']})
        pdb=folder/'prediction.pdb'
        pipeline.save_pdb(output['final_atom_positions'],output['confidence']*100,
            inputs[0]['p_msa'][0],inputs[0]['p_msa_mask'][0],str(pdb),model=0)
        if not pdb.is_file() or not pdb.stat().st_size:raise ValueError('Native PDB writer produced no file')
        record.update(pdb_sha256=sha(pdb),confidence_sha256=sha(folder/'residue_confidence.json'))
        del output,inputs
    except Exception as error:
        record=runtime_adapter.error_record(case_id,sequence,error)
    record.update(at_pacific=stamp(),forward_invocation_attempted=forward_attempted)
    save(folder/'outcome.json',record)
    gc.collect()
    if device=='cuda':torch.cuda.empty_cache()
    return record


def main():
    parser=argparse.ArgumentParser()
    for name in ('plan','admission'):parser.add_argument('--'+name,type=Path,required=True)
    for name in ('plan-sha256','admission-sha256'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--mode',choices=('neutral_gate','benchmark'),required=True)
    args=parser.parse_args()
    plan=validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256)
    gpu_spec=importlib.util.spec_from_file_location('p37_fold_root_GPU_audit',plan['project_gpu_audit_helper'])
    gpu_helper=importlib.util.module_from_spec(gpu_spec);gpu_spec.loader.exec_module(gpu_helper)
    save(HERE/'runtime'/('private_GPU_backend_audit_'+args.mode+'.json'),
        gpu_helper.conservative_project_gpu_audit(require_own_job=True))
    prepared=read(HERE/'runtime/folding_runtime_receipt.json')
    if (prepared['plan_sha256']!=args.plan_sha256 or prepared['job_id']!=os.environ['SLURM_JOB_ID']
        or prepared['manifest_sha256']!=sha(plan['folding_runtime_manifest'])):
        raise ValueError('Evaluator extraction ownership/identity differs')
    root=Path(prepared['local_root'])
    import torch
    import omegafold
    from omegafold import pipeline
    if (torch.__version__!='1.12.0+cu113' or not Path(omegafold.__file__).resolve().is_relative_to(root/'source')
        or torch.cuda.device_count()!=1):raise ValueError('Exact pinned evaluator and one Slurm GPU required')
    def no_network(*args,**kwargs):raise RuntimeError('Evaluator networking prohibited')
    socket.create_connection=no_network;socket.socket.connect=no_network
    torch.set_num_threads(4);torch.set_num_interop_threads(1)
    checkpoint=Path(plan['folding_checkpoint']['path'])
    if sha(checkpoint)!=plan['folding_checkpoint']['sha256']:raise ValueError('OmegaFold checkpoint changed')
    state=torch.load(checkpoint,map_location='cpu')
    if 'model' in state:state=state['model']
    model=omegafold.OmegaFold(omegafold.make_config(2))
    binding=model.load_state_dict(state,strict=True)
    if binding.missing_keys or binding.unexpected_keys:raise ValueError('Strict learned-weight binding failed')
    del state
    model.eval();model.to('cuda');pipeline._set_precision(True)
    spec=importlib.util.spec_from_file_location('p37_pinned_runtime_adapter',plan['folding_adapter'])
    runtime_adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(runtime_adapter)
    runtime=HERE/'runtime'
    if args.mode=='neutral_gate':
        record=fold_once('P37-NEUTRAL-FOLD-0000',NEUTRAL_SEQUENCE,runtime/'neutral_folding_gate',
            model,pipeline,runtime_adapter,torch,'cuda')
        save(runtime/'neutral_folding_gate_completion.json',{'at_pacific':stamp(),
            'passed':record['status']=='success','neutral_artificial_sequence':True,'real_benchmark_cases':0,
            'model_forwards_attempted':int(record['forward_invocation_attempted']),
            'outcome':record,'plan_sha256':args.plan_sha256})
        if record['status']!='success':raise RuntimeError('Neutral folding delivery failed; no benchmark dispatch')
        return
    generation=Path(plan['output_root'])/'generation'
    records,done=verify_generation(plan,generation)
    if not done['all_delivered']:raise ValueError('Benchmark folds require complete solver delivery')
    expected=fold_manifest(plan,generation)
    clean={r['case_id']:adapter(plan).postprocess(r.get('final_text')) for r in records if r['status']=='response'}
    fold_root=Path(plan['output_root'])/'folding';fold_root.mkdir(parents=True,exist_ok=False)
    save(fold_root/'manifest.json',{'at_pacific':stamp(),'eligible':expected,
        'generation_prediction_lock_sha256':done['prediction_lock_sha256'],'maximum_attempts_per_case':1})
    outcomes=[]
    for row in expected:
        ident=row['case_id'];sequence=clean[ident]
        if hashlib.sha256(sequence.encode()).hexdigest()!=row['postprocessed_sequence_sha256']:
            raise ValueError('Derived evaluator input changed')
        result=fold_once(ident,sequence,fold_root/'cases'/ident,model,pipeline,runtime_adapter,torch,'cuda')
        outcomes.append(result)
        current(fold_root/'progress.json',{'at_pacific':stamp(),'planned':len(expected),
            'observed':len(outcomes),'successes':sum(r['status']=='success' for r in outcomes),
            'errors':sum(r['status']=='error' for r in outcomes),'role':'direct_unsealed_evaluator_progress_lower_bound'})
    save(fold_root/'terminal_records.json',outcomes)
    files={str(p.relative_to(fold_root)):sha(p) for p in sorted((fold_root/'cases').rglob('*')) if p.is_file()}
    files.update({n:sha(fold_root/n) for n in ('manifest.json','terminal_records.json')})
    save(fold_root/'prediction_lock.json',{'files_sha256':files,'plan_sha256':args.plan_sha256,
        'generation_prediction_lock_sha256':done['prediction_lock_sha256']})
    save(fold_root/'completion.json',{'at_pacific':stamp(),'planned':len(expected),'terminal':len(outcomes),
        'successes':sum(r['status']=='success' for r in outcomes),'errors':sum(r['status']=='error' for r in outcomes),
        'prediction_lock_sha256':sha(fold_root/'prediction_lock.json')})


if __name__=='__main__':main()
