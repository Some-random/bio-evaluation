"""One-attempt P37 delivery and sealed released-code proxy aggregation.

Importing this module never makes a model call. Tests supply recording clients.
The live worker must independently verify the frozen plan/root admission.
"""
from __future__ import annotations

from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from datetime import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import threading
from zoneinfo import ZoneInfo

from protein_language import CONDITION,parse_final
from bound_request import PROMPT,payload


def stamp():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def canonical(value):
    return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(canonical(value))


def current(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix('.tmp');temporary.write_bytes(canonical(value));temporary.replace(path)


def adapter(plan):
    spec=importlib.util.spec_from_file_location('p37_pinned_contract_adapter',plan['contract_adapter'])
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


class TransportError(Exception):
    def __init__(self,message,http_status=None,body=None):
        super().__init__(message);self.http_status=http_status;self.body=body


def interpret(raw):
    """Keep malformed/no-body status separate from observed empty finals."""
    result={'status':'response_error','final_text':None,'finish_reason':None,
        'empty_final':None,'truncated':False,'refusal':False,'reasoning_present':False,
        'fatal_delivery_error':True,'envelope_parsed':False}
    try:
        body=json.loads(raw)
        choices=body['choices']
        if not isinstance(choices,list) or len(choices)!=1:raise ValueError('Exactly one choice required')
        choice=choices[0];message=choice['message']
        if not isinstance(message,dict):raise ValueError('Message object required')
        content=message.get('content')
        if not isinstance(content,(str,type(None))):raise ValueError('Text final or explicit null required')
        if message.get('tool_calls') or message.get('function_call'):raise ValueError('No tool response permitted')
        finish=choice.get('finish_reason')
        if not isinstance(finish,(str,type(None))):raise ValueError('Unexpected finish reason type')
        result.update(envelope_parsed=True,final_text=content,finish_reason=finish,
            empty_final=content is None or not content.strip(),truncated=finish=='length',
            refusal=bool(message.get('refusal')),
            reasoning_present=bool(message.get('reasoning') or message.get('reasoning_content')))
        result['fatal_delivery_error']=bool(result['empty_final'] or result['truncated'] or result['refusal']
            or result['reasoning_present'] or finish!='stop')
        result['status']='response'
        if result['fatal_delivery_error']:result['delivery_failure']='observed_incomplete_refused_or_nonfinal_response'
        if not result['fatal_delivery_error']:
            try:parse_final(content)
            except (TypeError,ValueError):
                result.update(fatal_delivery_error=True,format_constraint_error=True)
    except (ValueError,KeyError,TypeError,UnicodeError) as error:
        result['response_error_type']=type(error).__name__
    return result


def call_once(folder,case_id,request,transport,postprocess,stop_signal):
    key=hashlib.sha256(case_id.encode()).hexdigest()
    # A submitted future can remain queued when another worker observes a
    # fatal response. Such a slot has no admitted send attempt and must never
    # create a request record or enter the transport after it starts.
    if stop_signal.is_set():
        outcome={'case_id':case_id,'status':'not_dispatched',
            'reason':'fatal_delivery_signal_observed_before_worker_dispatch_admission',
            'fatal_delivery_error':False,'postprocessed_nonempty':False}
        save(folder/'outcomes'/f'{key}.json',outcome)
        return outcome
    request_path=folder/'requests'/f'{key}.json'
    save(request_path,request)
    save(folder/'attempts'/f'{key}.json',{'case_id':case_id,'at_pacific':stamp(),
        'request_sha256':sha(request_path),'role':'local_send_attempt_record_not_server_generation_count',
        'worker_dispatch_admitted_before_observed_fatal_signal':True})
    outcome={'case_id':case_id,'request_sha256':sha(request_path),'started_at_pacific':stamp(),
        'status':'response_error','empty_final':None,'truncated':False,'refusal':False,
        'final_text':None,'finish_reason':None,'fatal_delivery_error':True}
    try:
        raw=transport.send(case_id,request)
        if not isinstance(raw,bytes):raise TypeError('Transport must preserve exact raw response bytes')
        response_path=folder/'responses'/f'{key}.json';response_path.parent.mkdir(parents=True,exist_ok=True)
        with response_path.open('xb') as stream:stream.write(raw)
        outcome.update(interpret(raw),response_sha256=sha(response_path))
    except TransportError as error:
        outcome.update(status='http_error' if error.http_status is not None else 'transport_error',
            http_status=error.http_status,error_type=type(error).__name__)
        if error.body is not None:
            path=folder/'errors'/f'{key}.bin';path.parent.mkdir(parents=True,exist_ok=True)
            with path.open('xb') as stream:stream.write(error.body)
            outcome['error_body_sha256']=sha(path)
    except Exception as error:
        outcome.update(error_type=type(error).__name__,failure_category='local_guard_or_transport_interface_error')
    if outcome['fatal_delivery_error']:stop_signal.set()
    cleaned=postprocess(outcome.get('final_text')) if outcome['status']=='response' else ''
    outcome.update(completed_at_pacific=stamp(),postprocessed_nonempty=bool(cleaned),
        postprocessed_length=len(cleaned),postprocessed_sequence_sha256=hashlib.sha256(cleaned.encode()).hexdigest())
    save(folder/'outcomes'/f'{key}.json',outcome)
    return outcome


def summary(plan,records):
    observed=[r for r in records if r['status']!='not_dispatched']
    return {'at_pacific':stamp(),'condition_id':CONDITION,'role':'direct_unsealed_progress_lower_bound',
        'planned':len(plan['planned_case_ids']),'observed_outcomes':len(observed),
        'responses_saved':sum('response_sha256' in r for r in observed),
        'transport_errors':sum(r['status']=='transport_error' for r in observed),
        'http_errors':sum(r['status']=='http_error' for r in observed),
        'response_errors':sum(r['status']=='response_error' for r in observed),
        'empty_finals':sum(r.get('empty_final') is True for r in observed),
        'unknown_final_status':sum(r.get('empty_final') is None for r in observed),
        'truncations':sum(r.get('truncated') is True for r in observed),
        'refusals':sum(r.get('refusal') is True for r in observed),
        'format_constraint_errors':sum(r.get('format_constraint_error') is True for r in observed),
        'postprocessed_nonempty':sum(r.get('postprocessed_nonempty') is True for r in observed),
        'not_dispatched':sum(r['status']=='not_dispatched' for r in records)
            if {r['case_id'] for r in records}==set(plan['planned_case_ids']) else None,
        'biological_correctness_assessed':False}


def run_generation(plan,folder,transport,development=False):
    """Drain already sent calls after first delivery error; never retry a slot."""
    folder=Path(folder)
    folder.mkdir(parents=True,exist_ok=False)
    api=adapter(plan)
    ids=plan['development_case_ids'] if development else plan['planned_case_ids']
    if not ids or len(set(ids))!=len(ids):raise ValueError('Exact unique generation slots required')
    save(folder/'run_manifest.json',{'at_pacific':stamp(),'condition_id':CONDITION,'planned_case_ids':ids,
        'development_delivery_only':development,'plan_sha256':plan['plan_sha256'],
        'reference_targets_present':False,'maximum_attempts_per_case':1})
    results={};stop=False;cursor=0;stop_signal=threading.Event()
    concurrency=1 if development else plan['generation']['concurrency']
    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        pending={}
        while cursor<len(ids) or pending:
            while not stop and not stop_signal.is_set() and cursor<len(ids) and len(pending)<concurrency:
                i=cursor;ident=ids[i];cursor+=1
                pending[pool.submit(call_once,folder,ident,payload(plan,i,development=development),transport,api.postprocess,stop_signal)]=ident
            if not pending:break
            finished,_=wait(pending,return_when=FIRST_COMPLETED)
            for future in finished:
                ident=pending.pop(future);outcome=future.result();results[ident]=outcome
                if outcome['fatal_delivery_error'] or (development and not outcome['postprocessed_nonempty']):stop=True
            current(folder/'progress.json',summary({**plan,'planned_case_ids':ids},list(results.values())))
    for ident in ids:
        if ident not in results:
            row={'case_id':ident,'status':'not_dispatched','reason':'stopped_after_delivery_error_no_retry'}
            save(folder/'outcomes'/(hashlib.sha256(ident.encode()).hexdigest()+'.json'),row);results[ident]=row
    records=[results[i] for i in ids]
    save(folder/'terminal_records.json',records)
    files={str(p.relative_to(folder)):sha(p) for category in ('requests','responses','outcomes','errors','attempts')
        for p in sorted((folder/category).glob('*')) if p.is_file()}
    files.update({name:sha(folder/name) for name in ('terminal_records.json','run_manifest.json')})
    save(folder/'prediction_lock.json',{'condition_id':CONDITION,'planned_case_ids':ids,
        'plan_sha256':plan['plan_sha256'],'files_sha256':files,'reference_labels_opened':False})
    completion=summary({**plan,'planned_case_ids':ids},records)
    completion.update(role='sealed_one_attempt_generation_closure',closed_slots=len(ids),
        prediction_lock_sha256=sha(folder/'prediction_lock.json'),
        all_delivered=not stop and len(results)==len(ids),development_delivery_only=development,
        protein_format_success_count=sum(r.get('postprocessed_nonempty') is True for r in records),
        condition_id=CONDITION)
    save(folder/'completion.json',completion);current(folder/'progress.json',completion)
    return completion


def verify_generation(plan,folder):
    folder=Path(folder);completion=read(folder/'completion.json');lock=read(folder/'prediction_lock.json')
    if (completion['prediction_lock_sha256']!=sha(folder/'prediction_lock.json') or
        lock['condition_id']!=CONDITION or lock['plan_sha256']!=plan['plan_sha256'] or
        lock['planned_case_ids']!=plan['planned_case_ids']):raise ValueError('Generation lock identity mismatch')
    for name,digest in lock['files_sha256'].items():
        path=folder/name
        if Path(name).is_absolute() or '..' in Path(name).parts or path.is_symlink() or sha(path)!=digest:
            raise ValueError('Changed or foreign locked generation member')
    records=read(folder/'terminal_records.json')
    if [r['case_id'] for r in records]!=plan['planned_case_ids']:raise ValueError('Full slot order differs')
    for category in ('requests','responses','outcomes','errors','attempts'):
        actual={str(p.relative_to(folder)) for p in (folder/category).glob('*') if p.is_file()}
        expected={name for name in lock['files_sha256'] if name.startswith(category+'/')}
        if actual!=expected:raise ValueError('Unsealed generation artifact detected')
    for index,record in enumerate(records):
        key=hashlib.sha256(record['case_id'].encode()).hexdigest()
        request_name='requests/'+key+'.json';response_name='responses/'+key+'.json'
        if record['status']=='not_dispatched':
            if request_name in lock['files_sha256']:raise ValueError('Never-dispatched slot has a request record')
            continue
        if read(folder/request_name)!=payload(plan,index):raise ValueError('Request differs from frozen slot')
        if 'response_sha256' in record:
            if record['response_sha256']!=lock['files_sha256'].get(response_name):raise ValueError('Response identity differs')
            parsed=interpret((folder/response_name).read_bytes())
            if any(record.get(k)!=parsed.get(k) for k in parsed):raise ValueError('Raw response interpretation differs')
            clean=adapter(plan).postprocess(record.get('final_text')) if record['status']=='response' else ''
            if record['postprocessed_sequence_sha256']!=hashlib.sha256(clean.encode()).hexdigest():
                raise ValueError('Parsed sequence differs from sealed response')
    return records,completion


def fold_manifest(plan,folder):
    records,done=verify_generation(plan,folder)
    api=adapter(plan)
    observed=[r for r in records if r['status']!='not_dispatched']
    return api.fold_request_manifest(observed,plan['planned_case_ids'])


def aggregate(plan,folder,fold_records):
    records,done=verify_generation(plan,folder)
    api=adapter(plan)
    observed=[r for r in records if r['status']!='not_dispatched']
    result=api.evaluate(observed,plan['planned_case_ids'],fold_records)
    result.update(protocol_variant=CONDITION,plan_sha256=plan['plan_sha256'],
        generation_prediction_lock_sha256=done['prediction_lock_sha256'],
        declared_differences=plan['material_differences'],
        full_primary_metric_defined=bool(done['all_delivered'] and result['generation_terminal'] and
            result['complete_generation_metrics'] is not None and result['folding']['complete']),
        new_model_calls_by_aggregator=0,not_paper_native=True)
    result['format_validity_is_imposed_not_a_capability_score']=True
    result['generation_delivery_summary']=done
    result['residue_count_cutoff']=None
    result['constraint_scope']='Canonical nonempty tagged output; exact token-feasible closure within original uniform16K, no residue-count limit.'
    for name in ['observed_output_metrics','complete_generation_metrics']:
        if result.get(name) is not None:
            metrics=dict(result[name])
            result[name+'_with_source_format_diagnostic']=dict(metrics)
            metrics.pop('valid_rate',None)
            result[name]=metrics
    return result
