import copy
import unittest
from bound_request import PROMPT, DEVELOPMENT_PROMPTS, payload


def plan():
    return {'model':{'served_model_name':'Qwen/Qwen3.8-27B'},'generation':{
        'prompt':PROMPT,'max_tokens':16384,'temperature':.9,'top_p':.9,
        'top_k':50,'seed_base':42,'enable_thinking':False}}


class BoundChecks(unittest.TestCase):
    def test_all_1000_benchmark_prompts_and_seeds_preserve_original_condition(self):
        for i in range(1000):
            p=payload(plan(),i)
            self.assertEqual(p['messages'],[{'role':'user','content':PROMPT}])
            self.assertEqual(p['seed'],42+i)
            self.assertEqual(p['max_tokens'],16384)
            self.assertEqual(p['vllm_xargs']['p37_phase'],'benchmark')

    def test_fresh_neutral_development_does_not_replay_failed_pilot(self):
        for i in range(2):
            p=payload(plan(),i,development=True)
            self.assertEqual(p['messages'][0]['content'],DEVELOPMENT_PROMPTS[i])
            self.assertEqual(p['seed'],200042+i)
            self.assertNotIn(p['seed'],[100042,100043])

    def test_changed_prompt_sampling_and_budget_rejected(self):
        for key,value in [('prompt','select an enzyme'),('max_tokens',4096),
                          ('temperature',.1),('enable_thinking',True)]:
            p=plan();p['generation'][key]=value
            with self.assertRaises(ValueError):payload(p,0)
        for index in [-1,1000,True]:
            with self.assertRaises(ValueError):payload(plan(),index)
