"""Artificial recording transport/evaluator tests; no real model calls."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import io
import tarfile
import unittest
from unittest.mock import Mock,patch

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from p37_runner import (TransportError,aggregate,fold_manifest,interpret,payload,read,
    run_generation,sha,summary,verify_generation)
import worker
import p37_runner as runner_module
from admission import verify_folding_runtime

TASK=HERE.parent


def plan(n=3,concurrency=1):
    return {'planned_case_ids':[f'P37-UPG-{i:04d}' for i in range(n)],
        'development_case_ids':['P37-DEV-0000','P37-DEV-0001'],'plan_sha256':'artificial-plan',
        'contract_adapter':str(TASK/'contract_adapter.py'),'material_differences':['artificial test only'],
        'model':{'served_model_name':'RecordingModel'},
        'generation':{'prompt':'Generate a protein sequence with <protein> </protein>.','max_tokens':16384,
            'temperature':.9,'top_p':.9,'top_k':50,'seed_base':42,'concurrency':concurrency}}


def response(text='<protein>AAAAAAAA</protein>',finish='stop'):
    return json.dumps({'choices':[{'message':{'content':text},'finish_reason':finish}]}).encode()


class RecordingTransport:
    def __init__(self,values=None):self.calls=[];self.values=values or {}
    def send(self,case_id,request):
        self.calls.append((case_id,request))
        value=self.values.get(case_id,response())
        if isinstance(value,Exception):raise value
        return value


def folds(p,folder):
    return [{**r,'status':'success','mean_plddt':50.} for r in fold_manifest(p,folder)]


class GenerationTests(unittest.TestCase):
    def test_complete_locked_generation_and_full_proxy_denominator(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();client=RecordingTransport();folder=Path(td)/'generation'
            done=run_generation(p,folder,client)
            self.assertTrue(done['all_delivered']);self.assertEqual(done['responses_saved'],3)
            self.assertEqual([x[1]['seed'] for x in client.calls],[42,43,44])
            self.assertTrue(all(x[1]['max_tokens']==16384 for x in client.calls))
            records,_=verify_generation(p,folder)
            result=aggregate(p,folder,folds(p,folder))
            self.assertEqual(result['counts']['planned'],3)
            self.assertEqual(result['complete_generation_metrics']['valid_rate'],1.)
            self.assertEqual(result['complete_generation_metrics']['diversity'],.3333)
            self.assertEqual(result['complete_generation_metrics']['average_plddt'],50.)
            self.assertTrue(result['full_primary_metric_defined'])

    def test_nonprotein_final_is_counted_without_selective_replacement(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();client=RecordingTransport({p['planned_case_ids'][1]:response('ordinary text')})
            folder=Path(td)/'generation';run_generation(p,folder,client)
            result=aggregate(p,folder,folds(p,folder))
            self.assertEqual(len(client.calls),3)
            self.assertEqual(result['complete_generation_metrics']['valid_rate'],.6667)
            self.assertEqual(result['counts']['nonempty_postprocessed_outputs'],2)

    def test_invalid_JSON_is_unknown_final_and_stops_without_retry(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();client=RecordingTransport({p['planned_case_ids'][0]:b'not JSON'})
            folder=Path(td)/'generation';done=run_generation(p,folder,client)
            self.assertEqual(len(client.calls),1);self.assertEqual(done['not_dispatched'],2)
            self.assertEqual(done['empty_finals'],0);self.assertEqual(done['unknown_final_status'],1)
            result=aggregate(p,folder,[])
            self.assertFalse(result['full_primary_metric_defined'])
            self.assertIsNone(result['complete_generation_metrics'])

    def test_http_error_body_is_preserved_not_an_observed_empty_final(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();client=RecordingTransport({p['planned_case_ids'][0]:TransportError('artificial',503,b'busy')})
            folder=Path(td)/'generation';done=run_generation(p,folder,client)
            self.assertEqual(done['http_errors'],1);self.assertEqual(done['empty_finals'],0)
            self.assertEqual(len(list((folder/'errors').glob('*.bin'))),1)
            self.assertEqual(done['not_dispatched'],2)

    def test_outstanding_calls_drain_after_error_no_new_slot_sent(self):
        barrier=threading.Barrier(2)
        fatal_saved=threading.Event()
        original=runner_module.call_once
        class ConcurrentRecording(RecordingTransport):
            def send(self,case_id,request):
                self.calls.append((case_id,request));barrier.wait(timeout=5)
                if case_id.endswith('0000'):raise TransportError('artificial')
                if not fatal_saved.wait(timeout=5):raise AssertionError('Fatal outcome was never saved')
                return response()
        def ordered_call(*args):
            result=original(*args)
            if args[1].endswith('0000'):fatal_saved.set()
            return result
        with tempfile.TemporaryDirectory() as td:
            p=plan(4,2);client=ConcurrentRecording()
            with patch.object(runner_module,'call_once',ordered_call):
                done=run_generation(p,Path(td)/'generation',client)
            self.assertEqual(len(client.calls),2);self.assertEqual(done['responses_saved'],1)
            self.assertEqual(done['not_dispatched'],2);self.assertEqual(done['transport_errors'],1)

    def test_success_before_outstanding_failure_allows_pre_failure_third_send(self):
        barrier=threading.Barrier(2);third_issued=threading.Event();fatal_saved=threading.Event()
        original=runner_module.call_once
        class OrderedRecording(RecordingTransport):
            def send(self,case_id,request):
                self.calls.append((case_id,request))
                if case_id.endswith('0000'):
                    barrier.wait(timeout=5)
                    if not third_issued.wait(timeout=5):raise AssertionError('Expected pre-failure send')
                    raise TransportError('artificial')
                if case_id.endswith('0001'):
                    barrier.wait(timeout=5);return response()
                if case_id.endswith('0002'):
                    third_issued.set()
                    if not fatal_saved.wait(timeout=5):raise AssertionError('Expected fatal closure')
                    return response()
                raise AssertionError('Post-failure slot must not send')
        def ordered_call(*args):
            result=original(*args)
            if args[1].endswith('0000'):fatal_saved.set()
            return result
        with tempfile.TemporaryDirectory() as td:
            p=plan(4,2);client=OrderedRecording()
            with patch.object(runner_module,'call_once',ordered_call):
                done=run_generation(p,Path(td)/'generation',client)
            self.assertEqual(len(client.calls),3);self.assertEqual(done['responses_saved'],2)
            self.assertEqual(done['not_dispatched'],1);self.assertEqual(done['transport_errors'],1)

    def test_queued_worker_starting_after_fatal_signal_never_enters_transport(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();folder=Path(td);client=RecordingTransport();signal=threading.Event();signal.set()
            outcome=runner_module.call_once(folder,p['planned_case_ids'][0],payload(p,0),client,
                lambda text:text,signal)
            self.assertEqual(outcome['status'],'not_dispatched');self.assertEqual(client.calls,[])
            self.assertFalse((folder/'requests').exists());self.assertFalse((folder/'attempts').exists())
            self.assertEqual(len(list((folder/'outcomes').glob('*.json'))),1)

    def test_observed_empty_refusal_and_length_stop_are_separate(self):
        self.assertTrue(interpret(response(None))['empty_final'])
        self.assertTrue(interpret(response('text','length'))['truncated'])
        refused=json.dumps({'choices':[{'message':{'content':'no','refusal':'yes'},'finish_reason':'stop'}]}).encode()
        self.assertTrue(interpret(refused)['refusal'])
        malformed=json.dumps({'choices':[{'message':{'content':[]},'finish_reason':'stop'}]}).encode()
        self.assertIsNone(interpret(malformed)['empty_final'])

    def test_tampered_raw_response_blocks_evaluator(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();folder=Path(td)/'generation';run_generation(p,folder,RecordingTransport())
            next((folder/'responses').glob('*')).write_bytes(response('changed'))
            with self.assertRaisesRegex(ValueError,'locked generation member'):fold_manifest(p,folder)

    def test_extra_unsealed_response_blocks_evaluator(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();folder=Path(td)/'generation';run_generation(p,folder,RecordingTransport())
            (folder/'responses/foreign.json').write_bytes(response())
            with self.assertRaisesRegex(ValueError,'Unsealed generation'):fold_manifest(p,folder)

    def test_missing_or_failed_fold_keeps_full_eligibility(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();folder=Path(td)/'generation';run_generation(p,folder,RecordingTransport())
            results=folds(p,folder);results[1]={'case_id':results[1]['case_id'],'status':'error',
                'postprocessed_sequence_sha256':results[1]['postprocessed_sequence_sha256'],
                'folding_protocol':results[1]['folding_protocol']}
            result=aggregate(p,folder,results)
            self.assertEqual(result['folding']['errors'],1)
            self.assertEqual(result['counts']['fold_eligible'],3)
            self.assertIsNone(result['complete_generation_metrics']['average_plddt'])
            self.assertFalse(result['full_primary_metric_defined'])

    def test_foreign_or_wrong_sequence_fold_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();folder=Path(td)/'generation';run_generation(p,folder,RecordingTransport())
            result=folds(p,folder);result[0]['postprocessed_sequence_sha256']='bad'
            with self.assertRaisesRegex(ValueError,'locked generated output'):aggregate(p,folder,result)
            result=folds(p,folder);result[0]['case_id']='foreign'
            with self.assertRaisesRegex(ValueError,'Foreign'):aggregate(p,folder,result)

    def test_all_invalid_outputs_are_undefined_not_fabricated_zero_metrics(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();client=RecordingTransport({i:response('ordinary text') for i in p['planned_case_ids']})
            folder=Path(td)/'generation';run_generation(p,folder,client)
            result=aggregate(p,folder,[])
            self.assertIsNone(result['complete_generation_metrics']);self.assertFalse(result['full_primary_metric_defined'])

    def test_no_eligible_fold_uses_explicit_source_zero_convention(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();client=RecordingTransport({i:response('<protein>'+'A'*100+'</protein>') for i in p['planned_case_ids']})
            folder=Path(td)/'generation';run_generation(p,folder,client)
            self.assertEqual(fold_manifest(p,folder),[])
            result=aggregate(p,folder,[])
            self.assertEqual(result['counts']['fold_eligible'],0)
            self.assertEqual(result['complete_generation_metrics']['average_plddt'],0.)

    def test_existing_run_is_never_replayed(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();folder=Path(td)/'generation';client=RecordingTransport();run_generation(p,folder,client)
            with self.assertRaises(FileExistsError):run_generation(p,folder,client)
            self.assertEqual(len(client.calls),3)

    def test_unsealed_missing_outcomes_do_not_establish_zero_dispatch(self):
        self.assertIsNone(summary(plan(),[])['not_dispatched'])

    def test_development_gate_is_separate_and_stops_before_benchmark(self):
        with tempfile.TemporaryDirectory() as td:
            p=plan();client=RecordingTransport({p['development_case_ids'][0]:response('ordinary text')})
            done=run_generation(p,Path(td)/'development',client,development=True)
            self.assertFalse(done['all_delivered']);self.assertEqual(len(client.calls),1)
            self.assertTrue(done['development_delivery_only'])

    def test_each_model_phase_uses_fresh_root_project_audit_with_own_job_check(self):
        helper=Mock();helper.conservative_project_gpu_audit.return_value={'project_requested_GPUs':2}
        with patch.object(worker,'load',return_value=helper),patch.object(worker,'sha',return_value='pinned-digest'):
            p={'project_gpu_audit_helper':'pinned-root-helper','frozen_files_sha256':{'pinned-root-helper':'pinned-digest'}}
            self.assertEqual(worker.project_audit(p)['project_requested_GPUs'],2)
            worker.project_audit(p)
        self.assertEqual(helper.conservative_project_gpu_audit.call_count,2)
        helper.conservative_project_gpu_audit.assert_called_with(require_own_job=True)

    def test_evaluator_environment_excludes_Qwen_libraries_compilers_and_credentials(self):
        root=Path('/invented-portable-prefix')
        env=worker.folding_environment(root,{'CUDA_HOME':'/Qwen/cuda13','CUDACXX':'/Qwen/nvcc',
            'LD_LIBRARY_PATH':'/Qwen/libraries','PYTHONPATH':'/Qwen/modules','OPENAI_API_KEY':'artificial-secret',
            'CUDA_VISIBLE_DEVICES':'7','SLURM_JOB_ID':'artificial-job'})
        self.assertNotIn('CUDA_HOME',env);self.assertNotIn('CUDACXX',env);self.assertNotIn('OPENAI_API_KEY',env)
        self.assertEqual(env['LD_LIBRARY_PATH'],str(root/'python/lib')+':'+str(root/'site-packages/torch/lib'))
        self.assertEqual(env['PATH'],'/usr/local/bin:/usr/bin:/bin')
        self.assertEqual(env['CUDA_VISIBLE_DEVICES'],'7');self.assertEqual(env['SLURM_JOB_ID'],'artificial-job')

    def test_portable_archive_bytes_verified_before_use(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);archive=root/'runtime.tar';data=b'artificial package fixture'
            with tarfile.open(archive,'w') as tar:
                info=tarfile.TarInfo('python/fixture.txt');info.size=len(data);tar.addfile(info,io.BytesIO(data))
            document={'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
                'files':{'python/fixture.txt':{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}}}
            manifest=root/'manifest.json';manifest.write_text(json.dumps(document))
            extracted=verify_folding_runtime({'folding_runtime_manifest':str(manifest)},root/'extract')
            self.assertEqual((extracted/'python/fixture.txt').read_bytes(),data)
            with archive.open('ab') as stream:stream.write(b'tampered')
            with self.assertRaisesRegex(ValueError,'archive changed'):
                verify_folding_runtime({'folding_runtime_manifest':str(manifest)},root/'second')

    def test_portable_runtime_rejects_unsafe_members_before_extracting(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);archive=root/'runtime.tar'
            with tarfile.open(archive,'w') as tar:
                info=tarfile.TarInfo('../escape');info.size=1;tar.addfile(info,io.BytesIO(b'x'))
            document={'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
                'files':{'../escape':{'bytes':1,'sha256':hashlib.sha256(b'x').hexdigest()}}}
            manifest=root/'manifest.json';manifest.write_text(json.dumps(document))
            with self.assertRaisesRegex(ValueError,'Unexpected portable runtime'):
                verify_folding_runtime({'folding_runtime_manifest':str(manifest)},root/'extract')
            self.assertFalse((root/'escape').exists())


class NativeInterfaceRecordingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0,os.environ.get('P37_FOLD_SOURCE','/tmp/bio-p37-omegafold2-runtime-20261020/source'))
        import torch
        from omegafold import pipeline
        spec=importlib.util.spec_from_file_location('p37_recording_native_io',TASK/'engineering_20261020/runtime_adapter.py')
        native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
        cls.torch=torch;cls.pipeline=pipeline;cls.native=native

    def test_executable_fold_call_native_inputs_and_PDB_writer_on_artificial_tensors(self):
        from fold_worker import fold_once
        calls=[];torch=self.torch
        def recording(inputs,predict_with_confidence,fwd_cfg):
            calls.append((inputs,predict_with_confidence,fwd_cfg))
            n=len(inputs[0]['p_msa'][0])
            return {'confidence':torch.full((n,),.5),'final_atom_positions':torch.zeros((n,14,3))}
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td)/'fixture'
            result=fold_once('artificial','A'*8,folder,recording,self.pipeline,self.native,torch,'cpu')
            self.assertEqual(result['status'],'success');self.assertEqual(result['mean_plddt'],50.)
            self.assertTrue(result['forward_invocation_attempted'])
            self.assertEqual(len(calls),1);self.assertEqual(len(calls[0][0]),10)
            self.assertTrue(calls[0][1]);self.assertEqual(calls[0][2].subbatch_size,448)
            self.assertEqual(calls[0][2].num_recycle,10)
            self.assertTrue((folder/'prediction.pdb').stat().st_size>0)
            self.assertEqual(result['pdb_sha256'],sha(folder/'prediction.pdb'))

    def test_evaluator_exception_is_one_attempt_error_with_same_sequence_identity(self):
        from fold_worker import fold_once
        calls=[]
        def recording(*args,**kwargs):calls.append(1);raise RuntimeError('artificial evaluator error')
        with tempfile.TemporaryDirectory() as td:
            result=fold_once('artificial','A'*8,Path(td)/'fixture',recording,self.pipeline,self.native,self.torch,'cpu')
            self.assertEqual(result['status'],'error');self.assertEqual(len(calls),1)
            self.assertTrue(result['forward_invocation_attempted'])
            self.assertEqual(result['postprocessed_sequence_sha256'],hashlib.sha256(('A'*8).encode()).hexdigest())
        with tempfile.TemporaryDirectory() as td:
            result=fold_once('artificial','AX',Path(td)/'fixture',recording,self.pipeline,self.native,self.torch,'cpu')
            self.assertEqual(result['status'],'error');self.assertFalse(result['forward_invocation_attempted'])
            self.assertEqual(len(calls),1)


if __name__=='__main__':unittest.main()
