"""Dedicated P37 allocation: neutral fold gate, generation, then locked folds."""
from __future__ import annotations
import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request

from admission import validate,verify_folding_runtime
from p37_runner import TransportError,aggregate,current,read,run_generation,save,sha,stamp

HERE=Path(__file__).resolve().parent
PACKAGES={'vllm':'0.32.0','torch':'2.13.0','transformers':'5.17.0','triton':'3.7.1','flashinfer-python':'0.7.0.post1'}


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module


def project_audit(plan):
    path=plan['project_gpu_audit_helper']
    if sha(path)!=plan['frozen_files_sha256'][path]:raise ValueError('Root project GPU audit source changed')
    helper=load('p37_root_pinned_project_GPU_audit',plan['project_gpu_audit_helper'])
    return helper.conservative_project_gpu_audit(require_own_job=True)


def environment(common,local):
    env=common.environment(local)
    for name in list(env):
        if re.search(r'API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL',name,re.I) or name in {
            'SSH_AUTH_SOCK','NETRC','KUBECONFIG','GOOGLE_APPLICATION_CREDENTIALS',
            'PYTHONPATH','PYTHONHOME','VIRTUAL_ENV','OPENAI_BASE_URL','OPENAI_ORG_ID','OPENAI_PROJECT_ID'}:
            env.pop(name,None)
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',
        VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1',PIP_INDEX_URL='https://pypi.org/simple',
        PIP_EXTRA_INDEX_URL='',PIP_CONFIG_FILE='/dev/null')
    return env


def install_runtime(python,env,root):
    argv=[str(python),'-m','pip','install','--index-url','https://pypi.org/simple','--only-binary=:all:',
        '--break-system-packages','--upgrade',*[k+'=='+v for k,v in PACKAGES.items()],
        '--report',str(root/'pip_install_report.json')]
    with (root/'runtime_install.log').open('x') as log:
        subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=2400)
    with (root/'pip_check.log').open('x') as log:
        subprocess.run([str(python),'-m','pip','check'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)


class LocalTransport:
    def __init__(self,plan,identity_path,common):
        self.plan=plan;self.identity_path=identity_path;self.identity_sha=sha(identity_path);self.common=common
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def send(self,case_id,payload):
        if sha(self.identity_path)!=self.identity_sha:raise ValueError('Server identity changed')
        identity=read(self.identity_path)
        if (identity['job_id']!=os.environ['SLURM_JOB_ID'] or identity['hostname']!=socket.gethostname()
            or self.common.start_ticks(identity['pid'])!=identity['proc_start_ticks']
            or payload['model']!=self.plan['model']['served_model_name'] or payload['max_tokens']!=16384):
            raise ValueError('Request no longer matches the admitted own server')
        request=urllib.request.Request(self.plan['endpoint']+'/chat/completions',
            data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
        try:
            with self.opener.open(request,timeout=1800) as response:return response.read()
        except urllib.error.HTTPError as error:raise TransportError('HTTP response error',error.code,error.read()) from error
        except (urllib.error.URLError,TimeoutError,OSError) as error:raise TransportError(type(error).__name__) from error


def stop_server(server):
    if server is not None and server.poll() is None:
        os.killpg(server.pid,signal.SIGTERM)
        try:server.wait(timeout=60)
        except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait(timeout=10)


def folding_environment(root,inherited):
    env={k:v for k,v in inherited.items() if not re.search(r'API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL',k,re.I)}
    for key in ('CUDA_HOME','CUDA_PATH','CUDACXX','NVCC','CUDA_NVCC_EXECUTABLE','CMAKE_CUDA_COMPILER',
                'TORCH_CUDA_ARCH_LIST','LD_PRELOAD','CC','CXX','PYTHONHOME','PYTHONPATH','VIRTUAL_ENV'):
        env.pop(key,None)
    env.update(PYTHONHOME=str(root/'python'),PYTHONPATH=str(root/'site-packages')+':'+str(root/'source'),
        LD_LIBRARY_PATH=str(root/'python/lib')+':'+str(root/'site-packages/torch/lib'),PATH='/usr/local/bin:/usr/bin:/bin',
        PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
        OMP_NUM_THREADS='4',MKL_NUM_THREADS='4')
    return env


def run_folding(plan,args,mode,runtime_root):
    save(runtime_root/('private_GPU_audit_before_'+mode+'.json'),project_audit(plan))
    prepared=read(runtime_root/'folding_runtime_receipt.json')
    if prepared['plan_sha256']!=args.plan_sha256 or prepared['job_id']!=os.environ['SLURM_JOB_ID']:
        raise ValueError('Evaluator extraction belongs to another allocation')
    root=Path(prepared['local_root'])
    env=folding_environment(root,os.environ)
    command=[str(root/'python/bin/python3.10'),str(HERE/'fold_worker.py'),
        '--plan',str(args.plan),'--plan-sha256',args.plan_sha256,'--admission',str(args.admission),
        '--admission-sha256',args.admission_sha256,'--mode',mode]
    with (runtime_root/(mode+'.log')).open('x') as log:
        subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=plan['folding_timeout_seconds'])


def main():
    parser=argparse.ArgumentParser()
    for name in ('plan','admission'):parser.add_argument('--'+name,type=Path,required=True)
    for name in ('plan-sha256','admission-sha256'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--runtime-dir',type=Path)
    args=parser.parse_args()
    plan=validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256)
    runtime=HERE/'runtime';runtime.mkdir(exist_ok=True)
    common=load('p37_frozen_runtime_common',plan['runtime_common'])
    if args.runtime_dir is None:
        lock=(runtime/'allocation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (runtime/'allocation_started.json').exists():raise ValueError('No automatic allocation/model retry')
        save(runtime/'private_GPU_budget_audit.json',project_audit(plan))
        save(runtime/'allocation_started.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],
            'plan_sha256':args.plan_sha256,'admission_sha256':args.admission_sha256})
        if shutil.disk_usage('/tmp').free<48*1024**3:raise ValueError('At least48GiB private scratch required for both independent runtimes')
        for key in ('base_runtime','cuda_overlay'):
            if sha(plan[key]['path'])!=plan[key]['sha256']:raise ValueError('Qwen runtime artifact changed')
        local=Path(tempfile.mkdtemp(prefix='bio-p37-'+os.environ['SLURM_JOB_ID']+'-'))
        fold_root=verify_folding_runtime(plan,local/'folding')
        save(runtime/'folding_runtime_receipt.json',{'at_pacific':stamp(),'local_root':str(fold_root),
            'plan_sha256':args.plan_sha256,'job_id':os.environ['SLURM_JOB_ID'],
            'manifest_sha256':sha(plan['folding_runtime_manifest'])})
        with tarfile.open(plan['base_runtime']['path']) as archive:archive.extractall(local,filter='data')
        save(runtime/'runtime_archive_receipt.json',{'local_prefix':str(local),**common.apply_overlay(local)})
        env=environment(common,local);python=local/'python/bin/python3.12'
        install_runtime(python,env,runtime)
        argv=[str(python),str(Path(__file__).resolve()),*sys.argv[1:],'--runtime-dir',str(local)]
        os.execve(argv[0],argv,env)
    local=args.runtime_dir.resolve()
    if not local.name.startswith('bio-p37-'+os.environ['SLURM_JOB_ID']+'-'):raise ValueError('Private runtime ownership mismatch')
    lock=(runtime/'protocol.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    output=Path(plan['output_root'])
    if output.exists():raise FileExistsError('Preserve one-attempt P37 output directory')
    import importlib.metadata as metadata
    import torch
    observed={k:metadata.version(k) for k in PACKAGES}
    if any(observed[k].split('+')[0]!=v for k,v in PACKAGES.items()) or torch.cuda.device_count()!=1:
        raise ValueError('Pinned Qwen packages and exactly one visible GPU required')
    model_dir=common.validate_checkpoint(plan['model']['served_model_name'],plan['model']['revision'])
    save(runtime/'environment.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],
        'hostname':socket.gethostname(),'packages':observed,'visible_gpu_count':1,
        'model_directory':str(model_dir),'model_revision':plan['model']['revision'],
        'dtype':'bfloat16','tensor_parallel_size':1})
    from transformers import AutoTokenizer
    tokenizer=AutoTokenizer.from_pretrained(model_dir,local_files_only=True)
    from p37_runner import payload
    request=payload(plan,0)
    tokens=tokenizer.apply_chat_template(request['messages'],tokenize=True,add_generation_prompt=True,enable_thinking=False)
    if len(tokens)+16384>65536:raise ValueError('Exact prompt plus output exceeds context; never truncate')
    save(runtime/'context_preflight.json',{'at_pacific':stamp(),'prompt_tokens':len(tokens),
        'identical_unconditional_prompts':1002,'output_tokens':16384,'all_fit':True,'model_forwards':0})
    server=None
    try:
        current(runtime/'status.json',{'at_pacific':stamp(),'stage':'neutral_OmegaFold_delivery_gate',
            'job_id':os.environ['SLURM_JOB_ID'],'benchmark_dispatch_observed':False})
        run_folding(plan,args,'neutral_gate',runtime)
        if read(runtime/'neutral_folding_gate_completion.json')['passed'] is not True:raise ValueError('Folding delivery gate failed')
        save(runtime/'private_GPU_audit_before_Qwen_start.json',project_audit(plan))
        with socket.socket() as probe:probe.bind(('127.0.0.1',8477))
        command=[str(local/'python/bin/python3.12'),'-m','vllm.entrypoints.cli.main','serve',str(model_dir),
            '--served-model-name',plan['model']['served_model_name'],'--host','127.0.0.1','--port','8477',
            '--dtype','bfloat16','--tensor-parallel-size','1','--gpu-memory-utilization','0.95',
            '--max-model-len','65536','--max-num-seqs','4','--max-num-batched-tokens','8192',
            '--reasoning-parser','qwen3','--enable-prefix-caching']
        current(runtime/'status.json',{'at_pacific':stamp(),'stage':'starting_independent_P37_Qwen_server','job_id':os.environ['SLURM_JOB_ID']})
        with (runtime/'server.log').open('x') as log:
            server=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,cwd=local)
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));deadline=time.monotonic()+1800
        while time.monotonic()<deadline:
            if server.poll() is not None:raise RuntimeError('P37 server exited before readiness')
            try:
                with opener.open('http://127.0.0.1:8477/health',timeout=3) as response:
                    if response.status==200:break
            except (OSError,urllib.error.URLError):time.sleep(3)
        else:raise TimeoutError('Dedicated P37 readiness timeout')
        with opener.open(plan['endpoint']+'/models',timeout=5) as response:models=json.load(response)
        if [r['id'] for r in models['data']]!=[plan['model']['served_model_name']]:raise ValueError('Own served-model identity mismatch')
        identity=runtime/'server_identity.json'
        save(identity,{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'hostname':socket.gethostname(),
            'pid':server.pid,'proc_start_ticks':common.start_ticks(server.pid),'model':plan['model'],
            'server_command':command,'endpoint':plan['endpoint'],'plan_sha256':args.plan_sha256})
        transport=LocalTransport(plan,identity,common)
        output.mkdir()
        development=run_generation(plan,output/'development',transport,development=True)
        if not development['all_delivered'] or development['protein_format_success_count']!=2:
            raise RuntimeError('Exact two-case development delivery gate failed; no benchmark requests')
        save(runtime/'private_GPU_audit_before_benchmark_generation.json',project_audit(plan))
        current(runtime/'status.json',{'at_pacific':stamp(),'stage':'P37_generation_live','job_id':os.environ['SLURM_JOB_ID']})
        generation=run_generation(plan,output/'generation',transport)
        stop_server(server);server=None
        save(runtime/'own_Qwen_server_stopped_before_folding.json',{'at_pacific':stamp(),'own_server_stopped':True,
            'other_runtimes_changed':False})
        folds=[]
        if generation['all_delivered']:
            current(runtime/'status.json',{'at_pacific':stamp(),'stage':'P37_locked_outputs_folding_live','job_id':os.environ['SLURM_JOB_ID']})
            run_folding(plan,args,'benchmark',runtime)
            fold_root=output/'folding';closed=read(fold_root/'completion.json');fold_lock=read(fold_root/'prediction_lock.json')
            if closed['prediction_lock_sha256']!=sha(fold_root/'prediction_lock.json'):raise ValueError('Folding seal mismatch')
            for name,digest in fold_lock['files_sha256'].items():
                if Path(name).is_absolute() or '..' in Path(name).parts or sha(fold_root/name)!=digest:
                    raise ValueError('Changed folding artifact')
            folds=read(fold_root/'terminal_records.json')
        score=aggregate(plan,output/'generation',folds)
        score.update(at_pacific=stamp(),folding_prediction_lock_sha256=
            sha(output/'folding/prediction_lock.json') if generation['all_delivered'] else None)
        save(output/'scores.json',score)
        save(runtime/'terminal_receipt.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],
            'score_sha256':sha(output/'scores.json'),'full_primary_metric_defined':score['full_primary_metric_defined']})
        current(runtime/'status.json',{'at_pacific':stamp(),'stage':'P37_terminal_scored' if score['full_primary_metric_defined'] else 'P37_terminal_primary_metric_undefined',
            'job_id':os.environ['SLURM_JOB_ID'],'score_sha256':sha(output/'scores.json')})
    except Exception as error:
        current(runtime/'status.json',{'at_pacific':stamp(),'stage':'stopped_for_review','error_type':type(error).__name__,
            'error':str(error),'no_automatic_retry':True})
        raise
    finally:
        stop_server(server)


if __name__=='__main__':main()
