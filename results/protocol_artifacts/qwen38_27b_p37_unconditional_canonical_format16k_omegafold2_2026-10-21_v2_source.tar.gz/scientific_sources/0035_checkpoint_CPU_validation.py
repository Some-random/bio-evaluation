"""Exact tokenizer plus verbatim vLLM lifecycle, artificial fixtures only."""
from pathlib import Path
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import sys
import time
import types
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
sys.path.insert(0,str(HERE))


def main():
    if os.environ.get('CUDA_VISIBLE_DEVICES')!='':raise ValueError('Explicit CPU-only environment required')
    from tokenizers import Tokenizer
    import torch
    from protein_language import ConstraintError,ProteinLanguage,RequestConstraint,State,TokenVocabulary
    from bound_request import payload,PROMPT
    start=time.monotonic();checks={}
    tokenizer_path=Path('/dfs/scratch0/tchen/models/Qwen3.8-27B/tokenizer.json')
    expected='0997f410c57a1f4e53b09e4be8f4a172d90edd9564368fb0847030937229b9f3'
    vocab=TokenVocabulary.from_checkpoint_tokenizer(tokenizer_path,expected,{248044,248046})
    tokenizer=Tokenizer.from_file(str(tokenizer_path));size=248320
    for token,piece in vocab.pieces.items():
        if tokenizer.decode([token],skip_special_tokens=False).encode()!=piece:raise ValueError('Literal token decoder mismatch')
    checks['all_usable_token_pieces_match_pinned_decoder']=len(vocab.pieces)
    checks['finite_all_states_have_exact_shortest_completion_distance']=len(vocab.distance)==len(ProteinLanguage.states)
    checks['no_residue_count_cutoff']=True
    for text in ['<protein>ACDE</protein>','<protein>'+'ACDEFGHIKLMNPQRSTVWY'*25+'</protein>']:
        ids=tokenizer.encode(text,add_special_tokens=False).ids
        if tokenizer.decode(ids,skip_special_tokens=False)!=text:raise ValueError('Nonliteral roundtrip')
        constraint=RequestConstraint(vocab,len(ids)+1);prefix=[]
        for token in ids:
            masked=constraint(prefix,torch.zeros(size))
            if not torch.isfinite(masked[token]):raise ValueError('Feasible canonical token path was excluded')
            prefix.append(token)
        constraint.update(prefix+[248044])
        if not constraint.eos_seen:raise ValueError('Valid path did not terminate')
    checks['short_and_500_residue_artificial_actual_BPE_paths_preserved_at_exact_budget']=True
    # Reach the exact deadline with a single-byte body loop, then follow the
    # shortest tokenizer-supported closure. No prior response guides the rule.
    prefix=tokenizer.encode('<protein>A',add_special_tokens=False).ids
    constraint=RequestConstraint(vocab,16384);constraint.update(prefix)
    body_token=next(token for token,piece in vocab.pieces.items() if piece==b'A')
    room=16384-len(prefix)-vocab.distance[constraint.state]-1
    prefix += [body_token]*room;constraint.update(prefix)
    if body_token in vocab.allowed_next_ids(constraint.state,16384-len(prefix)):
        raise ValueError('Unclosable body loop remained admitted at deadline')
    while constraint.state.phase!='done':
        token=next(token for token,state in vocab.transitions[constraint.state].items()
                   if vocab.distance[state]==vocab.distance[constraint.state]-1)
        prefix.append(token);constraint.update(prefix)
    prefix.append(248044);constraint.update(prefix)
    if len(prefix)!=16384 or not constraint.eos_seen:raise ValueError('Uniform16K deadline closure differs')
    for fill in [0.,float('-inf'),float('nan')]:
        result=constraint(prefix,torch.full((size,),fill))
        if set(torch.where(torch.isfinite(result))[0].tolist())!=set(vocab.eos_ids):raise ValueError('Late EOS invariant failed')
    checks['exact_16384_token_deadline_forces_closure_and_EOS_no_residue_limit']=True
    checks['late_async_terminal_rows_are_finite_EOS_only_even_with_nan_upstream']=True
    source=ROOT/'.local/catalog_execution_2026-10-20/tasks/P34/available_execution_v1/source_api_harness.py'
    spec=importlib.util.spec_from_file_location('p37_CPU_verbatim_source_API',source)
    harness=importlib.util.module_from_spec(spec);spec.loader.exec_module(harness)
    source_dir=ROOT/'.local/catalog_execution_2026-10-20/tasks/P19/standalone_execution_v4/sources'
    scope=harness.load_verbatim_adapter(source_dir,torch)
    names=['vllm','vllm.v1','vllm.v1.sample','vllm.v1.sample.logits_processor'];saved={n:sys.modules.get(n) for n in names}
    try:
        for n in names:sys.modules[n]=types.ModuleType(n)
        sys.modules[names[-1]].AdapterLogitsProcessor=scope['AdapterLogitsProcessor']
        import p37_format_logits as plugin
    finally:
        for n,previous in saved.items():
            if previous is None:sys.modules.pop(n,None)
            else:sys.modules[n]=previous
    cfg=types.SimpleNamespace(speculative_config=None,model_config=types.SimpleNamespace(model=str(tokenizer_path.parent)))
    with patch.dict(os.environ,{'VLLM_USE_V2_MODEL_RUNNER':'0'}),patch.object(importlib.metadata,'version',return_value='0.32.0'):
        adapter=plugin.P37FormatLogitsProcessor(cfg,torch.device('cpu'),False)
    p={'model':{'served_model_name':'Qwen/Qwen3.8-27B'},'generation':{'prompt':PROMPT,'max_tokens':16384,'temperature':.9,'top_p':.9,'top_k':50,'seed_base':42,'enable_thinking':False}}
    def params(i=0):return types.SimpleNamespace(extra_args=payload(p,i)['vllm_xargs'],n=1,max_tokens=16384)
    a=[];b=[];B=scope['BatchUpdate'];D=scope['MoveDirectionality']
    adapter.update_state(B(batch_size=2,removed=[],added=[(0,params(),[],a),(1,params(1),[],b)],moved=[]))
    adapter.apply(torch.zeros((2,size)))
    a.extend(tokenizer.encode('<protein>AC',add_special_tokens=False).ids)
    adapter.update_state(None);adapter.apply(torch.zeros((2,size)))
    if adapter.req_info[0].func.state==adapter.req_info[1].func.state:raise ValueError('Live histories crossed')
    adapter.update_state(B(batch_size=2,removed=[],added=[],moved=[(0,1,D.SWAP)]));adapter.apply(torch.zeros((2,size)))
    adapter.update_state(B(batch_size=1,removed=[0],added=[],moved=[(1,0,D.UNIDIRECTIONAL)]));adapter.apply(torch.zeros((1,size)))
    adapter.update_state(B(batch_size=0,removed=[0],added=[],moved=[]))
    adapter.update_state(B(batch_size=1,removed=[],added=[(0,params(),[],[])],moved=[]));adapter.apply(torch.zeros((1,size)))
    if adapter.req_info[0].func.output_ids:raise ValueError('Slot reuse retained history')
    checks['verbatim_vllm032_live_history_swap_remove_move_and_slot_reuse']=True
    checks['hard_constraint_not_argmax_invariant']=adapter.is_argmax_invariant() is False
    for changed in [types.SimpleNamespace(extra_args={},n=1,max_tokens=16384),types.SimpleNamespace(extra_args=params().extra_args,n=1,max_tokens=4096)]:
        try:plugin.validate_request_params(changed)
        except ValueError:pass
        else:raise ValueError('Changed or missing request contract admitted')
    checks['missing_or_changed_prompt_phase_budget_contract_rejected']=True
    result={'stage':'unadmitted_CPU_pinned_tokenizer_and_verbatim_API_passed','checks':checks,'checks_passed':len(checks),
            'tokenizer_sha256':expected,'source_sha256':hashlib.sha256((HERE/'protein_language.py').read_bytes()).hexdigest(),
            'elapsed_seconds':time.monotonic()-start,'format_imposed_not_capability_score':True,'residue_count_cutoff':None,
            'model_calls':0,'model_weights_loaded':False,'GPU_allocations':0,'vllm_engine_imported':False}
    with (HERE/'checkpoint_CPU_validation.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result))


if __name__=='__main__':main()
