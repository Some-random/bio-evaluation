"""P37 folding preparation utilities. This module never runs a model forward.

Keep the released ten-cycle input and confidence conversion.  Build one
case at a time: the upstream list builder sorts by length and its batch
driver silently skips folding failures, so zip-by-position is unsafe.
"""
from __future__ import annotations

import hashlib
import math
from pathlib import Path

FOLDING_PROTOCOL = "SCIREASON_OMEGAFOLD_MODEL2_10CYCLE_V1"


def build_single_case_inputs(sequence: str, pipeline, output_dir: str | Path):
    """Construct CPU tensors only, preserving the identity of one input."""
    if not isinstance(sequence, str) or not 0 < len(sequence) < 100:
        raise ValueError("The frozen folding subset requires 1..99 residues")
    if any(c not in "ACDEFGHIKLMNPQRSTVWY-" for c in sequence):
        raise ValueError("Expected the frozen postprocessed residue alphabet")
    prepared = list(pipeline.list2inputs(
        [sequence], output_dir=str(output_dir), num_pseudo_msa=15,
        device="cpu", mask_rate=.12, num_cycle=10, deterministic=True,
    ))
    if len(prepared) != 1:
        raise RuntimeError("Native input builder did not return exactly one case")
    inputs, _unused_native_pdb_path = prepared[0]
    if len(inputs) != 10:
        raise RuntimeError("Native input builder changed its frozen cycle count")
    for cycle in inputs:
        if set(cycle) != {"p_msa", "p_msa_mask"}:
            raise RuntimeError("Unexpected native input fields")
        for tensor in cycle.values():
            if tuple(tensor.shape) != (16, len(sequence)) or tensor.device.type != "cpu":
                raise RuntimeError("Unexpected native CPU tensor shape or device")
    return inputs


def confidence_to_record(case_id: str, sequence: str, output: dict) -> dict:
    """Convert an already computed output; never call or select a model."""
    confidence = output.get("confidence")
    if confidence is None or tuple(confidence.shape) != (len(sequence),):
        raise ValueError("Expected one confidence value per residue")
    values = confidence.detach().cpu().tolist()
    if not all(isinstance(v, (int, float)) and math.isfinite(v) and 0 <= v <= 1 for v in values):
        raise ValueError("Residue confidence must be finite on the native 0..1 scale")
    # Use the native tensor reduction, retaining its dtype/rounding semantics.
    score = confidence.mean().item() * 100
    return {"case_id": case_id, "status": "success", "mean_plddt": score,
            "postprocessed_sequence_sha256": hashlib.sha256(sequence.encode()).hexdigest(),
            "folding_protocol": FOLDING_PROTOCOL}


def error_record(case_id: str, sequence: str, error: Exception) -> dict:
    """Retain per-case error identity instead of upstream's silent skip."""
    return {"case_id": case_id, "status": "error", "error_type": type(error).__name__,
            "postprocessed_sequence_sha256": hashlib.sha256(sequence.encode()).hexdigest(),
            "folding_protocol": FOLDING_PROTOCOL}
