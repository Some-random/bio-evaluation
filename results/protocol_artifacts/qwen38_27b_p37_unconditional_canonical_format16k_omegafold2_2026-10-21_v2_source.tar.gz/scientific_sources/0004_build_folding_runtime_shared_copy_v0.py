"""Copy the validated OmegaFold runtime to shared storage; no model forwards."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
SOURCE = Path('/tmp/bio-p37-omegafold2-runtime-20261020')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8*1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    target = HERE/'folding_runtime'
    if target.exists() or (HERE/'folding_runtime_manifest.json').exists():
        raise FileExistsError('Preserve the existing runtime and receipt')
    staging = Path(tempfile.mkdtemp(prefix='folding-runtime-build-',dir=HERE))
    for source, destination in [
        (SOURCE/'interpreters/cpython-3.10.18-linux-x86_64-gnu', staging/'python'),
        (SOURCE/'venv/lib/python3.10/site-packages', staging/'site-packages'),
        (SOURCE/'source', staging/'source')]:
        shutil.copytree(source,destination,symlinks=False)
    environment = {k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ('TOKEN','KEY','SECRET','PASSWORD','CREDENTIAL'))}
    environment.update(PYTHONHOME=str(staging/'python'),PYTHONPATH=str(staging/'site-packages')+':'+str(staging/'source'),
        PYTHONNOUSERSITE='1',CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    code = ('import torch,omegafold,importlib.metadata as m,json,platform;'
        'assert torch.__version__=="1.12.0+cu113";assert not torch.cuda.is_initialized();'
        'print(json.dumps({"python":platform.python_version(),"torch":torch.__version__,"numpy":m.version("numpy"),'
        '"biopython":m.version("biopython"),"huggingface-hub":m.version("huggingface-hub"),'
        '"omegafold_file":omegafold.__file__,"model_forwards":0}))')
    identity=json.loads(subprocess.check_output([str(staging/'python/bin/python3.10'),'-c',code],env=environment,text=True,timeout=180))
    files={str(p.relative_to(staging)):{'sha256':sha(p),'bytes':p.stat().st_size}
        for p in sorted(staging.rglob('*')) if p.is_file()}
    staging.rename(target)
    record={'stage':'shared_portable_OmegaFold_runtime_import_verified_no_forward',
        'at_pacific':datetime.datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        'job_id':os.environ.get('SLURM_JOB_ID'),'root':str(target),'identity':identity,
        'files':files,'file_count':len(files),'bytes':sum(x['bytes'] for x in files.values()),
        'model_forwards':0,'CUDA_initialized':False,'GPU_allocations':0,'source_runtime_modified':False,
        'launch_environment':{'PYTHONHOME':'<root>/python','PYTHONPATH':'<root>/site-packages:<root>/source'}}
    with (HERE/'folding_runtime_manifest.json').open('x') as handle:
        json.dump(record,handle,indent=2);handle.write('\n')
    print(json.dumps({k:record[k] for k in ['stage','job_id','file_count','bytes','model_forwards']}))


if __name__=='__main__':main()
