"""Pinned vLLM stop order at the exact original output cap; artificial only."""
import ast
import hashlib
import json
from pathlib import Path
import types
import unittest

HERE=Path(__file__).resolve().parent


class StopOrder(unittest.TestCase):
    def test_exact_official_EOS_precedes_length_at_16384(self):
        receipt=json.loads((HERE/'stop_order_source_receipt.json').read_text())
        source=HERE/'sources/vllm_v1_core_sched_utils.py';raw=source.read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(),receipt['sha256'])
        parsed=ast.parse(raw)
        body=[node for node in parsed.body if isinstance(node,ast.FunctionDef) and node.name=='check_stop']
        self.assertEqual(len(body),1)
        statuses=types.SimpleNamespace(FINISHED_STOPPED='stop',FINISHED_LENGTH_CAPPED='length')
        namespace={'Request':object,'RequestStatus':statuses}
        exec(compile(ast.Module(body=body,type_ignores=[]),str(source),'exec'),namespace)
        def request(last):
            return types.SimpleNamespace(pooling_params=None,
                sampling_params=types.SimpleNamespace(eos_token_id=248044,stop_token_ids=[248046]),
                output_token_ids=[last],num_output_tokens=16384,max_tokens=16384,num_tokens=16407)
        for eos in [248044,248046]:
            r=request(eos)
            self.assertTrue(namespace['check_stop'](r,65536))
            self.assertEqual(r.status,'stop')
        r=request(33)
        self.assertTrue(namespace['check_stop'](r,65536))
        self.assertEqual(r.status,'length')
