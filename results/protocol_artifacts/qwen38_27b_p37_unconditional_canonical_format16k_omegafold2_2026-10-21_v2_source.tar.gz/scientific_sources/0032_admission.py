"""Exact prospective P37 admission guards; no model or endpoint operations."""
import os
import fcntl
import subprocess
from pathlib import Path
import tarfile
from p37_runner import CONDITION,read,sha

HERE=Path(__file__).resolve().parent


def verify_previous_condition(plan,check_live=True):
    previous=plan['preserved_failed_condition']
    for name,digest in previous['files_sha256'].items():
        if sha(name)!=digest:raise ValueError('Preserved failed P37 condition changed')
    audit=read(previous['development_failure_audit'])
    terminal=read(previous['allocation_terminal_receipt'])
    if (audit.get('job_id')!='245226' or audit.get('benchmark_branch_entered') is not False
            or audit.get('stage')!='exact_development_condition_closed_failed_before_benchmark'
            or audit['development'].get('planned')!=2 or audit['development'].get('responses_saved')!=2
            or audit['development'].get('all_delivered') is not False
            or terminal.get('job_state')!='FAILED'
            or terminal.get('server_application_shutdown_complete_observed') is not True
            or not all(terminal.get('locks_free',{}).values())):
        raise ValueError('Exact failed development-before-benchmark boundary is required')
    if check_live:
        observed=subprocess.run(['/usr/local/bin/sacct','-j','245226','-n','-P','-o','JobID,State'],
            capture_output=True,text=True,check=True,timeout=30).stdout
        rows=[line.split('|') for line in observed.splitlines() if line]
        if not any(row[:2]==['245226','FAILED'] for row in rows):
            raise ValueError('Predecessor exact failed allocation is not terminal')
        for name in ['allocation.lock','protocol.lock']:
            with (Path(previous['runtime_root'])/name).open('a') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)


def validate(plan_path,plan_sha,admission_path,admission_sha,require_slurm=True):
    if sha(plan_path)!=plan_sha:raise ValueError('P37 plan hash changed')
    plan=read(plan_path)
    if (plan['condition_id']!=CONDITION or plan['planned']!=1000
            or plan['planned_case_ids']!=[f'P37-UPG-{i:04d}' for i in range(1000)]
            or plan['gpus_requested']!=1 or plan['generation']['max_tokens']!=16384
            or plan['generation']['prompt']!='Generate a protein sequence with <protein> </protein>.'
            or plan['generation']['enable_thinking'] is not False
            or plan.get('format_validity_is_imposed_not_a_capability_score') is not True
            or plan.get('residue_count_cutoff') is not None
            or plan.get('mandatory_model_runner')!='legacy_V1_explicit'
            or plan.get('custom_logits_processor')!='p37_format_logits:P37FormatLogitsProcessor'
            or plan.get('development_case_ids')!=['P37-BOUNDED-DEV-0000','P37-BOUNDED-DEV-0001']
            or plan['endpoint']!='http://127.0.0.1:8477/v1'
            or Path(plan['output_root']).resolve()!=HERE/'runtime/run_v1'):
        raise ValueError('Exact1000-slot uniform16K one-GPU P37 condition required')
    for name,digest in plan['frozen_files_sha256'].items():
        if Path(name).is_symlink() or sha(name)!=digest:raise ValueError('Frozen source or input changed: '+name)
    if sha(admission_path)!=admission_sha:raise ValueError('Root admission changed')
    admitted=read(admission_path)
    if (admitted.get('admitted') is not True or admitted.get('task_id')!='P37'
        or admitted.get('condition_id')!=CONDITION or admitted.get('plan_sha256')!=plan_sha
        or admitted.get('gpu_count')!=1 or admitted.get('project_gpu_ceiling')!=8
        or admitted.get('scope')!='neutral_gates_then1000_unconditional_canonical_format_once_then_locked_OmegaFold2'):
        raise ValueError('Separate exact root admission required before any model startup/forward')
    if sha(admitted['gpu_audit_receipt'])!=admitted['gpu_audit_receipt_sha256']:
        raise ValueError('Root GPU audit binding changed')
    if require_slurm and not os.environ.get('SLURM_JOB_ID'):raise ValueError('Slurm allocation required')
    verify_previous_condition(plan,check_live=require_slurm)
    plan['plan_sha256']=plan_sha
    return plan


def verify_folding_runtime(plan,destination):
    manifest=read(plan['folding_runtime_manifest'])
    archive=Path(manifest['archive'])
    if archive.stat().st_size!=manifest['archive_bytes'] or sha(archive)!=manifest['archive_sha256']:
        raise ValueError('Pinned portable evaluator archive changed')
    root=Path(destination)
    root.mkdir(exist_ok=False)
    with tarfile.open(archive) as tar:
        members=tar.getmembers()
        if (len(members)!=len(manifest['files']) or {m.name for m in members}!=set(manifest['files'])
            or any(not m.isfile() or Path(m.name).is_absolute() or '..' in Path(m.name).parts for m in members)):
            raise ValueError('Unexpected portable runtime members')
        tar.extractall(root,filter='data')
    for name,item in manifest['files'].items():
        path=root/name
        if (Path(name).is_absolute() or '..' in Path(name).parts or path.is_symlink()
            or not path.is_file() or path.stat().st_size!=item['bytes'] or sha(path)!=item['sha256']):
            raise ValueError('Pinned portable evaluator runtime changed')
    return root
