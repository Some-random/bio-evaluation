"""Explicit, priority-gated future submission. No waiting loop or automatic retry."""
import argparse
import fcntl
import subprocess
from recovery_common import HERE, ROOT, read, sha, stamp, validate_plan, write_once
from runtime_authority import capacity, validate_grants

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--submit',action='store_true',required=True)
    for name in ('plan-sha256','admission-sha256','priority-release-sha256'):
        p.add_argument('--'+name,required=True)
    a=p.parse_args()
    plan,_,_=validate_plan(HERE/'plan.json',a.plan_sha256)
    admission,release=HERE/'independent_admission.json',HERE/'root_priority_release.json'
    if sha(admission)!=a.admission_sha256 or sha(release)!=a.priority_release_sha256:
        raise PermissionError('Exact independent grant and root priority release required')
    validate_grants(a.plan_sha256,read(admission),read(release),a.admission_sha256)
    with (ROOT/'.local/evaluation_GPU_submission.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        # Time may have elapsed waiting for another submitter. Revalidate exact
        # pins and both grants inside the shared lock before accounting/claim.
        plan,_,_=validate_plan(HERE/'plan.json',a.plan_sha256)
        if sha(admission)!=a.admission_sha256 or sha(release)!=a.priority_release_sha256:
            raise PermissionError('Plan/grant changed while waiting for submission lock')
        validate_grants(a.plan_sha256,read(admission),read(release),a.admission_sha256)
        if (HERE/'submission_attempt.json').exists() or (HERE/'submission_receipt.json').exists():
            raise FileExistsError('Preserve prior or ambiguous submission; never automatically retry')
        old=subprocess.run(['sacct','-j','245811','-X','-n','-P','-o','JobIDRaw,State,ExitCode'],
            check=True,capture_output=True,text=True,timeout=30).stdout
        if not any(row.split('|')[:3] == ['245811','FAILED','1:0'] for row in old.splitlines()):
            raise PermissionError('Original allocation must remain terminal before submission')
        audit=capacity(plan,own=False)
        write_once(HERE/'private_GPU_audit_before_submission.json',audit)
        write_once(HERE/'submission_attempt.json',dict(at_utc=stamp(),plan_sha256=a.plan_sha256,
            admission_sha256=a.admission_sha256,root_priority_release_sha256=a.priority_release_sha256,
            requested_GPUs=1,automatic_retry=False))
        result=subprocess.run(['sbatch','--parsable','--export=NONE',str(HERE/'worker.sbatch'),
            a.plan_sha256,a.admission_sha256,a.priority_release_sha256],
            capture_output=True,text=True,timeout=60)
        value=result.stdout.strip().split(';')[0]
        if result.returncode or not value.isdigit():
            write_once(HERE/'submission_failure_or_ambiguity.json',dict(at_utc=stamp(),
                returncode=result.returncode,stdout=result.stdout,stderr=result.stderr,automatic_retry=False))
            raise RuntimeError('Submission failed or ambiguous; preserve attempt for review')
        write_once(HERE/'submission_receipt.json',dict(at_utc=stamp(),job_id=value,
            plan_sha256=a.plan_sha256,admission_sha256=a.admission_sha256,
            root_priority_release_sha256=a.priority_release_sha256,requested_GPUs=1))
        print(value)

if __name__=='__main__': main()
