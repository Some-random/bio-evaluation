"""Verify a future P37 fold-recovery result for independent CPU export review.

This is a read-only readiness verifier. It neither runs the old exporter nor
packages, scores, publishes, submits, cancels or rebinds any job. All original
generation values and folding structures are hash-checked as opaque bytes.
"""
import argparse
from pathlib import Path
import subprocess
import metadata_preflight as m


def scheduler_row(job, runner=subprocess.run):
    result = runner(['sacct', '-X', '-n', '-P', '-j', job,
                     '--format=JobIDRaw,State,ExitCode'],
                    check=True, capture_output=True, text=True, timeout=30)
    rows = [row.split('|')[:3] for row in result.stdout.splitlines()
            if row.split('|')[0] == job]
    if len(rows) != 1 or len(rows[0]) != 3:
        raise ValueError('One exact scheduler allocation row required')
    ident, state, exit_code = rows[0]
    return {'job_id': ident, 'state': state, 'exit_code': exit_code}


def verify(plan_sha, runner=subprocess.run):
    m.preflight(plan_sha, require_unstarted=False)
    runtime = m.HERE / 'runtime'
    required = [runtime / n for n in ('scores.json', 'terminal_receipt.json', 'scoring_attempt.json')]
    required += [runtime / 'folding' / n for n in
                 ('prediction_lock.json', 'completion.json', 'manifest.json', 'terminal_records.json')]
    for path in required:
        if path.is_symlink() or path.resolve() != path or not path.is_file():
            raise ValueError('Existing recovery terminal evidence is incomplete; no export is ready')
    submission_path = m.HERE / 'submission_receipt.json'
    admission_path, release_path = m.HERE / 'independent_admission.json', m.HERE / 'root_priority_release.json'
    for path in (submission_path, admission_path, release_path):
        if path.is_symlink() or path.resolve() != path or not path.is_file():
            raise ValueError('Exact future recovery authority/receipt missing')
    submission, admission, release = m.read(submission_path), m.read(admission_path), m.read(release_path)
    import runtime_authority
    runtime_authority.validate_grants(plan_sha, admission, release, m.sha(admission_path))
    if (submission.get('admission_sha256') != m.sha(admission_path)
            or submission.get('root_priority_release_sha256') != m.sha(release_path)):
        raise ValueError('Submitted recovery does not bind its exact source admission/release')
    job = submission.get('job_id')
    if not isinstance(job, str) or not job.isdigit():
        raise ValueError('Recorded recovery allocation identity missing')
    fold = runtime / 'folding'
    lock = m.read(fold / 'prediction_lock.json')
    members = lock['files_sha256']
    for name, digest in members.items():
        name_path = Path(name)
        if name_path.is_absolute() or '..' in name_path.parts:
            raise ValueError('Unsafe recovery folding member')
        m.regular(fold / name_path, digest)
    actual = {str(path.relative_to(fold)) for path in (fold / 'cases').rglob('*') if path.is_file()}
    if actual != {name for name in members if name.startswith('cases/')}:
        raise ValueError('Folding sealed inventory changed')
    score_sha = m.sha(runtime / 'scores.json')
    lock_sha = m.sha(fold / 'prediction_lock.json')
    claim = m.read(runtime / 'scoring_attempt.json')
    if (claim.get('recovery_plan_sha256') != plan_sha
            or claim.get('generation_prediction_lock_sha256') != m.GENERATION_LOCK_SHA
            or claim.get('folding_prediction_lock_sha256') != lock_sha):
        raise ValueError('Existing once-only score claim binds different evidence')
    evidence = dict(original_scheduler=scheduler_row('245811', runner),
        recovery_scheduler=scheduler_row(job, runner), submission=submission,
        terminal_receipt=m.read(runtime / 'terminal_receipt.json'),
        folding_lock=lock, folding_lock_sha256=lock_sha,
        folding_completion=m.read(fold / 'completion.json'),
        folding_manifest=m.read(fold / 'manifest.json'),
        frozen_eligible_rows=m.read(m.HERE / 'eligible_manifest.json')['eligible'],
        score=m.read(runtime / 'scores.json'), score_sha256=score_sha)
    result = m.validate_export_evidence(m.read(m.HERE / 'export_binding.json'), evidence)
    result.update(recovery_job_id=job, score_sha256=score_sha,
                  recovery_plan_sha256=plan_sha, old_export_245870_untouched=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--verify-existing-terminal', action='store_true', required=True)
    args = parser.parse_args()
    print(__import__('json').dumps(verify(args.plan_sha256), sort_keys=True))


if __name__ == '__main__':
    main()
