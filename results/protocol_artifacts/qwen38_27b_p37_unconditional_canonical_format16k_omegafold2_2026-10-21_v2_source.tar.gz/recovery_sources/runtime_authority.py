"""Reuse the reviewed v5 resource adapter; preserve the LPB priority hold."""
import os
import re
import subprocess
import time
import json
from recovery_common import HERE, ROOT, load, read, sha

ADAPTER = ROOT/'.local/resource_accounting_20261022/exact_external_checkpoint_jobs_adapter_v5.py'
ADAPTER_SHA = 'd7464059bdf95ab61fe0a2699cc4fb510252b9502aeb2c869d612f9d5d3d5f42'
PROOFS = [{'path': str(ROOT/'.local/resource_accounting_20261022/root_external_repaired_web_filter_job_review.json'),
           'sha256': 'f70f981e4ea599293abbdd1ae6f1ce864718d3aa1643980ced0d4fb067bc153c'},
          {'path': str(ROOT/'.local/goal_restore_20261024/root_external_web_jobs_249133_249410.json'),
           'sha256': '39596f2bb73d6d548a576400ed981b9a45fcad23b458891587ae46c58273bd2e'}]
BINDING = {'path': str(ROOT/'.local/goal_restore_20261024/additional_external_jobs_binding.json'),
           'sha256': 'ccde26c0227e496f82951ee350f3191eda2d6c0a6c7839b93e88b01b32f56ffd'}

def check_capacity_result(value, additional, own=False):
    count = value.get('project_requested_GPUs')
    if (type(count) is not int or count < 0 or count+additional > 8
            or type(value.get('project_requested_GPUs_with_addition')) is not int
            or value.get('project_requested_GPUs_with_addition') != count+additional
            or value.get('capacity_available') is not True
            or (own and value.get('own_allocation_verified') is not True)):
        raise ValueError('Fresh conservative project GPU capacity unavailable')
    return value

def capacity(plan, own=False, runner=None):
    if (plan['resource_adapter'] != str(ADAPTER) or plan['resource_adapter_sha256'] != ADAPTER_SHA
            or plan['additional_root_proofs'] != PROOFS or plan['additional_proof_binding'] != BINDING):
        raise ValueError('Identical preallocation/startup adapter and authority required')
    adapter = load('p37_recovery_resource_v5',ADAPTER,ADAPTER_SHA)
    value = adapter.capacity_audit(additional=0 if own else 1,override=False,runner=runner,
        require_own_job=own,additional_root_proofs=PROOFS,additional_proof_binding=BINDING)
    return check_capacity_result(value,0 if own else 1,own)

def validate_grants(plan_sha, grant, priority, admission_sha):
    if (grant.get('reviewer') not in {'/root','/root/independent_review'}
            or grant.get('approved') is not True or grant.get('plan_sha256') != plan_sha
            or grant.get('scope') != 'P37_existing1000_generation_440eligible_fold_score_only'
            or grant.get('new_generation_calls') != 0 or grant.get('requested_GPUs') != 1
            or priority.get('issuer') != '/root' or priority.get('approved') is not True
            or priority.get('plan_sha256') != plan_sha or priority.get('admission_sha256') != admission_sha
            or priority.get('LPB_priority_released_for_this_exact_recovery') is not True):
        raise PermissionError('Independent admission and explicit root LPB-priority release required')

def wait_submission_receipt(path, timeout=60, reader=read, now=time.monotonic, pause=time.sleep):
    """Bound the sbatch-receipt handoff only; never retry any submission or case."""
    deadline = now() + timeout
    while True:
        try:
            return reader(path)
        except (FileNotFoundError, json.JSONDecodeError):
            if now() >= deadline:
                raise PermissionError('Exact submission receipt was not finalized before bounded startup timeout')
            pause(min(0.1, max(0, deadline - now())))

def authorize_execution(plan_sha, admission_sha, release_sha):
    admission,release = HERE/'independent_admission.json',HERE/'root_priority_release.json'
    if sha(admission) != admission_sha or sha(release) != release_sha:
        raise PermissionError('Exact independent admission and priority release required')
    validate_grants(plan_sha,read(admission),read(release),admission_sha)
    own = os.environ.get('SLURM_JOB_ID'); submitted = wait_submission_receipt(HERE/'submission_receipt.json')
    if (not own or own == '245811' or str(submitted.get('job_id')) != own
            or submitted.get('plan_sha256') != plan_sha or submitted.get('admission_sha256') != admission_sha
            or submitted.get('root_priority_release_sha256') != release_sha):
        raise PermissionError('Exact future allocation receipt required')
    old = subprocess.run(['sacct','-j','245811','-X','-n','-P','-o','JobIDRaw,State,ExitCode'],
        check=True,capture_output=True,text=True,timeout=30).stdout
    if not any(row.split('|')[:3] == ['245811','FAILED','1:0'] for row in old.splitlines()):
        raise PermissionError('Original allocation must be terminal')
    current = subprocess.run(['scontrol','show','job','-o',own],check=True,
        capture_output=True,text=True,timeout=30).stdout
    for field,expected in [('WorkDir',str(ROOT)),('Command',str(HERE/'worker.sbatch'))]:
        match = re.search(r'(?:^|\s)'+field+r'=([^\s]+)',current)
        if not match or match.group(1) != expected:
            raise PermissionError('Actual recovery allocation command/workdir differs')
    return own
