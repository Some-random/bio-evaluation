"""Read-only P37 generation/export metadata checks. Never inspect sequence values.

This module has no scheduler mutation, model, scoring, packaging or publication
entry point. SHA verification streams original opaque bytes without parsing them.
The future model runner remains gated independently; this report grants nothing.
"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
OLD = TASK / 'bounded_format_proposal_v2'
GENERATION = OLD / 'runtime/run_v1/generation'
OLD_PLAN_SHA = 'fddaf859d7a1e0bcdb01ef6527b4a80ab8446f9ea9c170ebeb79b26826c253b7'
GENERATION_LOCK_SHA = 'f2ea1a423b4ccd65b9c79debb51bbae0cb900504cc3cae6734776c7e49fcb192'
ELIGIBILITY_SHA = '3acde419668cf9fa31a8d10dc1828648c0c76d4c19c77d914815d62b0133f6bb'


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            value.update(block)
    return value.hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def regular(path, digest):
    path = Path(path)
    if path.is_symlink() or path.resolve() != path or not path.is_file() or sha(path) != digest:
        raise ValueError('Pinned regular metadata/source or opaque sealed bytes changed')


def validate_generation_metadata(plan, lock, done, eligible):
    ids = plan.get('planned_case_ids')
    if (not isinstance(ids, list) or len(ids) != 1000 or len(set(ids)) != 1000
            or lock.get('planned_case_ids') != ids or lock.get('plan_sha256') != OLD_PLAN_SHA
            or done.get('prediction_lock_sha256') != GENERATION_LOCK_SHA
            or done.get('all_delivered') is not True
            or any(type(done.get(k)) is not int or done[k] != 1000
                for k in ('planned', 'closed_slots', 'observed_outcomes', 'responses_saved'))):
        raise ValueError('Complete original 1000-slot seal required')
    if (eligible.get('raw_sequences_included') is not False
            or eligible.get('old_generation_prediction_lock_sha256') != GENERATION_LOCK_SHA
            or eligible.get('old_terminal_records_sha256') != lock.get('files_sha256', {}).get('terminal_records.json')
            or any(type(eligible.get(k)) is not int or eligible[k] != n
                for k, n in [('eligible_count', 440), ('ineligible_count', 560), ('original_slots', 1000)])):
        raise ValueError('Exact existing typed length/hash projection required')
    rows = eligible.get('eligible')
    if not isinstance(rows, list) or len(rows) != 440:
        raise ValueError('Exactly440 frozen eligible outputs required')
    projected = []
    for row in rows:
        if (set(row) != {'case_id', 'length', 'postprocessed_sequence_sha256', 'folding_protocol'}
                or row['case_id'] not in ids or type(row['length']) is not int
                or not 1 <= row['length'] < 100
                or row['folding_protocol'] != 'SCIREASON_OMEGAFOLD_MODEL2_10CYCLE_V1'
                or not isinstance(row['postprocessed_sequence_sha256'], str)
                or re.fullmatch('[0-9a-f]{64}', row['postprocessed_sequence_sha256']) is None):
            raise ValueError('Unexpected payload or changed eligibility in metadata projection')
        projected.append(row['case_id'])
    if len(set(projected)) != 440 or [i for i in ids if i in set(projected)] != projected:
        raise ValueError('Frozen eligibility identities/order must be unique and unchanged')
    return projected


def validate_export_evidence(binding, evidence):
    """Validate future recovery output metadata, without rescoring or publishing.

    A prior FAILED generation allocation is legitimate preserved provenance. A
    separate exact successful recovery allocation and its sealed440 folds are
    required. This is deliberately different from the unusable old exporter.
    """
    if (binding.get('task_id') != 'P37' or binding.get('original_job_id') != '245811'
            or binding.get('old_CPU_export_job_id') != '245870'
            or binding.get('original_plan_sha256') != OLD_PLAN_SHA
            or binding.get('generation_prediction_lock_sha256') != GENERATION_LOCK_SHA
            or binding.get('new_generation_calls') != 0
            or binding.get('dispatch_or_publication_authorized') is not False):
        raise ValueError('Exact non-authorizing export binding required')
    old, future = evidence['original_scheduler'], evidence['recovery_scheduler']
    if old != {'job_id': '245811', 'state': 'FAILED', 'exit_code': '1:0'}:
        raise ValueError('Original FAILED generation job must remain recorded')
    submission, terminal = evidence['submission'], evidence['terminal_receipt']
    job = submission.get('job_id')
    if (not isinstance(job, str) or not job.isdigit() or job in {'245811', '245870'}
            or future != {'job_id': job, 'state': 'COMPLETED', 'exit_code': '0:0'}
            or terminal.get('job_id') != job
            or submission.get('plan_sha256') != binding['recovery_plan_sha256']
            or terminal.get('recovery_plan_sha256') != binding['recovery_plan_sha256']
            or terminal.get('original_plan_sha256') != OLD_PLAN_SHA
            or terminal.get('new_generation_calls') != 0):
        raise ValueError('Exact separately completed recovery allocation required')
    lock, done, manifest = evidence['folding_lock'], evidence['folding_completion'], evidence['folding_manifest']
    if (lock.get('original_plan_sha256') != OLD_PLAN_SHA
            or lock.get('recovery_plan_sha256') != binding['recovery_plan_sha256']
            or lock.get('generation_prediction_lock_sha256') != GENERATION_LOCK_SHA
            or manifest.get('eligible') != evidence['frozen_eligible_rows']
            or manifest.get('generation_prediction_lock_sha256') != GENERATION_LOCK_SHA
            or manifest.get('maximum_attempts_per_case') != 1
            or done.get('planned') != 440 or done.get('terminal') != 440
            or done.get('successes') != 440 or done.get('errors') != 0
            or done.get('prediction_lock_sha256') != evidence['folding_lock_sha256']):
        raise ValueError('All440 frozen eligible folds must be sealed without retries')
    score = evidence['score']
    if (score.get('plan_sha256') != OLD_PLAN_SHA
            or score.get('recovery_plan_sha256') != binding['recovery_plan_sha256']
            or score.get('generation_prediction_lock_sha256') != GENERATION_LOCK_SHA
            or score.get('folding_prediction_lock_sha256') != evidence['folding_lock_sha256']
            or score.get('full_primary_metric_defined') is not True
            or score.get('original_generation_unchanged') is not True
            or score.get('new_generation_calls') != 0
            or score.get('new_model_calls_by_aggregator') != 0
            or score.get('counts', {}).get('planned') != 1000
            or score.get('counts', {}).get('terminal_observed') != 1000
            or score.get('counts', {}).get('fold_eligible') != 440
            or terminal.get('score_sha256') != evidence['score_sha256']
            or terminal.get('full_primary_metric_defined') is not True):
        raise ValueError('Unchanged once-only complete score and its exact receipt required')
    if (len(evidence['frozen_eligible_rows']) != 440
            or len({row['case_id'] for row in evidence['frozen_eligible_rows']}) != 440):
        raise ValueError('Full440 identity projection required; no subset export')
    return {'ready_for_independent_export_review': True, 'generation_denominator': 1000,
            'folding_eligible': 440, 'new_model_calls': 0, 'new_scoring_calls': 0,
            'dispatch_or_publication_authorized': False}


def preflight(plan_sha, require_unstarted=True):
    regular(HERE / 'plan.json', plan_sha)
    plan = read(HERE / 'plan.json')
    if (plan.get('new_generation_calls') != 0 or plan.get('root_priority_release_required') is not True
            or plan.get('requested_GPUs') != 1 or plan.get('project_GPU_ceiling') != 8
            or plan.get('original_plan_sha256') != OLD_PLAN_SHA
            or plan.get('generation_prediction_lock_sha256') != GENERATION_LOCK_SHA):
        raise ValueError('Exact held existing-generation recovery only')
    for name, digest in plan['source_sha256'].items():
        regular(name, digest)
    regular(OLD / 'plan.json', OLD_PLAN_SHA)
    old = read(OLD / 'plan.json')
    for name, digest in old['frozen_files_sha256'].items():
        regular(name, digest)
    regular(GENERATION / 'prediction_lock.json', GENERATION_LOCK_SHA)
    regular(HERE / 'eligible_manifest.json', ELIGIBILITY_SHA)
    lock, done, eligible = read(GENERATION / 'prediction_lock.json'), read(GENERATION / 'completion.json'), read(HERE / 'eligible_manifest.json')
    validate_generation_metadata(old, lock, done, eligible)
    pending = []
    for name, digest in lock['files_sha256'].items():
        path = Path(name)
        if path.is_absolute() or '..' in path.parts:
            raise ValueError('Unsafe sealed member path')
        pending.append((GENERATION / path, digest))
    with ThreadPoolExecutor(max_workers=4) as executor:
        list(executor.map(lambda pair: regular(*pair), pending))
    for category in ('requests', 'responses', 'outcomes', 'errors', 'attempts'):
        actual = {str(p.relative_to(GENERATION)) for p in (GENERATION / category).glob('*') if p.is_file()}
        expected = {name for name in lock['files_sha256'] if name.startswith(category + '/')}
        if actual != expected:
            raise ValueError('Original sealed inventory changed')
    binding = read(HERE / 'export_binding.json')
    if binding['recovery_plan_sha256'] != plan_sha:
        raise ValueError('Recovery-aware exporter must bind this exact candidate')
    legacy_block = (OLD / 'runtime/run_v1/folding').exists() or (OLD / 'runtime/run_v1/scores.json').exists()
    new_runtime = HERE / 'runtime'
    if legacy_block or (require_unstarted and new_runtime.exists()):
        raise ValueError('Folding/scoring state exists; inspect once-only claims before further preparation')
    return {'stage': 'CPU_metadata_preflight_passed_no_dispatch', 'original_slots': 1000,
            'sealed_files': len(pending), 'eligible': 440, 'ineligible': 560,
            'sequence_payloads_parsed': False, 'labels_read': False, 'model_weights_read': False,
            'new_model_calls': 0, 'new_scoring_calls': 0, 'new_allocations': 0,
            'old_CPU_export_245870_untouched': True, 'GPU_priority_release_issued': False,
            'export_completed': False, 'dispatch_or_publication_authorized': False}
