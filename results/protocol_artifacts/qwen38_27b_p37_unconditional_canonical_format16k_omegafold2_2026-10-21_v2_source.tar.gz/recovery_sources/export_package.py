"""Disabled-until-reviewed CPU local packaging for the existing P37 condition.

No model, scorer, scheduler mutation, network publication or legacy export.
The exact-result guard performs read-only sacct allocation observations.
Actual protein/folding bytes are opaque archive members, never parsed here.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import shutil
import tempfile
import tarfile

HERE = Path(__file__).resolve().parent
RECOVERY = HERE.parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
OLD = RECOVERY.parent / 'bounded_format_proposal_v2'


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            value.update(block)
    return value.hexdigest()


def read(path): return json.loads(Path(path).read_bytes())


def read_exact(path, digest):
    payload = Path(path).read_bytes()
    if hashlib.sha256(payload).hexdigest() != digest:
        raise ValueError('Metadata changed before its exact byte read')
    return json.loads(payload)


def save(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False); stream.write('\n')


def regular(path, digest):
    path = Path(path)
    if path.is_symlink() or path.resolve() != path or not path.is_file() or sha(path) != digest:
        raise ValueError('Exact regular packaging source or reviewed evidence changed')


def load(name, path, digest):
    regular(path, digest)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def validate_result_review(review, config, evidence):
    if (review.get('reviewer') not in {'/root', '/root/independent_review', '/root/priority_runtime_review'}
            or review.get('owner') != '/root/p37_offline_repair'
            or review.get('approved') is not True
            or review.get('scope') != 'P37_exact_complete_recovery_result_local_packaging_only'
            or review.get('recovery_plan_sha256') != config['recovery_plan_sha256']
            or review.get('score_sha256') != evidence['score_sha256']
            or review.get('original_generation_prediction_lock_sha256') != config['generation_prediction_lock_sha256']
            or review.get('recovery_job_id') != evidence['recovery_job_id']
            or review.get('complete_generation_denominator') != 1000
            or review.get('complete_eligible_fold_count') != 440
            or review.get('new_generation_or_scoring_authorized') is not False
            or review.get('publication_authorized') is not False):
        raise PermissionError('Independent exact completed-result local packaging review required')


def select_public_sources(files, root=ROOT):
    """Source-code-only whitelist; operational identities and weights stay local."""
    output, omitted = {}, []
    for index, name in enumerate(sorted(files)):
        path = Path(name)
        if (not path.is_relative_to(root) or path.suffix not in {'.py', '.sbatch', '.md'}
                or path.name == 'project_gpu_audit_20261021.py'
                or 'resource_accounting_' in str(path) or 'private_' in path.name):
            omitted.append({'name': path.name, 'sha256': files[name]}); continue
        regular(path, files[name])
        output['scientific_sources/%04d_%s' % (index, path.name)] = path
    return output, omitted


def recovery_public_sources(config):
    """Use the exact configured source whitelist; reject any unexpected sibling."""
    allowed = config['recovery_public_source_names']
    omitted = config['recovery_nonpublic_source_names']
    names = allowed + omitted
    if (len(names) != len(set(names)) or not allowed
            or any(Path(n).name != n or Path(n).suffix != '.py' for n in names)
            or any('private' in name for name in allowed)):
        raise ValueError('Exact nonprivate recovery source whitelist required')
    actual = {path.name for path in RECOVERY.glob('*.py')}
    if actual != set(names):
        raise ValueError('Unlisted recovery source exists; never archive it implicitly')
    output = {}
    for name in names:
        path = RECOVERY / name
        regular(path, config['source_sha256'][str(path)])
        if name in allowed: output['recovery_sources/' + name] = path
    return output



def licensed_public_sources(config):
    """Require exact pinned licenses/attribution for archived upstream code."""
    expected = {'licenses/SciReason_LICENSE', 'licenses/OmegaFold_LICENSE',
                'licenses/vLLM_LICENSE', 'licenses/ATTRIBUTION.md'}
    members = config['public_license_members']
    if set(members) != expected:
        raise ValueError('All three upstream licenses and explicit attribution required')
    output = {}
    for name, source in members.items():
        path = Path(source)
        if path != HERE / name:
            raise ValueError('Exact local public license path required')
        regular(path, config['source_sha256'][str(path)])
        output[name] = path
    return output



def new_snapshot_root(config):
    """Use one private local CPU scratch directory; retain all exact byte checks."""
    if config.get('opaque_snapshot_parent') != '/tmp':
        raise ValueError('Exact reviewed local snapshot parent required')
    parent = Path('/tmp')
    if parent.is_symlink() or parent.resolve() != parent or not parent.is_dir():
        raise ValueError('Exact regular local scratch parent required')
    if shutil.disk_usage(parent).free < 8 * 1024**3:
        raise ValueError('Conservative eight-GiB local snapshot space required')
    return Path(tempfile.mkdtemp(prefix='p37-reviewed-opaque-snapshots-', dir=parent))


def snapshot_members(members, expected, directory):
    """Copy one opaque byte snapshot and compare each copy to the admitted hash."""
    if set(members) != set(expected): raise ValueError('Every archived member needs an exact expected digest')
    directory.mkdir(parents=True, exist_ok=False)
    output = {}
    for index, (name, source) in enumerate(sorted(members.items())):
        regular(source, expected[name])
        payload = source.read_bytes()
        if hashlib.sha256(payload).hexdigest() != expected[name]:
            raise ValueError('Input changed while taking its verified byte snapshot')
        target = directory / ('%06d_' % index + source.name)
        with target.open('xb') as stream: stream.write(payload)
        regular(target, expected[name]); output[name] = target
    return output


def verify_archive(path, expected):
    """Verify actual archive payloads and the helper manifest, not helper claims."""
    with tarfile.open(path, 'r:gz') as archive:
        names = archive.getnames()
        if (len(names) != len(set(names)) or set(names) != set(expected) | {'publication_manifest.json'}
                or any(not entry.isfile() for entry in archive.getmembers())):
            raise ValueError('Exact unique regular archive member set required')
        manifest = json.load(archive.extractfile('publication_manifest.json'))['files']
        if set(manifest) != set(expected): raise ValueError('Archive manifest identities changed')
        for name, digest in expected.items():
            data = archive.extractfile(name).read()
            if (hashlib.sha256(data).hexdigest() != digest
                    or manifest[name]['sha256'] != digest or manifest[name]['bytes'] != len(data)):
                raise ValueError('Archive payload differs from independently verified snapshot')


def capture_dynamic_metadata():
    runtime = RECOVERY / 'runtime'; generation = OLD / 'runtime/run_v1/generation'
    paths = [generation / n for n in ('prediction_lock.json', 'completion.json')]
    paths += [runtime / 'folding' / n for n in
              ('prediction_lock.json', 'completion.json', 'manifest.json', 'terminal_records.json')]
    paths += [runtime / n for n in ('scores.json', 'scoring_attempt.json', 'terminal_receipt.json')]
    paths += [RECOVERY / n for n in ('submission_receipt.json', 'independent_admission.json', 'root_priority_release.json')]
    return {str(path): sha(path) for path in paths}


def report_text(plan, score):
    metrics, folds, counts = score['complete_generation_metrics'], score['folding'], score['counts']
    if counts['planned'] != 1000 or counts['fold_eligible'] != 440:
        raise ValueError('Full generation and frozen eligible-fold denominators required')
    return ('# NatureLM-style unconditional generation\n\n'
        f"All 1,000 saved Qwen3.8-27B generations are retained. Mean length: {metrics['average_length']:.2f} residues; "
        f"released-code diversity: {metrics['diversity']:.4f}. OmegaFold2 completed {folds['successes']}/440 eligible folds; "
        f"mean predictor confidence: {metrics['average_plddt']:.2f}/100.\n\n"
        'The released evaluator folds outputs shorter than 100 residues: 440 are eligible and 560 are outside that gate. '
        'The generation denominator remains 1,000. A canonical tagged-output decoder imposed formatting without a residue-count cutoff; '
        'format validity is imposed rather than a model capability score. The original generation job failed after sealing and before folding; '
        'a separately admitted recovery used those same immutable outputs.\n\n'
        'This is an available-code adaptation. NatureLM reports 50% identity clustering, whereas this released-code diversity uses 99% '
        'equal-length positional clustering. Predictor confidence is not experimental function or measured structure. No generation was repeated.\n')


def prepare(config_sha, review_sha):
    regular(HERE / 'config.json', config_sha); config = read_exact(HERE / 'config.json', config_sha)
    if (config.get('scope') != 'CPU_local_package_only_after_complete_reviewed_P37_recovery'
            or config.get('new_model_calls') != 0 or config.get('new_scoring_calls') != 0
            or config.get('publish_or_submit') is not False):
        raise PermissionError('Only exact non-dispatching local packaging supported')
    for name, digest in config['source_sha256'].items(): regular(name, digest)
    public_recovery_sources = recovery_public_sources(config)
    public_licenses = licensed_public_sources(config)
    sys.path.insert(0, str(RECOVERY))
    guard = load('p37_recovery_aware_export_verify', RECOVERY / 'export_verify.py',
                 config['source_sha256'][str(RECOVERY / 'export_verify.py')])
    # Capture before validation, then use only exact copies of those validated
    # bytes. Any change between capture, validation and snapshot is rejected.
    captured = capture_dynamic_metadata()
    evidence = guard.verify(config['recovery_plan_sha256'])
    review_path = HERE / 'independent_complete_result_review.json'
    regular(review_path, review_sha)
    validate_result_review(read_exact(review_path, review_sha), config, evidence)
    old = read_exact(OLD / 'plan.json', config['source_sha256'][str(OLD / 'plan.json')])
    runtime = RECOVERY / 'runtime'; generation = OLD / 'runtime/run_v1/generation'; fold = runtime / 'folding'
    stage = HERE / 'stage'
    if stage.exists() or (HERE / 'packaging_attempt.json').exists():
        raise FileExistsError('Preserve every prior or ambiguous packaging attempt')
    save(HERE / 'packaging_attempt.json', dict(at_utc=datetime.now(timezone.utc).isoformat(),
        config_sha256=config_sha, independent_complete_result_review_sha256=review_sha,
        recovery_plan_sha256=config['recovery_plan_sha256'], score_sha256=evidence['score_sha256'],
        model_calls=0, scoring_calls=0, publication=False))
    stage.mkdir()
    snapshot_root = new_snapshot_root(config)
    save(HERE / 'opaque_snapshot_location.json', dict(root=str(snapshot_root), config_sha256=config_sha,
        role='private_CPU_opaque_snapshots_only_not_publication', mode_octal='0700',
        model_calls=0, scoring_calls=0, publication=False))
    packer = load('p37_existing_opaque_archive_helper', Path(config['package_helper']),
                  config['source_sha256'][config['package_helper']])
    scanner = load('p37_existing_secret_scanner', Path(config['secret_scanner']),
                   config['source_sha256'][config['secret_scanner']])
    sources, omitted = select_public_sources(old['frozen_files_sha256'])
    sources.update(public_recovery_sources)
    sources.update(public_licenses)
    sources['recovery_sources/export_package.py'] = Path(__file__).resolve()
    condition = stage / 'public_condition.json'
    save(condition, {**{key: old[key] for key in ('task_id', 'run_id', 'condition_id', 'generation',
        'folding_settings', 'material_differences', 'format_validity_is_imposed_not_a_capability_score')},
        'original_plan_sha256': config['original_plan_sha256'],
        'generation_prediction_lock_sha256': config['generation_prediction_lock_sha256'],
        'recovery_plan_sha256': config['recovery_plan_sha256'],
        'score_sha256': evidence['score_sha256'], 'omitted_private_or_noncode_sources': omitted,
        'generation_denominator': 1000, 'eligible_folds': 440,
        'unrelated_account_metadata_or_weights_included': False})
    sources['public_condition.json'] = condition
    trajectories, trajectory_expected = {}, {}
    for label, folder in [('generation', generation), ('folding', fold)]:
        regular(folder / 'prediction_lock.json', captured[str(folder / 'prediction_lock.json')])
        lock = read_exact(folder / 'prediction_lock.json', captured[str(folder / 'prediction_lock.json')])
        trajectories.update({label + '/' + name: folder / name for name in lock['files_sha256']})
        trajectory_expected.update({label + '/' + name: digest for name, digest in lock['files_sha256'].items()})
        for name in ('prediction_lock.json', 'completion.json'):
            trajectories[label + '/' + name] = folder / name
            trajectory_expected[label + '/' + name] = captured[str(folder / name)]
    source_expected = {}
    pinned_sources = {**old['frozen_files_sha256'], **config['source_sha256']}
    for name, source in sources.items():
        source_expected[name] = sha(condition) if source == condition else pinned_sources[str(source)]
    source_snapshot = snapshot_members(sources, source_expected, snapshot_root / 'source_snapshot')
    trajectory_snapshot = snapshot_members(trajectories, trajectory_expected, snapshot_root / 'trajectory_snapshot')
    # Score/report copies are bound to the exact pre-validation score hash.
    regular(runtime / 'scores.json', captured[str(runtime / 'scores.json')])
    if captured[str(runtime / 'scores.json')] != evidence['score_sha256']:
        raise ValueError('Captured score differs from reviewed score')
    run = old['run_id']; prefix = 'results/runs/' + run + '/'
    source_name = 'results/protocol_artifacts/' + run + '_source.tar.gz'
    trajectories_name = 'results/trajectory_archives/' + run + '_trajectories.tar.gz'
    source_receipt = packer.package(stage / source_name, source_snapshot, scanner)
    trajectory_receipt = packer.package(stage / trajectories_name, trajectory_snapshot, scanner)
    verify_archive(stage / source_name, source_expected)
    verify_archive(stage / trajectories_name, trajectory_expected)
    originals = {'scores.json': runtime / 'scores.json', 'generation_completion.json': generation / 'completion.json',
        'generation_prediction_lock.json': generation / 'prediction_lock.json',
        'folding_prediction_lock.json': fold / 'prediction_lock.json'}
    original_snapshot = snapshot_members(originals,
        {name:captured[str(source)] for name,source in originals.items()}, snapshot_root / 'result_snapshot')
    for name, source in original_snapshot.items():
        target = stage / (prefix + name); target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(source.read_bytes())
        regular(target, captured[str(originals[name])])
    report = report_text(old, read_exact(original_snapshot['scores.json'], evidence['score_sha256']))
    for name in ('reports/P37_CANONICAL_FORMAT_PROXY_RESULT.md', prefix + 'README.md'):
        target = stage / name; target.parent.mkdir(parents=True, exist_ok=True); target.write_text(report)
    save(stage / (prefix + 'artifact_manifest.json'), dict(task_id='P37', run_id=run,
        score_sha256=evidence['score_sha256'], original_plan_sha256=config['original_plan_sha256'],
        recovery_plan_sha256=config['recovery_plan_sha256'], generation_denominator=1000, eligible_folds=440,
        source_archive={'path': source_name, 'sha256': source_receipt['sha256']},
        trajectory_archive={'path': trajectories_name, 'sha256': trajectory_receipt['sha256']},
        format_validity_is_imposed_not_a_capability_score=True, native_NatureLM_equivalence=False))
    paths = {str(path.relative_to(stage)): sha(path) for path in stage.rglob('*')
             if path.is_file() and path != condition}
    expected = {prefix + n for n in (*originals, 'README.md', 'artifact_manifest.json')}
    expected.update({source_name, trajectories_name, 'reports/P37_CANONICAL_FORMAT_PROXY_RESULT.md'})
    if set(paths) != expected: raise ValueError('Exact nine-path local candidate required')
    # Sources, authority and original sealed inputs remain immutable through
    # candidate receipt creation; no second scorer/model operation occurs.
    regular(HERE / 'config.json', config_sha); regular(review_path, review_sha)
    for name, digest in config['source_sha256'].items(): regular(name, digest)
    for name, digest in captured.items(): regular(name, digest)
    for name, source in sources.items(): regular(source, source_expected[name])
    for name, source in trajectories.items(): regular(source, trajectory_expected[name])
    for name, digest in paths.items(): regular(stage / name, digest)
    candidate = dict(at_utc=datetime.now(timezone.utc).isoformat(), role='local_candidate_only_not_published',
        task_id='P37', config_sha256=config_sha, recovery_plan_sha256=config['recovery_plan_sha256'],
        independent_complete_result_review_sha256=review_sha, files_sha256=paths,
        source_sha256=config['source_sha256'], generation_denominator=1000, eligible_folds=440,
        score_sha256=evidence['score_sha256'], model_calls=0, scoring_calls=0, publication=False)
    save(HERE / 'candidate.json', candidate)
    return {'stage': 'local_P37_candidate_ready_for_separate_publication_review',
            'paths': len(paths), 'model_calls': 0, 'scoring_calls': 0, 'published': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare-local-only', action='store_true', required=True)
    parser.add_argument('--config-sha256', required=True)
    parser.add_argument('--independent-result-review-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(args.config_sha256, args.independent_result_review_sha256), sort_keys=True))


if __name__ == '__main__': main()
