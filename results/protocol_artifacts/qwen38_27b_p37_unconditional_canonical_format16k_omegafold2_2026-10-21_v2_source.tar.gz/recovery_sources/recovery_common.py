"""Pure metadata/seal checks for the existing P37 generation; no model calls."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
OLD = HERE.parent / 'bounded_format_proposal_v2'
GENERATION = OLD / 'runtime/run_v1/generation'
OLD_PLAN_SHA = 'fddaf859d7a1e0bcdb01ef6527b4a80ab8446f9ea9c170ebeb79b26826c253b7'
OLD_ADMISSION_SHA = 'e79a8cc51bdbcc3777d9949cf941b1b19541cc0c41dfe03460ce31718517fd68'
GENERATION_LOCK_SHA = 'f2ea1a423b4ccd65b9c79debb51bbae0cb900504cc3cae6734776c7e49fcb192'

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(8 * 1024**2), b''): h.update(block)
    return h.hexdigest()

def read(path): return json.loads(Path(path).read_bytes())
def stamp(): return datetime.now(timezone.utc).isoformat()

def write_once(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as output:
        json.dump(value, output, sort_keys=True, indent=2, allow_nan=False); output.write('\n')
        output.flush()
        os.fsync(output.fileno())
    directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)

def load(name, path, digest):
    path = Path(path)
    if path.is_symlink() or path.resolve() != path or sha(path) != digest:
        raise ValueError('Pinned regular source changed')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); sys.modules[name] = module
    spec.loader.exec_module(module); return module

def eligible_metadata(records, expected_ids):
    """Return only the saved length/hash projection; no sequence text."""
    if [r.get('case_id') for r in records] != expected_ids:
        raise ValueError('Exact original slot order required')
    output = []
    for row in records:
        length = row.get('postprocessed_length')
        if (row.get('status') != 'response' or type(length) is not int or length < 1
                or row.get('postprocessed_nonempty') is not True
                or row.get('fatal_delivery_error') is not False or row.get('truncated') is not False
                or not re.fullmatch('[0-9a-f]{64}', row.get('postprocessed_sequence_sha256', ''))):
            raise ValueError('Complete original generation required')
        if length < 100:
            output.append(dict(case_id=row['case_id'], length=length,
                postprocessed_sequence_sha256=row['postprocessed_sequence_sha256'],
                folding_protocol='SCIREASON_OMEGAFOLD_MODEL2_10CYCLE_V1'))
    return output

def validate_plan(path, expected_sha):
    if Path(path).resolve() != HERE / 'plan.json' or sha(path) != expected_sha:
        raise ValueError('Exact frozen recovery plan required')
    plan = read(path)
    required = dict(task_id='P37', role='existing_sealed_generation_fold_and_score_only',
        original_plan_sha256=OLD_PLAN_SHA, generation_prediction_lock_sha256=GENERATION_LOCK_SHA,
        new_generation_calls=0, maximum_fold_attempts_per_eligible_case=1,
        expected_original_cases=1000, expected_eligible_cases=440,
        requested_GPUs=1, project_GPU_ceiling=8, runtime_root=str(HERE/'runtime'),
        root_priority_release_required=True)
    if any(plan.get(k) != v for k,v in required.items()):
        raise ValueError('Only exact existing-generation recovery is supported')
    for name, digest in plan['source_sha256'].items():
        q = Path(name)
        if q.is_symlink() or q.resolve() != q or sha(q) != digest:
            raise ValueError('Frozen recovery source/evidence changed')
    if sha(OLD/'plan.json') != OLD_PLAN_SHA or sha(OLD/'peer_admission_preparation_agent.json') != OLD_ADMISSION_SHA:
        raise ValueError('Original scientific plan/admission changed')
    old = read(OLD/'plan.json')
    for name,digest in old['frozen_files_sha256'].items():
        if Path(name).is_symlink() or sha(name) != digest: raise ValueError('Original frozen source changed')
    if old['folding_settings'] != plan['folding_settings']: raise ValueError('Folding settings changed')
    lock,done = read(GENERATION/'prediction_lock.json'),read(GENERATION/'completion.json')
    if (sha(GENERATION/'prediction_lock.json') != GENERATION_LOCK_SHA
            or done['prediction_lock_sha256'] != GENERATION_LOCK_SHA or done.get('all_delivered') is not True
            or done.get('closed_slots') != 1000 or lock['plan_sha256'] != OLD_PLAN_SHA
            or lock['planned_case_ids'] != old['planned_case_ids']):
        raise ValueError('Complete immutable generation seal required')
    for name,digest in lock['files_sha256'].items():
        q = GENERATION/name
        if Path(name).is_absolute() or '..' in Path(name).parts or q.is_symlink() or sha(q) != digest:
            raise ValueError('Original generation file changed')
    for category in ('requests','responses','outcomes','errors','attempts'):
        actual = {str(q.relative_to(GENERATION)) for q in (GENERATION/category).glob('*') if q.is_file()}
        if actual != {n for n in lock['files_sha256'] if n.startswith(category+'/')}:
            raise ValueError('Original generation inventory changed')
    selected = eligible_metadata(read(GENERATION/'terminal_records.json'),old['planned_case_ids'])
    if selected != read(HERE/'eligible_manifest.json')['eligible'] or len(selected) != 440:
        raise ValueError('Unchanged eligibility gate/cohort required')
    gate = read(OLD/'runtime/neutral_folding_gate_completion.json')
    if gate.get('passed') is not True or gate.get('plan_sha256') != OLD_PLAN_SHA:
        raise ValueError('Original declared neutral gate missing')
    if (OLD/'runtime/run_v1/folding').exists() or (OLD/'runtime/run_v1/scores.json').exists():
        raise ValueError('Original folding/scoring has started; stop duplicate recovery')
    old['plan_sha256'] = OLD_PLAN_SHA
    return plan,old,selected

def old_modules():
    sys.path.insert(0,str(OLD))
    runner = load('p37_recovery_frozen_runner',OLD/'p37_runner.py','cf01788f70f5f9e9ff71bd091dc37e8533193cf2770cf9e8671aaddb2b29b9d7')
    admission = load('p37_recovery_frozen_admission',OLD/'admission.py','2b1a8106492f0381f618d26fb9aef6da2f7ccdd7e01e5ab6489106286c95f1ff')
    fold = load('p37_recovery_frozen_fold_functions',OLD/'fold_worker.py','84f538def5defb33dc98090eb12bf7b35d3309d52a368c3c768d8906da894a72')
    return runner,admission,fold
