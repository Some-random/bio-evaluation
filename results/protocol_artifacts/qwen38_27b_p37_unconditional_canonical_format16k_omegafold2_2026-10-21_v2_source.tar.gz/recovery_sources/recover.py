"""Finish existing P37 folds/scores only; default mode is CPU seal preflight."""
import argparse
import fcntl
import hashlib
import os
from pathlib import Path
import socket
import shutil
import subprocess
import sys
import tempfile
import recovery_common as c
import metadata_preflight
from runtime_authority import authorize_execution, capacity


def fold_backend(plan, old, selected, args, job):
    receipt = c.read(c.HERE/'runtime/evaluator_runtime.json')
    root = Path(receipt['local_root'])
    if (receipt['job_id'] != job or receipt['plan_sha256'] != args.plan_sha256
            or receipt['controller_pid'] != os.getppid() or root != Path(args.backend)
            or receipt['portable_manifest_sha256'] != c.sha(old['folding_runtime_manifest'])):
        raise ValueError('Exact parent-owned evaluator runtime required')
    runner, _, frozen_fold = c.old_modules()
    records, done = runner.verify_generation(old,c.GENERATION)
    if runner.fold_manifest(old,c.GENERATION) != selected:
        raise ValueError('Source-normalized eligibility differs from sealed length/hash projection')
    import torch
    import omegafold
    from omegafold import pipeline
    if (torch.__version__ != '1.12.0+cu113' or torch.cuda.device_count() != 1
            or not Path(omegafold.__file__).resolve().is_relative_to(root/'source')):
        raise ValueError('Original evaluator package and one GPU required')
    def no_network(*unused, **kwargs): raise RuntimeError('Evaluator networking prohibited')
    socket.create_connection=no_network; socket.socket.connect=no_network
    torch.set_num_threads(4); torch.set_num_interop_threads(1)
    checkpoint=Path(old['folding_checkpoint']['path'])
    if c.sha(checkpoint) != old['folding_checkpoint']['sha256']:
        raise ValueError('Original evaluator weights changed')
    state=torch.load(checkpoint,map_location='cpu')
    if 'model' in state: state=state['model']
    model=omegafold.OmegaFold(omegafold.make_config(2))
    binding=model.load_state_dict(state,strict=True)
    if binding.missing_keys or binding.unexpected_keys: raise ValueError('Strict original weight binding failed')
    del state
    model.eval(); model.to('cuda'); pipeline._set_precision(True)
    runtime_adapter=c.load('p37_recovery_frozen_runtime_adapter',Path(old['folding_adapter']),
        old['frozen_files_sha256'][old['folding_adapter']])
    api=runner.adapter(old)
    cleaned={row['case_id']:api.postprocess(row.get('final_text')) for row in records}
    out=c.HERE/'runtime/folding'; out.mkdir(exist_ok=False)
    c.write_once(out/'manifest.json',dict(at_utc=c.stamp(),eligible=selected,
        original_plan_sha256=c.OLD_PLAN_SHA,recovery_plan_sha256=args.plan_sha256,
        generation_prediction_lock_sha256=c.GENERATION_LOCK_SHA,maximum_attempts_per_case=1))
    outcomes=[]
    for entry in selected:
        sequence=cleaned[entry['case_id']]
        if hashlib.sha256(sequence.encode()).hexdigest() != entry['postprocessed_sequence_sha256']:
            raise ValueError('Evaluator input differs from sealed generated output')
        outcomes.append(frozen_fold.fold_once(entry['case_id'],sequence,out/'cases'/entry['case_id'],
            model,pipeline,runtime_adapter,torch,'cuda'))
        runner.current(out/'progress.json',dict(at_utc=c.stamp(),planned=len(selected),terminal=len(outcomes),
            successes=sum(x['status']=='success' for x in outcomes),errors=sum(x['status']=='error' for x in outcomes)))
    c.write_once(out/'terminal_records.json',outcomes)
    files={str(p.relative_to(out)):c.sha(p) for p in sorted((out/'cases').rglob('*')) if p.is_file()}
    files.update({n:c.sha(out/n) for n in ('manifest.json','terminal_records.json')})
    c.write_once(out/'prediction_lock.json',dict(files_sha256=files,recovery_plan_sha256=args.plan_sha256,
        original_plan_sha256=c.OLD_PLAN_SHA,generation_prediction_lock_sha256=c.GENERATION_LOCK_SHA))
    c.write_once(out/'completion.json',dict(at_utc=c.stamp(),planned=len(selected),terminal=len(outcomes),
        successes=sum(x['status']=='success' for x in outcomes),errors=sum(x['status']=='error' for x in outcomes),
        prediction_lock_sha256=c.sha(out/'prediction_lock.json')))
    # Exclusive score claim follows immutable generation and folding seals.
    c.write_once(c.HERE/'runtime/scoring_attempt.json',dict(at_utc=c.stamp(),recovery_plan_sha256=args.plan_sha256,
        generation_prediction_lock_sha256=c.GENERATION_LOCK_SHA,folding_prediction_lock_sha256=c.sha(out/'prediction_lock.json')))
    scores=runner.aggregate(old,c.GENERATION,outcomes)
    scores.update(at_utc=c.stamp(),recovery_plan_sha256=args.plan_sha256,
        original_generation_unchanged=True,folding_prediction_lock_sha256=c.sha(out/'prediction_lock.json'),
        new_generation_calls=0,evaluator_forward_attempts=sum(x['forward_invocation_attempted'] for x in outcomes))
    c.write_once(c.HERE/'runtime/scores.json',scores)
    c.write_once(c.HERE/'runtime/terminal_receipt.json',dict(at_utc=c.stamp(),job_id=job,
        score_sha256=c.sha(c.HERE/'runtime/scores.json'),full_primary_metric_defined=scores['full_primary_metric_defined'],
        original_plan_sha256=c.OLD_PLAN_SHA,recovery_plan_sha256=args.plan_sha256,new_generation_calls=0))


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-sha256',required=True)
    parser.add_argument('--execute',action='store_true')
    parser.add_argument('--admission-sha256')
    parser.add_argument('--priority-release-sha256')
    parser.add_argument('--backend')
    args=parser.parse_args(argv)
    if not args.execute:
        if args.backend: raise ValueError('Backend requires explicit admitted execution')
        print(__import__('json').dumps(metadata_preflight.preflight(args.plan_sha256)))
        return
    plan,old,selected=c.validate_plan(c.HERE/'plan.json',args.plan_sha256)
    if not args.admission_sha256 or not args.priority_release_sha256:
        raise PermissionError('Independent admission and explicit root priority release required')
    job=authorize_execution(args.plan_sha256,args.admission_sha256,args.priority_release_sha256)
    audit=capacity(plan,own=True)
    if args.backend:
        fold_backend(plan,old,selected,args,job); return
    runtime=c.HERE/'runtime'; runtime.mkdir(exist_ok=True)
    with (runtime/'controller.lock').open('a') as own_lock, (c.OLD/'runtime/protocol.lock').open('r') as original_lock:
        fcntl.flock(own_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        fcntl.flock(original_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (runtime/'attempt_started.json').exists(): raise FileExistsError('No automatic recovery retry')
        c.write_once(runtime/'private_GPU_audit.json',audit)
        c.write_once(runtime/'attempt_started.json',dict(at_utc=c.stamp(),job_id=job,
            plan_sha256=args.plan_sha256,admission_sha256=args.admission_sha256,
            priority_release_sha256=args.priority_release_sha256,new_generation_calls=0,no_automatic_retry=True))
        _,admission,_=c.old_modules()
        original_worker=c.load('p37_recovery_frozen_worker_helpers',c.OLD/'worker.py',
            old['frozen_files_sha256'][str(c.OLD/'worker.py')])
        if shutil.disk_usage(tempfile.gettempdir()).free < 48*1024**3:
            raise ValueError('Preserved conservative48GiB private scratch guard failed')
        with tempfile.TemporaryDirectory(prefix='p37-fold-recovery-'+job+'-') as scratch:
            root=admission.verify_folding_runtime(old,Path(scratch)/'folding')
            c.write_once(runtime/'evaluator_runtime.json',dict(at_utc=c.stamp(),job_id=job,controller_pid=os.getpid(),
                local_root=str(root),plan_sha256=args.plan_sha256,
                portable_manifest_sha256=c.sha(old['folding_runtime_manifest'])))
            env=original_worker.folding_environment(root,os.environ)
            command=[str(root/'python/bin/python3.10'),str(Path(__file__).resolve()),
                '--plan-sha256',args.plan_sha256,'--execute','--admission-sha256',args.admission_sha256,
                '--priority-release-sha256',args.priority_release_sha256,'--backend',str(root)]
            with (runtime/'folding_and_scoring.log').open('x') as log:
                subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,
                    timeout=old['folding_timeout_seconds'])
        print(__import__('json').dumps(dict(stage='P37_fold_score_recovery_terminal',job_id=job,
            score_sha256=c.sha(runtime/'scores.json'),new_generation_calls=0)))

if __name__=='__main__': main()
