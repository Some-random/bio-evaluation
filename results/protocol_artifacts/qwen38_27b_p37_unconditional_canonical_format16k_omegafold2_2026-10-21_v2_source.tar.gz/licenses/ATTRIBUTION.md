# Source attribution and local adaptations

The source archive preserves original upstream copyright/license headers.

* SciReason / OpenCompass: revision 92814ce45c36b691c19dc606bc1e4a50364eac51,
  Copyright 2020 OpenCompass Authors, Apache License 2.0. Its UPG evaluator and
  configuration are included as frozen scientific source files.
  https://github.com/open-sciencelab/SciReason/tree/92814ce45c36b691c19dc606bc1e4a50364eac51
  Complete upstream license: SciReason_LICENSE.
* OmegaFold: revision 313c873ad190b64506a497c926649e15fcd88fcd,
  Copyright 2022 HeliXon Limited, Apache License 2.0. The archived OmegaFold
  modules are immutable copies bundled with the frozen SciReason evaluator.
  https://github.com/HeliXonProtein/OmegaFold/tree/313c873ad190b64506a497c926649e15fcd88fcd
  Complete upstream license: OmegaFold_LICENSE.
* vLLM: release v0.31.0, Copyright contributors to the vLLM project,
  Apache License 2.0. The frozen scheduler utility source retains SPDX headers.
  https://github.com/vllm-project/vllm/tree/v0.31.0
  Complete upstream license: vLLM_LICENSE.

No NOTICE file exists at these exact three upstream roots (HTTP 404 checked
2026-10-24). Complete LICENSE texts were fetched from those pinned references.

Local wrappers implement the separately named canonical tagged-output adaptation,
portable evaluator execution, once-only recovery, metadata verification and export.
These additions wrap the frozen upstream science; available-code diversity and
short-output folding differ from the NatureLM paper as stated in the report.
No model weights, installed environment or unrelated account metadata is included.
