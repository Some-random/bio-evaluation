"""Synthetic secondary-read failures keep raw bytes and complete dispositions."""
import http.client,json,unittest,urllib.error
from unittest.mock import MagicMock
import test_runtime_guards as guards

class TransportCapture(unittest.TestCase):
    setUp=guards.PredictionSeal.setUp
    tearDown=guards.PredictionSeal.tearDown
    seal=guards.PredictionSeal.seal
    save_lock=guards.PredictionSeal.save_lock
    prepare_runtime=guards.RuntimeStopAndSeal.prepare_runtime
    invoke=guards.RuntimeStopAndSeal.invoke
    check_seal=guards.RuntimeStopAndSeal.check_seal
    def test_normal_partial_response_bytes_are_preserved(self):
        self.prepare_runtime()
        self.opener.open.return_value.__enter__.return_value.read.side_effect=http.client.IncompleteRead(b'SYNTHETIC_PARTIAL',100)
        self.invoke();completion=self.check_seal(attempted=1,passed=0,not_dispatched=1)
        self.assertEqual(1,completion['transport_errors']);self.assertEqual(1,self.opener.open.call_count)
        self.assertEqual(b'SYNTHETIC_PARTIAL',(self.output/'errors/synthetic-a.partial_response.bin').read_bytes())
        self.assertFalse(json.loads((self.output/'outcomes/synthetic-a.json').read_text())['response_body_complete'])
    def test_HTTP_error_partial_body_still_seals(self):
        self.prepare_runtime()
        error=urllib.error.HTTPError('http://127.0.0.1/synthetic',503,'Synthetic status',{},None)
        error.read=MagicMock(side_effect=http.client.IncompleteRead(b'SYNTHETIC_HTTP_PARTIAL',10))
        self.opener.open.side_effect=error
        self.invoke();completion=self.check_seal(attempted=1,passed=0,not_dispatched=1)
        self.assertEqual(1,completion['http_errors']);self.assertEqual(1,self.opener.open.call_count)
        self.assertEqual(b'SYNTHETIC_HTTP_PARTIAL',(self.output/'errors/synthetic-a.http').read_bytes())
        metadata=json.loads((self.output/'errors/synthetic-a.json').read_text())
        self.assertFalse(metadata['body_complete']);self.assertEqual('IncompleteRead',metadata['body_read_error']['type'])
    def test_HTTP_error_unreadable_body_still_seals(self):
        self.prepare_runtime()
        error=urllib.error.HTTPError('http://127.0.0.1/synthetic',503,'Synthetic status',{},None)
        error.read=MagicMock(side_effect=OSError('Synthetic closed error body'))
        self.opener.open.side_effect=error
        self.invoke();self.check_seal(attempted=1,passed=0,not_dispatched=1)
        self.assertEqual(b'',(self.output/'errors/synthetic-a.http').read_bytes())
        self.assertEqual(1,self.opener.open.call_count)

if __name__=='__main__':unittest.main()
