"""Prepare an offline narrow result candidate after once-only native scoring.

Never publishes by itself. Licensed source questions/images/references and raw
model text remain private; only aggregate results and input-free code enter it.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math
import tarfile
from datetime import datetime

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
EXECUTION = TASK / 'full_execution_20261021_v1'
ROOT = TASK.parents[3]
PUBLIC_PREFIX = 'results/runs/v07_slidevqa_available_full_guard_v3/'
SOURCE_ARCHIVE = 'results/protocol_artifacts/v07_slidevqa_available_full_guard_v3_source.tar.gz'
REPORT = 'reports/V07_SLIDEVQA_AVAILABLE_RESULT.md'
SECRET_SCANNER_SHA256 = '528735e220dd6a2b5ab3d5b6b51ec7143b5ffa891fdfcfc211d2a8099ce7093d'
SOURCE_NAMES = ('run.py', 'score.py', 'slidevqa_adapter.py', 'review_binding.py',
                'admission.py', 'worker.py', 'worker.sbatch', 'freeze_plan.py',
                'submit_once.py', 'test_contract.py', 'test_runtime_guards.py',
                'test_final_accounting.py', 'test_refusal_handling.py',
                'test_transport_capture.py', 'test_review_binding.py', 'review_row_schema.json', 'CPU_tests.json', 'README.md')
UPSTREAM_SOURCE_EXCLUSION = {
    'repository': 'nttmdlab-nlp/SlideVQA',
    'revision': '0d4168a935d60b0b218097205a02fb1133c8bead',
    'evaluator_sha256': '604be8d606ec46664e36810b43cdb497880043a39c57a687a819abc30660acbb',
    'license_sha256': '8c3c4aa46e0c873f8cd8899e9a27fb420d91e10b02de8d8a2d61af10d6e00a88',
    'evaluator_url': 'https://github.com/nttmdlab-nlp/SlideVQA/blob/0d4168a935d60b0b218097205a02fb1133c8bead/evaluate.py',
    'license_url': 'https://github.com/nttmdlab-nlp/SlideVQA/blob/0d4168a935d60b0b218097205a02fb1133c8bead/LICENSE',
    'upstream_evaluator_or_license_redistributed': False,
    'restriction_note': 'Upstream evaluator source and license text are excluded from this public archive under the pinned source distribution restrictions. Consult the official source and its terms for any permitted access.'}


def source_archive_metadata(files):
    return {'files': files, 'questions_images_references_raw_model_text_included': False,
            'upstream_source_exclusion': UPSTREAM_SOURCE_EXCLUSION}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate JSON key in publication evidence')
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def regular(path):
    path = Path(path)
    if path != path.resolve() or not path.is_file() or any(p.is_symlink() for p in [path, *path.parents]):
        raise ValueError('Regular canonical publication evidence file required')
    return path


def bootstrap(plan_path, plan_sha, admission_path, admission_sha):
    """Verify detached authority and executable pins before importing them."""
    for path, expected in ((plan_path, plan_sha), (admission_path, admission_sha)):
        if sha(regular(path)) != expected:
            raise ValueError('Exact admitted plan and admission bytes required')
    plan, approval = read(plan_path), read(admission_path)
    policy_path = ROOT / '.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review_resume_v2.json'
    policy = read(regular(policy_path))
    if (approval.get('admitted') is not True or approval.get('task_id') != 'V07'
            or approval.get('plan_sha256') != plan_sha or approval.get('delegation_sha256') != sha(policy_path)
            or approval.get('reviewer') not in policy['authorized_reviewers'] + ['root', '/root']
            or approval.get('reviewer') == '/root/v07_execution'
            or approval.get('authorized_scope') != 'reviewed_full_benchmark'
            or approval.get('one_attempt_per_case') is not True):
        raise ValueError('Independent full-plan authority required before imports')
    for name in ('admission.py', 'score.py', 'slidevqa_adapter.py', 'run.py', 'review_binding.py'):
        path = regular(EXECUTION / name)
        if plan.get('frozen_files_sha256', {}).get(str(path)) != sha(path):
            raise ValueError('Executable or transitive import differs from admitted pin')
    return plan


COUNTERS = ('attempted_confirmed', 'responses_saved', 'delivery_passed', 'transport_errors',
            'http_errors', 'response_errors', 'invalid_model_finals', 'truncations', 'empty_finals',
            'refusals', 'input_errors', 'not_dispatched')
SCORE_KEYS = {'planned', 'missing_finals', 'invalid_or_missing_finals', 'QA', 'ES', 'Main', 'task_id',
              'protocol_id', 'scored_at_pacific', 'prediction_lock_sha256', 'scorer_config_sha256',
              'run_id', 'scorer_sha256', 'native_scorer_sha256', 'formula_changes',
              'full_denominator_metric', 'all_planned_attempted', 'delivery_passed',
              'terminal_disposition_complete', 'benchmark_generation_complete', 'all_finals_valid',
              'comparison', 'raw_licensed_content_publishable'}
COMPLETION_KEYS = set(COUNTERS) | {'finished_at_pacific', 'planned', 'terminal_case_dispositions',
                  'observed_attempted_terminal', 'all_passed', 'phase', 'protocol_id', 'generation',
                  'model_revision', 'images_per_case', 'prediction_lock_path', 'prediction_lock_sha256',
                  'biological_correctness_assessed', 'catalog_complete'}
ATTEMPT_KEYS = {'started_at_pacific', 'task_id', 'run_id', 'prediction_lock_sha256',
                'scorer_config_sha256', 'scorer_sha256', 'output',
                'reference_access_begins_after_this_once_only_claim'}


def timestamp(value):
    if not isinstance(value, str) or len(value) > 64 or datetime.fromisoformat(value).tzinfo is None:
        raise ValueError('Bounded timezone-aware evidence timestamp required')


def validate_aggregates(score, completion, attempt, config, counts, score_path, lock_sha, config_sha, scorer_sha):
    """Validate output-only schemas and bindings without opening references."""
    if set(score) != SCORE_KEYS or set(completion) != COMPLETION_KEYS or set(attempt) != ATTEMPT_KEYS:
        raise ValueError('Unknown or missing aggregate/scoring-attempt fields')
    planned, delivered = config['planned'], counts['delivery_passed']
    attempted = counts['attempted_confirmed']
    for key in ('planned', 'missing_finals', 'invalid_or_missing_finals', 'delivery_passed'):
        if type(score[key]) is not int or not 0 <= score[key] <= planned:
            raise ValueError('Integer aggregate counts required')
    if (score['planned'] != planned or score['delivery_passed'] != delivered
            or score['missing_finals'] != planned - delivered
            or score['invalid_or_missing_finals'] != planned - delivered):
        raise ValueError('Aggregate counts differ from complete sealed outcomes')
    expected_score = {'task_id': 'V07', 'run_id': config['run_id'], 'protocol_id': config['protocol_id'],
        'prediction_lock_sha256': lock_sha, 'scorer_config_sha256': config_sha,
        'scorer_sha256': scorer_sha, 'native_scorer_sha256': config['native_scorer']['sha256'],
        'formula_changes': False, 'full_denominator_metric': True,
        'all_planned_attempted': attempted == planned, 'terminal_disposition_complete': True,
        'benchmark_generation_complete': attempted == planned, 'all_finals_valid': delivered == planned,
        'comparison': 'Released SlideVQA test adaptation; not exact Ryze Table3 reproduction',
        'raw_licensed_content_publishable': False}
    for key, expected in expected_score.items():
        if type(score[key]) is not type(expected) or score[key] != expected:
            raise ValueError('Score execution binding or completion flag differs: ' + key)
    for name in ('QA', 'ES', 'Main'):
        metric = score[name]
        if not isinstance(metric, dict) or set(metric) != {'F1', 'EM'}:
            raise ValueError('Exact native metric fields required')
        if any(type(value) not in (float, int) or not math.isfinite(value) or not 0 <= value <= 1
               for value in metric.values()):
            raise ValueError('Finite native metric fractions in [0,1] required')
    for key in COUNTERS:
        if type(completion[key]) is not int or completion[key] != counts[key]:
            raise ValueError('Completion counter differs from sealed artifacts: ' + key)
    expected_completion = {'planned': planned, 'terminal_case_dispositions': planned,
        'observed_attempted_terminal': attempted, 'all_passed': delivered == planned,
        'phase': 'benchmark_generation', 'protocol_id': config['protocol_id'], 'generation': config['generation'],
        'model_revision': config['model_revision'], 'images_per_case': 20,
        'prediction_lock_path': str((score_path.parent / 'prediction_lock.json').resolve()),
        'prediction_lock_sha256': lock_sha, 'biological_correctness_assessed': False, 'catalog_complete': False}
    for key, expected in expected_completion.items():
        if type(completion[key]) is not type(expected) or completion[key] != expected:
            raise ValueError('Completion execution binding differs: ' + key)
    expected_attempt = {'task_id': 'V07', 'run_id': config['run_id'], 'prediction_lock_sha256': lock_sha,
        'scorer_config_sha256': config_sha, 'scorer_sha256': scorer_sha,
        'output': str(score_path.resolve()), 'reference_access_begins_after_this_once_only_claim': True}
    for key, expected in expected_attempt.items():
        if type(attempt[key]) is not type(expected) or attempt[key] != expected:
            raise ValueError('Once-only scoring claim differs: ' + key)
    timestamp(score['scored_at_pacific']); timestamp(completion['finished_at_pacific']); timestamp(attempt['started_at_pacific'])


def sealed_counters(run, lock, refusal_detector):
    counts = dict.fromkeys(COUNTERS, 0)
    status_counter = {'delivered': 'delivery_passed', 'transport_error': 'transport_errors',
        'http_error': 'http_errors', 'invalid_response': 'response_errors',
        'invalid_model_final': 'invalid_model_finals', 'input_error': 'input_errors',
        'not_dispatched_after_first_failure': 'not_dispatched'}
    for item in lock['outcomes']:
        row = read(regular(run / item['path']))
        if row['status'] not in status_counter:
            raise ValueError('Unknown sealed terminal status')
        counts[status_counter[row['status']]] += 1
        counts['attempted_confirmed'] += int(row['attempted'])
    responses = [p for p in lock['files'] if p['path'].startswith('responses/')]
    counts['responses_saved'] = len(responses)
    for item in responses:
        try:
            body = read(regular(run / item['path']))
        except (ValueError, UnicodeDecodeError):
            continue
        if not (isinstance(body, dict) and isinstance(body.get('choices'), list)
                and body['choices'] and isinstance(body['choices'][0], dict)):
            continue
        choice = body['choices'][0]
        counts['truncations'] += int(choice.get('finish_reason') == 'length')
        message = choice.get('message')
        if isinstance(message, dict):
            counts['refusals'] += int(refusal_detector(message))
            final = message.get('content')
            counts['empty_finals'] += int(not isinstance(final, str) or not final.strip())
    return counts


def render(score, completion):
    planned = score['planned']
    attempted = completion['attempted_confirmed']
    valid = score['delivery_passed']
    lines = ['# V07: available full-deck SlideVQA condition', '',
             f"The fixed Qwen3.8-27B BF16 checkpoint attempted {attempted:,}/{planned:,} frozen questions once. "
             f"There were {valid:,} valid answer/evidence outputs; every planned case remains in the metric denominator.", '',
             '| Released native metric | F1 | Exact match |', '| --- | ---: | ---: |']
    for key, label in (('QA', 'Answer'), ('ES', 'Evidence pages'), ('Main', 'Joint answer and evidence')):
        lines.append(f"| {label} | {score[key]['F1'] * 100:.2f}% | {score[key]['EM'] * 100:.2f}% |")
    lines += ['',
              f"Full generation completed: **{score['benchmark_generation_complete']}**. "
              f"Invalid or missing finals: **{score['invalid_or_missing_finals']:,}**. "
              f"HTTP/transport/refusal counts: **{completion['http_errors']}/{completion['transport_errors']}/{completion['refusals']}**. "
              f"Truncations: **{completion['truncations']}**. No selective retries were performed.", '',
              'Each dispatched request was constructed with all 20 supplied page images in source order, using 7,700 author-URL files '
              'and 300 separately identified processed1024 copies. The pinned model used one GPU, temperature 1.0, '
              'top-p 0.95, top-k 20, seed 42, thinking enabled and a 16,384-token output budget. '
              'A supported JSON grammar constrained the output shape; the final validator required unique, ascending evidence pages. '
              'Four neutral geometric 20-image requests had to pass actual token, first/last-page and output checks before benchmark dispatch.', '',
              'The unchanged released SlideVQA QA, evidence and joint functions were applied after sealing the full prediction inventory. '
              'These metrics are an available local-model adaptation. [Ryze Table 3](https://arxiv.org/abs/2606.00902v1) reports 66.48% SlideVQA accuracy, '
              'but its exact cohort, aggregation, OCR/GLM configuration and metric mapping were not recoverable from the inspected release/history. '
              'The metric values above therefore do not establish a matched comparison or a reproduction of Table 3. '
              'Prior public pretraining exposure is unknown. Correct answers do not validate explanations or biological reasoning.', '',
              '[SlideVQA source](https://github.com/nttmdlab-nlp/SlideVQA/tree/0d4168a935d60b0b218097205a02fb1133c8bead) · '
              f'[Evaluation code](https://github.com/Some-random/bio-evaluation/blob/main/{SOURCE_ARCHIVE}) · '
              f'[Raw aggregate scores](https://github.com/Some-random/bio-evaluation/blob/main/{PUBLIC_PREFIX}scores.json)', '',
              'Licensed questions, page images, references and raw model text remain preserved privately under the existing source restrictions. '
              'The public artifact manifest records hashes of the full private prediction seal and the once-only scoring attempt.', '',
              'The upstream evaluator source and license text are also excluded from this archive because of their distribution restrictions. '
              f"The evaluated native source has SHA-256 `{UPSTREAM_SOURCE_EXCLUSION['evaluator_sha256']}`; "
              f"consult the [official evaluator]({UPSTREAM_SOURCE_EXCLUSION['evaluator_url']}) and "
              f"[official terms]({UPSTREAM_SOURCE_EXCLUSION['license_url']}) for permitted access.", '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--admission', type=Path, required=True)
    parser.add_argument('--admission-sha256', required=True)
    args = parser.parse_args()
    plan_path = EXECUTION / 'plan.json'
    args.admission = args.admission.absolute()
    bootstrap(plan_path, args.plan_sha256, args.admission, args.admission_sha256)
    # Executable/transitive pins have been verified before these imports.
    import sys
    sys.path.insert(0, str(EXECUTION))
    admission = load('v07_publication_admission', EXECUTION / 'admission.py')
    scorer = load('v07_publication_reference_blind_lock_check', EXECUTION / 'score.py')
    runner = load('v07_publication_frozen_refusal_detector', EXECUTION / 'run.py')
    plan = admission.validate(plan_path, args.plan_sha256, args.admission, args.admission_sha256)
    if plan.get('execution_scope') != 'reviewed_full_benchmark' or plan.get('planned_cases') != 2215:
        raise ValueError('Exact independently admitted full condition required')
    run = Path(plan['phases']['benchmark']['output'])
    config = {**read(plan['phases']['benchmark']['config']), **read(plan['scorer_config'])}
    _, lock, manifest = scorer.verify_prediction_lock(run, config)
    score_path = run / 'scores.json'
    score, completion, attempt = read(regular(score_path)), read(regular(run / 'completion.json')), read(regular(run / 'scoring_attempt.json'))
    counts = sealed_counters(run, lock, runner.is_explicit_refusal)
    validate_aggregates(score, completion, attempt, config, counts, score_path,
                        sha(run / 'prediction_lock.json'), sha(plan['scorer_config']), sha(EXECUTION / 'score.py'))
    terminal_path = regular(Path(plan['runtime_root']) / 'status.json')
    terminal = read(terminal_path)
    if (terminal.get('stage') != 'V07_terminal_native_available_condition_scored'
            or terminal.get('scores') != str(score_path)
            or terminal.get('scores_sha256') != sha(score_path)
            or terminal.get('generation_completion_sha256') != sha(run / 'completion.json')
            or terminal.get('generation_counts') != completion
            or terminal.get('benchmark_generation_complete') is not score['benchmark_generation_complete']):
        raise ValueError('Exact terminal worker result binding required')
    stage = HERE / 'stage'
    stage.mkdir(exist_ok=False)
    sources = {name: EXECUTION / name for name in SOURCE_NAMES}
    for path in sources.values():
        if plan['frozen_files_sha256'].get(str(path)) != sha(regular(path)):
            raise ValueError('Packaged execution source differs from admitted pin')
    native = ROOT / '.local/source_acquisition_2026-10-19/vision/slidevqa/source'
    if (Path(config['native_scorer']['path']) != native / 'evaluate.py'
            or sha(regular(native / 'evaluate.py')) != config['native_scorer']['sha256']):
        raise ValueError('Referenced native scorer differs from admitted scorer configuration')
    license_pin = next(item['sha256'] for item in read(TASK / 'source_manifest.json')['source_files']
                       if item['upstream_path'] == 'LICENSE')
    if (sha(regular(native / 'LICENSE')) != license_pin
            or license_pin != UPSTREAM_SOURCE_EXCLUSION['license_sha256']
            or config['native_scorer']['sha256'] != UPSTREAM_SOURCE_EXCLUSION['evaluator_sha256']):
        raise ValueError('Upstream license differs from frozen source manifest')
    # Verify upstream provenance privately, then package only our own code.
    # The native source and its license text must never enter this archive.
    sources.update({'publication/prepare.py': Path(__file__).resolve(),
                    'publication/test_prepare.py': HERE / 'test_prepare.py'})
    scanner_path = ROOT / 'scripts/daily_backup.py'
    if sha(regular(scanner_path)) != SECRET_SCANNER_SHA256:
        raise ValueError('Publication scanner differs from reviewed source')
    scanner = load('v07_narrow_publication_secret_scanner', scanner_path)
    for name, path in sources.items():
        scanner.safe_archive_member(name)
        if path.is_symlink() or not path.is_file():
            raise ValueError('Only regular source files may be packaged')
        scanner.scan_file(path)
    archive_path = stage / SOURCE_ARCHIVE
    archive_path.parent.mkdir(parents=True)
    source_manifest = {name: sha(path) for name, path in sources.items()}
    metadata = stage / 'source_archive_manifest.json'
    metadata.write_text(json.dumps(source_archive_metadata(source_manifest),
                                   indent=2, sort_keys=True) + '\n')
    with tarfile.open(archive_path, 'w:gz') as archive:
        for name, path in sorted(sources.items()):
            archive.add(path, arcname=name, recursive=False)
        archive.add(metadata, arcname='source_archive_manifest.json', recursive=False)
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        if {m.name for m in members} != set(sources) | {'source_archive_manifest.json'}:
            raise ValueError('Source archive member whitelist differs')
        for member in members:
            if not member.isfile():
                raise ValueError('Only regular source archive members permitted')
            data = archive.extractfile(member).read()
            expected = sha(metadata) if member.name == 'source_archive_manifest.json' else source_manifest[member.name]
            if hashlib.sha256(data).hexdigest() != expected:
                raise ValueError('Archived source bytes differ from admitted member')
    metadata.unlink()
    target = stage / PUBLIC_PREFIX
    target.mkdir(parents=True)
    (target / 'scores.json').write_bytes(score_path.read_bytes())
    public_completion = {key: value for key, value in completion.items() if key != 'prediction_lock_path'}
    (target / 'generation_completion.json').write_text(json.dumps(public_completion, indent=2, sort_keys=True) + '\n')
    report = render(score, completion)
    (target / 'README.md').write_text(report)
    report_path = stage / REPORT
    report_path.parent.mkdir(parents=True)
    report_path.write_text(report)
    artifact_manifest = {'task_id': 'V07', 'run_id': score['run_id'], 'plan_sha256': args.plan_sha256,
                         'admission_sha256': args.admission_sha256, 'source_denominator': 2215,
                         'score_sha256': sha(score_path), 'private_prediction_lock_sha256': sha(run / 'prediction_lock.json'),
                         'private_scoring_attempt_sha256': sha(run / 'scoring_attempt.json'),
                         'source_archive': {'path': SOURCE_ARCHIVE, 'sha256': sha(archive_path)},
                         'upstream_source_exclusion': UPSTREAM_SOURCE_EXCLUSION,
                         'raw_licensed_content_included': False, 'exact_Ryze_Table3_reproduction': False}
    (target / 'artifact_manifest.json').write_text(json.dumps(artifact_manifest, indent=2, sort_keys=True) + '\n')
    allowed = {PUBLIC_PREFIX + name for name in ('scores.json', 'generation_completion.json', 'README.md', 'artifact_manifest.json')}
    allowed |= {SOURCE_ARCHIVE, REPORT}
    files = {str(path.relative_to(stage)): sha(path) for path in stage.rglob('*') if path.is_file()}
    if set(files) != allowed:
        raise ValueError('Exact narrow six-file publication whitelist required')
    for name in files:
        scanner.scan_file(stage / name)
    candidate = {'task_id': 'V07', 'owner': '/root/v07_execution', 'repository': 'Some-random/bio-evaluation',
                 'visibility': 'public', 'stage_directory': str(stage), 'files_sha256': files,
                 'source_archive_members': source_manifest, 'plan_sha256': args.plan_sha256,
                 'upstream_source_exclusion': UPSTREAM_SOURCE_EXCLUSION,
                 'private_terminal_status_sha256': sha(terminal_path),
                 'private_completion_sha256': sha(run / 'completion.json'),
                 'private_scoring_attempt_sha256': sha(run / 'scoring_attempt.json'),
                 'requires_independent_publication_review': True, 'publication_performed': False,
                 'secret_and_archive_member_scans_passed': True,
                 'secret_scanner_sha256': sha(scanner_path),
                 'private_input_reference_image_or_raw_model_content_included': False,
                 'new_model_calls': 0, 'shared_aggregate_report_changes': False, 'website_or_schedule_changes': False}
    with (HERE / 'candidate.json').open('x') as stream:
        stream.write(json.dumps(candidate, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'prepared_candidate_files': len(files), 'publication_performed': False}))


if __name__ == '__main__':
    main()
