"""Artificial aggregate rendering; no questions, references or model calls."""
import unittest
import copy
import json
import tempfile
from pathlib import Path
from prepare import COUNTERS, UPSTREAM_SOURCE_EXCLUSION, render, sealed_counters, validate_aggregates


class AggregateReport(unittest.TestCase):
    def fixture(self):
        score = {'planned': 2215, 'delivery_passed': 2000, 'benchmark_generation_complete': True,
                 'invalid_or_missing_finals': 215, 'QA': {'F1': .25, 'EM': .1},
                 'ES': {'F1': .5, 'EM': .4}, 'Main': {'F1': .2, 'EM': .05}}
        completion = {'attempted_confirmed': 2215, 'http_errors': 0, 'transport_errors': 0,
                      'refusals': 0, 'truncations': 215}
        return score, completion

    def test_native_unit_fractions_are_displayed_as_percentages_once(self):
        score, completion = self.fixture()
        output = render(score, completion)
        self.assertIn('| Answer | 25.00% | 10.00% |', output)
        self.assertIn('| Joint answer and evidence | 20.00% | 5.00% |', output)
        self.assertIn('2,215/2,215', output)
        self.assertIn('remain preserved privately', output)

    def test_interrupted_run_is_not_described_as_complete(self):
        score, completion = self.fixture()
        score['benchmark_generation_complete'] = False
        completion['attempted_confirmed'] = 10
        completion['http_errors'] = 1
        output = render(score, completion)
        self.assertIn('10/2,215', output)
        self.assertIn('Full generation completed: **False**', output)
        self.assertIn('HTTP/transport/refusal counts: **1/0/0**', output)
        self.assertNotIn('Each question received', output)
        self.assertIn('Each dispatched request was constructed', output)

    def test_restricted_upstream_is_referenced_and_explicitly_excluded(self):
        output = render(*self.fixture())
        self.assertIn('upstream evaluator source and license text are also excluded', output)
        self.assertIn(UPSTREAM_SOURCE_EXCLUSION['evaluator_sha256'], output)
        self.assertIn(UPSTREAM_SOURCE_EXCLUSION['evaluator_url'], output)
        self.assertIn(UPSTREAM_SOURCE_EXCLUSION['license_url'], output)


class AggregateBinding(unittest.TestCase):
    def setUp(self):
        self.config = {'planned': 2, 'task_id': 'V07', 'run_id': 'synthetic-only',
                       'protocol_id': 'synthetic-protocol', 'generation': {'synthetic_only': True},
                       'model_revision': 'synthetic-revision', 'native_scorer': {'sha256': 'n' * 64}}
        self.counts = dict.fromkeys(COUNTERS, 0)
        self.counts.update(attempted_confirmed=2, responses_saved=2, delivery_passed=1,
                           invalid_model_finals=1, truncations=1)
        self.score_path = Path('/tmp/synthetic-v07/scores.json')
        self.score = {'planned': 2, 'delivery_passed': 1, 'missing_finals': 1, 'invalid_or_missing_finals': 1,
                      'QA': {'F1': .25, 'EM': .5}, 'ES': {'F1': .5, 'EM': 0.}, 'Main': {'F1': .25, 'EM': 0.},
                      'task_id': 'V07', 'run_id': 'synthetic-only', 'protocol_id': 'synthetic-protocol',
                      'prediction_lock_sha256': 'l' * 64, 'scorer_config_sha256': 'c' * 64,
                      'scorer_sha256': 's' * 64, 'native_scorer_sha256': 'n' * 64,
                      'scored_at_pacific': '2026-10-21T12:01:00-07:00',
                      'formula_changes': False, 'full_denominator_metric': True,
                      'all_planned_attempted': True, 'terminal_disposition_complete': True,
                      'benchmark_generation_complete': True, 'all_finals_valid': False,
                      'comparison': 'Released SlideVQA test adaptation; not exact Ryze Table3 reproduction',
                      'raw_licensed_content_publishable': False}
        self.completion = {**self.counts, 'planned': 2, 'terminal_case_dispositions': 2,
                           'observed_attempted_terminal': 2, 'all_passed': False,
                           'phase': 'benchmark_generation', 'protocol_id': 'synthetic-protocol',
                           'generation': {'synthetic_only': True}, 'model_revision': 'synthetic-revision',
                           'images_per_case': 20, 'prediction_lock_path': '/tmp/synthetic-v07/prediction_lock.json',
                           'prediction_lock_sha256': 'l' * 64, 'biological_correctness_assessed': False,
                           'catalog_complete': False, 'finished_at_pacific': '2026-10-21T12:00:00-07:00'}
        self.attempt = {'task_id': 'V07', 'run_id': 'synthetic-only', 'prediction_lock_sha256': 'l' * 64,
                        'scorer_config_sha256': 'c' * 64, 'scorer_sha256': 's' * 64,
                        'output': str(self.score_path), 'reference_access_begins_after_this_once_only_claim': True,
                        'started_at_pacific': '2026-10-21T12:00:30-07:00'}

    def validate(self):
        validate_aggregates(self.score, self.completion, self.attempt, self.config, self.counts,
                            self.score_path, 'l' * 64, 'c' * 64, 's' * 64)

    def test_exact_synthetic_binding_passes(self):
        self.validate()

    def test_unknown_fields_are_not_exported(self):
        for target in (self.score, self.completion, self.attempt):
            target['unexpected_raw_text'] = 'invented example'
            with self.assertRaises(ValueError): self.validate()
            del target['unexpected_raw_text']

    def test_metric_fractions_reject_nan_infinity_range_and_bool(self):
        for value in (float('nan'), float('inf'), -.1, 1.1, True):
            with self.subTest(value=value):
                self.score['QA']['F1'] = value
                with self.assertRaises(ValueError): self.validate()
        self.score['QA']['F1'] = .25

    def test_counts_and_complete_flags_match_seal(self):
        for key, value in [('missing_finals', 0), ('invalid_or_missing_finals', 0), ('delivery_passed', True),
                           ('all_planned_attempted', False), ('benchmark_generation_complete', False),
                           ('all_finals_valid', True)]:
            original = self.score[key]; self.score[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError): self.validate()
            self.score[key] = original
        self.completion['truncations'] = 0
        with self.assertRaises(ValueError): self.validate()

    def test_exact_scorer_native_and_attempt_bindings_required(self):
        for target, key in [(self.score, 'native_scorer_sha256'), (self.score, 'scorer_sha256'),
                            (self.attempt, 'run_id'), (self.attempt, 'scorer_config_sha256'),
                            (self.attempt, 'output'), (self.attempt, 'scorer_sha256')]:
            original = target[key]; target[key] = 'changed'
            with self.subTest(key=key), self.assertRaises(ValueError): self.validate()
            target[key] = original
        self.attempt['reference_access_begins_after_this_once_only_claim'] = False
        with self.assertRaises(ValueError): self.validate()

    def test_timestamps_cannot_contain_raw_text(self):
        self.completion['finished_at_pacific'] = 'invented raw text'
        with self.assertRaises(ValueError): self.validate()

    def test_sealed_counters_come_from_outcomes_and_response_envelopes(self):
        with tempfile.TemporaryDirectory() as folder:
            run = Path(folder); (run / 'outcomes').mkdir(); (run / 'responses').mkdir()
            outcomes = [{'case_id': 'a', 'attempted': True, 'status': 'delivered'},
                        {'case_id': 'b', 'attempted': True, 'status': 'invalid_model_final'}]
            files = []; index = []
            for outcome in outcomes:
                relative = 'outcomes/' + outcome['case_id'] + '.json'
                (run / relative).write_text(json.dumps(outcome)); index.append({'path': relative})
            bodies = [{'choices': [{'finish_reason': 'stop', 'message': {'content': 'invented final'}}]},
                      {'choices': [{'finish_reason': 'length', 'message': {'content': None}}]}]
            for number, body in enumerate(bodies):
                relative = f'responses/{number}.json'
                (run / relative).write_text(json.dumps(body)); files.append({'path': relative})
            counts = sealed_counters(run, {'outcomes': index, 'files': files}, lambda message: False)
            self.assertEqual(2, counts['attempted_confirmed'])
            self.assertEqual(1, counts['delivery_passed'])
            self.assertEqual(1, counts['invalid_model_finals'])
            self.assertEqual(1, counts['truncations'])
            self.assertEqual(1, counts['empty_finals'])
            self.assertEqual(0, counts['refusals'])


if __name__ == '__main__':
    unittest.main()
