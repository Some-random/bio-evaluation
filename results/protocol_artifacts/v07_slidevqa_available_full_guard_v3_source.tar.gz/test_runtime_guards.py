"""Synthetic-only runtime and prediction-seal regression checks; no model calls."""
import copy
import hashlib
import http.client
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch

TASK = Path(__file__).resolve().parent
sys.path.insert(0, str(TASK))

import run
import score
from slidevqa_adapter import digest, write_json


FINAL = '{"answer":"fictional blue circle","evidence_pages":[2]}'


class ResponseEnvelope(unittest.TestCase):
    def setUp(self):
        self.config = {
            "model": "synthetic-qwen",
            "generation": {"max_tokens": 8},
            "required_server": {"context_limit": 4096},
        }
        self.body = {
            "id": "synthetic-response",
            "object": "chat.completion",
            "model": "synthetic-qwen",
            "choices": [{"index": 0, "finish_reason": "stop",
                         "message": {"role": "assistant", "content": FINAL, "refusal": None}}],
            "usage": {"prompt_tokens": 120, "completion_tokens": 8, "total_tokens": 128},
        }

    def assert_rejected(self, body):
        with self.assertRaises(ValueError):
            run.parse_response(body, self.config, 120)

    def test_valid_envelope_preserves_final_and_usage(self):
        choice, message, final, usage = run.parse_response(self.body, self.config, 120)
        self.assertEqual(0, choice["index"])
        self.assertEqual("assistant", message["role"])
        self.assertEqual(FINAL, final)
        self.assertEqual(self.body["usage"], usage)

    def test_malformed_envelopes_have_controlled_failures(self):
        cases = [None, [], "response", {}, {**self.body, "choices": None},
                 {**self.body, "choices": []}, {**self.body, "choices": [None]}]
        for body in cases:
            with self.subTest(body=body):
                self.assert_rejected(body)

    def test_none_message_is_rejected_without_attribute_error(self):
        body = copy.deepcopy(self.body)
        body["choices"][0]["message"] = None
        self.assert_rejected(body)

    def test_multiple_choices_are_rejected(self):
        body = copy.deepcopy(self.body)
        body["choices"].append(copy.deepcopy(body["choices"][0]))
        body["choices"][1]["index"] = 1
        self.assert_rejected(body)

    def test_wrong_choice_index_is_rejected(self):
        body = copy.deepcopy(self.body)
        body["choices"][0]["index"] = 1
        self.assert_rejected(body)

    def test_wrong_model_and_role_are_rejected(self):
        body = copy.deepcopy(self.body)
        body["model"] = "different-checkpoint"
        self.assert_rejected(body)
        body = copy.deepcopy(self.body)
        body["choices"][0]["message"]["role"] = "user"
        self.assert_rejected(body)

    def test_explicit_refusal_is_rejected(self):
        body = copy.deepcopy(self.body)
        body["choices"][0]["message"]["refusal"] = "Synthetic refusal fixture"
        self.assert_rejected(body)

    def test_missing_or_invalid_usage_is_rejected(self):
        for usage in (None, [], {}, {"prompt_tokens": 120},
                      {"prompt_tokens": True, "completion_tokens": 8, "total_tokens": 128},
                      {"prompt_tokens": 120, "completion_tokens": -1, "total_tokens": 119},
                      {"prompt_tokens": 120, "completion_tokens": 8, "total_tokens": 129}):
            body = copy.deepcopy(self.body)
            body["usage"] = usage
            with self.subTest(usage=usage):
                self.assert_rejected(body)
        body = copy.deepcopy(self.body)
        del body["usage"]
        self.assert_rejected(body)

    def test_prompt_token_mismatch_is_rejected(self):
        body = copy.deepcopy(self.body)
        body["usage"].update(prompt_tokens=119, total_tokens=127)
        self.assert_rejected(body)

    def test_completion_budget_and_context_overruns_are_rejected(self):
        body = copy.deepcopy(self.body)
        body["usage"].update(completion_tokens=9, total_tokens=129)
        self.assert_rejected(body)
        self.config["required_server"]["context_limit"] = 127
        self.assert_rejected(self.body)


class PredictionSeal(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.directory = self.root / "run"
        (self.directory / "outcomes").mkdir(parents=True)
        image = self.root / "synthetic.png"
        image.write_bytes(b"Synthetic fixture; never sent to a model")
        rows = [{"case_id": case_id, "question": "Which fictional shape is blue?",
                 "deck_name": "synthetic-deck", "pages": [
                     {"page_number": page, "image_path": str(image), "sha256": digest(image),
                      "source_variant": "synthetic"} for page in range(1, 21)]}
                for case_id in ("synthetic-a", "synthetic-b")]
        inputs = self.root / "synthetic_inputs.jsonl"
        inputs.write_text("".join(json.dumps(row) + "\n" for row in rows))
        self.config = {
            "task_id": "V07", "run_id": "synthetic-run", "phase": "benchmark_generation",
            "protocol_id": "SYNTHETIC_RUNTIME_GUARDS", "planned": 2,
            "generation": {"n": 1, "seed": 42, "max_tokens": 8},
            "model_inputs": {"path": str(inputs), "count": 2, "sha256": digest(inputs)},
            "__config_sha256": "1" * 64, "__runner_sha256": "2" * 64,
            "__adapter_sha256": "3" * 64,
        }
        self.manifest = {
            key: self.config[key] for key in
            ("task_id", "run_id", "phase", "protocol_id", "planned", "generation")
        }
        self.manifest.update({"input_sha256": digest(inputs), "config_sha256": "1" * 64,
                              "runner_sha256": "2" * 64, "adapter_sha256": "3" * 64,
                              "reference_files_read": False})
        write_json(self.directory / "run_manifest.json", self.manifest)
        outcomes = []
        for case_id in ("synthetic-a", "synthetic-b"):
            relative = "outcomes/" + case_id + ".json"
            write_json(self.directory / relative, {
                "case_id": case_id, "attempted": True, "delivery_passed": True,
                "status": "delivered", "final": FINAL, "finish_reason": "stop",
            })
            outcomes.append({"case_id": case_id, "path": relative})
        self.lock = {"terminal": True, "planned": 2, "all_planned_attempted": True,
                     "outcomes": outcomes, "files": []}
        self.seal()

    def tearDown(self):
        self.temporary.cleanup()

    def seal(self):
        paths = ["run_manifest.json"] + [entry["path"] for entry in self.lock["outcomes"]]
        self.lock["files"] = [{"path": path, "sha256": digest(self.directory / path)} for path in paths]
        self.save_lock()

    def save_lock(self):
        write_json(self.directory / "prediction_lock.json", self.lock)

    def assert_rejected(self):
        with self.assertRaises(ValueError):
            score.verify_prediction_lock(self.directory, self.config)

    def test_complete_synthetic_seal_is_accepted(self):
        predictions, lock, manifest = score.verify_prediction_lock(self.directory, self.config)
        self.assertEqual({"synthetic-a": FINAL, "synthetic-b": FINAL}, predictions)
        self.assertEqual(self.lock, lock)
        self.assertEqual(self.manifest, manifest)

    def test_changed_outcome_is_rejected(self):
        path = self.directory / self.lock["outcomes"][0]["path"]
        row = json.loads(path.read_text())
        row["final"] = '{"answer":"changed fictional answer","evidence_pages":[3]}'
        write_json(path, row)
        self.assert_rejected()

    def test_outcome_must_be_in_hashed_file_list(self):
        self.lock["files"] = [entry for entry in self.lock["files"]
                              if entry["path"] != self.lock["outcomes"][0]["path"]]
        self.save_lock()
        self.assert_rejected()

    def test_manifest_must_be_in_hashed_file_list(self):
        self.lock["files"] = [entry for entry in self.lock["files"] if entry["path"] != "run_manifest.json"]
        self.save_lock()
        self.assert_rejected()

    def test_unsealed_extra_outcome_is_rejected(self):
        write_json(self.directory / "outcomes" / "unsealed.json", {
            "case_id": "extra-synthetic", "delivery_passed": False, "final": None,
        })
        self.assert_rejected()

    def test_outcome_path_cannot_escape_run(self):
        external = self.root / "external-outcome.json"
        write_json(external, {"case_id": "synthetic-a", "delivery_passed": True, "final": FINAL})
        self.lock["outcomes"][0]["path"] = "../external-outcome.json"
        self.lock["files"].append({"path": "../external-outcome.json", "sha256": digest(external)})
        self.save_lock()
        self.assert_rejected()

    def test_symlinked_outcome_cannot_escape_run(self):
        path = self.directory / self.lock["outcomes"][0]["path"]
        external = self.root / "external-outcome.json"
        external.write_bytes(path.read_bytes())
        path.unlink()
        path.symlink_to(external)
        self.assert_rejected()

    def test_outcome_index_case_id_must_match_record(self):
        self.lock["outcomes"][0]["case_id"] = "different-index-id"
        self.save_lock()
        self.assert_rejected()

    def test_duplicate_or_missing_terminal_record_is_rejected(self):
        original = copy.deepcopy(self.lock)
        self.lock["outcomes"][1] = copy.deepcopy(self.lock["outcomes"][0])
        self.save_lock()
        self.assert_rejected()
        self.lock = original
        self.lock["outcomes"].pop()
        self.save_lock()
        self.assert_rejected()

    def test_foreign_case_id_is_rejected_before_reference_access(self):
        path = self.directory / self.lock["outcomes"][0]["path"]
        row = json.loads(path.read_text())
        row["case_id"] = "foreign-synthetic"
        write_json(path, row)
        self.lock["outcomes"][0]["case_id"] = row["case_id"]
        self.seal()
        self.assert_rejected()

    def test_unfinished_lock_is_rejected(self):
        self.lock["terminal"] = False
        self.save_lock()
        self.assert_rejected()

    def test_manifest_identity_and_execution_hashes_are_bound(self):
        original = copy.deepcopy(self.manifest)
        changes = {"task_id": "OTHER", "run_id": "another-run", "phase": "development",
                   "protocol_id": "OTHER", "planned": 3, "generation": {"max_tokens": 9},
                   "input_sha256": "4" * 64, "config_sha256": "5" * 64,
                   "runner_sha256": "6" * 64, "adapter_sha256": "7" * 64}
        for key, value in changes.items():
            self.manifest = {**original, key: value}
            write_json(self.directory / "run_manifest.json", self.manifest)
            self.seal()
            with self.subTest(key=key):
                self.assert_rejected()


class ReferenceCohort(unittest.TestCase):
    def test_duplicate_reference_ids_are_rejected_before_native_metrics(self):
        def forbidden_metric(*args):
            self.fail("Duplicate reference IDs reached the native scorer")
        native = {name: forbidden_metric for name in
                  ("evaluate_f1_em_qa", "evaluate_f1_em_es", "evaluate_f1_em_main")}
        row = {"case_id": "synthetic-a", "question": "Which fictional shape?",
               "answer": "fictional blue circle", "evidence_pages": [2]}
        with self.assertRaises(ValueError):
            score.score_predictions(native, [row, copy.deepcopy(row)], {"synthetic-a": FINAL})


class ScoringAttempt(unittest.TestCase):
    setUp = PredictionSeal.setUp
    tearDown = PredictionSeal.tearDown
    seal = PredictionSeal.seal
    save_lock = PredictionSeal.save_lock

    def prepare_scoring(self):
        for expected, actual, filename in (
                ("__runner_sha256", "runner_sha256", "run.py"),
                ("__adapter_sha256", "adapter_sha256", "slidevqa_adapter.py")):
            self.config[expected] = self.manifest[actual] = digest(TASK / filename)
        self.config["__scorer_sha256"] = digest(TASK / "score.py")
        write_json(self.directory / "run_manifest.json", self.manifest)
        self.seal()
        self.references = self.root / "synthetic_references.jsonl"
        self.references.write_text("".join(json.dumps({
            "case_id": case_id, "question": "Which fictional shape?",
            "answer": "fictional blue circle", "evidence_pages": [2],
        }) + "\n" for case_id in ("synthetic-a", "synthetic-b")))
        self.config["references"] = {"path": str(self.references), "sha256": digest(self.references)}
        self.config["native_scorer"] = {"path": str(self.root / "unused_synthetic_scorer.py"),
                                         "sha256": "0" * 64}
        self.config_path = self.root / "synthetic_scorer_config.json"
        write_json(self.config_path, self.config)
        self.native = {
            "evaluate_f1_em_qa": lambda ground_truth, predictions: {"F1": 1.0, "EM": 1.0},
            "evaluate_f1_em_es": lambda ground_truth, predictions: {"F1": 1.0, "EM": 1.0},
            "evaluate_f1_em_main": lambda qa, evidence: {"F1": 1.0, "EM": 1.0},
        }

    def invoke(self, output):
        with patch.object(sys, "argv", [str(TASK / "score.py"), "--config", str(self.config_path),
                                        "--run", str(self.directory), "--output", str(output)]):
            score.main()

    def test_alternate_output_cannot_score_same_run_twice(self):
        self.prepare_scoring()
        reads = []
        original = score.read_jsonl
        def tracked(path):
            if Path(path) == self.references:
                reads.append(path)
            return original(path)
        with patch.object(score, "native_metric_functions", return_value=self.native) as native_loader, \
                patch.object(score, "read_jsonl", side_effect=tracked):
            self.invoke(self.root / "first-score.json")
            with self.assertRaises(FileExistsError):
                self.invoke(self.root / "second-score.json")
        self.assertEqual(1, len(reads))
        self.assertEqual(1, native_loader.call_count)
        self.assertFalse((self.root / "second-score.json").exists())

    def test_failure_after_claim_remains_once_only(self):
        self.prepare_scoring()
        self.config["references"]["sha256"] = "f" * 64
        write_json(self.config_path, self.config)
        with patch.object(score, "native_metric_functions", return_value=self.native) as native_loader:
            with self.assertRaisesRegex(ValueError, "Reference file changed"):
                self.invoke(self.root / "failed-score.json")
            self.assertTrue((self.directory / "scoring_attempt.json").is_file())
            with self.assertRaises(FileExistsError):
                self.invoke(self.root / "second-score.json")
        self.assertEqual(0, native_loader.call_count)

    def test_invalid_seal_never_opens_reference_file(self):
        self.prepare_scoring()
        path = self.directory / self.lock["outcomes"][0]["path"]
        path.write_text("changed synthetic prediction\n")
        original_digest = score.digest
        def guarded_digest(path):
            if Path(path) == self.references:
                self.fail("Invalid prediction seal opened the reference file")
            return original_digest(path)
        with patch.object(score, "digest", side_effect=guarded_digest), \
                patch.object(score, "native_metric_functions") as native_loader:
            with self.assertRaises(ValueError):
                self.invoke(self.root / "blocked-score.json")
        self.assertEqual(0, native_loader.call_count)
        self.assertFalse((self.directory / "scoring_attempt.json").exists())


class RuntimeStopAndSeal(unittest.TestCase):
    setUp = PredictionSeal.setUp
    tearDown = PredictionSeal.tearDown
    seal = PredictionSeal.seal
    save_lock = PredictionSeal.save_lock

    def prepare_runtime(self):
        self.config.update({"model": "synthetic-qwen", "model_revision": "synthetic-revision",
                            "required_server": {"context_limit": 4096}})
        self.config_path = self.root / "synthetic_generation_config.json"
        write_json(self.config_path, self.config)
        self.output = self.root / "new-generation"
        self.grant_path = self.root / "synthetic_grant.json"
        write_json(self.grant_path, {"output_root": str(self.output)})
        self.preflight = self.root / "processor" / "completion.json"
        write_json(self.preflight, {"synthetic_only": True})
        self.rows = run.read_jsonl(self.config["model_inputs"]["path"])
        observations = [{"case_id": row["case_id"], "input_tokens": 120,
                         "input_row_sha256": hashlib.sha256(json.dumps(
                             row, ensure_ascii=False, sort_keys=True).encode()).hexdigest()}
                        for row in self.rows]
        (self.preflight.parent / "cases.jsonl").write_text(
            "".join(json.dumps(row) + "\n" for row in observations))
        self.development = self.root / "unused_synthetic_development.json"
        write_json(self.development, {"synthetic_only": True})
        self.fake_runner = self.root / "runtime" / "run.py"
        self.fake_runner.parent.mkdir()
        self.fake_runner.write_text("Synthetic runtime identity; never executed\n")
        self.fake_runner.with_name("slidevqa_adapter.py").write_text("Synthetic adapter identity\n")
        self.body = {
            "model": "synthetic-qwen",
            "choices": [{"index": 0, "finish_reason": "stop",
                         "message": {"role": "assistant", "content": FINAL, "refusal": None}}],
            "usage": {"prompt_tokens": 120, "completion_tokens": 8, "total_tokens": 128},
        }
        self.opener = MagicMock()
        self.opener.open.return_value.__enter__.return_value.read.return_value = json.dumps(self.body).encode()

    def invoke(self):
        argv = [str(TASK / "run.py"), "--config", str(self.config_path), "--output", str(self.output),
                "--grant", str(self.grant_path), "--processor-preflight", str(self.preflight),
                "--development-completion", str(self.development)]
        with patch.object(sys, "argv", argv), patch.object(run, "__file__", str(self.fake_runner)), \
                patch.object(run, "validate_config", return_value=(self.config, self.rows)), \
                patch.object(run, "validate_gates", return_value=("http://127.0.0.1:1/v1", {"synthetic_only": True})), \
                patch.object(run.urllib.request, "build_opener", return_value=self.opener):
            run.main()

    def check_seal(self, attempted, passed, not_dispatched):
        completion = json.loads((self.output / "completion.json").read_text())
        self.assertEqual(2, completion["terminal_case_dispositions"])
        self.assertEqual(attempted, completion["attempted_confirmed"])
        self.assertEqual(passed, completion["delivery_passed"])
        self.assertEqual(not_dispatched, completion["not_dispatched"])
        config = {**self.config, "__config_sha256": digest(self.config_path),
                  "__runner_sha256": digest(self.fake_runner),
                  "__adapter_sha256": digest(self.fake_runner.with_name("slidevqa_adapter.py"))}
        predictions, lock, _ = score.verify_prediction_lock(self.output, config)
        self.assertTrue(lock["terminal"])
        self.assertEqual(2, len(predictions))
        self.assertEqual(passed, sum(value is not None for value in predictions.values()))
        return completion

    def test_normal_responses_seal_complete_two_case_run(self):
        self.prepare_runtime()
        self.invoke()
        completion = self.check_seal(attempted=2, passed=2, not_dispatched=0)
        self.assertTrue(completion["all_passed"])
        self.assertEqual(2, self.opener.open.call_count)
        for path in (self.output / "requests").iterdir():
            request = json.loads(path.read_text())
            self.assertEqual(20, sum(item["type"] == "image_url" for item in request["messages"][0]["content"]))

    def test_refusal_stops_once_and_seals_every_disposition(self):
        self.prepare_runtime()
        self.body["choices"][0]["message"]["refusal"] = "Synthetic refusal fixture"
        self.opener.open.return_value.__enter__.return_value.read.return_value = json.dumps(self.body).encode()
        self.invoke()
        completion = self.check_seal(attempted=1, passed=0, not_dispatched=1)
        self.assertEqual(1, completion["refusals"])
        self.assertEqual(1, self.opener.open.call_count)

    def test_malformed_response_stops_once_and_seals_every_disposition(self):
        self.prepare_runtime()
        self.body["choices"][0]["message"] = None
        self.opener.open.return_value.__enter__.return_value.read.return_value = json.dumps(self.body).encode()
        self.invoke()
        completion = self.check_seal(attempted=1, passed=0, not_dispatched=1)
        self.assertEqual(1, completion["response_errors"])
        self.assertEqual(1, self.opener.open.call_count)

    def test_incomplete_http_read_stops_once_and_seals_every_disposition(self):
        self.prepare_runtime()
        self.opener.open.side_effect = http.client.IncompleteRead(b"synthetic partial response", 100)
        self.invoke()
        completion = self.check_seal(attempted=1, passed=0, not_dispatched=1)
        self.assertEqual(1, completion["transport_errors"])
        self.assertEqual(1, self.opener.open.call_count)

    def test_changed_input_stops_without_dispatch_and_seals_every_disposition(self):
        self.prepare_runtime()
        with patch.object(run, "build_messages", side_effect=ValueError("Synthetic changed image")):
            self.invoke()
        completion = self.check_seal(attempted=0, passed=0, not_dispatched=1)
        self.assertEqual(1, completion["input_errors"])
        self.assertEqual(0, self.opener.open.call_count)

    def test_run_claim_prevents_second_attempt_with_new_output(self):
        self.prepare_runtime()
        self.body["choices"][0]["message"]["refusal"] = "Synthetic refusal fixture"
        self.opener.open.return_value.__enter__.return_value.read.return_value = json.dumps(self.body).encode()
        self.invoke()
        self.output = self.root / "different-output"
        write_json(self.grant_path, {"output_root": str(self.output)})
        with self.assertRaises(FileExistsError):
            self.invoke()
        self.assertEqual(1, self.opener.open.call_count)
        self.assertFalse(self.output.exists())


if __name__ == "__main__":
    unittest.main()
