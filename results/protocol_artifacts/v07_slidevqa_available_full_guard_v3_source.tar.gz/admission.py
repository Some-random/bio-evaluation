"""Exact independent admission for one V07 full-deck allocation."""
from pathlib import Path
import hashlib, importlib.util, json, os

HERE=Path(__file__).resolve().parent
TASK=HERE.parent
ROOT=TASK.parents[3]
POLICY=ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review_resume_v2.json'
OWNER='/root/v07_execution'
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def validate(plan_path,plan_sha,admission_path=None,admission_sha=None,require_job=False):
    if sha(plan_path)!=plan_sha:raise ValueError('Frozen exact V07 plan required')
    p=json.loads(Path(plan_path).read_bytes())
    expected={'task_id':'V07','engineering_owner':OWNER,'requested_GPUs':1,'project_GPU_ceiling':8,
        'maximum_attempts_per_case':1,'native_metric_formulas_unchanged':True,'new_training':False,
        'paid_model_calls':False,'automatic_retries':False,'source_case_denominator':2215}
    if any(p.get(k)!=v for k,v in expected.items()):raise ValueError('Wrong retained V07 condition')
    if p.get('execution_scope')not in ('neutral_delivery_only','reviewed_full_benchmark'):
        raise PermissionError('Exact phase scope required')
    expected_runtime=HERE/('neutral_delivery_runtime'if p['execution_scope']=='neutral_delivery_only'else'runtime')
    expected_submit=HERE/('neutral_delivery_submission'if p['execution_scope']=='neutral_delivery_only'else'submission')
    if p.get('runtime_root')!=str(expected_runtime)or p.get('submission_root')!=str(expected_submit):
        raise PermissionError('Exact isolated phase runtime/submission roots required')
    if p['execution_scope']=='neutral_delivery_only'and(p.get('planned_cases')!=0 or set(p['phases'])!={'development'}):
        raise PermissionError('Neutral-only admission cannot contain real benchmark dispatch')
    for name,hash_value in p['frozen_files_sha256'].items():
        f=Path(name)
        if f.is_symlink()or sha(f)!=hash_value:raise ValueError('Frozen source/config/receipt changed: '+f.name)
    if admission_path:
        if sha(admission_path)!=admission_sha:raise ValueError('Detached independent admission changed')
        a=json.loads(Path(admission_path).read_bytes());reviewer=a.get('reviewer')
        policy=json.loads(POLICY.read_bytes())
        if (a.get('admitted')is not True or a.get('task_id')!='V07'or a.get('plan_sha256')!=plan_sha
                or a.get('delegation_sha256')!=sha(POLICY)or reviewer==OWNER
                or reviewer not in policy['authorized_reviewers']+['root','/root']
                or a.get('gpu_count')!=1 or a.get('project_gpu_ceiling')!=8
                or a.get('authorized_scope')!=p['execution_scope']
                or a.get('one_attempt_per_case')is not True):
            raise PermissionError('Different independently admitted exact V07 plan required')
    elif require_job:raise PermissionError('No runtime without independent admission')
    if require_job and not os.environ.get('SLURM_JOB_ID'):raise PermissionError('Standalone Slurm allocation required')
    return p
def gpu_audit(p):
    helper=load('v07_pinned_GPU_accounting',p['GPU_audit_helper'])
    receipt=helper.conservative_project_gpu_audit(require_own_job=True)
    own=[r for r in receipt['jobs']if r['job_id']==os.environ['SLURM_JOB_ID']]
    if len(own)!=1 or own[0]['gpus']!=1 or own[0]['workdir']!=str(ROOT)or own[0]['command']!=str(HERE/'worker.sbatch'):
        raise PermissionError('Exact own one-GPU worker identity required')
    return receipt
