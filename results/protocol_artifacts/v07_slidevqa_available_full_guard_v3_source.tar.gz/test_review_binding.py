"""Invented source-review bindings exercise admission failures without real content."""
import copy
import hashlib
import tempfile
import unittest
from pathlib import Path
from review_binding import expected_case_binding, file_sha256, validate_review_bindings


class ExactReviewBindings(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.evidence = self.root / 'input_review.json'
        self.evidence.write_text('{"synthetic_only": true}')
        self.source_sha = hashlib.sha256(b'synthetic input source').hexdigest()
        self.rows = [{'case_id': 'synthetic-a', 'question': 'What color is the square?',
                      'pages': [{'page_number': 1, 'sha256': 'a' * 64}]},
                     {'case_id': 'synthetic-b', 'question': 'What color is the triangle?',
                      'pages': [{'page_number': 1, 'sha256': 'b' * 64}]}]
        self.reviews = [{**expected_case_binding(row, self.source_sha),
                         'dispatch_approved': True, 'question_content_reviewed': True,
                         'image_content_reviewed': True, 'reviewer': '/root/independent',
                         'global_hold_reconciliation_complete': True,
                         'question_context_flag_requires_final_coordinator_resolution': False,
                         'source_reviewers': ['/root/old_source_reviewer'],
                         'review_evidence': [{'path': str(self.evidence), 'sha256': file_sha256(self.evidence)}]}
                        for row in self.rows]

    def tearDown(self):
        self.temp.cleanup()

    def validate(self, reviews=None, rows=None):
        return validate_review_bindings(rows or self.rows, self.reviews if reviews is None else reviews,
                                        self.source_sha, ['/root/independent'], '/root/owner', self.root)

    def test_exact_canonical_bindings_pass_and_deduplicate_evidence(self):
        self.assertEqual({str(self.evidence): file_sha256(self.evidence)}, self.validate())

    def test_each_source_question_row_and_page_binding_is_required(self):
        for key in ('input_source_sha256', 'input_row_sha256', 'question_sha256', 'pages_sha256'):
            reviews = copy.deepcopy(self.reviews)
            reviews[0][key] = '0' * 64
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.validate(reviews)

    def test_order_duplicate_and_missing_case_are_rejected(self):
        for reviews in (list(reversed(self.reviews)), [self.reviews[0]] * 2, self.reviews[:1]):
            with self.subTest(reviews=reviews), self.assertRaises(ValueError):
                self.validate(reviews)

    def test_changed_source_question_or_pages_is_rejected(self):
        for key in ('question', 'pages'):
            rows = copy.deepcopy(self.rows)
            rows[0][key] = 'Changed synthetic question' if key == 'question' else list(reversed(self.rows[1]['pages']))
            with self.subTest(key=key), self.assertRaises(ValueError):
                self.validate(rows=rows)

    def test_unknown_held_owner_and_unadmitted_coordinator_are_rejected(self):
        variants = [('dispatch_approved', False), ('image_content_reviewed', False),
                    ('reviewer', '/root/owner'), ('reviewer', '/root/not_authorized'),
                    ('source_reviewers', []), ('source_reviewers', ['/root/owner']),
                    ('global_hold_reconciliation_complete', False),
                    ('question_context_flag_requires_final_coordinator_resolution', True)]
        for key, value in variants:
            reviews = copy.deepcopy(self.reviews); reviews[0][key] = value
            with self.subTest(key=key, value=value), self.assertRaises(PermissionError):
                self.validate(reviews)

    def test_changed_missing_and_symlink_evidence_is_rejected(self):
        self.evidence.write_text('changed synthetic evidence')
        with self.assertRaises(ValueError): self.validate()
        self.evidence.unlink()
        with self.assertRaises(ValueError): self.validate()
        target = self.root / 'target'; target.write_text('synthetic target')
        self.evidence.symlink_to(target)
        with self.assertRaises(ValueError): self.validate()

    def test_reference_like_evidence_is_rejected_without_reading(self):
        path = self.root / 'scorer_only' / 'hidden.json'
        reviews = copy.deepcopy(self.reviews)
        reviews[0]['review_evidence'] = [{'path': str(path), 'sha256': 'a' * 64}]
        with self.assertRaisesRegex(ValueError, 'Reference material'):
            self.validate(reviews)

    def test_no_evidence_or_noncanonical_path_is_rejected(self):
        for evidence in ([], [{'path': str(self.root / 'absent' / '..' / self.evidence.name),
                               'sha256': file_sha256(self.evidence)}]):
            reviews = copy.deepcopy(self.reviews); reviews[0]['review_evidence'] = evidence
            with self.subTest(evidence=evidence), self.assertRaises(ValueError):
                self.validate(reviews)


if __name__ == '__main__':
    unittest.main()
