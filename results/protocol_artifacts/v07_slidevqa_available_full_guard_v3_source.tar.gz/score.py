#!/usr/bin/env python3
"""Hash-lock predictions before opening isolated references; native formulas."""
import argparse
import json
import os
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from slidevqa_adapter import digest, native_metric_functions, parse_final, read_jsonl


def score_predictions(native, references, predictions):
    reference_ids = [r["case_id"] for r in references]
    if len(reference_ids) != len(set(reference_ids)):
        raise ValueError("Duplicate reference IDs")
    if set(predictions) - set(reference_ids):
        raise ValueError("Foreign prediction IDs")
    gts, preds = {}, {}
    invalid = missing = 0
    for row in references:
        key = row["case_id"]
        gts[key] = {"question": row["question"], "answer": row["answer"], "evidence_pages": row["evidence_pages"]}
        value = predictions.get(key)
        if value is None:
            missing += 1
        try:
            parsed = parse_final(value) if isinstance(value, str) else None
            if parsed is None:
                raise ValueError("No usable final")
        except (ValueError, TypeError, json.JSONDecodeError):
            invalid += 1
            parsed = {"answer": "", "evidence_pages": []}
        preds[key] = parsed
    qa = native["evaluate_f1_em_qa"](gts, preds)
    es = native["evaluate_f1_em_es"](gts, preds)
    joint = native["evaluate_f1_em_main"](qa, es)
    return {"planned": len(references), "missing_finals": missing, "invalid_or_missing_finals": invalid,
            "QA": {k: qa[k] for k in ("F1", "EM")}, "ES": {k: es[k] for k in ("F1", "EM")}, "Main": joint}


def verify_prediction_lock(run_dir, config):
    """Verify the complete frozen prediction cohort without opening references."""
    run_dir = Path(run_dir).resolve()
    if not run_dir.is_dir():
        raise ValueError("Missing run directory")
    planned = config.get("planned")
    if type(planned) is not int or planned < 1:
        raise ValueError("Invalid planned denominator")
    inputs = config.get("model_inputs", {})
    if (not isinstance(inputs, dict) or not inputs.get("path") or inputs.get("count") != planned
            or digest(inputs["path"]) != inputs.get("sha256")):
        raise ValueError("Frozen input cohort changed")
    input_rows = read_jsonl(inputs["path"])
    if any(not isinstance(row, dict) for row in input_rows):
        raise ValueError("Invalid input cohort record")
    input_ids = [row.get("case_id") for row in input_rows]
    if (len(input_ids) != planned or any(not isinstance(key, str) or not key for key in input_ids)
            or len(set(input_ids)) != planned):
        raise ValueError("Invalid or duplicate input IDs")

    lock_path = run_dir / "prediction_lock.json"
    initial_lock_sha256 = digest(lock_path)
    if config.get("__prediction_lock_sha256", initial_lock_sha256) != initial_lock_sha256:
        raise ValueError("Unexpected prediction lock")
    lock = json.loads(lock_path.read_text())
    if (not isinstance(lock, dict) or lock.get("terminal") is not True
            or type(lock.get("planned")) is not int or lock["planned"] != planned):
        raise ValueError("Generation has no complete terminal lock")
    files, outcomes = lock.get("files"), lock.get("outcomes")
    if not isinstance(files, list) or not files or not isinstance(outcomes, list) or len(outcomes) != planned:
        raise ValueError("Incomplete prediction lock inventory")

    def artifact_path(relative):
        if not isinstance(relative, str) or not relative:
            raise ValueError("Invalid sealed artifact path")
        name = Path(relative)
        if (name.is_absolute() or name.as_posix() != relative
                or any(part in (".", "..") for part in name.parts)):
            raise ValueError("Noncanonical sealed artifact path")
        path = run_dir / name
        resolved = path.resolve()
        if not resolved.is_relative_to(run_dir) or resolved != path or not path.is_file():
            raise ValueError("Sealed artifact escapes run or is missing")
        return path

    inventory = {}
    for entry in files:
        if not isinstance(entry, dict) or set(entry) != {"path", "sha256"}:
            raise ValueError("Invalid sealed file entry")
        relative = entry["path"]
        if relative in inventory:
            raise ValueError("Duplicate sealed artifact")
        path = artifact_path(relative)
        if digest(path) != entry["sha256"]:
            raise ValueError("Prediction lock file mismatch")
        inventory[relative] = path
    if "run_manifest.json" not in inventory:
        raise ValueError("Run manifest is not sealed")
    observed_files = {"run_manifest.json"}
    for sub in ("requests", "responses", "outcomes", "errors", "delivery"):
        directory = run_dir / sub
        if directory.exists():
            if not directory.is_dir():
                raise ValueError("Invalid prediction artifact directory")
            for path in directory.iterdir():
                if not path.is_file():
                    raise ValueError("Unexpected nested prediction artifact")
                observed_files.add(str(path.relative_to(run_dir)))
    if set(inventory) != observed_files:
        raise ValueError("Prediction artifact inventory is incomplete")
    manifest = json.loads(inventory["run_manifest.json"].read_text())
    if not isinstance(manifest, dict):
        raise ValueError("Invalid run manifest")
    for key in ("task_id", "run_id", "phase", "protocol_id", "planned", "generation"):
        if key not in config or manifest.get(key) != config[key]:
            raise ValueError("Prediction execution identity mismatch: " + key)
    if manifest.get("task_id") != "V07" or manifest.get("phase") != "benchmark_generation":
        raise ValueError("Only the frozen V07 benchmark condition can be scored")
    if manifest.get("input_sha256") != inputs["sha256"] or manifest.get("reference_files_read") is not False:
        raise ValueError("Prediction/input isolation mismatch")
    for expected, actual in (("__config_sha256", "config_sha256"),
                             ("__runner_sha256", "runner_sha256"),
                             ("__adapter_sha256", "adapter_sha256")):
        if expected in config and manifest.get(actual) != config[expected]:
            raise ValueError("Frozen execution binding mismatch: " + actual)

    predictions, outcome_paths = {}, set()
    attempted = 0
    for entry in outcomes:
        if not isinstance(entry, dict) or set(entry) != {"case_id", "path"}:
            raise ValueError("Invalid outcome index")
        relative = entry["path"]
        if relative not in inventory or Path(relative).parts[0] != "outcomes" or relative in outcome_paths:
            raise ValueError("Unsealed or duplicate terminal outcome")
        outcome_paths.add(relative)
        row = json.loads(inventory[relative].read_text())
        if not isinstance(row, dict):
            raise ValueError("Invalid terminal outcome record")
        case_id = row.get("case_id")
        if case_id != entry["case_id"] or case_id not in input_ids or case_id in predictions:
            raise ValueError("Terminal outcome case identity mismatch")
        if type(row.get("attempted")) is not bool or type(row.get("delivery_passed")) is not bool:
            raise ValueError("Invalid terminal outcome disposition")
        attempted += row["attempted"]
        if row["delivery_passed"]:
            if not row["attempted"] or row.get("finish_reason") != "stop" or row.get("status") != "delivered":
                raise ValueError("Inconsistent delivered outcome")
            try:
                parse_final(row.get("final"))
            except (ValueError, TypeError) as exc:
                raise ValueError("Delivered outcome has an invalid final") from exc
        predictions[case_id] = row.get("final") if row["delivery_passed"] else None
    sealed_outcomes = {relative for relative in inventory if Path(relative).parts[0] == "outcomes"}
    if outcome_paths != sealed_outcomes or set(predictions) != set(input_ids):
        raise ValueError("Incomplete or unindexed terminal outcomes")
    if type(lock.get("all_planned_attempted")) is not bool or lock["all_planned_attempted"] != (attempted == planned):
        raise ValueError("Attempt accounting differs from sealed outcomes")
    if digest(lock_path) != initial_lock_sha256:
        raise ValueError("Prediction lock changed during verification")
    return predictions, lock, manifest


def write_exclusive_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--run", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    config = json.loads(args.config.read_text())
    for expected, path in (("__runner_sha256", Path(__file__).with_name("run.py")),
                           ("__adapter_sha256", Path(__file__).with_name("slidevqa_adapter.py"))):
        if not config.get(expected) or digest(path) != config[expected]:
            raise ValueError("Scoring execution code binding mismatch: " + expected)
    if not config.get("__config_sha256"):
        raise ValueError("Exact generation configuration binding required")
    if not config.get("__scorer_sha256") or digest(__file__) != config["__scorer_sha256"]:
        raise ValueError("Frozen scorer code changed")
    predictions, lock, manifest = verify_prediction_lock(args.run, config)
    lock_path = args.run / "prediction_lock.json"
    lock_sha256, scorer_config_sha256 = digest(lock_path), digest(args.config)
    if args.output.exists():
        raise ValueError("Scoring output already exists; never overwrite an attempt")
    write_exclusive_json(args.run / "scoring_attempt.json", {
        "started_at_pacific": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "task_id": "V07", "run_id": manifest["run_id"],
        "prediction_lock_sha256": lock_sha256, "scorer_config_sha256": scorer_config_sha256,
        "scorer_sha256": digest(__file__), "output": str(args.output.resolve()),
        "reference_access_begins_after_this_once_only_claim": True,
    })
    # Reference access starts only after every frozen prediction artifact is verified.
    if digest(config["references"]["path"]) != config["references"]["sha256"]:
        raise ValueError("Reference file changed")
    references = read_jsonl(config["references"]["path"])
    reference_ids = [row["case_id"] for row in references]
    if len(reference_ids) != config["planned"] or len(set(reference_ids)) != config["planned"] or set(reference_ids) != set(predictions):
        raise ValueError("Reference cohort differs from the complete frozen prediction cohort")
    native = native_metric_functions(config["native_scorer"]["path"], config["native_scorer"]["sha256"])
    result = score_predictions(native, references, predictions)
    result.update({"task_id": "V07", "protocol_id": config["protocol_id"],
                   "scored_at_pacific": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
                   "prediction_lock_sha256": lock_sha256, "scorer_config_sha256": scorer_config_sha256,
                   "run_id": manifest["run_id"], "scorer_sha256": digest(__file__),
                   "native_scorer_sha256": config["native_scorer"]["sha256"],
                   "formula_changes": False, "full_denominator_metric": True,
                   "all_planned_attempted": lock.get("all_planned_attempted", False),
                   "delivery_passed": sum(value is not None for value in predictions.values()),
                   "terminal_disposition_complete": True,
                   "benchmark_generation_complete": lock.get("all_planned_attempted", False),
                   "all_finals_valid": all(value is not None for value in predictions.values()),
                   "comparison": "Released SlideVQA test adaptation; not exact Ryze Table3 reproduction",
                   "raw_licensed_content_publishable": False})
    if digest(lock_path) != lock_sha256 or digest(args.config) != scorer_config_sha256:
        raise ValueError("Scoring inputs changed during the once-only attempt")
    write_exclusive_json(args.output, result)


if __name__ == "__main__":
    main()
