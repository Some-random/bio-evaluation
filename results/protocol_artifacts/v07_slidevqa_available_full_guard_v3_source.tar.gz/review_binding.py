"""Validate exact independent input review bindings; never access references."""
from pathlib import Path
import hashlib
import json
import re


def canonical_sha256(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def file_sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def expected_case_binding(row, source_sha256):
    return {
        'case_id': row['case_id'],
        'input_source_sha256': source_sha256,
        'input_row_sha256': canonical_sha256(row),
        'question_sha256': hashlib.sha256(row['question'].encode()).hexdigest(),
        'pages_sha256': canonical_sha256(row['pages']),
    }


def validate_review_bindings(rows, reviews, source_sha256, authorized_reviewers, owner, evidence_root):
    """Return verified evidence pins after validating every source-ordered row.

    A final independent coordinator's admission and the earlier input-content
    reviews are distinct. This function verifies bindings; it creates neither.
    """
    if not re.fullmatch(r'[0-9a-f]{64}', source_sha256):
        raise ValueError('Exact source SHA-256 required')
    ids = [r['case_id'] for r in rows]
    review_ids = [r['case_id'] for r in reviews]
    if not ids or len(ids) != len(set(ids)) or review_ids != ids:
        raise ValueError('Unique complete source-order review rows required')
    evidence_root = Path(evidence_root).resolve()
    pins = {}
    for row, review in zip(rows, reviews):
        if any(review.get(key) != value for key, value in expected_case_binding(row, source_sha256).items()):
            raise ValueError('Review source, question or exact page binding differs: ' + row['case_id'])
        if not all(review.get(key) is True for key in
                   ('dispatch_approved', 'question_content_reviewed', 'image_content_reviewed')):
            raise PermissionError('Unknown or held review cannot authorize dispatch')
        if (review.get('global_hold_reconciliation_complete') is not True
                or review.get('question_context_flag_requires_final_coordinator_resolution') is not False):
            raise PermissionError('Global holds and explicit question-context flags must be resolved independently')
        reviewer = review.get('reviewer')
        if reviewer == owner or reviewer not in authorized_reviewers:
            raise PermissionError('Different authorized independent final coordinator required')
        source_reviewers = review.get('source_reviewers')
        if (not isinstance(source_reviewers, list) or not source_reviewers
                or len(set(source_reviewers)) != len(source_reviewers)
                or any(not isinstance(name, str) or not name.startswith('/root/')
                       or name == owner for name in source_reviewers)):
            raise PermissionError('Actual independent source reviewer identities required')
        evidence = review.get('review_evidence')
        if not isinstance(evidence, list) or not evidence:
            raise ValueError('Hash-bound independent review evidence required')
        seen = set()
        for item in evidence:
            if not isinstance(item, dict) or set(item) != {'path', 'sha256'}:
                raise ValueError('Review evidence must be an exact path and hash')
            path = Path(item['path'])
            if not path.is_absolute():
                raise ValueError('Absolute review evidence path required')
            resolved = path.resolve()
            if not resolved.is_relative_to(evidence_root):
                raise ValueError('Review evidence outside input review task')
            if any('scorer_only' == part or 'reference' in part.lower() for part in resolved.relative_to(evidence_root).parts):
                raise ValueError('Reference material cannot be input review evidence')
            if path != resolved or not path.is_file() or any(p.is_symlink() for p in [path, *path.parents]):
                raise ValueError('Regular non-symlink review evidence required')
            key = str(resolved)
            if key in seen:
                raise ValueError('Duplicate evidence in one case review')
            seen.add(key)
            expected = item['sha256']
            if not isinstance(expected, str) or not re.fullmatch(r'[0-9a-f]{64}', expected):
                raise ValueError('Review evidence SHA-256 required')
            if key in pins and pins[key] != expected:
                raise ValueError('Conflicting review evidence hash')
            if key not in pins:
                if file_sha256(path) != expected:
                    raise ValueError('Independent review evidence changed')
                pins[key] = expected
    return pins
