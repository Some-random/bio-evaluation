"""Reference-blind full-deck SlideVQA adapter. No network calls on import."""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path


PROTOCOL_ID = "SLIDEVQA_TEST2215_FULLDECK_ORIGINAL7700_PROCESSED300_QWEN38_ZERO_SHOT_V1"
PROMPT = (
    "Answer the question using the complete 20-page slide deck supplied in page order. "
    "Return a JSON object with exactly two fields: answer (a concise answer string) and "
    "evidence_pages (the unique 1-based page numbers supporting your answer, in ascending order). "
    "Use only the supplied images. Do not include explanations outside the JSON object.\nQuestion: "
)
OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "answer": {"type": "string"},
        "evidence_pages": {
            "type": "array", "minItems": 1, "maxItems": 20,
            "items": {"type": "integer", "minimum": 1, "maximum": 20},
            "uniqueItems": True,
        },
    },
    "required": ["answer", "evidence_pages"],
    "additionalProperties": False,
}


def supported_output_schema():
    """vLLM-supported generation schema; uniqueness stays in parse_final."""
    import copy
    schema=copy.deepcopy(OUTPUT_SCHEMA)
    del schema['properties']['evidence_pages']['uniqueItems']
    return schema


def digest(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line]


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n")


def validate_input(row):
    if set(row) != {"case_id", "question", "deck_name", "pages"}:
        raise ValueError("Input field allowlist violated")
    if not isinstance(row["question"], str) or not row["question"].strip():
        raise ValueError("Missing question")
    if len(row["pages"]) != 20:
        raise ValueError("Every case requires all 20 pages")
    for i, page in enumerate(row["pages"], 1):
        if set(page) != {"page_number", "image_path", "sha256", "source_variant"}:
            raise ValueError("Page field allowlist violated")
        if page["page_number"] != i:
            raise ValueError("Image order differs from original page order")
    return row


def build_messages(row, *, data_urls=False):
    validate_input(row)
    content = []
    for page in row["pages"]:
        p = Path(page["image_path"])
        if not p.is_file() or digest(p) != page["sha256"]:
            raise ValueError("Missing or changed input image")
        content.append({"type": "text", "text": f"Page {page['page_number']}"})
        if data_urls:
            mime = "image/png" if p.suffix.lower() == ".png" else "image/jpeg"
            url = "data:" + mime + ";base64," + base64.b64encode(p.read_bytes()).decode("ascii")
            content.append({"type": "image_url", "image_url": {"url": url}})
        else:
            content.append({"type": "image", "image": str(p)})
    content.append({"type": "text", "text": PROMPT + row["question"]})
    return [{"role": "user", "content": content}]


def parse_final(text):
    def unique_object(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("Duplicate output object key")
            value[key] = item
        return value
    value = json.loads(text, object_pairs_hook=unique_object)
    if not isinstance(value, dict) or set(value) != {"answer", "evidence_pages"}:
        raise ValueError("Expected exact answer/evidence_pages object")
    if not isinstance(value["answer"], str) or not value["answer"].strip():
        raise ValueError("Empty answer")
    pages = value["evidence_pages"]
    if not isinstance(pages, list) or not 1 <= len(pages) <= 20:
        raise ValueError("Invalid evidence page count")
    if any(type(i) is not int or not 1 <= i <= 20 for i in pages):
        raise ValueError("Evidence page out of bounds")
    if pages != sorted(set(pages)):
        raise ValueError("Evidence pages must be unique and ascending")
    return value


def native_metric_functions(source_path, expected_sha256):
    """Load unchanged published pure metric bodies; skip its broken __main__."""
    import ast
    import re
    import string
    from collections import Counter
    if digest(source_path) != expected_sha256:
        raise ValueError("Native scorer source changed")
    tree = ast.parse(Path(source_path).read_text())
    names = {"normalize_answer", "evaluate_f1_em_qa", "evaluate_f1_em_es", "evaluate_f1_em_main"}
    nodes = [n for n in tree.body if (
        isinstance(n, ast.FunctionDef) and n.name in names
    ) or (
        isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "WORD_NUMBER_MAP" for t in n.targets)
    )]
    if sum(isinstance(n, ast.FunctionDef) for n in nodes) != len(names):
        raise ValueError("Native functions missing")
    namespace = {"re": re, "string": string, "Counter": Counter}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source_path), "exec"), namespace)
    return namespace
