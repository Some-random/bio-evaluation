"""Invented refusal strings; no source questions, answers or model requests."""
import copy,json,unittest
import run
import test_runtime_guards as guards

class RefusalText(unittest.TestCase):
    def test_refusal_variants_stop(self):
        for text in ["Sorry, I can't provide that information.","I'm unable to help with that request.",
                     "I can’t assist with that request.","I am not able to comply with that request.",
                     "Unfortunately, I cannot provide instructions for that.",
                     "As an AI assistant, I can't assist with this request.",
                     "I'm sorry, but I cannot comply with this request."]:
            for content in (text,json.dumps({'answer':text,'evidence_pages':[1]})):
                with self.subTest(content=content):self.assertTrue(run.is_explicit_refusal({'content':content}))
    def test_attributed_quotes_and_missing_data_are_not_refusals(self):
        for text in ['The slide quotes “I can’t assist with that request.”',
                     'Quoted text: Sorry, I cannot provide that information.',
                     '"I cannot assist with that request."',
                     'I cannot determine the value from the supplied slides.',
                     "I can't calculate the total using the numbers shown.",
                     'The total was 17 fictional units.']:
            for content in (text,json.dumps({'answer':text,'evidence_pages':[2]})):
                with self.subTest(content=content):self.assertFalse(run.is_explicit_refusal({'content':content}))
    def test_explicit_provider_refusal_field_overrides_plain_text(self):
        self.assertTrue(run.is_explicit_refusal({'refusal':'Synthetic refusal field','content':'The chart shows 17.'}))

class RefusalRuntime(unittest.TestCase):
    setUp=guards.PredictionSeal.setUp
    tearDown=guards.PredictionSeal.tearDown
    seal=guards.PredictionSeal.seal
    save_lock=guards.PredictionSeal.save_lock
    prepare_runtime=guards.RuntimeStopAndSeal.prepare_runtime
    invoke=guards.RuntimeStopAndSeal.invoke
    check_seal=guards.RuntimeStopAndSeal.check_seal
    def test_curly_refusal_in_valid_json_stops_next_case(self):
        self.prepare_runtime();body=copy.deepcopy(self.body)
        body['choices'][0]['message']['content']=json.dumps({'answer':'I can’t assist with that request.','evidence_pages':[1]})
        self.opener.open.return_value.__enter__.return_value.read.return_value=json.dumps(body).encode()
        self.invoke();result=self.check_seal(attempted=1,passed=0,not_dispatched=1)
        self.assertEqual(1,result['refusals']);self.assertEqual(1,self.opener.open.call_count)
    def test_non_json_refusal_stops_next_case(self):
        self.prepare_runtime();body=copy.deepcopy(self.body)
        body['choices'][0]['message']['content']="Sorry, I can't provide that information."
        self.opener.open.return_value.__enter__.return_value.read.return_value=json.dumps(body).encode()
        self.invoke();self.check_seal(attempted=1,passed=0,not_dispatched=1)
        self.assertEqual(1,self.opener.open.call_count)
    def test_valid_quote_answer_remains_a_normal_model_answer(self):
        self.prepare_runtime();body=copy.deepcopy(self.body)
        body['choices'][0]['message']['content']=json.dumps({'answer':'The slide quotes “I can’t assist with that request.”','evidence_pages':[1]})
        self.opener.open.return_value.__enter__.return_value.read.return_value=json.dumps(body).encode()
        self.invoke();self.check_seal(attempted=2,passed=2,not_dispatched=0)
        self.assertEqual(2,self.opener.open.call_count)

if __name__=='__main__':unittest.main()
