"""One independently admitted own local vision replica, delivery, generation, score."""
from pathlib import Path
import argparse, fcntl, importlib.metadata, json, os, re, shutil, signal, socket
import subprocess, sys, tarfile, tempfile, time, urllib.error, urllib.request
from admission import HERE,TASK,ROOT,sha,load,validate,gpu_audit

PACKAGES={'vllm':'0.31.0','torch':'2.13.0','transformers':'5.17.0','triton':'3.7.1','flashinfer-python':'0.7.0.post1'}
def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n');temp.replace(path)
def stamp():
    from datetime import datetime
    from zoneinfo import ZoneInfo
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def environment(common,local):
    env=common.environment(local)
    for name in list(env):
        if re.search(r'API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL',name,re.I) or name in {'SSH_AUTH_SOCK','NETRC','KUBECONFIG','PYTHONHOME','PYTHONPATH','VIRTUAL_ENV','OPENAI_BASE_URL','GOOGLE_APPLICATION_CREDENTIALS'}:
            env.pop(name,None)
    env.update(PYTHONPATH=str(HERE),PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',VLLM_USE_V2_MODEL_RUNNER='0',
        HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1')
    return env
def stop_server(server):
    if server is not None and server.poll()is None:
        os.killpg(server.pid,signal.SIGTERM)
        try:server.wait(timeout=45)
        except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait(timeout=10)
def grant(plan,args,phase,identity,development=None):
    spec=plan['phases'][phase];config=Path(spec['config']);settings=json.loads(config.read_bytes())
    value={'authorized':True,'task_id':'V07','run_id':settings['run_id'],'config_sha256':sha(config),
        'runner_sha256':sha(HERE/'run.py'),'adapter_sha256':sha(HERE/'slidevqa_adapter.py'),
        'endpoint':plan['endpoint'],'server_identity_file':str(identity),'server_identity_sha256':sha(identity),
        'processor_preflight_sha256':sha(spec['processor_preflight']),'output_root':spec['output'],
        'independent_admission_file':str(args.admission),'independent_admission_sha256':args.admission_sha256,
        'plan_file':str(args.plan.resolve()),'plan_sha256':args.plan_sha256,
        'role':'runtime_derivation_of_exact_independent_plan_not_owner_admission'}
    if development:value['development_completion_sha256']=sha(development)
    target=Path(plan['runtime_root'])/f'{phase}_runtime_grant.json';write(target,value);return target
def phase(plan,args,mode,identity,python,env,development=None):
    spec=plan['phases'][mode]
    command=[str(python),str(HERE/'run.py'),'--config',spec['config'],'--output',spec['output'],
        '--grant',str(grant(plan,args,mode,identity,development)),'--processor-preflight',spec['processor_preflight']]
    if development:command.extend(['--development-completion',str(development)])
    with (Path(plan['runtime_root'])/f'{mode}.log').open('x')as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env,check=True)
    result=Path(spec['output'])/'completion.json'
    if mode=='development' and json.loads(result.read_text()).get('all_passed')is not True:
        raise ValueError('Full neutral20-image actual delivery gate failed; no benchmark dispatch')
    return result
def main():
    parser=argparse.ArgumentParser()
    for name in ('plan','admission'):parser.add_argument('--'+name,type=Path,required=True)
    for name in ('plan-sha256','admission-sha256'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--local',type=Path);args=parser.parse_args()
    plan=validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256,require_job=True)
    runtime=Path(plan['runtime_root']);runtime.mkdir(exist_ok=True)
    common=load('v07_pinned_runtime_common',plan['runtime_common'])
    if args.local is None:
        lock=(runtime/'allocation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        with (runtime/'allocation_started.json').open('x')as claim:
            json.dump({'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'plan_sha256':args.plan_sha256,
                'admission_sha256':args.admission_sha256,'no_automatic_retries':True},claim)
        write(runtime/'private_GPU_audit_at_start.json',gpu_audit(plan))
        if shutil.disk_usage('/tmp').free<48*1024**3:raise ValueError('48GiB private local scratch required')
        for key in ('base_runtime','cuda_overlay'):
            if sha(plan[key]['path'])!=plan[key]['sha256']:raise ValueError('Frozen runtime archive changed')
        local=Path(tempfile.mkdtemp(prefix='bio-v07-'+os.environ['SLURM_JOB_ID']+'-'))
        with tarfile.open(plan['base_runtime']['path'])as archive:archive.extractall(local,filter='data')
        extracted=common.apply_overlay(local)
        if extracted!={'base':plan['base_runtime']['sha256'],'overlay':plan['cuda_overlay']['sha256']}:
            raise ValueError('Applied portable runtime differs from independent plan')
        write(runtime/'runtime_extraction.json',{'at_pacific':stamp(),'local':str(local),
            'job_id':os.environ['SLURM_JOB_ID'],'plan_sha256':args.plan_sha256,**extracted})
        python=local/'python/bin/python3.12';env=environment(common,local)
        os.execve(str(python),[str(python),str(Path(__file__).resolve()),*sys.argv[1:],'--local',str(local)],env)
    local=args.local.resolve()
    if not local.name.startswith('bio-v07-'+os.environ['SLURM_JOB_ID']+'-'):raise ValueError('Private runtime ownership differs')
    extraction=json.loads((runtime/'runtime_extraction.json').read_text())
    if (str(local)!=extraction['local']or extraction.get('job_id')!=os.environ['SLURM_JOB_ID']
            or extraction.get('plan_sha256')!=args.plan_sha256
            or extraction.get('base')!=plan['base_runtime']['sha256']
            or extraction.get('overlay')!=plan['cuda_overlay']['sha256']):
        raise ValueError('Private runtime is not this allocation verified extraction')
    lock=(runtime/'protocol.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    env=environment(common,local);python=local/'python/bin/python3.12'
    observed={n:importlib.metadata.version(n)for n in PACKAGES}
    import torch
    if any(observed[n].split('+')[0]!=v for n,v in PACKAGES.items())or torch.cuda.device_count()!=1:
        raise ValueError('Exact frozen packages and one visible GPU required')
    write(runtime/'execution_environment.json',{'packages':observed,'torch_build':torch.__version__,
        'visible_GPUs':torch.cuda.device_count(),'GPU_name':torch.cuda.get_device_name(0),'python':sys.version})
    model=common.validate_checkpoint(plan['model']['name'],plan['model']['revision'])
    # Validate the actual installed API accepts the frozen multimodal schema.
    from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest
    from vllm.sampling_params import SamplingParams,StructuredOutputsParams
    from vllm.config.structured_outputs import StructuredOutputsConfig
    from transformers import AutoTokenizer
    from types import SimpleNamespace
    tokenizer=AutoTokenizer.from_pretrained(model,local_files_only=True)
    phases=('development',)if plan['execution_scope']=='neutral_delivery_only'else('development','benchmark')
    for phase_name in phases:
        settings=json.loads(Path(plan['phases'][phase_name]['config']).read_bytes())
        probe=ChatCompletionRequest.model_validate({'model':settings['model'],'messages':[{'role':'user','content':'Synthetic API schema check'}],**settings['generation']})
        if probe.max_tokens!=16384:raise ValueError('Installed HTTP API changes output budget')
        sampling=SamplingParams(max_tokens=16384,structured_outputs=StructuredOutputsParams(**settings['generation']['structured_outputs']))
        sampling._validate_structured_outputs(SimpleNamespace(is_diffusion=False),
            StructuredOutputsConfig(backend=plan['structured_output_backend']),tokenizer)
    server=None
    try:
        write(runtime/'private_GPU_audit_before_server.json',gpu_audit(plan))
        port=plan['port']
        if plan['endpoint']!=f'http://127.0.0.1:{port}/v1':raise ValueError('Own loopback endpoint required')
        with socket.socket()as probe:probe.bind(('127.0.0.1',port))
        command=[str(python),'-m','vllm.entrypoints.cli.main','serve',str(model),'--served-model-name',plan['model']['name'],
            '--host','127.0.0.1','--port',str(port),'--dtype','bfloat16','--tensor-parallel-size','1',
            '--gpu-memory-utilization','0.95','--max-model-len','65536','--max-num-seqs','1',
            '--max-num-batched-tokens','8192','--reasoning-parser','qwen3','--enable-prefix-caching',
            '--structured-outputs-config',json.dumps({'backend':plan['structured_output_backend']}),
            '--limit-mm-per-prompt','{"image":20,"video":0}']
        write(runtime/'status.json',{'at_pacific':stamp(),'stage':'starting_own20_image_Qwen','job_id':os.environ['SLURM_JOB_ID']})
        with (runtime/'server.log').open('x')as log:
            server=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env,cwd=local,start_new_session=True)
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));deadline=time.monotonic()+1800
        while time.monotonic()<deadline:
            if server.poll()is not None:raise RuntimeError('Own20-image Qwen server failed before readiness')
            try:
                with opener.open(plan['endpoint'].removesuffix('/v1')+'/health',timeout=3)as response:
                    if response.status==200:break
            except (OSError,urllib.error.URLError):time.sleep(3)
        else:raise TimeoutError('Own server readiness timeout')
        with opener.open(plan['endpoint']+'/models',timeout=5)as response:models=json.load(response)
        if [r['id']for r in models['data']]!=[plan['model']['name']]:raise ValueError('Actual served-model identity differs')
        processes=common.own_gpu_processes(server.pid)
        if len({r['gpu_uuid']for r in processes})!=1:raise ValueError('Exactly one own physical GPU required')
        identity=runtime/'server_identity.json'
        write(identity,{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'hostname':socket.gethostname(),'pid':server.pid,
            'proc_start_ticks':common.start_ticks(server.pid),'model':plan['model']['name'],'model_revision':plan['model']['revision'],
            'dtype':'bfloat16','context_limit':65536,'limit_mm_per_prompt':{'image':20,'video':0},'endpoint':plan['endpoint'],
            'command':command,'own_GPU_processes':processes,'plan_sha256':args.plan_sha256,'packages':observed})
        development=phase(plan,args,'development',identity,python,env)
        sys.path.insert(0,str(HERE))
        from slidevqa_adapter import parse_final
        visual_checks=[]
        for case_id,expected in plan['neutral_visual_assertions'].items():
            outcome=json.loads((Path(plan['phases']['development']['output'])/'outcomes'/(case_id+'.json')).read_text())
            final=parse_final(outcome['final'])
            passed=expected['answer_color']in final['answer'].casefold() and final['evidence_pages']==expected['evidence_pages']
            visual_checks.append({'case_id':case_id,'passed':passed,'expected_color':expected['answer_color'],
                'expected_page':expected['evidence_pages'],'prediction_sha256':sha(Path(plan['phases']['development']['output'])/'outcomes'/(case_id+'.json'))})
        write(runtime/'neutral_visual_delivery_assertions.json',{'all_passed':all(x['passed']for x in visual_checks),
            'checks':visual_checks,'benchmark_or_biological_correctness_assessed':False})
        if not all(x['passed']for x in visual_checks):
            raise ValueError('Neutral first/last image color/page delivery assertion failed; no benchmark dispatch')
        if plan['execution_scope']=='neutral_delivery_only':
            stop_server(server);server=None
            write(runtime/'status.json',{'at_pacific':stamp(),'stage':'neutral20_image_maxgrid_actual_model_delivery_passed',
                'development_completion':str(development),'development_completion_sha256':sha(development),
                'real_benchmark_calls':0,'benchmark_dispatch_authorized':False,'native_scores_produced':False})
            return
        write(runtime/'private_GPU_audit_before_benchmark.json',gpu_audit(plan))
        validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256,require_job=True)
        write(runtime/'status.json',{'at_pacific':stamp(),'stage':'V07_once_each_full_deck_generation_live','job_id':os.environ['SLURM_JOB_ID']})
        completion=phase(plan,args,'benchmark',identity,python,env,development)
        stop_server(server);server=None
        write(runtime/'own_server_stopped_before_scoring.json',{'at_pacific':stamp(),'own_server_stopped':True})
        output=Path(plan['phases']['benchmark']['output'])
        with (runtime/'scoring.log').open('x')as log:
            subprocess.run([str(python),str(HERE/'score.py'),'--config',plan['scorer_config'],'--run',str(output),
                '--output',str(output/'scores.json')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
        write(runtime/'status.json',{'at_pacific':stamp(),'stage':'V07_terminal_native_available_condition_scored',
            'scores':str(output/'scores.json'),'scores_sha256':sha(output/'scores.json'),
            'exact_Ryze_Table3_reproduction':False,'generation_completion_sha256':sha(completion),
            'generation_counts':json.loads(completion.read_text()),
            'benchmark_generation_complete':json.loads((output/'scores.json').read_text())['benchmark_generation_complete']})
    except Exception as error:
        write(runtime/'status.json',{'at_pacific':stamp(),'stage':'stopped_for_review','error_type':type(error).__name__,
            'error':str(error),'no_automatic_retry':True,'no_rerouting':True})
        raise
    finally:stop_server(server)
if __name__=='__main__':main()
