#!/usr/bin/env python3
"""One-attempt, full-deck local solver; needs a separate root-frozen grant."""
import argparse
import http.client
import json
import os
import re
import urllib.error
import urllib.request
from collections import Counter
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

from slidevqa_adapter import build_messages, digest, parse_final, read_jsonl, validate_input, write_json
from review_binding import validate_review_bindings


def now():
    return datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()


class InvalidFinal(ValueError):
    """A preserved model completion; never retried and never changes denominator."""


def is_explicit_refusal(message):
    """Recognize an assistant refusal, not a quoted phrase or missing-data answer."""
    if message.get('refusal'):
        return True
    text=message.get('content')
    if not isinstance(text,str):
        return False
    try:
        obj=json.loads(text)
    except (ValueError,TypeError):
        obj=None
    if isinstance(obj,dict):
        if not isinstance(obj.get('answer'),str):
            return False
        text=obj['answer']
    import unicodedata
    text=unicodedata.normalize('NFKC',text).replace('\u2019',"'").replace('\u2018',"'").strip()
    # Anchoring avoids classifying an attributed quotation as the assistant's
    # own refusal. Missing-data verbs such as determine/read/calculate are not
    # refusal triggers and remain ordinary native-scored model answers.
    prefix=r"(?:(?:unfortunately|sorry)[,!:;.]?\s*|i(?:'m| am)\s+(?:sorry|afraid)[,!:;.]?\s*)*"
    persona=r"(?:as an? (?:ai|language model|assistant)[^,;.!?\n]{0,60}[,;]\s*)?"
    transition=r"(?:(?:but|however)[,;]?\s*)?"
    denial=r"(?:i\s+(?:cannot|can't|will not|won't)|i(?:'m| am)\s+(?:unable|not able)\s+to)\s+"
    action=r"(?:assist\b|help\b|comply\b|provide\s+(?:(?:that|this|the|any)\s+)?(?:information|instructions|assistance|details)\b)"
    return bool(re.match(prefix+persona+transition+denial+action,text,re.I))


def validate_config(path):
    config = json.loads(path.read_text())
    if config["task_id"] != "V07" or config["phase"] not in ("benchmark_generation", "development"):
        raise ValueError("Wrong task/phase")
    if not re.fullmatch(r'[A-Za-z0-9_.-]+', config['run_id']):
        raise ValueError('Unsafe run identity')
    if set(config['generation']) != {'temperature','top_p','top_k','seed','n','max_tokens','chat_template_kwargs','structured_outputs'}:
        raise ValueError('Frozen generation field allowlist violated')
    for key in ("model_inputs", "case_review"):
        if digest(config[key]["path"]) != config[key]["sha256"]:
            raise ValueError("Frozen task file changed: " + key)
    rows = read_jsonl(config["model_inputs"]["path"])
    if len(rows) != config["planned"] or len({r["case_id"] for r in rows}) != len(rows):
        raise ValueError("Wrong or duplicate cohort")
    for row in rows:
        validate_input(row)
        if not re.fullmatch(r'[A-Za-z0-9_.-]+', row['case_id']):
            raise ValueError('Unsafe case identity')
    return config, rows


def parse_response(body, config, expected_prompt_tokens):
    if not isinstance(body, dict) or body.get('model') != config['model']:
        raise ValueError('Response model/envelope differs')
    choices = body.get('choices')
    if not isinstance(choices, list) or len(choices) != 1 or not isinstance(choices[0], dict):
        raise ValueError('Exactly one response choice required')
    choice = choices[0]
    if choice.get('index') != 0:
        raise ValueError('Wrong choice index')
    message = choice.get('message')
    if not isinstance(message, dict) or message.get('role') != 'assistant':
        raise ValueError('Malformed assistant message')
    if is_explicit_refusal(message):
        raise ValueError('Explicit refusal, stop without retry')
    final = message.get('content')
    if not isinstance(final, str) and not (final is None and choice.get('finish_reason') == 'length'):
        raise ValueError('No final content')
    usage = body.get('usage')
    if not isinstance(usage, dict) or any(type(usage.get(k)) is not int or usage[k] < 0 for k in ('prompt_tokens','completion_tokens','total_tokens')):
        raise ValueError('Exact actual token usage required')
    if usage['prompt_tokens'] != expected_prompt_tokens or usage['prompt_tokens'] < 1:
        raise ValueError('Actual expanded prompt tokens differ from pinned CPU processor')
    if usage['total_tokens'] != usage['prompt_tokens'] + usage['completion_tokens']:
        raise ValueError('Token usage is inconsistent')
    if usage['completion_tokens'] > config['generation']['max_tokens'] or usage['prompt_tokens'] + config['generation']['max_tokens'] > config['required_server']['context_limit']:
        raise ValueError('Actual context/output budget differs')
    return choice, message, final, usage


def validate_gates(config, config_path, rows, grant_path, preflight_path, development_path):
    grant = json.loads(grant_path.read_text())
    expected = {"authorized": True, "task_id": "V07", "run_id": config["run_id"], "config_sha256": digest(config_path)}
    if any(grant.get(k) != v for k, v in expected.items()):
        raise ValueError("No exact root grant")
    if digest(grant['independent_admission_file']) != grant['independent_admission_sha256']:
        raise ValueError('Independent admission changed')
    admission = json.loads(Path(grant['independent_admission_file']).read_text())
    policy_path = Path(__file__).parents[3] / 'dedicated_execution_20261021/delegated_engineering_review_resume_v2.json'
    policy = json.loads(policy_path.read_text())
    reviewer = admission.get('reviewer')
    if not admission.get('admitted') or reviewer == '/root/v07_execution' or reviewer not in policy['authorized_reviewers'] + ['root','/root']:
        raise ValueError('Different independent admitted peer required')
    if admission.get('delegation_sha256') != digest(policy_path) or admission.get('plan_sha256') != grant.get('plan_sha256'):
        raise ValueError('Independent plan/delegation differs')
    if digest(grant['plan_file'])!=grant['plan_sha256']:
        raise ValueError('Admitted plan bytes changed')
    plan=json.loads(Path(grant['plan_file']).read_text())
    phase='development'if config['phase']=='development'else'benchmark'
    spec=plan.get('phases',{}).get(phase)
    if not spec or admission.get('authorized_scope')!=plan.get('execution_scope'):
        raise ValueError('Admitted plan does not authorize this phase')
    if (Path(spec['config']).resolve()!=config_path.resolve()
            or plan['frozen_files_sha256'].get(str(config_path.resolve()))!=digest(config_path)
            or Path(spec['processor_preflight']).resolve()!=preflight_path.resolve()
            or plan['frozen_files_sha256'].get(str(preflight_path.resolve()))!=digest(preflight_path)
            or Path(spec['output']).resolve()!=Path(grant['output_root']).resolve()
            or grant['endpoint']!=plan['endpoint']):
        raise ValueError('Grant configuration, processor, output or endpoint is outside admitted phase')
    if plan['frozen_files_sha256'].get(str(Path(__file__).resolve()))!=digest(__file__):
        raise ValueError('Actual runner is outside admitted implementation')
    if grant.get("runner_sha256") != digest(__file__) or grant.get("adapter_sha256") != digest(Path(__file__).with_name("slidevqa_adapter.py")):
        raise ValueError("Frozen execution code changed")
    if digest(grant["server_identity_file"]) != grant["server_identity_sha256"]:
        raise ValueError("Server identity changed")
    identity = json.loads(Path(grant["server_identity_file"]).read_text())
    if identity.get("model_revision") != config["model_revision"] or identity.get("dtype") not in ("bfloat16", "torch.bfloat16"):
        raise ValueError("Wrong checkpoint or precision")
    if identity.get("limit_mm_per_prompt", {}).get("image", 0) < 20 or identity.get("context_limit", 0) < config["required_server"]["context_limit"]:
        raise ValueError("Server cannot accept full native deck/context")
    endpoint = grant["endpoint"].rstrip("/")
    if urlparse(endpoint).hostname not in ("127.0.0.1", "localhost", "::1"):
        raise ValueError("Only the authorized loopback local server is supported")
    if identity.get('endpoint') != endpoint or identity.get('job_id') != os.environ.get('SLURM_JOB_ID'):
        raise ValueError('Server is not the own allocated endpoint')
    if identity.get('plan_sha256')!=grant['plan_sha256']:
        raise ValueError('Server belongs to a different admitted plan')
    live = Path('/proc') / str(identity['pid']) / 'stat'
    if live.read_text().rsplit(') ',1)[1].split()[19] != identity['proc_start_ticks']:
        raise ValueError('Server process identity changed')
    reviews = read_jsonl(config["case_review"]["path"])
    if {r["case_id"] for r in reviews} != {r["case_id"] for r in rows}:
        raise ValueError("Review IDs mismatch")
    for r in reviews:
        if not all(r.get(k) is True for k in ("dispatch_approved", "question_content_reviewed", "image_content_reviewed")):
            raise ValueError("Independent full input content review remains unfinished")
        if config['phase'] != 'development' and (not r.get('reviewer') or r['reviewer'] == '/root/v07_execution'):
            raise ValueError('Independent review provenance required')
    if config['phase'] != 'development':
        review_pins=validate_review_bindings(rows,reviews,config['model_inputs']['sha256'],
            policy['authorized_reviewers']+['root','/root'],'/root/v07_execution',Path(__file__).parent.parent)
        if review_pins != plan.get('source_review_evidence_sha256'):
            raise ValueError('Final reviewed evidence differs from independent plan')
        if any(plan['frozen_files_sha256'].get(path)!=value for path,value in review_pins.items()):
            raise ValueError('Final reviewed evidence missing from frozen source inventory')
    if digest(preflight_path) != grant["processor_preflight_sha256"]:
        raise ValueError("Processor gate hash mismatch")
    preflight = json.loads(preflight_path.read_text())
    if not preflight.get("all_fit") or not preflight.get("all20_images_expanded") or preflight.get("config_sha256") != digest(config_path) or preflight.get("cases") != len(rows):
        raise ValueError("Actual expanded context gate not passed for complete cohort")
    case_observations = preflight_path.parent / "cases.jsonl"
    if digest(case_observations) != preflight["case_observations_sha256"]:
        raise ValueError("Processor observations changed")
    for filename, expected_hash in preflight["processor_files_sha256"].items():
        if digest(Path(config["model_path"]) / filename) != expected_hash:
            raise ValueError("Pinned processor files changed")
    if config["phase"] == "development":
        if config.get("synthetic_only") is not True or any(r.get("synthetic_only") is not True for r in reviews):
            raise ValueError("Only separately frozen synthetic delivery development is supported by this launcher")
        return endpoint, identity
    if digest(development_path) != grant["development_completion_sha256"]:
        raise ValueError("Development receipt changed")
    dev = json.loads(development_path.read_text())
    if not dev.get("all_passed") or dev.get("protocol_id") != config["protocol_id"] or dev.get("biological_correctness_assessed") is not False:
        raise ValueError("Separate unscored multimodal delivery gate not passed")
    if not isinstance(dev.get("planned"), int) or dev["planned"] < 1 or dev.get("delivery_passed") != dev["planned"]:
        raise ValueError("Development gate did not deliver its full frozen plan")
    if any(dev.get(k) != 0 for k in ("transport_errors", "http_errors", "response_errors", "truncations", "empty_finals", "refusals")):
        raise ValueError("Development gate contains failures")
    if dev.get("generation") != config["generation"] or dev.get("model_revision") != config["model_revision"] or dev.get("images_per_case") != 20:
        raise ValueError("Development condition differs from frozen benchmark")
    dev_lock = json.loads(Path(dev["prediction_lock_path"]).read_text())
    if digest(dev["prediction_lock_path"]) != dev["prediction_lock_sha256"]:
        raise ValueError("Development lock changed")
    for file in dev_lock["files"]:
        if digest(Path(dev["prediction_lock_path"]).parent / file["path"]) != file["sha256"]:
            raise ValueError("Development evidence changed")
    return endpoint, identity


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--output", type=Path)
    p.add_argument("--grant", type=Path)
    p.add_argument("--processor-preflight", type=Path)
    p.add_argument("--development-completion", type=Path)
    p.add_argument("--check-only", action="store_true")
    args = p.parse_args()
    config, rows = validate_config(args.config)
    if args.check_only:
        print(json.dumps({"planned": len(rows), "input_contract_valid": True,
            "review_approved": sum(r.get("dispatch_approved") is True for r in read_jsonl(config["case_review"]["path"])),
            "is_dispatch_evidence": False, "new_inference_calls": 0}))
        return
    if not all((args.output, args.grant, args.processor_preflight)) or (config["phase"] != "development" and not args.development_completion):
        raise ValueError("Exact grant, context and delivery receipts required")
    endpoint, identity = validate_gates(config, args.config, rows, args.grant, args.processor_preflight, args.development_completion)
    grant = json.loads(args.grant.read_text())
    if args.output.resolve() != Path(grant['output_root']).resolve():
        raise ValueError('Grant is bound to one canonical output directory')
    claim_dir = Path(__file__).parent / 'attempt_claims'
    claim_dir.mkdir(exist_ok=True)
    claim_path = claim_dir / (config['run_id'] + '.json')
    with claim_path.open('x') as claim:
        json.dump({'started_at_pacific':now(),'output':str(args.output.resolve()),'config_sha256':digest(args.config),
            'grant_sha256':digest(args.grant),'once_only_run':True},claim)
    args.output.mkdir(parents=True, exist_ok=False)
    for sub in ("requests", "responses", "outcomes", "errors", "delivery"):
        (args.output / sub).mkdir()
    observations = read_jsonl(args.processor_preflight.parent / 'cases.jsonl')
    observed = {r['case_id']:r for r in observations}
    if len(observed) != len(rows) or set(observed) != {r['case_id'] for r in rows}:
        raise ValueError('Processor observation IDs do not match complete input cohort')
    for row in rows:
        import hashlib
        if observed[row['case_id']]['input_row_sha256'] != hashlib.sha256(json.dumps(row,ensure_ascii=False,sort_keys=True).encode()).hexdigest():
            raise ValueError('Expanded processor observation belongs to different input row')
    write_json(args.output / "run_manifest.json", {
        "started_at_pacific": now(), "task_id": "V07", "run_id": config["run_id"],
        "phase": config["phase"], "protocol_id": config["protocol_id"], "planned": len(rows), "config_sha256": digest(args.config),
        "input_sha256": config["model_inputs"]["sha256"], "generation": config["generation"],
        "runner_sha256":digest(__file__),"adapter_sha256":digest(Path(__file__).with_name('slidevqa_adapter.py')),
        "grant_sha256": digest(args.grant), "server_identity": identity, "reference_files_read": False,
        "processor_preflight_sha256":digest(args.processor_preflight),"attempt_claim_sha256":digest(claim_path)})
    counts = Counter({k: 0 for k in ("attempted_confirmed", "responses_saved", "delivery_passed", "transport_errors", "http_errors", "response_errors", "invalid_model_finals", "truncations", "empty_finals", "refusals", "input_errors", "not_dispatched")})
    outcomes = []
    stopped = False
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    for row in rows:
        case_id = row["case_id"]
        outcome = {"case_id": case_id, "delivery_passed": False, "attempted": False,
            "final": None, "finish_reason": None, "response_body_complete": None}
        if stopped:
            outcome["status"] = "not_dispatched_after_first_failure"
            counts["not_dispatched"] += 1
        else:
            try:
                request = {"model": config["model"], "messages": build_messages(row, data_urls=True), **config["generation"]}
                write_json(args.output / "requests" / (case_id + ".json"), request)
                outcome["attempted"] = True
                counts["attempted_confirmed"] += 1
                http_request = urllib.request.Request(endpoint + "/chat/completions", data=json.dumps(request).encode(), headers={"Content-Type": "application/json"})
                with opener.open(http_request, timeout=3600) as response:
                    raw = response.read(16*1024*1024+1)
                (args.output / "responses" / (case_id + ".json")).write_bytes(raw)
                outcome['response_body_complete']=len(raw)<=16*1024*1024
                counts["responses_saved"] += 1
                if len(raw)>16*1024*1024:
                    raise ValueError('Frozen response byte guard exceeded')
                body = json.loads(raw)
                if isinstance(body,dict) and isinstance(body.get('choices'),list) and body['choices'] and isinstance(body['choices'][0],dict):
                    c = body['choices'][0];m = c.get('message')
                    outcome['finish_reason'] = c.get('finish_reason')
                    if c.get('finish_reason') == 'length':counts['truncations'] += 1
                    if isinstance(m,dict):
                        outcome['final'] = m.get('content')
                        if is_explicit_refusal(m):counts['refusals'] += 1
                        if not isinstance(m.get('content'),str) or not m.get('content','').strip():counts['empty_finals'] += 1
                choice, message, final, usage = parse_response(body,config,observed[case_id]['input_tokens'])
                outcome.update({"final": final, "finish_reason": choice.get("finish_reason"),"usage":usage})
                if choice.get('finish_reason') == 'length':
                    raise InvalidFinal('Preserved truncated model final; continue next untouched case')
                if choice.get("finish_reason") != "stop":
                    raise ValueError("Non-normal finish")
                try:parse_final(final)
                except (ValueError,TypeError)as exc:
                    raise InvalidFinal('Preserved invalid final answer/evidence format')from exc
                write_json(args.output/'delivery'/(case_id+'.json'),{'case_id':case_id,'image_count':20,
                    'expected_prompt_tokens':observed[case_id]['input_tokens'],'actual_usage':usage,
                    'request_sha256':digest(args.output/'requests'/(case_id+'.json')),
                    'response_sha256':digest(args.output/'responses'/(case_id+'.json')),
                    'actual_expanded_token_accounting_passed':True,'vision_attention_claim':False})
                outcome.update({"delivery_passed": True, "status": "delivered"})
                counts["delivery_passed"] += 1
            except InvalidFinal as exc:
                counts['invalid_model_finals'] += 1
                outcome['status']='invalid_model_final'
                write_json(args.output/'errors'/(case_id+'.json'),{'type':type(exc).__name__,'message':str(exc),
                    'next_untouched_case_may_continue':True,'this_case_retried':False})
            except urllib.error.HTTPError as exc:
                counts["http_errors"] += 1
                raw=b'';complete=True;read_error=None
                try:
                    raw=exc.read(16*1024*1024+1)
                    complete=len(raw)<=16*1024*1024
                except Exception as secondary:
                    partial=getattr(secondary,'partial',b'')
                    raw=bytes(partial)if isinstance(partial,(bytes,bytearray))else b''
                    complete=False
                    read_error={'type':type(secondary).__name__,'message':str(secondary)}
                (args.output / "errors" / (case_id + ".http")).write_bytes(raw)
                outcome['response_body_complete']=complete
                write_json(args.output/'errors'/(case_id+'.json'),{'type':type(exc).__name__,'status':exc.code,
                    'reason':str(exc.reason),'body_complete':complete,'captured_body_bytes':len(raw),'body_read_error':read_error})
                outcome["status"] = "http_error";stopped = True
            except (urllib.error.URLError, TimeoutError, OSError, http.client.HTTPException) as exc:
                counts["transport_errors" if outcome['attempted'] else 'input_errors'] += 1
                outcome["status"] = "transport_error" if outcome['attempted'] else 'input_error'
                partial=getattr(exc,'partial',None)
                captured=bytes(partial)if isinstance(partial,(bytes,bytearray))else None
                if captured is not None:
                    (args.output/'errors'/(case_id+'.partial_response.bin')).write_bytes(captured)
                if outcome['attempted']:outcome['response_body_complete']=False
                write_json(args.output / "errors" / (case_id + ".json"), {"type": type(exc).__name__, "message": str(exc),
                    'body_complete':False if outcome['attempted']else None,'captured_partial_bytes':len(captured)if captured is not None else None})
                stopped = True
            except (ValueError, KeyError, IndexError, TypeError, AttributeError) as exc:
                counts["response_errors" if outcome['attempted'] else 'input_errors'] += 1
                outcome["status"] = "invalid_response" if outcome['attempted'] else 'input_error'
                write_json(args.output / "errors" / (case_id + ".json"), {"type": type(exc).__name__, "message": str(exc)})
                stopped = True
        path = args.output / "outcomes" / (case_id + ".json")
        write_json(path, outcome)
        outcomes.append({"case_id": case_id, "path": str(path.relative_to(args.output))})
        write_json(args.output / "progress.json", {"updated_at_pacific": now(), "planned": len(rows), "terminal_case_dispositions": len(outcomes), "observed_attempted_terminal": counts["attempted_confirmed"], **counts})
    files = [{"path": str(p.relative_to(args.output)), "sha256": digest(p)}
        for sub in ("requests", "responses", "outcomes", "errors", "delivery") for p in sorted((args.output / sub).iterdir())]
    files.append({"path": "run_manifest.json", "sha256": digest(args.output / "run_manifest.json")})
    write_json(args.output / "prediction_lock.json", {"terminal": True, "planned": len(rows), "all_planned_attempted": counts["attempted_confirmed"] == len(rows), "files": files, "outcomes": outcomes})
    write_json(args.output / "completion.json", {"finished_at_pacific": now(), "planned": len(rows), "terminal_case_dispositions": len(outcomes), "observed_attempted_terminal": counts["attempted_confirmed"],
        **counts, "all_passed": counts["delivery_passed"] == len(rows),
        "phase": config["phase"], "protocol_id": config["protocol_id"], "generation": config["generation"],
        "model_revision": config["model_revision"], "images_per_case": 20,
        "prediction_lock_path": str((args.output / "prediction_lock.json").resolve()),
        "prediction_lock_sha256": digest(args.output / "prediction_lock.json"), "biological_correctness_assessed": False,
        "catalog_complete": False})

if __name__ == "__main__":main()
