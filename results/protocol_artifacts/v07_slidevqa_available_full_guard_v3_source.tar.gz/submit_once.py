"""Submit only an independently admitted exact plan under fresh locked GPU audit."""
from pathlib import Path
import argparse,fcntl,json,subprocess
from admission import HERE,ROOT,sha,load,validate
def main():
    parser=argparse.ArgumentParser()
    for name in ('plan','admission'):parser.add_argument('--'+name,type=Path,required=True)
    for name in ('plan-sha256','admission-sha256'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args()
    plan=validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256)
    submission=Path(plan['submission_root']);submission.mkdir(exist_ok=True)
    with (ROOT/'.local/evaluation_GPU_submission.lock').open('a')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256)
        helper=load('v07_frozen_fresh_submission_GPU_audit',plan['GPU_audit_helper'])
        audit=helper.conservative_project_gpu_audit(additional_gpus=1)
        audit_path=submission/'private_GPU_audit_submission.json'
        with audit_path.open('x')as stream:stream.write(json.dumps(audit,indent=2)+'\n')
        claim_path=submission/'submission_attempt.json'
        with claim_path.open('x')as stream:
            stream.write(json.dumps({'plan_sha256':args.plan_sha256,'admission_sha256':args.admission_sha256,
                'GPU_audit_sha256':sha(audit_path),'one_submission_attempt':True},indent=2)+'\n')
        command=['sbatch','--parsable','--time='+plan['job_time'],str(HERE/'worker.sbatch'),'--plan',str(args.plan.resolve()),
            '--plan-sha256',args.plan_sha256,'--admission',str(args.admission.resolve()),'--admission-sha256',args.admission_sha256]
        result=subprocess.run(command,text=True,capture_output=True,timeout=60)
        receipt={'plan_sha256':args.plan_sha256,'admission_sha256':args.admission_sha256,'command':command,
            'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
            'GPU_audit_receipt':str(audit_path),'GPU_audit_sha256':sha(audit_path),'automatic_retry':False}
        with (submission/'submission_receipt.json').open('x')as stream:stream.write(json.dumps(receipt,indent=2)+'\n')
        if result.returncode:raise RuntimeError('Recorded exact submission failed; do not blindly repeat')
        job_id=result.stdout.strip().split(';')[0]
        if not job_id.isdigit():raise ValueError('Ambiguous submission result; never repeat automatically')
        print(json.dumps({'job_id':job_id,'receipt':str(submission/'submission_receipt.json')}))
if __name__=='__main__':main()
