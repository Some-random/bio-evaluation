import ast
import hashlib
import importlib.util
import json
import sys
import tempfile
import unittest
import struct
import zlib
from pathlib import Path

TASK = Path(__file__).resolve().parent
sys.path.insert(0, str(TASK))
from slidevqa_adapter import build_messages, digest, native_metric_functions, parse_final, validate_input
from score import score_predictions
from run import validate_gates
from prepare_synthetic_development import synthetic_png

NATIVE = TASK.parents[4] / ".local/source_acquisition_2026-10-19/vision/slidevqa/source/evaluate.py"
NATIVE_HASH = "604be8d606ec46664e36810b43cdb497880043a39c57a687a819abc30660acbb"


class Contracts(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.directory = Path(self.tmp.name)
        image = self.directory / "synthetic.jpg"
        image.write_bytes(b"SYNTHETIC fixture, not a benchmark image")
        self.row = {"case_id": "fixture", "question": "Which fictional category is larger?", "deck_name": "fictional-deck",
                    "pages": [{"page_number": i, "image_path": str(image), "sha256": digest(image), "source_variant": "synthetic"} for i in range(1, 21)]}

    def tearDown(self):
        self.tmp.cleanup()

    def test_all_twenty_pages_preserved_and_labelled(self):
        messages = build_messages(self.row, data_urls=True)
        self.assertEqual([str(i) for i in range(1, 21)], [c["text"].removeprefix("Page ") for c in messages[0]["content"][:-1] if c["type"] == "text"])
        self.assertEqual(20, sum(c["type"] == "image_url" for c in messages[0]["content"]))

    def test_no_gold_metadata_accepted(self):
        for key in ("answer", "evidence_pages", "arithmetic_expression", "reasoning_type"):
            with self.subTest(key=key), self.assertRaises(ValueError):
                validate_input({**self.row, key: "gold"})

    def test_images_cannot_be_dropped(self):
        with self.assertRaises(ValueError):
            validate_input({**self.row, "pages": self.row["pages"][:19]})

    def test_images_cannot_be_reordered(self):
        with self.assertRaises(ValueError):
            validate_input({**self.row, "pages": list(reversed(self.row["pages"]))})

    def test_image_change_blocks_request(self):
        Path(self.row["pages"][0]["image_path"]).write_bytes(b"changed")
        with self.assertRaises(ValueError):
            build_messages(self.row)

    def test_valid_structured_final(self):
        self.assertEqual({"answer": "fictional", "evidence_pages": [2, 8]}, parse_final('{"answer":"fictional","evidence_pages":[2,8]}'))

    def test_invalid_pages_stay_invalid(self):
        for pages in ([0], [21], [True], [1, 1], [5, 2], []):
            with self.subTest(pages=pages), self.assertRaises(ValueError):
                parse_final(json.dumps({"answer": "synthetic", "evidence_pages": pages}))

    def test_no_wrapping_explanations_or_extra_keys(self):
        for text in ('```json\n{"answer":"x","evidence_pages":[1]}\n```', '{"answer":"x","evidence_pages":[1],"rationale":"unrequested"}'):
            with self.subTest(text=text), self.assertRaises(ValueError):
                parse_final(text)

    def test_empty_final_is_not_delivered(self):
        with self.assertRaises(ValueError):
            parse_final('{"answer":"  ","evidence_pages":[1]}')

    def test_duplicate_output_keys_rejected(self):
        with self.assertRaises(ValueError):
            parse_final('{"answer":"x","answer":"y","evidence_pages":[1]}')

    def test_synthetic_fixture_has_only_expected_png_chunks(self):
        data = synthetic_png(1024, 768, (0, 0, 255))
        self.assertEqual(b"\x89PNG\r\n\x1a\n", data[:8])
        pos, chunks, image = 8, [], b""
        while pos < len(data):
            size = struct.unpack(">I", data[pos:pos+4])[0]
            kind = data[pos+4:pos+8]
            payload = data[pos+8:pos+8+size]
            crc = struct.unpack(">I", data[pos+8+size:pos+12+size])[0]
            self.assertEqual(zlib.crc32(kind + payload) & 0xffffffff, crc)
            chunks.append(kind)
            if kind == b"IHDR":
                self.assertEqual((1024, 768), struct.unpack(">II", payload[:8]))
            if kind == b"IDAT":
                image += payload
            pos += size + 12
        self.assertEqual([b"IHDR", b"IDAT", b"IEND"], chunks)
        pixels = zlib.decompress(image)
        stride = 1 + 1024 * 3
        self.assertEqual(stride * 768, len(pixels))
        self.assertEqual(b"\xff\xff\xff", pixels[1:4])
        center = 384 * stride + 1 + 512 * 3
        self.assertEqual(b"\x00\x00\xff", pixels[center:center+3])

    def test_native_formula_source_hash_pinned(self):
        self.assertEqual(NATIVE_HASH, digest(NATIVE))
        with self.assertRaises(ValueError):
            native_metric_functions(NATIVE, "0" * 64)

    def test_native_exact_match_metrics(self):
        native = native_metric_functions(NATIVE, NATIVE_HASH)
        refs = [{"case_id": "a", "question": "What fictional value?", "answer": "the blue circle", "evidence_pages": [1, 2]}]
        result = score_predictions(native, refs, {"a": '{"answer":"blue circle","evidence_pages":[1,2]}'})
        self.assertEqual({"F1": 1.0, "EM": 1.0}, result["QA"])
        self.assertEqual({"F1": 1.0, "EM": 1.0}, result["ES"])
        self.assertEqual({"F1": 1.0, "EM": 1.0}, result["Main"])

    def test_native_partial_evidence_joint_metric(self):
        native = native_metric_functions(NATIVE, NATIVE_HASH)
        refs = [{"case_id": "a", "question": "What fictional value?", "answer": "blue", "evidence_pages": [1, 2]}]
        result = score_predictions(native, refs, {"a": '{"answer":"blue","evidence_pages":[1]}'})
        self.assertAlmostEqual(2 / 3, result["ES"]["F1"])
        self.assertAlmostEqual(2 / 3, result["Main"]["F1"])
        self.assertEqual(0, result["Main"]["EM"])

    def test_missing_invalid_predictions_keep_denominator(self):
        native = native_metric_functions(NATIVE, NATIVE_HASH)
        refs = [{"case_id": i, "question": "What fictional value?", "answer": "blue", "evidence_pages": [1]} for i in ("a", "b", "c")]
        result = score_predictions(native, refs, {"a": '{"answer":"blue","evidence_pages":[1]}', "b": "invalid"})
        self.assertEqual(3, result["planned"])
        self.assertEqual(2, result["invalid_or_missing_finals"])
        self.assertAlmostEqual(1 / 3, result["Main"]["F1"])

    def test_foreign_prediction_rejected(self):
        with self.assertRaises(ValueError):
            score_predictions(native_metric_functions(NATIVE, NATIVE_HASH), [], {"foreign": "x"})

    def test_grant_is_required_before_endpoint_request(self):
        grant = self.directory / "grant.json"
        grant.write_text('{"authorized":false}')
        config = self.directory / "config.json"
        config.write_text("{}")
        with self.assertRaisesRegex(ValueError, "No exact root grant"):
            validate_gates({"run_id": "fixture"}, config, [], grant, self.directory / "missing", self.directory / "missing")


if __name__ == "__main__":
    unittest.main()
