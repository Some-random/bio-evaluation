"""Synthetic continuation of ordinary invalid finals, with no case retries."""
import copy,json,unittest
import test_runtime_guards as guards
from slidevqa_adapter import OUTPUT_SCHEMA,supported_output_schema

class FinalAccounting(unittest.TestCase):
    setUp=guards.PredictionSeal.setUp
    tearDown=guards.PredictionSeal.tearDown
    seal=guards.PredictionSeal.seal
    save_lock=guards.PredictionSeal.save_lock
    prepare_runtime=guards.RuntimeStopAndSeal.prepare_runtime
    invoke=guards.RuntimeStopAndSeal.invoke
    check_seal=guards.RuntimeStopAndSeal.check_seal
    def pair(self,bad):
        self.opener.open.return_value.__enter__.return_value.read.side_effect=[json.dumps(bad).encode(),json.dumps(self.body).encode()]
        self.invoke();result=self.check_seal(attempted=2,passed=1,not_dispatched=0)
        self.assertEqual(2,self.opener.open.call_count)
        self.assertEqual(1,result['invalid_model_finals'])
        self.assertFalse(result['all_passed'])
        self.assertEqual('invalid_model_final',json.loads((self.output/'outcomes/synthetic-a.json').read_text())['status'])
    def test_invalid_json_final_continues_next_untouched_case(self):
        self.prepare_runtime();bad=copy.deepcopy(self.body)
        bad['choices'][0]['message']['content']='Synthetic malformed final, not JSON'
        self.pair(bad)
    def test_nonascending_final_continues_next_untouched_case(self):
        self.prepare_runtime();bad=copy.deepcopy(self.body)
        bad['choices'][0]['message']['content']='{"answer":"synthetic blue","evidence_pages":[2,1]}'
        self.pair(bad)
    def test_truncated_empty_final_continues_next_untouched_case(self):
        self.prepare_runtime();bad=copy.deepcopy(self.body)
        bad['choices'][0].update(finish_reason='length');bad['choices'][0]['message']['content']=None
        self.pair(bad)
    def test_empty_normal_final_continues_next_untouched_case(self):
        self.prepare_runtime();bad=copy.deepcopy(self.body)
        bad['choices'][0]['message']['content']=''
        self.pair(bad)
    def test_explicit_text_refusal_stops_new_requests(self):
        self.prepare_runtime();bad=copy.deepcopy(self.body)
        bad['choices'][0]['message']['content']='{"answer":"I cannot assist with this request","evidence_pages":[1]}'
        self.opener.open.return_value.__enter__.return_value.read.return_value=json.dumps(bad).encode()
        self.invoke();result=self.check_seal(attempted=1,passed=0,not_dispatched=1)
        self.assertEqual(1,result['refusals']);self.assertEqual(1,self.opener.open.call_count)
    def test_supported_schema_differs_only_in_unsupported_uniqueItems(self):
        expected=copy.deepcopy(OUTPUT_SCHEMA)
        self.assertTrue(expected['properties']['evidence_pages'].pop('uniqueItems'))
        self.assertEqual(expected,supported_output_schema())

if __name__=='__main__':unittest.main()
