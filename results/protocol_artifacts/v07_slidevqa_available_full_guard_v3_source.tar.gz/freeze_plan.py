"""Freeze exact independent reviewed scope; this file does not admit or submit."""
from pathlib import Path
import argparse,hashlib,json,sys
from admission import HERE,TASK,ROOT,POLICY,OWNER,sha
sys.path.insert(0,str(HERE))
from slidevqa_adapter import supported_output_schema
from review_binding import validate_review_bindings
PROTOCOL='SLIDEVQA_TEST2215_FULLDECK_ORIGINAL7700_PROCESSED300_QWEN38_ZERO_SHOT_SUPPORTED_SCHEMA_V2_FULL_GUARD_V3'
def write(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
def rebind_processor(source_path,original_path,new_config_path,directory):
    original_config=json.loads(original_path.read_text())
    receipt=json.loads(source_path.read_text());new=json.loads(new_config_path.read_text())
    for k in ('model_inputs','model','model_path','model_revision','dtype','required_server','processor','planned'):
        if new[k]!=original_config[k]:raise ValueError('Processor-relevant configuration changed: '+k)
    a=dict(new['generation']);b=dict(original_config['generation'])
    del a['structured_outputs'];del b['structured_outputs']
    if a!=b or new['generation']['structured_outputs']!={'json':supported_output_schema()}:
        raise ValueError('Only supported output-constraint compatibility correction may differ')
    observations=source_path.parent/'cases.jsonl'
    if sha(observations)!=receipt['case_observations_sha256']or receipt['config_sha256']!=sha(original_path):
        raise ValueError('Original actual processor receipt differs')
    directory.mkdir();(directory/'cases.jsonl').write_bytes(observations.read_bytes())
    receipt.update(config_sha256=sha(new_config_path),protocol_id=new['protocol_id'],original_processor_receipt=str(source_path),
        original_processor_receipt_sha256=sha(source_path),original_expanded_config_sha256=receipt['config_sha256'],
        rebinding_basis='Run/review/protocol labels and unsupported generation uniqueItems constraint changed; complete model inputs, processor, chat-template and token/context fields identical',
        model_forwards=0)
    write(directory/'completion.json',receipt);return directory/'completion.json'
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--review',type=Path,required=True)
    parser.add_argument('--review-sha256',required=True);args=parser.parse_args()
    if sha(args.review)!=args.review_sha256:raise ValueError('Independent review changed')
    tests=json.loads((HERE/'CPU_tests.json').read_text())
    if tests.get('passed')is not True or tests.get('tests',0)<72:
        raise ValueError('Complete synthetic tests required')
    for name,expected in tests['files_sha256'].items():
        if sha(HERE/name)!=expected:raise ValueError('Synthetic test receipt does not bind final code')
    API=json.loads((HERE/'CPU_runtime_API_completion.json').read_text())
    if (API.get('passed')is not True or API.get('visible_GPUs')!=0 or API.get('model_forwards')!=0
            or API.get('actual_vllm_sampling_backend_validation_passed')is not True):
        raise ValueError('Actual installed CPU runtime/schema gate required')
    if API.get('validated_backend')!='xgrammar' or API.get('output_schema_sha256')!=hashlib.sha256(json.dumps(supported_output_schema(),sort_keys=True).encode()).hexdigest():
        raise ValueError('Actual backend gate does not bind supported schemaV2')
    reviews=[json.loads(line)for line in args.review.read_text().splitlines()]
    original=json.loads((TASK/'condition_config.json').read_text())
    rows=[json.loads(line)for line in Path(original['model_inputs']['path']).read_text().splitlines()]
    policy=json.loads(POLICY.read_text())
    if len(reviews)!=2215 or len(rows)!=2215:raise ValueError('Complete exact reviewed source cohort required')
    if sha(original['model_inputs']['path'])!=original['model_inputs']['sha256']:
        raise ValueError('Frozen full source changed')
    review_pins=validate_review_bindings(rows,reviews,original['model_inputs']['sha256'],
        policy['authorized_reviewers']+['root','/root'],OWNER,TASK)
    config=dict(original);config.update(run_id='qwen38_27b_slidevqa_test2215_full_deck_mixed_images_20261021_full_guard_v3',
        protocol_id=PROTOCOL,case_review={'path':str(args.review.resolve()),'sha256':args.review_sha256},dispatch_authorized=False)
    config['generation']=dict(original['generation']);config['generation']['structured_outputs']={'json':supported_output_schema()}
    config['adaptations']=list(original['adaptations'])+['vLLM-supported generation JSON schema omits unsupported uniqueItems; unchanged strict final validator requires unique ascending evidence pages',
        'Ordinary invalid/truncated model finals retained as invalid and next untouched case continues once; provider/envelope/delivery interruption stops new calls']
    frozen=HERE/'frozen_benchmark_config.json'
    if frozen.exists():raise FileExistsError('Never overwrite frozen condition')
    write(frozen,config)
    full_processor=rebind_processor(TASK/'engineering_20261020/full_processor_check/completion.json',TASK/'condition_config.json',frozen,HERE/'benchmark_processor_binding')
    prepared_development=HERE/'prepared_development_config_v2.json'
    development=json.loads(prepared_development.read_text())
    for key in ('model_inputs','case_review'):
        if sha(development[key]['path'])!=development[key]['sha256']:
            raise ValueError('Frozen neutral source changed: '+key)
    development.update(protocol_id=PROTOCOL,run_id='qwen38_27b_slidevqa_synthetic20image_delivery_20261021_full_guard_v3')
    development['generation']=config['generation'];development['adaptations']=config['adaptations']
    development_path=HERE/'frozen_development_config.json';write(development_path,development)
    dev_processor=rebind_processor(TASK/'available_execution_20261021_v1/synthetic_delivery_v2/processor_preflight/completion.json',prepared_development,development_path,HERE/'development_processor_binding')
    scorer=json.loads((TASK/'scorer_config.private.json').read_text())
    for key in ('task_id','run_id','phase','planned','protocol_id','generation','model_inputs'):scorer[key]=config[key]
    scorer.update(__config_sha256=sha(frozen),__runner_sha256=sha(HERE/'run.py'),
        __adapter_sha256=sha(HERE/'slidevqa_adapter.py'),__scorer_sha256=sha(HERE/'score.py'))
    scorer_path=HERE/'frozen_scorer_config.private.json';write(scorer_path,scorer)
    synthetic_rows=[json.loads(line)for line in Path(development['model_inputs']['path']).read_text().splitlines()]
    synthetic_images={Path(page['image_path']):page['sha256']for row in synthetic_rows for page in row['pages']}
    if any(sha(path)!=expected for path,expected in synthetic_images.items()):
        raise ValueError('Frozen neutral image bytes changed')
    files=[HERE/'admission.py',HERE/'worker.py',HERE/'worker.sbatch',HERE/'freeze_plan.py',HERE/'submit_once.py',TASK/'available_execution_20261021_v1/cpu_runtime_api_check.py',
        TASK/'available_execution_20261021_v1/CPU_runtime_API.sbatch',HERE/'CPU_runtime_API_completion.json',HERE/'CPU_tests.json',frozen,scorer_path,args.review,development_path,
        dev_processor,dev_processor.parent/'cases.jsonl',
        full_processor,full_processor.parent/'cases.jsonl',HERE/'run.py',HERE/'score.py',HERE/'slidevqa_adapter.py',
        HERE/'review_binding.py',HERE/'review_row_schema.json',HERE/'test_review_binding.py',HERE/'test_refusal_handling.py',HERE/'test_transport_capture.py',
        HERE/'test_final_accounting.py',HERE/'test_contract.py',HERE/'test_runtime_guards.py',TASK/'source_manifest.json',TASK/'development_config.json',
        TASK/'synthetic_development/review.jsonl',TASK/'synthetic_development/model_inputs.jsonl',
        TASK/'engineering_20261020/processor_check/completion.json',TASK/'engineering_20261020/processor_check/cases.jsonl',
        ROOT/'.local/shared_vllm_pool_2026-10-17_v3/runtime_common.py',ROOT/'scripts/project_gpu_audit_20261021.py',
        ROOT/'.local/litqa2_replay/checkpoint_verification.json',ROOT/'.local/litqa2_replay/publisher_verification.json',
        ROOT/'.local/litqa2_replay/runtime_archive.json',ROOT/'.local/litqa2_replay/cuda_overlay_archive.json',
        ROOT/'.local/litqa2_replay/cuda_overlay_deletions.json',HERE/'README.md',
        prepared_development,Path(development['model_inputs']['path']),Path(development['case_review']['path']),
        TASK/'available_execution_20261021_v1/synthetic_delivery_v2/construction_receipt.json',
        TASK/'available_execution_20261021_v1/prepare_delivery_v2.py',TASK/'prepare_synthetic_development.py',
        TASK/'available_execution_20261021_v1/synthetic_delivery_v2/processor_preflight/completion.json',
        TASK/'engineering_20261020/full_processor_check/completion.json',
        POLICY,Path(config['model_inputs']['path']),*synthetic_images]
    p={'task_id':'V07','engineering_owner':OWNER,'condition_id':config['protocol_id'],
        'project_root':str(ROOT),'requested_GPUs':1,'project_GPU_ceiling':8,'source_case_denominator':2215,
        'planned_cases':2215,'planned_case_ids':[r['case_id']for r in rows],'source_scope_review_sha256':args.review_sha256,
        'execution_scope':'reviewed_full_benchmark','runtime_root':str(HERE/'runtime'),
        'submission_root':str(HERE/'submission'),'job_time':'7-00:00:00',
        'maximum_attempts_per_case':1,'native_metric_formulas_unchanged':True,'new_training':False,
        'paid_model_calls':False,'automatic_retries':False,'full_native_Ryze_Table3_reproduction':False,
        'image_condition':{'author_original_url_bytes':7700,'processed1024_different_encoding':300,'complete_page_identities':8000},
        'model':{'name':config['model'],'revision':config['model_revision'],'dtype':'bfloat16','tensor_parallel_size':1},
        'base_runtime':{'path':str(ROOT/'.local/litqa2_replay/runtime.tar'),'sha256':'732def4d7a95da921b67dbfcc8bbf1e602218868b7ee40e3cc9990e059f92893'},
        'cuda_overlay':{'path':str(ROOT/'.local/litqa2_replay/cuda_toolchain_overlay.tar'),'sha256':'e9f9c715bc3ce46a7d9d8b0d40a05372be14a978821df1f8facaf3039cca09a2'},
        'runtime_common':str(ROOT/'.local/shared_vllm_pool_2026-10-17_v3/runtime_common.py'),
        'GPU_audit_helper':str(ROOT/'scripts/project_gpu_audit_20261021.py'),
        'port':8510,'endpoint':'http://127.0.0.1:8510/v1','scorer_config':str(scorer_path),'structured_output_backend':'xgrammar',
        'neutral_visual_assertions':{'V07_synthetic_dev_00':{'answer_color':'blue','evidence_pages':[1]},
            'V07_synthetic_dev_01':{'answer_color':'red','evidence_pages':[20]},
            'V07_synthetic_max_dev_00':{'answer_color':'blue','evidence_pages':[1]},
            'V07_synthetic_max_dev_01':{'answer_color':'red','evidence_pages':[20]}},
        'phases':{'development':{'config':str(development_path),
            'processor_preflight':str(dev_processor),
            'output':str(HERE/'runtime/development')},'benchmark':{'config':str(frozen),
            'processor_preflight':str(full_processor),'output':str(HERE/'runtime/benchmark')}},
        'reference_access':'Only once-only scorer after complete verified prediction lock',
        'delivery_gate':'Own live20image actual model requests; exact API expanded prompt tokens match all pinned CPU observations',
        'adaptations':config['adaptations'],'publication':'Reviewed narrow code/aggregate permitted artifacts only; licensed raw content stays private',
        'source_review_evidence_sha256':review_pins,
        'frozen_files_sha256':{**{str(f.resolve()):sha(f)for f in files},**review_pins}}
    write(HERE/'plan.json',p);print(json.dumps({'plan':str(HERE/'plan.json'),'sha256':sha(HERE/'plan.json'),'admitted':False}))
if __name__=='__main__':main()
