P14 / DeepFRI molecular-function annotation

Exact 3,416 released test95 full-FASTA inputs, 489 fixed ordered GO-MF descriptions, uniform 16,384-token outputs and independently declared zero-shot Qwen adaptation. The archive retains exact frozen solver/scorer/source bytes and P14 continuation identity, permission-drain, boundary, grant, completion and once-only scoring evidence. The separate trajectory archive contains all original benchmark requests, responses and outcomes.

Scorer target values, model weights, credentials and installed runtime environments are excluded. Configuration files preserve original source paths and hashes: relocation is required to reproduce the filesystem layout, and scorer references must be obtained separately from their pinned release. This does not reproduce trained DeepFRI/ProtST heads or its PDB-modeled subset. No model calls or scoring attempts are made by export/publication.
