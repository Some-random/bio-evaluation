"""One offline invocation of the unchanged native scorer after wrapper failure."""
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
BASE = ROOT / '.local/catalog_execution_2026-10-20'
RUN = BASE / 'tasks/P14/runtime/benchmark'
HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def stamp():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    with (HERE / 'sole_native_invocation.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        root = read(HERE / 'root_review.json')
        manifest_path = BASE / 'continuation_v1/manifest.json'
        assert sha(manifest_path) == root['continuation_manifest_sha256']
        manifest = read(manifest_path)
        assert os.environ.get('SLURM_JOB_ID') == '243499'
        assert sha(BASE / 'control/P14_scoring_status.json') == root['original_failed_status_sha256']
        assert sha(BASE / 'control/P14_scoring.log') == root['original_failed_log_sha256']
        assert read(BASE / 'control/P14_scoring_status.json')['stage'] == 'failed_no_retry'
        receipt_path = BASE / 'continuation_v1/runtime/predecessor_terminal_receipt.json'
        receipt = read(receipt_path)
        assert sha(receipt_path) == root['predecessor_terminal_receipt_sha256']
        assert receipt['original_job_id'] == '243179' and receipt['original_job_state'] == 'TIMEOUT'
        assert receipt['successor_job_id'] == '243499'
        complete = read(RUN / 'completion.json')
        assert complete['planned'] == complete['terminal'] == complete['responses_saved'] == complete['delivery_passed'] == 3416
        assert sha(RUN / 'prediction_lock.json') == complete['prediction_lock_sha256'] == root['prediction_lock_sha256']
        assert not (RUN / 'scores.json').exists() and not (HERE / 'attempt.json').exists()
        write(HERE / 'attempt.json', {'at_pacific': stamp(), 'role': 'offline_only_unchanged_native_scorer_invocation',
            'prediction_lock_sha256': root['prediction_lock_sha256'], 'model_calls': 0,
            'original_failed_wrapper_evidence_preserved': True})
        helper_path = Path(manifest['scoring_helper'])
        assert sha(helper_path) == root['scoring_helper_sha256']
        spec = importlib.util.spec_from_file_location('p14_unchanged_native_runtime_helper', helper_path)
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        helper.BASE = BASE / 'continuation_v1'
        sys.argv = [str(helper_path), '--plan', manifest['dispatch_plan'],
                    '--plan-sha256', manifest['dispatch_plan_sha256'], '--task', 'P14']
        try:
            helper.main()
        except SystemExit as result:
            code = result.code or 0
        else:
            code = 0
        write(HERE / 'completion.json', {'at_pacific': stamp(), 'task_id': 'P14',
            'stage': 'native_score_completed_after_wrapper_repair' if code == 0 and (RUN / 'scores.json').is_file() else 'failed_no_automatic_retry',
            'exit_code': code, 'score_sha256': sha(RUN / 'scores.json') if (RUN / 'scores.json').is_file() else None,
            'prediction_lock_sha256': root['prediction_lock_sha256'], 'model_calls': 0,
            'native_scorer_changed': False, 'original_failed_wrapper_evidence_preserved': True})
        raise SystemExit(code)


if __name__ == '__main__':
    main()
