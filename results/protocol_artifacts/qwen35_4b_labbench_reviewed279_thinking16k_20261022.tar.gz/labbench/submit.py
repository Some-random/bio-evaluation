"""Submit one immutable model condition after locked fresh eight-GPU audit."""
from pathlib import Path
import argparse
import fcntl
import json
import subprocess
import sys

from worker import audit, sha, validate, write, HERE, ROOT


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha256", required=True)
    parser.add_argument("--grant", type=Path, required=True)
    parser.add_argument("--grant-sha256", required=True)
    parser.add_argument("--model-key", choices=["base", "posttrained"], required=True)
    args = parser.parse_args()
    plan = validate(args.plan, args.plan_sha256, args.grant, args.grant_sha256, args.model_key)
    runtime = Path(plan["models"][args.model_key]["runtime"])
    runtime.mkdir(parents=True, exist_ok=True)
    global_lock = (ROOT / ".local/evaluation_GPU_submission.lock").open("a")
    with global_lock:
        fcntl.flock(global_lock, fcntl.LOCK_EX)
        claim = runtime / "submission_claim.json"
        receipt_path = runtime / "submission_receipt.json"
        if claim.exists() or receipt_path.exists():
            raise ValueError("Submission already attempted; no automatic retry")
        try:
            observation = audit(plan, additional=1)
        except ValueError as error:
            if str(error) == "Evaluation project GPU requests exceed eight":
                print(json.dumps({"stage": "capacity_only_wait", "sbatch_invoked": False, "submission_attempt_started": False, "claim_exists": False, "receipt_exists": False, "reason": str(error)}))
                raise SystemExit(75)
            raise
        write(claim, {"model_key": args.model_key, "plan_sha256": args.plan_sha256, "grant_sha256": args.grant_sha256, "gpu_audit": observation, "no_retry_after_claim": True})
        command = ["sbatch", "--parsable", "--job-name=qwen35-labbench-" + args.model_key, str(HERE / "worker.sbatch"), "--plan", str(args.plan), "--plan-sha256", args.plan_sha256, "--grant", str(args.grant), "--grant-sha256", args.grant_sha256, "--model-key", args.model_key]
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=45)
        except Exception as error:
            write(receipt_path, {"stage": "submission_uncertain_no_retry", "model_key": args.model_key, "error_type": type(error).__name__, "error": str(error), "sbatch_invoked": True})
            raise
        job_id = result.stdout.strip().split(";")[0]
        valid = result.returncode == 0 and job_id.isdigit()
        receipt = {"stage": "submitted_not_model_dispatch_evidence" if valid else "submission_failed_or_uncertain_no_retry", "job_id": job_id if valid else None, "model_key": args.model_key, "plan_sha256": args.plan_sha256, "grant_sha256": args.grant_sha256, "sbatch_invoked": True, "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr, "requested_gpu_count": 1, "gpu_audit": observation}
        write(receipt_path, receipt)
        print(json.dumps(receipt))
        if not valid:
            raise SystemExit(1)


if __name__ == "__main__":
    main()
