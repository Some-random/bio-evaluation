"""Pure checks of actual two-model neutral proof; no GPU or model entrypoint."""
from pathlib import Path
import hashlib
import json


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def regular(path):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise ValueError('Expected regular neutral proof artifact: ' + str(path))
    return path


def pinned(record):
    path = regular(record['path'])
    if sha(path) != record['sha256']:
        raise ValueError('Neutral prerequisite source changed')
    return path


def validate_neutral_proof(plan, contract):
    expected = plan['neutral_validation']
    root = Path(expected['directory'])
    neutral_plan = pinned(expected['plan'])
    submission_path = pinned(expected['submission'])
    submission = json.loads(submission_path.read_text())
    expected_plan_sha = sha(neutral_plan)
    if submission.get('job_id') != expected['job_id'] or submission.get('plan_sha256') != expected_plan_sha:
        raise ValueError('Neutral prerequisite submission identity differs')
    receipt_path = regular(root / 'receipt.json')
    if Path(contract['neutral_gate_receipt']) != receipt_path:
        raise ValueError('Unexpected neutral receipt location')
    receipt = json.loads(receipt_path.read_text())
    shared_sha = plan['shared_contract']['sha256']
    if (receipt.get('passed') is not True or receipt.get('shared_contract_sha256') != shared_sha
            or receipt.get('job_id') != expected['job_id']
            or receipt.get('plan_sha256') != expected_plan_sha
            or receipt.get('synthetic_only') is not True or receipt.get('biological_calls') != 0
            or set(receipt.get('models', {})) != {'base', 'posttrained'}):
        raise ValueError('Actual two-model neutral receipt is incomplete or substituted')
    started = json.loads(regular(root / 'started.json').read_text())
    if started.get('job_id') != expected['job_id'] or started.get('plan_sha256') != expected_plan_sha:
        raise ValueError('Neutral started proof differs')
    verified = {}
    required_artifacts = {'private_gpu_audit.json', 'phase_claim.json', 'runtime.json',
                          'native_render_parity.json', 'parallel_requests.json',
                          'parallel_outputs.json', 'long_request.json', 'long_output.json'}
    for key in ['base', 'posttrained']:
        model = contract['models'][key]
        row = receipt['models'][key]
        path = regular(root / key / 'completion.json')
        if (row.get('passed') is not True or row.get('completion') != str(path)
                or row.get('completion_sha256') != sha(path)
                or row.get('model') != model['name'] or row.get('revision') != model['revision']):
            raise ValueError('Neutral completion identity or hash differs')
        completion = json.loads(path.read_text())
        if (completion.get('passed') is not True or completion.get('model_key') != key
                or completion.get('model') != model['name'] or completion.get('revision') != model['revision']
                or completion.get('shared_contract_sha256') != shared_sha
                or completion.get('synthetic_only') is not True
                or completion.get('parallel_cases') != 16 or completion.get('concurrency') != 16
                or completion.get('long_prompt_tokens', 0) < 40000
                or completion.get('reserved_output_tokens') != 16384
                or completion.get('context_limit') != 65536
                or (completion.get('parallel_gate') or {}).get('passed') is not True
                or (completion.get('long_gate') or {}).get('passed') is not True):
            raise ValueError('Neutral model runtime validation did not pass exact settings')
        artifacts = completion.get('artifact_pins', {})
        if not required_artifacts <= set(artifacts):
            raise ValueError('Neutral proof misses required actual artifacts')
        for name, expected_sha in artifacts.items():
            if Path(name).name != name:
                raise ValueError('Neutral artifact path escapes expected directory')
            artifact = regular(path.parent / name)
            if sha(artifact) != expected_sha:
                raise ValueError('Actual neutral artifact bytes changed')
        phase = json.loads((path.parent / 'phase_claim.json').read_text())
        if phase.get('job_id') != expected['job_id'] or phase.get('model_key') != key:
            raise ValueError('Neutral phase belongs to another job or model')
        runtime = json.loads((path.parent / 'runtime.json').read_text())
        if runtime.get('model_key') != key or runtime.get('GPU_count') != 1 or runtime.get('dtype') != 'bfloat16':
            raise ValueError('Neutral actual model runtime identity differs')
        if any((runtime.get('packages', {}).get(name) or '').split('+')[0] != version
               for name, version in contract['runtime_expected'].items()):
            raise ValueError('Neutral actual runtime versions differ')
        parity = json.loads((path.parent / 'native_render_parity.json').read_text())
        if parity.get('passed') is not True or parity.get('template_sha256') != contract['chat_template_sha256']:
            raise ValueError('Neutral actual native-template validation differs')
        outputs = json.loads((path.parent / 'parallel_outputs.json').read_text())
        long_outputs = json.loads((path.parent / 'long_output.json').read_text())
        if (len(outputs) != 16 or [r.get('case_id') for r in outputs] != [f'parallel_{i:02d}' for i in range(16)]
                or len(long_outputs) != 1 or long_outputs[0].get('case_id') != 'long_context'):
            raise ValueError('Neutral output cohort differs')
        for output in outputs + long_outputs:
            if (output.get('model_key') != key or output.get('task_id') != 'synthetic_neutral'
                    or output.get('final') != '5' or output.get('truncated')
                    or output.get('response_error') or output.get('finish_reason') != 'stop'
                    or not isinstance(output.get('token_ids'), list) or not output['token_ids']):
                raise ValueError('Actual neutral output did not pass')
        verified[key] = {'completion': str(path), 'completion_sha256': sha(path),
                         'model': model['name'], 'revision': model['revision'],
                         'artifact_count': len(artifacts)}
    return {'receipt_path': str(receipt_path), 'receipt_sha256': sha(receipt_path),
            'shared_contract_sha256': shared_sha, 'job_id': expected['job_id'],
            'neutral_plan_sha256': expected_plan_sha, 'models': verified,
            'passed': True}
