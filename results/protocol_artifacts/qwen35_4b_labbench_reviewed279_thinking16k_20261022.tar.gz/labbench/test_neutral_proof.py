"""Invented proof files only; block all scheduler/model subprocess entrypoints."""
from pathlib import Path
import json
import os
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

import neutral_proof as proof
import worker


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))
    return path


class NeutralProofTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='synthetic-neutral-proof-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        neutral = self.root / 'neutral'
        neutral.mkdir()
        self.neutral = neutral
        source_plan = write(neutral / 'plan.json', {'synthetic_fixture_only': True})
        submission = write(neutral / 'submission.json', {'job_id': '246419',
                                                       'plan_sha256': proof.sha(source_plan)})
        self.contract = {'models': {k: {'name': 'fixture_' + k, 'revision': 'artificial_revision'}
                                    for k in ['base', 'posttrained']},
                         'runtime_expected': {'vllm': '0.31.0', 'torch': '2.13.0'},
                         'chat_template_sha256': 'artificial_template',
                         'neutral_gate_receipt': str(neutral / 'receipt.json')}
        self.plan = {'shared_contract': {'path': '/unused/shared.json', 'sha256': 'artificial_shared'},
                     'neutral_validation': {'directory': str(neutral), 'job_id': '246419',
                          'plan': {'path': str(source_plan), 'sha256': proof.sha(source_plan)},
                          'submission': {'path': str(submission), 'sha256': proof.sha(submission)}},
                     'shared_runtime': {'path': '/unused/shared_runtime.py'},
                     'models': {'base': {'runtime': str(self.root / 'worker' / 'base')}}}
        write(neutral / 'started.json', {'job_id': '246419', 'plan_sha256': proof.sha(source_plan)})
        self.receipt = {'passed': True, 'shared_contract_sha256': 'artificial_shared',
                        'job_id': '246419', 'plan_sha256': proof.sha(source_plan),
                        'synthetic_only': True, 'biological_calls': 0, 'models': {}}
        for key, model in self.contract['models'].items():
            root = neutral / key
            root.mkdir()
            for name in ['private_gpu_audit.json', 'parallel_requests.json', 'long_request.json']:
                write(root / name, {'artificial_fixture': True})
            write(root / 'phase_claim.json', {'model_key': key, 'job_id': '246419'})
            write(root / 'runtime.json', {'model_key': key, 'GPU_count': 1,
                                          'dtype': 'bfloat16', 'packages': self.contract['runtime_expected']})
            write(root / 'native_render_parity.json', {'passed': True,
                                                      'template_sha256': 'artificial_template'})
            def output(case):
                return {'case_id': case, 'task_id': 'synthetic_neutral', 'model_key': key,
                        'final': '5', 'truncated': False, 'response_error': False,
                        'finish_reason': 'stop', 'token_ids': [1, 2]}
            write(root / 'parallel_outputs.json', [output(f'parallel_{i:02d}') for i in range(16)])
            write(root / 'long_output.json', [output('long_context')])
            completion = {'passed': True, 'model_key': key, 'model': model['name'],
                          'revision': model['revision'], 'shared_contract_sha256': 'artificial_shared',
                          'synthetic_only': True, 'parallel_cases': 16, 'concurrency': 16,
                          'long_prompt_tokens': 45000, 'reserved_output_tokens': 16384,
                          'context_limit': 65536, 'parallel_gate': {'passed': True},
                          'long_gate': {'passed': True},
                          'artifact_pins': {p.name: proof.sha(p) for p in root.glob('*.json')}}
            path = write(root / 'completion.json', completion)
            self.receipt['models'][key] = {'passed': True, 'completion': str(path),
                     'completion_sha256': proof.sha(path), 'model': model['name'],
                     'revision': model['revision']}
        write(neutral / 'receipt.json', self.receipt)

    def assert_blocks_model_entrypoint(self):
        restore = Mock(side_effect=AssertionError('Model runtime restoration reached'))
        fake_common = SimpleNamespace(load_contract=lambda *args: self.contract,
                                      restore_runtime=restore)
        def loader(path, name):
            return proof if Path(path).name == 'neutral_proof.py' else fake_common
        argv = ['worker', '--plan', '/unused/plan.json', '--plan-sha256', 'x',
                '--grant', '/unused/grant.json', '--grant-sha256', 'y', '--model-key', 'base']
        with patch.object(sys, 'argv', argv), patch.dict(os.environ, {'SLURM_JOB_ID': '900002'}), \
             patch.object(worker, 'validate', return_value=self.plan), \
             patch.object(worker, 'audit', return_value={}), patch.object(worker, 'load', side_effect=loader), \
             patch.object(worker.subprocess, 'run') as model_process:
            with self.assertRaises((ValueError, FileNotFoundError)):
                worker.main()
            restore.assert_not_called()
            model_process.assert_not_called()

    def test_complete_two_model_proof_passes(self):
        result = proof.validate_neutral_proof(self.plan, self.contract)
        self.assertTrue(result['passed'])
        self.assertEqual(set(result['models']), {'base', 'posttrained'})
        self.assertEqual(result['job_id'], '246419')

    def test_missing_receipt_cannot_reach_model(self):
        (self.neutral / 'receipt.json').unlink()
        self.assert_blocks_model_entrypoint()

    def test_missing_model_cannot_reach_model(self):
        self.receipt['models'].pop('posttrained')
        write(self.neutral / 'receipt.json', self.receipt)
        self.assert_blocks_model_entrypoint()

    def test_wrong_model_identity_cannot_reach_model(self):
        self.receipt['models']['base']['model'] = 'wrong_model'
        write(self.neutral / 'receipt.json', self.receipt)
        self.assert_blocks_model_entrypoint()

    def test_mutated_completion_cannot_reach_model(self):
        path = self.neutral / 'base' / 'completion.json'
        path.write_text(path.read_text() + '\n')
        self.assert_blocks_model_entrypoint()

    def test_mutated_underlying_artifact_cannot_reach_model(self):
        write(self.neutral / 'base' / 'parallel_outputs.json', [])
        self.assert_blocks_model_entrypoint()

    def test_wrong_job_or_plan_cannot_reach_model(self):
        self.receipt['job_id'] = 'wrong_job'
        self.receipt['plan_sha256'] = 'wrong_plan'
        write(self.neutral / 'receipt.json', self.receipt)
        self.assert_blocks_model_entrypoint()


if __name__ == '__main__':
    unittest.main()
