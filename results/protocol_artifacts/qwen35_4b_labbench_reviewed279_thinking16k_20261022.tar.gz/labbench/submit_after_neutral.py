"""Add the exact frozen neutral-job afterok constraint to reviewed submission.

The underlying plan/grant/once-only claim and locked eight-GPU audit remain in
submit.py. This wrapper adds a scheduler prerequisite; it grants no model calls.
"""
from pathlib import Path
import argparse
import json
import os
import sys

import submit
from worker import sha

SOURCE = Path(__file__).resolve().parent.parent / 'neutral_validation' / 'submission.json'
SOURCE_SHA256 = '50a55590f8c521ed73f41f5d2a04b34d021aec90149483028ef52e7b5dc6fa67'
NEUTRAL_PLAN_SHA256 = 'a4859c4870601c813ed5a47be6850b524af822c94bfe09204cd93d0ab2b81a57'


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--neutral-job-id', required=True, choices=['246419'])
    args, remaining = parser.parse_known_args()
    if sha(SOURCE) != SOURCE_SHA256:
        raise ValueError('Exact neutral submission receipt changed')
    source = json.loads(SOURCE.read_text())
    if source['job_id'] != args.neutral_job_id or source['plan_sha256'] != NEUTRAL_PLAN_SHA256:
        raise ValueError('Wrong neutral prerequisite allocation')
    # sbatch officially accepts this environment option. No worker or generation
    # setting is changed, and the worker independently checks the passed receipt.
    os.environ['SBATCH_DEPENDENCY'] = 'afterok:' + args.neutral_job_id
    sys.argv = [str(Path(__file__).resolve().parent / 'submit.py'), *remaining]
    submit.main()


if __name__ == '__main__':
    main()
