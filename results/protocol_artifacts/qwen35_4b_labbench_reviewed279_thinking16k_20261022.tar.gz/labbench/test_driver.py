"""Artificial end-to-end delivery/sealing checks, without model or real labels."""
from pathlib import Path
import json
import os
import tempfile
import unittest
import driver
import score


COMMON = Path(__file__).resolve().parent.parent / 'shared_runtime.py'
common = driver.load(COMMON, 'synthetic_labbench_test_common')


class FakeSession:
    def __init__(self, model_key, plan, mode='normal'):
        self.key, self.plan, self.mode = model_key, plan, mode
        self.calls = 0

    def prepare(self, row):
        prompt = row['messages'][0]['content']
        body = {'model': self.plan['models'][self.key]['name'], 'prompt': prompt,
                **self.plan['generation']}
        return {**row, 'model_key': self.key, 'prompt': prompt,
                'prompt_token_ids': [1, 2], 'prompt_tokens': 2,
                'body': body, 'request_sha256': common.digest(body),
                'messages_sha256': common.digest(row['messages'])}

    def generate_prepared(self, batch):
        self.calls += 1
        root = Path(self.plan['models'][self.key]['runtime'])
        # Every request has been durably created before this model entrypoint.
        if len(list((root / 'cases').glob('*/request.json'))) < len(batch):
            raise AssertionError('Request-before-dispatch invariant failed')
        if self.mode == 'exception':
            raise RuntimeError('Artificial runtime failure')
        result = []
        for row in batch:
            text, finish = 'artificial reasoning</think>[ANSWER]A[/ANSWER]', 'stop'
            if self.mode == 'truncate' and row['case_id'] == 'synthetic_0':
                text, finish = 'unfinished artificial reasoning', 'length'
            if self.mode == 'truncate_after_close' and row['case_id'] == 'synthetic_0':
                text, finish = 'artificial reasoning</think>[ANSWER]A[/ANSWER]', 'length'
            result.append(common.normalize_output(row, text, [1, 2, 3], finish, {}))
        return result


class DeliveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.previous_job = os.environ.get('SLURM_JOB_ID')
        os.environ['SLURM_JOB_ID'] = '900001'
        self.inputs = [{'task_id': 'B01' if i < 197 else 'B03',
                        'case_id': f'synthetic_{i}',
                        'messages': [{'role': 'user', 'content': f'Artificial fixture {i}'}]}
                       for i in range(279)]
        input_path = self.root / 'inputs.jsonl'
        input_path.write_text(''.join(json.dumps(r) + '\n' for r in self.inputs))
        self.plan = {'inputs': {'path': str(input_path), 'sha256': driver.sha(input_path)},
                     'models': {key: {'name': key, 'revision': 'synthetic_only',
                                      'runtime': str(self.root / key), 'run_id': 'fixture_' + key}
                                for key in ['base', 'posttrained']},
                     'generation': {'max_tokens': 16384}, 'context_limit': 65536,
                     'batch_size': 16, 'pins': {}, 'condition': 'synthetic_only',
                     'shared_runtime': {'path': str(COMMON)},
                     'score_runtime': str(self.root / 'scoring'),
                     'references_scorer_only': {}}
        contract_path = self.root / 'synthetic_shared_contract.json'
        contract_path.write_text(json.dumps({'source_pins': {}, 'context_limit': 65536,
                                             'generation': {'max_tokens': 16384}}))
        self.plan['shared_contract'] = {'path': str(contract_path), 'sha256': driver.sha(contract_path)}
        for task in ['B01', 'B03']:
            refs = self.root / (task + '.synthetic_references.jsonl')
            refs.write_text(''.join(json.dumps({'task': r['task_id'], 'case_id': r['case_id'],
                            'choice_count': 5, 'target_choice': 'A', 'unsure_choice': 'E'}) + '\n'
                            for r in self.inputs if r['task_id'] == task))
            self.plan['references_scorer_only'][task] = {'path': str(refs), 'sha256': driver.sha(refs)}
        self.path = self.root / 'plan.json'
        self.path.write_text(json.dumps(self.plan))

    def tearDown(self):
        if self.previous_job is None:
            os.environ.pop('SLURM_JOB_ID', None)
        else:
            os.environ['SLURM_JOB_ID'] = self.previous_job
        self.temp.cleanup()

    def run_model(self, key, mode='normal'):
        return driver.run_model(FakeSession(key, self.plan, mode), self.plan, self.path, key)

    def test_native_insufficient_information_is_not_a_refusal(self):
        result = driver.classify_refusal('I cannot provide an answer without the paper. [ANSWER]E[/ANSWER]')
        self.assertFalse(result['refusal'])
        self.assertTrue(result['possible_inability_text'])
        self.assertIsNone(driver.stop_reason(result))

    def test_explicit_refusal_stops_new_requests(self):
        result = driver.classify_refusal("I'm sorry, but I cannot help with that request because it could be unsafe.")
        self.assertTrue(result['refusal'])
        self.assertEqual(driver.stop_reason(result), 'explicit_refusal')

    def test_truncated_invalid_answer_is_saved_and_cohort_continues(self):
        done = self.run_model('base', 'truncate')
        self.assertEqual(done['responses_saved'], 279)
        self.assertEqual(done['terminal'], 279)
        self.assertEqual(done['truncations'], 1)
        self.assertEqual(done['empty_finals'], 1)
        self.assertEqual(done['runtime_exceptions'], 0)
        self.assertTrue(done['all_planned_terminal'])
        with self.assertRaises(ValueError):
            self.run_model('base')

    def test_uncertain_batch_exception_is_preserved_and_stops(self):
        with self.assertRaises(RuntimeError):
            self.run_model('base', 'exception')
        run = self.root / 'base'
        progress = json.loads((run / 'progress.json').read_text())
        self.assertEqual(progress['request_claims'], 16)
        self.assertEqual(progress['attempted_confirmed'], 0)
        self.assertEqual(progress['ambiguous_without_raw_response'], 16)
        self.assertEqual(progress['terminal'], 16)
        self.assertEqual(progress['responses_saved'], 0)
        self.assertEqual(progress['not_dispatched'], 263)
        self.assertFalse((run / 'prediction_lock.json').exists())

    def test_both_seals_required_before_reference_access(self):
        self.run_model('base')
        for row in self.plan['references_scorer_only'].values():
            Path(row['path']).unlink()
        with self.assertRaises(FileNotFoundError):
            score.score(self.path, driver.sha(self.path))
        self.assertFalse((self.root / 'scoring' / 'attempt_001.json').exists())

    def test_truncation_after_close_paired_seals_and_once_only_native_scoring(self):
        self.run_model('base', 'truncate_after_close')
        self.run_model('posttrained')
        raw = json.loads((self.root / 'base' / 'cases' / '000000' / 'response.json').read_text())
        self.assertIn('</think>[ANSWER]A[/ANSWER]', raw['raw_text'])
        self.assertEqual(raw['final_text'], '')
        self.assertTrue(raw['truncated'])
        result = score.score(self.path, driver.sha(self.path))
        self.assertEqual(result['models']['base']['per_task']['B01']['metrics']['n_total'], 197)
        self.assertEqual(result['models']['base']['per_task']['B01']['metrics']['n_correct'], 196)
        self.assertEqual(result['models']['posttrained']['per_task']['B03']['metrics']['n_correct'], 82)
        self.assertEqual(score.score(self.path, driver.sha(self.path)), result)
        request = self.root / 'base' / 'cases' / '000000' / 'request.json'
        request.write_text(request.read_text() + '\n')
        with self.assertRaises(ValueError):
            score.score(self.path, driver.sha(self.path))


if __name__ == '__main__':
    unittest.main()
