"""Mocked submission only: no scheduler command or model call is executed."""
import os
import sys
import unittest
from unittest.mock import patch
import submit_after_neutral as wrapper


class DependencyWrapperTests(unittest.TestCase):
    def test_exact_dependency_is_forwarded_without_changing_model_arguments(self):
        remaining = ['--plan', '/artificial/plan.json', '--plan-sha256', 'abc',
                     '--grant', '/artificial/grant.json', '--grant-sha256', 'def',
                     '--model-key', 'base']
        seen = []
        with patch.object(sys, 'argv', ['wrapper', '--neutral-job-id', '246419', *remaining]), \
             patch.dict(os.environ, {'SBATCH_DEPENDENCY': 'afterany:1'}), \
             patch.object(wrapper.submit, 'main', lambda: seen.append((list(sys.argv), os.environ['SBATCH_DEPENDENCY']))):
            wrapper.main()
        self.assertEqual(seen[0][0][1:], remaining)
        self.assertEqual(seen[0][1], 'afterok:246419')

    def test_receipt_change_cannot_reach_submitter(self):
        with patch.object(sys, 'argv', ['wrapper', '--neutral-job-id', '246419']), \
             patch.object(wrapper, 'sha', return_value='artificial mismatch'), \
             patch.object(wrapper.submit, 'main') as submit:
            with self.assertRaises(ValueError):
                wrapper.main()
            submit.assert_not_called()


if __name__ == '__main__':
    unittest.main()
