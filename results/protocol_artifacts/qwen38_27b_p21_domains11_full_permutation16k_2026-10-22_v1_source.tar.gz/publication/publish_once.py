"""Publish the four concrete, independently reviewed restored P21 artifacts once."""
from pathlib import Path
import argparse
import contextlib
import fcntl
import hashlib
import json
import os
import re
import stat
import subprocess
import tempfile

import package_contract as assemble
import package_contract as c

REVIEWERS = frozenset(('/root', '/root/independent_review'))
COMMIT_RE = re.compile('[0-9a-f]{40}')


def validate_review(path, digest, manifest, manifest_sha):
    if path is None or digest is None or c.sha(path) != digest:
        raise PermissionError('Exact independent concrete P21 review required')
    r = c.read(path)
    if (r.get('reviewer') not in REVIEWERS or r.get('approved') is not True
            or r.get('role') != 'independent_P21_exact_four_artifact_publication_review'
            or r.get('reviewed_assays') != 11 or r.get('native_panel_assays') != 67
            or r.get('task_id') != 'P21' or r.get('manifest_sha256') != manifest_sha
            or r.get('paths_sha256') != manifest['files_sha256']
            or r.get('repository') != c.REPOSITORY or r.get('visibility') != 'public'
            or r.get('config_sha256') != manifest['config_sha256']
            or r.get('root_adoption_sha256') != c.AUTH_SHA
            or r.get('secret_archive_scans_verified') is not True
            or r.get('exact_original_and_current_provenance_verified') is not True
            or r.get('full_native67_complete') is not False or r.get('prior13_pooled') is not False):
        raise PermissionError('Peer must approve only exact concrete restored P21 bytes')
    return r


def verify_helpers(manifest):
    c.source_check()
    for path in (c.GIT_HELPER, c.CREDENTIAL_HELPER, c.DESTINATION_POLICY, c.SCANNER):
        if manifest['source_files_sha256'].get(str(path)) != c.sha(path):
            raise ValueError('Exact helper/scanner source changed')


def confirm_destination(helper):
    if helper.URL != c.URL or helper.REPOSITORY != c.REPOSITORY:
        raise ValueError('Exact GitHub helper destination required')
    result = helper.confirm_destination()
    if (result.get('repository') != c.REPOSITORY or result.get('visibility') != 'public'
            or result.get('push_permission') is not True):
        raise ValueError('Actual repository identity, public visibility or push permission differs')
    return result


@contextlib.contextmanager
def exclusive_lock(path):
    fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise ValueError('Regular shared lock required')
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        os.close(fd)


def publication_stops():
    if os.path.lexists(c.HERE / 'STOP'):
        raise PermissionError('Publication STOP present')


def no_prior_attempt():
    publication_stops()
    if any(os.path.lexists(c.HERE / name) for name in
           ('publication_receipt.json', 'attempt_started.json', 'push_intent.json')):
        raise FileExistsError('Preserve prior publication attempt; no automatic ambiguous push retry')


def git_environment(environment):
    result = {key: value for key, value in environment.items() if not key.startswith('GIT_')}
    result.update(GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull, GIT_TERMINAL_PROMPT='0')
    return result


def git_blob_sha(checkout, revision_path):
    """Hash one Git blob through a bounded stream; no aggregate raw capture."""
    process = subprocess.Popen(['git', 'show', revision_path], cwd=checkout,
        env=git_environment(os.environ), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    digest = hashlib.sha256()
    for block in iter(lambda: process.stdout.read(1024 * 1024), b''):
        digest.update(block)
    process.stdout.close()
    process.stderr.read()
    process.stderr.close()
    if process.wait():
        raise RuntimeError('Local committed blob verification failed')
    return digest.hexdigest()


def commit_sha(text):
    value = text.strip()
    if not COMMIT_RE.fullmatch(value):
        raise ValueError('Exact SHA-1 commit identity required')
    return value


def verify_index(git, checkout, files):
    observed = set()
    for entry in git('ls-files', '--stage', '-z', '--', *sorted(files)).stdout.split('\0'):
        if not entry:
            continue
        metadata, name = entry.split('\t', 1)
        mode, oid, stage = metadata.split()
        if name in observed or mode != '100644' or stage != '0' or not COMMIT_RE.fullmatch(oid):
            raise ValueError('Only unique regular scoped staged blobs allowed')
        observed.add(name)
    if observed != set(files):
        raise ValueError('Staged paths differ from the exact concrete reviewed union')
    if any(git_blob_sha(checkout, ':' + name) != digest for name, digest in files.items()):
        raise ValueError('Staged Git bytes differ from independently reviewed artifacts')


def verify_tree(git, checkout, revision, files):
    observed = set()
    for entry in git('ls-tree', '-z', revision, '--', *sorted(files)).stdout.split('\0'):
        if not entry:
            continue
        metadata, name = entry.split('\t', 1)
        mode, kind, oid = metadata.split()
        if name in observed or mode != '100644' or kind != 'blob' or not COMMIT_RE.fullmatch(oid):
            raise ValueError('Only unique regular scoped committed blobs allowed')
        observed.add(name)
    if observed != set(files):
        raise ValueError('Committed artifact union differs from exact review')
    if any(git_blob_sha(checkout, revision + ':' + name) != digest for name, digest in files.items()):
        raise ValueError('Committed artifact bytes differ')


def publish(manifest_sha, review_path, review_sha):
    no_prior_attempt()
    manifest = assemble.check(c.HERE / 'manifest.json', manifest_sha)
    validate_review(review_path, review_sha, manifest, manifest_sha)
    verify_helpers(manifest)
    with exclusive_lock(c.ROOT / '.local/catalog_report_generation.lock'):
        with exclusive_lock(c.ROOT / '.local/evaluation_publication.lock'):
            no_prior_attempt()
            manifest = assemble.check(c.HERE / 'manifest.json', manifest_sha)
            validate_review(review_path, review_sha, manifest, manifest_sha)
            verify_helpers(manifest)
            c.write_json(c.HERE / 'attempt_started.json', {'at_pacific': c.stamp(), 'pair_id': c.PAIR_ID,
                'manifest_sha256': manifest_sha, 'independent_review_sha256': review_sha,
                'new_model_calls': 0, 'automatic_retry': False})
            helper = c.load('p21_domains11_git_helper', c.GIT_HELPER)
            confirm_destination(helper)
            helper.ENV = git_environment(getattr(helper, 'ENV', os.environ))
            files = manifest['files_sha256']
            paths = sorted(files)
            with tempfile.TemporaryDirectory(prefix='p21-domains11-publication-') as directory:
                checkout = Path(directory)
                def git(*args):
                    return helper.git(*args, cwd=checkout)
                git('init', '--quiet')
                git('remote', 'add', 'origin', c.URL)
                git('config', 'core.hooksPath', os.devnull)
                git('config', 'core.autocrlf', 'false')
                git('config', 'remote.origin.promisor', 'true')
                git('config', 'remote.origin.partialclonefilter', 'blob:none')
                git('sparse-checkout', 'init', '--no-cone')
                git('sparse-checkout', 'set', '--no-cone', *('/' + name for name in paths))
                git('fetch', '--filter=blob:none', '--depth=1', 'origin', 'main')
                before = commit_sha(git('rev-parse', 'FETCH_HEAD').stdout)
                git('checkout', '--detach', 'FETCH_HEAD')
                git('config', 'user.name', 'Codex')
                git('config', 'user.email', 'codex@localhost')
                for name in paths:
                    data = c.regular_bytes(c.HERE / 'stage' / name)
                    if c.digest(data) != files[name] or len(data) >= c.MAX_GIT_BYTES:
                        raise ValueError('Exact staged artifact changed or exceeds bounded Git size')
                    c.write_checkout_file(checkout, name, data)
                git('add', '-f', '--sparse', '--', *paths)
                changed = set(git('diff', '--cached', '--name-only').stdout.splitlines())
                if not changed or not changed <= set(files):
                    raise ValueError('Unexpected staged paths or identical prior publication requires review')
                verify_index(git, checkout, files)
                git('diff', '--cached', '--check', '--', *paths)
                git('commit', '--no-gpg-sign', '--no-verify', '-m',
                    'Publish PFArena T3 eleven-assay Qwen result and sealed trajectories')
                commit = commit_sha(git('rev-parse', 'HEAD').stdout)
                verify_tree(git, checkout, commit, files)
                if set(git('diff', '--name-only', before, commit).stdout.splitlines()) != changed:
                    raise ValueError('Committed paths differ from reviewed staged changes')
                confirm_destination(helper)
                publication_stops()
                c.write_json(c.HERE / 'push_intent.json', {'at_pacific': c.stamp(), 'pair_id': c.PAIR_ID,
                    'previous_main_head': before, 'commit_sha': commit, 'manifest_sha256': manifest_sha,
                    'paths_sha256': files, 'automatic_retry': False})
                publication_stops()
                git('push', 'origin', 'HEAD:refs/heads/main')
                git('fetch', '--filter=blob:none', 'origin', 'main')
                head = commit_sha(git('rev-parse', 'FETCH_HEAD').stdout)
                git('merge-base', '--is-ancestor', commit, head)
                verify_tree(git, checkout, commit, files)
                verify_tree(git, checkout, head, files)
                receipt = {'at_pacific': c.stamp(), 'stage': 'published', 'pair_id': c.PAIR_ID,
                    'repository': c.REPOSITORY, 'visibility': 'public', 'push_permission_verified': True,
                    'previous_main_head': before, 'commit_sha': commit, 'verified_remote_main_head': head,
                    'remote_bytes_verified': True, 'published_path_count': len(paths), 'paths_sha256': files,
                    'manifest_sha256': manifest_sha, 'independent_review_sha256': review_sha,
                    'plan_sha256': c.PLAN_SHA, 'reviewed_assays': 11, 'native_panel_assays': 67,
                    'model_weights_environments_credentials_private_GPU_metadata_published': False,
                    'local_native_T3_metric_adaptation': True, 'native_author_benchmark_score': False,
                    'experimental_biological_validation_claimed': False,
                    'full_native67_complete': False, 'prior13_pooled': False,
                    'protected_reference_rows_included': False,
                    'shared_aggregate_reports_modified': False, 'website_or_schedule_changed': False,
                    'new_model_calls': 0, 'new_scoring_attempts': 0, 'automatic_retry': False}
                for name, expected in files.items():
                    target = c.ROOT / name
                    if os.path.lexists(target):
                        if c.sha(target) != expected:raise ValueError('Existing local public path differs; preserve it')
                    else:
                        c.write_bytes(target, c.regular_bytes(c.HERE / 'stage' / name))
                receipt['local_root_copy_bytes_verified'] = True
                c.write_json(c.HERE / 'publication_receipt.json', receipt)
                return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--publish', action='store_true')
    parser.add_argument('--review', type=Path)
    parser.add_argument('--review-sha256')
    args = parser.parse_args(argv)
    if args.publish:
        result = publish(args.manifest_sha256, args.review, args.review_sha256)
        print(json.dumps({key: result[key] for key in ('stage', 'commit_sha', 'published_path_count', 'remote_bytes_verified')}))
    else:
        manifest = assemble.check(c.HERE / 'manifest.json', args.manifest_sha256)
        print(json.dumps({'stage': 'offline_closed_P21_package_checks_passed', 'public_paths': len(manifest['files_sha256']),
                          'published': False, 'network_calls': 0, 'model_calls': 0}))


if __name__ == '__main__':
    main()
