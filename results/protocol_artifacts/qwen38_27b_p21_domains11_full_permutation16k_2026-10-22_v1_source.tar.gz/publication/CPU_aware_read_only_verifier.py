"""Read-only verification of sealed P21 generation plus first native CPU score.

The original GPU allocation remains FAILED1:0. No original terminal record is
created/replaced; the successful CPU score has separate exact provenance.
"""
from pathlib import Path
import argparse
import json
import sys
HERE = Path(__file__).resolve().parent
OP = HERE.parent
sys.path.insert(0, str(OP))
import controls

CPU_CONFIG_SHA = 'edbf8c5ead66bd4630770de8cdb54323ae7d8801a7f97a4d4e2c635c14caf712'
CPU_ADMISSION_SHA = 'e3eeaa9acaa38eb58496e6771eb207f992f5ef9edda34a2c09de49b0dfe047e1'
CPU_SOURCE_SHA = 'aa9442012c7d92ed1151bb59ff9c428a613dc297db925b85491be8e0bcb2797b'
PRIOR_VERIFIER_SHA = 'e4c500c1976fd654affbf15c81258978506993fc7acdd2d6b862ed1d1855aeaa'
PROOF_SHA = 'e0c8d0b6439b46ba59892ba599c98b5303968f75d579a7abb908b53d528a00a3'


def validate_CPU_completion(done, attempt, native_claim, score_sha, lock_sha):
    if (done.get('role') != 'P21_first_native_CPU_score_completed'
            or done.get('config_sha256') != CPU_CONFIG_SHA
            or done.get('independent_admission_sha256') != CPU_ADMISSION_SHA
            or done.get('zero_native_score_proof_sha256') != PROOF_SHA
            or done.get('original_GPU_job_id') != '249787'
            or done.get('original_GPU_scheduler_state') != 'FAILED'
            or done.get('original_GPU_exit_code') != '1:0'
            or done.get('old_worker_status_and_intent_preserved') is not True
            or done.get('score_sha256') != score_sha or done.get('planned_assays') != 11
            or done.get('native_panel_assays') != 67 or done.get('full_native67_complete') is not False
            or done.get('benchmark_prediction_lock_sha256') != lock_sha
            or type(done.get('native_function_entries')) is not int or done['native_function_entries'] != 1
            or done.get('new_model_calls') != 0 or done.get('new_GPU_allocations') != 0):
        raise ValueError('Exact first-native CPU completion and true failed-GPU provenance required')
    if (attempt.get('config_sha256') != CPU_CONFIG_SHA
            or attempt.get('independent_admission_sha256') != CPU_ADMISSION_SHA
            or attempt.get('zero_native_score_proof_sha256') != PROOF_SHA
            or attempt.get('benchmark_prediction_lock_sha256') != lock_sha
            or attempt.get('first_native_function_entry_once_only') is not True
            or native_claim.get('sole_native_scoring_attempt') is not True
            or native_claim.get('prediction_lock_sha256') != lock_sha):
        raise ValueError('Durable first-native CPU/native claims must bind the exact full seal')


def verify(manifest_sha, admission_sha, score_sha):
    controls.validate(manifest_sha, admission_sha)
    cpu_root = OP / 'first_native_CPU_score_v2'
    source = cpu_root / 'score_once.py';controls.regular(source, CPU_SOURCE_SHA)
    cpu = controls.load('p21_reviewed_first_native_CPU_metadata_only', source)
    _, proof = cpu.authority(CPU_CONFIG_SHA, CPU_ADMISSION_SHA)
    cpu.unchanged(proof)  # only exact hashes/membership and actual FAILED sacct.
    prior_source = OP / 'publication_v2/verify_result.py'
    controls.regular(prior_source, PRIOR_VERIFIER_SHA)
    prior = controls.load('p21_accepted_eight_test_summary_guards', prior_source)
    root = controls.OLD / 'runtime'
    dev = controls.read(root / 'development/completion.json')
    bench = controls.read(root / 'benchmark/completion.json')
    hashes = {phase: proof['phase_evidence'][phase]['prediction_lock_sha256'] for phase in ('development', 'benchmark')}
    score_path = root / 'benchmark/scores.json';controls.regular(score_path, score_sha)
    score = controls.read(score_path)
    if (score.get('configuration_sha256') != controls.sha(controls.OLD / 'benchmark_config.json')
            or score.get('scorer_manifest_sha256') != controls.sha(controls.OLD / 'scorer_only_manifest.json')):
        raise ValueError('First native score is not bound to exact unchanged configuration/reference manifest')
    done = controls.read(cpu_root / 'completion.json')
    attempt = controls.read(cpu_root / 'native_entry_attempt.json')
    native_claim_path = root / 'benchmark/native_scoring_attempt.json'
    native_claim = controls.read(native_claim_path)
    validate_CPU_completion(done, attempt, native_claim, score_sha, hashes['benchmark'])
    if done['native_claim_sha256'] != controls.sha(native_claim_path):
        raise ValueError('Actual native claim differs from CPU completion')
    # Reuse accepted pure summary invariants. This is an explicitly derived
    # condition summary, never a fabricated/replacement original GPU receipt.
    derived = {'reviewed11_condition_terminal': True, 'native_score_sha256': score_sha,
        'prediction_lock_sha256': hashes['benchmark'], 'native_scoring_status': done['native_scoring_status'],
        'full_native67_complete': False, 'derived_from_separate_CPU_completion': True}
    prior.validate_summaries(dev, bench, score, derived, controls.read(root / 'server_terminal.json'), hashes, score_sha)
    if (root / 'terminal_receipt.json').exists():
        raise ValueError('Preserve the absent original successful-GPU receipt; do not fabricate one')
    evidence = {**proof['files_sha256'], **proof['sealed_member_hashes']}
    for path in (cpu_root / 'config.json', cpu_root / 'independent_admission.json', source,
                 cpu_root / 'completion.json', cpu_root / 'native_entry_attempt.json', native_claim_path, score_path):
        evidence[str(path)] = controls.sha(path)
    if evidence[str(score_path)] != score_sha:raise ValueError('Exact saved score drifted during verification')
    return {'role': 'read_only_P21_complete_generation_first_native_CPU_score_verification',
        'original_GPU_job_id': '249787', 'original_GPU_scheduler_state': 'FAILED', 'original_GPU_exit_code': '1:0',
        'CPU_native_score_completed': True, 'native_function_entries': 1,
        'manifest_sha256': manifest_sha, 'independent_admission_sha256': admission_sha,
        'original_plan_sha256': controls.PLAN_SHA, 'score_sha256': score_sha,
        'planned_assays': 11, 'native_panel_assays': 67, 'full_native67_complete': False,
        'native_scoring_status': score['native_scoring_status'], 'native_metrics': score['native_metrics'],
        'benchmark_completion': bench, 'evidence_sha256': evidence,
        'reference_bodies_parsed': False, 'new_model_or_scorer_calls': 0, 'publication_authorized': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-sha256', required=True);parser.add_argument('--admission-sha256', required=True)
    parser.add_argument('--score-sha256', required=True)
    args = parser.parse_args();print(json.dumps(verify(args.manifest_sha256, args.admission_sha256, args.score_sha256), indent=2))
