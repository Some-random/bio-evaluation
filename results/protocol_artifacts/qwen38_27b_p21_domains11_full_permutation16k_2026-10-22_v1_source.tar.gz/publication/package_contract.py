"""Exact P21 CPU package: four public files, no biological reference rows."""
from pathlib import Path
import hashlib
import importlib.util
import io
import json
import os
import sys
import tarfile

HERE = Path(__file__).resolve().parent
OP = HERE.parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
OLD = OP.parent / 'available_execution_domains11_v1'
REPOSITORY = 'Some-random/bio-evaluation'
URL = 'https://github.com/' + REPOSITORY + '.git'
PAIR_ID = 'qwen38_27b_p21_domains11_full_permutation16k_2026-10-22_v1'
PREFIX = 'results/runs/' + PAIR_ID + '/'
SCORE = PREFIX + 'scores.json'
REPORT = PREFIX + 'README.md'
ARCHIVE = 'results/trajectory_archives/' + PAIR_ID + '.tar.gz'
SOURCE = 'results/protocol_artifacts/' + PAIR_ID + '_source.tar.gz'
ALLOWED = frozenset((SCORE, REPORT, ARCHIVE, SOURCE))
PLAN_SHA = '7ecfc37c177eaaa942b3144a29fb71ac3704f1e632ff0b622447e8178a7f1f5a'
AUTH_SHA = '765f4999008e281eb03879a100fa282d3b35a0c10c8dfb9459aa669301a84945'
OP_SHA = '063628ff36f8fb130e6cbdfe7e1ae59ffb55b1786677edaa72e835140efff347'
ADMISSION_SHA = 'c020ee67f31675c999b261f8a51fd297a898390db0176349752a0e19d735344d'
MAX_GIT_BYTES = 90 * 1024**2
GIT_HELPER = ROOT / '.local/litqa2_replay/incremental_upload.py'
CREDENTIAL_HELPER = ROOT / '.local/litqa2_replay/github_credential_helper.py'
DESTINATION_POLICY = ROOT / 'scripts/publication_destination.py'
SCANNER = ROOT / 'scripts/daily_backup.py'
COMMON = ROOT / '.local/qwen35_4b_comparison_20261022/protein_properties/scalar_delivery_development_v3/restore_20261024_v1/publication/bundle_common.py'
COMMON_SHA = '6839105aadf3d6377e631998952430b62248f62c79aaa5d333d5faa4df734f41'
if COMMON.is_symlink() or hashlib.sha256(COMMON.read_bytes()).hexdigest() != COMMON_SHA:
    raise ValueError('Pinned filesystem primitives changed')
_spec = importlib.util.spec_from_file_location('p21_pinned_filesystem_primitives', COMMON)
_fs = importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_fs)
for _name in ('stamp', 'sha', 'digest', 'read', 'regular_bytes', 'write_bytes',
              'write_json', 'load', 'safe_name', 'write_checkout_file'):
    globals()[_name] = getattr(_fs, _name)


def source_check():
    if sys.flags.optimize:raise PermissionError('Optimized publication checks forbidden')
    cfg = read(HERE / 'config.json')
    if (cfg.get('role') != 'P21_domains11_exact_four_path_CPU_publication_source'
            or cfg.get('operational_manifest_sha256') != OP_SHA
            or cfg.get('root_adoption_sha256') != AUTH_SHA
            or cfg.get('original_plan_sha256') != PLAN_SHA
            or set(cfg.get('allowed_paths', [])) != ALLOWED
            or cfg.get('planned_assays') != 11 or cfg.get('native_panel_assays') != 67):
        raise ValueError('Exact adopted eleven-case publication scope required')
    for path, expected in cfg['files_sha256'].items():
        if sha(path) != expected:raise ValueError('Pinned package/source support changed')
    review = read(HERE / 'independent_source_review.json')
    if (review.get('reviewer') not in {'/root', '/root/independent_review'}
            or review.get('approved') is not True
            or review.get('role') != 'independent_P21_four_path_publication_source_review'
            or review.get('config_sha256') != sha(HERE / 'config.json')
            or review.get('files_sha256') != cfg['files_sha256']):
        raise PermissionError('Exact independent source review required')
    if os.path.lexists(HERE / 'STOP'):raise PermissionError('Publication STOP is active')
    return cfg


def complete_review(score_sha):
    review_path = HERE / 'independent_complete_result_review.json'
    review = read(review_path)
    if (review.get('reviewer') not in {'/root', '/root/independent_review'}
            or review.get('approved') is not True
            or review.get('role') != 'independent_P21_complete_result_local_packaging_only'
            or review.get('config_sha256') != sha(HERE / 'config.json')
            or review.get('operational_manifest_sha256') != OP_SHA
            or review.get('score_sha256') != score_sha
            or review.get('planned_assays') != 11 or review.get('synthetic_checks_passed') != 3
            or review.get('full_native67_complete') is not False):
        raise PermissionError('Exact completed eleven-case result review required')
    return review_path


def verify_result(score_sha):
    cfg = source_check()
    verifier_path = OP / 'publication_v3/verify_result.py'
    verifier = load('p21_accepted_read_only_result_verifier', verifier_path)
    return verifier.verify(OP_SHA, ADMISSION_SHA, score_sha)


def captured(path, expected, snapshots):
    path = Path(path)
    if str(path) in snapshots and snapshots[str(path)] != expected:
        raise ValueError('A previously reviewed snapshot expectation cannot be rebound')
    data = regular_bytes(path)
    if digest(data) != expected:raise ValueError('Exact captured source/member bytes changed')
    snapshots[str(path)] = expected
    return data


def recheck(snapshots):
    for path, expected in snapshots.items():
        if sha(path) != expected:raise ValueError('Original source/member changed during packaging')


def tar_bytes(members):
    target = io.BytesIO()
    with tarfile.open(fileobj=target, mode='w:gz') as archive:
        for name, data in sorted(members.items()):
            safe_name(name)
            item = tarfile.TarInfo(name);item.size = len(data);item.mode = 0o644;item.mtime = 0
            archive.addfile(item, io.BytesIO(data))
    value = target.getvalue()
    observed = {}
    with tarfile.open(fileobj=io.BytesIO(value), mode='r:gz') as archive:
        for member in archive:
            if not member.isfile() or member.name in observed:raise ValueError('Unsafe/duplicate archived member')
            observed[member.name] = digest(archive.extractfile(member).read())
    if observed != {k: digest(v) for k, v in members.items()}:
        raise ValueError('Actual archived payload differs from captured source bytes')
    return value


def report(score):
    metrics = score['native_metrics']
    values = ['undefined'] * 4 if metrics is None else [format(metrics[k], '.6f') for k in ('spearman', 'NDCG', 'NMS@5', 'Recall@5')]
    return ('# PFArena T3: eleven additional domain-stability assays\n\n'
        '| Model | Spearman | NDCG | NMS@5 | Recall@5 | Assays |\n'
        '|---|---:|---:|---:|---:|---:|\n'
        '| Qwen3.8-27B | ' + ' | '.join(values) + ' | 11/67 |\n\n'
        'The task asked the model to rank all supplied candidates for eleven independently reviewed ordinary isolated-domain stability assays. '
        'Three artificial delivery checks passed before benchmark dispatch. This separately attempted cohort is disjoint from '
        'the earlier eight- and five-assay results; no pooled metric is reported. The remaining 43 assays are outside this condition.\n\n'
        'The declared single-shot baseline retained native messages, legitimate measured anchors, the full candidate permutation '
        'and the four native metric formulas. It used pinned original BF16 Qwen3.8-27B, nonthinking, 16,384 output tokens and a mandatory '
        'full-permutation JSON constraint preserving every ranking order. Candidate outcome measurements remained scorer-only. '
        'This is retrospective agreement with existing measurements, not experimental validation or a matched tool-using paper result. '
        'Public pretraining exposure is unknown. GPT models were not evaluated for this cohort.\n\n'
        f"Native scoring status: `{score['native_scoring_status']}`. Transport/response errors: {score['transport_or_response_errors']}; "
        f"empty finals: {score['empty_finals']}; truncations: {score['truncations']}. All eleven cases remain in scope; undefined metrics are not replaced.\n\n"
        f'- [Exact saved native score](scores.json)\n- [Sealed requests, responses and metadata](../../trajectory_archives/{PAIR_ID}.tar.gz)\n'
        f'- [Execution code and pinned upstream source references](../../protocol_artifacts/{PAIR_ID}_source.tar.gz)\n').encode()


def check(path, expected):
    if sha(path) != expected:raise ValueError('Exact publication manifest changed')
    manifest = read(path);cfg = source_check()
    if (manifest.get('task_id') != 'P21' or manifest.get('config_sha256') != sha(HERE / 'config.json')
            or set(manifest.get('files_sha256', {})) != ALLOWED
            or manifest.get('repository') != REPOSITORY or manifest.get('visibility') != 'public'
            or manifest.get('planned_assays') != 11 or manifest.get('native_panel_assays') != 67
            or manifest.get('full_native67_complete') is not False or manifest.get('prior13_pooled') is not False):
        raise ValueError('Only the exact four-path eleven-case candidate is supported')
    complete_review(manifest['score_sha256'])
    if manifest['complete_result_review_sha256'] != sha(HERE / 'independent_complete_result_review.json'):
        raise ValueError('Completed result review changed')
    recheck(manifest['captured_private_sources_sha256'])
    scanner = load('p21_exact_candidate_scanner', SCANNER)
    private = read(ROOT / '.local/priority_results_20261023/private_reporting/root_thread_binding.json')['thread'].encode()
    for name, expected in manifest['files_sha256'].items():
        data = regular_bytes(HERE / 'stage' / name)
        if digest(data) != expected or private in data or len(data) >= MAX_GIT_BYTES:
            raise ValueError('Public artifact bytes/privacy/size changed')
        scanner.scan_file(HERE / 'stage' / name)
        if name.endswith('.tar.gz'):
            observed = {}
            with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
                for member in archive:
                    safe_name(member.name)
                    if not member.isfile() or member.name in observed:raise ValueError('Unsafe/duplicate actual archive member')
                    body = archive.extractfile(member).read()
                    if private in body:raise ValueError('Private conversation identifier in archive')
                    observed[member.name] = digest(body)
            if observed != manifest['archive_members_sha256'][name]:raise ValueError('Exact archive member lineage changed')
    if sha(HERE / 'stage' / SCORE) != manifest['score_sha256']:
        raise ValueError('Published score is not the reviewed saved score')
    return manifest
