"""Once-only bounded-memory packaging after exact P21 completed-result review."""
import argparse
import json
import os
import package_contract as c


def package(score_sha):
    cfg = c.source_check();review_path = c.complete_review(score_sha)
    evidence = c.verify_result(score_sha)
    if any(os.path.lexists(c.HERE / n) for n in ('stage', 'manifest.json', 'package_attempt.json')):
        raise FileExistsError('Preserve any prior packaging claim/partial candidate')
    c.write_json(c.HERE / 'package_attempt.json', {'at_pacific': c.stamp(),
        'score_sha256': score_sha, 'config_sha256': c.sha(c.HERE / 'config.json'),
        'complete_result_review_sha256': c.sha(review_path), 'new_model_or_score_calls': 0})
    snapshots = {**cfg['files_sha256'], **evidence['evidence_sha256']}
    for path in (c.HERE / 'config.json', c.HERE / 'independent_source_review.json', review_path):
        snapshots[str(path)] = c.sha(path)
    raw = {};sources = {}
    for phase in ('development', 'benchmark'):
        run = c.OLD / 'runtime' / phase
        seal_path = run / 'prediction_lock.json'
        seal = json.loads(c.captured(seal_path, evidence['evidence_sha256'][str(seal_path)], snapshots))
        for name, expected in seal['files_sha256'].items():
            raw[phase + '/' + name] = c.captured(run / name, expected, snapshots)
        for name in ('prediction_lock.json', 'completion.json'):
            path = run / name
            raw[phase + '/' + name] = c.captured(path, evidence['evidence_sha256'][str(path)], snapshots)
    score_path = c.OLD / 'runtime/benchmark/scores.json'
    score_body = c.captured(score_path, score_sha, snapshots);score = json.loads(score_body)
    raw['benchmark/scores.json'] = score_body
    raw['execution_provenance.json'] = (json.dumps({
        'original_GPU_job_id': evidence['original_GPU_job_id'],
        'original_GPU_scheduler_state': evidence['original_GPU_scheduler_state'],
        'original_GPU_exit_code': evidence['original_GPU_exit_code'],
        'complete_generation_preserved': True, 'synthetic_checks_passed': 3,
        'benchmark_cases_sealed': 11, 'CPU_first_native_score_completed': True,
        'native_function_entries': 1, 'new_generation_or_model_calls_by_CPU_recovery': 0,
        'original_plan_sha256': c.PLAN_SHA, 'operational_manifest_sha256': c.OP_SHA,
        'score_sha256': score_sha, 'protected_reference_tables_published': False,
        'private_resource_proof_bodies_published': False}, indent=2, sort_keys=True) + '\n').encode()
    for name, path in cfg['public_source_members'].items():
        sources[name] = c.captured(path, cfg['files_sha256'][path], snapshots)
    # Upstream source bodies/weights/reference tables and private resource proofs
    # are omitted; exact local content hashes and public source links are supplied.
    sources['UPSTREAM_SOURCE_REFERENCES.json'] = (json.dumps(cfg['upstream_references'], indent=2, sort_keys=True) + '\n').encode()
    sources['SOURCE_SCOPE.md'] = b'Exact project execution/scoring wrappers are included. Third-party implementation bodies, weights, environments, protected reference tables and private resource proof bodies are omitted; pinned public upstream source links and local SHA-256 identities are provided. No new license is assigned to upstream content.\n'
    def add_manifest(members):
        manifest = {name: {'sha256': c.digest(data), 'bytes': len(data)} for name, data in members.items()}
        members['MEMBER_MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    add_manifest(raw);add_manifest(sources)
    if sum(len(v) for v in [*raw.values(), *sources.values()]) > 64 * 1024**2:
        raise ValueError('Explicit bounded-memory package size exceeded')
    private = c.read(c.ROOT / '.local/priority_results_20261023/private_reporting/root_thread_binding.json')['thread'].encode()
    scanner = c.load('p21_captured_payload_scanner', c.SCANNER)
    for data in [*raw.values(), *sources.values(), score_body]:
        scanner.scan_bytes(data)
        if private in data:raise ValueError('Private conversation identifier in captured bytes')
    bodies = {c.SCORE: score_body, c.REPORT: c.report(score),
              c.ARCHIVE: c.tar_bytes(raw), c.SOURCE: c.tar_bytes(sources)}
    c.recheck(snapshots);c.source_check();c.complete_review(score_sha)
    stage = c.HERE / 'stage';stage.mkdir()
    for name, data in bodies.items():
        c.write_bytes(stage / name, data)
    c.recheck(snapshots);c.source_check();c.complete_review(score_sha)
    manifest = {'at_pacific': c.stamp(), 'role': 'offline_exact_four_path_P21_candidate_not_published',
        'task_id': 'P21', 'repository': c.REPOSITORY, 'visibility': 'public',
        'config_sha256': c.sha(c.HERE / 'config.json'), 'score_sha256': score_sha,
        'complete_result_review_sha256': c.sha(review_path), 'planned_assays': 11, 'native_panel_assays': 67,
        'full_native67_complete': False, 'prior13_pooled': False,
        'files_sha256': {name: c.digest(data) for name, data in bodies.items()},
        'archive_members_sha256': {c.ARCHIVE: {k: c.digest(v) for k, v in raw.items()},
                                  c.SOURCE: {k: c.digest(v) for k, v in sources.items()}},
        'source_files_sha256': cfg['files_sha256'], 'captured_private_sources_sha256': snapshots,
        'read_only_verification': evidence, 'new_model_or_scorer_calls': 0,
        'weights_environments_reference_tables_private_resource_proofs_included': False}
    c.write_json(c.HERE / 'manifest.json', manifest)
    c.check(c.HERE / 'manifest.json', c.sha(c.HERE / 'manifest.json'))
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__);parser.add_argument('--score-sha256', required=True)
    args = parser.parse_args();result = package(args.score_sha256)
    print(json.dumps({'stage': 'offline_candidate', 'public_paths': len(result['files_sha256']), 'published': False}))
