"""Exact current P21 authority/resource/once-submission guards; no science changes."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import socket
import stat
import time
from durable_io import durable_json

HERE = Path(__file__).resolve().parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
OLD = HERE.parent / 'available_execution_domains11_v1'
PLAN_SHA = '7ecfc37c177eaaa942b3144a29fb71ac3704f1e632ff0b622447e8178a7f1f5a'
ADOPTION = ROOT / '.local/goal_restore_20261024/P21_domains11_exact_scientific_adoption_and_release.json'
ADOPTION_SHA = '765f4999008e281eb03879a100fa282d3b35a0c10c8dfb9459aa669301a84945'
SHARED = ROOT / '.local/goal_restore_20261024/shared_resource_binding.json'
SHARED_SHA = 'cb881370f7dac295d7d153f72baddcbf604c0fce0cc651ee82c557e5efcad6f9'
OWNER = '/root/p37_offline_repair'
CONDITION = 'PFARENA_T3_ADDITIONAL_ORDINARY_DOMAIN_STABILITY11_FULL_PERMUTATION_V1'


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def regular(path, digest):
    path = Path(path)
    if path.is_symlink() or path != path.resolve() or not path.is_file() or sha(path) != digest:
        raise ValueError('Exact regular admitted source/evidence changed: ' + path.name)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require_capacity(value, addition):
    before, after = value.get('project_requested_GPUs'), value.get('project_requested_GPUs_with_addition')
    if (type(before) is not int or type(after) is not int or before < 0
            or type(value.get('additional_GPUs')) is not int or value['additional_GPUs'] != addition
            or after != before + addition or after > 8 or value.get('project_GPU_ceiling') != 8
            or value.get('capacity_available') is not True):
        raise ValueError('Fresh exact shared project GPU bound exceeded or malformed')
    return value


def independent_grant(grant, manifest_sha):
    if (grant.get('reviewer') not in {'/root', '/root/independent_review'}
            or grant.get('reviewer') == OWNER or grant.get('approved') is not True
            or grant.get('role') != 'independent_P21_current_operational_runtime_admission'
            or grant.get('manifest_sha256') != manifest_sha
            or grant.get('original_plan_sha256') != PLAN_SHA
            or grant.get('root_adoption_sha256') != ADOPTION_SHA
            or grant.get('shared_resource_binding_sha256') != SHARED_SHA
            or grant.get('scientific_scope_unchanged') is not True
            or grant.get('one_allocation_only') is not True
            or grant.get('old_priority_disable_preserved_and_superseded_for_exact11') is not True):
        raise PermissionError('New owner cannot self-admit; exact independent runtime/priority clearance required')
    return grant


def require_no_STOP():
    if os.path.lexists(HERE / 'STOP'):
        raise PermissionError('Current explicit scheduling STOP is active')


def validate(manifest_sha, admission_sha, *, job=False):
    regular(HERE / 'manifest.json', manifest_sha)
    manifest = read(HERE / 'manifest.json')
    regular(ADOPTION, ADOPTION_SHA)
    adopted = read(ADOPTION)
    if (adopted.get('approved') is not True or adopted.get('scientific_adopted') is not True
            or adopted.get('owner') != OWNER or adopted.get('condition') != CONDITION
            or adopted.get('frozen_plan_sha256') != PLAN_SHA
            or adopted.get('implementation_and_runtime_reviewer') != '/root/independent_review'):
        raise PermissionError('Exact root-adopted eleven-case scope and new owner required')
    if (manifest.get('role') != 'P21_domains11_additive_operational_amendment'
            or manifest.get('original_plan_sha256') != PLAN_SHA
            or manifest.get('root_adoption_sha256') != ADOPTION_SHA
            or manifest.get('scientific_files_unchanged') is not True
            or manifest.get('gpus_requested') != 1 or manifest.get('project_GPU_ceiling') != 8
            or manifest.get('new_scientific_or_case_permission') is not False):
        raise PermissionError('Exact unchanged-science operational manifest required')
    regular(OLD / 'plan.json', PLAN_SHA)
    original = read(OLD / 'plan.json')
    if manifest['original_files_sha256'] != original['frozen_files_sha256']:
        raise ValueError('All original 105 dependency pins must remain intact')
    for path, digest in {**manifest['original_files_sha256'], **manifest['files_sha256']}.items():
        regular(path, digest)
    regular(SHARED, SHARED_SHA)
    shared = read(SHARED)
    if (shared.get('role') != 'shared_resource_configuration_only_no_dispatch_authority'
            or shared.get('approved') is not True or shared.get('reviewer') != '/root/priority_runtime_review'
            or shared.get('project_GPU_ceiling') != 8
            or manifest.get('shared_resource_binding_sha256') != SHARED_SHA):
        raise PermissionError('Exact shared resource CONFIGURATION required, separate from new dispatch authority')
    for ref in [shared['resource_adapter'], shared['additional_proof_binding'], *shared['additional_root_proofs']]:
        regular(ref['path'], ref['sha256'])
    regular(HERE / 'independent_admission.json', admission_sha)
    grant = read(HERE / 'independent_admission.json')
    independent_grant(grant, manifest_sha)
    require_no_STOP()
    if job:
        verify_submission(manifest_sha, admission_sha)
    return manifest, grant, shared


def expected_command(manifest_sha, admission_sha, runtime_admission_sha):
    return ['sbatch', '--parsable', '--export=NONE', '--no-requeue', str(HERE / 'worker.sbatch'),
            manifest_sha, admission_sha, runtime_admission_sha]


def verify_submission(manifest_sha, admission_sha):
    job = os.environ.get('SLURM_JOB_ID', '')
    if not re.fullmatch(r'[0-9]{1,20}', job):
        raise PermissionError('Actual owned Slurm allocation required')
    deadline = time.monotonic() + 60
    while True:
        try:
            receipt = read(HERE / 'submission_receipt.json')
            break
        except (FileNotFoundError, json.JSONDecodeError):
            if time.monotonic() >= deadline:
                raise PermissionError('Exact once-submission receipt not durably finalized')
            time.sleep(.2)
    dynamic = HERE / 'runtime_admission.json'
    if (receipt.get('job_id') != job or receipt.get('manifest_sha256') != manifest_sha
            or receipt.get('independent_admission_sha256') != admission_sha
            or receipt.get('runtime_admission_sha256') != sha(dynamic)
            or receipt.get('command') != expected_command(manifest_sha, admission_sha, sha(dynamic))):
        raise PermissionError('Actual own allocation differs from its once-only recorded command')
    value = read(dynamic)
    grant = read(HERE / 'independent_admission.json')
    if (value.get('issuer') != OWNER
            or value.get('role') != 'mechanical_P21_runtime_derivation_from_exact_independent_admission'
            or value.get('independent_reviewer') != grant['reviewer']
            or value.get('operational_manifest_sha256') != manifest_sha
            or value.get('operational_admission_sha256') != admission_sha
            or value.get('root_adoption_sha256') != ADOPTION_SHA):
        raise PermissionError('Exact independent scientific+operational runtime admission required')
    regular(value['gpu_audit_receipt'], value['gpu_audit_receipt_sha256'])
    return receipt


def capacity(manifest_sha, admission_sha, *, addition, own=False):
    manifest, grant, shared = validate(manifest_sha, admission_sha, job=own)
    adapter = load('p21_current_exact_shared_v5', shared['resource_adapter']['path'])
    value = adapter.capacity_audit(additional=addition, override=False, require_own_job=own,
        additional_root_proofs=shared['additional_root_proofs'],
        additional_proof_binding=shared['additional_proof_binding'])
    require_capacity(value, addition)
    if own:
        matches = [v for v in value['jobs'] if v['job_id'] == os.environ['SLURM_JOB_ID']]
        if (len(matches) != 1 or type(matches[0]['gpus']) is not int or matches[0]['gpus'] != 1
                or matches[0]['command'].split()[0] != str(HERE / 'worker.sbatch')
                or Path(matches[0]['workdir']).resolve() != ROOT
                or matches[0].get('counted_toward_evaluation_project') is not True):
            raise PermissionError('Exact current own one-GPU script/workdir must remain counted')
    return value


def ipc_preflight(local=None, env=None):
    longest = Path('/tmp') / ('bio-p21-' + '9' * 20 + '-' + 'x' * 8) / 'cache/tmp' / ('f' * 36)
    maximum = len(os.fsencode(longest))
    if maximum > 107 or Path('/tmp').resolve() != Path('/tmp'):
        raise ValueError('Deterministic maximum private IPC path is unsafe')
    result = {'maximum_socket_path_bytes': maximum, 'limit_bytes': 107, 'actual_bind_passed': False}
    if local is None:
        return result
    local = Path(local)
    if (local.parent != Path('/tmp') or local != local.resolve()
            or not re.fullmatch(r'bio-p21-[0-9]{1,20}-[a-z0-9_]{8}', local.name)):
        raise ValueError('Exact short local private runtime namespace required')
    observed = local.lstat()
    if (not stat.S_ISDIR(observed.st_mode) or observed.st_uid != os.getuid()
            or stat.S_IMODE(observed.st_mode) != 0o700):
        raise ValueError('Current local runtime owner/mode changed')
    temporary = local / 'cache/tmp'
    if (env.get('TMPDIR') != str(temporary)
            or env.get('VLLM_RPC_BASE_PATH', str(temporary)) != str(temporary)):
        raise ValueError('Actual IPC environment is not the reviewed short private root')
    target = temporary / ('f' * 36)
    if temporary != temporary.resolve() or not temporary.is_dir() or len(os.fsencode(target)) > maximum:
        raise ValueError('Actual private IPC directory changed')
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as probe:
        probe.bind(str(target))
        created = target.lstat()
        try:
            if not stat.S_ISSOCK(created.st_mode) or created.st_uid != os.getuid():
                raise ValueError('Owned IPC probe identity changed')
            result['actual_bind_passed'] = True
            result['actual_socket_path_bytes'] = len(os.fsencode(target))
        finally:
            current = target.lstat()
            if (current.st_dev, current.st_ino, current.st_uid) != (created.st_dev, created.st_ino, created.st_uid):
                raise ValueError('Same-host IPC inode changed before cleanup')
            target.unlink()
    return result
