"""Execute unchanged P21 sources with reviewed operational-only runtime hooks.

No native payload, parser, sampling or scoring function is transformed. The
outer source is separately pinned while original __file__/source hashes stay
at their exact historical scientific versions.
"""
from pathlib import Path
import argparse
import os
import sys
import tempfile
import controls
from durable_io import runtime_writes, durable_json

HERE, OLD = controls.HERE, controls.OLD


def redirect_subprocess(command, prefix, original):
    if isinstance(command, (tuple, list)) and len(command) >= 2:
        for mode in ('runner', 'scorer'):
            if str(command[1]) == str(OLD / (mode + '.py')):
                return [command[0], str(HERE / 'operational_entry.py'), *prefix, mode, '--', *command[2:]]
    return command


def run(mode, manifest_sha, admission_sha, runtime_sha, original_args):
    if sys.flags.optimize:
        raise PermissionError('Optimized execution is forbidden')
    controls.validate(manifest_sha, admission_sha, job=True)
    if controls.sha(HERE / 'runtime_admission.json') != runtime_sha:
        raise PermissionError('Exact once-derived runtime authority changed')
    sys.path.insert(0, str(OLD))
    runtime = OLD / 'runtime'
    # Original tempfile.mkdtemp and vLLM IPC paths must use short node-local /tmp.
    os.environ['TMPDIR'] = '/tmp' if '--runtime-dir' not in original_args else os.environ['TMPDIR']
    tempfile.tempdir = '/tmp'
    module = controls.load('p21_unchanged_scientific_' + mode, OLD / (mode + '.py'))
    if mode == 'worker':
        original_check = module.check_root_admission
        def current_check(path, expected, plan_sha, plan):
            controls.validate(manifest_sha, admission_sha, job=True)
            if (Path(path) != HERE / 'runtime_admission.json'
                    or expected != runtime_sha or plan_sha != controls.PLAN_SHA):
                raise PermissionError('Original worker admission must be exact current mechanical derivation')
            return original_check(path, expected, plan_sha, plan)
        module.check_root_admission = current_check
        module.project_gpu_audit = lambda plan: controls.capacity(manifest_sha, admission_sha, addition=0, own=True)
        original_activate = module.activate_private_runtime
        prefix = ['--manifest-sha256', manifest_sha, '--admission-sha256', admission_sha,
                  '--runtime-admission-sha256', runtime_sha]
        def private_activate(shared, common, local, result_root, argv, executor=None):
            def exact_exec(binary, command, environment):
                # Original activate creates cache/tmp and the isolated environment.
                proof = controls.ipc_preflight(local, environment)
                durable_json(HERE / 'bootstrap_IPC_preflight.json', proof)
                rewritten = [binary, str(HERE / 'operational_entry.py'), *prefix, 'worker', '--', *command[2:]]
                return (executor or os.execve)(binary, rewritten, environment)
            return original_activate(shared, common, local, result_root, argv, exact_exec)
        module.activate_private_runtime = private_activate
        original_run = module.subprocess.run
        def current_run(command, *args, **kwargs):
            return original_run(redirect_subprocess(command, prefix, original_run), *args, **kwargs)
        module.subprocess.run = current_run
        if '--runtime-dir' in original_args:
            position = original_args.index('--runtime-dir')
            local = Path(original_args[position + 1])
            proof = controls.ipc_preflight(local, os.environ)
            durable_json(HERE / 'private_exec_IPC_preflight.json', proof)
        else:
            controls.ipc_preflight()
    elif mode not in {'runner', 'scorer'}:
        raise ValueError('Only the exact unchanged worker/runner/scorer can execute')
    sys.argv = [str(OLD / (mode + '.py')), *original_args]
    with runtime_writes(runtime):
        module.main()


def arguments(argv):
    if '--' not in argv:
        raise ValueError('Unchanged original arguments require explicit delimiter')
    delimiter = argv.index('--')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--admission-sha256', required=True)
    parser.add_argument('--runtime-admission-sha256', required=True)
    parser.add_argument('mode', choices=['worker', 'runner', 'scorer'])
    args = parser.parse_args(argv[:delimiter])
    args.original_args = argv[delimiter + 1:]
    if not args.original_args:
        raise ValueError('Unchanged original arguments cannot be empty')
    return args


def main():
    args = arguments(sys.argv[1:])
    run(args.mode, args.manifest_sha256, args.admission_sha256,
        args.runtime_admission_sha256, args.original_args)


if __name__ == '__main__':
    main()
