"""One independently admitted P21 allocation; no retry of ambiguous sbatch."""
from pathlib import Path
import argparse
import fcntl
import json
import subprocess
import sys
from datetime import datetime
from zoneinfo import ZoneInfo
import controls
from durable_io import durable_json

HERE, OLD, ROOT = controls.HERE, controls.OLD, controls.ROOT


def stamp():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def submit(manifest_sha, admission_sha):
    if sys.flags.optimize:
        raise PermissionError('Optimized execution is forbidden')
    controls.validate(manifest_sha, admission_sha)
    lock_path = ROOT / '.local/evaluation_GPU_submission.lock'
    with lock_path.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        # Never use an authority or source observation made before waiting for lock.
        manifest, grant, shared = controls.validate(manifest_sha, admission_sha)
        if (HERE / 'submission_attempt.json').exists() or (HERE / 'submission_receipt.json').exists():
            raise PermissionError('Sole allocation already claimed; no ambiguous sbatch retry')
        if (OLD / 'runtime').exists():
            raise PermissionError('Original runtime already exists; preserve it for independent inspection')
        for name in ('runtime_admission.json', 'gpu_budget_before_submission.json'):
            if (HERE / name).exists():
                raise PermissionError('Earlier operational preparation exists; no automatic retry')
        ipc = controls.ipc_preflight()
        audit = controls.capacity(manifest_sha, admission_sha, addition=1, own=False)
        audit_path = HERE / 'gpu_budget_before_submission.json'
        durable_json(audit_path, audit)
        original = controls.read(OLD / 'plan.json')
        runtime = {
            'role': 'mechanical_P21_runtime_derivation_from_exact_independent_admission',
            'issuer': controls.OWNER, 'independent_reviewer': grant['reviewer'],
            'admitted': True, 'task_id': 'P21', 'scope': original['scope'],
            'condition': original['condition'], 'plan_sha256': controls.PLAN_SHA,
            'source_scope_sha256': original['source_scope_sha256'],
            'gpu_count': 1, 'project_gpu_ceiling': 8,
            'allow_benchmark_only_after_development_gate': True,
            'delegation_sha256': original['delegation_sha256'],
            'gpu_audit_receipt': str(audit_path), 'gpu_audit_receipt_sha256': controls.sha(audit_path),
            'root_adoption_sha256': controls.ADOPTION_SHA,
            'operational_manifest_sha256': manifest_sha, 'operational_admission_sha256': admission_sha,
            'one_allocation_only': True, 'no_retries': True, 'at_pacific': stamp()}
        runtime_path = HERE / 'runtime_admission.json'
        durable_json(runtime_path, runtime)
        runtime_sha = controls.sha(runtime_path)
        command = controls.expected_command(manifest_sha, admission_sha, runtime_sha)
        # Capacity queries may be slow: recheck exact authority and STOP after them.
        controls.validate(manifest_sha, admission_sha)
        # Exclusive intent file and parent are durable BEFORE scheduler mutation.
        durable_json(HERE / 'submission_attempt.json', {
            'at_pacific': stamp(), 'command': command,
            'manifest_sha256': manifest_sha, 'independent_admission_sha256': admission_sha,
            'runtime_admission_sha256': runtime_sha,
            'preallocation_audit_sha256': controls.sha(audit_path),
            'IPC_preflight': ipc, 'ambiguous_submission_must_not_be_retried': True})
        controls.validate(manifest_sha, admission_sha)
        result = subprocess.run(command, check=False, text=True, capture_output=True, cwd=ROOT)
        if result.returncode:
            durable_json(HERE / 'submission_error.json', {'at_pacific': stamp(),
                'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
                'no_automatic_retry': True})
            raise RuntimeError('Sole sbatch did not return success; inspect preserved intent')
        job_id = result.stdout.strip().split(';', 1)[0]
        if not job_id.isdigit():
            raise RuntimeError('Ambiguous scheduler success; sole intent prevents resubmission')
        receipt = {'at_pacific': stamp(), 'job_id': job_id, 'command': command,
            'manifest_sha256': manifest_sha, 'independent_admission_sha256': admission_sha,
            'runtime_admission_sha256': runtime_sha, 'submission_attempt_sha256': controls.sha(HERE / 'submission_attempt.json'),
            'GPU_count': 1, 'full_native67_complete': False, 'preparation_is_not_dispatch': True}
        durable_json(HERE / 'submission_receipt.json', receipt)
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--admission-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(submit(args.manifest_sha256, args.admission_sha256)))


if __name__ == '__main__':
    main()
