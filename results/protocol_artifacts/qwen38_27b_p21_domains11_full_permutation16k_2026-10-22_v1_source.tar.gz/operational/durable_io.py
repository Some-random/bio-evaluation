"""Durability-only contexts for the unchanged P21 runtime's original writes."""
from contextlib import contextmanager
from pathlib import Path
import json
import os

ORIGINAL_OPEN = Path.open
ORIGINAL_REPLACE = Path.replace


def sync_parents(path, boundary):
    parent = Path(path).parent
    boundary = Path(boundary).parent
    if not parent.is_relative_to(boundary):
        raise ValueError('Durable write left its exact runtime ancestry')
    while True:
        directory = os.open(parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
        if parent == boundary:
            return
        if not parent.is_relative_to(boundary):
            raise ValueError('Durable write left its exact runtime ancestry')
        parent = parent.parent


class DurableContext:
    def __init__(self, stream, path, boundary, poison):
        self.stream, self.path, self.boundary, self.poison = stream, path, boundary, poison

    def __enter__(self):
        return self.stream.__enter__()

    def __exit__(self, kind, value, traceback):
        try:
            if kind is None:
                self.stream.flush()
                os.fsync(self.stream.fileno())
                sync_parents(self.path, self.boundary)
        except BaseException:
            self.poison.append(True)
            raise
        finally:
            self.stream.__exit__(kind, value, traceback)
        return False

    def __getattr__(self, name):
        return getattr(self.stream, name)


@contextmanager
def runtime_writes(boundary):
    """No source transformation: context exit persists before original POST/ref access."""
    boundary = Path(boundary).resolve()
    poison = []

    def opened(path, mode='r', *args, **kwargs):
        target = Path(path)
        writing = any(flag in mode for flag in ('w', 'x'))
        if writing and target.absolute().is_relative_to(boundary):
            if poison:
                raise OSError('Earlier durable write failed; further runtime writes are forbidden')
            if target.resolve() != target.absolute() or target.is_symlink():
                raise ValueError('Runtime write aliases are forbidden')
            stream = ORIGINAL_OPEN(target, mode, *args, **kwargs)
            return DurableContext(stream, target, boundary, poison)
        return ORIGINAL_OPEN(target, mode, *args, **kwargs)

    def replaced(path, target):
        target = Path(target)
        if target.absolute().is_relative_to(boundary):
            if poison:
                raise OSError('Earlier durable write failed; further runtime renames are forbidden')
            if target.resolve() != target.absolute() or Path(path).resolve() != Path(path).absolute():
                raise ValueError('Runtime rename aliases are forbidden')
            result = ORIGINAL_REPLACE(path, target)
            try:
                sync_parents(target, boundary)
            except BaseException:
                poison.append(True)
                raise
            return result
        return ORIGINAL_REPLACE(path, target)

    Path.open = opened
    Path.replace = replaced
    try:
        yield
    finally:
        Path.open = ORIGINAL_OPEN
        Path.replace = ORIGINAL_REPLACE


def durable_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with ORIGINAL_OPEN(path, 'x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    sync_parents(path, path.parent)
