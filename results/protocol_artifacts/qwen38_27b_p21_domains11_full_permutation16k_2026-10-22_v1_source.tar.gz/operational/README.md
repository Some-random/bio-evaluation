# P21 domains11 operational restoration

This additive wrapper executes the exact adopted plan `7ecfc37c…` without
editing its 105 pinned scientific/runtime dependencies. Root adoption
`765f4999…` covers three artificial delivery checks, eleven previously
reviewed ordinary isolated-domain stability cases and one native score after
their complete prediction seal. The previous 13 cases and other 43 cases
stay outside this condition; no pooled 24/67 result is produced.

The exact scientific/native source review is already recorded by
`supporting_source_review_main_docs_refresh.json` in the original directory.
This change adds current v5 GPU accounting and exact independent authority,
file-plus-parent durability before requests/claims, a once-only scheduler
intent, an actual receipt handshake, and deterministic/actual short `/tmp`
IPC checks. Original payload, parser, model, sampling, constraint, reference
ordering and native formulas are unchanged. A failed durability operation
poisons later runtime writes so a queued task cannot dispatch another call.

`independent_admission.json` must be authored by `/root/independent_review`
or `/root`, with role `independent_P21_current_operational_runtime_admission`,
`approved: true`, the exact manifest/original-plan/root-adoption/shared-binding
SHA-256 values, and all of `scientific_scope_unchanged`, `one_allocation_only`,
`old_priority_disable_preserved_and_superseded_for_exact11` set true.
The runtime admission is mechanically derived by the owner from that exact
grant, explicitly labels its owner issuer and independent reviewer separately,
and preserves the original worker's required admission schema. It is not an
owner-issued independent approval. The old priority marker remains unchanged;
only this exact adopted eleven-case entrypoint supersedes it.

The sole submission command is `python3 submit_once.py --manifest-sha256
<exact> --admission-sha256 <exact>`. It revalidates authority/source pins after
acquiring the shared GPU submission lock, audits current capacity with +1,
durably records the intent, then calls sbatch once. Startup repeats current
accounting with +0/own-allocation required. Submission failure or ambiguity is
preserved and must not be retried automatically. No allocation is created by
source preparation or the invented tests.

The unchanged scientific files keep their original `__file__` and historical
source metadata; this separately pinned outer wrapper is actual operational
provenance. Runtime files stay under the exact original runtime path so native
seals and scorer interfaces are preserved. Reference bodies are only parsed
by the original scorer after its full eleven-case seal and durable sole-score
claim. Dependency verification may hash their opaque bytes without interpreting
them. No trained head, model replacement or held input is introduced.

Tests: `python3 -m unittest -v test_operational.py`. All fixtures are invented;
the original runner is exercised with mocked local transport and tokenizer.
Actual source preparation is not generation, a score or publication. Native
completion, independent actual-result review and separately admitted narrow
publication remain mandatory after execution.

V2 preserves frozen V1 and adds dangling-STOP rejection, fresh authority/STOP
rechecks after capacity and durable intent, and explicit scheduler no-requeue.

V3 preserves frozen V2 and fixes explicit argument delimiter handling: argparse
REMAINDER strips the delimiter, so the wrapper now splits it before parsing.
