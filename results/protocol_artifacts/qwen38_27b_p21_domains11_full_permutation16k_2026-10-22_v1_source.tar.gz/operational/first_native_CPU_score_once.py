"""First actual native score after proven pre-entry launcher failure; CPU only."""
from pathlib import Path
from contextlib import ExitStack
import argparse
import fcntl
import json
import os
import socket
import stat
import subprocess
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
OP = HERE.parent
sys.path.insert(0, str(OP))
import controls
from durable_io import durable_json, runtime_writes
OLD = controls.OLD
RUNTIME = OLD / 'runtime'
PROOF = OP / 'independent_zero_native_score_failure_review.json'
PROOF_SHA = 'e0c8d0b6439b46ba59892ba599c98b5303968f75d579a7abb908b53d528a00a3'
MANIFEST_SHA = '063628ff36f8fb130e6cbdfe7e1ae59ffb55b1786677edaa72e835140efff347'
OP_ADMISSION_SHA = 'c020ee67f31675c999b261f8a51fd297a898390db0176349752a0e19d735344d'
LOCK_SHA = '768d41d6f1e6a3c1ed016e7c514675c61a405c3590de33a1ba675ab04cd2e499'


def stamp():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def authority(config_sha, admission_sha):
    if sys.flags.optimize:raise PermissionError('Optimized score-entry guards forbidden')
    controls.regular(HERE / 'config.json', config_sha)
    cfg = controls.read(HERE / 'config.json')
    if (cfg.get('role') != 'P21_proven_zero_call_first_native_CPU_score_source'
            or cfg.get('original_plan_sha256') != controls.PLAN_SHA
            or cfg.get('zero_native_score_proof_sha256') != PROOF_SHA
            or cfg.get('benchmark_prediction_lock_sha256') != LOCK_SHA
            or cfg.get('new_model_or_generation_calls') != 0):
        raise PermissionError('Only exact unchanged eleven-case first native entry is eligible')
    for path, digest in cfg['files_sha256'].items():controls.regular(path, digest)
    controls.validate(MANIFEST_SHA, OP_ADMISSION_SHA)
    controls.regular(PROOF, PROOF_SHA)
    proof = controls.read(PROOF)
    if (proof.get('approved_zero_native_score_boundary') is not True
            or proof.get('reviewer') != '/root/independent_review'
            or proof.get('native_score_function_calls_observed') != 0
            or proof.get('job_id') != '249787' or proof.get('scheduler_state') != 'FAILED'
            or proof.get('scheduler_exit_code') != '1:0'):
        raise PermissionError('Exact independent zero-native-call failure proof required')
    controls.regular(HERE / 'independent_admission.json', admission_sha)
    grant = controls.read(HERE / 'independent_admission.json')
    if (grant.get('reviewer') not in {'/root', '/root/independent_review'}
            or grant.get('approved') is not True
            or grant.get('role') != 'independent_P21_first_native_CPU_score_entry_admission'
            or grant.get('config_sha256') != config_sha
            or grant.get('zero_native_score_proof_sha256') != PROOF_SHA
            or grant.get('root_adoption_sha256') != controls.ADOPTION_SHA
            or grant.get('first_native_function_entry_once_only') is not True
            or grant.get('original_GPU_FAILED_preserved') is not True
            or grant.get('model_calls_or_allocations_authorized') is not False):
        raise PermissionError('Exact independent CPU-first-native-entry admission required')
    if os.path.lexists(HERE / 'STOP'):raise PermissionError('Recovery STOP is active')
    return cfg, proof


def unchanged(proof):
    for path, digest in {**proof['files_sha256'], **proof['sealed_member_hashes']}.items():
        controls.regular(path, digest)
    for phase in ('development', 'benchmark'):
        run = RUNTIME / phase
        actual = {str(run / n) for n in ('run_manifest.json', 'tokenizer_preflight.json')}
        for category in ('requests', 'responses', 'outcomes', 'errors'):
            actual.update(str(p) for p in (run / category).iterdir())
        expected = {p for p in proof['sealed_member_hashes'] if Path(p).is_relative_to(run)}
        if actual != expected:raise ValueError('Actual sealed cohort membership changed')
    result = subprocess.run(['sacct', '--jobs', '249787', '--noheader', '--parsable2',
        '--format=JobIDRaw,State,ExitCode'], check=True, text=True, capture_output=True)
    rows = [r.split('|') for r in result.stdout.splitlines() if r.split('|')[0] == '249787']
    if len(rows) != 1 or rows[0][1:3] != ['FAILED', '1:0']:
        raise ValueError('Original GPU failure identity drifted')


def native_arguments():
    return (RUNTIME / 'benchmark', OLD / 'benchmark_config.json',
            OLD / 'scorer_only_manifest.json', RUNTIME / 'benchmark/scores.json')


def call_original_score(module):
    # Exact original __main__ calls score(run, config, references, output).
    # There is deliberately no fallback to a nonexistent module.main().
    return module.score(*native_arguments())


def persist_then_call(claim_path, value, callback):
    durable_json(claim_path, value)
    return callback()


def guarded_native_entry(config_sha, admission_sha, module):
    # Recheck STOP and every exact authority/source after durable intent and any
    # prior filesystem/accounting wait, immediately before native function entry.
    authority(config_sha, admission_sha)
    with runtime_writes(RUNTIME):
        return call_original_score(module)


def execute(config_sha, admission_sha):
    cfg, proof = authority(config_sha, admission_sha)
    with ExitStack() as stack:
        for path in (RUNTIME / 'allocation.lock', RUNTIME / 'protocol.lock', RUNTIME / 'benchmark/.runner.lock'):
            if path.resolve() != path or path.is_symlink():raise ValueError('Owned original regular lock required')
            descriptor = os.open(path, os.O_RDWR | os.O_NOFOLLOW)
            stack.callback(os.close, descriptor)
            identity = os.fstat(descriptor)
            if not stat.S_ISREG(identity.st_mode) or identity.st_uid != os.getuid():
                raise PermissionError('Original output lock ownership differs')
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        authority(config_sha, admission_sha);unchanged(proof)
        for path in (HERE / 'native_entry_attempt.json', HERE / 'completion.json',
                     RUNTIME / 'benchmark/native_scoring_attempt.json', RUNTIME / 'benchmark/scores.json'):
            if os.path.lexists(path):raise FileExistsError('Preserve every actual/ambiguous native entry; never retry')
        sys.path.insert(0, str(OLD))
        module = controls.load('p21_exact_unchanged_first_native_scorer', OLD / 'scorer.py')
        def first_entry():
            return guarded_native_entry(config_sha, admission_sha, module)
        try:
            persist_then_call(HERE / 'native_entry_attempt.json', {
                'at_pacific': stamp(), 'pid': os.getpid(), 'hostname': socket.gethostname(),
                'config_sha256': config_sha, 'independent_admission_sha256': admission_sha,
                'zero_native_score_proof_sha256': PROOF_SHA,
                'benchmark_prediction_lock_sha256': LOCK_SHA,
                'first_native_function_entry_once_only': True, 'new_model_calls': 0}, first_entry)
            unchanged(proof);authority(config_sha, admission_sha)
            score_path = native_arguments()[-1];score = controls.read(score_path)
            native_claim = RUNTIME / 'benchmark/native_scoring_attempt.json'
            if (score.get('planned_assays') != 11 or score.get('prediction_lock_sha256') != LOCK_SHA
                    or controls.read(native_claim).get('sole_native_scoring_attempt') is not True):
                raise ValueError('Actual first native score scope/claim differs')
            completion = {'at_pacific': stamp(), 'role': 'P21_first_native_CPU_score_completed',
                'config_sha256': config_sha, 'independent_admission_sha256': admission_sha,
                'zero_native_score_proof_sha256': PROOF_SHA, 'original_GPU_job_id': '249787',
                'original_GPU_scheduler_state': 'FAILED', 'original_GPU_exit_code': '1:0',
                'old_worker_status_and_intent_preserved': True, 'planned_assays': 11,
                'native_panel_assays': 67, 'full_native67_complete': False,
                'score_sha256': controls.sha(score_path), 'native_claim_sha256': controls.sha(native_claim),
                'native_scoring_status': score['native_scoring_status'],
                'benchmark_prediction_lock_sha256': LOCK_SHA, 'new_model_calls': 0,
                'new_GPU_allocations': 0, 'native_function_entries': 1,
                'python_version': sys.version, 'pid': os.getpid(), 'hostname': socket.gethostname()}
            durable_json(HERE / 'completion.json', completion)
            return completion
        except BaseException as error:
            if not os.path.lexists(HERE / 'failure.json'):
                durable_json(HERE / 'failure.json', {'at_pacific': stamp(), 'error_type': type(error).__name__,
                    'no_automatic_retry': True, 'native_intents_and_outputs_preserved': True})
            raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config-sha256', required=True);parser.add_argument('--admission-sha256', required=True)
    args = parser.parse_args();print(json.dumps(execute(args.config_sha256, args.admission_sha256)))
