"""Artificial archive-boundary checks; no model, real sequence or network use."""
from pathlib import Path
import io
import json
import tarfile
import tempfile
import unittest
import copy
from unittest.mock import patch
import package
import publish


class ArchiveBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.source=self.root/'fixture.txt';self.source.write_text('artificial public fixture\n')
    def tearDown(self):self.tmp.cleanup()
    def test_exact_original_and_generated_bytes_pass(self):
        target=self.root/'valid.tar.gz'
        m=package.archive(target,{'source/fixture.txt':self.source},{'reference.json':b'{}\n'})
        publish.verify_archive(target,m['files'])
    def test_changed_reviewed_member_hash_rejected(self):
        target=self.root/'changed.tar.gz';m=package.archive(target,{'fixture.txt':self.source})
        m['files']['fixture.txt']['sha256']='0'*64
        with self.assertRaises(ValueError):publish.verify_archive(target,m['files'])
    def test_missing_member_rejected(self):
        target=self.root/'missing.tar.gz';m=package.archive(target,{'fixture.txt':self.source})
        with self.assertRaises(ValueError):publish.verify_archive(target,{})
    def test_parent_traversal_rejected(self):
        target=self.root/'unsafe.tar.gz'
        with self.assertRaises(ValueError):package.archive(target,{'../outside.txt':self.source})
    def test_link_rejected(self):
        target=self.root/'link.tar.gz'
        with tarfile.open(target,'w:gz')as a:
            member=tarfile.TarInfo('linked');member.type=tarfile.SYMTYPE;member.linkname='fixture.txt';a.addfile(member)
        with self.assertRaises(ValueError):publish.verify_archive(target,{})
    def test_duplicate_manifest_rejected(self):
        target=self.root/'duplicate.tar.gz';data=json.dumps({'files':{}}).encode()
        with tarfile.open(target,'w:gz')as a:
            for _ in range(2):
                m=tarfile.TarInfo('publication_manifest.json');m.size=len(data);a.addfile(m,io.BytesIO(data))
        with self.assertRaises(ValueError):publish.verify_archive(target,{})
    def test_existing_candidate_archive_preserved(self):
        target=self.root/'existing.tar.gz';target.write_bytes(b'preserve')
        with self.assertRaises(FileExistsError):package.archive(target,{'fixture.txt':self.source})
        self.assertEqual(target.read_bytes(),b'preserve')
    def test_linked_original_member_rejected(self):
        link=self.root/'alias.txt';link.symlink_to(self.source)
        with self.assertRaises(ValueError):package.archive(self.root/'alias.tar.gz',{'fixture.txt':link})
    def test_private_operational_source_name_rejected(self):
        with self.assertRaises(ValueError):package.public_source_path('private_GPU_audit.json',Path(__file__))
    def test_neural_weight_source_name_rejected(self):
        with self.assertRaises(ValueError):package.public_source_path('model.bin',Path(__file__))


class ClosureBindingTests(unittest.TestCase):
    def setUp(self):
        self.admission='a'*64;self.lock='l'*64
        self.submission={'job_id':'245861','plan_sha256':package.PLAN_SHA,'admission_sha256':self.admission,'GPU_count':1}
        self.status={'stage':'stopped_for_review','error_type':'FileExistsError',
            'error':'private_GPU_audit_before_benchmark.json'}
        self.generation_identity={'job_id':'245861','plan_sha256':package.PLAN_SHA,'admission_sha256':self.admission}
        self.done={'plan_sha256':package.PLAN_SHA,'job_id':'999001','scores_sha256':'s'*64,
            'generation_lock_sha256':self.lock,'full_proxy_condition_complete':True}
        self.scoring={'job_id':'999001','GPU_requests':0,'new_generator_calls':0,
            'continuation_plan_sha256':package.CPU_REPAIR_PLAN_SHA,'review_sha256':package.CPU_REPAIR_REVIEW_SHA}
        self.repaired={'stage':'CPU_only_scoring_continuation_complete','job_id':'999001','generation_job_id':'245861',
            'original_plan_sha256':package.PLAN_SHA,'continuation_plan_sha256':package.CPU_REPAIR_PLAN_SHA,
            'independent_review_sha256':package.CPU_REPAIR_REVIEW_SHA,'new_generator_calls':0,'GPU_requests':0,
            'scores_sha256':'s'*64,'generation_lock_sha256':self.lock,'full_proxy_condition_complete':True,
            'native_NatureLM_score':False,'experimental_validation':False}
        self.continuation={'root_admission_sha256':self.admission,'GPU_requests':0,'new_generator_calls':0,
            'maximum_proxy_attempts_per_case':1,'generation_prediction_lock_sha256':self.lock}
        self.gate={'passed':True,'job_id':'999001','full_lengths':[20,1022],'benchmark_cases':0,'artificial_evaluator_predictions':4}
    def validate(self):return package.closure_bindings(self.submission,self.status,self.done,self.scoring,self.repaired,self.continuation,self.gate,self.generation_identity,self.admission)
    def test_separate_failed_generation_and_successful_scoring_bind(self):self.assertEqual(self.validate(),('245861','999001'))
    def test_changed_generation_lock_rejected(self):
        self.repaired['generation_lock_sha256']='changed'
        with self.assertRaises(ValueError):self.validate()
    def test_nonzero_GPU_or_generator_calls_rejected(self):
        for name in ['GPU_requests','new_generator_calls']:
            with self.subTest(field=name):
                self.repaired[name]=1
                with self.assertRaises(ValueError):self.validate()
                self.repaired[name]=0
    def test_mismatched_failed_generation_identity_rejected(self):
        self.generation_identity['job_id']='ARTIFICIAL-OTHER'
        with self.assertRaises(ValueError):self.validate()
    def test_mismatched_successful_score_identity_rejected(self):
        self.done['job_id']='ARTIFICIAL-OTHER'
        with self.assertRaises(ValueError):self.validate()
    def test_same_generation_and_scoring_job_rejected(self):
        self.scoring['job_id']='245861'
        with self.assertRaises(ValueError):self.validate()
    def test_missing_fresh_resource_gate_rejected(self):
        self.gate['passed']=False
        with self.assertRaises(ValueError):self.validate()
    def test_bootstrap_failure_precedes_any_verifier_module_load(self):
        with patch.object(package,'bootstrap_plan',side_effect=ValueError('changed')),patch.object(package,'load')as loader:
            with self.assertRaises(ValueError):package.verify(Path('ARTIFICIAL'),self.admission)
            loader.assert_not_called()


class ReportTests(unittest.TestCase):
    def fixture(self):
        group={'evaluable':10,'full_group_mean_desired_proxy':.25}
        scores={'successes':30,'NetSolP_D':{'per_group':{'soluble':dict(group),'insoluble':dict(group)}},
            'DeepSTABp':{'evaluable':10,'full_cohort_mean_predicted_tm_c':50.}}
        lengths={g:{'full_group_mean_residues':1.,'full_group_minimum_residues':1,'full_group_maximum_residues':1}
            for g in ['soluble','insoluble','stable']}
        return scores,lengths
    def test_renderer_preserves_short_string_and_recovery_limitations(self):
        scores,lengths=self.fixture()
        with patch.object(package,'length_statistics',return_value=lengths):report=package.report_text({},scores,{'delivered':30})
        for required in ['one-residue strings','no sequence was regenerated','0.250000','results/protocol_artifacts/',
                'do not measure gains from conditioning','predictor applicability']:
            self.assertIn(required,report)
    def test_incomplete_group_mean_remains_undefined(self):
        scores,lengths=self.fixture();scores['successes']=29
        scores['NetSolP_D']['per_group']['soluble'].update(evaluable=9,full_group_mean_desired_proxy=None)
        lengths['soluble']['full_group_mean_residues']=None
        with patch.object(package,'length_statistics',return_value=lengths):report=package.report_text({},scores,{'delivered':29})
        self.assertIn('| Soluble | 9/10 | undefined | undefined |',report)


if __name__=='__main__':unittest.main()
