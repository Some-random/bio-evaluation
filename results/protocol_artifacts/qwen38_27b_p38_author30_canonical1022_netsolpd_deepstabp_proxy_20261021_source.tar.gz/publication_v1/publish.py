"""Publish exactly nine independently reviewed P38 result paths, offline by default."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import fcntl
import hashlib
import importlib.util
import json
import shutil
import subprocess
import tarfile
import tempfile

ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
HERE=Path(__file__).resolve().parent
OWNER='/root/p38_generation'
REPOSITORY='Some-random/bio-evaluation'
URL='https://github.com/'+REPOSITORY+'.git'
RUN='qwen38_27b_p38_author30_canonical1022_netsolpd_deepstabp_proxy_20261021'
BASE='results/runs/'+RUN+'/'
SOURCE='results/protocol_artifacts/'+RUN+'_source.tar.gz'
TRAJECTORIES='results/trajectory_archives/'+RUN+'_trajectories.tar.gz'
REPORT='reports/P38_AUTHOR30_PROXY_RESULT.md'
ALLOWED={BASE+n for n in ['scores.json','generation_completion.json','generation_prediction_lock.json',
    'evaluator_prediction_lock.json','README.md','artifact_manifest.json']}|{SOURCE,TRAJECTORIES,REPORT}
POLICY=ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review_resume_v2.json'


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()
def read(path):return json.loads(Path(path).read_text())
def stamp():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def save(path,value):
    with Path(path).open('x')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module


def verify_archive(path,expected):
    seen={};declared=None
    with tarfile.open(path,'r:gz')as archive:
        for member in archive:
            name=member.name;relative=Path(name)
            if (not member.isfile()or relative.is_absolute()or'..'in relative.parts
                    or'.local'in relative.parts or name in seen or name=='publication_manifest.json'and declared is not None):
                raise ValueError('Unsafe, linked or duplicate public archive member')
            data=archive.extractfile(member).read()
            if name=='publication_manifest.json':declared=json.loads(data);continue
            seen[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    if seen!=expected or declared!={'files':expected}:raise ValueError('Exact archive bytes/member map differ')


def check(candidate_path,candidate_sha):
    if sha(candidate_path)!=candidate_sha:raise ValueError('Exact reviewed publication candidate changed')
    m=read(candidate_path)
    if (m['task_id']!='P38'or m['owner']!=OWNER or m['repository']!=REPOSITORY or m['visibility']!='public'
            or m['planned']!=30 or m['native_NatureLM_score']is not False or m['experimental_validation']is not False
            or m['new_model_calls']!=0 or m['weights_environments_credentials_or_full_account_metadata_included']is not False
            or m['shared_aggregate_reports_modified']is not False or m['website_or_schedule_changes']is not False
            or set(m['files_sha256'])!=ALLOWED):raise ValueError('Exact narrow30-template proxy candidate required')
    required={str(p)for p in [HERE/'package.py',HERE/'publish.py',ROOT/'scripts/daily_backup.py',
        ROOT/'.local/litqa2_replay/incremental_upload.py',ROOT/'.local/litqa2_replay/github_credential_helper.py',
        ROOT/'configs/publication_destination.json',ROOT/'scripts/publication_destination.py',POLICY]}
    if not required<=set(m['support_sha256']):raise ValueError('All exact verifier/scanner/destination/delegation leaf pins required')
    for name,digest in m['support_sha256'].items():
        if Path(name).is_symlink()or sha(name)!=digest:raise ValueError('Frozen publication support changed')
    packager=load('p38_exact_offline_packager',HERE/'package.py')
    if m['plan_sha256']!=packager.PLAN_SHA:raise ValueError('Frozen P38 plan differs')
    plan,scores,generated,run=packager.verify(Path(m['admission_path']),m['admission_sha256'])
    stage=Path(m['stage_directory'])
    if stage.resolve()!=HERE/'stage':raise ValueError('Own exact stage required')
    scanner=load('p38_narrow_secret_scanner',ROOT/'scripts/daily_backup.py')
    for name,digest in m['files_sha256'].items():
        path=stage/name
        if path.is_symlink()or not path.is_file()or path.stat().st_size>=90*1024**2 or sha(path)!=digest:
            raise ValueError('Exact staged bytes changed or exceed Git boundary')
        scanner.scan_file(path)
    for public,actual in [(BASE+'scores.json',run/'evaluation/scores.json'),
        (BASE+'generation_completion.json',run/'benchmark/completion.json'),
        (BASE+'generation_prediction_lock.json',run/'benchmark/prediction_lock.json'),
        (BASE+'evaluator_prediction_lock.json',run/'evaluation/prediction_lock.json')]:
        if sha(stage/public)!=sha(actual):raise ValueError('Published saved result bytes differ')
    for archive_name,mapping_key,members_key in [(SOURCE,'private_source_mapping','source_archive_members'),
            (TRAJECTORIES,'private_trajectory_mapping','trajectory_archive_members')]:
        members=m[members_key]
        for name,path in m[mapping_key].items():
            source=Path(path)
            if archive_name==SOURCE:packager.public_source_path(name,source)
            if source.is_symlink()or members.get(name)!={'sha256':sha(source),'bytes':source.stat().st_size}:
                raise ValueError('Archived original source or trajectory identity differs')
        if archive_name==TRAJECTORIES and set(m[mapping_key])!=set(members):
            raise ValueError('Every saved trajectory archive member must bind original bytes')
        if archive_name==SOURCE:
            generated_members=packager.generated_sources(plan)
            if set(members)!=set(m[mapping_key])|set(generated_members):
                raise ValueError('Only exact source plus own generated references may be archived')
            for name,data in generated_members.items():
                if members[name]!={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}:
                    raise ValueError('Generated model/own-execution evidence differs from original saved runtime')
        verify_archive(stage/archive_name,members)
    expected_report=packager.report_text(plan,scores,generated)
    if any((stage/name).read_text()!=expected_report for name in [REPORT,BASE+'README.md']):
        raise ValueError('Qualified report differs from exact saved full-denominator result')
    manifest=read(stage/(BASE+'artifact_manifest.json'))
    if (manifest['plan_sha256']!=m['plan_sha256']or manifest['score_sha256']!=sha(run/'evaluation/scores.json')
            or manifest['source_archive']!={'path':SOURCE,'sha256':sha(stage/SOURCE)}
            or manifest['trajectory_archive']!={'path':TRAJECTORIES,'sha256':sha(stage/TRAJECTORIES)}):
        raise ValueError('Public artifact manifest differs from original saved result')
    return m


def review_guard(path,digest,m,candidate_sha):
    if path is None or digest is None or sha(path)!=digest:raise PermissionError('Exact independent publication review required')
    review=read(path);policy=read(POLICY);reviewer=review.get('reviewer')
    if (reviewer==OWNER or reviewer not in ['/root',*policy['authorized_reviewers']]
            or review.get('task_id')!='P38'or review.get('approved')is not True
            or review.get('candidate_sha256')!=candidate_sha or review.get('paths_sha256')!=m['files_sha256']
            or review.get('repository')!=REPOSITORY or review.get('visibility')!='public'
            or review.get('secret_archive_scans_verified')is not True or review.get('exclusions_verified')is not True):
        raise PermissionError('Different authorized peer must approve exact whitelist and scans')
    if reviewer!='/root'and(review.get('delegation_sha256')!=sha(POLICY)or'P38'not in policy['authorized_task_ids']):
        raise PermissionError('Bounded exact delegation required')


def publish(candidate_path,candidate_sha,review_path,review_sha):
    m=check(candidate_path,candidate_sha);review_guard(review_path,review_sha,m,candidate_sha)
    if (HERE/'attempt_started.json').exists()or(HERE/'publication_receipt.json').exists():
        raise FileExistsError('Preserve previous publication attempt; no ambiguous push retry')
    with(ROOT/'.local/catalog_report_generation.lock').open('a')as generation:
      fcntl.flock(generation,fcntl.LOCK_EX)
      with(ROOT/'.local/evaluation_publication.lock').open('a')as publication:
        fcntl.flock(publication,fcntl.LOCK_EX);check(candidate_path,candidate_sha)
        helper=load('p38_authorized_git_helper',ROOT/'.local/litqa2_replay/incremental_upload.py')
        if helper.REPOSITORY!=REPOSITORY or helper.URL!=URL:raise ValueError('Exact authorized repository required')
        actual=helper.confirm_destination()
        if actual['repository']!=REPOSITORY or actual['visibility']!='public'or actual['push_permission']is not True:
            raise ValueError('Actual repository identity, public visibility or push permission differs')
        with tempfile.TemporaryDirectory(prefix='p38-author30-publication-')as directory:
            checkout=Path(directory)
            def git(*args):return helper.git(*args,cwd=checkout)
            git('init','--quiet');git('remote','add','origin',URL)
            git('config','remote.origin.promisor','true');git('config','remote.origin.partialclonefilter','blob:none')
            git('sparse-checkout','init','--no-cone');git('sparse-checkout','set','--no-cone',*('/'+n for n in sorted(ALLOWED)))
            git('fetch','--filter=blob:none','--depth=1','origin','main');before=git('rev-parse','FETCH_HEAD').stdout.strip()
            git('checkout','--detach','FETCH_HEAD');git('config','user.name','Codex');git('config','user.email','codex@localhost')
            for name in sorted(ALLOWED):
                source=HERE/'stage'/name;target=checkout/name
                if target.is_symlink()or target.exists()and sha(target)!=m['files_sha256'][name]:
                    raise ValueError('Existing immutable public P38 artifact differs')
                target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
            git('add','-f','--sparse','--',*sorted(ALLOWED))
            changed=set(git('diff','--cached','--name-only').stdout.splitlines())
            if not changed or not changed<=ALLOWED:raise ValueError('Unexpected paths or already identical publication requires review')
            git('diff','--cached','--check','--',*sorted(ALLOWED))
            save(HERE/'attempt_started.json',{'at_pacific':stamp(),'candidate_sha256':candidate_sha,
                'independent_review_sha256':review_sha,'remote_main_before':before,'model_calls':0})
            git('commit','-m','Publish30-template constrained P38 proxy condition and complete saved trajectories')
            helper.confirm_destination();git('push','origin','HEAD:refs/heads/main')
            commit=git('rev-parse','HEAD').stdout.strip();git('fetch','--filter=blob:none','origin','main')
            head=git('rev-parse','FETCH_HEAD').stdout.strip()
            for name in sorted(ALLOWED):
                data=subprocess.run(['git','show','FETCH_HEAD:'+name],cwd=checkout,capture_output=True,check=True).stdout
                if hashlib.sha256(data).hexdigest()!=m['files_sha256'][name]:raise ValueError('Remote committed bytes differ')
            receipt={'at_pacific':stamp(),'stage':'published','repository':REPOSITORY,'visibility':'public',
                'previous_main_head':before,'commit_sha':commit,'verified_remote_main_head':head,
                'remote_bytes_verified':True,'published_path_count':len(ALLOWED),'paths_sha256':m['files_sha256'],
                'candidate_sha256':candidate_sha,'independent_review_sha256':review_sha,'task_id':'P38','planned':30,
                'native_NatureLM_score':False,'experimental_validation':False,
                'weights_environments_credentials_or_full_account_metadata_published':False,
                'shared_aggregate_reports_modified':False,'website_or_schedule_changes':False,'model_calls':0}
            save(HERE/'publication_receipt.json',receipt)
            print(json.dumps({k:receipt[k]for k in ['stage','commit_sha','published_path_count','remote_bytes_verified']}))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--candidate',type=Path,default=HERE/'candidate.json')
    parser.add_argument('--candidate-sha256',required=True);parser.add_argument('--publish',action='store_true')
    parser.add_argument('--review',type=Path);parser.add_argument('--review-sha256');args=parser.parse_args()
    if args.publish:publish(args.candidate,args.candidate_sha256,args.review,args.review_sha256)
    else:check(args.candidate,args.candidate_sha256);print(json.dumps({'stage':'offline_P38_publication_check_passed','network_calls':0,'model_calls':0}))
