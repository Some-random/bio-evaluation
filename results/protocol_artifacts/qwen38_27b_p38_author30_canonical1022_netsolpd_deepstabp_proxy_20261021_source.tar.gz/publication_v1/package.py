"""Verify sealed P38 artifacts and prepare a narrow, offline publication candidate.

This program has no solver/evaluator callback or network operation. It replays
scalar aggregation from exact saved outputs and never regenerates a sequence.
"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import fcntl
import hashlib
import importlib.util
import io
import json
import subprocess
import tarfile

ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
HERE=Path(__file__).resolve().parent
EXEC=HERE.parent/'available_execution_v1'
RUN='qwen38_27b_p38_author30_canonical1022_netsolpd_deepstabp_proxy_20261021'
PLAN_SHA='3efe508536ac08857289ddf641a3dae2c72b6dce1c95ba93c9df55f5bb18de30'
CPU_REPAIR_PLAN_SHA='09f2bde3c443699e5149d18d4f45c5689b2f6717cc91082574ae2e49a0762b64'
CPU_REPAIR_REVIEW_SHA='9b52490989cc2705b2d93abea565b770ee138434aa2808335e4b98a535990ffb'


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()
def read(path):return json.loads(Path(path).read_text())
def stamp():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x')as stream:json.dump(value,stream,indent=2,sort_keys=True,allow_nan=False);stream.write('\n')
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module


def verify_files(folder,lock):
    folder=Path(folder).resolve();files=lock['files_sha256']
    for name,digest in files.items():
        relative=Path(name);path=folder/relative
        if (relative.is_absolute()or'..'in relative.parts or path.is_symlink()
                or not path.resolve().is_relative_to(folder)or sha(path)!=digest):
            raise ValueError('Changed, foreign or linked sealed member')
    return files


def bootstrap_plan():
    if sha(EXEC/'plan.json')!=PLAN_SHA:raise ValueError('Original exact P38 plan changed before verifier import')
    plan=read(EXEC/'plan.json');source=EXEC/'admission.py'
    if sha(source)!=plan['frozen_files_sha256'][str(source)]:raise ValueError('Original admission source changed before import')
    return plan


def closure_bindings(submission,status,done,scoring_submission,repaired,continuation,gate,generation_identity,admission_sha):
    """Pure binding checks for failed generation versus sole CPU scoring closure."""
    generation_job=submission.get('job_id');job=scoring_submission.get('job_id')
    if (submission.get('plan_sha256')!=PLAN_SHA or submission.get('admission_sha256')!=admission_sha
            or submission.get('GPU_count')!=1 or generation_job!='245861'
            or generation_identity.get('job_id')!=generation_job or generation_identity.get('plan_sha256')!=PLAN_SHA
            or generation_identity.get('admission_sha256')!=admission_sha
            or status.get('job_id',generation_job)!=generation_job
            or status.get('stage')!='stopped_for_review'or status.get('error_type')!='FileExistsError'
            or 'private_GPU_audit_before_benchmark.json'not in status.get('error','')or done.get('plan_sha256')!=PLAN_SHA):
        raise ValueError('Exact failed-after-generation identity differs')
    if (not job or job==generation_job or scoring_submission.get('GPU_requests')!=0 or scoring_submission.get('new_generator_calls')!=0
            or scoring_submission.get('continuation_plan_sha256')!=CPU_REPAIR_PLAN_SHA
            or scoring_submission.get('review_sha256')!=CPU_REPAIR_REVIEW_SHA
            or continuation.get('root_admission_sha256')!=admission_sha or continuation.get('GPU_requests')!=0
            or continuation.get('new_generator_calls')!=0 or continuation.get('maximum_proxy_attempts_per_case')!=1
            or repaired.get('stage')!='CPU_only_scoring_continuation_complete'or repaired.get('job_id')!=job
            or repaired.get('generation_job_id')!=generation_job or repaired.get('original_plan_sha256')!=PLAN_SHA
            or repaired.get('continuation_plan_sha256')!=CPU_REPAIR_PLAN_SHA
            or repaired.get('independent_review_sha256')!=CPU_REPAIR_REVIEW_SHA
            or repaired.get('new_generator_calls')!=0 or repaired.get('GPU_requests')!=0
            or repaired.get('scores_sha256')!=done.get('scores_sha256')or done.get('job_id')!=job
            or repaired.get('generation_lock_sha256')!=continuation.get('generation_prediction_lock_sha256')
            or done.get('generation_lock_sha256')!=continuation.get('generation_prediction_lock_sha256')
            or repaired.get('full_proxy_condition_complete')!=done.get('full_proxy_condition_complete')
            or repaired.get('native_NatureLM_score')is not False or repaired.get('experimental_validation')is not False):
        raise ValueError('Exact zero-GPU/no-regeneration scoring continuation closure differs')
    if (gate.get('passed')is not True or gate.get('job_id')!=job or gate.get('full_lengths')!=[20,1022]
            or gate.get('benchmark_cases')!=0 or gate.get('artificial_evaluator_predictions')!=4):
        raise ValueError('Actual separate CPU resource gate must precede once-only benchmark scores')
    return generation_job,job


def verify(admission_path,admission_sha):
    # The unmodified, exact runtime verifier validates original source pins and
    # the distinct root grant before any saved result is interpreted.
    import sys
    if str(EXEC)not in sys.path:sys.path.insert(0,str(EXEC))
    bootstrap_plan()
    admission=load('p38_publication_runtime_admission',EXEC/'admission.py')
    plan=admission.validate(EXEC/'plan.json',PLAN_SHA,admission_path,admission_sha,require_job=False)
    cases=admission.verified_inputs(plan);run=Path(plan['output_root']);runtime=EXEC/'runtime'
    status=read(runtime/'status.json');done=read(runtime/'offline_proxy_scoring_completion.json')
    submission=read(EXEC/'resume_partition_repair_20261021/submission_receipt.json')
    repair=EXEC/'offline_scoring_repair_v1';scoring_submission=read(repair/'submission_receipt.json');repaired=read(repair/'completion.json')
    if (sha(repair/'plan.json')!=CPU_REPAIR_PLAN_SHA or sha(scoring_submission['review_path'])!=CPU_REPAIR_REVIEW_SHA):
        raise ValueError('Exact independently reviewed CPU continuation plan/review changed before import')
    declared=read(repair/'plan.json');source=repair/'worker.py'
    if sha(source)!=declared['files_sha256'][str(source)]:raise ValueError('CPU continuation guard changed before import')
    guard=load('p38_exact_CPU_scoring_continuation_guard',repair/'worker.py')
    continuation,_=guard.admitted(repair/'plan.json',CPU_REPAIR_PLAN_SHA,Path(scoring_submission['review_path']),CPU_REPAIR_REVIEW_SHA)
    gate=read(repair/'neutral_evaluator_gate/completion.json')
    generation_job,job=closure_bindings(submission,status,done,scoring_submission,repaired,continuation,gate,
        read(runtime/'allocation_started.json'),admission_sha)
    for actual_job,expected in [(generation_job,'FAILED|1:0'),(job,'COMPLETED|0:0')]:
        rows=subprocess.run(['sacct','-j',actual_job,'-n','-P','-X','-o','JobID,State,ExitCode'],
            capture_output=True,text=True,check=True,timeout=30).stdout.splitlines()
        if actual_job+'|'+expected not in rows:raise ValueError('Actual preserved generation/scoring allocation state differs')
    for name in ['allocation.lock','protocol.lock']:
        with(runtime/name).open('r+')as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    stopped=read(runtime/'own_Qwen_stopped_before_CPU_scores.json')
    if stopped.get('own_server_stopped')is not True or stopped.get('other_runtimes_changed')is not False:
        raise ValueError('Own Qwen shutdown before CPU scores must be recorded')
    gen=run/'benchmark';generated=read(gen/'completion.json');generation_lock=sha(gen/'prediction_lock.json')
    if (generated['plan_sha256']!=PLAN_SHA or generated['planned']!=30 or generated['closed_slots']!=30
            or generated['prediction_lock_sha256']!=generation_lock
            or done['generation_lock_sha256']!=generation_lock):raise ValueError('Exact complete30 generation seal required')
    evaluator=load('p38_publication_pure_generation_verifier',EXEC/'evaluate_locked.py')
    records=evaluator.verified_sequences(cases,gen,generation_lock)
    if any(r['sequence_valid']and not 1<=len(r['sequence'])<=1022 for r in records):
        raise ValueError('Complete generated output exceeds the adopted length condition')
    evaluation=run/'evaluation';lock=read(evaluation/'prediction_lock.json');files=verify_files(evaluation,lock)
    actual={str(p.relative_to(evaluation))for p in evaluation.rglob('*')if p.is_file()
            and str(p.relative_to(evaluation))not in {'prediction_lock.json','scores.json'}}
    if actual!=set(files)or lock['generation_prediction_lock_sha256']!=generation_lock:
        raise ValueError('Evaluation has missing or unsealed saved artifacts')
    outcomes=read(evaluation/'terminal_records.json')
    if [r.get('case_id')for r in outcomes]!=[c['case_id']for c in cases]:
        raise ValueError('Full ordered30 proxy denominator required')
    sol=[];thermal=[]
    for record,outcome in zip(records,outcomes):
        case=record['case'];ident=case['case_id'];group=case['property_group'];key=hashlib.sha256(ident.encode()).hexdigest()
        if outcome.get('property_group')!=group:raise ValueError('Proxy property identity differs')
        attempted=outcome.get('evaluator_attempted')is True
        if attempted:
            request_name='requests/'+key+'.json';attempt_name='attempts/'+key+'.json'
            if request_name not in files or attempt_name not in files or not record['sequence_valid']:
                raise ValueError('Attempted proxy must bind a valid complete generated sequence')
            request=read(evaluation/request_name);attempt=read(evaluation/attempt_name);sequence=record['sequence']
            if (request!={'case_id':ident,'property_group':group,'sequence':sequence,
                    'sequence_sha256':hashlib.sha256(sequence.encode()).hexdigest()}
                    or attempt.get('case_id')!=ident or attempt.get('request_sha256')!=files[request_name]
                    or attempt.get('maximum_attempts')!=1):raise ValueError('Proxy request/attempt identity differs')
        if outcome['status']=='success':
            response_name='responses/'+key+'.json'
            if not attempted or response_name not in files:raise ValueError('Successful proxy needs exact saved response')
            response=read(evaluation/response_name);field='predicted_tm_c'if group=='stable'else'predicted_solubility'
            if (response.get('case_id')!=ident or response.get('full_sequence_length')!=len(record['sequence'])
                    or response.get(field)!=outcome.get(field)):raise ValueError('Proxy scalar/full-sequence identity differs')
        if group=='stable':thermal.append({'case_id':ident,'predicted_tm_c':outcome.get('predicted_tm_c')})
        else:sol.append({'case_id':ident,'property_group':group,'predicted_solubility':outcome.get('predicted_solubility')})
    contract=evaluator.load_contract(plan['proxy_contract'],plan['frozen_files_sha256'][plan['proxy_contract']])
    scores=read(evaluation/'scores.json')
    if (sha(evaluation/'scores.json')!=done['scores_sha256']or scores['planned']!=30 or scores['terminal']!=30
            or scores['generation_prediction_lock_sha256']!=generation_lock
            or scores['evaluator_prediction_lock_sha256']!=sha(evaluation/'prediction_lock.json')
            or scores['NetSolP_D']!=contract.summarize([c for c in cases if c['property_group']!='stable'],sol)
            or scores['DeepSTABp']!=contract.summarize_thermal([c['case_id']for c in cases if c['property_group']=='stable'],thermal)
            or scores['successes']!=sum(o['status']=='success'for o in outcomes)
            or scores['evaluator_attempts']!=sum(o['evaluator_attempted']for o in outcomes)
            or scores['evaluator_errors']!=sum(o['status']=='evaluator_error'for o in outcomes)
            or scores['not_evaluated']!=sum(not o['evaluator_attempted']for o in outcomes)
            or scores['full_proxy_condition_complete']!=(scores['successes']==30)
            or done['full_proxy_condition_complete']!=scores['full_proxy_condition_complete']
            or scores['native_NatureLM_score']is not False or scores['experimental_validation']is not False
            or scores['sequence_truncation']is not False):raise ValueError('Replayed full-denominator proxy score differs')
    return plan,scores,generated,run


def public_source_path(name,path):
    relative=Path(name);source=Path(path)
    blocked={'.local','assets','models','venv','site-packages','.ssh'}
    if (relative.is_absolute()or'..'in relative.parts or blocked.intersection(relative.parts)
            or relative.suffix not in {'.py','.json','.md','.sbatch','.fs'}
            or 'private_gpu'in name.lower()or source.is_symlink()or not source.is_file()
            or not source.resolve().is_relative_to(ROOT.resolve())):
        raise ValueError('Private, linked or non-source member is outside the source whitelist')


def archive(path,members,generated=None):
    if path.exists():raise FileExistsError('Preserve existing candidate archive')
    if any(Path(source).is_symlink()or not Path(source).is_file()for source in members.values()):
        raise ValueError('Public archive original members must be regular nonlinked files')
    values={name:Path(source).read_bytes()for name,source in members.items()}
    for name,value in (generated or {}).items():
        if name in values:raise ValueError('Generated archive member collision')
        values[name]=value
    manifest={'files':{name:{'sha256':hashlib.sha256(value).hexdigest(),'bytes':len(value)}for name,value in values.items()}}
    values['publication_manifest.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
    path.parent.mkdir(parents=True,exist_ok=True)
    with tarfile.open(path,'w:gz')as target:
        for name,value in sorted(values.items()):
            relative=Path(name)
            if relative.is_absolute()or'..'in relative.parts:raise ValueError('Unsafe public archive path')
            member=tarfile.TarInfo(name);member.size=len(value);member.mtime=0;member.mode=0o644
            target.addfile(member,io.BytesIO(value))
    return manifest


def generated_sources(plan):
    reference={'task_id':'P38','condition_id':plan['condition_id'],'plan_sha256':PLAN_SHA,
        'model':plan['model'],'generation':plan['generation'],'scientific_condition':plan['scientific_condition'],
        'CPU_packages':plan['CPU_packages'],'released_evaluator_weight_sha256':{Path(n).name:d for n,d in plan['weights_sha256'].items()},
        'omitted_private_operational_helper_sha256':{'project_gpu_audit_20261021.py':sha(plan['project_gpu_audit_helper'])},
        'native_NatureLM_score':False,'experimental_validation':False,'new_model_calls_by_packaging':0}
    runtime=EXEC/'runtime'
    evidence={name:read(runtime/name)for name in ['allocation_started.json','context_preflight.json','neutral_evaluator_gate/completion.json',
        'CPU_environment_neutral.json','CPU_environment_benchmark.json','own_Qwen_stopped_before_CPU_scores.json',
        'offline_proxy_scoring_completion.json','status.json']}
    identity=read(runtime/'server_identity.json')
    evidence['own_server']={name:identity[name]for name in ['job_id','model','condition','plan_sha256','server_command']}
    repair=EXEC/'offline_scoring_repair_v1'
    evidence['CPU_only_scoring_continuation']={name:read(repair/name)for name in
        ['submission_receipt.json','completion.json','neutral_evaluator_gate/completion.json']}
    evidence['private_full_account_inventory_included']=False
    evidence['complete_generated_length_statistics']=length_statistics(plan)
    return {name:(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()for name,value in
        [('model_and_condition_reference.json',reference),('own_execution_evidence.json',evidence)]}


def length_statistics(plan):
    import sys
    if str(EXEC)not in sys.path:sys.path.insert(0,str(EXEC))
    bootstrap_plan()
    admission=load('p38_publication_length_inputs',EXEC/'admission.py')
    cases=admission.verified_inputs(plan);folder=Path(plan['output_root'])/'benchmark'
    if sha(EXEC/'evaluate_locked.py')!=plan['frozen_files_sha256'][str(EXEC/'evaluate_locked.py')]:
        raise ValueError('Pure sequence verifier changed before import')
    evaluator=load('p38_publication_length_seal',EXEC/'evaluate_locked.py')
    records=evaluator.verified_sequences(cases,folder,sha(folder/'prediction_lock.json'))
    result={}
    for group in ['soluble','insoluble','stable']:
        values=[len(r['sequence'])for r in records if r['case']['property_group']==group and r['sequence_valid']]
        full=len(values)==10
        result[group]={'planned':10,'valid_complete_outputs':len(values),'full_group_mean_residues':sum(values)/10 if full else None,
            'full_group_minimum_residues':min(values)if full else None,'full_group_maximum_residues':max(values)if full else None}
    return result


def report_text(plan,scores,generated):
    source_path='results/protocol_artifacts/'+RUN+'_source.tar.gz'
    trajectory_path='results/trajectory_archives/'+RUN+'_trajectories.tar.gz'
    sol=scores['NetSolP_D']['per_group'];thermal=scores['DeepSTABp']
    def scalar(value):return 'undefined'if value is None else f'{value:.6f}'
    lengths=length_statistics(plan)
    def length_text(group):
        row=lengths[group]
        return ('undefined'if row['full_group_mean_residues']is None else
            f"{row['full_group_mean_residues']:.1f}; {row['full_group_minimum_residues']}–{row['full_group_maximum_residues']}")
    report=(f'# P38: 30 author-template outputs under a constrained proxy condition\n\n'
        f'Pinned local Qwen3.8-27B produced {generated["delivered"]}/30 valid deliveries. '
        f'Released substitute evaluators scored {scores["successes"]}/30 complete outputs. '
        f'All 30 slots remain in the denominators; each property has ten planned templates.\n\n'
        f'| Requested property | Evaluated / planned | Full-group proxy mean | Complete length: mean; range |\n|---|---:|---:|---:|\n'
        f'| Soluble | {sol["soluble"]["evaluable"]}/10 | {scalar(sol["soluble"]["full_group_mean_desired_proxy"])} | {length_text("soluble")} |\n'
        f'| Insoluble | {sol["insoluble"]["evaluable"]}/10 | {scalar(sol["insoluble"]["full_group_mean_desired_proxy"])} | {length_text("insoluble")} |\n'
        f'| Stable | {thermal["evaluable"]}/10 | {scalar(thermal["full_cohort_mean_predicted_tm_c"])} °C predicted Tm | {length_text("stable")} |\n\n'
        'Solubility means use NetSolP-D probability for soluble prompts and one minus that probability for insoluble prompts. '
        'The stability value is DeepSTABp predicted melting temperature under a shared hypothetical 37°C growth/Lysate context. '
        'A missing full-group mean is undefined because coverage is incomplete.\n\n'
        'The exact published question wording was retained, with one generation per template and a prospective 16,384-token output budget. '
        'A bare canonical amino-acid output of 1–1022 residues was imposed by grammar. This changes the generation distribution; '
        'format validity is imposed and is not a capability score. Complete outputs were retained without cropping or selective retries.\n\n'
        'The acceptance rule admits one-residue strings, and each requested-property group contains such an output. '
        'Successful delivery and predictor execution do not validate a full functional protein; predictor applicability to these very short strings is unassessed.\n\n'
        'After all 30 generations were sealed and the own Qwen server stopped, a duplicate audit filename caused the generation allocation to exit. '
        'A separately reviewed CPU-only continuation passed a fresh artificial resource gate and scored the same locked outputs once; no sequence was regenerated.\n\n'
        'These are substitute predictor outputs. The inspected release did not supply the original NatureLM property heads, '
        'natural-control cohort or generation allocation. This condition does not reproduce the native NatureLM score or a matched '
        'paper comparison, and does not establish experimental stability, solubility or biological function. '
        'Without a natural or unconditional control, these values do not measure gains from conditioning. Public pretraining exposure is unknown.\n\n'
        f'[Complete source and protocol](https://github.com/Some-random/bio-evaluation/blob/main/{source_path}) · '
        f'[All saved trajectories](https://github.com/Some-random/bio-evaluation/blob/main/{trajectory_path})\n')
    return report


def package(admission_path,admission_sha):
    plan,scores,generated,run=verify(admission_path,admission_sha)
    stage=HERE/'stage'
    if stage.exists():raise FileExistsError('Preserve existing publication candidate')
    prefix='results/runs/'+RUN+'/'
    source={str(p.relative_to(ROOT)):p for p in [*EXEC.glob('*.py'),EXEC/'worker.sbatch',EXEC/'plan.json',
        EXEC/'CPU_validation.json',EXEC/'checkpoint_CPU_validation.json',
        HERE.parent/'proxy_contract.py',HERE.parent/'engineering_20261020/evaluator_runtime.py',
        HERE.parent/'solubility_proxy_prompt_manifest.json',HERE.parent/'thermal_proxy_prompt_manifest.json',
        HERE.parent/'exact_condition_availability.json',HERE/'package.py',HERE/'publish.py',HERE/'test_publication.py']}
    source[str((HERE/'preoutput_source_freeze.json').relative_to(ROOT))]=HERE/'preoutput_source_freeze.json'
    source[str((HERE/'post_generation_recovery_source_freeze.json').relative_to(ROOT))]=HERE/'post_generation_recovery_source_freeze.json'
    source[str((HERE/'post_generation_recovery_source_freeze_v2.json').relative_to(ROOT))]=HERE/'post_generation_recovery_source_freeze_v2.json'
    # Public source only: no evaluator/model weights, runtime archives, account
    # inventory, environment dumps or credentials enter either member map.
    source={name.removeprefix('.local/catalog_execution_2026-10-20/tasks/P38/'):path for name,path in source.items()}
    for name in plan['frozen_files_sha256']:
        p=Path(name)
        if p.is_relative_to(HERE.parent/'sources')and p.suffix in {'.py','.fs','.json'}:
            source[str(p.relative_to(HERE.parent))]=p
    source['shared_runtime/runtime_common.py']=Path(plan['runtime_common'])
    source['execution_admission/root_admission.json']=Path(admission_path)
    grant=read(admission_path)
    if grant.get('root_scientific_adoption_path'):
        adopted=Path(grant['root_scientific_adoption_path'])
        if sha(adopted)!=grant['root_scientific_adoption_sha256']:
            raise ValueError('Bound root scientific adoption changed')
        source['execution_admission/root_scientific_adoption.json']=adopted
    peer=HERE.parent/'resume_peer_review_p37_delivery_20261021.json'
    source['execution_admission/independent_technical_review.json']=peer
    repair=EXEC/'resume_partition_repair_20261021'
    for name in ['reconciliation.json','independent_operational_review_p37_delivery.json','submission_receipt.json']:
        source['execution_admission/partition_repair_'+name]=repair/name
    repair=EXEC/'offline_scoring_repair_v1';submission=read(repair/'submission_receipt.json')
    for path in [*sorted(repair.glob('*.py')),repair/'CPU.sbatch',repair/'plan.json',repair/'reconciliation.json',
            Path(submission['review_path']),repair/'submission_receipt.json',repair/'completion.json']:
        source['execution_admission/CPU_scoring_continuation/'+path.name]=path
    for name,path in source.items():public_source_path(name,path)
    trajectories={}
    for phase in ['development','benchmark','evaluation']:
        folder=run/phase
        for p in folder.rglob('*'):
            if p.is_file():trajectories[phase+'/'+str(p.relative_to(folder))]=p
    source_path='results/protocol_artifacts/'+RUN+'_source.tar.gz'
    trajectory_path='results/trajectory_archives/'+RUN+'_trajectories.tar.gz'
    source_members=archive(stage/source_path,source,generated_sources(plan))
    trajectory_members=archive(stage/trajectory_path,trajectories)
    for name,path in [('scores.json',run/'evaluation/scores.json'),('generation_completion.json',run/'benchmark/completion.json'),
                      ('generation_prediction_lock.json',run/'benchmark/prediction_lock.json'),
                      ('evaluator_prediction_lock.json',run/'evaluation/prediction_lock.json')]:
        target=stage/(prefix+name);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(path.read_bytes())
    report=report_text(plan,scores,generated)
    report_path='reports/P38_AUTHOR30_PROXY_RESULT.md';target=stage/report_path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(report)
    (stage/(prefix+'README.md')).write_text(report)
    save(stage/(prefix+'artifact_manifest.json'),{'task_id':'P38','run_id':RUN,'plan_sha256':PLAN_SHA,
        'score_sha256':sha(run/'evaluation/scores.json'),'source_archive':{'path':source_path,'sha256':sha(stage/source_path)},
        'trajectory_archive':{'path':trajectory_path,'sha256':sha(stage/trajectory_path)},
        'generation_lock_sha256':sha(run/'benchmark/prediction_lock.json'),'evaluator_lock_sha256':sha(run/'evaluation/prediction_lock.json')})
    paths={str(p.relative_to(stage)):sha(p)for p in stage.rglob('*')if p.is_file()}
    save(HERE/'candidate.json',{'at_pacific':stamp(),'task_id':'P38','owner':'/root/p38_generation',
        'repository':'Some-random/bio-evaluation','visibility':'public','plan_sha256':PLAN_SHA,'run_id':RUN,
        'stage_directory':str(stage),'files_sha256':paths,'source_archive_members':source_members['files'],
        'trajectory_archive_members':trajectory_members['files'],'admission_path':str(admission_path),'admission_sha256':admission_sha,
        'private_source_mapping':{name:str(path)for name,path in source.items()},
        'private_trajectory_mapping':{name:str(path)for name,path in trajectories.items()},
        'support_sha256':{str(p):sha(p)for p in [HERE/'package.py',HERE/'publish.py',ROOT/'scripts/daily_backup.py',
            ROOT/'.local/litqa2_replay/incremental_upload.py',ROOT/'.local/litqa2_replay/github_credential_helper.py',
            ROOT/'configs/publication_destination.json',ROOT/'scripts/publication_destination.py',
            ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review_resume_v2.json']},
        'planned':30,'native_NatureLM_score':False,'experimental_validation':False,
        'new_model_calls':0,'weights_environments_credentials_or_full_account_metadata_included':False,
        'shared_aggregate_reports_modified':False,'website_or_schedule_changes':False})
    print(json.dumps({'stage':'offline_candidate_prepared','paths':len(paths),'plan_sha256':PLAN_SHA,'model_calls':0}))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--admission',type=Path,required=True);parser.add_argument('--admission-sha256',required=True)
    args=parser.parse_args();package(args.admission,args.admission_sha256)
