"""Artificial30-case raw-generation and recording-oracle checks, no models."""
from pathlib import Path
import hashlib
import json
import tempfile
import unittest
import evaluate_locked as runner
import protocol


def fixture(root,long_index=None,invalid_index=None):
    cases=[];rows=[];folder=root/'generation';folder.mkdir();files={}
    for i in range(30):
        group='soluble' if i<10 else 'insoluble' if i<20 else 'stable'
        ident='ARTIFICIAL-'+str(i).zfill(2)
        cases.append({'case_id':ident,'property_group':group,'prompt':'Artificial fixed alphabet task '+str(i)})
        request=folder/('request_'+str(i)+'.json');request.write_text(json.dumps(protocol.payload(cases[-1],i)))
        files[request.name]=runner.sha(request)
        sequence='ACDEFGHIKLMNPQRSTVWY' if i!=long_index else 'A'*1023
        text=sequence if i!=invalid_index else 'not a canonical sequence'
        path=folder/('response_'+str(i)+'.json');path.write_text(json.dumps({'choices':[{
            'message':{'content':text},'finish_reason':'stop'}]}))
        files[path.name]=runner.sha(path)
        rows.append({'case_id':ident,'status':'response','response_file':path.name,
            'response_sha256':files[path.name],
            'request_file':request.name,'request_sha256':files[request.name],
            'sequence_sha256':hashlib.sha256(sequence.encode()).hexdigest()})
    runner.save(folder/'terminal_records.json',rows);files['terminal_records.json']=runner.sha(folder/'terminal_records.json')
    runner.save(folder/'prediction_lock.json',{'planned_case_ids':[c['case_id'] for c in cases],
        'reference_targets_present':False,'files_sha256':files})
    return cases,folder,runner.sha(folder/'prediction_lock.json')


class Recording:
    def __init__(self,error_at=None,wrong_identity=False):self.calls=[];self.error_at=error_at;self.wrong_identity=wrong_identity
    def __call__(self,ident,sequence):
        self.calls.append((ident,sequence))
        if ident==self.error_at:raise RuntimeError('Artificial evaluator failure')
        return {'case_id':ident if not self.wrong_identity else 'foreign','full_sequence_length':len(sequence),
            'sequence_sha256':hashlib.sha256(sequence.encode()).hexdigest(),
            'predicted_solubility':.8,'predicted_tm_c':42.}


class Checks(unittest.TestCase):
    def contract(self):
        p=runner.TASK/'proxy_contract.py';return runner.load_contract(p,runner.sha(p))
    def evaluate(self,cases,folder,seal,output,oracle=None,**kw):
        oracle=oracle or Recording()
        return runner.evaluate_once(cases,folder,output,seal,self.contract(),oracle,oracle,**kw)
    def test_full30_denominator_native_proxy_aggregators_and_one_attempt(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);cases,folder,seal=fixture(root);oracle=Recording()
            result=self.evaluate(cases,folder,seal,root/'evaluation',oracle)
            self.assertEqual(len(oracle.calls),30);self.assertTrue(result['full_proxy_condition_complete'])
            self.assertAlmostEqual(result['NetSolP_D']['per_group']['soluble']['full_group_mean_desired_proxy'],.8)
            self.assertAlmostEqual(result['NetSolP_D']['per_group']['insoluble']['full_group_mean_desired_proxy'],.2)
            self.assertEqual(result['DeepSTABp']['full_cohort_mean_predicted_tm_c'],42.)
            self.assertFalse(result['native_NatureLM_score']);self.assertFalse(result['experimental_validation'])
            with self.assertRaises(FileExistsError):self.evaluate(cases,folder,seal,root/'evaluation',oracle)
            self.assertEqual(len(oracle.calls),30)
    def test_changed_raw_or_unsealed_extra_rejected_before_oracle(self):
        for extra in [False,True]:
            with tempfile.TemporaryDirectory() as td:
                root=Path(td);cases,folder,seal=fixture(root);oracle=Recording()
                if extra:(folder/'extra.json').write_text('{}')
                else:(folder/'response_0.json').write_text('{}')
                with self.assertRaises(ValueError):self.evaluate(cases,folder,seal,root/'evaluation',oracle)
                self.assertFalse(oracle.calls)
    def test_missing_and_foreign_terminal_case_refused(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);cases,folder,seal=fixture(root)
            with self.assertRaises(ValueError):self.evaluate(cases[:-1],folder,seal,root/'evaluation')
    def test_unsealed_nested_file_cannot_hide_behind_progress_filename(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);cases,folder,seal=fixture(root);oracle=Recording()
            nested=folder/'unsealed';nested.mkdir();(nested/'progress.json').write_text('{}')
            with self.assertRaisesRegex(ValueError,'Unsealed generation artifact'):
                self.evaluate(cases,folder,seal,root/'evaluation',oracle)
            self.assertFalse(oracle.calls)
    def test_resealed_request_for_another_prompt_refused_before_oracle(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);cases,folder,seal=fixture(root);oracle=Recording()
            request=folder/'request_0.json';body=json.loads(request.read_text())
            body['messages'][0]['content']='Foreign artificial task';request.write_text(json.dumps(body))
            rows=json.loads((folder/'terminal_records.json').read_text())
            rows[0]['request_sha256']=runner.sha(request)
            (folder/'terminal_records.json').write_text(json.dumps(rows))
            lock=json.loads((folder/'prediction_lock.json').read_text())
            lock['files_sha256'][request.name]=runner.sha(request)
            lock['files_sha256']['terminal_records.json']=runner.sha(folder/'terminal_records.json')
            (folder/'prediction_lock.json').write_text(json.dumps(lock))
            with self.assertRaisesRegex(ValueError,'exact author-template'):
                self.evaluate(cases,folder,runner.sha(folder/'prediction_lock.json'),root/'evaluation',oracle)
            self.assertFalse(oracle.calls)
    def test_invalid_generation_retains_entire_group_denominator(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);cases,folder,seal=fixture(root,invalid_index=0);oracle=Recording()
            result=self.evaluate(cases,folder,seal,root/'evaluation',oracle)
            self.assertEqual(len(oracle.calls),29);self.assertEqual(result['not_evaluated'],1)
            self.assertEqual(result['NetSolP_D']['per_group']['soluble']['planned'],10)
            self.assertIsNone(result['NetSolP_D']['per_group']['soluble']['full_group_mean_desired_proxy'])
    def test_complete_overlength_is_never_cropped_or_sent_to_NetSolP(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);cases,folder,seal=fixture(root,long_index=0);oracle=Recording()
            result=self.evaluate(cases,folder,seal,root/'evaluation',oracle)
            self.assertEqual(len(oracle.calls),29);self.assertFalse(result['full_proxy_condition_complete'])
            rows=json.loads((root/'evaluation/terminal_records.json').read_text())
            self.assertEqual(rows[0]['complete_sequence_length'],1023);self.assertFalse(rows[0]['sequence_truncated'])
    def test_evaluator_failure_stops_new_calls_and_seals_all30(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);cases,folder,seal=fixture(root);oracle=Recording(error_at=cases[0]['case_id'])
            result=self.evaluate(cases,folder,seal,root/'evaluation',oracle)
            self.assertEqual(len(oracle.calls),1);self.assertEqual(result['terminal'],30)
            self.assertEqual(result['evaluator_errors'],1);self.assertEqual(result['not_evaluated'],29)
            self.assertFalse(result['full_proxy_condition_complete']);self.assertIsNone(result['DeepSTABp']['full_cohort_mean_predicted_tm_c'])
    def test_wrong_identity_is_error_without_retry(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);cases,folder,seal=fixture(root);oracle=Recording(wrong_identity=True)
            result=self.evaluate(cases,folder,seal,root/'evaluation',oracle)
            self.assertEqual(len(oracle.calls),1);self.assertEqual(result['evaluator_errors'],1)
    def test_thermal_resource_ceiling_is_explicit_and_no_sequence_truncation(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);cases,folder,seal=fixture(root,long_index=20);oracle=Recording()
            result=self.evaluate(cases,folder,seal,root/'evaluation',oracle,thermal_maximum_residues=1022)
            self.assertEqual(len(oracle.calls),29);self.assertEqual(result['declared_thermal_resource_ceiling'],1022)
            self.assertFalse(result['sequence_truncation']);self.assertIsNone(result['DeepSTABp']['full_cohort_mean_predicted_tm_c'])


if __name__=='__main__':unittest.main()
