"""Exact full author-template tokenizer/context validation, zero forwards."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import json
import os
import re
import time
import protocol
from generation import stamp,write

HERE=Path(__file__).resolve().parent
TOKENIZER=Path('/dfs/scratch0/tchen/models/Qwen3.8-27B')
EXPECTED='0997f410c57a1f4e53b09e4be8f4a172d90edd9564368fb0847030937229b9f3'


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    if os.environ.get('CUDA_VISIBLE_DEVICES')!='':raise ValueError('CPU-only tokenizer check required')
    if hashlib.sha256((TOKENIZER/'tokenizer.json').read_bytes()).hexdigest()!=EXPECTED:
        raise ValueError('Exact Qwen tokenizer release changed')
    from transformers import AutoTokenizer
    tokenizer=AutoTokenizer.from_pretrained(str(TOKENIZER),local_files_only=True)
    cases=[];sources={}
    for name in ['solubility_proxy_prompt_manifest.json','thermal_proxy_prompt_manifest.json']:
        path=HERE.parent/name;data=path.read_bytes();sources[str(path)]=hashlib.sha256(data).hexdigest()
        cases.extend(json.loads(data)['cases'])
    rows=[];start=time.monotonic()
    for phase,items in [('benchmark',cases),('development',protocol.development_cases())]:
        for index,item in enumerate(items):
            body=protocol.payload(item,index,development=phase=='development')
            rendered=tokenizer.apply_chat_template(body['messages'],tokenize=False,add_generation_prompt=True,
                **body['chat_template_kwargs'])
            if body['messages'][0]['content']not in rendered:raise ValueError('Complete exact question disappeared')
            ids=tokenizer.apply_chat_template(body['messages'],tokenize=True,return_dict=True,
                truncation=False,add_generation_prompt=True,**body['chat_template_kwargs'])['input_ids']
            if ids and isinstance(ids[0],list):ids=ids[0]
            if len(ids)+16384>65536:raise ValueError('Complete input/output context exceeds prospective limit')
            rows.append({'phase':phase,'case_id':item['case_id'],'prompt_tokens':len(ids),
                'rendered_prompt_sha256':hashlib.sha256(rendered.encode()).hexdigest()})
    lengths=[]
    for sequence in ['A','ACDEFGHIKLMNPQRSTVWY',('ACDEFGHIKLMNPQRSTVWY'*52)[:1022]]:
        if re.fullmatch(protocol.PATTERN,sequence)is None:raise ValueError('Declared language excludes artificial boundary')
        ids=tokenizer.encode(sequence,add_special_tokens=False)
        if tokenizer.decode(ids,skip_special_tokens=False)!=sequence or len(ids)+1>16384:
            raise ValueError('Exact canonical boundary cannot be represented completely within output cap')
        lengths.append({'residues':len(sequence),'ordinary_tokens':len(ids)})
    receipt={'at_pacific':stamp(),'stage':'full32_exact_tokenizer_context_check_passed_unadmitted',
        'model':'Qwen/Qwen3.8-27B','model_revision':'1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0',
        'tokenizer_sha256':EXPECTED,'transformers_version':importlib.metadata.version('transformers'),
        'all30_native_and2_neutral_fit':True,'per_case':rows,'output_boundaries':lengths,
        'input_manifests_sha256':sources,'model_forwards':0,'solver_model_calls':0,'GPU_allocations':0,
        'output_tokens':16384,'scientific_condition_adopted':False,
        'vllm_engine_or_structured_grammar_compiled':False,'actual_vllm032_HTTP_API_and_regex_gate_required':True,
        'elapsed_seconds':time.monotonic()-start}
    write(args.output,receipt);print(json.dumps({k:receipt[k]for k in ['stage','all30_native_and2_neutral_fit','model_forwards','elapsed_seconds']}))


if __name__=='__main__':main()
