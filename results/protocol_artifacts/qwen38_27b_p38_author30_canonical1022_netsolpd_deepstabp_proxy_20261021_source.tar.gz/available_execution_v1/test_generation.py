"""Artificial transport and locked-evaluator integration; no model calls."""
from pathlib import Path
import hashlib
import json
import tempfile
import unittest

import evaluate_locked
import generation
import protocol


def cases():
    return [{'case_id':f'ARTIFICIAL-{i:02d}',
        'property_group':'soluble' if i<10 else 'insoluble' if i<20 else 'stable',
        'prompt':f'Artificial fixed alphabet task {i}'} for i in range(30)]


def reply(text='ACDEFGHIKLMNPQRSTVWY',finish='stop',**fields):
    return json.dumps({'choices':[{'message':{'content':text,**fields},'finish_reason':finish}]}).encode()


class Recording:
    def __init__(self,failure=None,at=0):self.calls=[];self.failure=failure;self.at=at
    def __call__(self,ident,payload):
        self.calls.append((ident,payload))
        if len(self.calls)-1==self.at and self.failure is not None:
            if isinstance(self.failure,Exception):raise self.failure
            return self.failure
        return reply()


class Tests(unittest.TestCase):
    def test_full30_actual_raw_request_lock_to_two_offline_aggregators(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);transport=Recording();items=cases()
            completion=generation.run(items,root/'generation',transport,'a'*64)
            self.assertEqual(completion['attempted_confirmed'],30)
            self.assertEqual(completion['responses_saved'],30)
            self.assertEqual(completion['closed_slots'],30)
            self.assertTrue(completion['all_delivered'])
            observed=[]
            def oracle(ident,sequence):
                observed.append(ident)
                return {'case_id':ident,'full_sequence_length':len(sequence),
                    'sequence_sha256':hashlib.sha256(sequence.encode()).hexdigest(),
                    'predicted_solubility':.75,'predicted_tm_c':42.}
            contract_path=evaluate_locked.TASK/'proxy_contract.py'
            contract=evaluate_locked.load_contract(contract_path,evaluate_locked.sha(contract_path))
            scores=evaluate_locked.evaluate_once(items,root/'generation',root/'evaluation',
                completion['prediction_lock_sha256'],contract,oracle,oracle)
            self.assertEqual(observed,[c['case_id'] for c in items])
            self.assertTrue(scores['full_proxy_condition_complete'])
            self.assertAlmostEqual(scores['NetSolP_D']['per_group']['insoluble']['full_group_mean_desired_proxy'],.25)
            self.assertEqual(scores['DeepSTABp']['full_cohort_mean_predicted_tm_c'],42.)
            self.assertFalse(scores['experimental_validation'])

    def test_malformed_json_has_unknown_final_stops_and_retains_all_slots(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td)/'phase';transport=Recording(b'{',at=2)
            completion=generation.run(cases(),folder,transport,'a'*64)
            self.assertEqual(len(transport.calls),3)
            self.assertEqual(completion['responses_saved'],3)
            self.assertEqual(completion['response_errors'],1)
            self.assertEqual(completion['unknown_finals'],1)
            self.assertEqual(completion['empty_finals'],0)
            self.assertEqual(completion['not_dispatched'],27)
            self.assertEqual(completion['closed_slots'],30)
            records=json.loads((folder/'terminal_records.json').read_text())
            self.assertEqual([r['case_id'] for r in records],[c['case_id'] for c in cases()])
            self.assertTrue(all(r['status']=='not_dispatched' for r in records[3:]))
            with self.assertRaises(FileExistsError):generation.run(cases(),folder,transport,'a'*64)
            self.assertEqual(len(transport.calls),3)

    def test_HTTP503_body_preserved_without_observed_empty_final(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td)/'phase';body=b'Artificial server unavailable'
            transport=Recording(generation.TransportError('HTTP503',503,body))
            completion=generation.run(cases(),folder,transport,'a'*64)
            self.assertEqual(len(transport.calls),1)
            self.assertEqual(completion['HTTP_errors'],1)
            self.assertEqual(completion['server_errors'],1)
            self.assertEqual(completion['responses_saved'],0)
            self.assertEqual(completion['unknown_finals'],1)
            self.assertEqual(completion['empty_finals'],0)
            error_files=list((folder/'errors').glob('*.raw'))
            self.assertEqual(len(error_files),1);self.assertEqual(error_files[0].read_bytes(),body)

    def test_unexpected_local_transport_failure_seals_full_denominator(self):
        with tempfile.TemporaryDirectory() as td:
            transport=Recording(RuntimeError('Artificial client failure'))
            completion=generation.run(cases(),Path(td)/'phase',transport,'a'*64)
            self.assertEqual(completion['client_or_guard_errors'],1)
            self.assertEqual(completion['unknown_finals'],1)
            self.assertEqual(completion['empty_finals'],0)
            self.assertEqual(completion['closed_slots'],30)
            self.assertEqual(completion['not_dispatched'],29)

    def test_explicit_null_empty_final_is_observed(self):
        with tempfile.TemporaryDirectory() as td:
            result=generation.run(cases(),Path(td)/'phase',Recording(reply(None)),'a'*64)
            self.assertEqual(result['empty_finals'],1);self.assertEqual(result['unknown_finals'],0)
            self.assertFalse(result['all_delivered'])

    def test_refusal_reasoning_tools_and_length_all_stop_before_next_send(self):
        for raw,field in [(reply(refusal='Artificial refusal'),'refusals'),
                          (reply(reasoning='Artificial reasoning'),'reasoning_present'),
                          (reply(reasoning_content='Artificial reasoning'),'reasoning_present'),
                          (reply(tool_calls=[{'name':'artificial'}]),None),
                          (reply(finish='length'),'truncations')]:
            with self.subTest(field=field),tempfile.TemporaryDirectory() as td:
                transport=Recording(raw)
                result=generation.run(cases(),Path(td)/'phase',transport,'a'*64)
                self.assertEqual(len(transport.calls),1)
                if field:self.assertEqual(result[field],1)
                self.assertEqual(result['not_dispatched'],29);self.assertFalse(result['all_delivered'])

    def test_development_mismatch_stops_and_never_sends_second_slot(self):
        with tempfile.TemporaryDirectory() as td:
            transport=Recording(reply('A'))
            result=generation.run(cases()[:2],Path(td)/'phase',transport,'a'*64,development=True)
            self.assertEqual(len(transport.calls),1);self.assertEqual(result['closed_slots'],2)
            self.assertEqual(result['response_errors'],1);self.assertEqual(result['not_dispatched'],1)
            self.assertTrue(result['development_only'])

    def test_invalid_late_input_prevents_any_phase_or_request_creation(self):
        with tempfile.TemporaryDirectory() as td:
            items=cases();items[-1]['prompt']='';transport=Recording();folder=Path(td)/'phase'
            with self.assertRaises(ValueError):generation.run(items,folder,transport,'a'*64)
            self.assertFalse(transport.calls);self.assertFalse(folder.exists())

    def test_declared_length_rule_preserves_boundary_and_never_crops(self):
        self.assertEqual(protocol.interpret(reply('A'*1022))['sequence_length'],1022)
        result=protocol.interpret(reply('A'*1023))
        self.assertEqual(result['status'],'invalid_sequence');self.assertIsNone(result['sequence'])
        for index,item in enumerate(cases()):
            body=protocol.payload(item,index)
            self.assertEqual(body['messages'][0]['content'],item['prompt'])
            self.assertEqual(body['max_tokens'],16384)
            self.assertEqual(body['structured_outputs']['regex'],protocol.PATTERN)


if __name__=='__main__':unittest.main()
