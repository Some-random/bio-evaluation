"""Unadmitted available P38 proxy proposal; exact author questions stay intact."""
import hashlib
import json
import re

CONDITION='P38_QWEN_AUTHOR30_CANONICAL1022_NETSOLPD_DEEPSTABP_PROXY_PROPOSAL_V1'
MODEL='Qwen/Qwen3.8-27B'
PATTERN='[ACDEFGHIKLMNPQRSTVWY]{1,1022}'
DEVELOPMENT=('ACDEFGHIKLMNPQRSTVWY','YWVTSRQPNMLKIHGFEDCA')


def development_cases():
    return [{'case_id':f'P38-NEUTRAL-DEV-{i:04d}'}for i in range(2)]


def digest(data):return hashlib.sha256(data).hexdigest()


def payload(case,index,development=False):
    if not isinstance(index,int) or isinstance(index,bool) or index<0:
        raise ValueError('Exact nonnegative slot index required')
    if development:
        if index>=2:raise ValueError('Exactly two artificial development inputs')
        text='Return this artificial alphabet sequence verbatim, with no surrounding prose: '+DEVELOPMENT[index]
    else:
        if set(case)!={'case_id','property_group','prompt'} or case['property_group'] not in {'soluble','insoluble','stable'}:
            raise ValueError('Exact frozen author-template input required')
        text=case['prompt']
        if not isinstance(text,str) or not text:raise ValueError('Complete native prompt required')
    return {'model':MODEL,'messages':[{'role':'user','content':text}],
        'temperature':1.,'top_p':.95,'top_k':20,'seed':200042+index if development else 42+index,
        'max_tokens':16384,'n':1,'stream':False,'chat_template_kwargs':{'enable_thinking':False},
        'structured_outputs':{'regex':PATTERN}}


def interpret(raw):
    result={'status':'response_error','observed_final':False,'empty_final':False,
        'sequence':None,'truncated':False,'refusal':False,'reasoning_present':False,
        'tool_calls_present':False,'response_error':True}
    try:
        body=json.loads(raw)
        if not isinstance(body,dict) or not isinstance(body.get('choices'),list) or len(body['choices'])!=1:
            raise ValueError('One choice required')
        choice=body['choices'][0]
        if not isinstance(choice,dict) or not isinstance(choice.get('message'),dict):
            raise ValueError('Exact choice/message mappings required')
        message=choice['message'];text=message['content'];finish=choice.get('finish_reason')
        if not isinstance(text,(str,type(None))):raise ValueError('Text or explicit null final required')
        result.update(observed_final=True,empty_final=text is None or not text.strip(),
            finish_reason=finish,truncated=finish=='length',refusal=bool(message.get('refusal')),
            reasoning_present=bool(message.get('reasoning') or message.get('reasoning_content')),
            tool_calls_present=bool(message.get('tool_calls')),response_error=False)
        if (finish!='stop' or result['empty_final'] or result['refusal'] or result['reasoning_present']
                or result['tool_calls_present']):
            result['status']='invalid_delivery';return result
        if not re.fullmatch(PATTERN,text):
            result.update(status='invalid_sequence',response_error=True);return result
        result.update(status='response',sequence=text,sequence_sha256=digest(text.encode()),sequence_length=len(text))
    except (ValueError,TypeError,KeyError,IndexError):
        pass
    return result
