"""Unadmitted runnable P38 proposal: exact30, own Qwen, CPU proxy scores.

This file grants no scientific or model-dispatch permission. An independently
signed, exact plan admission must adopt the declared substitute endpoints and
the imposed 1..1022-residue output language before main can allocate a server.
"""
from pathlib import Path
import argparse
import fcntl
import importlib.metadata
import importlib.util
import json
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request

from admission import sha,validate,verified_inputs
from generation import ResponseGuardError,TransportError,run,stamp,write
import protocol

HERE=Path(__file__).resolve().parent
PACKAGES={'vllm':'0.32.0','torch':'2.13.0','transformers':'5.17.0','triton':'3.7.1','flashinfer-python':'0.7.0.post1'}


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module


def project_audit(plan):
    path=plan['project_gpu_audit_helper']
    if sha(path)!=plan['frozen_files_sha256'][path]:raise ValueError('Pinned project GPU helper changed')
    # The helper treats unknown jobs conservatively and verifies one own GPU.
    audit=load('p38_root_pinned_GPU_helper',path).conservative_project_gpu_audit(require_own_job=True)
    result=subprocess.run(['/usr/local/bin/scontrol','show','job','-o',os.environ['SLURM_JOB_ID']],
        text=True,capture_output=True,check=True,timeout=30).stdout
    fields=dict(re.findall(r'(?:^|\s)(\w+)=([^\s]*)',result))
    if (fields.get('WorkDir')!=plan['project_root'] or
            fields.get('Command')!=str(HERE/'worker.sbatch')):
        raise ValueError('Own one-GPU allocation is not this exact P38 worker')
    return audit


def Qwen_environment(common,local):
    env=common.environment(local)
    for name in list(env):
        if re.search(r'API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL',name,re.I) or name in {
            'SSH_AUTH_SOCK','NETRC','KUBECONFIG','PYTHONHOME','PYTHONPATH','VIRTUAL_ENV',
            'OPENAI_BASE_URL','OPENAI_PROJECT_ID','OPENAI_ORG_ID','GOOGLE_APPLICATION_CREDENTIALS'}:
            env.pop(name,None)
    env.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',
        VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1',VLLM_USE_V2_MODEL_RUNNER='0',PYTHONPATH=str(HERE),
        PIP_INDEX_URL='https://pypi.org/simple',PIP_EXTRA_INDEX_URL='',PIP_CONFIG_FILE='/dev/null')
    return env


def CPU_environment(root):
    # Entirely separate Python/Torch build. No inherited Qwen compiler or CUDA
    # library variables; no API keys, user site or host Python packages.
    return {'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C.UTF-8','TZ':'America/Los_Angeles',
        'PYTHONHOME':str(root/'python'),'PYTHONPATH':str(root/'site-packages')+':'+str(HERE),
        'LD_LIBRARY_PATH':str(root/'python/lib')+':'+str(root/'site-packages/torch/lib'),
        'PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','CUDA_VISIBLE_DEVICES':'',
        'OMP_NUM_THREADS':'4','MKL_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4',
        'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_HUB_DISABLE_TELEMETRY':'1',
        'DO_NOT_TRACK':'1','SLURM_JOB_ID':os.environ['SLURM_JOB_ID']}


def restore_CPU(plan,directory):
    manifest=json.loads(Path(plan['CPU_runtime_manifest']).read_text())
    if sha(manifest['archive'])!=manifest['archive_sha256']:raise ValueError('Portable CPU archive differs')
    directory.mkdir()
    with tarfile.open(manifest['archive']) as archive:archive.extractall(directory,filter='data')
    for name,entry in manifest['files'].items():
        target=(directory/name).resolve()
        if (Path(name).is_absolute() or '..' in Path(name).parts or not target.is_relative_to(directory)
                or sha(target)!=entry['sha256']):raise ValueError('Portable CPU runtime member differs')
    return manifest


def install_Qwen(python,env,runtime):
    command=[str(python),'-m','pip','install','--index-url','https://pypi.org/simple','--only-binary=:all:',
        '--break-system-packages','--upgrade',*[name+'=='+version for name,version in PACKAGES.items()],
        '--report',str(runtime/'pip_install_report.json')]
    with (runtime/'runtime_install.log').open('x') as log:
        subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=2400)
    with (runtime/'pip_check.log').open('x') as log:
        subprocess.run([str(python),'-m','pip','check'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)


class OwnTransport:
    def __init__(self,plan,identity,common):
        self.plan=plan;self.identity=Path(identity);self.identity_sha=sha(identity);self.common=common
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def __call__(self,ident,body):
        if sha(self.identity)!=self.identity_sha:raise ValueError('Own server identity changed')
        source=json.loads(self.identity.read_text())
        if (source['job_id']!=os.environ['SLURM_JOB_ID'] or source['hostname']!=socket.gethostname() or
                source['proc_start_ticks']!=self.common.start_ticks(source['pid']) or
                source['condition']!=protocol.CONDITION or source['model']!=protocol.MODEL or
                body['model']!=protocol.MODEL or body['max_tokens']!=16384 or
                body.get('structured_outputs')!={'regex':protocol.PATTERN}):
            raise ValueError('Request does not belong to the admitted own Qwen server')
        request=urllib.request.Request(self.plan['endpoint']+'/chat/completions',data=json.dumps(body).encode(),
            headers={'Content-Type':'application/json'})
        try:
            with self.opener.open(request,timeout=1800) as response:
                raw=response.read(self.plan['maximum_response_bytes']+1)
                if len(raw)>self.plan['maximum_response_bytes']:
                    raise ResponseGuardError('Response exceeded frozen byte guard',raw)
                return raw
        except urllib.error.HTTPError as error:
            raise TransportError('HTTP_response_error',error.code,error.read(self.plan['maximum_response_bytes']+1)) from error
        except (urllib.error.URLError,TimeoutError,OSError) as error:
            raise TransportError(type(error).__name__) from error


def stop_server(server):
    if server is not None and server.poll() is None:
        os.killpg(server.pid,signal.SIGTERM)
        try:server.wait(timeout=60)
        except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait(timeout=10)


def CPU_phase(plan,args,mode,local,runtime):
    write(runtime/('private_GPU_audit_before_'+mode+'.json'),project_audit(plan))
    root=local/'CPU'
    command=[str(root/'python/bin/python3.12'),str(HERE/'score_worker.py'),
        '--plan',str(args.plan),'--plan-sha256',args.plan_sha256,
        '--admission',str(args.admission),'--admission-sha256',args.admission_sha256,'--mode',mode]
    with (runtime/('CPU_'+mode+'.log')).open('x') as log:
        subprocess.run(command,env=CPU_environment(root),stdout=log,stderr=subprocess.STDOUT,
            timeout=plan['CPU_phase_timeout_seconds'],check=True)


def main():
    parser=argparse.ArgumentParser()
    for name in ['plan','admission']:parser.add_argument('--'+name,type=Path,required=True)
    for name in ['plan-sha256','admission-sha256']:parser.add_argument('--'+name,required=True)
    parser.add_argument('--local',type=Path);args=parser.parse_args()
    plan=validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256)
    if plan['condition_id']!=protocol.CONDITION:raise ValueError('Plan condition differs from this worker')
    cases=verified_inputs(plan);runtime=HERE/'runtime';runtime.mkdir(exist_ok=True)
    common=load('p38_frozen_runtime_common',plan['runtime_common'])
    if args.local is None:
        lock=(runtime/'allocation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (runtime/'allocation_started.json').exists():raise ValueError('No automatic allocation/model retries')
        write(runtime/'private_GPU_budget_audit.json',project_audit(plan))
        write(runtime/'allocation_started.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],
            'plan_sha256':args.plan_sha256,'admission_sha256':args.admission_sha256})
        if shutil.disk_usage('/tmp').free<48*1024**3:raise ValueError('At least48GiB private scratch required')
        local=Path(tempfile.mkdtemp(prefix='bio-p38-'+os.environ['SLURM_JOB_ID']+'-'))
        CPU_manifest=restore_CPU(plan,local/'CPU')
        write(runtime/'CPU_extraction_receipt.json',{'at_pacific':stamp(),'local_prefix':str(local/'CPU'),
            'archive_sha256':CPU_manifest['archive_sha256'],'verified_members':len(CPU_manifest['files'])})
        for key in ['base_runtime','cuda_overlay']:
            if sha(plan[key]['path'])!=plan[key]['sha256']:raise ValueError('Pinned Qwen runtime archive differs')
        with tarfile.open(plan['base_runtime']['path']) as archive:archive.extractall(local,filter='data')
        write(runtime/'Qwen_extraction_receipt.json',{'at_pacific':stamp(),'local_prefix':str(local),**common.apply_overlay(local)})
        env=Qwen_environment(common,local);python=local/'python/bin/python3.12'
        install_Qwen(python,env,runtime)
        argv=[str(python),str(Path(__file__).resolve()),*sys.argv[1:],'--local',str(local)]
        os.execve(str(python),argv,env)
    local=args.local.resolve()
    if not local.name.startswith('bio-p38-'+os.environ['SLURM_JOB_ID']+'-'):raise ValueError('Private runtime ownership differs')
    lock=(runtime/'protocol.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if Path(plan['output_root']).exists():raise FileExistsError('Preserve existing P38 outputs')
    observed={name:importlib.metadata.version(name)for name in PACKAGES}
    import torch
    if any(observed[k].split('+')[0]!=v for k,v in PACKAGES.items()) or torch.cuda.device_count()!=1:
        raise ValueError('Exact Qwen package identities and one visible GPU required')
    from vllm.sampling_params import StructuredOutputsParams
    from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest
    params=StructuredOutputsParams(regex=protocol.PATTERN)
    if params.regex!=protocol.PATTERN:raise ValueError('Actual vLLM0.32 regex API differs')
    model_dir=common.validate_checkpoint(protocol.MODEL,plan['model']['revision'])
    from transformers import AutoTokenizer
    tokenizer=AutoTokenizer.from_pretrained(model_dir,local_files_only=True)
    counts=[]
    for phase,phase_cases in [('benchmark',cases),('development',protocol.development_cases())]:
      for index,item in enumerate(phase_cases):
        body=protocol.payload(item,index,development=phase=='development')
        parsed=ChatCompletionRequest.model_validate(body)
        if parsed.structured_outputs is None or parsed.structured_outputs.regex!=protocol.PATTERN:
            raise ValueError('Actual installed HTTP request API changes regex constraint')
        ids=tokenizer.apply_chat_template(body['messages'],tokenize=True,add_generation_prompt=True,
            truncation=False,return_dict=True,enable_thinking=False)
        ids=ids['input_ids'] if hasattr(ids,'keys') else ids
        if ids and isinstance(ids[0],list):ids=ids[0]
        if len(ids)+16384>65536:raise ValueError('Complete input/output context exceeds65536; never truncate')
        counts.append({'phase':phase,'case_id':item['case_id'],'prompt_tokens':len(ids)})
    write(runtime/'context_preflight.json',{'at_pacific':stamp(),'all30fit':True,'prompt_tokens':counts,
        'output_tokens':16384,'model_forwards':0,'actual_vllm_version':observed['vllm']})
    server=None
    try:
        write(runtime/'status.json',{'at_pacific':stamp(),'stage':'neutral_CPU_resource_delivery_gate','job_id':os.environ['SLURM_JOB_ID']},current=True)
        CPU_phase(plan,args,'neutral',local,runtime)
        gate=json.loads((runtime/'neutral_evaluator_gate/completion.json').read_text())
        if gate['passed'] is not True:raise ValueError('Actual allocation CPU resource gate failed')
        write(runtime/'private_GPU_audit_before_Qwen.json',project_audit(plan))
        port=plan['port']
        if plan['endpoint']!=f'http://127.0.0.1:{port}/v1':raise ValueError('Only own loopback endpoint allowed')
        with socket.socket() as probe:probe.bind(('127.0.0.1',port))
        command=[str(local/'python/bin/python3.12'),'-m','vllm.entrypoints.cli.main','serve',str(model_dir),
            '--served-model-name',protocol.MODEL,'--host','127.0.0.1','--port',str(port),
            '--dtype','bfloat16','--tensor-parallel-size','1','--gpu-memory-utilization','0.95',
            '--max-model-len','65536','--max-num-seqs','1','--max-num-batched-tokens','8192',
            '--reasoning-parser','qwen3','--enable-prefix-caching','--limit-mm-per-prompt','{"image":0,"video":0}']
        write(runtime/'status.json',{'at_pacific':stamp(),'stage':'starting_own_P38_Qwen','job_id':os.environ['SLURM_JOB_ID']},current=True)
        with (runtime/'server.log').open('x') as log:
            server=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,cwd=local)
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));deadline=time.monotonic()+1800
        while time.monotonic()<deadline:
            if server.poll() is not None:raise RuntimeError('Own Qwen server exited before readiness')
            try:
                with opener.open(plan['endpoint'].removesuffix('/v1')+'/health',timeout=3) as response:
                    if response.status==200:break
            except (OSError,urllib.error.URLError):time.sleep(3)
        else:raise TimeoutError('Own Qwen readiness timeout')
        with opener.open(plan['endpoint']+'/models',timeout=5) as response:models=json.load(response)
        if [r['id']for r in models['data']]!=[protocol.MODEL]:raise ValueError('Own served-model identity differs')
        identity=runtime/'server_identity.json'
        write(identity,{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'hostname':socket.gethostname(),
            'pid':server.pid,'proc_start_ticks':common.start_ticks(server.pid),'model':protocol.MODEL,
            'condition':protocol.CONDITION,'plan_sha256':args.plan_sha256,'endpoint':plan['endpoint'],'server_command':command})
        transport=OwnTransport(plan,identity,common);output=Path(plan['output_root']);output.mkdir()
        development=run(protocol.development_cases(),output/'development',transport,args.plan_sha256,development=True)
        if development['all_delivered'] is not True:raise ValueError('Neutral exact-copy delivery failed; no benchmark requests')
        write(runtime/'private_GPU_audit_before_benchmark.json',project_audit(plan))
        # Read and hash the exact original input byte buffers again immediately
        # before the first real request; no stale post-development input cache.
        cases=verified_inputs(plan)
        write(runtime/'status.json',{'at_pacific':stamp(),'stage':'P38_exact30_generation_live','job_id':os.environ['SLURM_JOB_ID']},current=True)
        generation=run(cases,output/'benchmark',transport,args.plan_sha256)
        stop_server(server);server=None
        write(runtime/'own_Qwen_stopped_before_CPU_scores.json',{'at_pacific':stamp(),'own_server_stopped':True,
            'other_runtimes_changed':False})
        CPU_phase(plan,args,'benchmark',local,runtime)
        complete=json.loads((runtime/'offline_proxy_scoring_completion.json').read_text())
        write(runtime/'status.json',{'at_pacific':stamp(),'stage':'P38_terminal_proxy_scored' if complete['full_proxy_condition_complete'] else 'P38_terminal_full_proxy_metric_undefined',
            'job_id':os.environ['SLURM_JOB_ID'],'scores_sha256':complete['scores_sha256'],
            'native_NatureLM_score':False,'experimental_validation':False},current=True)
    except Exception as error:
        write(runtime/'status.json',{'at_pacific':stamp(),'stage':'stopped_for_review','error_type':type(error).__name__,
            'error':str(error),'no_automatic_retry':True},current=True)
        raise
    finally:stop_server(server)


if __name__=='__main__':main()
