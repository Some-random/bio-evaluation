"""Separate portable CPU process: neutral resource gate or locked30 proxies.

No generator, network client, API credential, CUDA model, reference label or
training loop is imported by this process.
"""
from pathlib import Path
import argparse
import gc
import importlib.metadata
import importlib.util
import json
import os
import resource
import time

from admission import sha,validate,verified_inputs
from evaluate_locked import evaluate_once,load_contract,save,stamp

HERE=Path(__file__).resolve().parent


def load(path):
    spec=importlib.util.spec_from_file_location('p38_exact_native_CPU_evaluator_source',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def check_CPU_runtime(plan):
    if os.environ.get('CUDA_VISIBLE_DEVICES')!='':raise ValueError('CPU evaluator CUDA visibility must be empty')
    import torch
    if torch.cuda.is_available() or torch.version.cuda is not None:raise ValueError('Exact CPU-only Torch required')
    observed={name:importlib.metadata.version(name)for name in plan['CPU_packages']}
    if observed!=plan['CPU_packages']:raise ValueError('Exact CPU evaluator package versions differ')
    for name,digest in plan['weights_sha256'].items():
        if sha(name)!=digest:raise ValueError('Exact released substitute evaluator weights differ')
    return observed


class SequentialEvaluators:
    """Never keep the ONNX and full thermal encoder instances concurrently."""
    def __init__(self,module):self.module=module;self.netsolp=None;self.thermal=None;self.thermal_started=False
    def solubility(self,ident,sequence):
        if self.thermal_started:raise ValueError('Frozen property order changed after thermal load')
        if self.netsolp is None:self.netsolp=self.module.NetSolPDistilledCPU(threads=4)
        return self.netsolp.predict(ident,sequence)
    def stability(self,ident,sequence):
        if not self.thermal_started:
            self.thermal_started=True;self.netsolp=None;gc.collect()
        if self.thermal is None:self.thermal=self.module.DeepSTABpCPU(threads=4)
        # The explicit common context is an assumption, never an organism claim.
        return self.thermal.predict(ident,sequence,growth_temp_c=37,mode='Lysate')


def neutral_gate(module,output):
    output=Path(output);output.mkdir(parents=True,exist_ok=False);start=time.monotonic()
    fixture=('ACDEFGHIKLMNPQRSTVWY'*52)[:1022];rows=[]
    for name,constructor in [('NetSolP_D',module.NetSolPDistilledCPU),('DeepSTABp',module.DeepSTABpCPU)]:
        model=constructor(threads=4)
        for index,text in enumerate(['A'*20,fixture]):
            ident=f'ARTIFICIAL-{name}-{index}';prediction=model.predict(ident,text)
            if prediction['case_id']!=ident or prediction['full_sequence_length']!=len(text):
                raise ValueError('Artificial evaluator complete-input identity differs')
            rows.append(prediction)
        del model;gc.collect()
    save(output/'artificial_predictions.json',rows)
    receipt={'at_pacific':stamp(),'passed':True,'job_id':os.environ['SLURM_JOB_ID'],
        'artificial_evaluator_predictions':4,'full_lengths':[20,1022],'solver_model_calls':0,
        'benchmark_cases':0,'CUDA_model_forwards':0,'maximum_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'elapsed_seconds':time.monotonic()-start,'predictions_sha256':sha(output/'artificial_predictions.json')}
    save(output/'completion.json',receipt);return receipt


def main():
    parser=argparse.ArgumentParser()
    for name in ['plan','admission']:parser.add_argument('--'+name,type=Path,required=True)
    for name in ['plan-sha256','admission-sha256']:parser.add_argument('--'+name,required=True)
    parser.add_argument('--mode',choices=['neutral','benchmark'],required=True);args=parser.parse_args()
    plan=validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256)
    observed=check_CPU_runtime(plan);module=load(plan['evaluator_source'])
    runtime=HERE/'runtime';runtime.mkdir(exist_ok=True)
    save(runtime/('CPU_environment_'+args.mode+'.json'),{'at_pacific':stamp(),
        'job_id':os.environ['SLURM_JOB_ID'],'packages':observed,'CUDA_VISIBLE_DEVICES':'',
        'torch_GPU_build':False,'training':False,'reference_labels_present':False})
    if args.mode=='neutral':neutral_gate(module,runtime/'neutral_evaluator_gate')
    else:
        cases=verified_inputs(plan)
        folder=Path(plan['output_root'])/'benchmark';completion=json.loads((folder/'completion.json').read_text())
        if completion.get('plan_sha256')!=args.plan_sha256:raise ValueError('Generation completion belongs to another plan')
        if completion['prediction_lock_sha256']!=sha(folder/'prediction_lock.json'):
            raise ValueError('Generation closure lock changed')
        contract=load_contract(plan['proxy_contract'],plan['frozen_files_sha256'][plan['proxy_contract']])
        callbacks=SequentialEvaluators(module)
        result=evaluate_once(cases,folder,Path(plan['output_root'])/'evaluation',completion['prediction_lock_sha256'],
            contract,callbacks.solubility,callbacks.stability,thermal_maximum_residues=1022)
        save(runtime/'offline_proxy_scoring_completion.json',{'at_pacific':stamp(),
            'job_id':os.environ['SLURM_JOB_ID'],'plan_sha256':args.plan_sha256,
            'scores_sha256':sha(Path(plan['output_root'])/'evaluation/scores.json'),
            'generation_lock_sha256':completion['prediction_lock_sha256'],
            'full_proxy_condition_complete':result['full_proxy_condition_complete'],
            'native_NatureLM_score':False,'experimental_validation':False})


if __name__=='__main__':main()
