"""One offline proxy attempt per exact locked P38 output; no model imports.

The future live wrapper must verify separate admission/source/runtime pins
before constructing either released CPU evaluator. This pure interface takes
recording evaluators for neutral tests and never sends a solver request.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import importlib.util
import json
import math
import protocol

TASK=Path(__file__).resolve().parent.parent
CANONICAL=frozenset('ACDEFGHIKLMNPQRSTVWY')


def stamp():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')


def load_contract(path,expected_sha):
    if sha(path)!=expected_sha:raise ValueError('Pinned pure proxy contract changed')
    spec=importlib.util.spec_from_file_location('p38_exact_released_proxy_contract',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def verified_sequences(cases,folder,expected_lock_sha):
    """Gate complete fixed cohort before an evaluator instance or call exists."""
    folder=Path(folder).resolve();lock_path=folder/'prediction_lock.json'
    if sha(lock_path)!=expected_lock_sha:raise ValueError('Generation seal changed')
    lock=json.loads(lock_path.read_text());ids=[case['case_id'] for case in cases]
    if len(ids)!=30 or len(set(ids))!=30 or lock.get('planned_case_ids')!=ids:
        raise ValueError('Exact ordered30 author-template cohort required')
    if Counter(case['property_group'] for case in cases)!={'soluble':10,'insoluble':10,'stable':10}:
        raise ValueError('Exact10 soluble/10 insoluble/10 stable denominator required')
    if lock.get('reference_targets_present') is not False:
        raise ValueError('No measurement labels belong in generation seal')
    files=lock['files_sha256']
    if 'terminal_records.json' not in files:raise ValueError('Terminal records must be locked')
    for name,digest in files.items():
        original=folder/name;path=original.resolve()
        if (Path(name).is_absolute() or '..' in Path(name).parts or
                not path.is_relative_to(folder) or any(p.is_symlink() for p in [original,*original.parents] if p!=folder)
                or sha(path)!=digest):
            raise ValueError('Changed or foreign generation artifact')
    actual={str(p.relative_to(folder)) for p in folder.rglob('*') if p.is_file()
            and str(p.relative_to(folder)) not in {'prediction_lock.json','completion.json','progress.json'}}
    if actual!=set(files):raise ValueError('Unsealed generation artifact detected')
    rows=json.loads((folder/'terminal_records.json').read_text())
    if [row.get('case_id') for row in rows]!=ids:raise ValueError('Complete ordered terminal denominator required')
    result=[]
    for index,(case,row) in enumerate(zip(cases,rows)):
        if case['property_group'] not in {'soluble','insoluble','stable'}:
            raise ValueError('Unknown property group')
        observed=row.get('status')=='response'
        if row.get('attempted',observed):
            name=row.get('request_file')
            if not isinstance(name,str) or name not in files or row.get('request_sha256')!=files[name]:
                raise ValueError('Attempted input must bind its exact locked request')
            if json.loads((folder/name).read_bytes())!=protocol.payload(case,index):
                raise ValueError('Locked request differs from exact author-template slot')
        sequence=None;raw_final=None;raw_finish=None;raw_refusal=False;raw_reasoning=False
        if observed:
            response_name=row.get('response_file')
            if not isinstance(response_name,str) or response_name not in files:
                raise ValueError('Observed response must be an exact locked raw artifact')
            if row.get('response_sha256')!=files[response_name]:raise ValueError('Raw response identity differs')
            body=json.loads((folder/response_name).read_bytes())
            choices=body.get('choices')
            if not isinstance(choices,list) or len(choices)!=1:raise ValueError('One raw choice required')
            message=choices[0]['message'];raw_final=message.get('content');raw_finish=choices[0].get('finish_reason')
            raw_refusal=bool(message.get('refusal') or message.get('tool_calls'))
            raw_reasoning=bool(message.get('reasoning') or message.get('reasoning_content'))
            sequence=raw_final
        valid=(isinstance(sequence,str) and bool(sequence) and not set(sequence)-CANONICAL
               and raw_finish=='stop' and not raw_refusal and not raw_reasoning)
        if valid and hashlib.sha256(sequence.encode()).hexdigest()!=row.get('sequence_sha256'):
            raise ValueError('Locked complete sequence identity mismatch')
        result.append({'case':case,'terminal':row,'sequence':sequence if valid else None,
            'sequence_valid':bool(valid)})
    return result


def evaluate_once(cases,folder,output,expected_lock_sha,contract,netsolp,thermal,
                  thermal_maximum_residues=None):
    """Callbacks are constructed only after external admission; no retries.

    A separately declared thermal resource ceiling may reject a complete input;
    it never slices it. None means no additional ceiling. All cases stay in the
    30-template denominator, including source-limit and delivery failures.
    """
    records=verified_sequences(cases,folder,expected_lock_sha)
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    save(output/'manifest.json',{'at_pacific':stamp(),'planned_case_ids':[c['case_id'] for c in cases],
        'generation_prediction_lock_sha256':expected_lock_sha,'maximum_attempts_per_case':1,
        'native_NetSolP_maximum_residues':1022,'declared_thermal_resource_ceiling':thermal_maximum_residues,
        'no_truncation':True,'references_present':False})
    outcomes=[];sol_rows=[];thermal_rows=[];stop=False
    for record in records:
        case=record['case'];ident=case['case_id'];group=case['property_group'];seq=record['sequence']
        outcome={'case_id':ident,'property_group':group,'at_pacific':stamp(),'evaluator_attempted':False}
        if stop:
            outcome.update(status='not_dispatched_after_evaluator_error')
        elif not record['sequence_valid']:
            outcome.update(status='invalid_generation')
        elif ((group in {'soluble','insoluble'} and len(seq)>1022)
              or (group=='stable' and thermal_maximum_residues is not None and len(seq)>thermal_maximum_residues)):
            outcome.update(status='complete_sequence_exceeds_declared_evaluator_limit',complete_sequence_length=len(seq),
                sequence_sha256=hashlib.sha256(seq.encode()).hexdigest(),sequence_truncated=False)
        else:
            request={'case_id':ident,'property_group':group,'sequence':seq,
                'sequence_sha256':hashlib.sha256(seq.encode()).hexdigest()}
            key=hashlib.sha256(ident.encode()).hexdigest();save(output/'requests'/f'{key}.json',request)
            save(output/'attempts'/f'{key}.json',{'case_id':ident,'at_pacific':stamp(),
                'request_sha256':sha(output/'requests'/f'{key}.json'),'maximum_attempts':1})
            outcome.update(evaluator_attempted=True,sequence_sha256=request['sequence_sha256'])
            try:
                prediction=(thermal(ident,seq) if group=='stable' else netsolp(ident,seq))
                if prediction.get('case_id')!=ident:raise ValueError('Evaluator response identity differs')
                if prediction.get('full_sequence_length')!=len(seq):raise ValueError('Evaluator complete sequence length differs')
                if prediction.get('sequence_sha256',request['sequence_sha256'])!=request['sequence_sha256']:
                    raise ValueError('Evaluator complete sequence identity differs')
                field='predicted_tm_c' if group=='stable' else 'predicted_solubility'
                value=prediction[field]
                if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
                    raise ValueError('Complete finite evaluator scalar required')
                if group!='stable' and not 0<=value<=1:raise ValueError('Released sigmoid probability required')
                save(output/'responses'/f'{key}.json',prediction)
                outcome.update(status='success',**{field:value})
            except Exception as error:
                outcome.update(status='evaluator_error',error_type=type(error).__name__)
                stop=True
        if group=='stable':
            thermal_rows.append({'case_id':ident,'predicted_tm_c':outcome.get('predicted_tm_c')})
        else:
            sol_rows.append({'case_id':ident,'property_group':group,'predicted_solubility':outcome.get('predicted_solubility')})
        outcomes.append(outcome)
        save(output/'outcomes'/(hashlib.sha256(ident.encode()).hexdigest()+'.json'),outcome)
    save(output/'terminal_records.json',outcomes)
    files={str(p.relative_to(output)):sha(p) for section in ['requests','responses','attempts','outcomes']
           for p in sorted((output/section).glob('*')) if p.is_file()}
    files.update({name:sha(output/name) for name in ['terminal_records.json','manifest.json']})
    save(output/'prediction_lock.json',{'files_sha256':files,
        'generation_prediction_lock_sha256':expected_lock_sha,'maximum_attempts_per_case':1})
    sol_cases=[c for c in cases if c['property_group']!='stable']
    result={'at_pacific':stamp(),'planned':30,'terminal':len(outcomes),
        'successes':sum(o['status']=='success' for o in outcomes),
        'evaluator_errors':sum(o['status']=='evaluator_error' for o in outcomes),
        'evaluator_attempts':sum(o['evaluator_attempted'] for o in outcomes),
        'not_evaluated':sum(not o['evaluator_attempted'] for o in outcomes),
        'generation_prediction_lock_sha256':expected_lock_sha,
        'evaluator_prediction_lock_sha256':sha(output/'prediction_lock.json'),
        'NetSolP_D':contract.summarize(sol_cases,sol_rows),
        'DeepSTABp':contract.summarize_thermal([c['case_id'] for c in cases if c['property_group']=='stable'],thermal_rows),
        'native_NatureLM_score':False,'experimental_validation':False,'model_calls_by_aggregator':0,
        'declared_thermal_resource_ceiling':thermal_maximum_residues,'sequence_truncation':False}
    result['full_proxy_condition_complete']=result['successes']==30
    save(output/'scores.json',result)
    return result
