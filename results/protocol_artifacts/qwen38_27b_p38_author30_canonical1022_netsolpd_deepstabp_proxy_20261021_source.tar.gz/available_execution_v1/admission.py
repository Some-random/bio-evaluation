"""Fail-closed proposed P38 runtime admission, with explicit proxy adoption."""
from pathlib import Path
import hashlib
import json
import os
import socket

DELEGATION_SHA='f70edf39692d5915f05bd4869b2290d9a7576bd5a89906c004aec137d7e29717'


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(8<<20),b''):digest.update(block)
    return digest.hexdigest()


def validate(plan_path,plan_sha,grant_path,grant_sha,require_job=True):
    if sha(plan_path)!=plan_sha or sha(grant_path)!=grant_sha:raise ValueError('Exact P38 plan or admission changed')
    plan=json.loads(Path(plan_path).read_text());grant=json.loads(Path(grant_path).read_text())
    for name,digest in plan['frozen_files_sha256'].items():
        if sha(name)!=digest:raise ValueError('Frozen P38 source/support changed')
    if plan['task_id']!='P38' or plan['planned']!=30 or plan['maximum_attempts_per_case']!=1:
        raise ValueError('Exact30 one-attempt author-template scope required')
    if (plan['scientific_condition']['native_NatureLM_equivalence'] is not False or
            plan['scientific_condition']['experimental_function_claim'] is not False or
            plan['scientific_condition']['minimum_residues']!=1 or
            plan['scientific_condition']['maximum_residues']!=1022):
        raise ValueError('Explicit separately named proxy/length condition required')
    if (grant.get('plan_sha256')!=plan_sha or grant.get('task_id')!='P38' or grant.get('admitted') is not True or
            grant.get('scientific_adaptation_adopted') is not True or
            grant.get('canonical_generation_length_rule')!=[1,1022] or
            grant.get('native_NatureLM_equivalence') is not False or
            grant.get('experimental_function_claim') is not False or
            grant.get('new_training') is not False or grant.get('paid_calls') is not False or
            grant.get('GPU_count')!=1 or grant.get('project_GPU_ceiling')!=8 or
            grant.get('maximum_attempts_per_case')!=1):
        raise ValueError('Exact scientific adaptation and once-only runtime admission required')
    owner=plan['engineering_owner'];reviewer=grant.get('reviewer')
    if not reviewer or reviewer==owner:raise ValueError('Owner cannot self-approve')
    if reviewer!='/root':
        delegation=Path(plan['delegation_path'])
        if (sha(delegation)!=DELEGATION_SHA or grant.get('delegation_sha256')!=DELEGATION_SHA or
                grant.get('independent_review_sha256') is None):
            raise ValueError('Independent bounded delegated review required')
        authority=json.loads(delegation.read_text())
        if (authority.get('issuer')!='root' or reviewer not in authority.get('authorized_reviewers',[]) or
                'P38' not in authority.get('authorized_task_ids',[])):
            raise ValueError('Reviewer/task is outside the root delegation')
        # This materially different evaluator/length intervention is a root
        # scientific decision. A peer's technical review cannot adopt it.
        if not isinstance(grant.get('root_scientific_adoption_path'),str) or not isinstance(grant.get('root_scientific_adoption_sha256'),str):
            raise ValueError('Exact root scientific adoption binding required')
        adopted_path=Path(grant['root_scientific_adoption_path'])
        if sha(adopted_path)!=grant['root_scientific_adoption_sha256']:
            raise ValueError('Root scientific adoption artifact changed')
        adopted=json.loads(adopted_path.read_text())
        if (adopted.get('issuer')!='root' or adopted.get('adopted') is not True or
                adopted.get('task_id')!='P38' or adopted.get('plan_sha256')!=plan_sha or
                adopted.get('condition_id')!=plan['condition_id'] or
                adopted.get('scientific_condition')!=plan['scientific_condition']):
            raise ValueError('Exact root scientific adaptation adoption required')
        review=Path(grant['independent_review_path'])
        if sha(review)!=grant['independent_review_sha256']:raise ValueError('Independent source review changed')
        reviewed=json.loads(review.read_text())
        if reviewed.get('plan_sha256')!=plan_sha or reviewed.get('reviewer')!=reviewer or reviewed.get('passed') is not True:
            raise ValueError('Independent review does not bind this exact reviewer and plan')
    resource=Path(plan['CPU_resource_gate_completion'])
    if sha(resource)!=plan['CPU_resource_gate_completion_sha256']:raise ValueError('Synthetic resource evidence changed')
    checked=json.loads(resource.read_text())
    if (checked.get('stage')!='synthetic_CPU_resource_gate_passed' or checked.get('GPU_requests')!=0 or
            checked.get('solver_model_calls')!=0 or checked.get('benchmark_cases')!=0 or
            checked.get('complete_sequence_lengths')!=[20,1022]):
        raise ValueError('Actual portable CPU synthetic resource gate required')
    if require_job and not os.environ.get('SLURM_JOB_ID'):raise ValueError('Dedicated allocation required')
    return plan


def verified_inputs(plan):
    """Use exact frozen byte buffers; no reference/measurement input exists."""
    rows=[]
    for name,digest in plan['input_manifests_sha256'].items():
        data=Path(name).read_bytes()
        if hashlib.sha256(data).hexdigest()!=digest:raise ValueError('Exact author-template inputs changed')
        item=json.loads(data)
        if item.get('exact_author_templates') is not True:raise ValueError('Native author question provenance required')
        rows.extend(item['cases'])
    if (len(rows)!=30 or len({row['case_id']for row in rows})!=30 or
            [row['case_id'] for row in rows]!=plan['planned_case_ids']):
        raise ValueError('Exact ordered30 author-template scope differs')
    from collections import Counter
    if Counter(r.get('property_group') for r in rows)!={'soluble':10,'insoluble':10,'stable':10}:
        raise ValueError('Exact ten-per-property denominator differs')
    if any(set(row)!={'case_id','property_group','prompt'} for row in rows):
        raise ValueError('No answer, label or reference field belongs in solver inputs')
    return rows
