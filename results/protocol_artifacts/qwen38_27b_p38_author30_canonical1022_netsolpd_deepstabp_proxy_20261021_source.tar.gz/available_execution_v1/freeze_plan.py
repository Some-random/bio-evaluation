"""Freeze a reviewable proposal; never issues admission, sbatch or model calls."""
from pathlib import Path
import hashlib
import json
import protocol
from generation import stamp,write

HERE=Path(__file__).resolve().parent
TASK=HERE.parent
ROOT=HERE.parents[4]


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p37=json.loads((TASK.parent/'P37/bounded_format_proposal_v2/plan.json').read_text())
    resource=TASK/'portable_CPU_resource_gate_v1';complete=json.loads((resource/'completion.json').read_text())
    terminal=json.loads((resource/'terminal_accounting_receipt.json').read_text())
    if complete['stage']!='synthetic_CPU_resource_gate_passed' or terminal['state']!='COMPLETED' or terminal['GPU_requests']!=0:
        raise ValueError('Terminal zero-GPU portable evaluator resource evidence required')
    interface=json.loads((HERE/'CPU_validation.json').read_text())
    if interface['tests_passed']!=29 or interface['tests_failed']!=0:raise ValueError('Final meaningful29 CPU checks required')
    for name,digest in interface['files_sha256'].items():
        if sha(name)!=digest:raise ValueError('CPU-tested source changed before proposal freeze')
    inputs={str(TASK/name):sha(TASK/name)for name in ['solubility_proxy_prompt_manifest.json','thermal_proxy_prompt_manifest.json']}
    cases=[]
    for name in inputs:cases.extend(json.loads(Path(name).read_text())['cases'])
    if len(cases)!=30 or len({c['case_id']for c in cases})!=30:raise ValueError('Exact30 unique author-template IDs required')
    manifest_path=TASK/'portable_CPU_runtime_v1/runtime_manifest.json'
    manifest=json.loads(manifest_path.read_text());resource_plan=json.loads((resource/'plan.json').read_text())
    plan={'at_pacific':stamp(),'role':'frozen_unadmitted_scientific_proxy_proposal_not_runtime_or_dispatch',
        'task_id':'P38','condition_id':protocol.CONDITION,'engineering_owner':'/root/update_comparison_publication',
        'scientific_condition_adopted':False,'root_scientific_adoption_required':True,
        'scientific_condition':{'minimum_residues':1,'maximum_residues':1022,'bare_canonical_output_language_imposed':True,
            'output_language_changes_generation_distribution':True,'author_question_wording_unchanged':True,
            'one_generation_per_author_template':True,'native_NatureLM_allocation_known':False,
            'solubility_proxy':'Released NetSolP-D probability of soluble E. coli expression',
            'stability_proxy':'Released DeepSTABp predicted Tm under hypothetical37C growth and Lysate context',
            'natural_control_cohort_present':False,'native_NatureLM_equivalence':False,'experimental_function_claim':False,
            'no_prefix_cropping':True,'new_head_training':False},
        'project_root':str(ROOT),'planned':30,'planned_case_ids':[c['case_id']for c in cases],
        'maximum_attempts_per_case':1,'input_manifests_sha256':inputs,
        'model':p37['model'],'base_runtime':p37['base_runtime'],'cuda_overlay':p37['cuda_overlay'],
        'runtime_common':p37['runtime_common'],'project_gpu_audit_helper':str(ROOT/'scripts/project_gpu_audit_20261021.py'),
        'delegation_path':str(ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review.json'),
        'requested_GPU_count':1,'project_GPU_ceiling':8,'port':8507,'endpoint':'http://127.0.0.1:8507/v1',
        'generation':{'temperature':1.,'top_p':.95,'top_k':20,'seed_base':42,'max_tokens':16384,
            'nonthinking':True,'n':1,'regex':protocol.PATTERN,'maximum_model_context':65536},
        'maximum_response_bytes':16*1024*1024,'CPU_phase_timeout_seconds':7200,
        'CPU_runtime_manifest':str(manifest_path),'CPU_packages':manifest['expected_packages'],
        'CPU_resource_gate_completion':str(resource/'completion.json'),
        'CPU_resource_gate_completion_sha256':sha(resource/'completion.json'),
        'weights_sha256':resource_plan['weights_sha256'],
        'evaluator_source':str(TASK/'engineering_20261020/evaluator_runtime.py'),
        'proxy_contract':str(TASK/'proxy_contract.py'),'output_root':str(HERE/'runtime/run_v1'),
        'phases':['exact private runtime/identity/context','neutralCPU20and1022 resource gate',
            'two new artificial exact-copy Qwen delivery checks','once each exact30 author prompts',
            'stop own Qwen server','one offline prediction per complete locked output/full denominators'],
        'no_selective_retries':True,'new_paid_calls':False,'new_training':False,'reference_labels_present':False}
    pins=list(HERE.glob('*.py'))+[HERE/'worker.sbatch',HERE/'README.md',HERE/'CPU_validation.json',
        HERE/'checkpoint_CPU_validation.json',resource/'completion.json',resource/'terminal_accounting_receipt.json',
        manifest_path,TASK/'engineering_20261020/evaluator_runtime.py',TASK/'proxy_contract.py',
        TASK/'protocol_contract.json',TASK/'thermal_protocol_contract.json',TASK/'exact_condition_availability.json',
        TASK/'evaluator_assets_manifest.json',TASK/'assets/ESM12_alphabet.pkl',
        ROOT/'.local/source_recovery_round2_2026-10-19/paper_artifacts/p38_author_templates.json',
        Path(plan['project_gpu_audit_helper']),Path(plan['runtime_common']),Path(plan['delegation_path'])]
    pins += [Path(name)for name in inputs]
    pins += [p for p in (TASK/'sources').rglob('*')if p.is_file()and p.suffix in {'.py','.json','.model','.fs'}and '.git'not in p.parts]
    plan['frozen_files_sha256']={str(p):sha(p)for p in sorted(set(pins))}
    write(HERE/'plan.json',plan)
    write(HERE/'freeze_receipt.json',{'at_pacific':stamp(),'plan_sha256':sha(HERE/'plan.json'),
        'source_and_support_pins':len(plan['frozen_files_sha256']),'neural_asset_pins':len(plan['weights_sha256']),
        'solver_model_calls':0,'GPU_submissions':0,'scientific_condition_adopted':False,
        'root_scientific_adoption_and_independent_technical_admission_required':True})
    print(json.dumps({'plan_sha256':sha(HERE/'plan.json'),'pins':len(plan['frozen_files_sha256']),
        'scientific_condition_adopted':False,'solver_model_calls':0}))


if __name__=='__main__':main()
