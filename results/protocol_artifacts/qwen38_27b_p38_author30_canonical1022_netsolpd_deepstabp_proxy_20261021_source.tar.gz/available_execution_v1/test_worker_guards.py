"""Artificial admission, own-server and CPU-isolation checks, no allocations."""
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
import json
import os
import tempfile
import unittest

import admission
import generation
import protocol
import score_worker
import worker
from test_generation import cases


class Guards(unittest.TestCase):
    def admission_fixture(self,root):
        resource=root/'resource.json';resource.write_text(json.dumps({'stage':'synthetic_CPU_resource_gate_passed',
            'GPU_requests':0,'solver_model_calls':0,'benchmark_cases':0,'complete_sequence_lengths':[20,1022]}))
        plan={'task_id':'P38','planned':30,'maximum_attempts_per_case':1,
            'engineering_owner':'/root/update_comparison_publication','frozen_files_sha256':{},
            'scientific_condition':{'native_NatureLM_equivalence':False,'experimental_function_claim':False,
                'minimum_residues':1,'maximum_residues':1022},'CPU_resource_gate_completion':str(resource),
            'CPU_resource_gate_completion_sha256':admission.sha(resource)}
        path=root/'plan.json';path.write_text(json.dumps(plan));digest=admission.sha(path)
        grant={'task_id':'P38','plan_sha256':digest,'admitted':True,'reviewer':'/root',
            'scientific_adaptation_adopted':True,'canonical_generation_length_rule':[1,1022],
            'native_NatureLM_equivalence':False,'experimental_function_claim':False,
            'new_training':False,'paid_calls':False,'GPU_count':1,'project_GPU_ceiling':8,
            'maximum_attempts_per_case':1}
        g=root/'grant.json';g.write_text(json.dumps(grant));return path,digest,g,grant

    def test_exact_root_admission_does_not_follow_from_resource_gate(self):
        with tempfile.TemporaryDirectory() as td:
            p,d,g,grant=self.admission_fixture(Path(td))
            self.assertEqual(admission.validate(p,d,g,admission.sha(g),require_job=False)['planned'],30)
            grant['scientific_adaptation_adopted']=False;g.write_text(json.dumps(grant))
            with self.assertRaisesRegex(ValueError,'scientific adaptation'):
                admission.validate(p,d,g,admission.sha(g),require_job=False)

    def test_owner_cannot_self_approve_or_turn_proxy_into_native(self):
        for mutation in [{'reviewer':'/root/update_comparison_publication'}, {'native_NatureLM_equivalence':True},
                         {'canonical_generation_length_rule':[1,2048]},{'GPU_count':2},
                         {'project_GPU_ceiling':9},{'maximum_attempts_per_case':2}]:
            with self.subTest(mutation=mutation),tempfile.TemporaryDirectory() as td:
                p,d,g,grant=self.admission_fixture(Path(td));grant.update(mutation);g.write_text(json.dumps(grant))
                with self.assertRaises(ValueError):admission.validate(p,d,g,admission.sha(g),require_job=False)

    def test_changed_resource_receipt_is_not_reused(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);p,d,g,grant=self.admission_fixture(root)
            (root/'resource.json').write_text('{}')
            with self.assertRaisesRegex(ValueError,'resource evidence'):
                admission.validate(p,d,g,admission.sha(g),require_job=False)

    def test_unlisted_peer_cannot_authorize_itself(self):
        with tempfile.TemporaryDirectory() as td:
            p,d,g,grant=self.admission_fixture(Path(td));plan=json.loads(p.read_text())
            plan['delegation_path']=str(Path(__file__).resolve().parents[3]/'dedicated_execution_20261021/delegated_engineering_review.json')
            p.write_text(json.dumps(plan));d=admission.sha(p)
            grant.update(plan_sha256=d,reviewer='/arbitrary/unlisted/reviewer',
                delegation_sha256=admission.DELEGATION_SHA,independent_review_sha256='a'*64)
            g.write_text(json.dumps(grant))
            with self.assertRaisesRegex(ValueError,'outside the root delegation'):
                admission.validate(p,d,g,admission.sha(g),require_job=False)

    def test_approved_technical_peer_cannot_adopt_scientific_condition(self):
        with tempfile.TemporaryDirectory() as td:
            p,d,g,grant=self.admission_fixture(Path(td));plan=json.loads(p.read_text())
            plan['delegation_path']=str(Path(__file__).resolve().parents[3]/'dedicated_execution_20261021/delegated_engineering_review.json')
            p.write_text(json.dumps(plan));d=admission.sha(p)
            grant.update(plan_sha256=d,reviewer='/root/new_2026_benchmarks',
                delegation_sha256=admission.DELEGATION_SHA,independent_review_sha256='a'*64)
            g.write_text(json.dumps(grant))
            with self.assertRaisesRegex(ValueError,'root scientific adoption binding'):
                admission.validate(p,d,g,admission.sha(g),require_job=False)

    def test_CPU_subprocess_env_excludes_Qwen_compilers_credentials_and_GPU(self):
        inherited={'SLURM_JOB_ID':'123','CUDA_VISIBLE_DEVICES':'0','CUDA_HOME':'/untrusted/cuda',
            'LD_LIBRARY_PATH':'/untrusted/Qwen','PYTHONPATH':'/untrusted/python','OPENAI_API_KEY':'sentinel',
            'SSH_AUTH_SOCK':'/untrusted/socket'}
        with patch.dict(os.environ,inherited,clear=True):
            env=worker.CPU_environment(Path('/private/CPU'))
        self.assertEqual(env['CUDA_VISIBLE_DEVICES'],'')
        self.assertEqual(env['LD_LIBRARY_PATH'],'/private/CPU/python/lib:/private/CPU/site-packages/torch/lib')
        for key in ['CUDA_HOME','OPENAI_API_KEY','SSH_AUTH_SOCK']:self.assertNotIn(key,env)
        self.assertNotIn('/untrusted',str(env));self.assertEqual(env['SLURM_JOB_ID'],'123')

    def own_transport(self,root,raw,limit=10000):
        identity=root/'identity.json';identity.write_text(json.dumps({'job_id':'123','hostname':'artificialhost',
            'proc_start_ticks':456,'pid':12,'condition':protocol.CONDITION,'model':protocol.MODEL}))
        transport=worker.OwnTransport({'endpoint':'http://127.0.0.1:9999/v1','maximum_response_bytes':limit},identity,
            SimpleNamespace(start_ticks=lambda pid:456))
        class Response:
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,n):return raw[:n]
        transport.opener=SimpleNamespace(open=lambda *args,**kwargs:Response())
        return transport,identity

    def test_raw_oversize_fragment_saved_but_no_observed_final_claim(self):
        with tempfile.TemporaryDirectory() as td,patch.dict(os.environ,{'SLURM_JOB_ID':'123'}),patch.object(worker.socket,'gethostname',return_value='artificialhost'):
            root=Path(td);transport,_=self.own_transport(root,b'x'*200,limit=50)
            result=generation.run(cases(),root/'phase',transport,'a'*64)
            self.assertEqual(result['attempted_confirmed'],1);self.assertEqual(result['client_or_guard_errors'],1)
            self.assertEqual(result['responses_saved'],0);self.assertEqual(result['unknown_finals'],1)
            self.assertEqual(result['empty_finals'],0);self.assertEqual(result['not_dispatched'],29)
            fragment=list((root/'phase/errors').glob('*.partial'))
            self.assertEqual(len(fragment),1);self.assertEqual(fragment[0].read_bytes(),b'x'*51)

    def test_changed_own_server_identity_prevents_send(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);transport,identity=self.own_transport(root,b'{}');identity.write_text('{}')
            with self.assertRaisesRegex(ValueError,'identity changed'):
                transport('ARTIFICIAL',protocol.payload(cases()[0],0))

    def test_input_changed_after_development_refused_from_exact_frozen_bytes(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'inputs.json';p.write_text(json.dumps({'exact_author_templates':True,'cases':cases()}))
            plan={'input_manifests_sha256':{str(p):admission.sha(p)},'planned_case_ids':[c['case_id']for c in cases()]}
            self.assertEqual(admission.verified_inputs(plan),cases())
            row=json.loads(p.read_text());row['cases'][-1]['prompt']='Changed artificial prompt'
            p.write_text(json.dumps(row))
            with self.assertRaisesRegex(ValueError,'inputs changed'):admission.verified_inputs(plan)

    def test_sequential_evaluator_adapter_drops_ONNX_before_loading_thermal(self):
        events=[]
        class Sol:
            def __init__(self,threads):events.append('load_sol')
            def predict(self,ident,sequence):return {'case_id':ident}
            def __del__(self):events.append('drop_sol')
        class Thermal:
            def __init__(self,threads):events.append('load_thermal')
            def predict(self,ident,sequence,growth_temp_c,mode):
                self.context=(growth_temp_c,mode);return {'case_id':ident}
        callbacks=score_worker.SequentialEvaluators(SimpleNamespace(NetSolPDistilledCPU=Sol,DeepSTABpCPU=Thermal))
        callbacks.solubility('ARTIFICIAL-A','A');callbacks.stability('ARTIFICIAL-B','A')
        self.assertEqual(events,['load_sol','drop_sol','load_thermal'])
        self.assertEqual(callbacks.thermal.context,(37,'Lysate'))
        with self.assertRaises(ValueError):callbacks.solubility('ARTIFICIAL-C','A')


if __name__=='__main__':unittest.main()
