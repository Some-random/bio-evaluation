"""One attempt per fixed P38 slot; callable transport for artificial tests."""
from collections import Counter
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import hashlib
import json
import protocol


def stamp():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path,value,current=False):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if current:
        temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)
    else:
        with path.open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')


class TransportError(Exception):
    def __init__(self,message,http_status=None,body=None):
        super().__init__(message);self.http_status=http_status;self.body=body


class ResponseGuardError(Exception):
    """A bounded response fragment, not a complete observed final."""
    def __init__(self,message,fragment):super().__init__(message);self.fragment=fragment


def summarize(cases,records):
    attempted=[r for r in records if r.get('attempted')]
    return {'at_pacific':stamp(),'planned':len(cases),'recorded_outcomes':len(records),
        'attempted_confirmed':len(attempted),'responses_saved':sum(r.get('response_saved',False)for r in attempted),
        'delivered':sum(r['status']=='response' for r in attempted),
        'transport_errors':sum(r['status']=='transport_error' for r in attempted),
        'HTTP_errors':sum(r['status']=='HTTP_error' for r in attempted),
        'server_errors':sum(r.get('server_error',False)for r in attempted),
        'client_or_guard_errors':sum(r.get('client_or_guard_error',False)for r in attempted),
        'response_errors':sum(r.get('response_error',False)for r in attempted),
        'truncations':sum(r.get('truncated',False)for r in attempted),
        'refusals':sum(r.get('refusal',False)for r in attempted),
        'empty_finals':sum(r.get('empty_final',False)for r in attempted),
        'unknown_finals':sum(not r.get('observed_final',False)for r in attempted),
        'reasoning_present':sum(r.get('reasoning_present',False)for r in attempted),
        'not_dispatched':sum(r.get('not_dispatched',False)for r in records),
        'role':'direct_unsealed_progress_lower_bound'}


def run(cases,folder,transport,plan_sha,development=False):
    if (len(cases)!=(2 if development else 30) or len({c['case_id'] for c in cases})!=len(cases)):
        raise ValueError('Exact phase denominator required')
    if not development and Counter(c.get('property_group') for c in cases)!={'soluble':10,'insoluble':10,'stable':10}:
        raise ValueError('Exact ten-per-property denominator required')
    # Validate every immutable request before any output directory or send. A
    # later invalid row must not strand an already-started phase.
    requests=[protocol.payload(case,index,development=development) for index,case in enumerate(cases)]
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False)
    write(folder/'manifest.json',{'plan_sha256':plan_sha,'condition':protocol.CONDITION,
        'planned_case_ids':[c['case_id'] for c in cases],'development_only':development,
        'maximum_attempts_per_case':1,'reference_targets_present':False})
    records=[];halted=False
    for index,case in enumerate(cases):
        ident=case['case_id'];key=hashlib.sha256(ident.encode()).hexdigest()
        if halted:
            outcome={'case_id':ident,'status':'not_dispatched','attempted':False,'not_dispatched':True,
                'observed_final':False,'empty_final':False,'reason':'stop_after_first_failure_no_retry'}
        else:
            body=requests[index]
            request_file=folder/'requests'/f'{key}.json';write(request_file,body)
            write(folder/'attempts'/f'{key}.json',{'case_id':ident,'at_pacific':stamp(),
                'request_sha256':sha(request_file),'role':'client_send_attempt_not_server_completion'})
            outcome={'case_id':ident,'attempted':True,'not_dispatched':False,
                'request_file':str(request_file.relative_to(folder)),'request_sha256':sha(request_file),
                'observed_final':False,'empty_final':False}
            try:
                raw=transport(ident,body)
                if not isinstance(raw,bytes):raise TypeError('Exact raw response bytes required')
                response=folder/'responses'/f'{key}.json';response.parent.mkdir(exist_ok=True)
                with response.open('xb') as stream:stream.write(raw)
                outcome.update(protocol.interpret(raw),response_saved=True,
                    response_file=str(response.relative_to(folder)),response_sha256=sha(response))
                if development:
                    outcome['exact_copy_passed']=(outcome['status']=='response' and
                        outcome['sequence']==protocol.DEVELOPMENT[index])
                    if not outcome['exact_copy_passed']:
                        outcome['status']='invalid_development_copy';outcome['response_error']=True
            except TransportError as error:
                outcome.update(status='HTTP_error' if error.http_status is not None else 'transport_error',
                    http_status=error.http_status,server_error=error.http_status is not None and 500<=error.http_status<600)
                if error.body is not None:
                    path=folder/'errors'/f'{key}.raw';path.parent.mkdir(exist_ok=True)
                    with path.open('xb') as stream:stream.write(error.body)
                    outcome['error_body_sha256']=sha(path)
            except ResponseGuardError as error:
                outcome.update(status='client_or_guard_error',client_or_guard_error=True,
                    error_type=type(error).__name__,raw_response_complete=False)
                path=folder/'errors'/f'{key}.partial';path.parent.mkdir(exist_ok=True)
                with path.open('xb')as stream:stream.write(error.fragment)
                outcome.update(partial_response_file=str(path.relative_to(folder)),partial_response_sha256=sha(path))
            except Exception as error:
                # An unexpected local transport/client failure is an attempted
                # request with unknown final status, never an observed empty.
                outcome.update(status='client_or_guard_error',client_or_guard_error=True,
                    error_type=type(error).__name__)
            halted=outcome['status']!='response'
        write(folder/'outcomes'/f'{key}.json',outcome);records.append(outcome)
        write(folder/'progress.json',summarize(cases,records),current=True)
    write(folder/'terminal_records.json',records)
    files={str(p.relative_to(folder)):sha(p) for category in ['requests','attempts','responses','outcomes','errors']
           for p in sorted((folder/category).glob('*')) if p.is_file()}
    files.update({name:sha(folder/name)for name in ['terminal_records.json','manifest.json']})
    lock={'plan_sha256':plan_sha,'condition':protocol.CONDITION,
        'planned_case_ids':[c['case_id']for c in cases],'reference_targets_present':False,'files_sha256':files}
    write(folder/'prediction_lock.json',lock)
    complete={**summarize(cases,records),'role':'sealed_complete_phase_outcome_accounting',
        'plan_sha256':plan_sha,'condition':protocol.CONDITION,'closed_slots':len(records),
        'all_delivered':not halted and all(r['status']=='response'for r in records),
        'development_only':development,'prediction_lock_sha256':sha(folder/'prediction_lock.json')}
    write(folder/'completion.json',complete)
    return complete
