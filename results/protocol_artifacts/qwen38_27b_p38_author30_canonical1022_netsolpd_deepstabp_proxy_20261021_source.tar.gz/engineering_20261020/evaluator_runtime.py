"""Isolated CPU adapters for released P38 alternative evaluators.

No generation, network calls, labels, training, thresholds or biological cases.
The synthetic validation entry point lives in validate_runtime.py.
"""
from __future__ import annotations

import ast
import gc
import hashlib
import importlib.util
import math
from pathlib import Path
import pickle
from types import SimpleNamespace

TASK = Path(__file__).resolve().parent.parent
SOURCE = TASK / "sources"
ASSETS = TASK / "assets"
CANONICAL = set("ACDEFGHIKLMNPQRSTVWY")


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def checked_sequence(sequence, maximum=None):
    if not isinstance(sequence, str) or not sequence:
        raise ValueError("empty_or_not_text")
    if any(x not in CANONICAL for x in sequence):
        raise ValueError("not_one_bare_canonical_sequence")
    if maximum is not None and len(sequence) > maximum:
        raise ValueError("complete_sequence_exceeds_evaluator_limit")
    return sequence


def load_native_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class NetSolPDistilledCPU:
    """Released token/mask transform and quantized ONNX, without truncation."""

    def __init__(self, threads=4):
        import onnxruntime as ort
        native_path = SOURCE / "netsolp/PredictionServer/data.py"
        if sha256(native_path) != "f7f06e4dfec467c598d3879629fb772be2eb9983f6251f43b67a028a4e35abc1":
            raise ValueError("native_netsolp_preprocessing_hash_changed")
        # Publisher-verified archive extraction, no untrusted arbitrary pickle.
        alphabet_path = ASSETS / "ESM12_alphabet.pkl"
        if sha256(alphabet_path) != "8e3eb50cd9471d5a8444751717b3776cb93fca9c7773cd34da3136e77bf0efdd":
            raise ValueError("native_alphabet_hash_changed")
        with alphabet_path.open("rb") as stream:
            alphabet = pickle.load(stream)
        self.native_data = load_native_module(native_path, "p38_netsolp_native_data")
        self.converter = self.native_data.BatchConverter(alphabet)
        options = ort.SessionOptions()
        options.intra_op_num_threads = threads
        options.inter_op_num_threads = threads
        options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        self.session = ort.InferenceSession(
            str(ASSETS / "Solubility_ESM1b_distilled_quantized.onnx"),
            sess_options=options, providers=["CPUExecutionProvider"],
        )
        self.input_schema = [(v.name, v.type, v.shape) for v in self.session.get_inputs()]

    def predict(self, case_id, sequence):
        import numpy as np
        checked_sequence(sequence, maximum=1022)
        toks, lengths, mask, labels = self.converter([(sequence, case_id)])
        if labels != [case_id] or int(lengths[0]) != len(sequence):
            raise ValueError("native_conversion_identity_or_length_changed")
        schema = self.session.get_inputs()
        native_input = {schema[0].name: toks.numpy(), schema[1].name: lengths.numpy(), schema[2].name: mask.numpy()}
        logit = np.asarray(self.session.run(None, native_input)[0])
        if logit.size != 1:
            raise ValueError("native_model_not_single_scalar")
        # Exact released sigmoid; no threshold/label conversion.
        probability = float((1 / (1 + np.exp(-logit))).reshape(-1)[0])
        if not math.isfinite(probability) or not 0 <= probability <= 1:
            raise ValueError("invalid_native_probability")
        return {"case_id": case_id, "predicted_solubility": probability,
                "full_sequence_length": len(sequence), "sequence_sha256": hashlib.sha256(sequence.encode()).hexdigest()}


def native_thermal_functions():
    """Use exact upstream functions/class; substitute only framework base.

    LightningModule's training/checkpoint wrapper is unnecessary at inference.
    Its nn.Module child class has the identical __init__ and forward body.
    Exact released state_dict keys and shapes are checked during loading.
    """
    import numpy as np
    import pandas as pd
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    path = SOURCE / "deepstabp/src/Api/app/predictor.py"
    if sha256(path) != "7fea694a16a6cd894fe01769f76ec58676f520a003f1ebf4f92b736563d8c965":
        raise ValueError("native_deepstabp_source_hash_changed")
    tree = ast.parse(path.read_text())
    selected = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))
                and node.name in {"new_features", "deepSTAPpMLP", "determine_tm"}]
    if len(selected) != 3:
        raise ValueError("missing_native_thermal_definitions")
    cls = next(node for node in selected if isinstance(node, ast.ClassDef))
    cls.bases = [ast.Attribute(value=ast.Name(id="nn", ctx=ast.Load()), attr="Module", ctx=ast.Load())]
    module = ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[]))
    namespace = {"torch": torch, "nn": nn, "F": F, "np": np, "pd": pd}
    exec(compile(module, str(path), "exec"), namespace)
    return namespace


class DeepSTABpCPU:
    """Exact released ProtT5 encoder and thermal MLP, on CPU only."""

    def __init__(self, threads=4):
        import torch
        from transformers import T5Config, T5EncoderModel, T5Tokenizer
        torch.set_num_threads(threads)
        source_dir = SOURCE / "prott5"
        self.tokenizer = T5Tokenizer.from_pretrained(str(source_dir), do_lower_case=False,
                                                     local_files_only=True, legacy=True)
        self.native = native_thermal_functions()
        self.head = self.native["deepSTAPpMLP"](dropout=0.1, learning_rate=0.0001, batch_size=1)
        # The released Lightning checkpoint has tensor state plus optimizer metadata.
        checkpoint = torch.load(ASSETS / "deepstabp_epoch1_step2316.ckpt", map_location="cpu", weights_only=True)
        head_state = checkpoint["state_dict"]
        incompatible = self.head.load_state_dict(head_state, strict=True)
        self.head_schema = {k: list(v.shape) for k, v in head_state.items()}
        self.head.eval()
        del checkpoint, head_state
        gc.collect()
        config = T5Config.from_pretrained(str(source_dir), local_files_only=True)
        self.encoder = T5EncoderModel(config).cpu().eval()
        # Read the already acquired pinned full encoder+decoder release. Only the
        # encoder and tied input embedding belong to upstream T5EncoderModel.
        full_state = torch.load(ASSETS / "prott5_pytorch_model.bin", map_location="cpu", weights_only=True, mmap=True)
        if "state_dict" in full_state:
            raise ValueError("unexpected_prott5_checkpoint_wrapper")
        expected = set(self.encoder.state_dict())
        selected = {k: full_state[k] for k in expected if k in full_state}
        if set(selected) != expected:
            raise ValueError("missing_original_encoder_state")
        excluded = set(full_state) - expected
        if any(not (k.startswith("decoder.") or k == "lm_head.weight") for k in excluded):
            raise ValueError("unrecognized_excluded_prott5_state")
        self.encoder.load_state_dict(selected, strict=True)
        self.encoder_schema_count = len(selected)
        self.excluded_original_decoder_state_count = len(excluded)
        del full_state, selected
        gc.collect()
        self.encoder.eval()
        if next(self.encoder.parameters()).device.type != "cpu":
            raise ValueError("cpu_only_validation_required")

    def predict(self, case_id, sequence, growth_temp_c=37, mode="Lysate"):
        import torch
        checked_sequence(sequence)
        if mode not in {"Lysate", "Cell"}:
            raise ValueError("invalid_thermal_context")
        # Native F# reader inserts a space between each residue before API input.
        records = [SimpleNamespace(header=case_id, sequence=" ".join(sequence))]
        with torch.inference_mode():
            output = self.native["determine_tm"](records, mode, growth_temp_c, self.encoder,
                                                     self.head, self.native["new_features"], self.tokenizer)
        if len(output) != 1 or output.iloc[0]["Protein"] != case_id:
            raise ValueError("native_thermal_identity_changed")
        value = float(output.iloc[0]["Tm"])
        if not math.isfinite(value):
            raise ValueError("nonfinite_thermal_prediction")
        return {"case_id": case_id, "predicted_tm_c": value, "hypothetical_growth_temp_c": growth_temp_c,
                "assumed_context": mode, "full_sequence_length": len(sequence)}
