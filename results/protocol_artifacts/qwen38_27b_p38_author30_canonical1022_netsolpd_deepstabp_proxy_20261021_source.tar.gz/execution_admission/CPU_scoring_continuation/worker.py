"""CPU-only, once-only scoring of P38's unchanged complete sealed30 outputs."""
from pathlib import Path
import argparse
import fcntl
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time

HERE=Path(__file__).resolve().parent
EXEC=HERE.parent
ROOT=EXEC.parents[4]
sys.path.insert(0,str(EXEC))
from admission import sha,validate,verified_inputs
from evaluate_locked import verified_sequences
from generation import stamp,write


def admitted(plan_path,plan_sha,review_path,review_sha):
    if sha(plan_path)!=plan_sha or sha(review_path)!=review_sha:raise ValueError('Exact CPU continuation plan/review changed')
    p=json.loads(plan_path.read_text());r=json.loads(review_path.read_text())
    for name,digest in p['files_sha256'].items():
        if Path(name).is_symlink()or sha(name)!=digest:raise ValueError('CPU continuation source/evidence changed')
    policy=Path(p['delegation_path']);authority=json.loads(policy.read_text())
    if (sha(policy)!=p['delegation_sha256']or r.get('reviewer')not in authority['authorized_reviewers']
            or r.get('reviewer')=='/root/p38_generation'or r.get('task_id')!='P38'or r.get('admitted')is not True
            or r.get('continuation_plan_sha256')!=plan_sha or r.get('delegation_sha256')!=sha(policy)
            or r.get('GPU_requests')!=0 or r.get('new_generator_calls')!=0 or r.get('maximum_proxy_attempts_per_case')!=1):
        raise ValueError('Different delegated peer must admit this exact CPU-only continuation')
    original=validate(p['original_plan_path'],p['original_plan_sha256'],p['root_admission_path'],p['root_admission_sha256'],require_job=False)
    return p,original


def boundary(p,original,accounting=True):
    runtime=EXEC/'runtime';run=Path(original['output_root'])
    stopped=json.loads((runtime/'own_Qwen_stopped_before_CPU_scores.json').read_text())
    state=json.loads((runtime/'status.json').read_text())
    if (state.get('stage')!='stopped_for_review'or state.get('error_type')!='FileExistsError'
            or 'private_GPU_audit_before_benchmark.json'not in state.get('error','')
            or stopped.get('own_server_stopped')is not True or stopped.get('other_runtimes_changed')is not False):
        raise ValueError('Exact generation-complete metadata-only failure boundary required')
    if accounting:
        rows=subprocess.run(['sacct','-j','245861','-n','-P','-X','-o','JobID,State,ExitCode'],
            capture_output=True,text=True,check=True,timeout=30).stdout.splitlines()
        if '245861|FAILED|1:0'not in rows:raise ValueError('Original allocation must be terminal with exact known failure')
    for name in ['CPU_environment_benchmark.json','offline_proxy_scoring_completion.json']:
        if(runtime/name).exists():raise FileExistsError('A prior benchmark scoring process must not be retried')
    if(run/'evaluation').exists():raise FileExistsError('Preserve prior proxy attempts; no selective retry')
    generation=run/'benchmark';done=json.loads((generation/'completion.json').read_text())
    if (sha(generation/'prediction_lock.json')!=p['generation_prediction_lock_sha256']
            or done.get('prediction_lock_sha256')!=p['generation_prediction_lock_sha256']
            or done.get('all_delivered')is not True or done.get('closed_slots')!=30 or done.get('delivered')!=30):
        raise ValueError('Exact complete30 once-only generation seal required')
    records=verified_sequences(verified_inputs(original),generation,p['generation_prediction_lock_sha256'])
    if len(records)!=30 or any(not r['sequence_valid']or not 1<=len(r['sequence'])<=1022 for r in records):
        raise ValueError('Every complete original output must obey adopted canonical1..1022 condition')
    return records


def environment(root):
    return {'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C.UTF-8','TZ':'America/Los_Angeles',
        'PYTHONHOME':str(root/'python'),'PYTHONPATH':str(root/'site-packages')+':'+str(EXEC),
        'LD_LIBRARY_PATH':str(root/'python/lib')+':'+str(root/'site-packages/torch/lib'),
        'PYTHONNOUSERSITE':'1','PYTHONDONTWRITEBYTECODE':'1','CUDA_VISIBLE_DEVICES':'',
        'OMP_NUM_THREADS':'4','MKL_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'4',
        'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','HF_HUB_DISABLE_TELEMETRY':'1',
        'DO_NOT_TRACK':'1','SLURM_JOB_ID':os.environ['SLURM_JOB_ID']}


def main():
    parser=argparse.ArgumentParser()
    for name in ['plan','review']:parser.add_argument('--'+name,type=Path,required=True)
    for name in ['plan-sha256','review-sha256']:parser.add_argument('--'+name,required=True)
    args=parser.parse_args();p,original=admitted(args.plan,args.plan_sha256,args.review,args.review_sha256)
    if not os.environ.get('SLURM_JOB_ID')or os.environ.get('CUDA_VISIBLE_DEVICES')!='':raise ValueError('CPU-only Slurm required')
    own=subprocess.run(['scontrol','show','job','-o',os.environ['SLURM_JOB_ID']],capture_output=True,text=True,check=True,timeout=30).stdout
    fields=dict(re.findall(r'(?:^|\s)(\w+)=([^\s]*)',own))
    if ('gres/gpu' in fields.get('ReqTRES','')or fields.get('WorkDir')!=str(ROOT)
            or fields.get('Command')!=str(HERE/'CPU.sbatch')):raise ValueError('Exact own zero-GPU CPU allocation required')
    locks=[]
    for path in [HERE/'allocation.lock',EXEC/'runtime/allocation.lock',EXEC/'runtime/protocol.lock']:
        lock=path.open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(lock)
    if(HERE/'started.json').exists():raise FileExistsError('No automatic scoring-allocation retry')
    boundary(p,original)
    write(HERE/'started.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'continuation_plan_sha256':args.plan_sha256,
        'independent_review_sha256':args.review_sha256,'original_generation_job_id':'245861','GPU_requests':0,'new_generator_calls':0})
    local=Path(tempfile.mkdtemp(prefix='bio-p38-score-'+os.environ['SLURM_JOB_ID']+'-'))
    try:
        manifest=json.loads(Path(original['CPU_runtime_manifest']).read_text())
        if sha(manifest['archive'])!=manifest['archive_sha256']:raise ValueError('Exact portable CPU archive differs')
        cpu=local/'CPU';cpu.mkdir()
        with tarfile.open(manifest['archive'])as archive:archive.extractall(cpu,filter='data')
        for name,item in manifest['files'].items():
            target=(cpu/name).resolve()
            if Path(name).is_absolute()or'..'in Path(name).parts or not target.is_relative_to(cpu)or sha(target)!=item['sha256']:
                raise ValueError('Exact portable CPU runtime member differs')
        write(HERE/'runtime_extraction.json',{'at_pacific':stamp(),'archive_sha256':manifest['archive_sha256'],
            'verified_members':len(manifest['files']),'GPU_requests':0,'training':False})
        env=environment(cpu);python=cpu/'python/bin/python3.12'
        # Byte-identical scorer in a private directory gives the neutral-only
        # phase fresh output paths; biological scoring uses the original path.
        neutral=local/'neutral';neutral.mkdir();copy=neutral/'score_worker.py'
        shutil.copyfile(EXEC/'score_worker.py',copy)
        if sha(copy)!=original['frozen_files_sha256'][str(EXEC/'score_worker.py')]:raise ValueError('Neutral scorer copy changed')
        common=['--plan',p['original_plan_path'],'--plan-sha256',p['original_plan_sha256'],
            '--admission',p['root_admission_path'],'--admission-sha256',p['root_admission_sha256']]
        with(HERE/'neutral.log').open('x')as log:
            subprocess.run([str(python),str(copy),*common,'--mode','neutral'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=7200)
        gate=neutral/'runtime/neutral_evaluator_gate'
        shutil.copytree(gate,HERE/'neutral_evaluator_gate')
        shutil.copyfile(neutral/'runtime/CPU_environment_neutral.json',HERE/'CPU_environment_neutral.json')
        if json.loads((gate/'completion.json').read_text()).get('passed')is not True:raise ValueError('Actual CPU continuation resource gate failed')
        boundary(p,original)
        write(HERE/'benchmark_scoring_started.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],
            'generation_prediction_lock_sha256':p['generation_prediction_lock_sha256'],'maximum_proxy_attempts_per_case':1,
            'new_generator_calls':0,'GPU_requests':0})
        with(HERE/'benchmark.log').open('x')as log:
            subprocess.run([str(python),str(EXEC/'score_worker.py'),*common,'--mode','benchmark'],
                env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=7200)
        done=json.loads((EXEC/'runtime/offline_proxy_scoring_completion.json').read_text())
        if done['job_id']!=os.environ['SLURM_JOB_ID']or done['generation_lock_sha256']!=p['generation_prediction_lock_sha256']:
            raise ValueError('Exact CPU scoring closure identity differs')
        write(HERE/'completion.json',{'at_pacific':stamp(),'stage':'CPU_only_scoring_continuation_complete',
            'job_id':os.environ['SLURM_JOB_ID'],'generation_job_id':'245861','continuation_plan_sha256':args.plan_sha256,
            'original_plan_sha256':p['original_plan_sha256'],'independent_review_sha256':args.review_sha256,
            'generation_lock_sha256':p['generation_prediction_lock_sha256'],'scores_sha256':done['scores_sha256'],
            'full_proxy_condition_complete':done['full_proxy_condition_complete'],'new_generator_calls':0,'GPU_requests':0,
            'native_NatureLM_score':False,'experimental_validation':False})
    finally:shutil.rmtree(local)


if __name__=='__main__':main()
