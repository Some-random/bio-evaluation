"""Submit the independently admitted zero-GPU scoring continuation once."""
from pathlib import Path
import argparse
import fcntl
import subprocess
import worker

HERE=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser()
    for name in ['plan','review']:parser.add_argument('--'+name,type=Path,required=True)
    for name in ['plan-sha256','review-sha256']:parser.add_argument('--'+name,required=True)
    args=parser.parse_args();p,original=worker.admitted(args.plan,args.plan_sha256,args.review,args.review_sha256)
    with(HERE/'submission.lock').open('a')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if any((HERE/name).exists()for name in ['submission_attempt.json','submission_receipt.json','started.json']):
            raise FileExistsError('Prior CPU scoring submission/allocation must not be repeated')
        queue=subprocess.run(['squeue','-h','-u','dongweij','-o','%i|%j|%T'],capture_output=True,text=True,check=True,timeout=30).stdout
        if 'bio-p38-score-locked30'in queue:raise ValueError('Existing scorer allocation must not be duplicated')
        locks=[]
        for path in [worker.EXEC/'runtime/allocation.lock',worker.EXEC/'runtime/protocol.lock']:
            held=path.open('a');fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(held)
        worker.boundary(p,original)
        command=['sbatch','--parsable',str(HERE/'CPU.sbatch'),args.plan_sha256,str(args.review),args.review_sha256]
        worker.write(HERE/'submission_attempt.json',{'at_pacific':worker.stamp(),'continuation_plan_sha256':args.plan_sha256,
            'review_sha256':args.review_sha256,'GPU_requests':0,'new_generator_calls':0,'no_automatic_retry':True})
        result=subprocess.run(command,capture_output=True,text=True,timeout=60,cwd=worker.ROOT)
        worker.write(HERE/'submission_result.json',{'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
        if result.returncode!=0:raise RuntimeError('CPU scheduler rejection preserved; no automatic retry')
        job=result.stdout.strip().split(';')[0]
        if not job.isdigit():raise ValueError('Ambiguous CPU scheduler result; reconcile without resubmitting')
        receipt={'at_pacific':worker.stamp(),'job_id':job,'continuation_plan_sha256':args.plan_sha256,
            'review_path':str(args.review),'review_sha256':args.review_sha256,'original_generation_job_id':'245861',
            'GPU_requests':0,'new_generator_calls':0,'maximum_proxy_attempts_per_case':1,'actual_scoring_started':False}
        worker.write(HERE/'submission_receipt.json',receipt);print(job)


if __name__=='__main__':main()
