"""Artificial no-retry/complete-cohort/CPU-environment boundary checks."""
from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch
import worker


class BoundaryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.runtime=self.root/'runtime'
        self.runtime.mkdir();self.run=self.root/'run';self.gen=self.run/'benchmark';self.gen.mkdir(parents=True)
        self.save(self.runtime/'status.json',{'stage':'stopped_for_review','error_type':'FileExistsError',
            'error':'private_GPU_audit_before_benchmark.json'})
        self.save(self.runtime/'own_Qwen_stopped_before_CPU_scores.json',{'own_server_stopped':True,'other_runtimes_changed':False})
        self.save(self.gen/'prediction_lock.json',{'artificial':True});self.digest=worker.sha(self.gen/'prediction_lock.json')
        self.save(self.gen/'completion.json',{'prediction_lock_sha256':self.digest,'all_delivered':True,'closed_slots':30,'delivered':30})
        self.records=[{'sequence_valid':True,'sequence':'A'}for _ in range(30)]
        self.patches=[patch.object(worker,'EXEC',self.root),patch.object(worker,'verified_inputs',return_value=[]),
            patch.object(worker,'verified_sequences',return_value=self.records)]
        for p in self.patches:p.start()
    def tearDown(self):
        for p in reversed(self.patches):p.stop()
        self.tmp.cleanup()
    def save(self,path,value):path.write_text(json.dumps(value))
    def boundary(self):return worker.boundary({'generation_prediction_lock_sha256':self.digest},{'output_root':str(self.run)},accounting=False)
    def test_exact_no_attempt_boundary_passes(self):self.assertEqual(len(self.boundary()),30)
    def test_existing_evaluation_never_retried(self):
        (self.run/'evaluation').mkdir()
        with self.assertRaises(FileExistsError):self.boundary()
    def test_existing_scorer_environment_never_retried(self):
        self.save(self.runtime/'CPU_environment_benchmark.json',{})
        with self.assertRaises(FileExistsError):self.boundary()
    def test_changed_lock_rejected(self):
        self.save(self.gen/'prediction_lock.json',{'changed':True})
        with self.assertRaises(ValueError):self.boundary()
    def test_incomplete_cohort_rejected(self):
        self.records.pop()
        with self.assertRaises(ValueError):self.boundary()
    def test_oversized_complete_sequence_rejected_without_cropping(self):
        self.records[0]['sequence']='A'*1023
        with self.assertRaises(ValueError):self.boundary()
        self.assertEqual(len(self.records[0]['sequence']),1023)
    def test_unrelated_error_not_admitted(self):
        self.save(self.runtime/'status.json',{'stage':'stopped_for_review','error_type':'TimeoutError','error':'other'})
        with self.assertRaises(ValueError):self.boundary()
    def test_CPU_environment_drops_credentials_and_GPU_libraries(self):
        with patch.dict(worker.os.environ,{'SLURM_JOB_ID':'ARTIFICIAL','OPENAI_API_KEY':'ARTIFICIAL','CUDA_HOME':'ARTIFICIAL'}):
            env=worker.environment(self.root)
        self.assertEqual(env['CUDA_VISIBLE_DEVICES'],'');self.assertNotIn('OPENAI_API_KEY',env);self.assertNotIn('CUDA_HOME',env)


if __name__=='__main__':unittest.main()
