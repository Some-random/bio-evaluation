"""Pure source-pinned PFArena task adapter. No API or real-case loader."""
import argparse,ast,hashlib,json,re,sys
from dataclasses import dataclass,asdict
from pathlib import Path
import importlib.util
ROOT=Path(__file__).resolve().parents[5]
SOURCE=ROOT/'.local/source_recovery_round2_2026-10-19/pfarena/official_code/code'
CONTEXT_FIELDS=('assay_id','uniprot_id','primary_task_class','fitness_type','readout_subclass','wildtype_sequence','sequence_length')
PINS={'llm/infer_api_mutation.py':'242a8a36503860ecd3ac9c2609516d07860b66be37cd7f9d7c983a400e9d6ad4','router.py':'f1ce2e22dec4efdd6051706289c5e108b0f569c44bc71655c12844b91688ce18','prompts/multi_mutant_ranking_anchor.py':'b9b42655d35e83f41f91342f58f08b356121e371eb89b9646aad3cf2d54b4405','prompts/multi_mutant_ranking_mutation.py':'4db6b6e95575cdb75317eab85761ecd093ae89a9658609cab1239759b07678e4'}
NATIVE_TASK='4'

def native_builders():
 namespace={'argparse':argparse,'dataclass':dataclass,'Path':Path,'json':json,'re':re,'__name__':'isolated_pfarena_native_builders'}
 nodes={}
 for filename,expected in PINS.items():
  data=(SOURCE/filename).read_bytes()
  if hashlib.sha256(data).hexdigest()!=expected:raise ValueError('upstream_source_changed')
  nodes[filename]=ast.parse(data.decode())
 factory_name='multi_mutant_ranking_anchor_template' if NATIVE_TASK=='3' else 'multi_mutant_ranking_mutation_template'
 factory_file='prompts/multi_mutant_ranking_anchor.py' if NATIVE_TASK=='3' else 'prompts/multi_mutant_ranking_mutation.py'
 factory=next(n for n in nodes[factory_file].body if isinstance(n,ast.FunctionDef) and n.name==factory_name)
 exec(compile(ast.Module(body=[factory],type_ignores=[]),factory_file,'exec'),namespace)
 # Exact selected upstream factory. This wrapper chooses the frozen task only.
 namespace['get_prompt_template']=lambda task_id:namespace[factory_name]() if task_id==NATIVE_TASK else (_ for _ in ()).throw(ValueError('other_task_forbidden'))
 selected={'AssayContext','MutationTask','context_from_assay_row','build_prompt','extract_balanced_json','parse_rank_mode_mutants'}
 body=[n for n in nodes['llm/infer_api_mutation.py'].body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in selected]
 exec(compile(ast.Module(body=body,type_ignores=[]),'llm/infer_api_mutation.py','exec'),namespace)
 return namespace

def build_messages(context_row,candidate_ids,allowed_assays,held_assays,*,anchor_mutant='',anchor_dms_score='',single_mutant_dms_scores=''):
 assay=context_row['assay_id'].strip()
 if assay in held_assays or assay not in allowed_assays:raise PermissionError('assay_not_independently_reviewed_or_held')
 ids=tuple(candidate_ids)
 if not ids or any(not isinstance(x,str) or not x or any(c.isspace() for c in x) for x in ids) or len(set(ids))!=len(ids):raise ValueError('candidate_ids_must_be_complete_unique_frozen_tokens')
 projected={key:context_row[key] for key in CONTEXT_FIELDS}
 native=native_builders();context=native['context_from_assay_row'](projected,Path('/local/native/assay.csv'))
 if len(context.wildtype_sequence)!=context.sequence_length:raise ValueError('full_sequence_length_mismatch')
 if NATIVE_TASK=='3' and (not anchor_mutant or not anchor_dms_score):raise ValueError('native_anchor_context_required')
 if NATIVE_TASK=='4' and not single_mutant_dms_scores:raise ValueError('native_single_mutant_context_required')
 task=native['MutationTask'](input_path=Path('/local/native/input.csv'),output_path=Path('/local/output/predictions.csv'),context=context,mutants=ids,ground_truth_path=None,anchor_mutant=anchor_mutant if NATIVE_TASK=='3' else '',anchor_dms_score=anchor_dms_score if NATIVE_TASK=='3' else '',single_mutant_dms_scores=single_mutant_dms_scores if NATIVE_TASK=='4' else '')
 return [{'role':'user','content':native['build_prompt'](task,argparse.Namespace(task_id=NATIVE_TASK))}]

def audit_saved_final(candidate_ids,raw_final):
 native=native_builders()
 # Keep native extracted ranking and separate raw completeness diagnostic.
 parsed=native['parse_rank_mode_mutants'](raw_final)
 obj=native['extract_balanced_json'](raw_final)
 name='pfarena_delivery_audit_isolated'
 spec=importlib.util.spec_from_file_location(name,ROOT/'scripts/pfarena_output_contract_checks.py');mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
 return {'native_parsed_ranking':list(parsed) if parsed is not None else None,'delivery_audit':asdict(mod.audit_ranking_object(candidate_ids,obj)),'native_scoring_formula_changed':False}
