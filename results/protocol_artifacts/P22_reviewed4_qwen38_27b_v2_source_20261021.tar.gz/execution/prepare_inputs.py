"""Independently prepare four native T4 vertebrate isolated-domain inputs.

Candidate outcomes stay scorer-only. Entire released single-mutant score context
is legitimate native input and is retained verbatim through the pinned builder.
"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import ast,csv,hashlib,importlib.util,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[4]
DATA=ROOT/'.local/source_recovery_round2_2026-10-19/pfarena/authenticated/raw/T4_single_mutant_informed_multi_mutant_ranking'
CODE=ROOT/'.local/source_recovery_round2_2026-10-19/pfarena/official_code/code'
from input_contract import AMINO_ACIDS,CONDITION,validate_input_context
IDENTITIES={
 'P29323':('Homo sapiens (Human)','Human EphB2 isolated domain; native folding-free-energy stability, not receptor activation or binding engineering.'),
 'P48052':('Homo sapiens (Human)','Human carboxypeptidase A2 isolated domain; native folding-free-energy stability, not catalytic activity selection.'),
 'P07751':('Gallus gallus (Chicken)','Chicken alpha-II spectrin isolated domain; native folding-free-energy stability, not organism growth or interaction engineering.'),
 'Q9ULT8':('Homo sapiens (Human)','Human HECTD1 isolated domain; native folding-free-energy stability, not ubiquitination activity selection.')}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rel(p):return str(Path(p).resolve().relative_to(ROOT))
def save(n,v):
 with (HERE/n).open('x') as f:json.dump(v,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
def adapter():
 p=HERE.parent/'engineering_20261020/ranking_adapter.py';spec=importlib.util.spec_from_file_location('_p22_native_input_adapter',p);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);return m

def build_case(native,row,candidates,text,case_id,allowed):
 ctx={'case_id':case_id,'wildtype_sequence':row['wildtype_sequence'].strip(),'sequence_length':int(float(row['sequence_length'])),'candidate_ids':list(candidates),'single_mutant_dms_scores':text};validate_input_context(ctx)
 projected={k:row[k] for k in native.CONTEXT_FIELDS}
 return {'task_id':'P22','case_id':case_id,'messages':native.build_messages(projected,candidates,allowed,set(),single_mutant_dms_scores=text)},ctx

def main():
 native=adapter();namespace=native.native_builders()
 tree=ast.parse((CODE/'llm/infer_api_mutation.py').read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='read_single_mutant_dms_scores')
 scope={'csv':csv,'Path':Path};exec(compile(ast.Module(body=[fn],type_ignores=[]),'native_read_single_mutant_dms_scores','exec'),scope)
 evidence_path=HERE/'source_checks/T4_mammalian_uniprot_metadata.tsv';evidence={r['Entry']:r for r in csv.DictReader(evidence_path.open(),delimiter='\t')}
 rows=list(csv.DictReader((DATA/'assay.csv').open()));selected=[r for r in rows if r['source_dataset']=='MegaScale' and r['uniprot_id'] in IDENTITIES]
 if len(rows)!=29 or len(selected)!=4:raise ValueError('Exact native/positive-review cohort changed')
 allowed={r['assay_id'] for r in selected};acquisition_path=DATA.parent.parent/'completion.json';acquisition=json.loads(acquisition_path.read_text())
 cases=[];contexts=[];reviews=[];refs=[]
 for row in selected:
  organism,reason=IDENTITIES[row['uniprot_id']];info=evidence[row['uniprot_id']]
  if info['Organism']!=organism:raise ValueError('Independent exact official organism identity differs')
  if (row['primary_task_class'],row['fitness_type'],row['readout_subclass'])!=('stability','stability','folding_free_energy_stability_readout'):raise ValueError('Independent ordinary stability objective differs')
  source=DATA/row['DMS_filename'];single=source.parent/'single_mutant_context.csv'
  if DATA.parent/row['single_context_data_path']!=single:raise ValueError('Native single context path differs')
  for f in [source,single]:
   record=acquisition['files']['T4_single_mutant_informed_multi_mutant_ranking/'+str(f.relative_to(DATA))]
   if not record['publisher_digest_verified'] or sha(f)!=record['sha256']:raise ValueError('Publisher pinned source/context differs')
  candidates=[];groups=set()
  for projected in csv.DictReader(source.open()):
   # Protected combination DMS_score/sequence are never accessed.
   value=projected['mutant'].strip()
   if value:candidates.append(value)
   group=projected['candidate_group_id'].strip()
   if group:groups.add(group)
  if len(groups)!=1 or len(candidates)!=int(float(row['n_combo_candidates'])):raise ValueError('Complete native combination cohort differs')
  text=scope['read_single_mutant_dms_scores'](single)
  if len(text.splitlines())!=int(float(row['n_context_single'])):raise ValueError('Full native single context omitted')
  case_id='P22::'+row['assay_id'];case,ctx=build_case(native,row,candidates,text,case_id,allowed);cases.append(case);contexts.append(ctx)
  reviews.append({'case_id':case_id,'assay_id':row['assay_id'],'uniprot_id':row['uniprot_id'],'verified_organism':organism,'verified_protein_name':info['Protein names'],'native_objective':'folding_free_energy_stability_readout','scope_reason':reason,'native_fragment_length':ctx['sequence_length'],'candidate_count':len(candidates),'legitimate_supplied_single_context_rows':len(text.splitlines()),'single_context_path':rel(single),'single_context_sha256':sha(single),'native_combination_score_fields_accessed':False,'native_prompt_preserved':True,'independent_T4_input_preparation_admitted':True,'runtime_dispatch_admitted':False})
  record=acquisition['files']['T4_single_mutant_informed_multi_mutant_ranking/'+row['DMS_filename']]
  refs.append({'case_id':case_id,'assay_id':row['assay_id'],'native_truth_id':next(iter(groups)),'target_path':rel(source),'sha256':record['sha256'],'native_relative_path':row['DMS_filename'],'publisher_digest_verified_at_acquisition':True,'protected_combination_score_fields_accessed_in_preparation':False})
 dev=[];devctx=[]
 for index,count in enumerate([19,97,100],1):
  sequence=AMINO_ACIDS*6;candidates=[];single_ids=[]
  for position in range(2,count+2):
   before=sequence[position-1];after=AMINO_ACIDS[(AMINO_ACIDS.index(before)+1)%20];single_ids.append(before+str(position)+after);candidates.append('A1C+'+single_ids[-1])
  singles=['A1C',*single_ids];text='\n'.join(x+': 0.0' for x in singles)
  assay='SYNTHETIC_T4_DELIVERY_'+str(index);row={'assay_id':assay,'uniprot_id':'ARTIFICIAL_ONLY','primary_task_class':'stability','fitness_type':'stability','readout_subclass':'synthetic_interface_no_real_measurements','wildtype_sequence':sequence,'sequence_length':str(len(sequence))}
  c,ctx=build_case(native,row,candidates,text,'P22::synthetic_delivery_'+str(index).zfill(2),{assay});dev.append(c);devctx.append(ctx)
 for phase,cs,cts in [('benchmark',cases,contexts),('development',dev,devctx)]:
  with (HERE/(phase+'_inputs.jsonl')).open('x') as f:
   for c in cs:f.write(json.dumps(c,sort_keys=True,allow_nan=False)+'\n')
  save(phase+'_delivery_contexts.json',{'task_id':'P22','cases':cts,'protected_combination_reference_labels_included':False,'legitimate_complete_native_single_mutant_scores_included':True})
 now=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
 save('input_review.json',{'at_pacific':now,'task_id':'P22','condition':CONDITION,'approved_case_ids':[c['case_id'] for c in cases],'cases':reviews,'native_panel_assays':29,'reviewed_assays':4,'remaining_outside_this_reviewed_condition':25,'all_native_assays_approved':False,'P21_or_P19_admission_inherited':False,'P20_interrupted_action_reopened':False,'excluded_before_candidate_or_single_context_content_access':[r['assay_id'] for r in rows if r['assay_id'] not in allowed],'held_cases':[],'basis':'Independent exact official organism, source fragment/objective and native single-context review. Positive4 only; no safety classification of remaining25.','source_metadata_sha256':sha(DATA/'assay.csv'),'publisher_identity_metadata_sha256':sha(evidence_path),'new_model_calls':0,'protected_combination_outcome_score_fields_accessed':False})
 save('development_review.json',{'task_id':'P22','approved_case_ids':[c['case_id'] for c in dev],'held_cases':[],'synthetic_only':True,'biological_correctness_assessed':False})
 save('scorer_only_manifest.json',{'task_id':'P22','condition':CONDITION,'cases':refs,'source_dataset_revision':'5be3973dd45a9d7d33572f016be18f8ef941f2ff','reference_labels_isolated':True,'native_scorer_file':rel(CODE/'evaluation/full.py'),'native_scorer_sha256':sha(CODE/'evaluation/full.py'),'native_router_file':rel(CODE/'router.py'),'native_router_sha256':sha(CODE/'router.py'),'native_parser_file':rel(CODE/'llm/infer_api_mutation.py'),'native_parser_sha256':sha(CODE/'llm/infer_api_mutation.py'),'native_metrics':['spearman','NDCG','NMS@5','Recall@5'],'native_panel_assays':29,'native_strict_coverage':True,'missing_query_random_fallback_enabled':False})
 save('input_materialization_receipt.json',{'at_pacific':now,'task_id':'P22','stage':'native_reviewed4_and_synthetic3_materialized_not_dispatched','native_panel_assays':29,'reviewed_assays':4,'remaining_not_admitted_to_this_condition':25,'human_assays':3,'chicken_assays':1,'candidate_count_total':sum(len(c['candidate_ids']) for c in contexts),'native_single_context_rows':sum(len(c['single_mutant_dms_scores'].splitlines()) for c in contexts),'native_full_sequences_prompts_candidates_and_single_context_preserved':True,'protected_combination_outcome_score_fields_accessed':False,'new_inference_calls':0,'GPU_allocations':0})
 print(json.dumps({'reviewed_inputs':4,'synthetic_inputs':3,'native_panel':29,'candidate_total':sum(len(c['candidate_ids']) for c in contexts),'calls':0}))
if __name__=='__main__':main()
