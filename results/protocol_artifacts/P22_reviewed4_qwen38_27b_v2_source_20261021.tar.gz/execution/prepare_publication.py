"""Prepare a local publication candidate after successful terminal P22 scoring.

No upload, website or model operation. Original locked trajectory bytes remain
unchanged. Model weights, environments, bootstrap/server logs and protected
measurement CSV files are excluded by an explicit allowlist.
"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
import shutil
import subprocess
import tarfile

HERE=Path(__file__).resolve().parent
TASK=HERE


def read(path):return json.loads(Path(path).read_text())


def sha(path):
    result=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):result.update(chunk)
    return result.hexdigest()


def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')


def main():
    runtime=HERE/'runtime';terminal=read(runtime/'terminal_receipt.json')
    if terminal.get('reviewed4_condition_terminal') is not True or terminal.get('full_native29_complete') is not False:
        raise ValueError('Actual terminal reviewed4 result required')
    job=terminal['job_id']
    accounting=subprocess.run(['sacct','-j'+job,'--format=JobIDRaw,State,ExitCode,Elapsed,AllocTRES','-P','--noheader'],text=True,capture_output=True,check=True).stdout
    roots=[line.split('|') for line in accounting.splitlines() if line.split('|')[0]==job]
    if len(roots)!=1 or roots[0][1:3]!=['COMPLETED','0:0']:raise ValueError('Successful Slurm terminal proof required')
    if read(runtime/'server_terminal.json')['own_server_stopped'] is not True:raise ValueError('Own server cleanup proof required')
    plan=read(HERE/'plan.json');scope=read(HERE/'source_scope.json')
    if scope['approved']!=4 or scope['native_panel']!=29 or scope['remaining_unadmitted']!=25:raise ValueError('Fixed subset qualification changed')
    scores=read(runtime/'benchmark/scores.json')
    if scores['planned_assays']!=4 or scores['native_panel_assays']!=29 or scores['full_native_benchmark_complete'] is not False:
        raise ValueError('Native score lost its4/29 subset qualification')
    if sha(runtime/'benchmark/scores.json')!=terminal['native_score_sha256']:raise ValueError('Native score bytes changed')
    target=HERE/'publication_candidate';target.mkdir(exist_ok=False)
    for phase,expected in [('development',3),('benchmark',4)]:
        base=runtime/phase;done=read(base/'completion.json');lock=read(base/'prediction_lock.json')
        if done['planned']!=expected or done['terminal']!=expected:raise ValueError('Incomplete phase cannot be packaged as terminal')
        if sha(base/'prediction_lock.json')!=done['prediction_lock_sha256']:raise ValueError('Prediction lock hash changed')
        for relative,digest in lock['files_sha256'].items():
            path=(base/relative).resolve()
            if not path.is_relative_to(base.resolve()) or path.is_symlink() or not path.is_file() or sha(path)!=digest:
                raise ValueError('Locked member is not the exact original file')
            destination=target/'trajectories'/phase/relative;destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(path,destination)
        for name in ['completion.json','prediction_lock.json','progress.json']:
            shutil.copyfile(base/name,target/'trajectories'/phase/name)
    shutil.copyfile(runtime/'benchmark/scores.json',target/'scores.json')
    for phase in ['development','benchmark']:
        # Frozen admitted prompts only; no protected target/reference CSV files.
        shutil.copyfile(TASK/(phase+'_inputs.jsonl'),target/(phase+'_inputs.jsonl'))
        cfg=read(plan[phase+'_config'])
        keep=['task_id','condition','run_id','model','model_revision','generation','planned','split','native_panel_assays','input_sha256','review_sha256','native_prompt_preserved','material_differences','full_native_benchmark_complete']
        save(target/(phase+'_configuration.json'),{key:cfg[key] for key in keep if key in cfg})
    save(target/'scope.json',{'benchmark':'PFArena','task':'Single-mutant-informed ranking,reviewed vertebrate domain-stability subset',
        'admitted_assays':4,'native_panel_assays':29,'remaining_assays_not_admitted_to_this_condition':25,
        'human_assays':3,'chicken_assays':1,'approved_case_ids':scope['approved_case_ids'],
        'full_native_benchmark_complete':False,'full_catalog_complete':False,'no_new_head_training':True})
    env=read(runtime/'environment.json')
    save(target/'execution_provenance.json',{'job_id':job,'Slurm_terminal_accounting':accounting,
        'model':plan['model'],'revision':plan['model_revision'],'dtype':'bfloat16','tensor_parallel_size':1,
        'uniform_output_tokens':16384,'context_limit':65536,'condition':plan['condition'],
        'model_runner':'legacy_V1_explicit','custom_logits_processor':plan['custom_logits_processor'],
        'mandatory_plugin_import_sha256':sha(runtime/'mandatory_plugin_import.json'),
        'packages':read(runtime/'post_exec_package_identity.json')['packages'],
        'plan_sha256':sha(HERE/'plan.json'),'root_admission_sha256':read(runtime/'allocation_started.json')['admission_sha256'],
        'native_scorer_sha256':plan['frozen_files_sha256'][plan['scorer']],
        'native_prompt_and_scorer_unchanged':True,'source_scope_sha256':sha(HERE/'source_scope.json'),
        'native_measurement_CSV_files_packaged':False,'model_weights_or_runtime_environment_packaged':False})
    row={'evaluation':'PFArena — single-mutant-informed ranking','scope':'Reviewed vertebrate domain-stability subset:4/29 assays',
        'model':'Qwen3.8-27B','Qwen_native_metrics':scores['native_metrics'],
        'native_scoring_status':scores['native_scoring_status'],'GPT_models':'Not evaluated on this subset',
        'full_native_benchmark_complete':False,'full_catalog_complete':False,
        'measurement_interpretation':'Retrospective native comparison with existing assay measurements; no experimental validation of proposals.',
        'scores_sha256':sha(target/'scores.json'),'benchmark_prediction_lock_sha256':read(runtime/'benchmark/completion.json')['prediction_lock_sha256']}
    save(target/'result_row.json',row)
    metric_text='; '.join(name+'='+str(value) for name,value in (scores['native_metrics'] or {}).items()) or 'Undefined under native strict coverage'
    (target/'RESULT_ROW.md').write_text('| Evaluation | Qwen3.8-27B | GPT models |\n| --- | --- | --- |\n| PFArena — single-mutant-informed ranking,reviewed vertebrate stability subset(4/29 assays) | '+metric_text+' | Not evaluated |\n\nThis subset result does not complete the native29-assay panel or the retained catalog.\n')
    manifest={str(path.relative_to(target)):{'sha256':sha(path),'bytes':path.stat().st_size} for path in sorted(target.rglob('*')) if path.is_file()}
    save(target/'package_manifest.json',{'prepared_at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        'role':'local_publication_candidate_not_uploaded','files':manifest,'protected_measurement_tables_included':False,
        'model_weights_environments_or_credentials_included':False,'original_locked_trajectory_bytes_changed':False})
    archive=HERE/'P22_reviewed4_trajectory_publication_candidate.tar.gz'
    with tarfile.open(archive,'x:gz') as out:out.add(target,arcname='P22_reviewed4')
    save(HERE/'publication_candidate_receipt.json',{'at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        'stage':'prepared_local_publication_candidate_not_uploaded','job_id':job,'reviewed_assays':4,'native_panel':29,
        'native_scoring_status':scores['native_scoring_status'],'native_metrics':scores['native_metrics'],
        'archive_path':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,
        'publication_candidate_directory':str(target),'package_manifest_sha256':sha(target/'package_manifest.json'),
        'actual_publication_performed':False,'website_or_schedule_changed':False})
    print(json.dumps({'prepared_local_publication_candidate':str(archive),'native_scoring_status':scores['native_scoring_status'],
        'native_metrics':scores['native_metrics'],'uploaded':False}))


if __name__=='__main__':main()
