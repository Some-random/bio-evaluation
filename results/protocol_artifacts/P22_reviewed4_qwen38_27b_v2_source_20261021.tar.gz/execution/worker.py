"""Separate TP1 P22 allocation: existing synthetic3 gate -> reviewed4 -> scorer.

Never submitted by preparation. A frozen root admission and Slurm allocation
are mandatory before runtime extraction or server startup. Original P22
native prompts/parser/scoring functions remain unchanged.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request
import urllib.parse
from datetime import datetime
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
sys.path.insert(0, str(HERE))
import protocol


def stamp(): return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def read(path): return json.loads(Path(path).read_text())


def sha(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file(): raise ValueError('Pinned ordinary file required')
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8*1024*1024), b''): value.update(chunk)
    return value.hexdigest()


def save(path, value, exclusive=True):
    path = Path(path);path.parent.mkdir(parents=True, exist_ok=True)
    if exclusive:
        with path.open('x') as stream: json.dump(value, stream, indent=2);stream.write('\n')
    else:
        temp = path.with_name(path.name+'.tmp')
        with temp.open('w') as stream: json.dump(value, stream, indent=2);stream.write('\n')
        temp.chmod(0o600);temp.replace(path)
    path.chmod(0o600)


def load_module(name, path, extra_path=None):
    if extra_path: sys.path.insert(0, str(extra_path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec);sys.modules[name] = module;spec.loader.exec_module(module)
    return module


def endpoint_bind_address(plan):
    parsed=urllib.parse.urlsplit(plan['endpoint'])
    if parsed.scheme!='http' or parsed.hostname!='127.0.0.1' or parsed.port!=8423 or parsed.path!='/v1':
        raise ValueError('Exact independent V2 loopback endpoint required')
    return parsed.hostname,parsed.port


def validate_plan(path, expected):
    if sha(path) != expected: raise ValueError('Frozen P22 execution plan changed')
    plan = read(path)
    if (plan.get('task_id') != 'P22' or plan.get('scope') != protocol.SCOPE or plan.get('planned') != 4 or
            plan.get('synthetic_development_planned') != 3 or plan.get('gpus_requested') != 1 or
            plan.get('native_panel_assays') != 29 or plan.get('remaining_unadmitted_assays') != 25):
        raise ValueError('Only the exact separately admitted vertebrate stability4 subset is eligible')
    if (plan['generation']['max_tokens'] != 16384 or plan['generation']['chat_template_kwargs'] != {'enable_thinking': False} or
            plan['endpoint'] != 'http://127.0.0.1:8423/v1' or Path(plan['runtime_root']).resolve() != HERE/'runtime'):
        raise ValueError('Uniform16K condition or dedicated runtime identity changed')
    if (plan.get('condition') != 'PFARENA_T4_REVIEWED_VERTEBRATE_DOMAIN_CANONICAL_JSON_PERMUTATION_V2' or
            plan.get('mandatory_model_runner') != 'legacy_V1_explicit' or
            plan.get('custom_logits_processor') != 'p22_permutation_logits:P22PermutationLogitsProcessor'):
        raise ValueError('Exact mandatory T4 full-permutation generation constraint is required')
    for name, expected_file in plan['frozen_files_sha256'].items():
        if sha(name) != expected_file: raise ValueError('Frozen P22/V06 runtime dependency changed: '+name)
    return plan


def helpers(plan):
    path = Path(plan['vetted_V06_worker'])
    return load_module('p22_vetted_V06_runtime_helpers', path, path.parent)


def project_gpu_audit(plan):
    path = Path(plan['project_gpu_audit_helper'])
    if sha(path) != plan['project_gpu_audit_helper_sha256']:
        raise ValueError('Root-reviewed project GPU accounting helper changed')
    audit = load_module('p22_v4_exact_project_GPU_audit', path)
    return audit.conservative_project_gpu_audit(require_own_job=True)


def check_root_admission(path, expected, plan_sha, plan):
    if sha(path) != expected: raise ValueError('Root admission digest changed')
    admission = read(path)
    protocol.validate_admission_data(admission, plan_sha, plan['source_scope_sha256'])
    audit = Path(admission['gpu_audit_receipt'])
    if sha(audit) != admission['gpu_audit_receipt_sha256']: raise ValueError('Root GPU budget audit changed')
    if not os.environ.get('SLURM_JOB_ID'): raise ValueError('Actual Slurm allocation required')
    return admission


def activate_private_runtime(shared, common, local, runtime, argv, executor=None):
    """After archive extraction: overlay, pinned install/check, then private exec."""
    receipts = common.apply_overlay(local)
    save(runtime/'runtime_archive_receipt.json', {'local_prefix': str(local), **receipts})
    environment = shared.clean_environment(common, local)
    shared.install_private_runtime(local/'python/bin/python3.12', environment, runtime)
    environment['VLLM_USE_V2_MODEL_RUNNER'] = '0'
    environment['PYTHONPATH'] = str(HERE)
    command = [str(local/'python/bin/python3.12'), str(Path(__file__).resolve()), *argv, '--runtime-dir', str(local)]
    (executor or os.execve)(command[0], command, environment)


def verify_runtime_identity(shared, package_info, visible_gpus):
    shared.verify_package_identity(package_info)
    if visible_gpus != 1:
        raise ValueError('Exactly one Slurm-visible GPU required after the verified pinned install')
    return package_info


def phase_grant(plan, config, identity_path, admission_path, phase, dev_completion=None):
    if phase == 'benchmark' and dev_completion is None:
        raise ValueError('Actual sealed development completion required')
    root = Path(plan['runtime_root'])
    grant = {'authorized': True, 'task_id': 'P22', 'run_id': config['run_id'],
        'config_sha256': sha(plan[phase+'_config']), 'endpoint': plan['endpoint'],
        'server_identity_file': str(identity_path), 'server_identity_sha256': sha(identity_path),
        'root_admission_sha256': sha(admission_path), 'phase': phase,
        'planned': config['planned'], 'one_attempt_per_case': True,
        'source_scope_sha256': plan['source_scope_sha256']}
    if phase == 'benchmark':
        if dev_completion is None: raise ValueError('Actual sealed development completion required')
        grant['development_completion_sha256'] = sha(dev_completion)
        grant['development_prediction_lock_sha256'] = read(dev_completion)['prediction_lock_sha256']
    target = root/(phase+'_runtime_grant.json');save(target, grant)
    return target


def execute_phases(plan, python, identity_path, admission_path):
    runtime = Path(plan['runtime_root'])
    dev_config, bench_config = read(plan['development_config']), read(plan['benchmark_config'])
    runner = load_module('p22_exact_existing_runner', plan['runner'], ROOT/'scripts')
    def phase(name, config, development=None):
        output = runtime/name
        if output.exists(): raise ValueError('A phase output already exists; no automatic resume or retry')
        if name == 'benchmark': runner.validate_development(config, development)
        grant = phase_grant(plan, config, identity_path, admission_path, name, development)
        command = [python, plan['runner'], '--config', plan[name+'_config'], '--output', str(output),
            '--grant', str(grant), '--model-path', plan['model_directory'], '--context-limit', '65536',
            '--concurrency', '1', '--timeout', '1800']
        if development is not None: command += ['--development-completion', str(development)]
        save(runtime/'status.json', {'at_pacific': stamp(), 'stage': name+'_generation',
            'job_id': os.environ['SLURM_JOB_ID'], 'planned': config['planned'],
            'progress_path': str(output/'progress.json'), 'no_automatic_retry': True}, exclusive=False)
        subprocess.run(command, check=True)
        return read(output/'completion.json')
    def dev(): return phase('development', dev_config)
    def benchmark(done): return phase('benchmark', bench_config, runtime/'development/completion.json')
    def score(done):
        output = runtime/'benchmark/scores.json'
        save(runtime/'scoring_attempt.json', {'at_pacific': stamp(), 'sole_native_scoring_attempt': True,
            'benchmark_prediction_lock_sha256': done['prediction_lock_sha256'], 'planned_assays': 4,
            'native_panel_assays': 29, 'reference_access_after_prediction_seal_only': True})
        subprocess.run([python, plan['scorer'], '--run', str(runtime/'benchmark'),
            '--config', plan['benchmark_config'], '--references', plan['scorer_only_manifest'],
            '--output', str(output)], check=True)
        return read(output)
    return protocol.run_order(plan, dev, benchmark, score)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True);parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--admission', type=Path);parser.add_argument('--admission-sha256')
    parser.add_argument('--runtime-dir', type=Path);parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args();plan = validate_plan(args.plan, args.plan_sha256)
    if args.check_only:
        print(json.dumps({'task_id': 'P22', 'planned': 4, 'development': 3, 'uniform_output_tokens': 16384,
            'root_admission_required': True, 'GPU_allocations': 0, 'model_calls': 0}));return
    if args.admission is None or args.admission_sha256 is None: raise ValueError('Root admission arguments required')
    check_root_admission(args.admission, args.admission_sha256, args.plan_sha256, plan)
    runtime = Path(plan['runtime_root']);runtime.mkdir(exist_ok=True)
    shared = helpers(plan);common = shared.common_module(plan)
    if args.runtime_dir is None:
        lock = (runtime/'allocation.lock').open('a');fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (runtime/'allocation_started.json').exists(): raise ValueError('This allocation already started; no automatic resubmission')
        audit = project_gpu_audit(plan)
        own = [r for r in audit['jobs'] if r['job_id'] == os.environ['SLURM_JOB_ID']]
        if len(own) != 1 or own[0]['gpus'] != 1: raise ValueError('Actual own singleGPU Slurm accounting is missing')
        save(runtime/'gpu_budget_audit.json', audit)
        save(runtime/'allocation_started.json', {'at_pacific': stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
            'plan_sha256': args.plan_sha256, 'admission_sha256': args.admission_sha256})
        if shutil.disk_usage('/tmp').free < 32*1024**3: raise ValueError('Verified runtime needs at least32GiB local scratch')
        for name in ['base_runtime','cuda_overlay']:
            if sha(plan[name]['path']) != plan[name]['sha256']: raise ValueError('Vetted runtime archive changed')
        local = Path(tempfile.mkdtemp(prefix='bio-p22-'+os.environ['SLURM_JOB_ID']+'-'))
        with tarfile.open(plan['base_runtime']['path']) as archive: archive.extractall(local, filter='data')
        activate_private_runtime(shared, common, local, runtime, sys.argv[1:])
    local = args.runtime_dir.resolve()
    if not local.name.startswith('bio-p22-'+os.environ['SLURM_JOB_ID']+'-'): raise ValueError('Private runtime ownership mismatch')
    lock = (runtime/'protocol.lock').open('a');fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
    if any((runtime/name).exists() for name in ['development','benchmark','terminal_receipt.json']):
        raise ValueError('Phase outputs already exist; no repeated calls')
    save(runtime/'gpu_budget_audit_at_server_start.json', project_gpu_audit(plan))
    import importlib.metadata as metadata
    import torch
    installed = verify_runtime_identity(shared, {'packages': {name: metadata.version(name) for name in shared.PINNED_PACKAGES}}, torch.cuda.device_count())
    save(runtime/'post_exec_package_identity.json', installed)
    if os.environ.get('VLLM_USE_V2_MODEL_RUNNER') != '0' or os.environ.get('PYTHONPATH') != str(HERE):
        raise ValueError('Mandatory isolated T4 full-permutation legacy runner/plugin environment differs')
    import p22_permutation_logits
    from vllm.v1.sample.logits_processor import AdapterLogitsProcessor
    if not issubclass(p22_permutation_logits.P22PermutationLogitsProcessor, AdapterLogitsProcessor):
        raise ValueError('Actual installed V1 plugin ABI is incompatible')
    save(runtime/'mandatory_plugin_import.json', {'at_pacific':stamp(),
        'model_runner':'legacy_V1_explicit','VLLM_USE_V2_MODEL_RUNNER':'0',
        'custom_logits_processor':plan['custom_logits_processor'],
        'plugin_sha256':sha(HERE/'p22_permutation_logits.py'),'actual_installed_vllm_import_succeeded':True,
        'source_inputs_or_target_rows_read_by_import':False})
    model_dir = common.validate_checkpoint(plan['model'], plan['model_revision'])
    if str(model_dir) != plan['model_directory']: raise ValueError('Pinned checkpoint directory changed')
    runner = load_module('p22_preflight_existing_runner', plan['runner'], ROOT/'scripts')
    for name in ['development','benchmark']:
        config, cases, _ = runner.load_contract(Path(plan[name+'_config']))
        result = runner.count_tokens(config, cases, model_dir, 65536)
        save(runtime/(name+'_tokenizer_preflight.json'), result)
    save(runtime/'environment.json', {'at_pacific': stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
        'hostname': socket.gethostname(), 'visibleGPUcount': 1, 'dtype': 'bfloat16', 'tensor_parallel_size': 1,
        'vllm': metadata.version('vllm'), 'torch': torch.__version__, 'transformers': metadata.version('transformers'),
        'model_directory': str(model_dir), 'checkpoint_audit_sha256': sha(plan['checkpoint_audit'])})
    with socket.socket() as probe: probe.bind(endpoint_bind_address(plan))
    python = str(local/'python/bin/python3.12')
    command = [python, '-m','vllm.entrypoints.cli.main','serve',str(model_dir),'--served-model-name',plan['model'],
        '--host','127.0.0.1','--port','8423','--dtype','bfloat16','--tensor-parallel-size','1',
        '--gpu-memory-utilization','0.95','--max-model-len','65536','--max-num-seqs','4',
        '--max-num-batched-tokens','8192','--reasoning-parser','qwen3','--enable-prefix-caching',
        '--limit-mm-per-prompt','{"image":0,"video":0}',
        '--logits-processors',plan['custom_logits_processor']]
    server = None
    try:
        save(runtime/'status.json', {'at_pacific': stamp(), 'stage': 'starting_independent_P22_server',
            'job_id': os.environ['SLURM_JOB_ID'], 'endpoint': plan['endpoint']}, exclusive=False)
        with (runtime/'server.log').open('x') as log:
            server = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True, cwd=local)
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}));deadline = time.monotonic()+1800
        while time.monotonic() < deadline:
            if server.poll() is not None: raise RuntimeError('Own P22 server exited before readiness')
            try:
                with opener.open('http://127.0.0.1:8423/health', timeout=3) as response:
                    if response.status == 200: break
            except (OSError, urllib.error.URLError): time.sleep(3)
        else: raise TimeoutError('Own P22 readiness timeout; no model retry')
        with opener.open(plan['endpoint']+'/models', timeout=5) as response: models = json.load(response)
        if [r['id'] for r in models['data']] != [plan['model']]: raise ValueError('Served model identity differs')
        identity = {'at_pacific': stamp(), 'task_id': 'P22', 'job_id': os.environ['SLURM_JOB_ID'],
            'hostname': socket.gethostname(), 'pid': server.pid, 'proc_start_ticks': common.start_ticks(server.pid),
            'model': plan['model'], 'revision': plan['model_revision'], 'dtype': 'bfloat16',
            'tensor_parallel_size': 1, 'dedicated_gpu_count': 1, 'endpoint': plan['endpoint'],
            'max_model_len': 65536, 'plan_sha256': args.plan_sha256,
            'admission_sha256': args.admission_sha256, 'server_command': command,
            'condition':plan['condition'],'model_runner':'legacy_V1_explicit',
            'custom_logits_processor':plan['custom_logits_processor'],
            'plugin_sha256':sha(HERE/'p22_permutation_logits.py'),
            'gpu_processes': common.own_gpu_processes(server.pid)}
        identity_path = runtime/'server_identity.json';save(identity_path, identity)
        result = execute_phases(plan, python, identity_path, args.admission)
        save(runtime/'terminal_receipt.json', {'at_pacific': stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
            'reviewed4_condition_terminal': True, 'full_native29_complete': False, 'full_catalog_complete': False,
            'development_completion_sha256': sha(runtime/'development/completion.json'),
            'benchmark_completion_sha256': sha(runtime/'benchmark/completion.json'),
            'prediction_lock_sha256': read(runtime/'benchmark/completion.json')['prediction_lock_sha256'],
            'native_score_sha256': sha(runtime/'benchmark/scores.json'),
            'native_scoring_status': result['score']['native_scoring_status']})
        save(runtime/'status.json', {'at_pacific': stamp(), 'stage': 'reviewed4_scoring_terminal',
            'native_scoring_status': result['score']['native_scoring_status'],
            'planned_assays': 4, 'native_panel_assays': 29, 'full_native_benchmark_complete': False}, exclusive=False)
    except Exception as error:
        save(runtime/'status.json', {'at_pacific': stamp(), 'stage': 'stopped_for_review',
            'error_type': type(error).__name__, 'error': str(error), 'no_automatic_retry': True,
            'missing_progress_is_not_zero_attempts': True}, exclusive=False)
        raise
    finally:
        if server is not None and server.poll() is None:
            os.killpg(server.pid, signal.SIGTERM)
            try: server.wait(timeout=60)
            except subprocess.TimeoutExpired: os.killpg(server.pid, signal.SIGKILL);server.wait(timeout=10)
        save(runtime/'server_terminal.json', {'at_pacific': stamp(), 'own_server_stopped': True,
            'other_project_runtimes_changed': False}, exclusive=False)


if __name__ == '__main__': main()
