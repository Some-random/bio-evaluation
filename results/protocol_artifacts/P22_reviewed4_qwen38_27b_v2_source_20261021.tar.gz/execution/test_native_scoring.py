"""Native T4 formulas on artificial measurements; no released outcomes."""
import json
from pathlib import Path
import tempfile
import unittest
import scorer
from test_contracts import fixture
from input_contract import audit_ranking


class NativeScorerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root=scorer.ROOT/'.local/source_recovery_round2_2026-10-19/pfarena/official_code/code'
        cls.native=scorer.load_native(root/'evaluation/full.py',root/'router.py')

    def synthetic(self):
        _,ctx=fixture(8);native=self.native
        rows=tuple((m,float(8-i)) for i,m in enumerate(ctx['candidate_ids']))
        truth=native.AssayTruth('invented',rows,dict(rows),Path('/artificial-only.csv'),8,0,0,0)
        predictions=[native.PredictionRow('invented',m,float(i),i,'artificial') for i,m in enumerate(ctx['candidate_ids'])]
        return ctx,truth,predictions

    def test_exact_native_T4_perfect_metrics(self):
        _,truth,pred=self.synthetic();native=self.native;setting='T4_single_mutant_informed_multi_mutant_ranking'
        native._validate_predictions({'invented':truth},{'invented':pred},top_k=5,strict=True,setting=setting)
        out=native.evaluate_one_assay(truth=truth,pred_rows=pred,top_k=5,setting=setting)
        for name in ['spearman','NDCG','NMS@5','Recall@5']:self.assertAlmostEqual(out[name],1.0)

    def test_reversed_native_rankings_are_not_repaired(self):
        _,truth,pred=self.synthetic();native=self.native
        pred=[native.PredictionRow('invented',row.mutant,float(i),i,'artificial') for i,row in enumerate(reversed(pred))]
        out=native.evaluate_one_assay(truth=truth,pred_rows=pred,top_k=5,setting='T4_single_mutant_informed_multi_mutant_ranking')
        self.assertAlmostEqual(out['spearman'],-1.0);self.assertLess(out['NDCG'],1.0)

    def test_native_strict_flag_and_full_permutation_are_separate(self):
        ctx,truth,pred=self.synthetic();native=self.native
        native._validate_predictions({'invented':truth},{'invented':pred[:5]},top_k=5,strict=True,setting='T4_single_mutant_informed_multi_mutant_ranking')
        final=json.dumps({'ranking':[p.mutant for p in pred[:5]]})
        self.assertFalse(audit_ranking(ctx,final)['delivery_passed'])
        with self.assertRaises(ValueError):
            native._validate_predictions({'invented':truth},{'invented':pred[:4]},top_k=5,strict=True,setting='T4_single_mutant_informed_multi_mutant_ranking')

    def test_partial_or_hash_changed_lock_blocks_reference_access(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);config=root/'config.json';config.write_text('{}')
            done={'task_id':'P22','config_sha256':scorer.sha(config),'planned':8,'terminal':7}
            (root/'completion.json').write_text(json.dumps(done))
            with self.assertRaises(ValueError):scorer.verify_prediction_lock(root,config,8)
            member=root/'sealed-response.json';member.write_text('artificial')
            lock={'config_sha256':scorer.sha(config),'reference_labels_opened':False,'files_sha256':{'sealed-response.json':scorer.sha(member)}}
            (root/'prediction_lock.json').write_text(json.dumps(lock));done.update(terminal=8,prediction_lock_sha256=scorer.sha(root/'prediction_lock.json'))
            (root/'completion.json').write_text(json.dumps(done));member.write_text('changed')
            with self.assertRaises(ValueError):scorer.verify_prediction_lock(root,config,8)


if __name__=='__main__':unittest.main()
