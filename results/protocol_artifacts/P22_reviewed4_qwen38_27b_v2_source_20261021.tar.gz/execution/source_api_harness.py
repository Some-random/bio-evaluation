"""CPU harness for verbatim pinned vLLM classes/functions, without engine import.

Imports are replaced with CPU/library names; selected method AST bodies are not
rewritten. This validates API behavior, not installed GPU-engine integration.
"""
import ast
import inspect
import sys
import types
from abc import ABC, abstractmethod
from collections.abc import Sequence, Callable
from dataclasses import dataclass
from enum import Enum, auto
from functools import partial
from pathlib import Path
from typing import TypeVar


def load_verbatim_adapter(source_directory: Path, torch):
    scope = dict(torch=torch, ABC=ABC, abstractmethod=abstractmethod,
                 Sequence=Sequence, Callable=Callable, dataclass=dataclass,
                 Enum=Enum, auto=auto, partial=partial, inspect=inspect,
                 SamplingParams=types.SimpleNamespace, T=TypeVar("T"),
                 RequestLogitsProcessor=Callable)
    def execute(path, names):
        tree = ast.parse(path.read_text())
        body = [x for x in tree.body if isinstance(x, (ast.ClassDef, ast.FunctionDef)) and x.name in names]
        assert len(body) == len(names), (path, names)
        module = ast.Module(body=[ast.ImportFrom(module="__future__", names=[ast.alias(name="annotations")], level=0), *body], type_ignores=[])
        exec(compile(ast.fix_missing_locations(module), str(path), "exec"), scope)
    execute(source_directory / "vllm__v1__sample__logits_processor__interface.py", {"MoveDirectionality", "BatchUpdate", "LogitsProcessor"})
    execute(source_directory / "vllm__v1__sample__logits_processor__builtin.py", {"process_dict_updates"})
    execute(source_directory / "vllm__v1__sample__logits_processor____init__.py", {"AdapterLogitsProcessor"})
    return scope


def import_production_adapter_with_source_base(scope):
    # Only the import boundary is supplied locally. The concrete production
    # adapter and all selected upstream lifecycle method bodies run unchanged.
    names = ["vllm", "vllm.v1", "vllm.v1.sample", "vllm.v1.sample.logits_processor"]
    saved = {name: sys.modules.get(name) for name in names}
    try:
        for name in names:
            sys.modules[name] = types.ModuleType(name)
        sys.modules[names[-1]].AdapterLogitsProcessor = scope["AdapterLogitsProcessor"]
        import p22_permutation_logits
        return p22_permutation_logits
    finally:
        for name, module in saved.items():
            if module is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = module
