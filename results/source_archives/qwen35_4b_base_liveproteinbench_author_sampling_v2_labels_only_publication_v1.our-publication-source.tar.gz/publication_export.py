"""Pure generated-choice projection; no I/O, native text, tokens or control state.

The caller supplies its already verified generated prediction and delivery flags.
This module neither parses benchmark text nor computes correctness.
"""
import re

FLAGS=('response_saved','transport_error','http_error','response_error','refusal','truncated',
       'empty_final','missing_closing_think','output_invalid')
FIELDS=frozenset(('case_id','task_id','generated_label','delivery','hashes','official_source',
    'content_omitted','omission_reason','original_local_bytes_unchanged'))
HASH_NAMES=frozenset(('source_record_sha256','request_sha256','outcome_sha256','raw_response_sha256','final_text_sha256'))
OMISSION_REASON='All free-form generated text, token arrays and upstream/native input payloads are omitted; original local bytes and scoring remain unchanged.'


def validate_record(row):
    if (set(row)!=FIELDS or not isinstance(row['case_id'],str)
            or not re.fullmatch('[A-Za-z0-9_-]+',row['case_id'])
            or not isinstance(row['task_id'],str)or not re.fullmatch('[A-Za-z0-9_-]+',row['task_id'])
            or row['generated_label']not in (None,'A','B','C','D')
            or not isinstance(row['official_source'],str)
            or not re.fullmatch(r'https://github\.com/Rongdingyi/LiveProteinBench/tree/[0-9a-f]{40}',row['official_source'])
            or row['content_omitted']is not True or row['original_local_bytes_unchanged']is not True
            or row['omission_reason']!=OMISSION_REASON or set(row['delivery'])!=set(FLAGS)
            or any(type(v)is not bool for v in row['delivery'].values())or set(row['hashes'])!=HASH_NAMES):
        raise ValueError('Exact generated-choice metadata schema required')
    for name,value in row['hashes'].items():
        if value is None and name=='raw_response_sha256':continue
        if not isinstance(value,str)or not re.fullmatch('[0-9a-f]{64}',value):
            raise ValueError('Only opaque SHA256 provenance is allowed')
    return row


def project_record(case_id,task_id,generated_label,delivery,hashes,official_source):
    # Rebuild exact fields, so caller dictionaries cannot introduce extra content.
    if set(delivery)!=set(FLAGS)or set(hashes)!=HASH_NAMES:
        raise ValueError('Exact delivery/provenance field sets required')
    row=dict(case_id=case_id,task_id=task_id,generated_label=generated_label,
        delivery={name:delivery[name]for name in FLAGS},hashes={name:hashes[name]for name in sorted(HASH_NAMES)},
        official_source=official_source,content_omitted=True,omission_reason=OMISSION_REASON,
        original_local_bytes_unchanged=True)
    return validate_record(row)
