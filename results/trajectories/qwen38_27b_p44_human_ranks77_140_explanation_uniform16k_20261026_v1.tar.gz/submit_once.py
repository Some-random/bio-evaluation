"""Exact independently admitted one-allocation launcher; default does nothing.

Capacity-only observations may be repeated. An actual or ambiguous sbatch
invocation is durably claimed once and never retried. This is no general queue.
"""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import os
from pathlib import Path
import re
import subprocess
import sys
import types

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from prepare_extension import read, save, sha
import runtime_guard as guard
import resource_authority as resources

QUEUE = resources.ROOT / '.local/qwen35_4b_comparison_20261022/queue/controller.py'
QUEUE_SHA = 'e0c371e8a0639c90436790e0f69eaca527ca2db2af3e587ac276fa4bce3aeafb'


def stamp():
    return datetime.now(timezone.utc).isoformat()


def ready_comparison_requests():
    """Preserve the existing admitted, dispatch-ready comparison priority."""
    source = QUEUE.read_bytes()
    guard.require(hashlib.sha256(source).hexdigest() == QUEUE_SHA, 'Exact accepted comparison queue observer required')
    queue = types.ModuleType('next64_read_only_existing_comparison_priority')
    queue.__file__ = str(QUEUE)
    exec(compile(source, str(QUEUE), 'exec'), queue.__dict__)
    pending = []
    with (queue.QUEUE / 'intake.lock').open('a') as intake:
        fcntl.flock(intake, fcntl.LOCK_SH)
        for path in sorted((queue.QUEUE / 'accepted').glob('*.json')):
            ticket = read(path); request = ticket['request']
            guard.require(ticket['request_digest'] == queue.request_digest(request), 'Accepted comparison ticket changed')
            _, state_path = queue.ticket_paths(request['request_id'])
            state = read(state_path)
            if state['stage'] in queue.FINAL or state['stage'] in queue.ACTIVE:
                continue
            queue.validate_request(request)
            if all(Path(p).is_file() for p in request['wait_for_paths']):
                pending.append(request['request_id'])
    return pending


def reject_existing_attempt():
    for path in (HERE / 'submission_intent.json', HERE / 'submission_receipt.json',
                 HERE / 'runtime/allocation_started.json', HERE / 'runtime/run_v1'):
        guard.require(not os.path.lexists(path), 'Existing actual or ambiguous allocation/attempt is never retried')


def bind_and_retire_own_STOP(plan_sha, admission_sha):
    plan, _ = guard.validate_runtime(plan_sha, admission_sha, metadata_STOP_retirement=True)
    reject_existing_attempt()
    guard.verify_known_attempt_ownership(plan, before_first_dispatch=True)
    binding_path = HERE / 'runtime/runtime_binding.json'
    binding = {'role': 'exact_next64_runtime_binding_before_first_model_action',
        'owner': '/root/main_docs_refresh/p13_downstream_source_map',
        'root_scientific_adoption_sha256': guard.ADOPTION_SHA,
        'plan_sha256': plan_sha, 'runtime_admission_sha256': admission_sha}
    if os.path.lexists(binding_path):
        guard.require(guard.same_json_value(read(binding_path), binding), 'Existing runtime binding cannot change')
    else:
        save(binding_path, binding)
    stop = HERE / 'STOP'; retired = HERE / 'STOP.retired_under_exact_runtime_admission'
    receipt = HERE / 'execution_STOP_retirement_receipt.json'
    if os.path.lexists(stop):
        guard.require(sha(stop) == plan['execution_STOP_sha256'] and not os.path.lexists(retired)
                      and not os.path.lexists(receipt), 'Preserve own STOP bytes and any ambiguous retirement')
        os.rename(stop, retired)
        directory = os.open(HERE, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
        save(receipt, {**binding, 'role': 'only_new_exact64_execution_STOP_retired_under_independent_runtime_admission',
            'at_utc': stamp(), 'original_STOP_sha256': sha(retired),
            'other_STOPs_changed': False})
    else:
        guard.require(retired.is_file() and sha(retired) == plan['execution_STOP_sha256']
                      and receipt.is_file(), 'No inferred STOP clearance or automatic retirement repair')
        value = read(receipt)
        guard.require(value.get('role') == 'only_new_exact64_execution_STOP_retired_under_independent_runtime_admission'
                      and value.get('original_STOP_sha256') == plan['execution_STOP_sha256']
                      and value.get('plan_sha256') == plan_sha
                      and value.get('runtime_admission_sha256') == admission_sha,
                      'Exact prior own STOP retirement binding required')
    guard.validate_runtime(plan_sha, admission_sha)
    return plan


def submit(plan_sha, admission_sha, *, runner=None):
    # Caller cannot route to a different worker, plan, admission or model.
    plan = bind_and_retire_own_STOP(plan_sha, admission_sha)
    with resources.locked_accounting() as observe:
        reject_existing_attempt()
        guard.validate_runtime(plan_sha, admission_sha)
        guard.verify_known_attempt_ownership(plan, before_first_dispatch=True)
        audit = observe(additional=1, require_own_job=False)
        priority = ready_comparison_requests()
        if not audit['capacity_available'] or priority:
            return {'stage': 'yielding_to_existing_comparison' if priority else 'waiting_capacity',
                'project_requested_GPUs': audit['project_requested_GPUs'],
                'ready_comparison_requests': priority, 'sbatch_invoked': False}
        command = ['sbatch', '--parsable', str(HERE / 'worker.sbatch'), plan_sha,
                   str(HERE / 'runtime_admission.json'), admission_sha]
        guard.validate_runtime(plan_sha, admission_sha)
        save(HERE / 'submission_gpu_audit.json', audit)
        save(HERE / 'submission_intent.json', {'at_utc': stamp(), 'plan_sha256': plan_sha,
            'runtime_admission_sha256': admission_sha, 'command': command,
            'meaning': 'One sbatch invocation about to start; unknown delivery is never retryable'})
        invoke = subprocess.run if runner is None else runner
        try:
            result = invoke(command, capture_output=True, text=True, timeout=60)
        except BaseException as error:
            save(HERE / 'submission_receipt.json', {'at_utc': stamp(), 'exception_type': type(error).__name__,
                'delivery_unknown': True, 'automatic_retry': False, 'plan_sha256': plan_sha})
            raise
        job = result.stdout.strip().split(';')[0]
        receipt = {'at_utc': stamp(), 'returncode': result.returncode, 'stdout': result.stdout,
            'stderr': result.stderr, 'job_id': job if re.fullmatch('[0-9]+', job) else None,
            'plan_sha256': plan_sha, 'runtime_admission_sha256': admission_sha,
            'one_attempt': True, 'model_delivery_inferred': False, 'automatic_retry': False}
        save(HERE / 'submission_receipt.json', receipt)
        guard.require(result.returncode == 0 and receipt['job_id'] is not None,
                      'Actual submission failed or ambiguous; preserve and never retry')
        return receipt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--submit', action='store_true')
    parser.add_argument('--plan-sha256')
    parser.add_argument('--admission-sha256')
    args = parser.parse_args()
    if not args.submit:
        print('Disabled default: no STOP change, queue observation, scheduler or model action.')
        return
    guard.require(bool(args.plan_sha256 and args.admission_sha256), 'Exact independent plan/admission hashes required')
    os.umask(0o077)
    print(__import__('json').dumps(submit(args.plan_sha256, args.admission_sha256), sort_keys=True))


if __name__ == '__main__':
    main()
