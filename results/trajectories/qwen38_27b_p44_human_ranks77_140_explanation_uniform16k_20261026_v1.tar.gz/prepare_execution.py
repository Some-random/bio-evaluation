"""Disabled exact64 CPU packet preparation; no model, scoring or submission.

Default mode reports metadata readiness only. --prepare requires an exact
independent actual-reference review before it reads either private projection.
It never reopens the original Parquet, repairs fields or infers -1 decisions.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).resolve().parent))
from prepare_extension import HERE, IDS_SHA256, TASK, load_contract, read, save, sha
from runtime_guard import ADOPTION_SHA, PROSPECTIVE, scientific_scope
from runner_adapter import load_runner

SOLVER = TASK / 'next_human64_cpu_preparation_20261026_v1/input_review_private/solver_source_projection.json'
SOLVER_SHA = '372485ab54a5ef675443f720e81395ba7065e6093ee3ee11798d495ac795d2a5'
REFERENCE_ROOT = TASK / 'next_human64_reference_CPU_preparation_20261026_v1'
REFERENCE = REFERENCE_ROOT / 'reference_review_private/reference_source_projection.json'
REFERENCE_SHA = 'b4ab42c82bfee68b90c092b2cf3d0f10d265312a6da07f79f58f24c9afa4dc75'
REFERENCE_REVIEW = REFERENCE_ROOT / 'independent_actual_complete_reference_source_isolation_axis_review_20261026_v1.json'
REFERENCE_FIELDS = ('protein_function', 'go_mf', 'go_bp', 'go_cc', 'interpro_formatted',
                    'ppi_formatted', 'organism', 'subcellular_location', 'protein_names')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def bounded_pinned(path, expected):
    path = Path(path)
    require(path.is_absolute() and path == path.resolve(), 'Canonical nonsymlink path required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_size <= 1024 * 1024,
                'Bounded regular admitted projection/review required')
        data = stream.read(1024 * 1024 + 1)
        identity = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns, item.st_ctime_ns)
        require(identity(before) == identity(os.fstat(stream.fileno())) == identity(path.lstat())
                and hashlib.sha256(data).hexdigest() == expected,
                'Exact unchanged admitted private projection/review required')
    return json.loads(data)


def reviewed_axis_metadata(review, ids):
    require(review.get('passed') is True
            and review.get('role') == 'independent_P44_exact64_actual_complete_reference_source_type_isolation_axis_review'
            and review.get('approved_for_bounded_reference_packaging_and_CPU_judge_context_preparation') is True
            and review.get('reviewer') in
            ('/root/remaining_scope_audit', '/root/independent_review'),
            'Actual independent complete reference/source/axis review required')
    expected = review.get('reference_projection_sha256', review.get('curated_reference_projection_sha256'))
    require(expected == REFERENCE_SHA
            and review.get('candidate_ordered_ids_sha256', review.get('ordered_case_ids_sha256')) == IDS_SHA256,
            'Actual reference review must bind exact unchanged projection and ordered64 IDs')
    rows = review.get('case_reviews')
    require(isinstance(rows, list) and len(rows) == 64 and [row.get('case_id') for row in rows] == ids,
            'Explicit independently reviewed case/axis metadata for every source-order case required')
    result = {}
    for row in rows:
        require(row.get('status') == 'independently_reviewed_permitted'
                and row.get('held_or_interrupted_scope') is False,
                'Preserve any actual deferred or held reference scope; no silent denominator reduction')
        axes = row.get('axis_evidence', {})
        require(set(axes) == {'molecular_function', 'biological_process', 'cellular_component'},
                'Three independently reviewed functional aspects required')
        result[row['case_id']] = {}
        for axis, value in axes.items():
            require(value.get('reviewed') is True and type(value.get('all_sources_silent')) is bool,
                    'Never infer -1 admission from absent GO or empty context')
            result[row['case_id']][axis] = {'reviewed': True, 'all_sources_silent': value['all_sources_silent']}
    return result


def prepare(reference_review_sha):
    adoption, protocol = scientific_scope()
    require(isinstance(reference_review_sha, str) and len(reference_review_sha) == 64,
            'Exact actual reference review hash required')
    review = bounded_pinned(REFERENCE_REVIEW, reference_review_sha)
    candidate_path = TASK / 'remaining8554_metadata_audit_20261025_v1/next_human64_metadata_candidate.json'
    metadata = bounded_pinned(candidate_path, '3f147e86449d88e16e159fadab70c9d6b12d4091558ba9e3d4341801f1751bca')['candidates']
    ids = [row['case_id'] for row in metadata]
    contract = load_contract()
    require(len(ids) == 64 and contract.canonical_hash(ids) == IDS_SHA256,
            'Exact64 source-order metadata required')
    axis_metadata = reviewed_axis_metadata(review, ids)  # Before any private body read.
    review_by_id = {row['case_id']: row for row in review['case_reviews']}
    claim = HERE / 'CPU_packet_preparation_attempt.json'
    require(not os.path.lexists(claim) and not os.path.lexists(HERE / 'preparation/panel.json'),
            'Preserve previous/partial preparation; no automatic overwrite')
    (HERE / 'preparation').chmod(0o700)
    save(claim, {'role': 'one_exact_reviewed64_CPU_packet_preparation_not_model_attempt',
        'at_utc': datetime.now(timezone.utc).isoformat(), 'root_scientific_adoption_sha256': ADOPTION_SHA,
        'actual_reference_review_sha256': reference_review_sha, 'scientific_changes': False, 'model_calls': 0})
    solvers, references = bounded_pinned(SOLVER, SOLVER_SHA), bounded_pinned(REFERENCE, REFERENCE_SHA)
    require([row['case_id'] for row in solvers] == [row['case_id'] for row in references] == ids,
            'Fixed complete solver/reference identity order required')
    require(all(row['source_index'] == identity['source_index'] for row, identity in zip(solvers, metadata))
            and all(row['source_index'] == identity['source_index'] for row, identity in zip(references, metadata)),
            'Original source positions changed')
    fit = bounded_pinned(PROSPECTIVE / 'solver_tokenizer_preflight.json',
                         'c1fc0fb72d2ea2e3881543ecbb48c383efbecffcb384e239f2537735caee3b84')
    expected_envelopes = {row['case_id']: row['solver_envelope_canonical_sha256'] for row in fit['per_case']}
    configuration = dict(adoption['model_configuration'])
    configuration.update(endpoint='http://127.0.0.1:8494/v1', configuration_status='frozen_pending_exact_engineering_and_runtime_admission')
    panel = {'task_id': 'P44', 'role': 'explanation_assessment', 'condition_id': adoption['condition_id'],
        'ordered_case_ids': ids, 'ordered_ids_sha256': IDS_SHA256, 'source_released_denominator': 8630,
        'source_revision': 'a18315a77d27dd4fe5a28b9b757695cff4ba4e3f',
        'source_parquet_sha256': 'f8acd81f3b08400783a34f4189428e4f41fa0c648bc8e4fa58b10ee58bb66828',
        'evidence_snapshot_sha256': contract.canonical_hash({'solver_projection': SOLVER_SHA, 'reference_projection': REFERENCE_SHA}),
        'actual_input_review_sha256': '536863ac7fd17106f7e0f81d3f953c14b84c7f3fdd6b7cc47a9fbb9c71f41b39',
        'actual_reference_review_sha256': reference_review_sha, 'prior_completed_case_count': 76,
        'prior_condition_modified_or_results_pooled': False, 'other_release_cases_outside_old76_and_new64': 8490,
        'runtime_admission_granted': False}
    panel_sha = contract.canonical_hash(panel)
    runner = load_runner()
    _, workflow = runner.source_modules()
    records, envelopes = [], []
    for source_input, source_reference in zip(solvers, references):
        case_id = source_input['case_id']
        require(review_by_id[case_id].get('all_nine_admitted_reference_fields_inspected') is True
                and review_by_id[case_id]['selected_source_columns_sha256'] == source_reference['selected_source_columns_sha256']
                and review_by_id[case_id]['source_index'] == source_reference['source_index'],
                'Exact independently reviewed native reference row and source position required')
        require(set(source_input['input']) == set(contract.SOLVER_FIELDS)
                and set(source_reference['reference']) == set(REFERENCE_FIELDS), 'Exact original field projections required')
        require(all(source_input['input'][key] == source_reference['reference'][key]
                    for key in ('organism', 'interpro_formatted', 'ppi_formatted')),
                'Source contexts differ; do not inject or repair evidence')
        admission = {'task_id': 'P44', 'case_id': case_id, 'status': 'independently_reviewed_permitted',
                     'held_or_interrupted_scope': False, 'panel_sha256': panel_sha}
        ordered_input = {key: source_input['input'][key] for key in contract.SOLVER_FIELDS}
        solver = contract.build_solver_packet(panel, case_id, ordered_input, admission)
        dossier = contract.build_judge_dossier(panel, case_id, source_reference['reference'], admission, axis_metadata[case_id])
        dossier['evidence']['protein_names'] = source_reference['reference']['protein_names']
        envelope = workflow.solver_envelope(solver, configuration)
        require(contract.canonical_hash(envelope) == expected_envelopes[case_id],
                'Prepared exact solver request differs from independently tokenized complete prompt')
        paths = {'solver': HERE / 'preparation/packets/solver' / (case_id + '.json'),
                 'reference': HERE / 'preparation/packets/judge_reference' / (case_id + '.json')}
        save(paths['solver'], solver); save(paths['reference'], dossier)
        envelope_path = HERE / 'solver_envelopes' / (f'{len(envelopes):03d}.json')
        save(envelope_path, envelope)
        envelopes.append({'case_id': case_id, 'path': str(envelope_path), 'sha256': sha(envelope_path)})
        records.append({'case_id': case_id, 'source_index': source_input['source_index'],
            'length': source_input['sequence_length_metadata'],
            'solver_path': str(paths['solver'].relative_to(HERE / 'preparation')), 'solver_sha256': sha(paths['solver']),
            'reference_path': str(paths['reference'].relative_to(HERE / 'preparation')), 'reference_sha256': sha(paths['reference']),
            'solver_native_source_columns_sha256': source_input['selected_source_columns_sha256'],
            'reference_native_source_columns_sha256': source_reference['selected_source_columns_sha256']})
    require(sum(row['input']['interpro_formatted'] == '' for row in solvers) == 3
            and sum(row['input']['ppi_formatted'] == '' for row in solvers) == 20,
            'Preserve all empty native contexts without dropping cases')
    save(HERE / 'preparation/panel.json', panel)
    save(HERE / 'preparation/admission.json', review)
    save(HERE / 'solver_envelopes_manifest.json', {'planned': 64, 'envelopes': envelopes,
        'complete_original_sequences': True, 'overlap_with_old76': 0, 'all_match_independently_CPU_tokenized_requests': True})
    save(HERE / 'preparation/packet_validation.json', {'role': 'actual_reviewed_CPU_packet_preparation_not_runtime',
        'task_id': 'P44', 'passed': True, 'planned': 64, 'panel_sha256': panel_sha,
        'admission_sha256': sha(HERE / 'preparation/admission.json'), 'per_case': records,
        'solver_projection_sha256': SOLVER_SHA, 'reference_projection_sha256': REFERENCE_SHA,
        'actual_reference_review_sha256': reference_review_sha, 'all64_full_sequences_original_context_types_preserved': True,
        'reference_field_values_native_and_unmodified': True, 'minus_one_flags_from_independent_review_only': True,
        'old76_other8490_and_frozen_prior_packets_unchanged': True, 'model_scorer_GPU_actions': 0})
    save(HERE / 'prepared_configuration.json', configuration)
    require(sha(SOLVER) == SOLVER_SHA and sha(REFERENCE) == REFERENCE_SHA,
            'Original admitted private projection changed during packaging')
    return {'stage': 'exact64_private_CPU_packets_prepared_not_runtime_admitted', 'planned': 64,
            'packet_validation_sha256': sha(HERE / 'preparation/packet_validation.json'), 'model_calls': 0}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--actual-reference-review-sha256')
    args = parser.parse_args()
    if args.prepare:
        print(json.dumps(prepare(args.actual_reference_review_sha256), sort_keys=True))
    else:
        print(json.dumps({'stage': 'disabled_execution_metadata_readiness_only', 'planned': 64,
            'reference_review_present': REFERENCE_REVIEW.is_file(), 'execution_STOP_present': os.path.lexists(HERE / 'STOP'),
            'private_projections_opened': False, 'model_scorer_GPU_actions': 0}, sort_keys=True))
