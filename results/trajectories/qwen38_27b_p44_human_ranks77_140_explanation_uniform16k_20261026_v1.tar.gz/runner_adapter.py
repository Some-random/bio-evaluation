"""Exact prior protocol source in an isolated namespace with durable writes.

No real input or runtime action occurs on import. Scientific phase, parsing,
failure and aggregation functions stay byte-identical to the accepted source.
The separate contract helper adds a real-next64 scoring claim before old math.
"""
import hashlib
from pathlib import Path
import types
from prepare_extension import HERE, save

RUNNER_SHA = 'b5864ff8da0cdf751e68f5d11c1e1518a2c0c2b1c62e197fe389c447254640aa'


def load_runner():
    path = HERE / 'p44_runner.py'
    source = path.read_bytes()
    if hashlib.sha256(source).hexdigest() != RUNNER_SHA:
        raise ValueError('Exact byte-identical original protocol runner required')
    module = types.ModuleType('next64_isolated_exact_original_protocol_runner')
    module.__file__ = str(path)
    exec(compile(source, str(path), 'exec'), module.__dict__)
    module.save = save  # Same JSON data/spacing; exclusive fsynced file+parent persistence.
    return module
