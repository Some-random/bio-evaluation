"""New scope guard around the accepted shared conservative GPU observer.

Import queries nothing. Every observation first validates the exact next64
runtime authority, then holds the existing shared submission lock. The old
module contributes accounting only and grants no old-cohort authority here.
"""
from contextlib import contextmanager
import fcntl
import hashlib
import os
from pathlib import Path
import types

from prepare_extension import HERE
from runtime_guard import bound_runtime, require

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
SHARED_LOCK = ROOT / '.local/evaluation_GPU_submission.lock'
ACCEPTED_SOURCE = HERE.parent / 'restore_20261024_v1/resource_authority.py'
ACCEPTED_SHA = '10c9d074cc312eee6a3c5214cb97580e1e3a04b2930477e78b71aabe85a03527'


def accepted_observer():
    source = ACCEPTED_SOURCE.read_bytes()
    require(hashlib.sha256(source).hexdigest() == ACCEPTED_SHA, 'Exact accepted accounting observer wrapper required')
    module = types.ModuleType('isolated_accepted_P44_conservative_GPU_accounting_only')
    module.__file__ = str(ACCEPTED_SOURCE)
    exec(compile(source, str(ACCEPTED_SOURCE), 'exec'), module.__dict__)
    return module


@contextmanager
def locked_accounting():
    bound_runtime()  # STOP, exact science, references/context/ownership and independent runtime admission.
    require(not SHARED_LOCK.is_symlink(), 'Shared project GPU lock must not be a symlink')
    fd = os.open(SHARED_LOCK, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        bound_runtime()
        observer = accepted_observer()

        def observe(*, additional, require_own_job=False, runner=None):
            require((additional, require_own_job) in ((1, False), (0, True))
                    and type(additional) is int and type(require_own_job) is bool,
                    'Only new allocation +1 or own startup +0 observations are allowed')
            bound_runtime()
            value = observer.capacity_audit(additional=additional, require_own_job=require_own_job, runner=runner)
            count = value.get('project_requested_GPUs')
            require(type(count) is int and count >= 0
                    and value.get('project_requested_GPUs_with_addition') == count + additional
                    and value.get('capacity_available') is (count + additional <= 8)
                    and (not require_own_job or value.get('own_allocation_verified') is True),
                    'Fresh conservative accounting, including pending/unknown jobs, must satisfy eight-GPU ceiling')
            return value

        yield observe
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def capacity_audit(*, additional, require_own_job=False, runner=None):
    with locked_accounting() as observe:
        return observe(additional=additional, require_own_job=require_own_job, runner=runner)
