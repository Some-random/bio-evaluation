"""Whole64 complete solver/reference-template sizing, CPU/offline only.

Requires actually reviewed and packaged references. This creates no generation,
prediction lock, judge call, runtime admission, score or source re-projection.
Actual saved candidates still need fresh context checks after the full seal.
"""
from collections.abc import Mapping
from datetime import datetime, timezone
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from prepare_extension import HERE, load_contract, read, save, sha
from runtime_guard import ADOPTION_SHA, PROSPECTIVE, scientific_scope
from runner_adapter import load_runner


def require(condition, message):
    if not condition:
        raise ValueError(message)


def count(tokenizer, request):
    encoded = tokenizer.apply_chat_template(request['messages'], tokenize=True,
                                            add_generation_prompt=True, enable_thinking=False)
    ids = encoded['input_ids'] if isinstance(encoded, Mapping) else encoded
    if hasattr(ids, 'tolist'):
        ids = ids.tolist()
    if isinstance(ids, list) and len(ids) == 1 and isinstance(ids[0], list):
        ids = ids[0]
    require(isinstance(ids, list) and ids and all(type(value) is int for value in ids),
            'Explicit flat integer token IDs required')
    return len(ids)


def main():
    os.environ.update(CUDA_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
        USE_TORCH='0', USE_TF='0', USE_FLAX='0', TOKENIZERS_PARALLELISM='false', OMP_NUM_THREADS='2')
    scientific_scope()
    require((HERE / 'STOP').is_file(), 'Disabled CPU preparation only; runtime remains separately gated')
    validation = read(HERE / 'preparation/packet_validation.json')
    require(validation.get('passed') is True and validation.get('planned') == 64
            and sha(HERE / 'preparation/admission.json') == validation['admission_sha256'],
            'Exact actual reference review and complete packet validation required before protected template parsing')
    prior_cpu = read(PROSPECTIVE / 'cpu_config.json')
    require(sha(PROSPECTIVE / 'cpu_config.json') == '97fd6274a374cbb8cc89b517eed67e1f9973459273a0e681332ef526221255fd',
            'Exact independently accepted CPU tokenizer configuration required')
    model = Path('/dfs/scratch0/tchen/models/Qwen3.8-27B')
    for name, expected in prior_cpu['tokenizer_files_sha256'].items():
        require(sha(model / name) == expected, 'Pinned tokenizer bytes changed')
    from transformers import AutoTokenizer
    import transformers
    import tokenizers
    import jinja2
    require(transformers.__version__ == '5.17.0' and tokenizers.__version__ == '0.23.3'
            and jinja2.__version__ == '3.1.6', 'Exact isolated CPU tokenizer environment required')
    tokenizer = AutoTokenizer.from_pretrained(model, local_files_only=True, trust_remote_code=False, use_fast=True)
    contract, runner = load_contract(), load_runner()
    configuration = read(HERE / 'prepared_configuration.json')
    manifest = read(HERE / 'solver_envelopes_manifest.json')
    by_id = {row['case_id']: row for row in validation['per_case']}
    records = []
    for row in manifest['envelopes']:
        case_id = row['case_id']
        require(sha(row['path']) == row['sha256'], 'Exact complete solver envelope changed')
        reference_path = HERE / 'preparation' / by_id[case_id]['reference_path']
        require(sha(reference_path) == by_id[case_id]['reference_sha256'], 'Reviewed reference dossier changed')
        solver, dossier = read(row['path']), read(reference_path)
        template = {'task_id': 'P44', 'case_id': case_id,
            'judge_role': 'declared_replacement_explanation_judge', 'reference_dossier': dossier,
            'single_saved_generation': '__UNGENERATED_SIZING_PLACEHOLDER__',
            'prediction_lock_sha256': '__SIZING_TEMPLATE_NOT_A_PREDICTION_LOCK__'}
        judge = runner.judge_envelope(template, configuration, contract)
        solver_tokens, judge_tokens = count(tokenizer, solver), count(tokenizer, judge)
        records.append({'case_id': case_id, 'solver_input_tokens': solver_tokens, 'solver_output_tokens': 16384,
            'judge_template_input_tokens': judge_tokens, 'candidate_reserve_tokens': 16384,
            'judge_output_tokens': 16384, 'solver_fits': solver_tokens + 16384 <= 65536,
            'judge_template_with_reserves_fits': judge_tokens + 32768 <= 65536,
            'actual_future_saved_candidate_requires_fresh_tokenization_after_full_solver_seal': True})
    require(len(records) == 64 and all(row['solver_fits'] and row['judge_template_with_reserves_fits'] for row in records),
            'All64 complete solver and full judge templates with unchanged reserves must fit')
    for name, expected in prior_cpu['tokenizer_files_sha256'].items():
        require(sha(model / name) == expected, 'Tokenizer changed during CPU template preparation')
    result = {'role': 'whole64_complete_solver_and_reference_template_CPU_fit_not_actual_judgment',
        'at_utc': datetime.now(timezone.utc).isoformat(), 'planned': 64, 'all_fit': True,
        'root_scientific_adoption_sha256': ADOPTION_SHA,
        'packet_validation_sha256': sha(HERE / 'preparation/packet_validation.json'),
        'reference_review_sha256': validation['actual_reference_review_sha256'],
        'max_solver_input_tokens': max(row['solver_input_tokens'] for row in records),
        'max_judge_template_input_tokens': max(row['judge_template_input_tokens'] for row in records),
        'solver_output_tokens': 16384, 'candidate_reserve_tokens': 16384, 'judge_output_tokens': 16384,
        'context_tokens': 65536, 'transformers_version': transformers.__version__,
        'tokenizers_version': tokenizers.__version__, 'jinja2_version': jinja2.__version__,
        'tokenizer_files_sha256': prior_cpu['tokenizer_files_sha256'],
        'actual_saved_candidate_fit_verified': False, 'full_solver_seal_or_runtime_admission_created': False,
        'model_weights_loaded_or_model_forwards': 0, 'network_model_scorer_GPU_paid_or_scheduler_actions': 0,
        'per_case': records}
    save(HERE / 'judge_template_tokenizer_preflight.json', result)
    print({key: value for key, value in result.items() if key not in ('per_case', 'tokenizer_files_sha256')})


if __name__ == '__main__':
    main()
