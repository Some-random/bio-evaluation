"""Artificial-only new scope/durability/axis-metadata checks; no real inputs."""
import json
from contextlib import contextmanager
from pathlib import Path
import stat
import tempfile
import types
import unittest
from unittest import mock

import prepare_execution as prep
import prepare_extension as helpers
import runner_adapter
import runtime_guard
import resource_authority
import submit_once
import worker


class ExecutionGuardTests(unittest.TestCase):
    def test_runtime_STOP_precedes_any_authority_or_case_access(self):
        with mock.patch.object(runtime_guard, 'scientific_scope') as science:
            with self.assertRaisesRegex(ValueError, 'STOP remains active'):
                runtime_guard.validate_runtime('a' * 64, 'b' * 64)
        science.assert_not_called()

    def test_original_math_adapter_rejects_foreign_native_scope(self):
        contract = helpers.load_contract()
        ids = ['NEUTRAL_FOREIGN_FIXTURE']
        panel = {'task_id': 'P44', 'role': 'explanation_assessment', 'ordered_case_ids': ids,
                 'ordered_ids_sha256': contract.canonical_hash(ids)}
        with self.assertRaisesRegex(ValueError, 'only exact next64 or artificial'):
            contract.aggregate_judgments(panel, {})

    def test_original_math_not_entered_before_real_scope_gate(self):
        contract = helpers.load_contract()
        ids = ['NEUTRAL_GATE_FIXTURE']
        panel = {'task_id': 'P44', 'role': 'explanation_assessment', 'ordered_case_ids': ids,
                 'ordered_ids_sha256': contract.canonical_hash(ids)}
        with mock.patch.object(helpers, 'IDS_SHA256', contract.canonical_hash(ids)), \
             mock.patch.object(runtime_guard, 'begin_scoring', side_effect=RuntimeError('Artificial gate rejection')) as begin:
            with self.assertRaisesRegex(RuntimeError, 'Artificial gate rejection'):
                contract.aggregate_judgments(panel, {})
        begin.assert_called_once()

    def test_durable_writer_never_overwrites_and_uses_private_new_paths(self):
        with tempfile.TemporaryDirectory(prefix='P44-execution-guards-artificial-') as directory:
            path = Path(directory) / 'new-parent/nested/file.json'
            helpers.save(path, {'artificial_only': True})
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
            self.assertEqual(stat.S_IMODE(path.parent.stat().st_mode), 0o700)
            self.assertEqual(stat.S_IMODE(path.parent.parent.stat().st_mode), 0o700)
            with self.assertRaises(FileExistsError):
                helpers.save(path, {'replacement': True})
            self.assertEqual(json.loads(path.read_text()), {'artificial_only': True})

    def test_reference_review_cannot_default_silence_or_skip_cases(self):
        ids = [f'ARTIFICIAL:{i}' for i in range(64)]
        review = {'passed': True, 'reviewer': '/root/remaining_scope_audit',
            'role': 'independent_P44_exact64_actual_complete_reference_source_type_isolation_axis_review',
            'approved_for_bounded_reference_packaging_and_CPU_judge_context_preparation': True,
            'reference_projection_sha256': prep.REFERENCE_SHA, 'ordered_case_ids_sha256': prep.IDS_SHA256,
            'case_reviews': [{'case_id': case_id, 'status': 'independently_reviewed_permitted',
                'held_or_interrupted_scope': False, 'axis_evidence': {axis: {'reviewed': True, 'all_sources_silent': False}
                    for axis in ('molecular_function', 'biological_process', 'cellular_component')}} for case_id in ids]}
        result = prep.reviewed_axis_metadata(review, ids)
        self.assertEqual(len(result), 64)
        review['case_reviews'][0]['axis_evidence']['molecular_function'].update(
            review_note='Neutral artificial review qualification', evidence_basis_fields=['neutral fixture'])
        normalized = prep.reviewed_axis_metadata(review, ids)
        self.assertEqual(normalized[ids[0]]['molecular_function'], {'reviewed': True, 'all_sources_silent': False})
        self.assertIn('review_note', review['case_reviews'][0]['axis_evidence']['molecular_function'])
        for changed in (dict(review, passed=False),
                        dict(review, approved_for_bounded_reference_packaging_and_CPU_judge_context_preparation=False),
                        dict(review, case_reviews=review['case_reviews'][:-1])):
            with self.assertRaises(ValueError):
                prep.reviewed_axis_metadata(changed, ids)
        review['case_reviews'][0]['axis_evidence']['molecular_function'].pop('all_sources_silent')
        with self.assertRaisesRegex(ValueError, 'Never infer -1'):
            prep.reviewed_axis_metadata(review, ids)

    def test_exact_original_runner_source_with_only_durable_writer_adapter(self):
        runner = runner_adapter.load_runner()
        self.assertIs(runner.save, helpers.save)
        self.assertEqual(runner.JUDGE_RUBRIC['minus_one_rule'],
            'Only molecular_function, biological_process and cellular_component may be -1; require reviewed silence of ALL evidence sources for the aspect. Missing GO labels alone never suffice.')

    def test_sealed_judgment_argument_mismatch_stops_before_scoring_claim(self):
        contract = helpers.load_contract()
        ids = ['ARTIFICIAL:SEALED_ARGUMENT']
        with tempfile.TemporaryDirectory(prefix='P44-artificial-sealed-argument-') as directory:
            root = Path(directory); folder = root / 'runtime/run_v1'
            helpers.save(folder / 'judgments.json', {'ARTIFICIAL:SEALED_ARGUMENT': {'status': 'invalid'}})
            helpers.save(folder / 'judge_outcomes.json', [])
            helpers.save(folder / 'prediction_lock.json', {'artificial': True})
            config = {'artificial': True}
            helpers.save(folder / 'judge_lock.json', {'closed': True, 'planned': 64,
                'judgments_sha256': helpers.sha(folder / 'judgments.json'),
                'judge_outcomes_sha256': helpers.sha(folder / 'judge_outcomes.json'),
                'prediction_lock_sha256': helpers.sha(folder / 'prediction_lock.json'),
                'configuration_sha256': contract.canonical_hash(config)})
            with mock.patch.object(runtime_guard, 'HERE', root), \
                 mock.patch.object(runtime_guard, 'IDS_SHA256', contract.canonical_hash(ids)), \
                 mock.patch.object(runtime_guard, 'bound_runtime', return_value=({}, {'model_configuration': config}, {})):
                with self.assertRaisesRegex(ValueError, 'Scoring argument must equal'):
                    runtime_guard.begin_scoring({'ordered_case_ids': ids}, {}, contract)
            self.assertFalse((folder / 'scoring_attempt.json').exists())

    def test_resource_authority_blocks_before_lock_or_queue_observation(self):
        with mock.patch.object(resource_authority, 'bound_runtime', side_effect=ValueError('Artificial denied admission')), \
             mock.patch.object(resource_authority, 'accepted_observer') as observer, \
             mock.patch.object(resource_authority.os, 'open') as opened:
            with self.assertRaisesRegex(ValueError, 'denied admission'):
                resource_authority.capacity_audit(additional=1)
        observer.assert_not_called(); opened.assert_not_called()

    def test_typed_payload_identity_does_not_equate_false_with_zero(self):
        self.assertFalse(runtime_guard.same_json_value({'enable_thinking': False}, {'enable_thinking': 0}))
        self.assertFalse(runtime_guard.same_json_value({'temperature': 0}, {'temperature': False}))

    def test_judge_gate_rejects_unsealed_solver_before_reference_read(self):
        fake_contract = types.SimpleNamespace(validate_panel=lambda panel: ['ARTIFICIAL:SEAL'])
        seen = []
        plan = {'panel': '/artificial/panel', 'judge_reference_directory': '/artificial/closed-references'}
        def read_only_metadata(path):
            seen.append(str(path))
            if str(path) == plan['panel']:
                return {}
            if str(path).endswith('prediction_lock.json'):
                return {'sealed': False}
            raise AssertionError('Reference or runtime body reached before complete seal')
        with mock.patch.object(runtime_guard, 'bound_runtime', return_value=({}, plan, {})), \
             mock.patch.dict(runtime_guard.os.environ, {'SLURM_JOB_ID': 'ARTIFICIAL_JOB'}), \
             mock.patch.object(helpers, 'load_contract', return_value=fake_contract), \
             mock.patch.object(runner_adapter, 'load_runner', return_value=object()), \
             mock.patch.object(runtime_guard, 'read', side_effect=read_only_metadata):
            with self.assertRaisesRegex(ValueError, 'whole64 solver seal'):
                runtime_guard.authorize_dispatch('panel_judge', 'ARTIFICIAL:SEAL', {})
        self.assertFalse(any('closed-references' in path for path in seen))

    def test_foreign_next64_intent_alias_is_rejected(self):
        ids = ['ARTIFICIAL:ALIAS']
        fake_contract = types.SimpleNamespace(validate_panel=lambda panel: ids, canonical_hash=lambda value: 'artificial-ids')
        audit = {'unresolved_schema_or_metadata_candidates': [], 'intent_metadata_records_and_aliases': [
            {'intent_metadata': {'phase': 'panel_solver', 'case_id': ids[0]},
             'physical_copies': [{'path': '/artificial/foreign/transport_intent.json'}]}]}
        with mock.patch.object(helpers, 'load_contract', return_value=fake_contract), \
             mock.patch.object(runtime_guard, 'read', return_value={}), \
             mock.patch.object(runtime_guard, 'IDS_SHA256', 'artificial-ids'), \
             mock.patch.object(runtime_guard, 'known_attempt_metadata', return_value=audit):
            with self.assertRaisesRegex(ValueError, 'Foreign or copied'):
                runtime_guard.verify_known_attempt_ownership({'panel': '/artificial/panel'})

    def test_ambiguous_sbatch_has_durable_claim_and_is_never_reinvoked(self):
        @contextmanager
        def fake_locked():
            yield lambda **kwargs: {'capacity_available': True, 'project_requested_GPUs': 0}
        with tempfile.TemporaryDirectory(prefix='P44-artificial-submit-once-') as directory:
            root = Path(directory)
            with mock.patch.object(submit_once, 'HERE', root), \
                 mock.patch.object(submit_once, 'bind_and_retire_own_STOP', return_value={}), \
                 mock.patch.object(submit_once.guard, 'validate_runtime'), \
                 mock.patch.object(submit_once.guard, 'verify_known_attempt_ownership'), \
                 mock.patch.object(submit_once.resources, 'locked_accounting', fake_locked), \
                 mock.patch.object(submit_once, 'ready_comparison_requests', return_value=[]):
                invoke = mock.Mock(side_effect=TimeoutError('Artificial unknown delivery'))
                with self.assertRaises(TimeoutError):
                    submit_once.submit('a' * 64, 'b' * 64, runner=invoke)
                self.assertTrue((root / 'submission_intent.json').is_file())
                self.assertTrue(helpers.read(root / 'submission_receipt.json')['delivery_unknown'])
                with self.assertRaisesRegex(ValueError, 'never retried'):
                    submit_once.submit('a' * 64, 'b' * 64, runner=invoke)
                self.assertEqual(invoke.call_count, 1)

    def test_worker_adapter_keeps_original_packages_and_blocks_startup_on_STOP(self):
        adapted = worker.load_worker('a' * 64, 'b' * 64)
        self.assertEqual(adapted.PINNED_PACKAGES, {'vllm': '0.32.0', 'torch': '2.13.0',
            'transformers': '5.17.0', 'triton': '3.7.1', 'flashinfer-python': '0.7.0.post1'})
        with self.assertRaisesRegex(ValueError, 'STOP remains active'):
            adapted.validate_plan(worker.HERE / 'plan.json', 'a' * 64)

    def test_original_CPU_API_transport_and_parser_use_artificial_response_only(self):
        import io
        adapted = worker.load_worker('a' * 64, 'b' * 64)
        response = b'{"choices":[{"message":{"content":"4"},"finish_reason":"stop"}]}'
        with tempfile.TemporaryDirectory(prefix='P44-artificial-CPU-API-') as directory:
            identity_file = Path(directory) / 'identity.json'
            helpers.save(identity_file, {'job_id': 'ARTIFICIAL_JOB', 'hostname': 'ARTIFICIAL_HOST',
                'pid': 1, 'proc_start_ticks': 'ARTIFICIAL_TICKS'})
            common = types.SimpleNamespace(start_ticks=lambda pid: 'ARTIFICIAL_TICKS')
            transport = adapted.LocalTransport({'endpoint': 'http://127.0.0.1:1/v1',
                'model_configuration': {'model': 'ARTIFICIAL_MODEL'}}, identity_file,
                helpers.sha(identity_file), common)
            transport.opener = types.SimpleNamespace(open=mock.Mock(return_value=io.BytesIO(response)))
            payload = {'model': 'ARTIFICIAL_MODEL', 'max_tokens': 16384}
            with mock.patch.object(worker.guard, 'authorize_dispatch') as authorize, \
                 mock.patch.dict(adapted.os.environ, {'SLURM_JOB_ID': 'ARTIFICIAL_JOB'}), \
                 mock.patch.object(adapted.socket, 'gethostname', return_value='ARTIFICIAL_HOST'):
                raw = transport.send('development_solver', 'ARTIFICIAL:CPU_API', payload)
            authorize.assert_called_once_with('development_solver', 'ARTIFICIAL:CPU_API', payload)
            parsed = runner_adapter.load_runner().parse_response(raw)
            self.assertEqual((parsed['status'], parsed['text']), ('completed', '4'))


if __name__ == '__main__':
    unittest.main(verbosity=2)
