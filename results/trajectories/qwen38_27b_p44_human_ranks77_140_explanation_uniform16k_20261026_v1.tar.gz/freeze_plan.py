"""Freeze exact existing metadata and opaque admitted packet hashes on CPU only.

No original source, model, scheduler, scorer or network is opened. Default is
read-only source preparation; --freeze creates a disabled exact plan once.
"""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from prepare_extension import IDS_SHA256, read, save, sha
import runtime_guard as guard


def freeze():
    guard.require((HERE / 'STOP').is_file(), 'Disabled execution STOP must remain present during source freeze')
    guard.require(not (HERE / 'plan.json').exists(), 'Preserve an existing frozen exact plan')
    adoption, _ = guard.scientific_scope()
    previous = HERE.parent / 'wider_human_extension_20261022_v1'
    old = read(previous / 'plan.json')
    guard.require(sha(previous / 'plan.json') == '1557688bcb161bc803357f4d10a875ae7c1d7a7bc3195d420e8abf3821d947ee',
                  'Exact accepted prior environment/method metadata required')
    validation = read(HERE / 'preparation/packet_validation.json')
    context = read(HERE / 'judge_template_tokenizer_preflight.json')
    guard.require(validation.get('passed') is True and len(validation['per_case']) == 64,
                  'Complete actual private packet preparation required')
    guard.require(context.get('all_fit') is True and context.get('planned') == 64
                  and context.get('actual_saved_candidate_fit_verified') is False,
                  'Complete full judge-template CPU fit required; actual candidates do not yet exist')
    plan = {key: old[key] for key in ('task_id', 'execution_scope', 'planned', 'source_released_denominator',
        'judge_declaration', 'gpus_requested', 'tensor_parallel_size', 'dtype', 'total_project_gpu_ceiling',
        'base_runtime', 'cuda_overlay', 'runtime_common', 'checkpoint_audit', 'runtime_package_installation',
        'native_exact_condition_unavailable_evidence', 'P28_P29_GO_results_reused_or_changed',
        'new_paid_or_OpenAI_calls', 'training', 'submission_by_preparation')}
    plan.update(created_at_utc=datetime.now(timezone.utc).isoformat(), condition=guard.CONDITION,
        run_id='qwen38_27b_p44_human_ranks77_140_explanation_uniform16k_20261026_v1',
        execution_scope_compatibility_qualification='The inherited internal scope literal selects the unchanged64 runner branch; exact ordered ranks77-140 and bounded known-attempt ownership are enforced separately. No global untouched claim.',
        ordered_case_ids_sha256=IDS_SHA256, remaining_release_cases_unreviewed=8490,
        prior_completed_case_count=76, prior_condition_modified=False, prior_condition_results_pooled=False,
        source_human_ranks_inclusive=[77, 140], runtime_admission_granted=False,
        root_scientific_adoption_sha256=guard.ADOPTION_SHA, prospective_protocol_sha256=guard.PROTOCOL_SHA,
        model_configuration=read(HERE / 'prepared_configuration.json'), endpoint='http://127.0.0.1:8494/v1',
        panel=str(HERE / 'preparation/panel.json'),
        judge_reference_directory=str(HERE / 'preparation/packets/judge_reference'),
        solver_envelope_manifest=str(HERE / 'solver_envelopes_manifest.json'),
        neutral_gate_inputs=str(HERE / 'neutral_gate_inputs.json'), output_root=str(HERE / 'runtime/run_v1'),
        phase_policy=adoption['phase_policy'], scoring_policy=adoption['scoring_policy'],
        execution_STOP_sha256=sha(HERE / 'STOP'),
        material_differences=[
          'Separately adopted fixed source-order human ranks77-140; old12+64 immutable and unpooled; other8490 unchanged.',
          *old['material_differences'][1:],
          'Known-attempt scan is bounded to preserved P44 intent metadata/aliases; no global zero-attempt proof is claimed.',
          'Preserve three empty InterPro and twenty empty PPI inputs, native annotation types and all64 denominator.',
          'The actual complete candidate is tokenized only after the complete solver seal and before each judge intent.'])
    paths = [HERE / name for name in (
        'prepare_extension.py', 'runner_adapter.py', 'runtime_guard.py', 'resource_authority.py',
        'worker.py', 'worker.sbatch', 'submit_once.py', 'freeze_plan.py', 'p44_runner.py',
        'test_p44_runner.py', 'test_execution_guards.py', 'prepare_execution.py', 'tokenizer_preflight_judge.py',
        'prepared_configuration.json', 'neutral_gate_inputs.json', 'solver_envelopes_manifest.json',
        'judge_template_tokenizer_preflight.json', 'synthetic_validation.json',
        'preparation/offline_workflow.py', 'preparation/panel.json', 'preparation/admission.json',
        'preparation/packet_validation.json', 'CPU_preparation_source_snapshot_v1/manifest.json',
        'CPU_packet_preparation_invocation.json', 'CPU_packet_preparation_invocation_receipt.json',
        'CPU_judge_template_invocation_receipt.json',
        'independent_packet_context_integrity_review_20261026_v1.json')]
    prospective = guard.PROSPECTIVE
    paths += [prospective / name for name in ('root_scientific_adoption.json', 'protocol.json',
        'fixed_definitions.json', 'cpu_config.json', 'solver_tokenizer_preflight.json',
        'independent_prospective_protocol_CPU_review_20261026_v1.json')]
    paths += [HERE.parent / 'next_human64_cpu_preparation_20261026_v1/independent_actual_complete_input_source_isolation_review_20261026_v1.json',
        HERE.parent / 'next_human64_reference_CPU_preparation_20261026_v1/independent_actual_complete_reference_source_isolation_axis_review_20261026_v1.json',
        HERE.parent / 'next_human64_reference_CPU_preparation_20261026_v1/audit_known_attempt_metadata.py',
        HERE.parent / 'next_human64_reference_CPU_preparation_20261026_v1/attempt_alias_metadata_audit.json',
        HERE.parent / 'engineering_20261020/explanation_contract.py', previous / 'worker.py',
        HERE.parent / 'restore_20261024_v1/resource_authority.py',
        HERE.parent / 'remaining8554_metadata_audit_20261025_v1/manifest.v2.json',
        HERE.parent / 'remaining8554_metadata_audit_20261025_v1/supporting_metadata_review.json']
    # Reuse bounded accepted environment/source metadata, never hash the huge archives/weights here.
    paths += [Path(path) for path in old['frozen_files_sha256'] if Path(path).parent != previous
        and not Path(path).is_relative_to(previous) and Path(path).stat().st_size < 1024 * 1024]
    for row in validation['per_case']:
        for kind in ('solver', 'reference'):
            path = HERE / 'preparation' / row[kind + '_path']
            guard.require(sha(path) == row[kind + '_sha256'], 'Admitted private packet bytes changed')
            paths.append(path)
    for row in read(HERE / 'solver_envelopes_manifest.json')['envelopes']:
        path = Path(row['path'])
        guard.require(sha(path) == row['sha256'], 'Frozen complete solver envelope changed')
        paths.append(path)
    paths = sorted(set(paths))
    guard.require(all(path.is_file() and not path.is_symlink() and path.stat().st_size < 1024 * 1024 for path in paths),
                  'Only bounded regular metadata/code and already admitted private packets are hashed')
    plan['frozen_files_sha256'] = {str(path): sha(path) for path in paths}
    save(HERE / 'plan.json', plan)
    return sha(HERE / 'plan.json')


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--freeze', action='store_true')
    args = parser.parse_args()
    if args.freeze:
        print(freeze())
    else:
        print('Disabled source-only default; no runtime admission, STOP change or model action.')


if __name__ == '__main__':
    main()
