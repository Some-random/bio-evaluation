"""Artificial-only once-only/isolation/full-denominator P44 workflow checks."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import p44_runner as run


def reply(text, finish='stop'):
    return {'choices': [{'message': {'role': 'assistant', 'content': text}, 'finish_reason': finish}], 'usage': {}}


def judgment(reliability=9):
    return json.dumps({**{axis: reliability for axis in run.source_modules()[0].AXES}, 'critique': 'Artificial reference support.'})


def fixture(root):
    contract, _ = run.source_modules(); ids = ['ARTIFICIAL:A', 'ARTIFICIAL:B']
    panel = {'task_id': 'P44', 'role': 'explanation_assessment', 'ordered_case_ids': ids,
        'ordered_ids_sha256': contract.canonical_hash(ids), 'evidence_snapshot_sha256': 'artificial'}
    run.save(root / 'panel.json', panel)
    configuration = {'model': 'ARTIFICIAL MODEL', 'revision': 'artificial', 'temperature': 0, 'top_p': 1,
        'max_tokens': 16384, 'chat_template_kwargs': {'enable_thinking': False}}
    rows = []; neutral = []
    for index, case_id in enumerate(ids):
        envelope = {'model': configuration['model'], 'messages': [{'role': 'user', 'content': 'ARTIFICIAL SOLVER ONLY'}],
            **{key: configuration[key] for key in ('temperature', 'top_p', 'max_tokens', 'chat_template_kwargs')}}
        path = root / 'envelopes' / (str(index) + '.json'); run.save(path, envelope)
        rows.append({'case_id': case_id, 'path': str(path), 'sha256': run.sha(path)})
        dossier = {'case_id': case_id, 'evidence': {'protein_function': 'SECRET_REFERENCE_CANARY'},
            'axis_evidence': {axis: {'reviewed': True, 'all_sources_silent': False} for axis in contract.FUNCTIONAL_AXES},
            'evidence_snapshot_sha256': 'artificial'}
        run.save(root / 'references' / (case_id + '.json'), dossier)
        lock = contract.freeze_predictions(panel, {identity: {'case_id': identity, 'status': 'saved', 'generation': 'artificial'} for identity in ids})
        packet = contract.build_judge_packet(panel, case_id, dossier, lock)
        neutral.append({'case_id': case_id, 'solver_envelope': envelope, 'expected_solver_final': '4',
            'judge_packet': packet, 'expected_reliability_range': [8, 10]})
    run.save(root / 'envelopes.json', {'envelopes': rows})
    run.save(root / 'neutral.json', {'cases': neutral})
    return {'task_id': 'P44', 'condition': 'ARTIFICIAL ONLY', 'execution_scope': 'artificial_fixture',
        'planned': 2, 'source_released_denominator': 2, 'remaining_release_cases_unreviewed': 0, 'model_configuration': configuration,
        'panel': str(root / 'panel.json'), 'judge_reference_directory': str(root / 'references'),
        'solver_envelope_manifest': str(root / 'envelopes.json'), 'neutral_gate_inputs': str(root / 'neutral.json')}


def callback(phase, case_id, payload):
    if phase == 'development_solver': return reply('4')
    if phase.endswith('judge'): return reply(judgment())
    return reply('Artificial candidate explanation')


class ProtocolChecks(unittest.TestCase):
    def test_full_order_and_reference_isolation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); plan = fixture(root); transport = run.RecordingTransport(callback)
            completion = run.run_protocol(plan, root / 'output', transport)
            self.assertTrue(completion['panel_primary_defined'])
            self.assertEqual(completion['local_declared_axis_macro_score'], 9)
            phases = [phase for phase, _, _ in transport.calls]
            self.assertEqual(phases, ['development_solver', 'development_judge'] * 2 + ['panel_solver'] * 2 + ['panel_judge'] * 2)
            self.assertNotIn('SECRET_REFERENCE_CANARY', json.dumps([payload for phase, _, payload in transport.calls if phase == 'panel_solver']))
            self.assertIn('SECRET_REFERENCE_CANARY', json.dumps([payload for phase, _, payload in transport.calls if phase == 'panel_judge']))
            self.assertTrue((root / 'output/prediction_lock.json').exists())
            with self.assertRaises(FileExistsError): run.run_protocol(plan, root / 'output', transport)

    def test_transport_stop_preserves_undispatched_and_no_judge(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); plan = fixture(root)
            def fail(phase, case_id, payload):
                return run.TransportFailure('artificial transport failure') if phase == 'panel_solver' else callback(phase, case_id, payload)
            transport = run.RecordingTransport(fail); result = run.run_protocol(plan, root / 'out', transport)
            self.assertFalse(result['prediction_lock_sealed']); self.assertEqual(result['solver']['not_dispatched_after_stop'], 1)
            self.assertNotIn('panel_judge', [row[0] for row in transport.calls]); self.assertFalse((root / 'out/prediction_lock.json').exists())

    def test_truncation_stays_invalid_in_full_denominator(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); plan = fixture(root)
            def truncate(phase, case_id, payload):
                return reply('partial', 'length') if phase == 'panel_solver' and case_id.endswith('A') else callback(phase, case_id, payload)
            result = run.run_protocol(plan, root / 'out', run.RecordingTransport(truncate))
            scores = run.read(root / 'out/scores.json')
            self.assertEqual(scores['planned'], 2); self.assertEqual(scores['valid_judgments'], 1)
            self.assertIsNone(scores['local_declared_axis_macro_score']); self.assertEqual(result['judge']['not_applicable_solver_failure'], 1)

    def test_invalid_judge_stops_and_primary_undefined(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); plan = fixture(root)
            def invalid(phase, case_id, payload):
                return reply('{"reliability": true}') if phase == 'panel_judge' else callback(phase, case_id, payload)
            transport = run.RecordingTransport(invalid); result = run.run_protocol(plan, root / 'out', transport)
            self.assertFalse(result['panel_primary_defined']); self.assertEqual(result['judge']['not_dispatched_after_stop'], 1)
            self.assertEqual(len([row for row in transport.calls if row[0] == 'panel_judge']), 1)

    def test_development_failure_produces_no_real_calls(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); plan = fixture(root); transport = run.RecordingTransport(lambda *args: reply('bad'))
            with self.assertRaises(RuntimeError): run.run_protocol(plan, root / 'out', transport)
            self.assertEqual(len(transport.calls), 1); self.assertEqual(run.read(root / 'out/completion.json')['real_panel_dispatches'], 0)

    def test_context_failure_before_transport_preserves_intent_boundary(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); transport = run.RecordingTransport(callback)
            def fail(payload): raise ValueError('Artificial context overflow')
            with self.assertRaises(ValueError): run.call_once(root, 'artificial', 0, 'A', {}, transport, fail)
            self.assertEqual(transport.calls, []); self.assertTrue((root / '000/request.json').exists())
            self.assertFalse((root / '000/transport_intent.json').exists())

    def test_response_refusal_and_nonfinite_are_stopped(self):
        self.assertTrue(run.parse_response(json.dumps(reply('I cannot assist with this.')).encode())['stop'])
        self.assertEqual(run.parse_response(b'{"choices":NaN}')['status'], 'response_error')
        self.assertEqual(run.parse_response(json.dumps(reply('', 'length')).encode())['status'], 'truncated')

    def test_unjustified_minus_one_and_extra_fields_rejected(self):
        contract, _ = run.source_modules()
        value = json.loads(judgment()); value['molecular_function'] = -1
        dossier = {'axis_evidence': {axis: {'reviewed': True, 'all_sources_silent': False} for axis in contract.FUNCTIONAL_AXES}}
        with self.assertRaises(ValueError): contract.parse_judgment(json.dumps(value), dossier)
        value = json.loads(judgment()); value['extra'] = 'invalid'
        with self.assertRaises(ValueError): contract.parse_judgment(json.dumps(value), dossier)


if __name__ == '__main__': unittest.main()
