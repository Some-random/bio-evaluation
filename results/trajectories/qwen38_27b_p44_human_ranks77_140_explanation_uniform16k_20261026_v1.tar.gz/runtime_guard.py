"""Revocable exact-next64 metadata/seal gates; no scheduler/model action on import.

Missing reference, ownership, engineering or runtime admissions are exact
internal prerequisites. This module never creates them or clears STOP.
"""
from datetime import datetime, timezone
import os
import json
from pathlib import Path
import hashlib
import types
from prepare_extension import HERE, IDS_SHA256, read, save, sha

PROSPECTIVE = HERE.parent / 'next_human64_prospective_protocol_20261026_v1'
ADOPTION_SHA = '4da60a5bc838a8d4cdb34a5a7d1255bc19fd30456c7c33c52711e439205c1a43'
PROTOCOL_SHA = '789ca32ca19c935c8aac8371ea9d931ff79a7f3329bf5eb846b46b4354b78f77'
CONDITION = 'BIOREASON_PRO_P44_HUMAN_RANKS77_140_LOCAL_SELF_JUDGE_UNIFORM16K_PROSPECTIVE_V1'
MODEL_KEYS = ('model', 'revision', 'temperature', 'top_p', 'max_tokens',
              'chat_template_kwargs', 'max_context_tokens')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def same_json_value(left, right):
    return json.dumps(left, sort_keys=True, separators=(',', ':'), allow_nan=False) == \
        json.dumps(right, sort_keys=True, separators=(',', ':'), allow_nan=False)


def require_unheld():
    require(not os.path.lexists(HERE / 'STOP'), 'Exact next64 execution STOP remains active')


def pinned_metadata(path, digest):
    path = Path(path)
    require(path.is_absolute() and path == path.resolve() and path.is_file()
            and not path.is_symlink() and path.stat().st_size < 1024 * 1024,
            'Bounded canonical regular metadata required')
    require(sha(path) == digest, 'Exact scientific/engineering/runtime metadata changed')
    return read(path)


def scientific_scope():
    adoption = pinned_metadata(PROSPECTIVE / 'root_scientific_adoption.json', ADOPTION_SHA)
    protocol = pinned_metadata(PROSPECTIVE / 'protocol.json', PROTOCOL_SHA)
    require(adoption.get('issuer') == '/root' and adoption.get('scientific_condition_adopted') is True
            and adoption.get('sole_owner') == '/root/main_docs_refresh/p13_downstream_source_map'
            and adoption.get('ordered_case_ids_sha256') == IDS_SHA256
            and adoption.get('planned') == 64 and adoption.get('condition_id') == CONDITION
            and adoption.get('protocol', {}).get('sha256') == PROTOCOL_SHA
            and protocol.get('planned') == 64 and protocol.get('candidate_ordered_ids_sha256') == IDS_SHA256,
            'Exact separately adopted fixed next64 scientific scope required')
    return adoption, protocol


def validate_runtime(plan_sha, admission_sha, *, require_allocation=False, metadata_STOP_retirement=False):
    if not metadata_STOP_retirement:
        require_unheld()  # Fail before inputs/references or any server/model work.
    adoption, protocol = scientific_scope()
    plan = pinned_metadata(HERE / 'plan.json', plan_sha)
    admission = pinned_metadata(HERE / 'runtime_admission.json', admission_sha)
    require(plan.get('task_id') == 'P44' and plan.get('planned') == 64
            and plan.get('condition') == CONDITION and plan.get('gpus_requested') == 1
            and plan.get('dtype') == 'bfloat16' and plan.get('tensor_parallel_size') == 1
            and plan.get('total_project_gpu_ceiling') == 8
            and Path(plan.get('output_root', '')).resolve() == HERE / 'runtime/run_v1'
            and plan.get('root_scientific_adoption_sha256') == ADOPTION_SHA
            and plan.get('prospective_protocol_sha256') == PROTOCOL_SHA,
            'Exact next64 plan/ownership/runtime boundary required')
    require(same_json_value({key: plan['model_configuration'][key] for key in MODEL_KEYS},
                           {key: adoption['model_configuration'][key] for key in MODEL_KEYS})
            and same_json_value(plan.get('phase_policy'), adoption['phase_policy'])
            and same_json_value(plan.get('scoring_policy'), adoption['scoring_policy']),
            'Frozen model, full budgets, phase/stop and original aggregation rules required')
    require(admission.get('admitted') is True
            and admission.get('reviewer') in ('/root/remaining_scope_audit', '/root/independent_review', '/root')
            and admission.get('task_id') == 'P44'
            and admission.get('scope') == 'solver_and_declared_local_judge_P44_human_ranks77_140_once'
            and admission.get('plan_sha256') == plan_sha
            and admission.get('root_scientific_adoption_sha256') == ADOPTION_SHA
            and admission.get('project_GPU_ceiling') == 8 and admission.get('requested_GPUs') == 1
            and admission.get('selective_or_ambiguous_retry_authorized') is False,
            'Exact independent runtime admission required; scientific adoption alone is insufficient')
    if metadata_STOP_retirement:
        require(not require_allocation and admission.get('permit_execution_STOP_retirement') is True,
                'Only independently admitted metadata verification may precede own STOP retirement')
    for kind in ('reference_review', 'judge_template_context_review', 'attempt_ownership_review', 'engineering_review'):
        binding = admission.get(kind, {})
        reviewed = pinned_metadata(binding.get('path', ''), binding.get('sha256'))
        require(reviewed.get('passed') is True, 'Exact passed reference/context/ownership/engineering gates required')
    for path, digest in plan['frozen_files_sha256'].items():
        require(sha(path) == digest, 'Frozen next64 code/input/reference artifact changed')
    if require_allocation:
        require(bool(os.environ.get('SLURM_JOB_ID')), 'Own admitted Slurm allocation required')
    return plan, admission


def bound_runtime():
    require_unheld()
    binding = read(HERE / 'runtime/runtime_binding.json')
    require(binding.get('role') == 'exact_next64_runtime_binding_before_first_model_action'
            and binding.get('root_scientific_adoption_sha256') == ADOPTION_SHA
            and binding.get('owner') == '/root/main_docs_refresh/p13_downstream_source_map',
            'Exact durable runtime authority binding required')
    plan, admission = validate_runtime(binding['plan_sha256'], binding['runtime_admission_sha256'])
    return binding, plan, admission


def begin_scoring(panel, judgments, contract):
    binding, plan, _ = bound_runtime()
    require(contract.canonical_hash(panel['ordered_case_ids']) == IDS_SHA256,
            'Only exact adopted64 can enter real scoring')
    folder = HERE / 'runtime/run_v1'
    judge_lock = read(folder / 'judge_lock.json')  # Lock metadata only; no dossier parsed here.
    require(judge_lock.get('closed') is True and judge_lock.get('planned') == 64
            and judge_lock.get('judgments_sha256') == sha(folder / 'judgments.json')
            and judge_lock.get('judge_outcomes_sha256') == sha(folder / 'judge_outcomes.json')
            and judge_lock.get('prediction_lock_sha256') == sha(folder / 'prediction_lock.json')
            and judge_lock.get('configuration_sha256') == contract.canonical_hash(plan['model_configuration']),
            'Complete original solver and judge seals required before once-only scoring')
    require(contract.canonical_hash(judgments) == contract.canonical_hash(read(folder / 'judgments.json')),
            'Scoring argument must equal the exact sealed judgments file')
    require(not os.path.lexists(folder / 'scores.json') and not os.path.lexists(folder / 'scoring_attempt.json'),
            'Preserve prior/ambiguous scoring attempt; no automatic rescore')
    save(folder / 'scoring_attempt.json', {'role': 'one_original_frozen_axis_macro_scoring_attempt',
        'at_utc': datetime.now(timezone.utc).isoformat(), 'plan_sha256': binding['plan_sha256'],
        'runtime_admission_sha256': binding['runtime_admission_sha256'],
        'judge_lock_sha256': sha(folder / 'judge_lock.json'), 'prediction_lock_sha256': sha(folder / 'prediction_lock.json'),
        'judgments_argument_sha256': contract.canonical_hash(judgments), 'planned': 64,
        'automatic_retry': False, 'original_contract_sha256': '071444944b4c986b60e87318b8db8018ef92138491eadfc6b07ea888f3e40923'})


def known_attempt_metadata():
    path = HERE.parent / 'next_human64_reference_CPU_preparation_20261026_v1/audit_known_attempt_metadata.py'
    source = path.read_bytes()
    require(hashlib.sha256(source).hexdigest() == '131210bc08ebe282dd350fc343799dde9b50a9095cb7951aca2ff43b90bd025e',
            'Exact independently reviewed bounded attempt-metadata scanner required')
    module = types.ModuleType('exact_P44_known_attempt_metadata_only_observer')
    module.__file__ = str(path)
    exec(compile(source, str(path), 'exec'), module.__dict__)
    return module.audit()


def verify_known_attempt_ownership(plan, *, before_first_dispatch=False):
    from prepare_extension import load_contract
    panel = read(plan['panel'])
    contract = load_contract()
    ids = contract.validate_panel(panel)
    require(contract.canonical_hash(ids) == IDS_SHA256, 'Exact next64 attempt ownership boundary required')
    audit = known_attempt_metadata()
    require(not audit['unresolved_schema_or_metadata_candidates'], 'Unresolved known attempt metadata blocks dispatch')
    target = set(ids)
    observed = [record for record in audit['intent_metadata_records_and_aliases']
                if record['intent_metadata']['case_id'] in target]
    if before_first_dispatch:
        require(not observed, 'Known next64 invocation exists; preserve actual or ambiguous attempts')
    pairs = set()
    for record in observed:
        value = record['intent_metadata']; case_id, phase = value['case_id'], value['phase']
        require(phase in ('panel_solver', 'panel_judge'), 'Unexpected known phase/alias for native next64')
        pair = (phase, case_id)
        require(pair not in pairs, 'Multiple different known intent records for one next64 phase/case')
        pairs.add(pair)
        expected = HERE / 'runtime/run_v1' / ('solver' if phase == 'panel_solver' else 'judge') / f'{ids.index(case_id):03d}' / 'transport_intent.json'
        require(all(Path(copy['path']) == expected for copy in record['physical_copies']),
                'Foreign or copied native next64 intent alias blocks dispatch')
    return audit


def authorize_dispatch(phase, case_id, payload):
    binding, plan, _ = bound_runtime()
    require(bool(os.environ.get('SLURM_JOB_ID')), 'Own admitted allocation required before each local API attempt')
    from prepare_extension import load_contract
    from runner_adapter import load_runner
    contract, runner = load_contract(), load_runner()
    panel = read(plan['panel']); ids = contract.validate_panel(panel)
    if phase in ('development_solver', 'development_judge'):
        neutral = read(plan['neutral_gate_inputs'])['cases']
        matches = [row for row in neutral if row['case_id'] == case_id]
        require(len(neutral) == 2 and len(matches) == 1, 'Only two frozen artificial control identities allowed')
        row = matches[0]
        expected = row['solver_envelope'] if phase == 'development_solver' else runner.judge_envelope(
            row['judge_packet'], plan['model_configuration'], contract)
        index = neutral.index(row)
        folder = HERE / 'runtime/run_v1' / phase / f'{index:03d}'
    else:
        require(phase in ('panel_solver', 'panel_judge') and case_id in ids, 'Exact native phase and64 identity required')
        index = ids.index(case_id)
        if phase == 'panel_solver':
            record = read(plan['solver_envelope_manifest'])['envelopes'][index]
            require(record['case_id'] == case_id and sha(record['path']) == record['sha256'], 'Frozen solver request changed')
            expected = read(record['path'])  # Five admitted input fields only; never any reference dossier.
            folder = HERE / 'runtime/run_v1/solver' / f'{index:03d}'
        else:
            lock_path = HERE / 'runtime/run_v1/prediction_lock.json'
            lock = read(lock_path)
            require(lock.get('sealed') is True
                    and set(lock.get('terminal_predictions', {})) == set(ids)
                    and lock.get('predictions_sha256') == contract.canonical_hash(lock['terminal_predictions'])
                    and lock.get('panel_sha256') == contract.canonical_hash(panel),
                    'Complete immutable whole64 solver seal required before real judge dossier access')
            dossier = read(Path(plan['judge_reference_directory']) / (case_id + '.json'))
            packet = contract.build_judge_packet(panel, case_id, dossier, lock)
            expected = runner.judge_envelope(packet, plan['model_configuration'], contract)
            folder = HERE / 'runtime/run_v1/judge' / f'{index:03d}'
    require(same_json_value(payload, expected),
            'HTTP payload must equal the exact frozen solver/control or sealed original judge request')
    verify_known_attempt_ownership(plan)
    intent_path = folder / 'transport_intent.json'
    intent = read(intent_path)
    require(intent.get('phase') == phase and intent.get('case_id') == case_id
            and intent.get('request_sha256') == sha(folder / 'request.json'),
            'Exact durable original transport intent/request binding required')
    # Revocation is checked again at the final claim edge, before any HTTP call.
    require_unheld()
    save(folder / 'HTTP_send_started.json', {'role': 'one_original_local_HTTP_invocation_about_to_start_not_delivery',
        'at_utc': datetime.now(timezone.utc).isoformat(), 'phase': phase, 'case_id': case_id,
        'plan_sha256': binding['plan_sha256'], 'runtime_admission_sha256': binding['runtime_admission_sha256'],
        'transport_intent_sha256': sha(intent_path), 'request_sha256': sha(folder / 'request.json'),
        'automatic_retry': False})
