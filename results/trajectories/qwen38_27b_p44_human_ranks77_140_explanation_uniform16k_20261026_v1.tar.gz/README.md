# Exact next human64 execution packet

This disabled packet binds human source ranks77–140 to the already adopted local solver/self-judge method. Old12+64 remain separate and unchanged; other8490 remain outside this condition. No global zero-attempt claim is made.

The original generic contract, protocol runner, offline renderer and model worker sources are byte-identical to accepted sources. Isolated adapters add exact scope/STOP/runtime gates, durable output writes, final HTTP claims, shared locked GPU accounting and a once-only scoring claim bound to the sealed judgments. The inherited internal runner scope literal selects its unchanged64 branch; exact new identity and root adoption are separately enforced.

Actual solver inputs and all9 judge fields have independent full-record reviews. Native annotations and null/empty values remain intact, including3empty InterPro/20empty PPI contexts. Solver requests contain only the admitted five fields. Whole64 solver seal precedes actual judge dossier access. The full CPU template fit reserves16384 candidate and16384 judge tokens; every actual saved candidate is checked again with the original processor before judge intent.

The private package validation and independent opaque packet/context review are frozen.37 artificial CPU checks pass:14 scope/durability/API/submission guards,8 unchanged protocol regressions and15 unchanged generic five-axis/schema/formula checks. The CPU API fixture uses an in-memory artificial response; no network, native scoring or model call occurs. Original score math is unchanged; primary score remains undefined for any invalid/missing required case.

Independent engineering PASS and exact runtime_admission.json are still required. runtime_admission.template.json is explicitly false and grants nothing. The reviewer may bind one exact engineering receipt for both engineering and bounded ownership checks. The already issued root scientific adoption delegates unchanged completion after those gates, without a routine additional root/user turn.

Only submit_once.py --submit with exact plan/admission hashes can retire this new execution STOP, preserving its bytes and receipt. It rechecks bounded known attempt aliases and fresh conservative GPU accounting under the shared project lock through the durable sole sbatch claim. It yields to existing ready admitted comparison work. Capacity-only observations may repeat; actual/ambiguous sbatch, HTTP or scoring attempts never retry. Own allocation is freshly checked at startup and after runtime environment installation before model imports.

The sole invocation and every exact source/receipt hash are in execution_review_candidate.json and manifest.json. Independent preparation review does not itself imply allocation, model delivery, valid judgments, biological validation or publication admission. Main-document integration remains root-owned; narrow publication requires its later independent numerical/privacy/license/export gates.
