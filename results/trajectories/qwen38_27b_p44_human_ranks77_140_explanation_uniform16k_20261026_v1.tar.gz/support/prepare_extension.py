"""Narrow helpers for a separately admitted P44 next64 condition.

Imports read no case/reference/runtime data. The original generic contract is
loaded from its exact verified bytes in an isolated namespace. Its scoring
math stays unchanged; a real next64 score requires the new durable seal gate.
"""
from pathlib import Path
import hashlib
import json
import os
import types

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
CONTRACT = TASK / 'engineering_20261020/explanation_contract.py'
CONTRACT_SHA256 = '071444944b4c986b60e87318b8db8018ef92138491eadfc6b07ea888f3e40923'
IDS_SHA256 = 'e008c29996b18a53b2219f57ece0daccafac9f191c2966983e96bfd0dcc43580'


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    missing = []
    parent = path.parent
    while not parent.exists():
        missing.append(parent)
        parent = parent.parent
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    for directory in missing:
        directory.chmod(0o700)
    data = (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def load_contract():
    source = CONTRACT.read_bytes()
    if hashlib.sha256(source).hexdigest() != CONTRACT_SHA256:
        raise ValueError('Exact original generic P44 contract required')
    contract = types.ModuleType('exact_next64_isolated_original_P44_contract')
    contract.__file__ = str(CONTRACT)
    exec(compile(source, str(CONTRACT), 'exec'), contract.__dict__)
    original_aggregate = contract.aggregate_judgments

    def aggregate_with_durable_real64_gate(panel, judgments):
        ids = contract.validate_panel(panel)
        if not all(case_id.startswith('ARTIFICIAL:') for case_id in ids):
            if contract.canonical_hash(ids) != IDS_SHA256:
                raise ValueError('This adapter permits only exact next64 or artificial fixtures')
            from runtime_guard import begin_scoring
            begin_scoring(panel, judgments, contract)
        return original_aggregate(panel, judgments)

    contract.aggregate_judgments = aggregate_with_durable_real64_gate
    return contract
