"""Disabled four-path local artifact assembly after exact independent closure review.

No model, scheduler, Git, network, scorer attempt or main-document edits. The
completed concrete bytes still need independent privacy/license/publication
review before the separate narrow publisher may send them anywhere.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import tarfile

DELIVERY = Path(__file__).resolve().parent
sys.path.insert(0, str(DELIVERY))
import export_condition as exporter
run = exporter.run
HERE = exporter.HERE
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')


def score_presentation(scores):
    """Render the original primary/diagnostics; nonfunctional absence is n/a."""
    def formatted(value):
        return 'undefined' if value is None else f'{value:.4f}'
    complete = scores['all_case_complete']
    values = scores['per_axis_score'] if complete else scores['valid_only_diagnostics']['per_axis']
    rows = []
    for axis, value in values.items():
        absent = scores['per_axis_evidence_absent_count'].get(axis)
        absence_text = 'n/a' if absent is None else str(absent)
        rows.append('| ' + axis.replace('_', ' ').title() + ' | ' + formatted(value) + ' | '
            + str(scores['per_axis_scored_case_count'][axis]) + ' | ' + absence_text + ' |')
    return {'axis_rows': '\n'.join(rows),
        'primary_text': ('The full64 local axis-macro score is **' + formatted(scores['local_declared_axis_macro_score']) + '/10**.'
            if complete else 'The full64 primary score is **undefined** because at least one required valid judgment is missing. Valid-only diagnostics below do not replace it.'),
        'table_label': 'Local score /10' if complete else 'Valid-only diagnostic /10'}


def assemble():
    exporter.source_review()
    plan, scores, completion, audited_members = exporter.audit_closed(HERE)
    export = DELIVERY / 'private_export_candidate_v1'
    manifest = run.read(export / 'export_member_manifest.json')
    if set(manifest['members']) != set(audited_members):
        raise ValueError('Export candidate whitelist differs from the full current audit')
    exporter.exact_tree(export, set(audited_members) | {'export_member_manifest.json'})
    for name, source in audited_members.items():
        record = manifest['members'][name]
        if (record['sha256'] != run.sha(source) or record['bytes'] != source.stat().st_size
            or run.sha(export / name) != record['sha256'] or (export / name).stat().st_size != record['bytes']):
            raise ValueError('Exact private export source/copy/manifest binding changed')
    review_path = DELIVERY / 'independent_actual_completion_review.json'
    review = run.read(review_path)
    folder = Path(plan['output_root'])
    required = {'plan_sha256': run.sha(HERE / 'plan.json'),
        'score_sha256': run.sha(folder / 'scores.json'),
        'prediction_lock_sha256': run.sha(folder / 'prediction_lock.json'),
        'judge_lock_sha256': run.sha(folder / 'judge_lock.json'),
        'export_manifest_sha256': run.sha(export / 'export_member_manifest.json')}
    if (review.get('passed') is not True
        or review.get('reviewer') not in ('/root/remaining_scope_audit', '/root/independent_review', '/root', '/root/classification_docs_review')
        or any(review.get(key) != value for key, value in required.items())):
        raise ValueError('Exact independent actual full64 delivery/seal/formula/export review required')
    contract = run.read(DELIVERY / 'prospective_four_path_delivery_contract.json')
    paths = contract['proposed_paths']
    if len(paths) != 4 or any((ROOT / name).exists() for name in paths):
        raise ValueError('Preserve existing report/archive artifacts; no overwrite')
    run.save(DELIVERY / 'assembly_attempt.json', {'role': 'one_local_four_path_assembly_not_publication',
        'at_utc': datetime.now(timezone.utc).isoformat(), **required,
        'independent_actual_completion_review_sha256': run.sha(review_path), 'paths': paths})
    archive_members = {name: export / name for name in set(audited_members) | {'export_member_manifest.json'}}
    archive_members['support/independent_actual_completion_review.json'] = review_path
    archive = ROOT / paths[2]; archive.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, 'x:gz') as stream:
        for name, source in sorted(archive_members.items()):
            stream.add(source, arcname=name, recursive=False)
    archive.chmod(0o600)
    archive_manifest = {'task_id': 'P44', 'condition': plan['condition'], 'run_id': plan['run_id'],
        'archive_sha256': run.sha(archive), 'archive_bytes': archive.stat().st_size,
        'members': {name: {'sha256': run.sha(source), 'bytes': source.stat().st_size}
                    for name, source in sorted(archive_members.items())},
        'prior76_modified_or_pooled': False, 'whole_release_completed': False,
        'other8490_unchanged': True, 'source_revision': 'a18315a77d27dd4fe5a28b9b757695cff4ba4e3f',
        'publisher_dataset_metadata_license': 'apache-2.0', 'publication_attempted': False}
    run.save(ROOT / paths[3], archive_manifest)
    report = {'task_id': 'P44', 'condition': plan['condition'], 'run_id': plan['run_id'],
        'at_utc': datetime.now(timezone.utc).isoformat(),
        'condition_status': 'complete_under_exact_local_adopted_method' if scores['all_case_complete'] else 'terminal_incomplete_primary_undefined',
        'planned': 64, 'source_human_ranks_inclusive': [77, 140],
        'ordered_case_ids_sha256': plan['ordered_case_ids_sha256'], 'source_released_denominator': 8630,
        'prior_completed_separate_immutable': 76, 'other_source_cases_outside_condition': 8490,
        'model_configuration': plan['model_configuration'], 'dtype': 'bfloat16', 'tensor_parallel_size': 1,
        'solver': completion['solver'], 'judge': completion['judge'],
        'neutral_delivery_gate': {'solver_calls': 2, 'judge_calls': 2, 'artificial_only': True},
        'local_axis_macro_score': scores['local_declared_axis_macro_score'],
        'per_axis_score': scores['per_axis_score'],
        'valid_judgments': scores['valid_judgments'],
        'terminal_failures_and_missing': scores['terminal_failures_and_missing'],
        'valid_only_diagnostics': scores['valid_only_diagnostics'],
        'per_axis_scored_case_count': scores['per_axis_scored_case_count'],
        'per_axis_evidence_absent_count': scores['per_axis_evidence_absent_count'],
        'primary_defined_only_with_full64_valid': True,
        'native_GPT5_1_or_author_cohort_aggregation_reproduced': False,
        'same_checkpoint_self_judging_bias': True, 'independent_human_calibration': False,
        'biological_truth_validation': False, 'prior76_results_pooled_or_modified': False,
        'main_docs_or_shared_aggregate_modified': False,
        'material_differences': plan['material_differences'], **required,
        'runtime_admission_sha256': run.sha(HERE / 'runtime_admission.json'),
        'root_scientific_adoption_sha256': exporter.guard.ADOPTION_SHA,
        'trajectory_archive': paths[2], 'trajectory_manifest': paths[3],
        'source_metadata_sha256': run.sha(DELIVERY / 'license_metadata/PUBLISHER_DATASET_METADATA.json')}
    run.save(ROOT / paths[1], report)
    presentation = score_presentation(scores)
    rows, primary_text, table_label = (presentation[key] for key in ('axis_rows', 'primary_text', 'table_label'))
    text = f'''# BioReason-Pro: human source ranks77–140

Qwen3.8-27B saved {completion['solver']['completed']}/64 completed explanations and {scores['valid_judgments']}/64 valid local judgments for this separately adopted fixed condition. {primary_text}

Solver truncations: {completion['solver']['truncations']}. Truncated outcomes remain invalid in the full64 denominator, receive no replacement or retry, and are not sent for judging. All source-order64 identities remain in the accounting.

These64 proteins follow the earlier separately scored12+64 in original human source order. Earlier76 results remain unchanged and unpooled. Other8490 release entries remain outside this condition; the full release has8630 entries.

| Assessment | {table_label} | Scored cases | Reviewed evidence absent |
|---|---:|---:|---:|
{rows}

The solver received the complete original sequence, organism, InterPro, PPI and fallible GO predictor context. Three empty InterPro and20empty PPI fields were preserved. Curated names/function/GO/localization remained excluded from solver requests. Every solver outcome was sealed before native judge dossiers were used, and each actual saved candidate passed the full unchanged context check with16384 judge output tokens reserved.

Only independently reviewed silence of all relevant evidence permits -1 on the first three axes; missing GO alone does not establish biological absence. Source annotations, nulls and conflicts were retained. Specificity measures detail and utility separately from reliability and does not validate a mechanism.

Both phases used the pinned Qwen3.8-27B BF16 TP1 checkpoint with nonthinking16384-token outputs. This same-model self-judge is uncalibrated and differs from the paper's GPT-5.1/native author cohort and aggregation. These scores do not establish biological truth. Four fresh artificial delivery gates preceded benchmark calls; no selective or ambiguous retries were made.

Source: [BioReason-Pro released test data](https://huggingface.co/datasets/wanglab/bioreason-pro-test-data/tree/a18315a77d27dd4fe5a28b9b757695cff4ba4e3f), revision`a18315a77d27dd4fe5a28b9b757695cff4ba4e3f`; publisher dataset metadata declares Apache-2.0. The archive retains the exact declaration, full license terms and source attribution. [Numerical record]({Path(paths[1]).name}) · [Audited trajectories](../{paths[2]}).
'''
    target = ROOT / paths[0]
    with target.open('x') as stream:
        stream.write(text)
    target.chmod(0o600)
    ready = {'role': 'concrete_four_path_publication_candidate_not_publication_authority',
        **required, 'paths_sha256': {name: run.sha(ROOT / name) for name in paths},
        'planned': 64, 'prior76_modified_or_pooled': False, 'other8490_unchanged': True,
        'primary_defined': scores['all_case_complete'], 'local_axis_macro_score': scores['local_declared_axis_macro_score'],
        'new_model_or_scorer_attempts': 0, 'publication_attempted': False,
        'independent_concrete_byte_privacy_license_publication_review_required': True}
    run.save(DELIVERY / 'publication_ready.json', ready)
    return ready


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--assemble', action='store_true')
    args = parser.parse_args()
    if args.assemble:
        os.umask(0o077)
        print(json.dumps(assemble(), sort_keys=True))
    else:
        print('Disabled default: no native bodies, assembly, publication or model/scorer action.')
