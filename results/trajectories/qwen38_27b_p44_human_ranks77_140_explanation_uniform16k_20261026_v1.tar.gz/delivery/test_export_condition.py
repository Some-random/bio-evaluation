"""Artificial-only postrun whitelist/claim/source/formula comparison fixtures."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

spec = importlib.util.spec_from_file_location('next64_postrun_export_fixture', Path(__file__).with_name('export_condition.py'))
exporter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exporter)


class ExportChecks(unittest.TestCase):
    def test_exact_tree_rejects_extra_empty_directory_and_symlink(self):
        with tempfile.TemporaryDirectory(prefix='P44-artificial-export-tree-') as directory:
            base = Path(directory); (base / 'fixed.json').write_text('{}')
            exporter.exact_tree(base, {'fixed.json'})
            (base / 'extra').mkdir()
            with self.assertRaises(ValueError): exporter.exact_tree(base, {'fixed.json'})
            (base / 'extra').rmdir(); (base / 'link').symlink_to(base / 'fixed.json')
            with self.assertRaises(ValueError): exporter.exact_tree(base, {'fixed.json', 'link'})

    def test_absent_tree_allowed_only_for_exact_empty_membership(self):
        with tempfile.TemporaryDirectory(prefix='P44-artificial-empty-judge-') as directory:
            base = Path(directory) / 'judge'
            exporter.exact_tree(base, set())
            with self.assertRaises(ValueError): exporter.exact_tree(base, {'000/request.json'})
            base.mkdir(); exporter.exact_tree(base, set())
            (base / 'unexpected').mkdir()
            with self.assertRaises(ValueError): exporter.exact_tree(base, set())
            (base / 'unexpected').rmdir(); base.rmdir()
            base.symlink_to(Path(directory) / 'missing-target')
            with self.assertRaises(ValueError): exporter.exact_tree(base, set())

    def test_completed_attempt_requires_exact_HTTP_claim(self):
        with tempfile.TemporaryDirectory(prefix='P44-artificial-completed-attempt-') as directory:
            path = Path(directory); run = exporter.run
            payload = {'model': 'ARTIFICIAL', 'max_tokens': 16384}
            run.save(path / 'request.json', payload)
            run.save(path / 'context_check.json', {'input_tokens': 3, 'output_tokens': 16384, 'input_unchanged': True})
            run.save(path / 'transport_intent.json', {'phase': 'development_solver', 'case_id': 'ARTIFICIAL:EXPORT',
                'request_sha256': run.sha(path / 'request.json')})
            raw = b'{"choices":[{"message":{"content":"4"},"finish_reason":"stop"}]}'
            (path / 'response.body').write_bytes(raw)
            outcome = run.parse_response(raw)
            outcome.update(case_id='ARTIFICIAL:EXPORT', request_sha256=run.sha(path / 'request.json'),
                raw_response_sha256=run.sha(path / 'response.body'), transport_call_returned=True)
            run.save(path / 'outcome.json', outcome)
            claim = {'role': 'one_original_local_HTTP_invocation_about_to_start_not_delivery',
                'phase': 'development_solver', 'case_id': 'ARTIFICIAL:EXPORT',
                'request_sha256': run.sha(path / 'request.json'),
                'transport_intent_sha256': run.sha(path / 'transport_intent.json'),
                'plan_sha256': 'ARTIFICIAL_PLAN', 'runtime_admission_sha256': 'ARTIFICIAL_ADMISSION',
                'automatic_retry': False}
            run.save(path / 'HTTP_send_started.json', claim)
            original_read = run.read
            def read_with_artificial_binding(source):
                if Path(source) == exporter.HERE / 'runtime/runtime_binding.json':
                    return {'plan_sha256': 'ARTIFICIAL_PLAN', 'runtime_admission_sha256': 'ARTIFICIAL_ADMISSION'}
                return original_read(source)
            with mock.patch.object(run, 'read', side_effect=read_with_artificial_binding):
                result = exporter.completed_attempt(path, payload, 'ARTIFICIAL:EXPORT', 'development_solver', 65536)
                self.assertEqual(result['status'], 'completed')
                raw = b'{"choices":[{"message":{"content":"ARTIFICIAL truncated final"},"finish_reason":"length"}]}'
                (path / 'response.body').write_bytes(raw)
                truncated = run.parse_response(raw)
                truncated.update(case_id='ARTIFICIAL:EXPORT', request_sha256=run.sha(path / 'request.json'),
                    raw_response_sha256=run.sha(path / 'response.body'), transport_call_returned=True)
                (path / 'outcome.json').write_text(json.dumps(truncated))
                with self.assertRaisesRegex(ValueError, 'failure class'):
                    exporter.completed_attempt(path, payload, 'ARTIFICIAL:EXPORT', 'development_solver', 65536)
                result = exporter.completed_attempt(path, payload, 'ARTIFICIAL:EXPORT', 'development_solver', 65536,
                    allowed_statuses=('completed', 'truncated'))
                self.assertEqual(result['status'], 'truncated')
                claim['automatic_retry'] = True
                (path / 'HTTP_send_started.json').write_text(json.dumps(claim))
                with self.assertRaisesRegex(ValueError, 'HTTP claim'):
                    exporter.completed_attempt(path, payload, 'ARTIFICIAL:EXPORT', 'development_solver', 65536)

    def test_no_artificial_flag_can_bypass_native_export_authority(self):
        with tempfile.TemporaryDirectory(prefix='P44-artificial-export-gate-') as directory:
            base = Path(directory)
            exporter.run.save(base / 'plan.json', {'output_root': str(base / 'output')})
            with mock.patch.object(exporter.guard, 'bound_runtime') as gate:
                with self.assertRaisesRegex(ValueError, 'artificial-mode bypass'):
                    exporter.audit_closed(base, artificial=True)
            gate.assert_not_called()

    def test_false_source_review_precedes_any_native_audit(self):
        with tempfile.TemporaryDirectory(prefix='P44-artificial-export-review-') as directory:
            base = Path(directory)
            exporter.run.save(base / 'independent_postrun_exporter_source_review.json', {'passed': False})
            with mock.patch.object(exporter, 'DELIVERY', base), mock.patch.object(exporter, 'audit_closed') as audit:
                with self.assertRaisesRegex(ValueError, 'source review'):
                    exporter.export(base, base / 'never-created')
            audit.assert_not_called()
            self.assertFalse((base / 'never-created').exists())

    def test_formula_integrity_comparison_rejects_foreign_identity_and_writes_nothing(self):
        contract = exporter.run.source_modules()[0]
        ids = ['ARTIFICIAL:POSTRUN']
        panel = {'task_id': 'P44', 'role': 'explanation_assessment', 'ordered_case_ids': ids,
            'ordered_ids_sha256': contract.canonical_hash(ids)}
        with self.assertRaisesRegex(ValueError, 'exact adopted next64'):
            exporter.original_formula_integrity_audit(panel, {})
        with mock.patch.object(exporter, 'IDS_SHA256', contract.canonical_hash(ids)):
            result = exporter.original_formula_integrity_audit(panel, {})
        self.assertFalse(result['all_case_complete'])
        self.assertIsNone(result['local_declared_axis_macro_score'])

    def test_publisher_rejects_changed_review_before_any_Git_or_scanner(self):
        source = Path(__file__).with_name('publish_narrow.py')
        spec = importlib.util.spec_from_file_location('next64_artificial_publisher_fixture', source)
        publisher = importlib.util.module_from_spec(spec); spec.loader.exec_module(publisher)
        with tempfile.TemporaryDirectory(prefix='P44-artificial-publisher-review-') as directory:
            base = Path(directory); review = base / 'review.json'; review.write_text('{}')
            with mock.patch.object(publisher, 'DELIVERY', base), mock.patch.object(publisher.run, 'HERE', base), \
                 mock.patch.object(publisher.guard, 'bound_runtime'), mock.patch.object(publisher, 'load') as load:
                with self.assertRaisesRegex(ValueError, 'review hash changed'):
                    publisher.publish(review, '0' * 64)
            load.assert_not_called()
            self.assertFalse((base / 'publication_intent.json').exists())

    def test_dangling_STOP_and_attempt_markers_block_before_loader_or_Git(self):
        source = Path(__file__).with_name('publish_narrow.py')
        spec = importlib.util.spec_from_file_location('next64_artificial_STOP_fixture', source)
        publisher = importlib.util.module_from_spec(spec); spec.loader.exec_module(publisher)
        with tempfile.TemporaryDirectory(prefix='P44-artificial-dangling-STOP-') as directory:
            base = Path(directory)
            for name in ('STOP', 'publication_intent.json', 'publication_receipt.json'):
                with self.subTest(marker=name):
                    marker = base / name; marker.symlink_to(base / 'absent-target')
                    with mock.patch.object(publisher, 'DELIVERY', base), mock.patch.object(publisher.run, 'HERE', base), \
                         mock.patch.object(publisher.guard, 'bound_runtime'), mock.patch.object(publisher, 'load') as load:
                        with self.assertRaises(ValueError):
                            publisher.publish(base / 'never-read-review.json', '0' * 64)
                    load.assert_not_called(); marker.unlink()

    def test_all_five_axes_render_with_undefined_primary_and_nonfunctional_absence_na(self):
        source = Path(__file__).with_name('prepare_publication.py')
        spec = importlib.util.spec_from_file_location('next64_artificial_five_axis_render', source)
        preparation = importlib.util.module_from_spec(spec); spec.loader.exec_module(preparation)
        axes = ('molecular_function', 'biological_process', 'cellular_component', 'specificity', 'reliability')
        scores = {'all_case_complete': False, 'local_declared_axis_macro_score': None, 'per_axis_score': None,
            'valid_only_diagnostics': {'per_axis': dict.fromkeys(axes, 7.25)},
            'per_axis_scored_case_count': dict.fromkeys(axes, 63),
            'per_axis_evidence_absent_count': {'molecular_function': 1, 'biological_process': 0, 'cellular_component': 2}}
        before = json.dumps(scores, sort_keys=True)
        with mock.patch.object(preparation.run, 'read', side_effect=AssertionError('No real body permitted')):
            presentation = preparation.score_presentation(scores)
        self.assertEqual(len(presentation['axis_rows'].splitlines()), 5)
        self.assertIn('Specificity | 7.2500 | 63 | n/a |', presentation['axis_rows'])
        self.assertIn('Reliability | 7.2500 | 63 | n/a |', presentation['axis_rows'])
        self.assertIn('primary score is **undefined**', presentation['primary_text'])
        self.assertEqual(presentation['table_label'], 'Valid-only diagnostic /10')
        self.assertEqual(json.dumps(scores, sort_keys=True), before)


if __name__ == '__main__':
    unittest.main(verbosity=2)
