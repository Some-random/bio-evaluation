"""Publish only four independently reviewed P44 report/archive paths."""
import argparse
import fcntl
import hashlib
import importlib.util
from pathlib import Path
import tempfile
import sys
import os

DELIVERY = Path(__file__).resolve().parent
sys.path.insert(0, str(DELIVERY.parent))
from runner_adapter import load_runner
import runtime_guard as guard
run = load_runner()

ROOT = run.HERE.parents[4]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module); return module


def publish(review_path, review_sha):
    here = run.HERE
    guard.bound_runtime()
    if os.path.lexists(DELIVERY / 'STOP'): raise ValueError('Postrun publication STOP remains active')
    if os.path.lexists(DELIVERY / 'publication_intent.json'): raise ValueError('Preserve actual or ambiguous publication attempt; no automatic replay')
    if os.path.lexists(here / 'publication_receipt.json'): raise ValueError('Preserve immutable publication receipt')
    if run.sha(review_path) != review_sha: raise ValueError('Independent publication review hash changed')
    review = run.read(review_path); ready = run.read(DELIVERY / 'publication_ready.json')
    required_review_pins = {
        str(Path(__file__).resolve()): run.sha(Path(__file__).resolve()),
        str(ROOT / 'scripts/daily_backup.py'): run.sha(ROOT / 'scripts/daily_backup.py'),
        str(ROOT / '.local/litqa2_replay/incremental_upload.py'): run.sha(ROOT / '.local/litqa2_replay/incremental_upload.py'),
        str(DELIVERY / 'publication_ready.json'): run.sha(DELIVERY / 'publication_ready.json'),
        str(here / 'plan.json'): run.sha(here / 'plan.json'),
    }
    if any(review.get('artifact_sha256', {}).get(path) != pin for path, pin in required_review_pins.items()):
        raise ValueError('Independent review must bind publisher/helper/scanner/ready/plan source pins')
    expected = {'reports/P44_HUMAN_RANKS77_140_EXPLANATION_RESULT_2026-10-26.md',
        'reports/P44_HUMAN_RANKS77_140_EXPLANATION_RESULT_2026-10-26.json',
        'results/trajectories/qwen38_27b_p44_human_ranks77_140_explanation_uniform16k_20261026_v1.tar.gz',
        'results/trajectories/qwen38_27b_p44_human_ranks77_140_explanation_uniform16k_20261026_v1.tar.manifest.json'}
    if (review.get('approved_for_publication') is not True or review.get('task_id') != 'P44' or
            review.get('reviewer') not in ('/root/remaining_scope_audit', '/root/independent_review', '/root', '/root/classification_docs_review') or
            review.get('paths_sha256') != ready['paths_sha256'] or set(ready['paths_sha256']) != expected):
        raise ValueError('Exact independent four-path publication approval is required')
    scanner = load('p44_existing_secret_scan', ROOT / 'scripts/daily_backup.py')
    helper = load('p44_existing_publication_helper', ROOT / '.local/litqa2_replay/incremental_upload.py')
    captured = {}
    for name, pin in ready['paths_sha256'].items():
        path = ROOT / name
        if path.is_symlink() or not path.is_file() or path.stat().st_size >= 100 * 1024 * 1024: raise ValueError('Invalid publication source')
        if run.sha(path) != pin: raise ValueError('Reviewed publication source changed')
        scanner.scan_file(path); captured[name] = path.read_bytes()
    guard.bound_runtime()
    if os.path.lexists(DELIVERY / 'STOP'): raise ValueError('Postrun publication revoked before first Git action')
    run.save(DELIVERY / 'publication_intent.json', {'role': 'one_exact_four_path_publication_attempt_not_remote_delivery',
        'at_pacific': run.stamp(), 'review_path': str(review_path), 'review_sha256': review_sha,
        'paths_sha256': ready['paths_sha256'], 'plan_sha256': run.sha(here / 'plan.json'), 'automatic_replay': False})
    with tempfile.TemporaryDirectory(prefix='p44-human64-extension-publication-') as directory:
        checkout = Path(directory)
        def git(*args): return helper.git(*args, cwd=checkout)
        git('init', '--quiet'); git('remote', 'add', 'origin', helper.URL)
        git('config', 'remote.origin.promisor', 'true'); git('config', 'remote.origin.partialclonefilter', 'blob:none')
        git('sparse-checkout', 'init', '--no-cone')
        git('sparse-checkout', 'set', '--no-cone', *('/' + name for name in sorted(expected)))
        with (ROOT / '.local/evaluation_publication.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            destination = helper.confirm_destination()
            if destination['repository'] != 'Some-random/bio-evaluation' or destination['visibility'] != 'public' or destination['push_permission'] is not True:
                raise ValueError('Exact authorized public destination required')
            git('fetch', '--filter=blob:none', '--depth=1', 'origin', 'main')
            before = git('rev-parse', 'FETCH_HEAD').stdout.strip(); git('checkout', '--detach', 'FETCH_HEAD')
            baseline = git('ls-tree', '-r', 'HEAD', '--', *sorted(expected)).stdout
            for name, data in captured.items():
                if (checkout / name).exists() and (checkout / name).read_bytes() != data:
                    raise ValueError('Existing immutable P44 public bytes differ')
                if (ROOT / name).read_bytes() != data: raise ValueError('Publication source changed after capture')
                target = checkout / name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(data)
            git('config', 'user.name', 'Codex'); git('config', 'user.email', 'codex@localhost')
            git('add', '-f', '--sparse', '--', *sorted(expected))
            changes = set(git('diff', '--cached', '--name-only').stdout.splitlines())
            if not changes <= expected: raise ValueError('Unexpected staged publication paths')
            git('diff', '--cached', '--check', '--', *sorted(expected))
            if changes:
                git('commit', '-m', 'Publish P44 human ranks77-140 local explanation evidence')
                for attempt in range(3):
                    guard.bound_runtime()
                    if os.path.lexists(DELIVERY / 'STOP'): raise ValueError('Postrun publication revoked before push')
                    helper.confirm_destination()
                    pushed = helper.git('push', 'origin', 'HEAD:refs/heads/main', cwd=checkout, allow_failure=True)
                    if pushed.returncode == 0: break
                    git('fetch', '--filter=blob:none', 'origin', 'main')
                    if git('ls-tree', '-r', 'FETCH_HEAD', '--', *sorted(expected)).stdout != baseline:
                        raise ValueError('Remote P44 paths changed; stop for review')
                    git('rebase', 'FETCH_HEAD')
                else: raise RuntimeError('Publication push did not complete')
            commit = git('rev-parse', 'HEAD').stdout.strip()
            git('fetch', '--filter=blob:none', 'origin', 'main')
            verified_head = git('rev-parse', 'FETCH_HEAD').stdout.strip()
            for name, data in captured.items():
                # The helper decodes text, so verify all bytes through git directly.
                import subprocess
                raw = subprocess.run(['git', 'show', 'FETCH_HEAD:' + name], cwd=checkout, capture_output=True, check=True).stdout
                if raw != data: raise ValueError('Published bytes do not match reviewed bytes')
            receipt = {'task_id': 'P44', 'stage': 'published_reviewed_human_ranks77_140_condition', 'at_pacific': run.stamp(),
                'commit_sha': commit, 'previous_main_head': before, 'verified_remote_main_head': verified_head,
                'repository': destination['repository'], 'visibility': destination['visibility'], 'remote_bytes_verified': True,
                'paths_sha256': ready['paths_sha256'], 'review_path': str(review_path), 'review_sha256': review_sha,
                'local_axis_macro_score': ready['local_axis_macro_score'], 'planned': 64, 'source_released_denominator': 8630,
                'primary_defined': ready['primary_defined'], 'prior76_modified_or_pooled': False, 'other8490_unchanged': True,
                'full_native_P44_complete': False, 'P28_P29_metrics_changed': False, 'new_inference_calls': 0,
                'weights_or_credentials_published': False, 'website_or_schedules_changed': False,
                'shared_aggregate_reports_changed': False}
            run.save(here / 'publication_receipt.json', receipt)
            print({'published': True, 'commit_sha': commit, 'paths': len(expected), 'remote_bytes_verified': True})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--review', type=Path, required=True); parser.add_argument('--review-sha256', required=True)
    args = parser.parse_args(); publish(args.review, args.review_sha256)
