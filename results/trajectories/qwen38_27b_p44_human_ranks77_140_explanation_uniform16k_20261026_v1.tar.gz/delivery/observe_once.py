"""One read-only observation of this already-submitted allocation.

Never submits, cancels, retries, imports a model or reads per-case request,
response, candidate or reference bodies. Terminal evidence does not infer
successful protocol completion or authorize publication.
"""
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))
from prepare_extension import read, save, sha
import runtime_guard as guard

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
TERMINAL = {'COMPLETED', 'FAILED', 'CANCELLED', 'TIMEOUT', 'OUT_OF_MEMORY', 'NODE_FAIL',
    'PREEMPTED', 'BOOT_FAIL', 'DEADLINE', 'REVOKED', 'SPECIAL_EXIT'}


def terminal_accounting(stdout, return_code, job_id):
    guard.require(return_code == 0, 'Failed accounting remains unknown')
    allocations = []
    for line in stdout.splitlines():
        fields = line.split('|')
        if fields and fields[-1] == '':
            fields.pop()
        if not fields or fields[0] != str(job_id):
            continue
        guard.require(len(fields) == 6, 'Malformed exact-allocation accounting')
        allocations.append([value.strip() for value in fields])
    guard.require(len(allocations) == 1, 'Missing or duplicate exact allocation remains unknown')
    job, name, state, exit_code, resources, workdir = allocations[0]
    state = state.split()[0]
    match = re.search(r'(?:^|,)gres/gpu=(\d+)(?:,|$)', resources)
    guard.require(name == 'bio-p44-next-human64' and workdir == str(ROOT)
        and state in TERMINAL and match is not None and int(match.group(1)) == 1,
        'Exact terminal own job/workdir/one-GPU identity required')
    return {'job_id': job, 'job_name': name, 'state': state, 'exit_code': exit_code,
        'allocation_resources': resources, 'workdir': workdir, 'verified_exact_terminal_allocation': True}


def phase_counts():
    result = {}
    for phase in ('development_solver', 'development_judge', 'solver', 'judge'):
        base = HERE / 'runtime/run_v1' / phase
        result[phase] = {label: len(list(base.glob('*/' + name))) for label, name in (
            ('transport_intents', 'transport_intent.json'), ('HTTP_claims', 'HTTP_send_started.json'),
            ('observed_outcomes', 'outcome.json'))}
    return result


def observe():
    # A renewed STOP does not prevent observing already-issued work. No dispatch
    # authority is acquired here; only exact previously sealed grant metadata is read.
    binding = read(HERE / 'runtime/runtime_binding.json')
    guard.require(binding.get('root_scientific_adoption_sha256') == guard.ADOPTION_SHA,
                  'Exact previously admitted scientific scope required')
    guard.require(sha(HERE / 'plan.json') == binding['plan_sha256']
                  and sha(HERE / 'runtime_admission.json') == binding['runtime_admission_sha256'],
                  'Previously submitted plan/admission metadata changed')
    submission = read(HERE / 'submission_receipt.json'); job = submission.get('job_id')
    guard.require(isinstance(job, str) and re.fullmatch('[0-9]+', job)
                  and submission.get('returncode') == 0
                  and submission.get('plan_sha256') == binding['plan_sha256']
                  and submission.get('runtime_admission_sha256') == binding['runtime_admission_sha256'],
                  'Exact successful sole submission receipt required for observation')
    query = subprocess.run(['squeue', '-h', '-j', job, '-o', '%i|%T|%R'],
        capture_output=True, text=True, timeout=30)
    guard.require(query.returncode == 0, 'Queue observation failed; no termination inferred')
    value = {'role': 'one_read_only_exact_submitted_allocation_observation',
        'at_utc': datetime.now(timezone.utc).isoformat(), 'job_id': job,
        'plan_sha256': binding['plan_sha256'], 'runtime_admission_sha256': binding['runtime_admission_sha256'],
        'squeue_stdout': query.stdout, 'phase_counts': phase_counts(),
        'new_job_model_scorer_retry_or_publication_actions': 0}
    for label, path in (('worker', HERE / 'runtime/status.json'),
                        ('protocol', HERE / 'runtime/run_v1/progress.json'),
                        ('completion', HERE / 'runtime/run_v1/completion.json')):
        if path.is_file():
            value[label] = read(path)
    if not query.stdout.strip():
        accounting = subprocess.run(['sacct', '-j', job, '-n', '-P', '-o',
            'JobIDRaw,JobName%60,State,ExitCode,AllocTRES%200,WorkDir%200'],
            capture_output=True, text=True, timeout=30)
        value['accounting_stdout'] = accounting.stdout
        value['accounting_stderr'] = accounting.stderr
        value['accounting_return_code'] = accounting.returncode
        try:
            terminal = terminal_accounting(accounting.stdout, accounting.returncode, job)
            allocation = read(HERE / 'runtime/allocation_started.json')
            guard.require(allocation['job_id'] == job and allocation['plan_sha256'] == binding['plan_sha256'],
                          'Own startup metadata differs from sole submitted allocation')
            value['terminal'] = terminal
        except (OSError, KeyError, ValueError) as error:
            value['terminal_accounting_unknown'] = {'type': type(error).__name__, 'reason': str(error)}
    name = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ') + '.json'
    save(HERE / 'read_only_observations' / name, value)
    return value


if __name__ == '__main__':
    print(json.dumps(observe(), sort_keys=True))
