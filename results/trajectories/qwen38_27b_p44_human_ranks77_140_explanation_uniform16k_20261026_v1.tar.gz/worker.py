"""Disabled new-scope adapter around the exact accepted TP1 BF16 worker.

Import starts no process and reads no case/reference. Actual main requires exact
independent runtime admission and STOP retirement. Model/server/package/context
behavior is borrowed unchanged; source, scope, ownership and HTTP claim guards
bind it to this separately adopted fixed64.
"""
import argparse
import hashlib
import os
from pathlib import Path
import sys
import types

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from prepare_extension import sha
from runner_adapter import load_runner
import runtime_guard as guard
import resource_authority as resources

OLD_WORKER = HERE.parent / 'wider_human_extension_20261022_v1/worker.py'
OLD_WORKER_SHA = '4bfc8ff5274656789273ba2cbfedf3f8d00388f130a78dcf5fefddbba7deccf8'


def load_worker(plan_sha, admission_sha):
    source = OLD_WORKER.read_bytes()
    guard.require(hashlib.sha256(source).hexdigest() == OLD_WORKER_SHA,
                  'Exact accepted original server/environment/API/checkpoint worker source required')
    runner = load_runner()
    previous = sys.modules.get('p44_runner')
    sys.modules['p44_runner'] = runner
    try:
        worker = types.ModuleType('next64_isolated_exact_original_model_worker')
        # The old code re-execs this adapter after private environment installation.
        worker.__file__ = str(HERE / 'worker.py')
        exec(compile(source, str(OLD_WORKER), 'exec'), worker.__dict__)
    finally:
        if previous is None:
            sys.modules.pop('p44_runner', None)
        else:
            sys.modules['p44_runner'] = previous

    def validate_plan(path, digest):
        guard.require(Path(path).resolve() == HERE / 'plan.json' and digest == plan_sha,
                      'Exact independently admitted next64 plan path/hash required')
        plan, _ = guard.validate_runtime(plan_sha, admission_sha, require_allocation=True)
        return plan

    def validate_admission(path, digest, exact_plan_sha):
        guard.require(Path(path).resolve() == HERE / 'runtime_admission.json'
                      and digest == admission_sha and exact_plan_sha == plan_sha,
                      'Exact independent new64 runtime admission path/hash required')
        _, admission = guard.validate_runtime(plan_sha, admission_sha, require_allocation=True)
        return admission

    original_transport = worker.LocalTransport

    class GuardedLocalTransport(original_transport):
        def send(self, phase, case_id, payload):
            guard.authorize_dispatch(phase, case_id, payload)
            return super().send(phase, case_id, payload)

    worker.validate_plan = validate_plan
    worker.validate_admission = validate_admission
    worker.conservative_gpu_audit = lambda: resources.capacity_audit(additional=0, require_own_job=True)
    worker.LocalTransport = GuardedLocalTransport
    return worker


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--plan', required=True, type=Path)
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--admission', required=True, type=Path)
    parser.add_argument('--admission-sha256', required=True)
    args, _ = parser.parse_known_args()
    os.umask(0o077)
    guard.require(args.plan.resolve() == HERE / 'plan.json'
                  and args.admission.resolve() == HERE / 'runtime_admission.json', 'Exact own next64 paths required')
    guard.validate_runtime(args.plan_sha256, args.admission_sha256, require_allocation=True)
    if '--runtime-dir' in sys.argv:
        # Package installation may take time; refresh own-allocation accounting
        # on the re-exec edge before importing torch or loading model weights.
        resources.capacity_audit(additional=0, require_own_job=True)
    # No importing torch, loading weights, package installation or server startup precedes this gate.
    load_worker(args.plan_sha256, args.admission_sha256).main()


if __name__ == '__main__':
    main()
