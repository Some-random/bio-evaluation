"""Prepare independently admitted P44 packets without model/network access."""
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
CONTRACT = HERE.parent / 'engineering_20261020/explanation_contract.py'
CONTRACT_PIN = '071444944b4c986b60e87318b8db8018ef92138491eadfc6b07ea888f3e40923'
SOURCE = HERE.parent / 'engineering_20261020/source_recovery/released_test.parquet'
SOURCE_PIN = 'f8acd81f3b08400783a34f4189428e4f41fa0c648bc8e4fa58b10ee58bb66828'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_contract():
    if sha(CONTRACT) != CONTRACT_PIN:
        raise ValueError('Previous explanation-assessment contract changed')
    spec = importlib.util.spec_from_file_location('p44_contract', CONTRACT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.write('\n')
    path.chmod(0o600)

def verify_source_projection(selected, contract):
    import pyarrow.dataset as ds
    if sha(SOURCE) != SOURCE_PIN:
        raise ValueError('Pinned release bytes changed')
    ids = [r['protein_id'] for r in selected]
    fields = list(dict.fromkeys(('protein_id', 'protein_names', 'length') + contract.SOLVER_FIELDS + contract.DOSSIER_FIELDS))
    actual = ds.dataset(SOURCE, format='parquet').to_table(columns=fields,
                filter=ds.field('protein_id').isin(ids)).to_pylist()
    actual_by_id = {r['protein_id']: r for r in actual}
    if actual_by_id != {r['protein_id']: r for r in selected}:
        raise ValueError('Selected complete original source fields changed')
    for row in selected:
        seq = row['sequence']
        if (row['organism'] != 'Homo sapiens (Human)' or not isinstance(seq, str)
                or len(seq) != row['length'] or not seq.isupper() or not seq.isalpha()):
            raise ValueError('Reviewed organism or full source sequence integrity failed')

def main():
    contract = load_contract()
    selected = json.loads((HERE / 'review_selected_source_rows.json').read_text())
    verify_source_projection(selected, contract)
    panel = json.loads((HERE / 'panel.json').read_text())
    admission = json.loads((HERE / 'admission.json').read_text())
    ids = contract.validate_panel(panel)
    if ids != [r['protein_id'] for r in selected] or admission['ordered_case_ids'] != ids:
        raise ValueError('Exact reviewed source order changed')
    if admission['source_sha256'] != SOURCE_PIN or admission['selected_source_sha256'] != sha(HERE / 'review_selected_source_rows.json'):
        raise ValueError('Admission/source identity changed')
    if len(ids) != 12 or panel['source_released_denominator'] != 8630:
        raise ValueError('Prospective panel must not masquerade as full release')
    by_id = {r['case_id']: r for r in admission['case_reviews']}
    if set(by_id) != set(ids):
        raise ValueError('Independent case review is incomplete')
    packets = HERE / 'packets'
    packets.mkdir(exist_ok=False)
    (packets / 'solver').mkdir()
    (packets / 'judge_reference').mkdir()
    records = []
    for row in selected:
        case_id = row['protein_id']
        review = by_id[case_id]
        solver = contract.build_solver_packet(panel, case_id, row, review)
        dossier = contract.build_judge_dossier(panel, case_id, row, review, review['axis_evidence'])
        solver_path = packets / 'solver' / (case_id + '.json')
        reference_path = packets / 'judge_reference' / (case_id + '.json')
        save(solver_path, solver)
        save(reference_path, dossier)
        if solver['input']['sequence'] != row['sequence']:
            raise ValueError('Source sequence was cropped or changed')
        if set(solver['input']) != set(contract.SOLVER_FIELDS):
            raise ValueError('Reference leak into solver input')
        if set(dossier['evidence']) != set(contract.DOSSIER_FIELDS):
            raise ValueError('Reference dossier lacks complete evidence fields')
        records.append({'case_id': case_id, 'length': row['length'],
                        'sequence_sha256': hashlib.sha256(row['sequence'].encode()).hexdigest(),
                        'solver_path': str(solver_path.relative_to(HERE)), 'solver_sha256': sha(solver_path),
                        'reference_path': str(reference_path.relative_to(HERE)), 'reference_sha256': sha(reference_path)})
    validation = {'task_id': 'P44', 'passed': True,
        'role': 'real_source_packet_validation_not_model_delivery',
        'source_released_denominator': 8630, 'prepared_prospective_panel': 12,
        'remaining_source_cases_unreviewed': 8618, 'excluded_reviewed_cases': 0,
        'exact_selected_source_projection': True, 'complete_sequences_uncropped': 12,
        'source_order_preserved': True, 'case_admission_separate_from_P28_P29': True,
        'solver_reference_field_isolation_verified': True,
        'full_composite_reference_dossiers': 12,
        'minus_one_requires_all_source_evidence_silent': True,
        'panel_sha256': contract.canonical_hash(panel), 'admission_sha256': sha(HERE / 'admission.json'),
        'source_parquet_sha256': SOURCE_PIN, 'selected_source_sha256': sha(HERE / 'review_selected_source_rows.json'),
        'contract_sha256': sha(CONTRACT), 'per_case': records,
        'packet_bundle_sha256': contract.canonical_hash(records),
        'new_inference_calls': 0, 'judge_calls': 0, 'benchmark_score_computed': False,
        'runtime_admission_granted': False}
    save(HERE / 'packet_validation.json', validation)
    print(json.dumps({key: validation[key] for key in ('passed', 'prepared_prospective_panel', 'complete_sequences_uncropped', 'packet_bundle_sha256')}))

if __name__ == '__main__':
    main()
