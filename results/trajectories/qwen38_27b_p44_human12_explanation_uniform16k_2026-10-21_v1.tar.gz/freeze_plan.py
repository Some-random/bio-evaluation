"""Freeze reviewed P44 human12 interface-panel execution; no calls or jobs."""
from __future__ import annotations
import copy
import json
from pathlib import Path
from p44_runner import HERE, PREP, CONTRACT, JUDGE_INSTRUCTION, JUDGE_RUBRIC, read, save, sha, source_modules, stamp

ROOT = HERE.parents[4]


def main():
    contract, workflow = source_modules(); panel = workflow.validate_prepared_bundle()
    ids = contract.validate_panel(panel)
    if len(ids) != 12 or panel['source_released_denominator'] != 8630: raise ValueError('Exact prepared panel required')
    configuration = {'model': 'Qwen/Qwen3.8-27B', 'revision': '1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0',
        'temperature': 0, 'top_p': 1, 'max_tokens': 16384, 'chat_template_kwargs': {'enable_thinking': False},
        'max_context_tokens': 65536, 'endpoint': 'http://127.0.0.1:8444/v1',
        'configuration_status': 'frozen_pending_exact_root_review', 'automatic_dispatch': False}
    directory = HERE / 'solver_envelopes'; directory.mkdir(exist_ok=False)
    records = []
    for index, case_id in enumerate(ids):
        packet = read(PREP / 'packets/solver' / (case_id + '.json'))
        envelope = workflow.solver_envelope(packet, configuration)
        old = read(PREP / 'prepared_solver_envelopes' / (case_id + '.json'))
        if {k:v for k,v in envelope.items() if k != 'max_tokens'} != {k:v for k,v in old.items() if k != 'max_tokens'}:
            raise ValueError('Original isolated solver request changed beyond prospective output cap')
        path = directory / f'{index:03d}.json'; save(path, envelope)
        records.append({'case_id': case_id, 'path': str(path), 'sha256': sha(path), 'historical_proposed_sha256': sha(PREP / 'prepared_solver_envelopes' / (case_id + '.json'))})
    judge_directory = HERE / 'judge_reference_v2'; judge_directory.mkdir(exist_ok=False)
    source_by_id = {row['protein_id']: row for row in read(PREP / 'review_selected_source_rows.json')}
    for case_id in ids:
        dossier = copy.deepcopy(read(PREP / 'packets/judge_reference' / (case_id + '.json')))
        dossier['evidence']['protein_names'] = source_by_id[case_id]['protein_names']
        save(judge_directory / (case_id + '.json'), dossier)
    manifest = HERE / 'solver_envelopes_manifest.json'
    save(manifest, {'planned': 12, 'envelopes': records, 'complete_original_sequences': True,
        'only_solver_request_change_from_proposed': 'Undispatched output cap4096 to16384 before first dispatch'})
    fixtures = []
    for index, candidate, expected in [(0, 'Fictional object has the recorded binding role, process B and location C.', [8, 10]),
        (1, 'Fictional object has no binding role, never participates in process B, and is absent from location C.', [1, 3])]:
        case_id = 'ARTIFICIAL:' + str(index)
        dossier = {'case_id': case_id, 'evidence': {'protein_function': 'The fictional object has a binding role and participates in process B.',
            'go_mf': 'recorded binding role', 'go_bp': 'process B', 'go_cc': 'location C',
            'interpro_formatted': '', 'ppi_formatted': '', 'organism': 'Imaginary fixture', 'subcellular_location': 'location C'},
            'axis_evidence': {axis: {'all_sources_silent': False, 'reviewed': True} for axis in contract.FUNCTIONAL_AXES},
            'evidence_snapshot_sha256': 'artificial_fixture_only'}
        neutral_panel = {'task_id': 'P44', 'role': 'explanation_assessment', 'ordered_case_ids': [case_id],
            'ordered_ids_sha256': contract.canonical_hash([case_id]), 'evidence_snapshot_sha256': 'artificial_fixture_only'}
        lock = contract.freeze_predictions(neutral_panel, {case_id: {'case_id': case_id, 'status': 'saved', 'generation': candidate}})
        packet = contract.build_judge_packet(neutral_panel, case_id, dossier, lock)
        envelope = {'model': configuration['model'], 'messages': [{'role': 'user', 'content': 'What is 2+2? Reply with only the digit.'}],
            **{key: configuration[key] for key in ('temperature', 'top_p', 'max_tokens', 'chat_template_kwargs')}}
        fixtures.append({'case_id': case_id, 'solver_envelope': envelope, 'expected_solver_final': '4',
            'judge_packet': packet, 'expected_reliability_range': expected})
    neutral = HERE / 'neutral_gate_inputs.json'
    save(neutral, {'cases': fixtures, 'artificial_only': True, 'not_biological_validation': True})
    pool = read(ROOT / '.local/catalog_execution_2026-10-20/continuation_v1/pool_plan.json')
    files = [HERE / name for name in ['p44_runner.py', 'worker.py', 'worker.sbatch', 'test_p44_runner.py', 'freeze_plan.py',
        'independent_scope_review.json', 'rubric_recovery_20261021.json', 'solver_envelopes_manifest.json', 'neutral_gate_inputs.json']]
    files += [CONTRACT, PREP / 'offline_workflow.py', PREP / 'prepare_packets.py', PREP / 'panel.json', PREP / 'admission.json',
        PREP / 'packet_validation.json', PREP / 'review_selected_source_rows.json', PREP / 'tokenizer_preflight.json']
    files += list((PREP / 'packets/solver').glob('*.json')) + list((PREP / 'packets/judge_reference').glob('*.json'))
    files += [Path(row['path']) for row in records] + list(judge_directory.glob('*.json'))
    files += [Path(pool['runtime_common']), ROOT / '.local/litqa2_replay/checkpoint_verification.json',
        ROOT / '.local/litqa2_replay/publisher_verification.json', ROOT / '.local/litqa2_replay/runtime_archive.json',
        ROOT / '.local/litqa2_replay/cuda_overlay_archive.json', ROOT / '.local/litqa2_replay/cuda_overlay_deletions.json',
        ROOT / 'scripts/serve_catalog_20261020.py', ROOT / 'scripts/project_gpu_audit_20261021.py']
    plan = {'created_at_pacific': stamp(), 'task_id': 'P44',
        'condition': 'BIOREASON_PRO_P44_REVIEWED_HUMAN12_QWEN_SOLVER_LOCAL_SELF_JUDGE_UNIFORM16K_V1',
        'execution_scope': 'reviewed_P44_human12_interface_panel', 'planned': 12,
        'source_released_denominator': 8630, 'remaining_release_cases_unreviewed': 8618,
        'run_id': 'qwen38_27b_p44_human12_explanation_uniform16k_2026-10-21_v1',
        'model_configuration': configuration, 'endpoint': configuration['endpoint'],
        'judge_declaration': {'identity': configuration['model'] + '@' + configuration['revision'],
            'rubric_sha256': contract.canonical_hash({'instruction': JUDGE_INSTRUCTION, 'per_axis': JUDGE_RUBRIC}),
            'schema_sha256': contract.canonical_hash(contract.judgment_json_schema()),
            'native_GPT5_1_reproduced': False, 'same_checkpoint_solver_and_judge': True,
            'independent_human_calibration': False, 'strict_JSON_schema_constrained': True},
        'gpus_requested': 1, 'tensor_parallel_size': 1, 'dtype': 'bfloat16', 'total_project_gpu_ceiling': 8,
        'panel': str(PREP / 'panel.json'), 'judge_reference_directory': str(judge_directory),
        'solver_envelope_manifest': str(manifest), 'neutral_gate_inputs': str(neutral), 'output_root': str(HERE / 'runtime/run_v1'),
        'base_runtime': pool['base_runtime'], 'cuda_overlay': pool['cuda_overlay'], 'runtime_common': pool['runtime_common'],
        'checkpoint_audit': str(ROOT / '.local/litqa2_replay/checkpoint_verification.json'),
        'phase_policy': {'neutral_solver_calls': 2, 'neutral_judge_calls': 2, 'solver_attempts_per_case': 1,
            'judge_attempts_per_delivered_case': 1, 'selective_retry': False,
            'stop_new_dispatch_on': ['transport_error', 'http_error', 'response_error', 'refusal'],
            'truncation_policy': 'Retain truncated outcome invalid, continue unchanged untouched cases, no retry',
            'solver_stop_policy': 'Leave full panel accounting; no prediction seal or judge calls after stop',
            'judge_stop_policy': 'Close with all12 denominator and primary undefined for any invalid/missing judgment',
            'intent_without_outcome_policy': 'Unknown delivery and never retryable'},
        'scoring_policy': {'primary': 'Mean of per-axis means, excluding only reviewed justified -1; undefined unless all12 valid',
            'diagnostics': ['valid-only axis macro', 'pooled case-axis mean', 'mean valid case means'],
            'native_author_aggregation_equivalence_claimed': False},
        'material_differences': [
            'First12 independently reviewed human entries are an interface panel, not the full8630 release or certified author cohort.',
            'Pinned local Qwen replaces native GPT-5.1; scores are not numerically interchangeable with the paper.',
            'Same checkpoint solver and judge creates self-judging bias; no independent human validation.',
            'Per-axis rubric reconstructed from recovered official indexed C.3, preserving specificity utility distinct from reliability; original author API payload/schema bytes unavailable.',
            'Raw full sequences plus released predictor context replace native trained ESM3/GOgraph representations.',
            'Prospective16K nonthinking outputs for both stages differ from native judge512 tokens and prior proposed4K/2K.',
            'Judge dossier includes scorer-only protein names from the exact reviewed source rows as C.3 specifies; solver still excludes names.',
            'Q96GE6 released120-residue sequence and out-of-range InterPro coordinates retained without correction.'],
        'native_exact_condition_unavailable_evidence': str(HERE.parent / 'engineering_20261020/paper_contract_recovery.json'),
        'P28_P29_GO_results_reused_or_changed': False, 'runtime_admission_granted': False,
        'new_paid_or_OpenAI_calls': False, 'training': False, 'submission_by_preparation': False,
        'runtime_package_installation': {'official_index': 'https://pypi.org/simple',
            'packages': {'vllm': '0.32.0', 'torch': '2.13.0', 'transformers': '5.17.0', 'triton': '3.7.1', 'flashinfer-python': '0.7.0.post1'},
            'private_prefix': True, 'pip_report_and_check_required': True},
        'frozen_files_sha256': {str(path): sha(path) for path in files}}
    save(HERE / 'plan.json', plan)
    save(HERE / 'admission_NOT_GRANTED_template.json', {'admitted': False, 'task_id': 'P44',
        'scope': 'solver_and_declared_local_judge_reviewed12_once', 'plan_sha256': sha(HERE / 'plan.json'),
        'gpu_count': 1, 'project_gpu_ceiling': 8, 'gpu_audit_receipt': 'ROOT_MUST_SUPPLY_FRESH_AUDIT', 'gpu_audit_receipt_sha256': None})
    save(HERE / 'freeze_receipt.json', {'at_pacific': stamp(), 'plan_sha256': sha(HERE / 'plan.json'),
        'planned': 12, 'source_released_denominator': 8630, 'solver_output_tokens': 16384,
        'judge_output_tokens': 16384, 'model_calls': 0, 'jobs_submitted': 0})
    print(json.dumps(read(HERE / 'freeze_receipt.json')))


if __name__ == '__main__': main()
