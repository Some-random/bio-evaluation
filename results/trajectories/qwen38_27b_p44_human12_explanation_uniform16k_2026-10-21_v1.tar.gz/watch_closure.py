"""Singleton evidence observer; exact terminal accounting precedes local export."""
import fcntl
import json
from pathlib import Path
import re
import subprocess
import sys
import time

import p44_runner as run

TERMINAL = {'COMPLETED', 'FAILED', 'CANCELLED', 'TIMEOUT', 'OUT_OF_MEMORY', 'NODE_FAIL',
    'PREEMPTED', 'BOOT_FAIL', 'DEADLINE', 'REVOKED', 'SPECIAL_EXIT'}


def terminal_accounting(stdout, return_code, job_id, project):
    if return_code != 0: raise ValueError('Failed accounting query remains unknown')
    allocations = []
    for line in stdout.splitlines():
        fields = line.split('|')
        if fields and fields[-1] == '': fields.pop()
        if not fields or fields[0] != str(job_id): continue
        if len(fields) != 6: raise ValueError('Malformed exact-job accounting')
        allocations.append([value.strip() for value in fields])
    if len(allocations) != 1: raise ValueError('Missing/duplicate exact allocation remains unknown')
    job, name, state, exit_code, resources, workdir = allocations[0]
    state = state.split()[0]
    if name != 'bio-p44-qwen-solver-judge' or workdir != str(project): raise ValueError('Accounting allocation identity changed')
    if state not in TERMINAL: raise ValueError('Allocation is not terminal')
    match = re.search(r'(?:^|,)gres/gpu=(\d+)(?:,|$)', resources)
    if not match or int(match.group(1)) != 1: raise ValueError('Exact own one-GPU allocation not established')
    return {'job_id': job, 'job_name': name, 'state': state, 'exit_code': exit_code,
        'allocation_resources': resources, 'workdir': workdir, 'verified_exact_terminal_allocation': True}


def phase_counts(folder):
    result = {}
    for phase in ['development_solver', 'development_judge', 'solver', 'judge']:
        intents = list((folder / phase).glob('*/transport_intent.json'))
        outcomes = list((folder / phase).glob('*/outcome.json'))
        result[phase] = {'transport_intents': len(intents), 'observed_outcomes': len(outcomes),
            'intent_without_outcome': len(intents) - len(outcomes)}
    return result


def main():
    here = run.HERE; monitor = here / 'closure_monitor_v2'; monitor.mkdir(exist_ok=True)
    with (monitor / 'singleton.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        submission = run.read(here / 'submission_receipt.json'); job = submission['job_id']
        if submission['plan_sha256'] != run.sha(here / 'plan.json'): raise ValueError('Submitted plan changed')
        folder = here / 'runtime/run_v1'
        while True:
            query = subprocess.run(['squeue', '-h', '-j', job, '-o', '%i|%T|%R'], capture_output=True, text=True, timeout=30)
            if query.returncode: raise RuntimeError('Queue query failed; no termination or retry inferred')
            state = {'at_pacific': run.stamp(), 'job_id': job, 'slurm_queue': query.stdout.strip(),
                'phase_counts': phase_counts(folder), 'model_calls_by_observer': 0, 'new_jobs_or_retries': 0,
                'user_messages_or_schedules': 0, 'owner': '/root/p44_explanation'}
            for name, path in [('worker', here / 'runtime/status.json'), ('protocol', folder / 'progress.json')]:
                if path.exists(): state[name] = run.read(path)
            run.current(monitor / 'status.json', state)
            if not query.stdout.strip(): break
            time.sleep(30)
        query = subprocess.run(['sacct', '-j', job, '-n', '-P', '-o',
            'JobIDRaw,JobName%60,State,ExitCode,AllocTRES%200,WorkDir%200'], capture_output=True, text=True, timeout=30)
        try:
            terminal = terminal_accounting(query.stdout, query.returncode, job, here.parents[4])
            allocation = run.read(here / 'runtime/allocation_started.json')
            if allocation['job_id'] != job or allocation['plan_sha256'] != submission['plan_sha256']:
                raise ValueError('Own started allocation identity differs from exact submission')
        except (ValueError, OSError, KeyError) as error:
            run.save(monitor / 'terminal_accounting_pending_review.json', {'at_pacific': run.stamp(), 'job_id': job,
                'return_code': query.returncode, 'stdout': query.stdout, 'stderr': query.stderr,
                'error_type': type(error).__name__, 'error': str(error), 'export_performed': False})
            return
        terminal.update(at_pacific=run.stamp(), accounting_return_code=query.returncode,
            accounting_stdout=query.stdout, accounting_stderr=query.stderr, phase_counts=phase_counts(folder))
        run.save(monitor / 'terminal_job_receipt.json', terminal)
        completion = run.read(folder / 'completion.json') if (folder / 'completion.json').exists() else {
            'stage': 'allocation_terminal_before_protocol_completion', 'panel_primary_defined': False}
        if completion.get('panel_primary_defined') is True:
            if (monitor / 'export_intent.json').exists(): raise ValueError('Local export already attempted once')
            output = here / 'public_export_review_v2'
            run.save(monitor / 'export_intent.json', {'at_pacific': run.stamp(), 'output': str(output), 'one_attempt': True,
                'exact_terminal_receipt_sha256': run.sha(monitor / 'terminal_job_receipt.json')})
            result = subprocess.run([sys.executable, str(here / 'export_condition.py'), '--output', str(output)],
                capture_output=True, text=True, timeout=180)
            run.save(monitor / 'export_receipt.json', {'at_pacific': run.stamp(), 'return_code': result.returncode,
                'stdout': result.stdout, 'stderr': result.stderr, 'public_export': str(output), 'git_publication': False})
            if result.returncode: raise RuntimeError('Terminal local export failed; owner review required')
        status = run.read(here.parent / 'status.json'); counts = phase_counts(folder)
        status.update(updated_at_pacific=run.stamp(), runtime_job_id=job, owner='/root/p44_explanation',
            phase_counts=counts, actual_candidate_calls=counts['solver']['observed_outcomes'], actual_judge_calls=counts['judge']['observed_outcomes'],
            actual_neutral_delivery_calls=counts['development_solver']['observed_outcomes'] + counts['development_judge']['observed_outcomes'],
            stage=completion['stage'], terminal_completion=completion,
            next_action='Owner reviews complete terminal evidence and obtains concrete-byte narrow publication review; no retry or new cohort.',
            public_export_review_path=str(here / 'public_export_review_v2') if (here / 'public_export_review_v2').exists() else None)
        run.current(here.parent / 'status.json', status)
        run.current(monitor / 'completion.json', {'at_pacific': run.stamp(), 'job_id': job, 'stage': completion['stage'],
            'new_inference_calls': 0, 'git_publication': False, 'owner_review_required': True})


if __name__ == '__main__': main()
