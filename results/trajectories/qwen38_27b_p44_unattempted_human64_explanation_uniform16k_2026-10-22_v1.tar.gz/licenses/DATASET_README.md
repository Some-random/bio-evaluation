---
license: apache-2.0
language:
- en
tags:
- protein
- gene-ontology
- function-prediction
- biology
- bioinformatics
- evaluation
size_categories:
- 1K<n<10K
dataset_info:
  features:
  - name: protein_id
    dtype: string
  - name: protein_names
    dtype: string
  - name: protein_function
    dtype: string
  - name: organism
    dtype: string
  - name: subcellular_location
    dtype: string
  - name: go_ids
    dtype: string
  - name: go_bp
    dtype: string
  - name: go_mf
    dtype: string
  - name: go_cc
    dtype: string
  - name: sequence
    dtype: string
  - name: length
    dtype: int64
  - name: interpro_ids
    list: string
  - name: interpro_location
    dtype: string
  - name: structure_path
    dtype: string
  - name: interpro_formatted
    dtype: string
  - name: go_pred
    dtype: string
  - name: ppi_formatted
    dtype: string
  splits:
  - name: test
    num_bytes: 42466207
    num_examples: 8630
  download_size: 15543445
  dataset_size: 42466207
configs:
- config_name: default
  data_files:
  - split: test
    path: data/test-*
---

<h1 align="center">
🧬 BioReason-Pro<br>Advancing Protein Function Prediction with<br>Multimodal Biological Reasoning
</h1>

<p align="center">
  <a href="https://www.biorxiv.org/content/10.64898/2026.03.19.712954v1" target="_blank"><img src="https://img.shields.io/badge/bioRxiv-2026.03.19.712954-FF6B6B?style=for-the-badge&logo=arxiv&logoColor=white" alt="bioRxiv"></a>
  <a href="https://github.com/bowang-lab/BioReason-Pro"><img src="https://img.shields.io/badge/GitHub-Code-4A90E2?style=for-the-badge&logo=github&logoColor=white" alt="GitHub"></a>
  <a href="https://bioreason.net"><img src="https://img.shields.io/badge/Website-Online-00B89E?style=for-the-badge&logo=internet-explorer&logoColor=white" alt="Website"></a>
  <a href="https://huggingface.co/collections/wanglab/bioreason-pro"><img src="https://img.shields.io/badge/HuggingFace-Models & Data-FFBF00?style=for-the-badge&logo=huggingface&logoColor=white" alt="HuggingFace"></a>
</p>

<br>

## BioReason-Pro Test Data

Evaluation dataset for BioReason-Pro. Contains proteins with GO term annotations, GO-GPT predictions, InterPro domains, STRING protein-protein interactions, and protein metadata. Temporal holdout follows the CAFA framework.


## Citation

If you find this work useful, please cite our papers:

```bibtex
@article {Fallahpour2026.03.19.712954,
    author = {Fallahpour, Adibvafa and Seyed-Ahmadi, Arman and Idehpour, Parsa and Ibrahim, Omar and Gupta, Purav and Naimer, Jack and Zhu, Kevin and Shah, Arnav and Ma, Shihao and Adduri, Abhinav and G{\"u}loglu, Talu and Liu, Nuo and Cui, Haotian and Jain, Arihant and de Castro, Max and Fallahpour, Amirfaham and Cembellin-Prieto, Antonio and Stiles, John S. and Nem{\v c}ko, Filip and Nevue, Alexander A. and Moon, Hyungseok C. and Sosnick, Lucas and Markham, Olivia and Duan, Haonan and Lee, Michelle Y. Y. and Salvador, Andrea F. M. and Maddison, Chris J. and Thaiss, Christoph A. and Ricci-Tam, Chiara and Plosky, Brian S. and Burke, Dave P. and Hsu, Patrick D. and Goodarzi, Hani and Wang, Bo},
    title = {BioReason-Pro: Advancing Protein Function Prediction with Multimodal Biological Reasoning},
    elocation-id = {2026.03.19.712954},
    year = {2026},
    doi = {10.64898/2026.03.19.712954},
    publisher = {Cold Spring Harbor Laboratory},
    URL = {https://www.biorxiv.org/content/early/2026/03/20/2026.03.19.712954},
    eprint = {https://www.biorxiv.org/content/early/2026/03/20/2026.03.19.712954.full.pdf},
    journal = {bioRxiv}
}

@misc{fallahpour2025bioreasonincentivizingmultimodalbiological,
      title={BioReason: Incentivizing Multimodal Biological Reasoning within a DNA-LLM Model}, 
      author={Adibvafa Fallahpour and Andrew Magnuson and Purav Gupta and Shihao Ma and Jack Naimer and Arnav Shah and Haonan Duan and Omar Ibrahim and Hani Goodarzi and Chris J. Maddison and Bo Wang},
      year={2025},
      eprint={2505.23579},
      archivePrefix={arXiv},
      primaryClass={cs.LG},
      url={https://arxiv.org/abs/2505.23579}, 
}
```
