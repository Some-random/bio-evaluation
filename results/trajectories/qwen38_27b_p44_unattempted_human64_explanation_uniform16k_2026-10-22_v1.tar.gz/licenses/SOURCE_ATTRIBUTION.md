# Source attribution and changes

Dataset: Wang Lab, **BioReason-Pro Test Data**, `wanglab/bioreason-pro-test-data`, pinned revision `a18315a77d27dd4fe5a28b9b757695cff4ba4e3f`. Source: https://huggingface.co/datasets/wanglab/bioreason-pro-test-data/tree/a18315a77d27dd4fe5a28b9b757695cff4ba4e3f . The publisher dataset card declares Apache-2.0. The complete pinned dataset README, its citations and the complete Apache License 2.0 are retained in this archive.

Upstream software: **bowang-lab/BioReason-Pro**, pinned tree `a93ac2a96387103c100c4d6a6674d6fe1dfaf9e8`. Source: https://github.com/bowang-lab/BioReason-Pro/tree/a93ac2a96387103c100c4d6a6674d6fe1dfaf9e8 . Its complete MIT license, including the original copyright notice, is retained verbatim.

This evaluation covers a separately reviewed 64-case human-protein extension. Earlier 12-case outputs are preserved separately. Our local request packaging, runtime controls, output validation and declared axis-macro aggregation are adaptations. The fixed local Qwen3.8-27B judge replaces the authors' GPT-5.1 judge; the same checkpoint solves and judges. This does not reproduce the complete author evaluation or experimentally validate predicted mechanisms. The numerical report documents these changes; no upstream endorsement is implied.

All original annotations, source metadata and applicable notices included in the approved source subset are retained. No unreviewed release entries, model weights, private resource-proof bodies or credentials are included.
