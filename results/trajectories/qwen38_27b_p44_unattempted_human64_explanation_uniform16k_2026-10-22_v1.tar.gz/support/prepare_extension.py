"""Prepare an unattempted, independently reviewed P44 extension; no transport.

The first 64 human entries after the old, immutable 12 are selected in source
order before any new model output. The remaining candidates are not admitted.
"""
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
CONTRACT = TASK / 'engineering_20261020/explanation_contract.py'
CONTRACT_SHA256 = '071444944b4c986b60e87318b8db8018ef92138491eadfc6b07ea888f3e40923'
SOURCE_SHA256 = 'f8acd81f3b08400783a34f4189428e4f41fa0c648bc8e4fa58b10ee58bb66828'
PROJECTION_SHA256 = '6ee86cd0ab790018ad15f2ceebf34e2ff0649086d69c51622695f6368d024b06'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text())
def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write('\n')
    path.chmod(0o600)
def load_contract():
    if sha(CONTRACT) != CONTRACT_SHA256: raise ValueError('Original contract changed')
    spec = importlib.util.spec_from_file_location('p44_extension_contract', CONTRACT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def select():
    projection = HERE / 'candidate_rows_private.json'
    if sha(projection) != PROJECTION_SHA256: raise ValueError('Exact human projection changed')
    rows = read(projection)[:64]
    old = set(read(TASK / 'real_input_preparation_v1/panel.json')['ordered_case_ids'])
    ids = [row['protein_id'] for row in rows]
    if len(ids) != 64 or len(set(ids)) != 64 or set(ids) & old:
        raise ValueError('Fixed extension overlaps or denominator changed')
    for row in rows:
        if row['organism'] != 'Homo sapiens (Human)': raise ValueError('Foreign organism')
        sequence = row['sequence']
        if not isinstance(sequence, str) or len(sequence) != row['length'] or not sequence.isupper() or not sequence.isalpha():
            raise ValueError('Full original sequence integrity failed')
    return rows

def main():
    contract = load_contract()
    prep = HERE / 'preparation'
    if not prep.exists():
        prep.mkdir()
        rows = select()
        save(prep / 'review_selected_source_rows.json', rows)
        ids = [row['protein_id'] for row in rows]
        panel = {'task_id': 'P44', 'role': 'explanation_assessment',
            'condition_id': 'BIOREASON_PRO_P44_UNATTEMPTED_HUMAN64_LOCAL_SELF_JUDGE_UNIFORM16K_V1',
            'ordered_case_ids': ids, 'ordered_ids_sha256': contract.canonical_hash(ids),
            'source_released_denominator': 8630,
            'source_revision': 'a18315a77d27dd4fe5a28b9b757695cff4ba4e3f',
            'source_parquet_sha256': SOURCE_SHA256,
            'evidence_snapshot_sha256': sha(prep / 'review_selected_source_rows.json'),
            'selection': 'First64 previously unattempted exact human entries in original release order; original12 excluded before outputs.',
            'native_author_judged_panel_reproduced': False,
            'old12_condition_modified': False, 'P28_P29_eligibility_or_exclusion_inherited': False,
            'training': False, 'runtime_admission_granted': False}
        save(prep / 'panel.json', panel)
        print('Fixed64 selection written; await independent actual input review.')
        return
    rows = select()
    if rows != read(prep / 'review_selected_source_rows.json'): raise ValueError('Selected source rows changed')
    panel = read(prep / 'panel.json')
    review = read(HERE / 'independent_scope_review.json')
    ids = contract.validate_panel(panel)
    if review.get('admitted_ordered_case_ids') != ids or review.get('admitted') is not True:
        raise ValueError('All exact64 require independent admission; revise prospectively if any deferred')
    if review.get('selected_rows_sha256') != sha(prep / 'review_selected_source_rows.json'):
        raise ValueError('Independent actual input source identity mismatch')
    by_id = {r['case_id']: r for r in review['case_reviews']}
    records = []
    for row in rows:
        case_id = row['protein_id']
        decision = by_id[case_id]
        if decision.get('status') != 'independently_reviewed_permitted' or decision.get('held_or_interrupted_scope') is not False:
            raise ValueError('A deferred or interrupted input cannot be packaged')
        admission = {'task_id': 'P44', 'case_id': case_id,
            'status': 'independently_reviewed_permitted', 'held_or_interrupted_scope': False,
            'panel_sha256': contract.canonical_hash(panel)}
        solver = contract.build_solver_packet(panel, case_id, row, admission)
        dossier = contract.build_judge_dossier(panel, case_id, row, admission, decision['axis_evidence'])
        dossier['evidence']['protein_names'] = row['protein_names']
        solver_path = prep / 'packets/solver' / (case_id + '.json')
        reference_path = prep / 'packets/judge_reference' / (case_id + '.json')
        save(solver_path, solver)
        save(reference_path, dossier)
        if set(solver['input']) != set(contract.SOLVER_FIELDS) or solver['input']['sequence'] != row['sequence']:
            raise ValueError('Source field isolation/full-sequence preservation failed')
        records.append({'case_id': case_id, 'length': row['length'],
            'source_row_sha256': contract.canonical_hash(row),
            'sequence_sha256': hashlib.sha256(row['sequence'].encode()).hexdigest(),
            'solver_path': str(solver_path.relative_to(prep)), 'solver_sha256': sha(solver_path),
            'reference_path': str(reference_path.relative_to(prep)), 'reference_sha256': sha(reference_path)})
    save(prep / 'admission.json', review)
    save(prep / 'packet_validation.json', {'task_id': 'P44', 'passed': True,
        'role': 'actual_source_packet_validation_not_model_delivery', 'planned': 64,
        'source_released_denominator': 8630, 'old12_untouched': True,
        'independent_review_sha256': sha(HERE / 'independent_scope_review.json'),
        'panel_sha256': contract.canonical_hash(panel), 'admission_sha256': sha(prep / 'admission.json'),
        'complete_sequences_uncropped': 64, 'source_order_preserved': True,
        'solver_reference_field_isolation_verified': True, 'per_case': records,
        'source_sha256': SOURCE_SHA256, 'new_inference_calls': 0})

if __name__ == '__main__': main()
