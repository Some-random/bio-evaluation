# BioReason-Pro: unattempted human64 extension

This is a separately scored local Qwen3.8-27B solver/self-judge condition on the first 64 previously unattempted human release entries, selected in original source order. The earlier completed 12 condition is immutable and is not pooled into this result. The complete release contains 8,630 entries; this extension does not reproduce the author's judged cohort or GPT-5.1 judge.

The solver receives only original full amino-acid sequences, organism, released InterPro/PPI context and fallible GO-predictor annotations. Reference protein names, curated function/GO and location are not included in solver requests. Integrity hashing of reference files occurs before dispatch; actual reference dossier parsing and judge prompt construction occur only after all solver outcomes are sealed.

Both stages use the previously declared nonthinking 16K Qwen condition and the final recovered C.3-derived local rubric/schema. Candidate and judge attempts occur once; invalid and ambiguous responses are retained. The primary axis-macro 1–10 score is undefined if required valid outcomes are missing. It is an uncalibrated same-model judging assessment, not validation of biological mechanisms.

Source: wanglab/bioreason-pro-test-data revision a18315a77d27dd4fe5a28b9b757695cff4ba4e3f, publisher dataset metadata declares Apache-2.0. Exact full source rows remain preserved locally; attribution and source identity must accompany any permitted public export. Complete context/source-coordinate discrepancies and reviewed evidence silences remain unchanged.

No GPU/model call follows from preparation. Exact root scientific adoption, independent technical/engineering admission, CPU tokenization and actual artificial delivery gates precede benchmark dispatch. A bounded one-condition capacity waiter yields to admitted ready comparison work and uses the shared eight-GPU accounting lock; it never retries actual or uncertain submission.
