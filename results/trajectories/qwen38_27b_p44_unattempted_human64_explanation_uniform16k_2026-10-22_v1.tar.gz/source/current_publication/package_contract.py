"""Exact CPU-only P44 package/provenance checks; no dispatch or score attempt."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import tarfile

HERE = Path(__file__).resolve().parent
RESTORE = HERE.parent
OLD = RESTORE.parent / 'wider_human_extension_20261022_v1'
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
REPOSITORY = 'Some-random/bio-evaluation'
URL = 'https://github.com/' + REPOSITORY + '.git'
EXPORT_AUTHOR = '/root/priority_runtime_review'
PAIR_ID = 'qwen38_27b_p44_unattempted_human64_explanation_uniform16k_2026-10-22_v1'
PLAN_SHA = '1557688bcb161bc803357f4d10a875ae7c1d7a7bc3195d420e8abf3821d947ee'
AUTH_SHA = 'bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
MAX_GIT_BYTES = 90 * 1024**2
REPORT = 'reports/P44_HUMAN64_EXTENSION_EXPLANATION_RESULT_2026-10-22.md'
ARCHIVE = 'results/trajectories/' + PAIR_ID + '.tar.gz'
ALLOWED = frozenset((REPORT, REPORT[:-3] + '.json', ARCHIVE, ARCHIVE[:-7] + '.tar.manifest.json'))
GIT_HELPER = ROOT / '.local/litqa2_replay/incremental_upload.py'
CREDENTIAL_HELPER = ROOT / '.local/litqa2_replay/github_credential_helper.py'
DESTINATION_POLICY = ROOT / 'scripts/publication_destination.py'
SCANNER = ROOT / 'scripts/daily_backup.py'
COMMON = ROOT / '.local/qwen35_4b_comparison_20261022/protein_properties/scalar_delivery_development_v3/restore_20261024_v1/publication/bundle_common.py'
COMMON_SHA = '6839105aadf3d6377e631998952430b62248f62c79aaa5d333d5faa4df734f41'
if COMMON.is_symlink() or hashlib.sha256(COMMON.read_bytes()).hexdigest() != COMMON_SHA:
    raise ValueError('Previously independently reviewed filesystem primitive source changed')
_spec = importlib.util.spec_from_file_location('p44_pinned_filesystem_primitives', COMMON)
_fs = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_fs)
for _name in ('stamp', 'sha', 'digest', 'read', 'regular_bytes', 'regular_descriptor', 'write_bytes',
              'write_json', 'load', 'safe_name', 'write_checkout_file'):
    globals()[_name] = getattr(_fs, _name)

LICENSE_FILES = ('DATASET_LICENSE_APACHE_2_0.txt', 'CODE_LICENSE_MIT.txt', 'DATASET_README.md', 'SOURCE_ATTRIBUTION.md')

PUBLIC_OPERATIONAL = ('resource_authority.py', 'capacity_waiter.py', 'worker.py', 'worker.sbatch',
    'amendment.json', 'root_priority_release.json', 'independent_source_runtime_review.json',
    'independent_resource_admission.json', 'STOP_clearance_receipt.json')


def source_check():
    c = read(HERE / 'config.json')
    if (c.get('role') != 'P44_current_restoration_CPU_package_source_configuration'
            or c.get('job_id') != '249561' or c.get('root_authorization_sha256') != AUTH_SHA
            or set(c.get('allowed_paths', [])) != ALLOWED
            or c.get('original_plan_sha256') != PLAN_SHA
            or c.get('public_operational_files') != list(PUBLIC_OPERATIONAL)
            or c.get('license_files') != list(LICENSE_FILES)):
        raise ValueError('Exact unchanged P44 scope and current restoration are required')
    for path, digest in c['files_sha256'].items():
        if sha(path) != digest:
            raise ValueError('Frozen package/support source changed')
    review = read(HERE / 'independent_source_review.json')
    if (review.get('approved') is not True or review.get('reviewer') not in {'/root', '/root/independent_review'}
            or review.get('role') != 'independent_P44_restored_publication_source_review'
            or review.get('config_sha256') != sha(HERE / 'config.json')
            or review.get('files_sha256') != c['files_sha256']):
        raise PermissionError('Exact independent source admission required')
    return c


def provenance():
    c = source_check()
    receipt = read(OLD / 'submission_receipt.json')
    terminal = read(OLD / 'closure_monitor_v2/terminal_job_receipt.json')
    if (receipt.get('job_id') != c['job_id'] or receipt.get('returncode') != 0
            or receipt.get('plan_sha256') != PLAN_SHA
            or terminal.get('job_id') != c['job_id']
            or terminal.get('verified_exact_terminal_allocation') is not True
            or terminal.get('state') != 'COMPLETED' or terminal.get('exit_code') != '0:0'):
        raise ValueError('Actual successful exact P44 terminal allocation required')
    recovery_root = RESTORE / 'export_recovery_v1'
    recovery = read(recovery_root / 'completed.json')
    if (recovery.get('job_id') != c['job_id'] or recovery.get('planned') != 64
            or recovery.get('config_sha256') != sha(recovery_root / 'config.json')
            or recovery.get('output_root') != str(OLD / 'public_export_review_v3')
            or recovery.get('export_manifest_sha256') != sha(OLD / 'public_export_review_v3/export_member_manifest.json')
            or recovery.get('model_calls') != 0 or recovery.get('new_score_attempts') != 0
            or recovery.get('old_partial_snapshot_sha256') != '13e4fba0400047516de4d009adae4d00c5a20db2eb88a308c80cf54c3d28c8a5'
            or recovery.get('independent_recovery_admission_sha256') != sha(recovery_root / 'independent_recovery_admission.json')):
        raise ValueError('Exact completed source-bound CPU export recovery required')
    return {'job_id': c['job_id'], 'scheduler_state': terminal['state'],
        'scheduler_exit_code': terminal['exit_code'], 'science_changed': False,
        'root_authorization_sha256': AUTH_SHA,
        'restoration_amendment_sha256': sha(RESTORE / 'amendment.json'),
        'restoration_admission_sha256': sha(RESTORE / 'independent_resource_admission.json'),
        'priority_release_sha256': sha(RESTORE / 'root_priority_release.json'),
        'STOP_clearance_receipt_sha256': sha(RESTORE / 'STOP_clearance_receipt.json'),
        'submission_receipt_sha256': sha(OLD / 'submission_receipt.json'),
        'runtime_admission_sha256': sha(OLD / 'runtime_admission.json'),
        'terminal_receipt_sha256': sha(OLD / 'closure_monitor_v2/terminal_job_receipt.json'),
        'CPU_export_recovery_config_sha256': sha(recovery_root / 'config.json'),
        'CPU_export_recovery_admission_sha256': sha(recovery_root / 'independent_recovery_admission.json'),
        'CPU_export_recovery_completion_sha256': sha(recovery_root / 'completed.json'),
        'recovered_v3_export_manifest_sha256': recovery['export_manifest_sha256'],
        'old_partial_export_preserved': True,
        'current_shared_resource_binding_sha256': 'cb881370f7dac295d7d153f72baddcbf604c0fce0cc651ee82c557e5efcad6f9',
        'scheduling_restore_only': True, 'private_resource_proof_bodies_packaged': False,
        'full_8630_release_completed': False, 'prior12_pooled': False,
        'no_model_or_score_attempt_by_packager': True}


def before_package():
    source_check()
    provenance()
    if os.path.lexists(HERE / 'STOP'):
        raise PermissionError('Publication-specific STOP present')
    if any(os.path.lexists(HERE / name) for name in ('stage', 'manifest.json', 'package_attempt.json')):
        raise FileExistsError('Preserve earlier package attempt without replay')
    write_json(HERE / 'package_attempt.json', {'at_pacific': stamp(), 'one_attempt': True,
        'config_sha256': sha(HERE / 'config.json'), 'job_id': '249561', 'model_calls': 0,
        'scoring_attempts': 0})


def operational_members():
    source_check()
    result = {'operational_restore/' + name: RESTORE / name for name in PUBLIC_OPERATIONAL}
    result.update({'licenses/' + name: HERE / 'license_sources' / name for name in LICENSE_FILES})
    for name in ('recover.py', 'config.json', 'independent_recovery_admission.json', 'completed.json'):
        result['operational_restore/CPU_export_recovery/' + name] = RESTORE / 'export_recovery_v1' / name
    for name in ('prepare_package.py', 'package_contract.py', 'publish_once.py'):
        result['source/current_publication/' + name] = HERE / name
    path = HERE / 'public_operational_provenance.json'
    write_json(path, provenance())
    result['support/current_operational_provenance.json'] = path
    return result


def expected_members():
    # Existing audit validates saved candidate/judge bytes and the already
    # persisted score; it creates no score attempt or model call.
    import sys
    sys.path.insert(0, str(OLD))
    import export_condition
    _, _, _, sources = export_condition.audit_closed(OLD)
    sources = dict(sources)
    sources['export_member_manifest.json'] = OLD / 'public_export_review_v3/export_member_manifest.json'
    sources['support/publisher_dataset_metadata.json'] = OLD.parent / 'engineering_20261020/source_recovery/hf_test_repo.json'
    sources.update({'operational_restore/' + name: RESTORE / name for name in PUBLIC_OPERATIONAL})
    sources.update({'licenses/' + name: HERE / 'license_sources' / name for name in LICENSE_FILES})
    for name in ('recover.py', 'config.json', 'independent_recovery_admission.json', 'completed.json'):
        sources['operational_restore/CPU_export_recovery/' + name] = RESTORE / 'export_recovery_v1' / name
    sources.update({'source/current_publication/' + name: HERE / name
                    for name in ('prepare_package.py', 'package_contract.py', 'publish_once.py')})
    sources['support/current_operational_provenance.json'] = HERE / 'public_operational_provenance.json'
    return {name: {'sha256': sha(path), 'bytes': len(regular_bytes(path))}
            for name, path in sources.items()}


def check_archive(path, expected, scanner):
    observed = {}
    with tarfile.open(path, 'r:gz') as stream:
        for item in stream:
            safe_name(item.name)
            if not item.isfile() or item.name in observed:
                raise ValueError('Only unique regular archive members allowed')
            data = stream.extractfile(item).read()
            scanner.scan_bytes(data)
            if item.name.endswith('.json'):
                _fs.check_json_privacy(_fs.loads(data))
            observed[item.name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    if observed != expected:
        raise ValueError('Archive members differ from exact audited source/copy hashes')


def finalize(ready):
    c = source_check()
    if set(ready['paths_sha256']) != ALLOWED or ready['operational_restoration'] != provenance():
        raise ValueError('Exact four paths/current operational provenance required')
    manifest = {'task_id': 'P44', 'repository': REPOSITORY, 'visibility': 'public',
        'at_pacific': stamp(), 'files_sha256': ready['paths_sha256'],
        'config_sha256': sha(HERE / 'config.json'), 'source_files_sha256': c['files_sha256'],
        'root_authorization_sha256': AUTH_SHA, 'original_plan_sha256': PLAN_SHA,
        'operational_restoration': provenance(), 'ready_sha256': sha(HERE / 'publication_ready.json'),
        'score_sha256': sha(OLD / 'runtime/run_v1/scores.json'), 'planned': 64,
        'whole_release_complete': False, 'prior12_pooled': False, 'new_model_calls': 0,
        'new_score_attempts': 0, 'shared_aggregate_documents_modified': False}
    write_json(HERE / 'manifest.json', manifest)
    check(HERE / 'manifest.json', sha(HERE / 'manifest.json'))


def check(path, digest):
    if sha(path) != digest:
        raise ValueError('Concrete package manifest changed')
    c = source_check(); m = read(path)
    if (m.get('task_id') != 'P44' or m.get('repository') != REPOSITORY
            or m.get('visibility') != 'public' or set(m['files_sha256']) != ALLOWED
            or m.get('config_sha256') != sha(HERE / 'config.json')
            or m.get('source_files_sha256') != c['files_sha256']
            or m.get('root_authorization_sha256') != AUTH_SHA
            or m.get('original_plan_sha256') != PLAN_SHA
            or m.get('operational_restoration') != provenance()
            or m.get('whole_release_complete') is not False or m.get('prior12_pooled') is not False
            or m.get('new_model_calls') != 0 or m.get('new_score_attempts') != 0
            or m.get('planned') != 64 or m.get('shared_aggregate_documents_modified') is not False):
        raise ValueError('Exact restored human64 adaptation package required')
    if sha(HERE / 'publication_ready.json') != m['ready_sha256']:
        raise ValueError('Concrete ready record changed')
    scanner = load('p44_current_package_scanner', SCANNER)
    for name, pin in m['files_sha256'].items():
        safe_name(name); path = HERE / 'stage' / name
        data = regular_bytes(path)
        if hashlib.sha256(data).hexdigest() != pin or len(data) >= MAX_GIT_BYTES:
            raise ValueError('Reviewed stage bytes changed or exceed fixed blob bound')
        scanner.scan_file(path)
    meta = read(HERE / 'stage' / (ARCHIVE[:-7] + '.tar.manifest.json'))
    expected = expected_members()
    if meta['members'] != expected:
        raise ValueError('Archive manifest differs from current exact audited source whitelist')
    check_archive(HERE / 'stage' / ARCHIVE, expected, scanner)
    if meta['archive_sha256'] != m['files_sha256'][ARCHIVE]:
        raise ValueError('Archive manifest pin changed')
    report = read(HERE / 'stage' / (REPORT[:-3] + '.json'))
    if (report['score_sha256'] != m['score_sha256']
            or sha(OLD / 'runtime/run_v1/scores.json') != m['score_sha256']
            or report['operational_restoration'] != provenance()
            or report['prior12_results_pooled'] is not False
            or report['full_native_author_evaluation_reproduced'] is not False
            or report['native_GPT5_1_judge_reproduced'] is not False
            or report['same_checkpoint_self_judging_bias'] is not True):
        raise ValueError('Score/current provenance or material qualification changed')
    source_check()
    return m
