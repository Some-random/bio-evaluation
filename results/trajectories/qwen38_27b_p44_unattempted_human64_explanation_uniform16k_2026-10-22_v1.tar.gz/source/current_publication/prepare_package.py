"""Prepare four concrete result/trajectory files after exact terminal auditing.

No model, scheduler or Git calls. Public upload still needs independent review
of the completed bytes and the separately pinned narrow publisher.
"""
import json
from pathlib import Path
import tarfile
import sys
CURRENT = Path(__file__).resolve().parent
sys.path.insert(0, str(CURRENT.parent.parent / 'wider_human_extension_20261022_v1'))
import package_contract as contract
import export_condition
import p44_runner as run

ROOT = CURRENT / 'stage'
STEM = 'P44_HUMAN64_EXTENSION_EXPLANATION_RESULT_2026-10-22'

def main():
    contract.before_package()
    here = run.HERE
    plan, scores, completion, audited_members = export_condition.audit_closed(here)
    if not scores['all_case_complete'] or scores['planned'] != 64:
        raise ValueError('Incomplete condition needs a separately reviewed failure report')
    export = here / 'public_export_review_v3'
    manifest = run.read(export / 'export_member_manifest.json')
    if set(manifest['members']) != set(audited_members):
        raise ValueError('Export manifest must match the current audited source whitelist exactly')
    expected = set(manifest['members']) | {'export_member_manifest.json'}
    export_condition.exact_tree(export, expected)
    for name, record in manifest['members'].items():
        source = audited_members[name]
        if (record['sha256'] != run.sha(source) or record['bytes'] != source.stat().st_size or
                run.sha(export / name) != record['sha256'] or (export / name).stat().st_size != record['bytes']):
            raise ValueError('Export manifest/source/copy bytes differ from the current audited member')
    source_card = here.parent / 'engineering_20261020/source_recovery/hf_test_repo.json'
    card = run.read(source_card)
    if (card.get('id') != 'wanglab/bioreason-pro-test-data' or
            card.get('sha') != 'a18315a77d27dd4fe5a28b9b757695cff4ba4e3f' or
            card.get('cardData', {}).get('license') != 'apache-2.0'):
        raise ValueError('Pinned publisher source/license metadata required')
    archive_members = {name: export / name for name in expected}
    archive_members['support/publisher_dataset_metadata.json'] = source_card
    archive_members.update(contract.operational_members())
    run_id = plan['run_id']
    archive_name = 'results/trajectories/' + run_id + '.tar.gz'
    archive = ROOT / archive_name
    archive.parent.mkdir(parents=True, exist_ok=True)
    if archive.exists(): raise ValueError('Preserve existing immutable trajectory archive')
    with tarfile.open(archive, 'x:gz') as stream:
        for name, source in sorted(archive_members.items()): stream.add(source, arcname=name, recursive=False)
    archive_manifest_name = 'results/trajectories/' + run_id + '.tar.manifest.json'
    run.save(ROOT / archive_manifest_name, {'task_id': 'P44', 'condition': plan['condition'],
        'run_id': run_id, 'archive_sha256': run.sha(archive), 'archive_bytes': archive.stat().st_size,
        'members': {name: {'sha256': run.sha(source), 'bytes': source.stat().st_size} for name, source in sorted(archive_members.items())},
        'source': {'publisher': 'wanglab', 'dataset': 'bioreason-pro-test-data',
            'revision': 'a18315a77d27dd4fe5a28b9b757695cff4ba4e3f',
            'url': 'https://huggingface.co/datasets/wanglab/bioreason-pro-test-data',
            'publisher_metadata_license': 'apache-2.0'},
        'prior12_condition_modified': False, 'whole_release_completed': False})
    report = {'task_id': 'P44', 'condition': plan['condition'], 'at_pacific': run.stamp(),
        'model': plan['model_configuration'], 'planned': 64, 'source_released_denominator': 8630,
        'coverage': 'First64 previously unattempted human entries in original release order, separate from immutable earlier12.',
        'solver': completion['solver'], 'judge': completion['judge'],
        'local_axis_macro_score': scores['local_declared_axis_macro_score'],
        'per_axis_score': scores['per_axis_score'],
        'per_axis_scored_case_count': scores['per_axis_scored_case_count'],
        'per_axis_evidence_absent_count': scores['per_axis_evidence_absent_count'],
        'full_native_author_evaluation_reproduced': False, 'native_GPT5_1_judge_reproduced': False,
        'same_checkpoint_self_judging_bias': True, 'independent_human_calibration': False,
        'prior12_results_pooled': False, 'prior12_condition_modified': False,
        'other_source_cases_unreviewed': 8554,
        'material_differences': plan['material_differences'],
        'plan_sha256': run.sha(here / 'plan.json'),
        'prediction_lock_sha256': run.sha(Path(plan['output_root']) / 'prediction_lock.json'),
        'judge_lock_sha256': run.sha(Path(plan['output_root']) / 'judge_lock.json'),
        'score_sha256': run.sha(Path(plan['output_root']) / 'scores.json'),
        'trajectory_archive': archive_name, 'operational_restoration': contract.provenance()}
    json_name = 'reports/' + STEM + '.json'
    md_name = 'reports/' + STEM + '.md'
    run.save(ROOT / json_name, report)
    axis_rows = '\n'.join('| ' + axis.replace('_', ' ').title() + ' | ' + f'{value:.4f}' + ' | ' +
        str(scores['per_axis_scored_case_count'][axis]) + ' |' for axis, value in scores['per_axis_score'].items())
    text = f'''# BioReason-Pro: 64 additional human proteins

Qwen3.8-27B completed **64/64 functional explanations and 64/64 local judgments**. Its declared local axis-macro score is **{scores['local_declared_axis_macro_score']:.4f}/10**.

These are the first 64 previously unattempted human entries in the released source order. They form a separate fixed extension. The earlier 12-case result remains unchanged and is not pooled into this score. Together the two conditions cover 76 source entries; the release contains 8,630.

| Assessment | Qwen local-judge score / 10 | Evaluated cases |
|---|---:|---:|
{axis_rows}

Only independently reviewed absence of all reference evidence permits an axis to be unevaluable: one molecular-function axis and two cellular-component axes meet that rule. Missing GO labels alone do not establish absence. Source annotation disagreements and three domain-coordinate inconsistencies were preserved.

The solver received complete original sequences and released domain, interaction and fallible predictor context. Reference names, curated function/GO and localization were excluded from solver requests. Every solver outcome was sealed before reference dossiers were parsed into judge prompts; earlier integrity hashing did not expose those references in solver requests.

Both stages used the pinned Qwen3.8-27B BF16 model with nonthinking 16,384-token outputs. This replaces the paper's GPT-5.1 judge and uses the same checkpoint as solver and judge. The score is an uncalibrated local explanation assessment, **not the paper's benchmark score or biological validation of proposed mechanisms**.

Delivery: {completion['solver']['transport_errors']} solver and {completion['judge']['transport_errors']} judge transport errors; {completion['solver']['truncations']} solver and {completion['judge']['truncations']} judge truncations; {completion['solver']['empty_finals']} solver and {completion['judge']['empty_finals']} judge empty finals. All planned cases remain in the declared score accounting. No selective retries were used.

Full dataset Apache-2.0 and upstream code MIT licenses, the pinned dataset README and source attribution are retained inside the trajectory archive.

Source: [BioReason-Pro released test data](https://huggingface.co/datasets/wanglab/bioreason-pro-test-data), revision `a18315a77d27dd4fe5a28b9b757695cff4ba4e3f`; publisher metadata declares Apache-2.0. [Exact numerical record]({STEM}.json) · [Audited trajectories](../{archive_name}).
'''
    path = ROOT / md_name
    with path.open('x') as stream: stream.write(text)
    paths = [md_name, json_name, archive_name, archive_manifest_name]
    ready = {'task_id': 'P44', 'at_pacific': run.stamp(), 'planned': 64,
        'local_axis_macro_score': scores['local_declared_axis_macro_score'],
        'paths_sha256': {name: run.sha(ROOT / name) for name in paths},
        'root_scientific_adoption_sha256': run.sha(here / 'root_scientific_adoption.json'),
        'publication_attempted': False, 'independent_concrete_byte_review_required': True,
        'whole_release_completed': False, 'shared_aggregate_reports_changed': False}
    ready['operational_restoration'] = contract.provenance()
    run.save(CURRENT / 'publication_ready.json', ready)
    contract.finalize(ready)
    print(json.dumps(ready))

if __name__ == '__main__': main()
