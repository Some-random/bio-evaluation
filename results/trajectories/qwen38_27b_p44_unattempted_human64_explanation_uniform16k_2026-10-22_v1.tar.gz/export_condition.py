"""Fail-closed audit and exact-member local export of a complete P44 condition.

No model/job/Git calls. Incomplete outcomes stay local for a separately reviewed
failure export; this exporter cannot silently omit them or define their score.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import stat

import p44_runner as run

ROOT_FILES = ['plan.json', 'root_ready_manifest.json', 'runtime_admission.json',
    'root_scientific_adoption.json', 'independent_technical_review.json',
    'p44_runner.py', 'worker.py', 'worker.sbatch', 'test_p44_runner.py', 'freeze_extension.py',
    'independent_scope_review.json', 'tokenizer_preflight.json', 'synthetic_validation.json', 'README.md']
RUN_FILES = ['run_manifest.json', 'development_completion.json', 'solver_outcomes.json', 'terminal_predictions.json',
    'prediction_lock.json', 'judge_outcomes.json', 'judgments.json', 'judge_lock.json', 'scores.json', 'completion.json']
ATTEMPT_FILES = ['request.json', 'context_check.json', 'transport_intent.json', 'response.body', 'outcome.json']


def regular(path, base):
    path = Path(path); base = Path(base)
    if not path.is_relative_to(base): raise ValueError('File escapes allowed source root')
    for item in [path, *path.parents]:
        if item == base.parent: break
        if item.is_symlink(): raise ValueError('Symlink in publication source')
    if not stat.S_ISREG(path.stat().st_mode): raise ValueError('Only regular publication files allowed')
    return path


def exact_tree(base, expected):
    """Reject extra files, empty directories and symlinks before copying bytes."""
    expected = set(expected); actual = set(); directories = set()
    if base.is_symlink() or not base.is_dir(): raise ValueError('Expected regular source directory')
    for directory, dirs, files in os.walk(base, followlinks=False):
        relative = Path(directory).relative_to(base)
        for name in dirs:
            path = Path(directory) / name
            if path.is_symlink(): raise ValueError('Symlink directory in export source')
            directories.add(str(path.relative_to(base)))
        for name in files:
            path = regular(Path(directory) / name, base); actual.add(str(path.relative_to(base)))
    allowed_directories = {str(parent) for name in expected for parent in Path(name).parents if str(parent) != '.'}
    if actual != expected or directories != allowed_directories: raise ValueError('Source members differ from exact whitelist')


def completed_attempt(directory, expected_payload, case_id, phase, context_limit):
    expected = set(ATTEMPT_FILES)
    if phase == 'panel_judge': expected.add('parsed_outcome.json')
    exact_tree(directory, expected)
    if run.read(directory / 'request.json') != expected_payload: raise ValueError('Actual request differs from frozen request')
    context = run.read(directory / 'context_check.json')
    if (type(context['input_tokens']) is not int or context['input_tokens'] < 0 or context['input_unchanged'] is not True or
            context['output_tokens'] != expected_payload['max_tokens'] or context['input_tokens'] + context['output_tokens'] > context_limit):
        raise ValueError('Actual unchanged context/configuration does not reconcile')
    intent = run.read(directory / 'transport_intent.json'); outcome = run.read(directory / 'outcome.json')
    request_sha = run.sha(directory / 'request.json')
    if intent['case_id'] != case_id or intent['phase'] != phase or intent['request_sha256'] != request_sha:
        raise ValueError('Transport intent differs from case/request identity')
    parsed = run.parse_response((directory / 'response.body').read_bytes())
    if parsed['status'] != 'completed': raise ValueError('Failure export requires separate explicit review; no silent omission')
    for key, value in parsed.items():
        if outcome.get(key) != value: raise ValueError('Per-attempt outcome differs from raw response')
    if (outcome['case_id'] != case_id or outcome['request_sha256'] != request_sha or
            outcome['raw_response_sha256'] != run.sha(directory / 'response.body') or outcome['transport_call_returned'] is not True):
        raise ValueError('Outcome identity/hash changed')
    if phase == 'panel_judge' and run.read(directory / 'parsed_outcome.json') != outcome:
        raise ValueError('Judge parsed outcome differs from successful raw outcome')
    return outcome


def audit_closed(here, *, artificial=False):
    here = Path(here); plan = run.read(here / 'plan.json'); folder = Path(plan['output_root'])
    contract, _ = run.source_modules(); panel = run.read(plan['panel']); ids = contract.validate_panel(panel)
    if not artificial and (plan['execution_scope'] != 'reviewed_P44_unattempted_human64_extension' or len(ids) != 64 or plan['source_released_denominator'] != 8630):
        raise ValueError('Only exact reviewed64 condition can be exported')
    for name, pin in plan['frozen_files_sha256'].items():
        regular(name, Path(name).parent)
        if run.sha(name) != pin: raise ValueError('Frozen artifact changed')
    admission = run.read(here / 'runtime_admission.json')
    adoption = run.read(here / 'root_scientific_adoption.json')
    submission = run.read(here / 'submission_receipt.json')
    if (admission.get('admitted') is not True or adoption.get('adopted') is not True or
            admission['plan_sha256'] != run.sha(here / 'plan.json') or adoption['plan_sha256'] != admission['plan_sha256'] or
            admission['root_scientific_adoption_sha256'] != run.sha(here / 'root_scientific_adoption.json') or
            submission['plan_sha256'] != admission['plan_sha256'] or submission['admission_sha256'] != run.sha(here / 'runtime_admission.json')):
        raise ValueError('Root grant/adoption/submission do not bind exact plan')
    accounting = run.read(here / 'closure_monitor_v2/terminal_job_receipt.json')
    if accounting.get('verified_exact_terminal_allocation') is not True or accounting['job_id'] != submission['job_id']:
        raise ValueError('Fresh exact terminal allocation accounting required')
    from watch_closure import terminal_accounting
    verified = terminal_accounting(accounting['accounting_stdout'], accounting['accounting_return_code'], submission['job_id'], here.parents[4] if not artificial else Path(accounting['workdir']))
    if any(accounting.get(key) != value for key, value in verified.items()): raise ValueError('Recorded terminal accounting does not reconcile')
    allocation = run.read(here / 'runtime/allocation_started.json')
    if allocation['job_id'] != submission['job_id'] or allocation['plan_sha256'] != submission['plan_sha256']:
        raise ValueError('Own started allocation differs from exact submitted grant')
    manifest = run.read(folder / 'run_manifest.json')
    if manifest['plan_sha256'] != contract.canonical_hash(plan) or manifest['panel_sha256'] != contract.canonical_hash(panel):
        raise ValueError('Actual protocol manifest does not bind exact plan and panel')
    completion = run.read(folder / 'completion.json'); scores = run.read(folder / 'scores.json')
    if completion.get('panel_primary_defined') is not True or not scores['all_case_complete']:
        raise ValueError('Incomplete condition needs separately reviewed full-failure export')
    predictions = run.read(folder / 'terminal_predictions.json'); lock = run.read(folder / 'prediction_lock.json')
    if lock != contract.freeze_predictions(panel, predictions): raise ValueError('Prediction lock changed')
    neutral = run.read(plan['neutral_gate_inputs'])['cases']; neutral_records = []
    expected_paths = {phase: set() for phase in ['development_solver', 'development_judge', 'solver', 'judge']}
    for index, fixture in enumerate(neutral):
        cid = fixture['case_id']
        out = completed_attempt(folder / 'development_solver' / f'{index:03d}', fixture['solver_envelope'], cid,
            'development_solver', plan['model_configuration']['max_context_tokens'])
        if out['text'].strip().lower().rstrip('.') != fixture['expected_solver_final']: raise ValueError('Neutral solver gate changed')
        packet = fixture['judge_packet']; envelope = run.judge_envelope(packet, plan['model_configuration'], contract)
        out = completed_attempt(folder / 'development_judge' / f'{index:03d}', envelope, cid,
            'development_judge', plan['model_configuration']['max_context_tokens'])
        judgment = contract.parse_judgment(out['text'], packet['reference_dossier'])
        lo, hi = fixture['expected_reliability_range']
        if not lo <= judgment['reliability'] <= hi: raise ValueError('Neutral judge anchor gate changed')
        neutral_records.append({'case_id': cid, 'passed': True, 'judgment': judgment})
        for phase in ['development_solver', 'development_judge']:
            expected_paths[phase].update(f'{index:03d}/{name}' for name in ATTEMPT_FILES)
    gate = run.read(folder / 'development_completion.json')
    if (gate['all_passed'] is not True or gate['records'] != neutral_records or gate['solver_calls'] != len(neutral) or
            gate['judge_calls'] != len(neutral) or gate['artificial_only'] is not True): raise ValueError('Complete neutral gate evidence changed')
    solver = run.read(folder / 'solver_outcomes.json'); judged = run.read(folder / 'judge_outcomes.json')
    judgments = run.read(folder / 'judgments.json'); envelopes = run.read(plan['solver_envelope_manifest'])['envelopes']
    if any([row['case_id'] for row in rows] != ids for rows in [solver, judged, envelopes]) or set(judgments) != set(ids):
        raise ValueError('Full case identity/order/denominator changed')
    for index, cid in enumerate(ids):
        out = completed_attempt(folder / 'solver' / f'{index:03d}', run.read(envelopes[index]['path']), cid,
            'panel_solver', plan['model_configuration']['max_context_tokens'])
        if solver[index] != out or predictions[cid] != {'case_id': cid, 'status': 'saved', 'generation': out['text']}:
            raise ValueError('Aggregate/locked candidate differs from per-attempt raw final')
        dossier = run.read(Path(plan['judge_reference_directory']) / (cid + '.json'))
        packet = contract.build_judge_packet(panel, cid, dossier, lock)
        if run.read(folder / 'judge_packets' / (cid + '.json')) != packet: raise ValueError('Saved packet/dossier differs from frozen case')
        out = completed_attempt(folder / 'judge' / f'{index:03d}', run.judge_envelope(packet, plan['model_configuration'], contract), cid,
            'panel_judge', plan['model_configuration']['max_context_tokens'])
        expected_record = {'case_id': cid, 'status': 'scored', 'raw_judgment': out['text'], 'dossier': dossier,
            'prediction_lock_sha256': contract.canonical_hash(lock), 'configuration_sha256': contract.canonical_hash(plan['model_configuration'])}
        contract.parse_judgment(out['text'], dossier)
        if judged[index] != out or judgments[cid] != expected_record: raise ValueError('Aggregate judge outcome/dossier differs from frozen raw attempt')
        for phase in ['solver', 'judge']:
            expected_paths[phase].update(f'{index:03d}/{name}' for name in ATTEMPT_FILES + (['parsed_outcome.json'] if phase == 'judge' else []))
    if completion['solver'] != run.summary(solver, len(ids)) or completion['judge'] != run.summary(judged, len(ids)):
        raise ValueError('Completion summaries differ from full per-case outcomes')
    judge_lock = run.read(folder / 'judge_lock.json')
    if any(judge_lock[key] != run.sha(folder / name) for key, name in [('prediction_lock_sha256', 'prediction_lock.json'),
            ('judgments_sha256', 'judgments.json'), ('judge_outcomes_sha256', 'judge_outcomes.json')]): raise ValueError('Judge lock changed')
    expected_score = contract.aggregate_judgments(panel, judgments)
    for key, value in expected_score.items():
        if key != 'new_inference_calls' and scores.get(key) != value: raise ValueError('Persisted score does not reconcile')
    if completion['local_declared_axis_macro_score'] != scores['local_declared_axis_macro_score']: raise ValueError('Completion score changed')
    members = {name: here / name for name in ROOT_FILES}
    members.update({name: folder / name for name in RUN_FILES})
    members.update({name: here / name for name in ['submission_receipt.json', 'submission_intent.json',
        'solver_envelopes_manifest.json', 'neutral_gate_inputs.json', 'export_condition.py', 'watch_closure.py', 'test_export_condition.py']})
    members.update({'support/terminal_job_receipt.json': here / 'closure_monitor_v2/terminal_job_receipt.json',
        'support/allocation_started.json': here / 'runtime/allocation_started.json',
        'support/panel.json': Path(plan['panel']),
        'support/explanation_contract.py': run.CONTRACT,
        'support/offline_workflow.py': run.PREP / 'offline_workflow.py',
        'support/prepare_extension.py': here / 'prepare_extension.py',
        'support/packet_validation.json': run.PREP / 'packet_validation.json',
        'support/source_admission.json': run.PREP / 'admission.json',
        'support/review_selected_source_rows.json': run.PREP / 'review_selected_source_rows.json'})
    if artificial:
        # Invented fixture uses only its own temporary support files.
        for label in list(members):
            if label.startswith('support/') and label not in {'support/terminal_job_receipt.json', 'support/allocation_started.json', 'support/panel.json'}:
                members.pop(label)
    for phase, names in expected_paths.items():
        exact_tree(folder / phase, names)
        members.update({phase + '/' + name: folder / phase / name for name in names})
    for label, source in [('judge_packets', folder / 'judge_packets'), ('judge_reference', Path(plan['judge_reference_directory']))]:
        names = {cid + '.json' for cid in ids}; exact_tree(source, names)
        members.update({label + '/' + name: source / name for name in names})
    names = {Path(row['path']).name for row in envelopes}; exact_tree(here / 'solver_envelopes', names)
    members.update({'frozen_solver_envelopes/' + name: here / 'solver_envelopes' / name for name in names})
    for path in members.values(): regular(path, path.parent)
    return plan, scores, completion, members


def export(here, output):
    plan, scores, completion, members = audit_closed(here)
    output.mkdir(parents=True, exist_ok=False)
    manifest = {'task_id': 'P44', 'at_pacific': run.stamp(), 'plan_sha256': run.sha(here / 'plan.json'),
        'root_grant_sha256': run.sha(here / 'runtime_admission.json'),
        'root_adoption_sha256': run.sha(here / 'root_scientific_adoption.json'),
        'planned': 64, 'source_released_denominator': 8630, 'unreviewed_release_cases': 8554,
        'requested_thinking_enabled': plan['model_configuration']['chat_template_kwargs']['enable_thinking'],
        'observed_solver_reasoning_fields_present': completion['solver']['reasoning_present'],
        'observed_judge_reasoning_fields_present': completion['judge']['reasoning_present'],
        'native_replication': False, 'self_judging_bias': True, 'P28_P29_metrics_changed': False,
        'members': {name: {'sha256': run.sha(path), 'bytes': path.stat().st_size, 'original_source_path': str(path)} for name, path in sorted(members.items())},
        'git_publication': False, 'new_inference_calls': 0}
    for name, path in members.items():
        target = output / name; target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        if run.sha(target) != manifest['members'][name]['sha256']: raise ValueError('Copy byte verification failed')
    run.save(output / 'export_member_manifest.json', manifest)
    exact_tree(output, set(members) | {'export_member_manifest.json'})
    return {'passed': True, 'planned': 64, 'source_released_denominator': 8630, 'copied_members': len(members),
        'export_manifest_sha256': run.sha(output / 'export_member_manifest.json'), 'git_publication': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args(); print(json.dumps(export(run.HERE, arguments.output)))
