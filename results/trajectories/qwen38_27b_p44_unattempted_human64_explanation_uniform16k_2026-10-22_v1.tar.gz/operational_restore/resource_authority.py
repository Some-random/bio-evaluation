"""Additive P44 resource binding; no case, reference, model or scheduler reads on import."""
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
ORIGINAL = HERE.parent / 'wider_human_extension_20261022_v1'
PLAN_SHA256 = '1557688bcb161bc803357f4d10a875ae7c1d7a7bc3195d420e8abf3821d947ee'
SCOPE = 'P44_human64_existing_frozen_science_resource_accounting_only'
ADAPTER = ROOT / '.local/resource_accounting_20261022/exact_external_checkpoint_jobs_adapter_v5.py'
ADAPTER_SHA256 = 'd7464059bdf95ab61fe0a2699cc4fb510252b9502aeb2c869d612f9d5d3d5f42'
PROOFS = [{'path': '/dfs/scratch0/dongweij/bio-evaluation/.local/resource_accounting_20261022/root_external_repaired_web_filter_job_review.json', 'sha256': 'f70f981e4ea599293abbdd1ae6f1ce864718d3aa1643980ced0d4fb067bc153c'}, {'path': '/dfs/scratch0/dongweij/bio-evaluation/.local/goal_restore_20261024/root_external_web_jobs_249133_249410.json', 'sha256': '39596f2bb73d6d548a576400ed981b9a45fcad23b458891587ae46c58273bd2e'}]
BINDING = {'path': '/dfs/scratch0/dongweij/bio-evaluation/.local/goal_restore_20261024/additional_external_jobs_binding.json', 'sha256': 'ccde26c0227e496f82951ee350f3191eda2d6c0a6c7839b93e88b01b32f56ffd'}
CHECKPOINT_PROOF = {'path': str(ROOT / '.local/resource_accounting_20261022/root_external_checkpoint_jobs_review_20261023.json'),
                    'sha256': 'edfc703f1556b0e0c743798c4b91d7396a2cfe84f4c8563ba9466b719490434d'}
CURRENT_ROOT_SCOPE = {'path': str(ROOT / '.local/priority_results_20261023/root_scope.json'),
                      'sha256': '50296e691e085aba9e0488d26f1e1dc7582b6ba1c3015584a64bf214b81004b8'}
ORIGINAL_SOURCE_PINS = {
    'capacity_waiter.py': 'bbed04aff125541c03f9e6958bee517ecfeb2309e119c4cde599795ddfd86201',
    'worker.py': '4bfc8ff5274656789273ba2cbfedf3f8d00388f130a78dcf5fefddbba7deccf8',
    'worker.sbatch': 'f3193008fdf8075afc48cd5bfafe6a17c04662f383ff169358e08f07615029ea',
    'p44_runner.py': 'b5864ff8da0cdf751e68f5d11c1e1518a2c0c2b1c62e197fe389c447254640aa',
}
SOURCE_NAMES = frozenset(('resource_authority.py', 'capacity_waiter.py', 'worker.py',
                          'worker.sbatch', 'test_restore.py'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def pinned(path, digest):
    path = Path(path)
    if (path.is_symlink() or path.resolve() != path or not path.is_file()
            or sha(path) != digest):
        raise ValueError('Exact regular pinned resource source or authority required')
    return path


def require_unheld():
    if (HERE / 'STOP').exists() or (HERE / 'STOP').is_symlink():
        raise PermissionError('P44 restoration scheduling STOP remains active')


def verify_manifest(amendment_sha256):
    verify_restore_root()
    manifest = read(pinned(HERE / 'amendment.json', amendment_sha256))
    expected = dict(scope=SCOPE, original_plan_sha256=PLAN_SHA256,
        original_plan=str(ORIGINAL / 'plan.json'), requested_GPUs=1, project_GPU_ceiling=8,
        scientific_changes=False, automatic_retry=False, admission_granted_by_packet=False,
        resource_adapter=str(ADAPTER), resource_adapter_sha256=ADAPTER_SHA256,
        additional_root_proofs=PROOFS, additional_proof_binding=BINDING,
        checkpoint_root_proof=CHECKPOINT_PROOF, current_root_scope=CURRENT_ROOT_SCOPE,
        original_source_sha256=ORIGINAL_SOURCE_PINS,
        root_authorization=dict(path=str(ROOT_AUTHORIZATION),sha256=ROOT_AUTHORIZATION_SHA),
        shared_resource_binding=dict(path=str(SHARED_RESOURCE_BINDING),sha256=SHARED_RESOURCE_BINDING_SHA))
    if any(manifest.get(key) != value for key, value in expected.items()):
        raise ValueError('Exact resource-only amendment required')
    sources = manifest.get('source_sha256', {})
    if set(sources) != SOURCE_NAMES:
        raise ValueError('Complete additive source inventory required')
    for name, digest in sources.items():
        pinned(HERE / name, digest)
    pinned(ORIGINAL / 'plan.json', PLAN_SHA256)
    for name, digest in ORIGINAL_SOURCE_PINS.items():
        pinned(ORIGINAL / name, digest)
    for evidence in [dict(path=str(ADAPTER), sha256=ADAPTER_SHA256), *PROOFS, BINDING, CHECKPOINT_PROOF, CURRENT_ROOT_SCOPE]:
        pinned(evidence['path'], evidence['sha256'])
    shared_resource_configuration()
    for path,digest in manifest['preserved_legacy_STOP_sha256'].items(): pinned(path,digest)
    return manifest


def validate_authority_values(amendment_sha256, admission_sha256, admission, release):
    if (admission.get('reviewer') not in {'/root', '/root/independent_review'}
            or admission.get('admitted') is not True or admission.get('scope') != SCOPE
            or admission.get('amendment_sha256') != amendment_sha256
            or admission.get('original_plan_sha256') != PLAN_SHA256
            or admission.get('scientific_changes') is not False
            or admission.get('automatic_retry') is not False
            or admission.get('root_authorization_sha256') != ROOT_AUTHORIZATION_SHA
            or admission.get('shared_resource_binding_sha256') != SHARED_RESOURCE_BINDING_SHA):
        raise PermissionError('Independent exact resource admission required')
    if (release.get('issuer') != '/root' or release.get('approved') is not True
            or release.get('scope') != SCOPE or release.get('amendment_sha256') != amendment_sha256
            or release.get('resource_admission_sha256') != admission_sha256
            or release.get('original_plan_sha256') != PLAN_SHA256
            or release.get('current_root_scope_sha256') != CURRENT_ROOT_SCOPE['sha256']
            or release.get('P44_priority_released_for_this_exact_amendment') is not True
            or release.get('root_authorization_sha256') != ROOT_AUTHORIZATION_SHA
            or release.get('prepared_by') != '/root/priority_runtime_review'):
        raise PermissionError('Exact separate root priority release required')


def authorize(amendment_sha256, resource_admission_sha256, priority_release_sha256):
    require_unheld()
    manifest = verify_manifest(amendment_sha256)
    admission_path = pinned(HERE / 'independent_resource_admission.json', resource_admission_sha256)
    release_path = pinned(HERE / 'root_priority_release.json', priority_release_sha256)
    validate_authority_values(amendment_sha256, resource_admission_sha256,
                              read(admission_path), read(release_path))
    return manifest


def load_adapter():
    shared_resource_configuration()
    path = pinned(ADAPTER, ADAPTER_SHA256)
    spec = importlib.util.spec_from_file_location('p44_exact_resource_adapter_v5', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def capacity_audit(*, additional, require_own_job=False, runner=None):
    if (type(additional) is not int or type(require_own_job) is not bool
            or (additional, require_own_job) not in {(1, False), (0, True)}):
        raise ValueError('Only preallocation +1 and startup own-allocation +0 are supported')
    value = load_adapter().capacity_audit(additional=additional, override=False, runner=runner,
        require_own_job=require_own_job, additional_root_proofs=PROOFS,
        additional_proof_binding=BINDING)
    count = value.get('project_requested_GPUs')
    if (type(count) is not int or count < 0
            or type(value.get('project_requested_GPUs_with_addition')) is not int
            or value['project_requested_GPUs_with_addition'] != count + additional
            or value.get('capacity_available') is not (count + additional <= 8)
            or (require_own_job and (value.get('own_allocation_verified') is not True
                                    or not value['capacity_available']))):
        raise ValueError('Fresh conservative project GPU accounting required')
    return value


def verify_runtime_binding(admission, amendment_sha256, resource_admission_sha256, priority_release_sha256):
    expected = dict(resource_amendment_sha256=amendment_sha256,
        resource_admission_sha256=resource_admission_sha256,
        resource_priority_release_sha256=priority_release_sha256)
    if any(admission.get(key) != value for key, value in expected.items()):
        raise PermissionError('Runtime admission must bind the same exact resource amendment')

ROOT_AUTHORIZATION=ROOT/'.local/goal_restore_20261024/root_authorization.json'
ROOT_AUTHORIZATION_SHA='bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
SHARED_RESOURCE_BINDING=ROOT/'.local/goal_restore_20261024/shared_resource_binding.json'
SHARED_RESOURCE_BINDING_SHA='cb881370f7dac295d7d153f72baddcbf604c0fce0cc651ee82c557e5efcad6f9'

def verify_restore_root():
    authority=read(pinned(ROOT_AUTHORIZATION,ROOT_AUTHORIZATION_SHA))
    if (authority.get('issuer')!='/root' or authority.get('approved') is not True
        or authority.get('owners',{}).get('P44')!='/root/priority_runtime_review'
        or authority.get('independent_review_delegation',{}).get('P13_P37_P44_classification')!='/root/independent_review'
        or 'P44_reviewed_human64_solver_fixed_local_judge' not in authority.get('restore_already_reviewed_local_lanes',[])
        or authority.get('project_GPU_ceiling')!=8):
        raise PermissionError('Exact explicit P44 restoration root authority required')
    return authority

def shared_resource_configuration():
    c=read(pinned(SHARED_RESOURCE_BINDING,SHARED_RESOURCE_BINDING_SHA))
    if (c.get('resource_adapter')!=dict(path=str(ADAPTER),sha256=ADAPTER_SHA256)
        or c.get('additional_root_proofs')!=PROOFS or c.get('additional_proof_binding')!=BINDING
        or c.get('root_authorization')!=dict(path=str(ROOT_AUTHORIZATION),sha256=ROOT_AUTHORIZATION_SHA)
        or c.get('project_GPU_ceiling')!=8):
        raise PermissionError('Exact common restoration resource configuration required')
    for ref in [*PROOFS,BINDING]: pinned(ref['path'],ref['sha256'])
    return c
