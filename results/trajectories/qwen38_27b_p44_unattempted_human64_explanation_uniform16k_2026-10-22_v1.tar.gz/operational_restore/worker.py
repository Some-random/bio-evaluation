"""One separately admitted P44 Slurm allocation, TP1 BF16 Qwen solver/judge."""
from __future__ import annotations
import argparse
import copy
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request

from resource_authority import ORIGINAL, authorize as authorize_resources, capacity_audit as resource_capacity_audit, verify_runtime_binding
sys.path.insert(0, str(ORIGINAL))
from p44_runner import TransportFailure,current,read,run_protocol,save,sha,stamp

HERE=ORIGINAL
PINNED_PACKAGES={'vllm':'0.32.0','torch':'2.13.0','transformers':'5.17.0','triton':'3.7.1','flashinfer-python':'0.7.0.post1'}

def runtime_install_command(python,report):
    return [str(python),'-m','pip','install','--index-url','https://pypi.org/simple','--only-binary=:all:',
      '--break-system-packages','--upgrade',*[name+'=='+version for name,version in PINNED_PACKAGES.items()],'--report',str(report)]

def verify_package_identity(info):
    for name,version in PINNED_PACKAGES.items():
        observed=info['packages'][name]
        if observed.split('+',1)[0]!=version:raise ValueError('Pinned package mismatch: '+name+'='+observed)
    return info

def install_private_runtime(python,environment,output):
    with (output/'runtime_install.log').open('x') as log:
        subprocess.run(runtime_install_command(python,output/'pip_install_report.json'),env=environment,
          stdout=log,stderr=subprocess.STDOUT,check=True,timeout=2400)
    with (output/'pip_check.log').open('x') as log:
        subprocess.run([str(python),'-m','pip','check'],env=environment,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    code='import importlib.metadata as m,json,platform;print(json.dumps({"python":platform.python_version(),"packages":{n:m.version(n) for n in '+repr(list(PINNED_PACKAGES))+'}}))'
    info=json.loads(subprocess.check_output([str(python),'-c',code],env=environment,text=True,timeout=120))
    verify_package_identity(info);save(output/'installed_package_identity.json',info)

def validate_plan(path,digest):
    if sha(path)!=digest:raise ValueError('Frozen P44 plan hash changed')
    plan=read(path)
    if plan['execution_scope']!='reviewed_P44_unattempted_human64_extension' or plan['planned']!=64 or plan['gpus_requested']!=1:
        raise ValueError('Exactly one independent P44 reviewed64 allocation is required')
    if plan['model_configuration']['max_tokens']!=16384 or plan['model_configuration']['chat_template_kwargs']!={'enable_thinking':False}:
        raise ValueError('Frozen uniform16K nonthinking condition changed')
    for name,pin in plan['frozen_files_sha256'].items():
        if sha(name)!=pin:raise ValueError('Frozen input/code/source changed: '+name)
    if Path(plan['output_root']).resolve()!=HERE/'runtime/run_v1':raise ValueError('Unexpected P44 output root')
    if plan['endpoint']!='http://127.0.0.1:8494/v1':raise ValueError('Dedicated P44 loopback endpoint required')
    return plan

def validate_admission(path,digest,plan_digest):
    if sha(path)!=digest:raise ValueError('Admission hash changed')
    admission=read(path)
    if (admission.get('admitted') is not True or admission.get('task_id')!='P44'
        or admission.get('plan_sha256')!=plan_digest or admission.get('gpu_count')!=1
        or admission.get('project_gpu_ceiling')!=8 or admission.get('scope')!='solver_and_declared_local_judge_unattempted_human64_once'):
        raise ValueError('A separate exact root admission is required before any model/server startup')
    audit=Path(admission['gpu_audit_receipt'])
    if sha(audit)!=admission['gpu_audit_receipt_sha256']:raise ValueError('GPU ownership/budget audit pin changed')
    adoption=HERE/'root_scientific_adoption.json'
    if sha(adoption)!=admission['root_scientific_adoption_sha256']:
        raise ValueError('Root scientific adoption changed')
    scope=read(adoption)
    if scope.get('issuer')!='/root' or scope.get('adopted') is not True or scope.get('plan_sha256')!=plan_digest:
        raise ValueError('This exact new64 scientific condition needs root adoption')
    if not os.environ.get('SLURM_JOB_ID'):raise ValueError('Slurm allocation required')
    return admission

def conservative_gpu_audit():
    return resource_capacity_audit(additional=0, require_own_job=True)


def common_module(plan):
    spec=importlib.util.spec_from_file_location('p44_frozen_runtime_common',plan['runtime_common'])
    common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common);return common

def clean_environment(common,local):
    environment=common.environment(local)
    for name in list(environment):
        if re.search(r'(?:API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL)',name,re.I) or name in ['SSH_AUTH_SOCK','NETRC','KUBECONFIG','GOOGLE_APPLICATION_CREDENTIALS','OPENAI_BASE_URL','OPENAI_ORG_ID','OPENAI_PROJECT_ID','PYTHONPATH','PYTHONHOME','VIRTUAL_ENV']:
            environment.pop(name,None)
    environment.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',DO_NOT_TRACK='1',VLLM_NO_USAGE_STATS='1')
    environment.update(PIP_INDEX_URL='https://pypi.org/simple',PIP_EXTRA_INDEX_URL='',PIP_CONFIG_FILE='/dev/null')
    return environment

class LocalTransport:
    def __init__(self,plan,identity_file,identity_sha256,common):
        self.plan=plan;self.identity_file=identity_file;self.identity_sha256=identity_sha256;self.common=common
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def send(self,phase,question_id,payload):
        if sha(self.identity_file)!=self.identity_sha256:raise ValueError('P44 server identity file changed')
        identity=read(self.identity_file)
        if (identity['job_id']!=os.environ.get('SLURM_JOB_ID') or identity['hostname']!=socket.gethostname()
            or self.common.start_ticks(identity['pid'])!=identity['proc_start_ticks']
            or payload['model']!=self.plan['model_configuration']['model'] or payload['max_tokens']!=16384):
            raise ValueError('Local request no longer matches the admitted own server')
        request=urllib.request.Request(self.plan['endpoint']+'/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
        try:
            with self.opener.open(request,timeout=1800) as response:return response.read()
        except urllib.error.HTTPError as error:raise TransportFailure(str(error),error.code,error.read()) from error
        except (urllib.error.URLError,TimeoutError,OSError) as error:raise TransportFailure(str(error)) from error

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--plan-sha256',required=True)
    parser.add_argument('--admission',type=Path,required=True);parser.add_argument('--admission-sha256',required=True);parser.add_argument('--runtime-dir',type=Path)
    for name in ('resource-amendment-sha256','resource-admission-sha256','priority-release-sha256'):
        parser.add_argument('--'+name,required=True)
    args=parser.parse_args()
    authorize_resources(args.resource_amendment_sha256,args.resource_admission_sha256,args.priority_release_sha256)
    plan=validate_plan(args.plan,args.plan_sha256)
    admission=validate_admission(args.admission,args.admission_sha256,args.plan_sha256)
    verify_runtime_binding(admission,args.resource_amendment_sha256,args.resource_admission_sha256,args.priority_release_sha256)
    runtime_root=HERE/'runtime';runtime_root.mkdir(exist_ok=True)
    common=common_module(plan)
    if args.runtime_dir is None:
        lock=(runtime_root/'allocation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (runtime_root/'allocation_started.json').exists():raise ValueError('This one-attempt P44 allocation already started; no automatic resubmission/retry')
        audit=conservative_gpu_audit();save(runtime_root/'gpu_budget_audit.json',audit)
        save(runtime_root/'allocation_started.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'plan_sha256':args.plan_sha256,'admission_sha256':args.admission_sha256})
        if shutil.disk_usage('/tmp').free<32*1024**3:raise ValueError('Private runtime needs at least32GiB free local scratch')
        for artifact in ['base_runtime','cuda_overlay']:
            value=plan[artifact]
            if sha(value['path'])!=value['sha256']:raise ValueError('Runtime archive digest changed')
        local=Path(tempfile.mkdtemp(prefix='bio-p44ext-'+os.environ['SLURM_JOB_ID']+'-'))
        with tarfile.open(plan['base_runtime']['path']) as archive:archive.extractall(local,filter='data')
        receipts=common.apply_overlay(local);save(runtime_root/'runtime_archive_receipt.json',{'local_prefix':str(local),**receipts})
        environment=clean_environment(common,local)
        # The verified base archive contains vLLM0.31.0. Reproduce the existing
        # catalog worker's exact pinned upgrade in this new private prefix.
        install_private_runtime(local/'python/bin/python3.12',environment,runtime_root)
        command=[str(local/'python/bin/python3.12'),str(Path(__file__).resolve()),*sys.argv[1:],'--runtime-dir',str(local)]
        os.execve(command[0],command,environment)
    local=args.runtime_dir.resolve()
    if not local.name.startswith('bio-p44ext-'+os.environ['SLURM_JOB_ID']+'-'):raise ValueError('Private runtime ownership mismatch')
    lock=(runtime_root/'protocol.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if Path(plan['output_root']).exists():raise ValueError('P44 output already exists; no second benchmark attempt')
    import importlib.metadata as metadata
    import torch
    verify_package_identity({'packages':{name:metadata.version(name) for name in PINNED_PACKAGES}})
    if torch.cuda.device_count()!=1:raise ValueError('Exactly one Slurm-visible GPU required after verified pinned install')
    model=plan['model_configuration'];model_dir=common.validate_checkpoint(model['model'],model['revision'])
    save(runtime_root/'environment.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'hostname':socket.gethostname(),
      'visible_gpu_count':1,'dtype':'bfloat16','tensor_parallel_size':1,'vllm':metadata.version('vllm'),'torch':torch.__version__,
      'transformers':metadata.version('transformers'),'model_directory':str(model_dir),'checkpoint_audit_sha256':sha(plan['checkpoint_audit'])})
    from transformers import AutoProcessor
    processor=AutoProcessor.from_pretrained(model_dir,local_files_only=True)
    def context_check(payload):
        encoded=processor.apply_chat_template(copy.deepcopy(payload['messages']),tokenize=True,return_dict=True,return_tensors='pt',add_generation_prompt=True,**payload['chat_template_kwargs'])
        tokens=int(encoded['input_ids'].shape[-1]);del encoded
        if tokens+16384>65536:raise ValueError('Full unchanged prompt plus uniform16K output exceeds frozen context; stop, never truncate')
        return tokens
    for row in read(plan['solver_envelope_manifest'])['envelopes']:context_check(read(row['path']))
    save(runtime_root/'uniform16k_context_preflight.json',{'at_pacific':stamp(),'cases':64,'all_fit':True,'output_tokens':16384,'context_limit':65536,'model_forwards':0})
    with socket.socket() as probe:probe.bind(('127.0.0.1',8494))
    command=[str(local/'python/bin/python3.12'),'-m','vllm.entrypoints.cli.main','serve',str(model_dir),
      '--served-model-name',model['model'],'--host','127.0.0.1','--port','8494','--dtype','bfloat16','--tensor-parallel-size','1',
      '--gpu-memory-utilization','0.95','--max-model-len','65536','--max-num-seqs','4','--max-num-batched-tokens','8192',
      '--reasoning-parser','qwen3','--enable-prefix-caching','--limit-mm-per-prompt','{"image":1,"video":0}']
    server=None
    try:
        current(runtime_root/'status.json',{'at_pacific':stamp(),'stage':'starting_independent_P44_server','job_id':os.environ['SLURM_JOB_ID'],'endpoint':plan['endpoint']})
        with (runtime_root/'server.log').open('x') as log:server=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,cwd=local)
        deadline=time.monotonic()+1800;opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        while time.monotonic()<deadline:
            if server.poll() is not None:raise RuntimeError('P44 server exited before readiness')
            try:
                with opener.open('http://127.0.0.1:8494/health',timeout=3) as health:
                    if health.status==200:break
            except (OSError,urllib.error.URLError):time.sleep(3)
        else:raise TimeoutError('P44 own server readiness timeout; no model-call retry')
        with opener.open(plan['endpoint']+'/models',timeout=5) as response:models=json.load(response)
        if [row['id'] for row in models['data']]!=[model['model']]:raise ValueError('Served model ID mismatch')
        identity={'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'hostname':socket.gethostname(),'pid':server.pid,
          'proc_start_ticks':common.start_ticks(server.pid),'model':model['model'],'revision':model['revision'],'dtype':'bfloat16',
          'tensor_parallel_size':1,'dedicated_gpu_count':1,'endpoint':plan['endpoint'],'max_model_len':65536,
          'plan_sha256':args.plan_sha256,'admission_sha256':args.admission_sha256,'server_command':command,
          'gpu_processes':common.own_gpu_processes(server.pid)}
        identity_path=runtime_root/'server_identity.json';save(identity_path,identity)
        transport=LocalTransport(plan,identity_path,sha(identity_path),common)
        current(runtime_root/'status.json',{'at_pacific':stamp(),'stage':'serving_frozen_P44_protocol','job_id':os.environ['SLURM_JOB_ID'],'endpoint':plan['endpoint']})
        completion=run_protocol(plan,plan['output_root'],transport,context_check)
        save(runtime_root/'terminal_receipt.json',{'at_pacific':stamp(),'job_id':os.environ['SLURM_JOB_ID'],'completion':completion,
          'completion_sha256':sha(Path(plan['output_root'])/'completion.json')})
    except Exception as error:
        current(runtime_root/'status.json',{'at_pacific':stamp(),'stage':'stopped_for_review','error_type':type(error).__name__,'error':str(error),'no_automatic_retry':True})
        raise
    finally:
        if server is not None and server.poll() is None:
            os.killpg(server.pid,signal.SIGTERM)
            try:server.wait(timeout=60)
            except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait(timeout=10)
        current(runtime_root/'server_terminal.json',{'at_pacific':stamp(),'own_server_stopped':True,'other_project_runtimes_changed':False})

if __name__=='__main__':main()
