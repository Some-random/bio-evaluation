"""One additive CPU export recovery into new v3; no scheduler/model/score/push.

The pinned existing full-condition auditor supplies every authoritative source.
Old partial v2 and failed-observer evidence are never modified. Eight-thread
maps retain sorted member order; any uncertain new attempt is never replayed.
"""
from pathlib import Path, PurePosixPath
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
import stat
import sys

HERE = Path(__file__).resolve().parent
RESTORE = HERE.parent
OLD = RESTORE.parent / 'wider_human_extension_20261022_v1'
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
AUTH_SHA = 'bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
SNAPSHOT_SHA = '13e4fba0400047516de4d009adae4d00c5a20db2eb88a308c80cf54c3d28c8a5'
REVIEWER = '/root/independent_review'
REVIEWERS = frozenset(('/root', '/root/independent_review'))


def parent_fd(path, create=False):
    path = Path(path).absolute()
    directory = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            if create:
                try: os.mkdir(part, 0o700, dir_fd=directory)
                except FileExistsError: pass
            current = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
            os.close(directory); directory = current
        return directory
    except BaseException:
        os.close(directory); raise


def regular_fd(path):
    path = Path(path).absolute(); directory = parent_fd(path)
    try: fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
    finally: os.close(directory)
    if not stat.S_ISREG(os.fstat(fd).st_mode):
        os.close(fd); raise ValueError('Only anchored regular files are allowed')
    return fd


def raw(path):
    with os.fdopen(regular_fd(path), 'rb') as stream: return stream.read()


def record(path):
    h = hashlib.sha256(); size = 0
    with os.fdopen(regular_fd(path), 'rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            h.update(block); size += len(block)
    return {'sha256': h.hexdigest(), 'bytes': size}


def sha(path): return record(path)['sha256']
def read(path): return json.loads(raw(path))

def pinned(path, expected):
    if sha(path) != expected: raise ValueError('Pinned source/evidence changed: ' + str(path))
    return Path(path)


def create_json(path, value):
    path = Path(path).absolute(); directory = parent_fd(path, create=True)
    try:
        fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory)
        with os.fdopen(fd, 'w') as stream:
            json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False); stream.write('\n')
            stream.flush(); os.fsync(stream.fileno())
        os.fsync(directory)
    finally: os.close(directory)


def safe_name(name):
    if not isinstance(name, str) or not name or '\\' in name: raise ValueError('Unsafe member name')
    p = PurePosixPath(name)
    if p.is_absolute() or p.as_posix() != name or any(x in ('..', '.', '.local', '') for x in p.parts):
        raise ValueError('Unsafe export member name')
    return name


def tree(folder):
    folder = Path(folder)
    if folder.is_symlink() or not folder.is_dir(): raise ValueError('Regular export root required')
    observed = set()
    for directory, dirs, files in os.walk(folder, followlinks=False):
        for name in dirs:
            if (Path(directory) / name).is_symlink(): raise ValueError('Symlink directory in export')
        for name in files:
            path = Path(directory) / name
            with os.fdopen(regular_fd(path), 'rb'): pass
            observed.add(safe_name(path.relative_to(folder).as_posix()))
    return observed


def check_review(review, config_sha, config):
    expected = {'approved': True,
        'role': 'independent_P44_additive_CPU_export_recovery_admission',
        'config_sha256': config_sha, 'job_id': '249561', 'planned': 64,
        'output_root': config['output_root'], 'old_partial_snapshot_sha256': config['old_partial_snapshot']['sha256'],
        'model_calls': 0, 'new_score_attempts': 0, 'Git_or_publication_authorized': False}
    if review.get('reviewer') not in REVIEWERS or any(review.get(k) != v for k, v in expected.items()):
        raise PermissionError('Exact independent CPU-only recovery admission required')


def validate(config_sha):
    config = read(pinned(HERE / 'config.json', config_sha))
    expected = {'role': 'P44_additive_once_CPU_export_recovery_to_new_v3', 'job_id': '249561',
        'planned': 64, 'source_released_denominator': 8630, 'workers': 8,
        'output_root': str(OLD / 'public_export_review_v3'),
        'old_partial_root': str(OLD / 'public_export_review_v2'),
        'old_closure_lock': str(OLD / 'closure_monitor_v2/singleton.lock'),
        'old_root': str(OLD), 'old_exporter': str(OLD / 'export_condition.py'),
        'old_partial_snapshot': {'path': str(RESTORE / 'partial_export_v2_timeout_snapshot.json'), 'sha256': SNAPSHOT_SHA},
        'root_authorization': {'path': str(ROOT / '.local/goal_restore_20261024/root_authorization.json'), 'sha256': AUTH_SHA},
        'model_calls': 0, 'new_score_attempts': 0, 'scheduler_calls': 0,
        'Git_or_publication_authorized': False, 'automatic_retry': False}
    if any(config.get(k) != v for k, v in expected.items()): raise PermissionError('Exact unchanged human64 CPU recovery scope required')
    for path, expected_sha in config['files_sha256'].items(): pinned(path, expected_sha)
    authority = read(pinned(config['root_authorization']['path'], AUTH_SHA))
    if (authority.get('issuer') != '/root' or authority.get('approved') is not True
            or 'P44_reviewed_human64_solver_fixed_local_judge' not in authority.get('restore_already_reviewed_local_lanes', [])):
        raise PermissionError('Exact root restoration authority required')
    snapshot = read(pinned(config['old_partial_snapshot']['path'], SNAPSHOT_SHA))
    if (snapshot.get('partial_root') != config['old_partial_root'] or snapshot.get('file_count') != 322
            or len(snapshot.get('files', {})) != 322 or snapshot.get('original_GPU_job') != '249561'
            or snapshot.get('all_old_partial_files_to_be_preserved') is not True):
        raise ValueError('Exact preserved old322 partial snapshot required')
    for path, digest in snapshot['failure_evidence_sha256'].items(): pinned(path, digest)
    terminal = read(OLD / 'closure_monitor_v2/terminal_job_receipt.json')
    if (terminal.get('job_id') != '249561' or terminal.get('state') != 'COMPLETED'
            or terminal.get('exit_code') != '0:0' or terminal.get('verified_exact_terminal_allocation') is not True):
        raise ValueError('Exact successful old GPU terminal receipt required')
    admission = HERE / 'independent_recovery_admission.json'
    admission_bytes = raw(admission)
    check_review(json.loads(admission_bytes), config_sha, config)
    if os.path.lexists(HERE / 'STOP'): raise PermissionError('Recovery STOP present')
    config['_admission_sha256'] = hashlib.sha256(admission_bytes).hexdigest()
    return config


@contextmanager
def locked(path, existing):
    if existing: fd = regular_fd(path)
    else:
        fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
        if not stat.S_ISREG(os.fstat(fd).st_mode): os.close(fd); raise ValueError('Regular recovery lock required')
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
    finally: os.close(fd)


def no_attempt(config):
    if any(os.path.lexists(HERE / name) for name in ('claim.json', 'completed.json')) or os.path.lexists(config['output_root']):
        raise FileExistsError('Preserve any prior new-v3 recovery attempt; never replay')


def verify_partial(config, snapshot):
    old = Path(config['old_partial_root'])
    if tree(old) != set(snapshot['files']): raise ValueError('Old partial inventory changed or has extras')
    for name, expected in snapshot['files'].items():
        safe_name(name)
        if record(old / name) != expected: raise ValueError('Old partial bytes changed; preserve and review')


def inventory(members, workers):
    names = sorted(members)
    for name in names: safe_name(name)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        return dict(zip(names, pool.map(lambda name: record(members[name]), names)))


def copy_missing(name, source, expected, destination):
    target = Path(destination) / safe_name(name)
    if os.path.lexists(target): raise FileExistsError('New export must never overwrite a file')
    if record(source) != expected: raise ValueError('Source changed before copying')
    directory = parent_fd(target, create=True)
    h = hashlib.sha256(); size = 0
    try:
        fd = os.open(target.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory)
        with os.fdopen(fd, 'wb') as output, os.fdopen(regular_fd(source), 'rb') as incoming:
            for block in iter(lambda: incoming.read(1024**2), b''):
                output.write(block); h.update(block); size += len(block)
            output.flush(); os.fsync(output.fileno())
        os.fsync(directory)
    finally: os.close(directory)
    if {'sha256': h.hexdigest(), 'bytes': size} != expected or record(source) != expected or record(target) != expected:
        raise ValueError('Source/copy changed during copying')


def load_auditor(config):
    # Only called after exact admission. These pinned modules contain no top-level
    # dispatch; audit_closed verifies already persisted full64 outputs and score.
    sys.path.insert(0, config['old_root'])
    import export_condition
    if (Path(export_condition.__file__).resolve() != Path(config['old_exporter'])
            or Path(export_condition.run.__file__).resolve() != OLD / 'p44_runner.py'):
        raise ValueError('Foreign cached export module')
    return export_condition


def manifest_for(plan, completion, members, records):
    return {'task_id': 'P44', 'at_pacific': datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        'plan_sha256': sha(OLD / 'plan.json'), 'root_grant_sha256': sha(OLD / 'runtime_admission.json'),
        'root_adoption_sha256': sha(OLD / 'root_scientific_adoption.json'),
        'planned': 64, 'source_released_denominator': 8630, 'unreviewed_release_cases': 8554,
        'requested_thinking_enabled': plan['model_configuration']['chat_template_kwargs']['enable_thinking'],
        'observed_solver_reasoning_fields_present': completion['solver']['reasoning_present'],
        'observed_judge_reasoning_fields_present': completion['judge']['reasoning_present'],
        'native_replication': False, 'self_judging_bias': True, 'P28_P29_metrics_changed': False,
        'members': {name: {**records[name], 'original_source_path': str(members[name])} for name in sorted(members)},
        'git_publication': False, 'new_inference_calls': 0}


def recover(config_sha, auditor=None):
    config = validate(config_sha)
    cpu_job = os.environ.get('SLURM_JOB_ID', '')
    if not cpu_job.isdigit() or cpu_job == '249561': raise PermissionError('Separate finite CPU allocation identity required')
    with locked(config['old_closure_lock'], existing=True), locked(HERE / 'recovery.lock', existing=False):
        config = validate(config_sha); no_attempt(config)
        create_json(HERE / 'claim.json', {'config_sha256': config_sha, 'recovery_CPU_job_id': cpu_job,
            'independent_recovery_admission_sha256': config['_admission_sha256'], 'automatic_retry': False})
        snapshot = read(config['old_partial_snapshot']['path']); verify_partial(config, snapshot)
        auditor = load_auditor(config) if auditor is None else auditor
        plan, scores, completion, members = auditor.audit_closed(OLD)
        if scores.get('all_case_complete') is not True or scores.get('planned') != 64:
            raise ValueError('Only exact completed full64 condition can export')
        if not members or 'export_member_manifest.json' in members: raise ValueError('Invalid audited source union')
        if not set(snapshot['files']) <= set(members): raise ValueError('Old partial includes nonaudited extra files')
        records = inventory(members, config['workers'])
        destination = Path(config['output_root']); destination.mkdir(exist_ok=False)
        selected = {}
        reused = 0
        for name in sorted(members):
            partial = snapshot['files'].get(name)
            if partial == records[name]: selected[name] = Path(config['old_partial_root']) / name; reused += 1
            else: selected[name] = Path(members[name])
        names = sorted(members)
        with ThreadPoolExecutor(max_workers=config['workers']) as pool:
            list(pool.map(lambda name: copy_missing(name, selected[name], records[name], destination), names))
        # Full semantic audit and all byte inventories are repeated after the copy.
        second = auditor.audit_closed(OLD)
        if second[:3] != (plan, scores, completion) or second[3] != members or inventory(members, config['workers']) != records:
            raise ValueError('Audited source lineage changed during recovery')
        if tree(destination) != set(members): raise ValueError('Unexpected new export files')
        if inventory({name: destination / name for name in members}, config['workers']) != records:
            raise ValueError('New export differs from authoritative audited source')
        verify_partial(config, snapshot); config = validate(config_sha)
        manifest = manifest_for(plan, completion, members, records)
        create_json(destination / 'export_member_manifest.json', manifest)
        auditor.exact_tree(destination, set(members) | {'export_member_manifest.json'})
        if inventory(members, config['workers']) != records: raise ValueError('Final authoritative source drift')
        verify_partial(config, snapshot); config = validate(config_sha)
        result = {'job_id': '249561', 'config_sha256': config_sha, 'output_root': str(destination),
            'export_manifest_sha256': sha(destination / 'export_member_manifest.json'),
            'copied_members': len(members), 'planned': 64, 'recovery_CPU_job_id': cpu_job,
            'model_calls': 0, 'new_score_attempts': 0, 'old_partial_snapshot_sha256': config['old_partial_snapshot']['sha256'],
            'reused_identical_old_partial_members': reused, 'old_partial_members_preserved': len(snapshot['files']),
            'old_partial_members_not_reused': len(snapshot['files']) - reused,
            'original_export_manifest_schema_preserved': True, 'Git_or_publication_performed': False,
            'independent_recovery_admission_sha256': config['_admission_sha256']}
        create_json(HERE / 'completed.json', result)
        return result


def main():
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('--config-sha256', required=True)
    a = p.parse_args(); print(json.dumps(recover(a.config_sha256), sort_keys=True))


if __name__ == '__main__': main()
