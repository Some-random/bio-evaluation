"""One admitted P44 allocation, only after fresh locked capacity is available.

Capacity-only waits are repeatable. An actual or uncertain sbatch invocation is
claimed durably once and is never repeated. This creates no general controller.
"""
import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import subprocess
import time
from resource_authority import HERE as AMENDMENT, ORIGINAL, authorize as authorize_resources, capacity_audit as resource_capacity_audit
sys.path.insert(0, str(ORIGINAL))
from p44_runner import HERE, read, save, sha, stamp, current

ROOT = HERE.parents[4]
QUEUE = ROOT / '.local/qwen35_4b_comparison_20261022/queue/controller.py'
QUEUE_SHA256 = 'e0c371e8a0639c90436790e0f69eaca527ca2db2af3e587ac276fa4bce3aeafb'
GPU_HELPER = ROOT / 'scripts/project_gpu_audit_20261021.py'
GPU_HELPER_SHA256 = '9045eaf578e27dedcd5aba285b5a6253240244d70f52b7ad93e0dd7c0ecf9cc9'
_RESOURCE_ARGUMENTS = None

def exact(path):
    path = Path(path)
    if path != path.resolve() or not path.is_relative_to(ROOT): raise ValueError('Exact project path required')
    if path.is_symlink() or not stat.S_ISREG(path.stat().st_mode): raise ValueError('Pinned regular source required')
    return path

def durable(path, value):
    path = Path(path)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    path.chmod(0o600)
    parent_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(parent_fd)
    finally: os.close(parent_fd)

def validate(enablement_path, enablement_sha256):
    if _RESOURCE_ARGUMENTS is None: raise PermissionError('Explicit resource amendment arguments required')
    authorize_resources(**_RESOURCE_ARGUMENTS)
    if sha(exact(enablement_path)) != enablement_sha256: raise ValueError('Independent enablement changed')
    enabled = read(enablement_path)
    if enabled.get('admitted') is not True or enabled.get('issuer') in [None, '/root/bioreason_remaining_coverage']:
        raise ValueError('Owner cannot self-admit')
    if enabled.get('scope') != 'one_P44_unattempted_human64_allocation_capacity_waiter':
        raise ValueError('Wrong engineering enablement scope')
    for path, pin in enabled['artifact_sha256'].items():
        if sha(exact(path)) != pin: raise ValueError('Frozen enabled artifact changed: ' + path)
    adoption = HERE / 'root_scientific_adoption.json'
    root = read(adoption)
    plan_sha256 = sha(HERE / 'plan.json')
    if (root.get('issuer') != '/root' or root.get('adopted') is not True or
            root.get('plan_sha256') != plan_sha256 or enabled['plan_sha256'] != plan_sha256 or
            sha(adoption) != enabled['root_scientific_adoption_sha256']):
        raise ValueError('Root must adopt this exact scientific condition first')
    plan = read(HERE / 'plan.json')
    if plan['planned'] != 64 or plan['gpus_requested'] != 1 or plan['execution_scope'] != 'reviewed_P44_unattempted_human64_extension':
        raise ValueError('Only exact one-GPU new64 extension permitted')
    for path, pin in plan['frozen_files_sha256'].items():
        if sha(exact(path)) != pin: raise ValueError('Frozen scientific artifact changed')
    if sha(exact(QUEUE)) != QUEUE_SHA256 or sha(exact(GPU_HELPER)) != GPU_HELPER_SHA256:
        raise ValueError('Shared capacity observer source changed')
    return enabled, plan

def ready_comparison_requests(queue):
    """Yield to existing admitted, dispatch-ready comparison work."""
    pending = []
    with (queue.QUEUE / 'intake.lock').open('a') as intake:
        fcntl.flock(intake, fcntl.LOCK_SH)
        for path in sorted((queue.QUEUE / 'accepted').glob('*.json')):
            ticket = read(path)
            request = ticket['request']
            if ticket['request_digest'] != queue.request_digest(request):
                raise ValueError('Accepted comparison ticket changed')
            _, state_path = queue.ticket_paths(request['request_id'])
            state = read(state_path)
            if state['stage'] in queue.FINAL or state['stage'] in queue.ACTIVE:
                continue
            queue.validate_request(request)
            if all(Path(p).is_file() for p in request['wait_for_paths']):
                pending.append(request['request_id'])
    return pending

def main():
    global _RESOURCE_ARGUMENTS
    parser = argparse.ArgumentParser()
    parser.add_argument('--enablement', required=True, type=Path)
    parser.add_argument('--enablement-sha256', required=True)
    for name in ('resource-amendment-sha256', 'resource-admission-sha256', 'priority-release-sha256'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    _RESOURCE_ARGUMENTS = dict(amendment_sha256=args.resource_amendment_sha256,
        resource_admission_sha256=args.resource_admission_sha256, priority_release_sha256=args.priority_release_sha256)
    authorize_resources(**_RESOURCE_ARGUMENTS)
    observer = HERE / 'capacity_waiter_runtime'
    observer.mkdir(exist_ok=True)
    with (observer / 'singleton.lock').open('a') as singleton:
        fcntl.flock(singleton, fcntl.LOCK_EX | fcntl.LOCK_NB)
        while True:
            enabled, plan = validate(args.enablement, args.enablement_sha256)
            if (AMENDMENT / 'STOP').exists():
                current(observer / 'status.json', {'at_pacific': stamp(), 'stage': 'stopped_before_submission', 'sbatch_invoked': False})
                return
            if (HERE / 'submission_intent.json').exists() or (HERE / 'submission_receipt.json').exists():
                raise ValueError('Existing actual or ambiguous submission is never retried')
            lock_path = ROOT / '.local/evaluation_GPU_submission.lock'
            if lock_path.is_symlink(): raise ValueError('GPU lock must not be a symlink')
            with lock_path.open('a') as gpu_lock:
                fcntl.flock(gpu_lock, fcntl.LOCK_EX)
                enabled, plan = validate(args.enablement, args.enablement_sha256)
                spec = importlib.util.spec_from_file_location('p44_capacity_observer', QUEUE)
                queue = importlib.util.module_from_spec(spec); spec.loader.exec_module(queue)
                audit = resource_capacity_audit(additional=1, require_own_job=False)
                priority = ready_comparison_requests(queue)
                stage = 'yielding_to_ready_admitted_comparison' if priority else 'capacity_available' if audit['capacity_available'] else 'waiting_capacity'
                current(observer / 'status.json', {'at_pacific': stamp(), 'stage': stage,
                    'project_requested_GPUs': audit['project_requested_GPUs'], 'additional_GPUs': 1,
                    'ready_comparison_requests_with_priority': priority,
                    'project_GPU_ceiling': 8, 'sbatch_invoked': False, 'model_dispatch_observed': False})
                if audit['capacity_available'] and not priority:
                    authorize_resources(**_RESOURCE_ARGUMENTS)
                    audit_path = HERE / 'submission_gpu_audit.json'
                    durable(audit_path, audit)
                    admission_path = HERE / 'runtime_admission.json'
                    durable(admission_path, {'at_pacific': stamp(), 'issuer': enabled['issuer'], 'admitted': True, 'task_id': 'P44',
                        'scope': 'solver_and_declared_local_judge_unattempted_human64_once', 'plan_sha256': sha(HERE / 'plan.json'),
                        'gpu_count': 1, 'project_gpu_ceiling': 8, 'gpu_audit_receipt': str(audit_path),
                        'gpu_audit_receipt_sha256': sha(audit_path), 'root_scientific_adoption_sha256': sha(HERE / 'root_scientific_adoption.json'),
                        'independent_enablement_path': str(args.enablement), 'independent_enablement_sha256': args.enablement_sha256,
                        'resource_amendment_sha256': args.resource_amendment_sha256,
                        'resource_admission_sha256': args.resource_admission_sha256,
                        'resource_priority_release_sha256': args.priority_release_sha256})
                    command = ['sbatch', '--parsable', str(AMENDMENT / 'worker.sbatch'), sha(HERE / 'plan.json'), str(admission_path), sha(admission_path),
                        args.resource_amendment_sha256, args.resource_admission_sha256, args.priority_release_sha256]
                    authorize_resources(**_RESOURCE_ARGUMENTS)
                    durable(HERE / 'submission_intent.json', {'at_pacific': stamp(), 'plan_sha256': sha(HERE / 'plan.json'),
                        'command': command, 'meaning': 'One sbatch invocation about to start; ambiguous outcomes are not retryable'})
                    result = subprocess.run(command, capture_output=True, text=True, timeout=60)
                    job = result.stdout.strip().split(';')[0]
                    receipt = {'at_pacific': stamp(), 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
                        'job_id': job if re.fullmatch('[0-9]+', job) else None, 'plan_sha256': sha(HERE / 'plan.json'),
                        'admission_sha256': sha(admission_path), 'one_attempt': True, 'runtime_or_model_dispatch_inferred': False}
                    durable(HERE / 'submission_receipt.json', receipt)
                    if result.returncode or receipt['job_id'] is None: raise RuntimeError('Actual submission failed or ambiguous; do not retry')
                    current(observer / 'status.json', {'at_pacific': stamp(), 'stage': 'submitted_once_runtime_not_yet_observed', 'job_id': job,
                        'sbatch_invoked': True, 'model_dispatch_observed': False})
                    return
            time.sleep(30)

if __name__ == '__main__': main()
