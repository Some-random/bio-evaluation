"""Freeze one reviewed64 P44 condition. This never submits or invokes a model."""
import copy
from pathlib import Path
from prepare_extension import HERE, TASK, CONTRACT, load_contract, read, save, sha
import p44_runner as run

def main():
    contract, workflow = run.source_modules()
    panel = workflow.validate_prepared_bundle()
    ids = contract.validate_panel(panel)
    if len(ids) != 64: raise ValueError('Exact fixed64 extension required')
    previous = read(TASK / 'local_execution_v1/plan.json')
    plan = copy.deepcopy(previous)
    configuration = copy.deepcopy(previous['model_configuration'])
    configuration['endpoint'] = 'http://127.0.0.1:8494/v1'
    configuration['configuration_status'] = 'frozen_pending_exact_root_scientific_adoption_and_peer_admission'
    envelopes = HERE / 'solver_envelopes'
    envelopes.mkdir(exist_ok=True)
    records = []
    for index, case_id in enumerate(ids):
        packet = read(HERE / 'preparation/packets/solver' / (case_id + '.json'))
        envelope = workflow.solver_envelope(packet, configuration)
        path = envelopes / f'{index:03d}.json'
        if path.exists():
            if read(path) != envelope: raise ValueError('An already prepared solver envelope changed')
        else: save(path, envelope)
        records.append({'case_id': case_id, 'path': str(path), 'sha256': sha(path)})
    manifest = {'planned': 64, 'envelopes': records, 'complete_original_sequences': True, 'overlap_with_old12': 0}
    if (HERE / 'solver_envelopes_manifest.json').exists():
        if read(HERE / 'solver_envelopes_manifest.json') != manifest: raise ValueError('Prepared envelope manifest changed')
    else: save(HERE / 'solver_envelopes_manifest.json', manifest)
    neutral = read(TASK / 'local_execution_v1/neutral_gate_inputs.json')
    if (HERE / 'neutral_gate_inputs.json').exists():
        if read(HERE / 'neutral_gate_inputs.json') != neutral: raise ValueError('Neutral gates changed')
    else: save(HERE / 'neutral_gate_inputs.json', neutral)
    differences = previous['material_differences']
    differences[0] = 'Fixed first64 previously unattempted human entries in source order, disjoint from old12; a separately scored extension, not the full8630 release or certified author cohort.'
    differences = [s for s in differences if not s.startswith('Q96GE6')]
    differences.append('Source annotation discrepancies, missing evidence and InterPro coordinates beyond released sequence lengths are retained without correction; predictor annotations are fallible supplied inputs.')
    plan.update(created_at_pacific=run.stamp(),
        condition='BIOREASON_PRO_P44_UNATTEMPTED_HUMAN64_LOCAL_SELF_JUDGE_UNIFORM16K_V1',
        execution_scope='reviewed_P44_unattempted_human64_extension', planned=64,
        remaining_release_cases_unreviewed=8554, prior_completed_case_count=12,
        prior_condition_modified=False, prior_condition_results_pooled=False,
        run_id='qwen38_27b_p44_unattempted_human64_explanation_uniform16k_2026-10-22_v1',
        model_configuration=configuration, endpoint=configuration['endpoint'],
        panel=str(HERE / 'preparation/panel.json'),
        judge_reference_directory=str(HERE / 'preparation/packets/judge_reference'),
        solver_envelope_manifest=str(HERE / 'solver_envelopes_manifest.json'),
        neutral_gate_inputs=str(HERE / 'neutral_gate_inputs.json'),
        output_root=str(HERE / 'runtime/run_v1'), material_differences=differences)
    plan['phase_policy']['judge_stop_policy'] = 'Close with all64 denominator and primary undefined for any invalid/missing judgment'
    plan['scoring_policy']['primary'] = 'Mean of per-axis means, excluding only independently reviewed justified -1; undefined unless all64 valid'
    files = [HERE / p for p in ['prepare_extension.py', 'p44_runner.py', 'worker.py', 'worker.sbatch',
        'test_p44_runner.py', 'test_export_condition.py', 'export_condition.py', 'watch_closure.py',
        'capacity_waiter.py', 'freeze_extension.py', 'independent_scope_review.json',
        'solver_envelopes_manifest.json', 'neutral_gate_inputs.json', 'tokenizer_preflight.py',
        'preparation/offline_workflow.py', 'preparation/panel.json', 'preparation/admission.json',
        'preparation/packet_validation.json', 'preparation/review_selected_source_rows.json']]
    files += [Path(p) for p in previous['frozen_files_sha256'] if p.endswith('explanation_contract.py') or
        p.endswith('runtime_common.py') or '/.local/litqa2_replay/' in p or '/scripts/' in p]
    files += [Path(r['path']) for r in records]
    files += [HERE.parents[4] / '.local/qwen35_4b_comparison_20261022/queue/controller.py',
        HERE.parents[4] / '.local/qwen35_base_capability_20261022/root_scope_and_unrelated_job_review.json']
    files += list((HERE / 'preparation/packets/judge_reference').glob('*.json'))
    files += list((HERE / 'preparation/packets/solver').glob('*.json'))
    plan['frozen_files_sha256'] = {str(p): sha(p) for p in files}
    save(HERE / 'plan.json', plan)
    save(HERE / 'freeze_receipt.json', {'at_pacific': run.stamp(), 'plan_sha256': sha(HERE / 'plan.json'),
        'planned': 64, 'old12_modified': False, 'solver_output_tokens': 16384, 'judge_output_tokens': 16384,
        'model_calls': 0, 'jobs_submitted': 0, 'runtime_admitted': False})
    print(sha(HERE / 'plan.json'))

if __name__ == '__main__': main()
