"""Invented data only; no real candidate packets, outputs or references opened."""
import json
from pathlib import Path
import tempfile
import unittest

import export_condition as export
import p44_runner as run
from test_p44_runner import fixture, callback
from watch_closure import terminal_accounting


def complete_fixture(root):
    plan = fixture(root)
    (root / 'envelopes').rename(root / 'solver_envelopes')
    manifest = run.read(root / 'envelopes.json')
    for row in manifest['envelopes']: row['path'] = str(root / 'solver_envelopes' / Path(row['path']).name)
    (root / 'envelopes.json').write_text(json.dumps(manifest))
    plan['output_root'] = str(root / 'runtime/run_v1')
    plan['model_configuration']['max_context_tokens'] = 65536
    plan['frozen_files_sha256'] = {row['path']: run.sha(row['path']) for row in manifest['envelopes']}
    run.save(root / 'plan.json', plan)
    run.run_protocol(plan, Path(plan['output_root']), run.RecordingTransport(callback))
    for name in export.ROOT_FILES:
        if not (root / name).exists(): (root / name).write_text('Artificial fixture only')
    for name in ['submission_intent.json', 'solver_envelopes_manifest.json', 'neutral_gate_inputs.json', 'export_condition.py', 'watch_closure.py', 'test_export_condition.py']:
        if not (root / name).exists(): (root / name).write_text('Artificial fixture only')
    adoption = {'adopted': True, 'plan_sha256': run.sha(root / 'plan.json')}
    (root / 'root_scientific_adoption.json').write_text(json.dumps(adoption))
    admission = {'admitted': True, 'plan_sha256': adoption['plan_sha256'],
        'root_scientific_adoption_sha256': run.sha(root / 'root_scientific_adoption.json')}
    (root / 'runtime_admission.json').write_text(json.dumps(admission))
    run.save(root / 'submission_receipt.json', {'job_id': '77', 'plan_sha256': admission['plan_sha256'],
        'admission_sha256': run.sha(root / 'runtime_admission.json')})
    run.save(root / 'runtime/allocation_started.json', {'job_id': '77', 'plan_sha256': admission['plan_sha256']})
    raw = f'77|bio-p44-human64-extension|COMPLETED|0:0|cpu=10,gres/gpu=1,gres/gpu:a100=1|{root}|\n'
    accounting = terminal_accounting(raw, 0, '77', root)
    accounting.update(accounting_stdout=raw, accounting_return_code=0)
    run.save(root / 'closure_monitor_v2/terminal_job_receipt.json', accounting)
    return plan


class AuditChecks(unittest.TestCase):
    def test_complete_artificial_audit(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); complete_fixture(root)
            plan, scores, completion, members = export.audit_closed(root, artificial=True)
            self.assertEqual(scores['planned'], 2); self.assertTrue(completion['panel_primary_defined'])
            self.assertIn('judge/001/parsed_outcome.json', members)

    def test_extra_member_and_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root / 'one').write_text('invented')
            export.exact_tree(root, {'one'})
            (root / 'extra').write_text('unbound')
            with self.assertRaises(ValueError): export.exact_tree(root, {'one'})
            (root / 'extra').unlink(); (root / 'extra').symlink_to(root / 'one')
            with self.assertRaises(ValueError): export.exact_tree(root, {'one', 'extra'})

    def test_accounting_missing_failed_nonterminal_or_foreign_rejected(self):
        root = Path('/artificial/project')
        valid = '77|bio-p44-human64-extension|COMPLETED|0:0|gres/gpu=1|/artificial/project|\n'
        for raw, code in [('', 0), (valid, 1), (valid.replace('77|', '78|'), 0),
                (valid.replace('COMPLETED', 'RUNNING'), 0), (valid.replace('project|', 'other|'), 0),
                (valid.replace('gres/gpu=1', 'gres/gpu=2'), 0)]:
            with self.subTest(raw=raw, code=code), self.assertRaises(ValueError): terminal_accounting(raw, code, '77', root)
        self.assertTrue(terminal_accounting(valid, 0, '77', root)['verified_exact_terminal_allocation'])
        self.assertTrue(terminal_accounting(valid + '77.batch|batch|COMPLETED|0:0|cpu=10||\n', 0, '77', root)['verified_exact_terminal_allocation'])

    def test_altered_aggregate_outcome_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); plan = complete_fixture(root); path = Path(plan['output_root']) / 'solver_outcomes.json'
            value = run.read(path); value[0]['text'] = 'Altered final'; path.write_text(json.dumps(value))
            with self.assertRaises(ValueError): export.audit_closed(root, artificial=True)

    def test_altered_per_attempt_outcome_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); plan = complete_fixture(root); path = Path(plan['output_root']) / 'solver/000/outcome.json'
            value = run.read(path); value['text'] = 'Altered final'; path.write_text(json.dumps(value))
            with self.assertRaises(ValueError): export.audit_closed(root, artificial=True)

    def test_altered_dossier_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); plan = complete_fixture(root); path = Path(plan['output_root']) / 'judgments.json'
            value = run.read(path); value['ARTIFICIAL:A']['dossier']['evidence']['protein_function'] = 'Forged evidence'; path.write_text(json.dumps(value))
            with self.assertRaises(ValueError): export.audit_closed(root, artificial=True)

    def test_altered_neutral_gate_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); plan = complete_fixture(root); path = Path(plan['output_root']) / 'development_completion.json'
            value = run.read(path); value['records'][0]['judgment']['reliability'] = 1; path.write_text(json.dumps(value))
            with self.assertRaises(ValueError): export.audit_closed(root, artificial=True)

    def test_altered_root_grant_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); complete_fixture(root); path = root / 'runtime_admission.json'
            value = run.read(path); value['plan_sha256'] = 'forged'; path.write_text(json.dumps(value))
            with self.assertRaises(ValueError): export.audit_closed(root, artificial=True)


if __name__ == '__main__': unittest.main()
