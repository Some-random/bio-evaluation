| Evaluation | Qwen3.8-27B | GPT models |
| --- | --- | --- |
| PFArena — single-mutant generation,reviewed mammalian stability subset(34/123 assays) | NMS@40=0.8537157459614935; Recall@40=0.036029411764705886 | Not evaluated |

This subset result does not complete the native123-assay panel or the retained catalog.
