"""Prospective pointwise abundance adaptation; no native LLM replication claim."""
import hashlib
import importlib.util
from functools import lru_cache
import json
import math
from pathlib import Path
import re

CONDITION = "PROTEINGYM_V13_TPMT_HUMAN_ABUNDANCE_POINTWISE_QWEN_V1"
MODEL = "Qwen/Qwen3.8-27B"
ASSAY = "TPMT_HUMAN_Matreyek_2018"
NATIVE_COUNT = 3648
REFERENCE_LENGTH = 245
REFERENCE_SHA256 = "059d7c2c8feb87a96ccef6fc7f4866895687212f5bb9393c910970133e134081"
SCALAR_REGEX = r'\{"score":-?(0|[1-9][0-9]{0,5})(\.[0-9]{1,6})?\}'
GENERATION = {"temperature": 0.0, "top_p": 1.0, "seed": 42, "max_tokens": 16384, "chat_template_kwargs": {"enable_thinking": False}}
INPUT_KEYS = {"case_id", "DMS_id", "UniProt_ID", "native_source_row_index", "mutant", "reference_sequence", "mutated_sequence", "objective"}
HERE = Path(__file__).resolve().parent
INPUT_CONTRACT = HERE.parent / "tpmt_input_preparation_proposal_20261025_v1/input_contract.py"


def sha(path):
    result = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


@lru_cache(maxsize=1)
def _input_contract():
    spec = importlib.util.spec_from_file_location("tpmt_prepared_input_contract", INPUT_CONTRACT)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_input(row, *, expected_reference_sha256=REFERENCE_SHA256, expected_length=REFERENCE_LENGTH):
    if set(row) != INPUT_KEYS or row.get("DMS_id") != ASSAY or row.get("UniProt_ID") != "TPMT_HUMAN" or row.get("objective") != "intracellular_protein_abundance":
        raise ValueError("exact_abundance_input_schema_required")
    index = row["native_source_row_index"]
    if type(index) is not int or not 0 <= index < NATIVE_COUNT or row["case_id"] != f"P17::{ASSAY}::{index:08}":
        raise ValueError("exact_native_row_identity_required")
    reference = row["reference_sequence"]
    if not isinstance(reference, str) or len(reference) != expected_length or hashlib.sha256(reference.encode()).hexdigest() != expected_reference_sha256:
        raise ValueError("exact_whole_reference_required")
    _input_contract().validate_source_row({"mutant": row["mutant"], "mutated_sequence": row["mutated_sequence"]}, reference, index)
    return row


def question(row):
    validate_input(row)
    return ("Predict the intracellular protein-abundance effect of this complete human protein variant relative to its reference sequence. "
            "Return one numerical score: larger means greater intracellular protein abundance. The score is an uncalibrated prediction for retrospective ranking; it is not a measured abundance value or a validated biological function. Do not supply an explanation.\n\n"
            "Reference protein sequence:\n" + row["reference_sequence"] + "\n\nNative substitutions:\n" + row["mutant"]
            + "\n\nComplete variant protein sequence:\n" + row["mutated_sequence"]
            + '\n\nReturn exactly a compact JSON object with the single key "score" and a finite number.')


def payload(row):
    return {"model": MODEL, "messages": [{"role": "user", "content": question(row)}], **GENERATION, "structured_outputs": {"regex": SCALAR_REGEX}}


def parse_reply(raw):
    obj = json.loads(raw)
    choices = obj.get("choices")
    if not isinstance(choices, list) or len(choices) != 1:
        raise ValueError("one_completion_required")
    choice = choices[0]
    message = choice.get("message", {})
    if choice.get("finish_reason") != "stop" or any(message.get(key) for key in ["reasoning", "reasoning_content", "tool_calls", "refusal"]):
        raise ValueError("clean_nonreasoning_final_required")
    text = message.get("content")
    if not isinstance(text, str) or re.fullmatch(SCALAR_REGEX, text) is None:
        raise ValueError("exact_bounded_compact_numeric_JSON_required")
    value = json.loads(text)["score"]
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError("finite_numeric_score_required")
    return float(value)
