"""Once-only local requests; bounded concurrency, original raw records, no retry."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,FIRST_COMPLETED,wait
import datetime,hashlib,json,os,socket,threading,urllib.error,urllib.request
from zoneinfo import ZoneInfo
import protocol
MAX_CAPTURE_BYTES=8*1024*1024

def now():return datetime.datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def save(path,value,exclusive=True):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 if exclusive:
  with path.open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
 else:
  temp=path.with_suffix(path.suffix+'.tmp')
  with temp.open('w')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
  os.replace(temp,path)

def outcome_from_raw(raw):
 result={'status':'invalid_response','observed_final':False,'empty_final':False,'truncation':False,'reasoning_present':False,'tool_calls_present':False,'refusal':False,'response_errors':1,'http_errors':0,'server_errors':0,'transport_errors':0,'score':None}
 try:
  body=json.loads(raw);choices=body.get('choices',[])
  if len(choices)==1:
   c=choices[0];m=c.get('message',{});text=m.get('content');result.update(observed_final='content'in m and(text is None or isinstance(text,str)),empty_final='content'in m and(text is None or isinstance(text,str)and not text.strip()),truncation=c.get('finish_reason')=='length',reasoning_present=bool(m.get('reasoning')or m.get('reasoning_content')),tool_calls_present=bool(m.get('tool_calls')),refusal=bool(m.get('refusal')))
  result['score']=protocol.parse_reply(raw);result.update(status='delivered',response_errors=0)
 except(ValueError,KeyError,TypeError,AttributeError,IndexError):pass
 return result

def development_cases():
 return [{'case_id':'P17::artificial_numeric_copy_'+str(i),'payload':{'model':protocol.MODEL,'messages':[{'role':'user','content':'Return exactly this compact JSON, with no explanation: '+text}],**protocol.GENERATION,'structured_outputs':{'regex':protocol.SCALAR_REGEX}},'expected_score':score}for i,(text,score)in enumerate([('{"score":0}',0.0),('{"score":-2.5}',-2.5),('{"score":123.125}',123.125)])]

def run_phase(*,plan_sha,endpoint,folder,phase,cases,assert_owned_server,workers=8,opener_factory=None):
 folder=Path(folder);folder.mkdir(exist_ok=False)
 for name in ['requests','responses','outcomes']:(folder/name).mkdir()
 total=len(cases);expected_ids=[r['case_id']for r in cases]
 if len(set(expected_ids))!=total:raise ValueError('Frozen case IDs must be unique')
 opener_factory=opener_factory or(lambda:urllib.request.build_opener(urllib.request.ProxyHandler({})))
 attempted=0;outcomes=[];halted=False;counter_lock=threading.Lock();stop_event=threading.Event()
 def request_one(case):
  nonlocal attempted
  if stop_event.is_set():return None
  assert_owned_server()
  if stop_event.is_set():return None
  key=hashlib.sha256(case['case_id'].encode()).hexdigest()
  payload=case['payload']if phase=='development'else protocol.payload(case)
  if stop_event.is_set():return None
  save(folder/'requests'/(key+'.json'),{'case_id':case['case_id'],'payload':payload})
  request=urllib.request.Request(endpoint+'/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
  try:
   with counter_lock:attempted+=1
   with opener_factory().open(request,timeout=1200)as response:raw=response.read(MAX_CAPTURE_BYTES+1)
   with(folder/'responses'/(key+'.raw.json')).open('xb')as f:f.write(raw)
   if len(raw)>MAX_CAPTURE_BYTES:result={'status':'response_size_exceeded','observed_final':False,'empty_final':False,'response_errors':1,'raw_capture_complete':False,'score':None}
   else:result=outcome_from_raw(raw)
   result['response_saved']=True
  except urllib.error.HTTPError as error:
   raw=error.read(MAX_CAPTURE_BYTES+1)
   with(folder/'responses'/(key+'.http_error.raw')).open('xb')as f:f.write(raw)
   result={'status':'HTTP_failure','http_errors':1,'server_errors':int(error.code>=500),'http_status':error.code,'observed_final':False,'empty_final':False,'score':None,'response_saved':False,'server_acceptance_unknown':True}
  except(urllib.error.URLError,TimeoutError,OSError)as error:
   result={'status':'transport_failure','transport_errors':1,'error_type':type(error).__name__,'observed_final':False,'empty_final':False,'score':None,'response_saved':False,'server_acceptance_unknown':True}
  result.update(case_id=case['case_id'],attempted=True,not_dispatched=False)
  if phase=='development':result['artificial_exact_copy_passed']=result['status']=='delivered'and result['score']==case['expected_score']
  if result['status']!='delivered'or phase=='development'and result.get('artificial_exact_copy_passed')is not True:stop_event.set()
  save(folder/'outcomes'/(key+'.json'),result)
  return result
 def counts():
  return {'planned':total,'attempted_confirmed':attempted,'terminal':len(outcomes),'not_dispatched':total-attempted,'responses_saved':sum(x.get('response_saved',False)for x in outcomes),'delivery_passed':sum(x['status']=='delivered'for x in outcomes),'empty_finals':sum(x.get('empty_final',False)for x in outcomes),'unknown_finals':sum(not x.get('observed_final',False)for x in outcomes),'http_errors':sum(x.get('http_errors',0)for x in outcomes),'server_errors':sum(x.get('server_errors',0)for x in outcomes),'transport_errors':sum(x.get('transport_errors',0)for x in outcomes),'response_errors':sum(x.get('response_errors',0)for x in outcomes),'truncations':sum(x.get('truncation',False)for x in outcomes),'refusals':sum(x.get('refusal',False)for x in outcomes),'reasoning_present':sum(x.get('reasoning_present',False)for x in outcomes),'tool_calls_present':sum(x.get('tool_calls_present',False)for x in outcomes)}
 def progress():save(folder/'progress.json',{'at_pacific':now(),'task_id':'P17','phase':phase,'role':'direct_unsealed_progress_lower_bound','plan_sha256':plan_sha,**counts()},exclusive=False)
 # Development is sequential and stops after the first failed exact-copy check.
 # Any benchmark delivery error stops creating requests and drains
 # already submitted futures. No previous request is ever retried or resumed.
 with ThreadPoolExecutor(max_workers=1 if phase=='development'else workers)as executor:
  pending={};position=0;limit=1 if phase=='development'else workers
  while position<total or pending:
   while not halted and not stop_event.is_set()and position<total and len(pending)<limit:
    case=cases[position];position+=1;pending[executor.submit(request_one,case)]=case['case_id']
   progress()
   if not pending:break
   done,_=wait(pending,return_when=FIRST_COMPLETED)
   for future in done:
    pending.pop(future);result=future.result()
    if result is None:continue
    outcomes.append(result)
    if phase=='development'and result.get('artificial_exact_copy_passed')is not True:halted=True
    if result['status']!='delivered':halted=True
   progress()
 lock={'task_id':'P17','phase':phase,'planned':total,'plan_sha256':plan_sha,'reference_labels_opened':False,'files_sha256':{str(p.relative_to(folder)):protocol.sha(p)for base in ['requests','responses','outcomes']for p in sorted((folder/base).iterdir())if p.is_file()}}
 save(folder/'prediction_lock.json',lock)
 completion={'at_pacific':now(),'task_id':'P17','phase':phase,'plan_sha256':plan_sha,**counts(),'prediction_lock_sha256':protocol.sha(folder/'prediction_lock.json'),'all_delivered':len(outcomes)==total and all(r['status']=='delivered'for r in outcomes),'artificial_exact_copy_gate_passed':len(outcomes)==total and all(r.get('artificial_exact_copy_passed')is True for r in outcomes)if phase=='development'else None,'stopped_new_requests_after_fatal_failure':halted,'one_attempt_per_case':True}
 save(folder/'completion.json',completion);return completion
