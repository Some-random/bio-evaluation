"""Pure input/isolation contract; adapted from existing P17 input validation.

No prompt, model, decoding setting, scoring formula or reference target reader is
defined. Biological strings occur only in future admitted private input files.
"""
import hashlib
import json
import os
from pathlib import Path
import re

ASSAY = "TPMT_HUMAN_Matreyek_2018"
OBJECTIVE = "intracellular_protein_abundance"
AA = frozenset("ACDEFGHIKLMNPQRSTVWY")
SOURCE_INPUT_FIELDS = ("mutant", "mutated_sequence")
INPUT_FIELDS = frozenset({"case_id", "DMS_id", "UniProt_ID", "native_source_row_index", "mutant", "reference_sequence", "mutated_sequence", "objective"})


class ContractError(ValueError):
    def __init__(self, code, row_index=None):
        super().__init__(code)
        self.code = code
        self.row_index = row_index


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def private_json(path, value):
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "w") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")


def validate_reference(meta, expected_metadata):
    for field, expected in expected_metadata.items():
        if meta.get(field) != expected:
            raise ContractError("exact_reference_metadata_mismatch")
    if meta.get("DMS_id") != ASSAY or meta.get("UniProt_ID") != "TPMT_HUMAN":
        raise ContractError("exact_single_assay_required")
    try:
        length = int(meta["seq_len"])
        count = int(meta["DMS_total_number_mutants"])
    except (ValueError, KeyError, TypeError):
        raise ContractError("native_reference_dimension_invalid") from None
    sequence = meta.get("target_seq")
    if not isinstance(sequence, str) or not sequence or set(sequence) - AA or len(sequence) != length or count <= 0:
        raise ContractError("whole_native_reference_required")
    return sequence, count


def validate_source_row(source, reference, row_index):
    if set(source) != set(SOURCE_INPUT_FIELDS):
        raise ContractError("only_native_input_columns_permitted", row_index)
    mutant = source["mutant"]
    sequence = source["mutated_sequence"]
    if not isinstance(mutant, str) or not isinstance(sequence, str) or len(sequence) != len(reference) or set(sequence) - AA:
        raise ContractError("whole_native_variant_required", row_index)
    expected = list(reference)
    seen_positions = set()
    for substitution in mutant.split(":"):
        match = re.fullmatch(r"([ACDEFGHIKLMNPQRSTVWY])([1-9][0-9]*)([ACDEFGHIKLMNPQRSTVWY])", substitution)
        if match is None:
            raise ContractError("native_substitution_syntax_invalid", row_index)
        before, position, after = match.groups()
        index = int(position) - 1
        if index >= len(reference) or index in seen_positions or reference[index] != before:
            raise ContractError("native_variant_identity_invalid", row_index)
        seen_positions.add(index)
        expected[index] = after
    if "".join(expected) != sequence:
        raise ContractError("native_variant_identity_invalid", row_index)
    return source


def write_inputs(output, meta, expected_metadata, source_rows):
    """Called only after source access is admitted by the separate guarded CLI.

    Preserves source order and every native row; writes no targets. A failure
    keeps private partial artifacts and a sanitized marker, never auto-retries.
    """
    reference, native_count = validate_reference(meta, expected_metadata)
    output = Path(output)
    output.mkdir(mode=0o700, parents=False, exist_ok=False)
    destination = output / "inputs.jsonl"
    identities = output / "row_identity_hashes.jsonl"
    seen = set()
    count = 0
    try:
        input_fd = os.open(destination, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        audit_fd = os.open(identities, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(input_fd, "w") as solver, os.fdopen(audit_fd, "w") as audit:
            for index, source in enumerate(source_rows):
                validate_source_row(source, reference, index)
                mutant_hash = canonical_hash(source["mutant"])
                if mutant_hash in seen:
                    raise ContractError("duplicate_native_variant_identifier", index)
                seen.add(mutant_hash)
                case_id = "P17::" + ASSAY + "::" + str(index).zfill(8)
                case = {"case_id": case_id, "DMS_id": ASSAY, "UniProt_ID": "TPMT_HUMAN", "native_source_row_index": index, "mutant": source["mutant"], "reference_sequence": reference, "mutated_sequence": source["mutated_sequence"], "objective": OBJECTIVE}
                if set(case) != INPUT_FIELDS:
                    raise ContractError("input_schema_invalid", index)
                solver.write(json.dumps(case, separators=(",", ":")) + "\n")
                audit.write(json.dumps({"case_id": case_id, "native_source_row_index": index, "source_input_identity_sha256": canonical_hash({"DMS_id": ASSAY, "native_source_row_index": index, **source})}, separators=(",", ":")) + "\n")
                count += 1
        if count != native_count:
            raise ContractError("complete_native_denominator_mismatch")
        result = {"role": "private_prepared_native_inputs_only_not_model_runtime_or_scoring_admission", "DMS_id": ASSAY, "objective": OBJECTIVE, "native_source_order_preserved": True, "native_metadata_declared_rows": native_count, "prepared_rows": count, "whole_reference_length": len(reference), "whole_reference_sha256": hashlib.sha256(reference.encode()).hexdigest(), "input_sha256": digest(destination), "row_identity_hashes_sha256": digest(identities), "source_input_columns": list(SOURCE_INPUT_FIELDS), "protected_target_columns_materialized": False, "protected_target_file_created": False, "model_requests_or_outputs_created": False, "scientific_condition_adopted": False}
        private_json(output / "input_manifest.json", result)
        return result
    except Exception as exc:
        code = exc.code if isinstance(exc, ContractError) else "preparation_failed"
        private_json(output / "failure.json", {"role": "sanitized_preserved_failed_preparation_no_auto_retry", "error_code": code, "row_index": exc.row_index if isinstance(exc, ContractError) else None, "partial_artifacts_preserved": True, "safe_to_retry_inferred": False})
        raise ContractError(code, exc.row_index if isinstance(exc, ContractError) else None) from None
