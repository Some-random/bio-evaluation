"""CSV projection derived from the independently reviewed metadata projector.

Only requested field values are constructed. If selected_ids is supplied, only
the ID field is constructed until a row is selected. This module does not open
files and has no model, target, request or response interface.
"""
import csv
from io import StringIO


class ProjectionError(ValueError):
    pass


def projected_rows(stream, fields, *, id_field=None, selected_ids=None):
    header = next(csv.reader(StringIO(stream.readline())))
    if len(set(header)) != len(header) or any(x not in header for x in fields):
        raise ProjectionError("source_schema_invalid")
    if selected_ids is not None and (id_field not in fields or id_field not in header):
        raise ProjectionError("selection_schema_invalid")
    indexes = {header.index(name): name for name in fields}
    id_index = header.index(id_field) if id_field else None
    if selected_ids is not None and any(i < id_index for i in indexes):
        raise ProjectionError("selection_field_must_precede_retained_values")
    selected_seen = set()
    row = {}
    value = []
    column = 0
    quoted = False
    after_quote = False
    accepted = selected_ids is None
    row_started = False

    def capture():
        return column == id_index or (accepted and column in indexes)

    def end_field():
        nonlocal value, column, accepted
        if selected_ids is not None and column == id_index:
            item = "".join(value)
            accepted = item in selected_ids
            if accepted:
                if item in selected_seen:
                    raise ProjectionError("duplicate_selected_source_id")
                selected_seen.add(item)
                row[id_field] = item
        elif accepted and column in indexes:
            row[indexes[column]] = "".join(value)
        value = []
        column += 1

    def end_row():
        nonlocal row, column, accepted, row_started
        end_field()
        if column != len(header):
            raise ProjectionError("source_column_count_invalid")
        result = row if accepted else None
        if result is not None and set(result) != set(fields):
            raise ProjectionError("source_projection_incomplete")
        row = {}
        column = 0
        accepted = selected_ids is None
        row_started = False
        return result

    while True:
        char = stream.read(1)
        if not char:
            if quoted and not after_quote:
                raise ProjectionError("unclosed_source_quote")
            if row_started:
                result = end_row()
                if result is not None:
                    yield result
            break
        row_started = True
        if quoted:
            if after_quote:
                if char == '"':
                    if capture():
                        value.append('"')
                    after_quote = False
                    continue
                quoted = False
                after_quote = False
                if char not in ",\r\n":
                    raise ProjectionError("invalid_source_quote_boundary")
            elif char == '"':
                after_quote = True
                continue
            else:
                if capture():
                    value.append(char)
                continue
        if char == '"':
            if value:
                raise ProjectionError("invalid_source_quote")
            quoted = True
        elif char == ',':
            end_field()
        elif char == '\n':
            result = end_row()
            if result is not None:
                yield result
        elif char == '\r':
            continue
        elif capture():
            value.append(char)
    if selected_ids is not None and selected_seen != set(selected_ids):
        raise ProjectionError("selected_source_id_absent")
