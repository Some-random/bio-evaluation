"""CPU-only installed request/grammar validation; never loads model weights."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata as metadata
import json
import os

import scorer

protocol, runner = scorer.protocol, scorer.runner


def check(plan, output):
    if os.environ.get("CUDA_VISIBLE_DEVICES") != "":
        raise PermissionError("CPU_only_API_check_required")
    expected = {"vllm":"0.32.0", "torch":"2.13.0", "transformers":"5.17.0", "triton":"3.7.1", "flashinfer-python":"0.7.0.post1", "xgrammar":"0.2.8"}
    packages = {name: metadata.version(name) for name in expected}
    if packages != expected:
        raise ValueError("exact_installed_runtime_packages_required")
    from transformers import AutoTokenizer
    from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest
    from vllm.sampling_params import StructuredOutputsParams
    import xgrammar as xgr
    import torch
    tokenizer = AutoTokenizer.from_pretrained(plan["model_directory"], local_files_only=True, trust_remote_code=False)
    compiler = xgr.GrammarCompiler(xgr.TokenizerInfo.from_huggingface(tokenizer), max_threads=2)
    grammar = compiler.compile_regex(protocol.SCALAR_REGEX)
    valid = ['{"score":0}', '{"score":-2.5}', '{"score":123.125}']
    invalid = ['{"score":NaN}', '{"score":1e3}', '{"score":01}', '{"score":1.1234567}', '{"score":0}x']
    for text in valid:
        if not xgr.GrammarMatcher(grammar).accept_string(text):
            raise ValueError("finite_scalar_grammar_acceptance_failed")
    for text in invalid:
        if xgr.GrammarMatcher(grammar).accept_string(text):
            raise ValueError("finite_scalar_grammar_rejection_failed")
    def validate(body):
        parsed = ChatCompletionRequest.model_validate(body)
        if parsed.structured_outputs.regex != protocol.SCALAR_REGEX or StructuredOutputsParams(regex=protocol.SCALAR_REGEX).regex != protocol.SCALAR_REGEX:
            raise ValueError("native_structured_API_mapping_changed")
    for case in runner.development_cases():
        validate(case["payload"])
    record = json.loads(Path(plan["input_manifest"]).read_text())["assays"][0]
    ledger = [json.loads(line) for line in Path(plan["prepared_payload_hash_ledger"]).read_text().splitlines()]
    count = 0
    with Path(record["input_path"]).open() as source:
        for index, line in enumerate(source):
            case = json.loads(line)
            request = protocol.payload(case)
            validate(request)
            digest = hashlib.sha256(json.dumps(request, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            item = ledger[index]
            if (case["native_source_row_index"] != index or item["case_id"] != case["case_id"] or item["native_source_row_index"] != index or item["prepared_payload_sha256"] != digest or item["intact_native_prompt_tokens"] + 16384 > 65536):
                raise ValueError("full_payload_context_ledger_binding_changed")
            count += 1
    if count != 5083 or len(ledger) != count:
        raise ValueError("full_native_API_denominator_required")
    flags = torch._C._cuda_getArchFlags().split()
    if not {"sm_80", "sm_100"}.issubset(flags):
        raise ValueError("A100_B200_compiled_torch_support_required")
    config = json.loads((Path(plan["model_directory"]) / "config.json").read_text())
    from vllm.model_executor.models import ModelRegistry
    architectures = config["architectures"]
    if not all(architecture in ModelRegistry.get_supported_archs() for architecture in architectures):
        raise ValueError("checkpoint_architecture_not_supported_by_exact_vllm")
    runner.save(output, {"role":"CPU_actual_installed_API_regex_and_full_payload_binding_not_runtime_release", "packages":packages, "native_API_requests_checked":count, "artificial_API_requests_checked":3, "regex_valid_examples":len(valid), "regex_invalid_examples":len(invalid), "CPU_context_receipt_sha256":protocol.sha(plan["CPU_validation"]), "prepared_payload_hash_ledger_sha256":protocol.sha(plan["prepared_payload_hash_ledger"]), "supported_checkpoint_architectures":architectures, "torch_compiled_GPU_architectures":flags, "actual_allocated_GPU_validation_pending":True, "model_calls":0, "model_forwards":0, "model_weights_loaded":False, "protected_targets_read":False})


if __name__ == "__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--plan",type=Path,required=True);parser.add_argument("--output",type=Path,required=True);args=parser.parse_args()
    try:
        check(json.loads(args.plan.read_text()), args.output)
    except Exception as error:
        print(json.dumps({"error_code":"CPU_installed_API_gate_failed", "error_type":type(error).__name__, "model_calls":0}))
        raise SystemExit(2)
