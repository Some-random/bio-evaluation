"""Once-only exact PTEN abundance scoring, after admitted sealed predictions.

Importing this module loads generic code only. The CLI must validate the exact
plan, independent grant, root adoption and frozen code before any input or
protected target is read. Protected measurements are never written or logged.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import re
import sys
import zipfile

HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent / "pten_abundance_condition_candidate_20261026_v1"
NATIVE_COUNT = 5083
ASSAY = "PTEN_HUMAN_Matreyek_2021"
UNIPROT = "PTEN_HUMAN"
ARCHIVE_MEMBER = "DMS_ProteinGym_substitutions/" + ASSAY + ".csv"
MODEL_REVISION = "1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0"
PROJECTION_SOURCE = HERE.parent / "pten_input_preparation_proposal_20261026_v3/projected_csv.py"
STABLE_SOURCE = HERE.parent / "pten_input_preparation_proposal_20261026_v3/stable_source.py"


class ScoringError(ValueError):
    """Fixed safe error codes, without row values or exception representations."""


def _module(name, path, dependencies=None):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    previous = {}
    for key, value in (dependencies or {}).items():
        previous[key] = sys.modules.get(key)
        sys.modules[key] = value
    try:
        spec.loader.exec_module(module)
    finally:
        for key, value in previous.items():
            if value is None:
                sys.modules.pop(key, None)
            else:
                sys.modules[key] = value
    return module


protocol = _module("p17_pten_scoring_protocol", CANDIDATE / "protocol.py")
runner = _module("p17_pten_scoring_runner", CANDIDATE / "runner.py", {"protocol": protocol})
metric = _module("p17_pten_scoring_metric", CANDIDATE / "singleton_metric_contract.py")


def _now():
    return datetime.now(timezone.utc).isoformat()


def _exclusive_json(path, value):
    """A durable exclusive claim remains present after every failure or crash."""
    path = Path(path)
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "w") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    directory_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def _read_json(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ScoringError("regular_frozen_file_required")
    return json.loads(path.read_bytes())


def _digest_required(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def _require_pinned_file(plan, path):
    path = Path(path)
    pin = plan["frozen_files_sha256"].get(str(path))
    if not _digest_required(pin) or path.is_symlink() or not path.is_file() or protocol.sha(path) != pin:
        raise ScoringError("exact_frozen_file_pin_required")


def _validate_plan_metadata(plan):
    if (plan.get("task_id") != "P17" or plan.get("condition") != protocol.CONDITION
            or plan.get("expected_native_variants") != NATIVE_COUNT
            or plan.get("reviewed_assays") != 1):
        raise ScoringError("exact_singleton_native_plan_required")
    if (plan.get("model") != protocol.MODEL or plan.get("model_revision") != MODEL_REVISION
            or plan.get("dtype") != "bfloat16" or plan.get("context_limit") != 65536
            or plan.get("generation") != protocol.GENERATION):
        raise ScoringError("frozen_scientific_condition_changed")
    for key, source in [("protocol_source", CANDIDATE / "protocol.py"),
                        ("runner_source", CANDIDATE / "runner.py"),
                        ("metric_contract_source", CANDIDATE / "singleton_metric_contract.py")]:
        if Path(plan[key]) != source:
            raise ScoringError("exact_adopted_source_module_required")
        _require_pinned_file(plan, source)
    _require_pinned_file(plan, plan["input_manifest"])
    adoption = Path(plan["root_scientific_adoption"])
    if (not _digest_required(plan.get("root_scientific_adoption_sha256"))
            or adoption.is_symlink() or not adoption.is_file()
            or protocol.sha(adoption) != plan["root_scientific_adoption_sha256"]):
        raise ScoringError("exact_root_scientific_adoption_binding_required")
    if not _digest_required(plan.get("native_archive_sha256")):
        raise ScoringError("pinned_native_archive_required")


def _read_assays(plan):
    manifest = _read_json(plan["input_manifest"])
    records = manifest.get("assays")
    if not isinstance(records, list) or len(records) != 1:
        raise ScoringError("exact_singleton_input_manifest_required")
    record = records[0]
    if (record.get("DMS_id") != ASSAY or record.get("UniProt_ID") != UNIPROT
            or record.get("source_archive_member") != ARCHIVE_MEMBER
            or record.get("planned_native_variants") != NATIVE_COUNT):
        raise ScoringError("exact_singleton_source_record_required")
    path = Path(record["input_path"])
    _require_pinned_file(plan, path)
    if protocol.sha(path) != record["input_sha256"]:
        raise ScoringError("exact_native_input_digest_required")
    cases = []
    with path.open() as handle:
        for index, line in enumerate(handle):
            case = json.loads(line)
            protocol.validate_input(case)
            if index >= NATIVE_COUNT or case["native_source_row_index"] != index:
                raise ScoringError("exact_native_source_order_required")
            cases.append(case)
    if len(cases) != NATIVE_COUNT:
        raise ScoringError("complete_native_input_denominator_required")
    return [{**record, "cases": cases}]


def verified_predictions(assays, run, lock, done):
    """Reused old P17 wire/raw/outcome verifier with exact directory coverage.

    A resealed wrong question, altered outcome, undeclared attempt, truncated
    capture or absent raw final cannot supply a native prediction.
    """
    run = Path(run)
    cases = [case for assay in assays for case in assay["cases"]]
    expected = {hashlib.sha256(c["case_id"].encode()).hexdigest(): c for c in cases}
    if len(expected) != len(cases):
        raise ScoringError("duplicate_frozen_case_identity")
    kinds = {"requests": {}, "outcomes": {}, "raw": {}, "http": {}}
    files = lock.get("files_sha256")
    if not isinstance(files, dict):
        raise ScoringError("exact_sealed_member_map_required")
    for rel, digest in files.items():
        path = run / rel
        parts = Path(rel).parts
        if (len(parts) != 2 or Path(rel).is_absolute() or ".." in parts
                or path.is_symlink() or not path.is_file()
                or not _digest_required(digest) or protocol.sha(path) != digest):
            raise ScoringError("unsafe_or_changed_sealed_attempt_member")
        directory, name = parts
        if directory == "requests" and name.endswith(".json"):
            kind, key = "requests", name[:-5]
        elif directory == "outcomes" and name.endswith(".json"):
            kind, key = "outcomes", name[:-5]
        elif directory == "responses" and name.endswith(".raw.json"):
            kind, key = "raw", name[:-9]
        elif directory == "responses" and name.endswith(".http_error.raw"):
            kind, key = "http", name[:-15]
        else:
            raise ScoringError("unknown_sealed_attempt_member")
        if key not in expected or key in kinds[kind]:
            raise ScoringError("foreign_or_duplicate_sealed_attempt_identity")
        kinds[kind][key] = path
    actual = set()
    for directory in ("requests", "responses", "outcomes"):
        base = run / directory
        if base.is_symlink() or not base.is_dir():
            raise ScoringError("exact_regular_attempt_directories_required")
        for path in base.iterdir():
            if path.is_symlink() or not path.is_file():
                raise ScoringError("unexpected_nested_or_linked_attempt_member")
            actual.add(str(path.relative_to(run)))
    if actual != set(files):
        raise ScoringError("unsealed_attempt_directory_member")
    if (set(kinds["requests"]) != set(kinds["outcomes"])
            or set(kinds["raw"]) & set(kinds["http"])
            or not (set(kinds["raw"]) | set(kinds["http"])) <= set(kinds["requests"])):
        raise ScoringError("exact_request_attempt_outcome_provenance_required")
    if (done.get("planned") != len(cases)
            or done.get("attempted_confirmed") != len(kinds["requests"])
            or done.get("terminal") != len(kinds["outcomes"])
            or done.get("responses_saved") != len(kinds["raw"])
            or done.get("not_dispatched") != len(cases) - len(kinds["requests"])):
        raise ScoringError("sealed_attempt_count_denominator_mismatch")
    predictions = {}
    for key, path in kinds["outcomes"].items():
        case = expected[key]
        request = _read_json(kinds["requests"][key])
        outcome = _read_json(path)
        if request != {"case_id": case["case_id"], "payload": protocol.payload(case)}:
            raise ScoringError("sealed_wire_request_differs_from_frozen_whole_question")
        if (outcome.get("case_id") != case["case_id"] or outcome.get("attempted") is not True
                or outcome.get("not_dispatched") is not False
                or bool(outcome.get("response_saved")) != (key in kinds["raw"])):
            raise ScoringError("case_attempt_outcome_provenance_mismatch")
        if key in kinds["raw"]:
            raw = kinds["raw"][key].read_bytes()
            if len(raw) > runner.MAX_CAPTURE_BYTES:
                if (outcome.get("status") != "response_size_exceeded"
                        or outcome.get("raw_capture_complete") is not False
                        or outcome.get("observed_final") is not False
                        or outcome.get("empty_final") is not False or outcome.get("score") is not None):
                    raise ScoringError("exact_oversized_unknown_final_provenance_required")
                continue
            parsed = runner.outcome_from_raw(raw)
            for field in ("status", "observed_final", "empty_final", "truncation",
                          "reasoning_present", "tool_calls_present", "refusal", "score"):
                if outcome.get(field) != parsed.get(field):
                    raise ScoringError("sealed_raw_final_differs_from_recorded_outcome")
            if parsed["status"] == "delivered":
                predictions[case["case_id"]] = parsed["score"]
        elif outcome.get("status") == "delivered":
            raise ScoringError("delivered_prediction_requires_original_raw_final")
    return predictions


def _validate_completion(run, plan_sha):
    done = _read_json(run / "completion.json")
    lock = _read_json(run / "prediction_lock.json")
    if (done.get("task_id") != "P17" or lock.get("task_id") != "P17"
            or done.get("phase") != "benchmark" or lock.get("phase") != "benchmark"
            or done.get("planned") != NATIVE_COUNT or lock.get("planned") != NATIVE_COUNT
            or done.get("plan_sha256") != plan_sha or lock.get("plan_sha256") != plan_sha
            or lock.get("reference_labels_opened") is not False
            or done.get("one_attempt_per_case") is not True
            or protocol.sha(run / "prediction_lock.json") != done.get("prediction_lock_sha256")):
        raise ScoringError("exact_plan_bound_benchmark_prediction_seal_required")
    return done, lock


def _read_protected_references(plan, assay, run, claim_binding):
    # This durable reader claim is created only by the sealed all-valid metric
    # loader. A crash or source error leaves both once-only claims in place.
    scoring_claim = _read_json(run / "sole_scoring_claim.json")
    if (any(scoring_claim.get(key) != value for key, value in claim_binding.items())
            or scoring_claim.get("role") != "exclusive_once_only_native_scoring_attempt"
            or scoring_claim.get("valid_native_predictions") != NATIVE_COUNT
            or scoring_claim.get("exact_plan_bound_raw_request_outcome_validation_complete") is not True
            or scoring_claim.get("all_original_attempts_sealed") is not True):
        raise ScoringError("full_valid_exact_scoring_claim_required_before_protected_reader")
    _exclusive_json(run / "protected_target_read_claim.json", {
        **claim_binding, "at_utc": _now(), "role": "sole_protected_target_reader_claim",
        "native_archive_sha256": plan["native_archive_sha256"],
        "target_values_persisted": False,
    })
    try:
        archive_path = Path(plan["native_archive"])
        _require_pinned_file(plan, STABLE_SOURCE)
        stable = _module("p17_pten_protected_stable_source", STABLE_SOURCE)
        values = {}
        cases = assay["cases"]
        # Hash, permitted ZIP read and final verification retain one no-follow
        # descriptor; no path re-open can substitute a different archive.
        with stable.StableSource(archive_path, plan["native_archive_sha256"]) as held:
            with zipfile.ZipFile(held.stream) as archive:
                if sum(info.filename == ARCHIVE_MEMBER for info in archive.infolist()) != 1:
                    raise ScoringError("exact_single_native_source_member_required")
                with archive.open(ARCHIVE_MEMBER) as stream:
                    _require_pinned_file(plan, PROJECTION_SOURCE)
                    projection = _module("p17_pten_protected_projection", PROJECTION_SOURCE)
                    reader = projection.projected_rows(io.TextIOWrapper(stream), ("mutant", "mutated_sequence", "DMS_score"))
                    for index, row in enumerate(reader):
                        if (index >= len(cases) or cases[index]["native_source_row_index"] != index
                                or row["mutant"] != cases[index]["mutant"]
                                or row["mutated_sequence"] != cases[index]["mutated_sequence"]):
                            raise ScoringError("native_source_index_mutant_whole_variant_join_mismatch")
                        try:
                            value = float(row["DMS_score"])
                        except (TypeError, ValueError, OverflowError):
                            raise ScoringError("finite_native_reference_required") from None
                        if not math.isfinite(value):
                            raise ScoringError("finite_native_reference_required")
                        values[cases[index]["case_id"]] = value
            if len(values) != NATIVE_COUNT:
                raise ScoringError("complete_native_reference_denominator_required")
            held.verify()
        return values
    except ScoringError:
        raise
    except Exception:
        raise ScoringError("protected_native_source_read_failed") from None


def _score_admitted(plan, run, plan_sha, grant_sha):
    """Internal implementation, reached only after public admission succeeds."""
    run = Path(run)
    expected_run = Path(plan["runtime_root"]) / "benchmark"
    if run != expected_run or run.is_symlink() or not run.is_dir():
        raise ScoringError("exact_frozen_benchmark_runtime_required")
    for marker in ("sole_scoring_claim.json", "protected_target_read_claim.json", "scores.json", "scoring_failure.json"):
        if (run / marker).exists() or (run / marker).is_symlink():
            raise ScoringError("existing_scoring_or_target_claim_preserved_no_retry")
    done, lock = _validate_completion(run, plan_sha)
    assays = _read_assays(plan)
    predictions = verified_predictions(assays, run, lock, done)
    binding = {"task_id": "P17", "condition": protocol.CONDITION,
               "plan_sha256": plan_sha, "engineering_admission_sha256": grant_sha,
               "prediction_lock_sha256": done["prediction_lock_sha256"],
               "native_denominator": NATIVE_COUNT}
    _exclusive_json(run / "sole_scoring_claim.json", {
        **binding, "at_utc": _now(), "role": "exclusive_once_only_native_scoring_attempt",
        "exact_plan_bound_raw_request_outcome_validation_complete": True,
        "all_original_attempts_sealed": True,
        "valid_native_predictions": len(predictions),
        "protected_targets_opened": False, "automatic_retry_allowed": False,
    })
    try:
        seal = {"exact_plan_bound_raw_request_outcome_validation_complete": True,
                "all_original_attempts_sealed": True,
                "planned_native_variants": NATIVE_COUNT, "sole_scoring_claim_admitted": True}
        result = metric.native_singleton_after_complete_seal(
            [case["case_id"] for case in assays[0]["cases"]], predictions, seal,
            lambda: _read_protected_references(plan, assays[0], run, binding))
        result.update(
            task_id="P17", condition=protocol.CONDITION, reviewed_assays=1,
            native_release_assays=217, full_native_benchmark_complete=False,
            native_coarse_selection_type="Expression",
            planned_native_variants=NATIVE_COUNT,
            attempted_confirmed=done["attempted_confirmed"], terminal=done["terminal"],
            not_dispatched=done["not_dispatched"], valid_native_predictions=len(predictions),
            invalid_or_missing_native_predictions=NATIVE_COUNT - len(predictions),
            prediction_lock_sha256=done["prediction_lock_sha256"],
            plan_sha256=plan_sha, engineering_admission_sha256=grant_sha,
            root_scientific_adoption_sha256=plan["root_scientific_adoption_sha256"],
            source_metric_contract_sha256=plan["frozen_files_sha256"][str(CANDIDATE / "singleton_metric_contract.py")],
            no_old30_or_separate9_pooling=True, no_TPMT_pooling=True, no_PRKN_pooling=True, no_new_training=True,
            no_native_LLM_prompt_or_historical_ProtST_replication=True,
            protected_target_values_persisted=False,
        )
        _exclusive_json(run / "scores.json", result)
        return result
    except BaseException:
        # Do not serialize source exceptions, CSV cells, sequences or values.
        try:
            _exclusive_json(run / "scoring_failure.json", {
                **binding, "at_utc": _now(), "error_code": "sole_scoring_attempt_failed",
                "claims_and_partial_artifacts_preserved": True, "automatic_retry_allowed": False,
                "protected_target_values_persisted": False,
            })
        except OSError:
            pass
        raise ScoringError("sole_scoring_attempt_failed_no_automatic_retry") from None


def score(plan_path, plan_sha, grant_path, grant_sha, run=None):
    """Validate exact independent admission before input or target access."""
    try:
        plan_path, grant_path = Path(plan_path), Path(grant_path)
        if not _digest_required(plan_sha) or not _digest_required(grant_sha):
            raise ScoringError("exact_plan_and_grant_digests_required")
        if protocol.sha(plan_path) != plan_sha or protocol.sha(grant_path) != grant_sha:
            raise ScoringError("plan_or_grant_digest_mismatch")
        plan = _read_json(plan_path)
        grant = _read_json(grant_path)
        if (grant_path != HERE / "engineering_admission.json"
                or grant.get("approved") is not True
                or grant.get("plan_sha256") != plan_sha
                or grant.get("allow_once_scoring_after_full_seal") is not True):
            raise ScoringError("exact_independent_once_scoring_admission_required")
        admission_path = HERE / "admission.py"
        _require_pinned_file(plan, admission_path)
        admission = _module("p17_pten_scoring_admission", admission_path)
        admitted = admission.validate_plan_and_grant(
            plan_path, plan_sha, grant_path, grant_sha, require_job=False, allow_scoring=True)
        if admitted is False:
            raise ScoringError("independent_plan_admission_rejected")
        _validate_plan_metadata(plan)
        selected_run = Path(run) if run is not None else Path(plan["runtime_root"]) / "benchmark"
        return _score_admitted(plan, selected_run, plan_sha, grant_sha)
    except ScoringError:
        raise
    except Exception:
        raise ScoringError("scoring_admission_or_validation_failed") from None


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha", required=True)
    parser.add_argument("--grant", type=Path, required=True)
    parser.add_argument("--grant-sha", required=True)
    parser.add_argument("--run", type=Path)
    args = parser.parse_args(argv)
    try:
        result = score(args.plan, args.plan_sha, args.grant, args.grant_sha, args.run)
    except ScoringError:
        print(json.dumps({"status": "scoring_admission_or_attempt_failed", "automatic_retry_allowed": False}), file=sys.stderr)
        return 1
    print(json.dumps({"native_scoring_status": result["native_scoring_status"],
                      "native_denominator": NATIVE_COUNT,
                      "protected_references_opened": result["protected_references_opened"]}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
