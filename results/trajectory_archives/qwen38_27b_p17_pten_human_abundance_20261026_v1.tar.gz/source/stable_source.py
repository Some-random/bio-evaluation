"""Pin one canonical regular-file descriptor for hashing and permitted reads.

This module defines no biological parser, model, target or network interface.
Only an already admitted caller supplies an exact path and expected SHA256.
"""
from contextlib import contextmanager
import hashlib
import io
import os
from pathlib import Path
import stat


class SourceIntegrityError(ValueError):
    pass


def file_signature(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_uid, value.st_gid,
            value.st_nlink, value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def descriptor_hash(stream):
    stream.seek(0)
    digest = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
        digest.update(chunk)
    stream.seek(0)
    return digest.hexdigest()


class StableSource:
    def __init__(self, path, expected_sha256):
        self.path = Path(path)
        self.expected = expected_sha256
        self.stream = None
        self.parent_fd = None
        self.initial = None

    def _path_identity(self):
        if self.path.resolve(strict=True) != self.path:
            raise SourceIntegrityError("source_path_not_canonical")
        source = os.stat(self.path, follow_symlinks=False)
        parent = os.stat(self.path.parent, follow_symlinks=False)
        held_parent = os.fstat(self.parent_fd)
        if (parent.st_dev, parent.st_ino) != (held_parent.st_dev, held_parent.st_ino):
            raise SourceIntegrityError("source_parent_identity_changed")
        if not stat.S_ISREG(source.st_mode) or file_signature(source) != self.initial:
            raise SourceIntegrityError("source_path_identity_or_stat_changed")

    def __enter__(self):
        if not self.path.is_absolute() or self.path.resolve(strict=True) != self.path:
            raise SourceIntegrityError("source_path_not_canonical")
        parent_fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
        raw_fd = None
        try:
            # No ancestor or final component may be a symbolic link. Retain the
            # parent descriptor too, so replacing an ancestor cannot redirect us.
            for part in self.path.parts[1:-1]:
                following = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                    dir_fd=parent_fd)
                os.close(parent_fd)
                parent_fd = following
            self.parent_fd = parent_fd
            raw_fd = os.open(self.path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                             dir_fd=parent_fd)
            status = os.fstat(raw_fd)
            if not stat.S_ISREG(status.st_mode):
                raise SourceIntegrityError("source_descriptor_not_regular_file")
            self.initial = file_signature(status)
            self.stream = os.fdopen(raw_fd, "rb", buffering=0)
            raw_fd = None
            self._path_identity()
            if descriptor_hash(self.stream) != self.expected:
                raise SourceIntegrityError("source_descriptor_hash_mismatch")
            if file_signature(os.fstat(self.stream.fileno())) != self.initial:
                raise SourceIntegrityError("source_descriptor_changed_while_hashing")
            self._path_identity()
            return self
        except BaseException:
            if raw_fd is not None:
                os.close(raw_fd)
            if self.stream is not None:
                self.stream.close()
                self.stream = None
            os.close(parent_fd)
            self.parent_fd = None
            raise

    def verify(self):
        if self.stream is None or file_signature(os.fstat(self.stream.fileno())) != self.initial:
            raise SourceIntegrityError("source_descriptor_identity_or_stat_changed")
        self._path_identity()
        if descriptor_hash(self.stream) != self.expected:
            raise SourceIntegrityError("source_descriptor_hash_changed")
        if file_signature(os.fstat(self.stream.fileno())) != self.initial:
            raise SourceIntegrityError("source_descriptor_changed_while_hashing")
        self._path_identity()

    @contextmanager
    def text_reader(self):
        self.stream.seek(0)
        text = io.TextIOWrapper(self.stream, encoding="utf-8", newline="")
        try:
            yield text
        finally:
            text.detach()

    def binding(self):
        return {"path": str(self.path), "sha256": self.expected,
                "verified_same_regular_descriptor": True,
                "verified_identity_stat": dict(zip(
                    ["device", "inode", "mode", "uid", "gid", "links", "bytes", "mtime_ns", "ctime_ns"],
                    self.initial))}

    def __exit__(self, kind, value, traceback):
        # Callers verify after the last permitted read and immediately before
        # committing success. Closing must not invent a success after failure.
        try:
            if self.stream is not None:
                self.stream.close()
        finally:
            if self.parent_fd is not None:
                os.close(self.parent_fd)
            self.stream = None
            self.parent_fd = None

