# Native ProtST retrieval delivery

These are five released-query top-20 rankings produced by the released ProtST-ESM1b/PubMedBERT joint checkpoint over the separately qualified RDKit consumed-residue corpus projection. They are not Qwen results. The release provides no query relevance gold or aggregate accuracy metric; biological correctness has not been scored. Full historical TorchDrug graph/cohort or numerical ranking equivalence is not claimed.

The manifest and prediction lock bind the exact saved feature tensors, complete score matrix and all fixed query rankings. No checkpoint, credential, reference label or environment archive is included.
