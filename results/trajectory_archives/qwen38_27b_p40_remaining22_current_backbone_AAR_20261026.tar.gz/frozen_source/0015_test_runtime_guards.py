"""Synthetic runtime, filesystem, listener, resource and once-submission checks."""
from pathlib import Path
from types import SimpleNamespace
import copy
import json
import os
import shutil
import tempfile
import unittest
from unittest.mock import patch
import offline_runtime
import protocol
import runtime_controls as controls
import server_identity as identity
import submit_once
import worker


class RuntimeGuards(unittest.TestCase):
    def test_same_verified_metadata_buffer_no_reopen(self):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'metadata.json';path.write_text('{"original":true}')
            digest=protocol.sha(path)
            with patch.object(Path,'read_bytes',side_effect=AssertionError('must consume verified descriptor bytes')):
                self.assertEqual(controls.verified_json(path,digest),{'original':True})
            alias=Path(root)/'alias';alias.symlink_to(path)
            with self.assertRaises(ValueError):controls.regular(alias,digest)
            path.write_text('{}')
            with self.assertRaises(ValueError):controls.regular(path,digest)
    def test_short_runtime_explicit_tmp_despite_inherited_site_TMPDIR(self):
        with tempfile.TemporaryDirectory() as site,patch.dict(os.environ,{'TMPDIR':site}):
            local=worker.private_local('123456')
            try:
                self.assertEqual(local.parent,Path('/tmp'));self.assertEqual(local.stat().st_mode&0o777,0o700)
                temporary=local/'cache/tmp';temporary.mkdir(parents=True)
                env={'TMPDIR':str(temporary),'VLLM_RPC_BASE_PATH':str(temporary)}
                result=controls.ipc_preflight(local,env,bind=True)
                self.assertTrue(result['actual_bind_passed']);self.assertLessEqual(result['maximum_socket_path_bytes'],107)
                env['TMPDIR']=site
                with self.assertRaises(ValueError):controls.ipc_preflight(local,env)
            finally:shutil.rmtree(local)
    def test_capacity_unknown_pending_counts_and_strict_integer(self):
        value={'project_requested_GPUs':7,'project_requested_GPUs_with_addition':8,'additional_GPUs':1,
               'project_GPU_ceiling':8,'capacity_available':True,'jobs':[]}
        self.assertIs(controls.require_capacity(value,1),value)
        for key,bad in [('project_requested_GPUs',True),('project_requested_GPUs_with_addition',9),
                        ('additional_GPUs',True),('capacity_available',False)]:
            changed={**value,key:bad}
            with self.subTest(key=key),self.assertRaises(PermissionError):controls.require_capacity(changed,1)
        with self.assertRaises(PermissionError):controls.require_capacity({**value,'project_requested_GPUs':8,'project_requested_GPUs_with_addition':9},1)
    def test_owned_allocation_must_be_counted_and_exact_script(self):
        row={'job_id':'123','gpus':1,'command':str(controls.HERE/'worker.sbatch'),'workdir':str(controls.ROOT),
             'counted_toward_evaluation_project':True}
        value={'project_requested_GPUs':2,'project_requested_GPUs_with_addition':2,'additional_GPUs':0,
               'project_GPU_ceiling':8,'capacity_available':True,'own_allocation_verified':True,'jobs':[row]}
        with patch.dict(os.environ,{'SLURM_JOB_ID':'123'}):
            controls.require_capacity(value,0,own=True)
            for field,bad in [('gpus',2),('counted_toward_evaluation_project',False),('command','/wrong/script')]:
                changed=copy.deepcopy(value);changed['jobs'][0][field]=bad
                with self.subTest(field=field),self.assertRaises(PermissionError):controls.require_capacity(changed,0,own=True)
    def test_offline_closure_only_exact_nine_changes(self):
        expected={'vllm':'0.32.0','humming-kernels':'0.1.17'}
        before={**offline_runtime.PINNED,'vllm':'0.31.0','other':'1'}
        after={**before,**expected}
        self.assertTrue(offline_runtime.validate_closure(before,after,expected)['all_other_distributions_unchanged'])
        for modified in [{**after,'other':'2'},{**after,'unexpected':'1'},{**after,'torch':'0'}]:
            with self.assertRaises(ValueError):offline_runtime.validate_closure(before,modified,expected)
    def test_request_and_ancestry_fsync_failure_prevents_transport(self):
        row={'case_id':'artificial','condition_id':protocol.CONDITION,'target_length':2,
             'messages':[{'role':'user','content':'Synthetic only'}]}
        with tempfile.TemporaryDirectory() as root:
            sent=[]
            with patch.object(protocol.os,'fsync',side_effect=OSError('synthetic durability failure')):
                with self.assertRaises(OSError):protocol.run_phase([row],Path(root)/'phase',lambda body:sent.append(body),phase='development',plan_sha='fixture',expected=['AA'])
            self.assertEqual(sent,[])
    def test_models_context_root_and_redirect_fail_closed(self):
        plan={'model':'Synthetic/model','model_directory':'/synthetic/model','context_limit':65536}
        card={'data':[{'id':plan['model'],'root':plan['model_directory'],'max_model_len':65536}]}
        self.assertEqual(identity.verify_models_reply(card,plan),card['data'][0])
        for field,bad in [('id','Other/model'),('root','/wrong'),('max_model_len',65535),('max_model_len',True)]:
            changed=copy.deepcopy(card);changed['data'][0][field]=bad
            with self.subTest(field=field,bad=bad),self.assertRaises(ValueError):identity.verify_models_reply(changed,plan)
        self.assertIsNone(identity.NoRedirect().redirect_request(None,None,302,'redirect',{},'https://external.invalid'))
        self.assertTrue(any(isinstance(h,identity.NoRedirect) for h in identity.loopback_opener().handlers))
    def test_root_process_listener_namespace_argv_and_wildcard(self):
        with tempfile.TemporaryDirectory() as root:
            proc=Path(root);pid=123;ticks='456';base=proc/str(pid)
            for path in [base/'net',base/'fd',base/'ns',proc/'self/ns']:path.mkdir(parents=True,exist_ok=True)
            python=proc/'python';python.write_text('synthetic')
            (base/'exe').symlink_to(python);(base/'ns/net').symlink_to('net:[1]');(proc/'self/ns/net').symlink_to('net:[1]')
            (base/'stat').write_text('123 (synthetic) '+' '.join(['S']+['0']*18+[ticks]))
            command=[str(python),'-m','synthetic'];(base/'cmdline').write_bytes(b'\0'.join(v.encode() for v in command)+b'\0')
            header='sl local_address rem_address st tx_queue rx_queue tr tm->when retrnsmt uid timeout inode\n'
            line='0: 0100007F:2102 00000000:0000 0A 0 0 0 0 0 987\n'
            (base/'net/tcp').write_text(header+line);(base/'net/tcp6').write_text(header)
            (base/'fd/9').symlink_to('socket:[987]')
            identity.process_identity(pid,ticks,command,python,proc=proc)
            self.assertEqual(identity.owned_listener(pid,ticks,'http://127.0.0.1:8450/v1',proc=proc)['listener_inodes'],['987'])
            with self.assertRaises(PermissionError):identity.process_identity(pid,ticks,command+['drift'],python,proc=proc)
            (base/'net/tcp').write_text(header+line.replace('0100007F','00000000'))
            with self.assertRaises(PermissionError):identity.owned_listener(pid,ticks,'http://127.0.0.1:8450/v1',proc=proc)
            (base/'net/tcp').write_text(header+line);(base/'fd/9').unlink()
            with self.assertRaises(PermissionError):identity.owned_listener(pid,ticks,'http://127.0.0.1:8450/v1',proc=proc)
            (base/'fd/9').symlink_to('socket:[987]');(base/'ns/net').unlink();(base/'ns/net').symlink_to('net:[2]')
            with self.assertRaises(PermissionError):identity.owned_listener(pid,ticks,'http://127.0.0.1:8450/v1',proc=proc)
    def test_once_submission_intent_durable_before_mutation_and_ambiguity_blocks_retry(self):
        for response in [SimpleNamespace(returncode=0,stdout='12345\n',stderr=''),SimpleNamespace(returncode=0,stdout='ambiguous',stderr='')]:
            with self.subTest(response=response.stdout),tempfile.TemporaryDirectory() as root:
                here=Path(root);lock=here/'global.lock';calls=[]
                plan={'runtime_root':str(here/'runtime')}
                def scheduler(command,**kwargs):
                    self.assertTrue((here/'submission_attempt.json').is_file());calls.append(command)
                    return response
                with patch.object(submit_once,'HERE',here),patch.object(controls,'HERE',here),\
                     patch.object(submit_once.admission,'validate',return_value=plan),\
                     patch.object(controls,'shared_configuration',return_value={'shared_submission_lock':str(lock)}),\
                     patch.object(controls,'capacity',return_value={'synthetic':True}),\
                     patch.object(submit_once.subprocess,'run',side_effect=scheduler):
                    args=(here/'plan.json','p',here/'admission.json','a',here/'release.json','r')
                    if response.stdout=='ambiguous':
                        with self.assertRaises(RuntimeError):submit_once.submit(*args)
                    else:self.assertEqual(submit_once.submit(*args)['job_id'],'12345')
                    with self.assertRaises(PermissionError):submit_once.submit(*args)
                    self.assertEqual(len(calls),1)
    def test_actual_submission_verifies_matching_durable_intent(self):
        with tempfile.TemporaryDirectory() as root:
            here=Path(root)
            with patch.object(controls,'HERE',here),patch.dict(os.environ,{'SLURM_JOB_ID':'123'}):
                args=(here/'plan','p',here/'admission','a',here/'release','r')
                command=controls.expected_submission(*args)
                audit=here/'gpu_budget_before_submission.json';audit.write_text('{}')
                attempt={'command':command,'plan_sha256':'p','admission_sha256':'a','release_sha256':'r',
                    'ambiguous_submission_must_not_be_retried':True,'preallocation_audit_sha256':protocol.sha(audit)}
                apath=here/'submission_attempt.json';apath.write_text(json.dumps(attempt))
                receipt={'job_id':'123','command':command,'plan_sha256':'p','admission_sha256':'a',
                    'release_sha256':'r','submission_attempt_sha256':protocol.sha(apath)}
                rpath=here/'submission_receipt.json';rpath.write_text(json.dumps(receipt))
                self.assertEqual(controls.verify_submission(*args)['job_id'],'123')
                attempt['command']=['wrong'];apath.write_text(json.dumps(attempt))
                receipt['submission_attempt_sha256']=protocol.sha(apath);rpath.write_text(json.dumps(receipt))
                with self.assertRaises(PermissionError):controls.verify_submission(*args)
    def test_submission_durability_failure_prevents_scheduler(self):
        with tempfile.TemporaryDirectory() as root:
            here=Path(root)
            with patch.object(submit_once,'HERE',here),patch.object(submit_once.admission,'validate',return_value={}),\
                 patch.object(controls,'shared_configuration',return_value={'shared_submission_lock':str(here/'lock')}),\
                 patch.object(controls,'capacity',return_value={}),\
                 patch.object(controls,'durable_json',side_effect=OSError('synthetic durability failure')),\
                 patch.object(submit_once.subprocess,'run') as scheduler:
                with self.assertRaises(OSError):submit_once.submit(here/'plan','p',here/'grant','g',here/'release','r')
                scheduler.assert_not_called()


if __name__=='__main__':unittest.main()
