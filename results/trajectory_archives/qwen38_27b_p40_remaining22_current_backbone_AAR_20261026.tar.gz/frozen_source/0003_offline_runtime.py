"""Exact cached vLLM upgrade in one private prefix, with no online fallback."""
from pathlib import Path
import json
import shutil
import subprocess
import tarfile
import protocol
import runtime_controls as controls

PINNED = {'vllm': '0.32.0', 'torch': '2.13.0', 'transformers': '5.17.0',
          'triton': '3.7.1', 'flashinfer-python': '0.7.0.post1'}


def inventory(python, environment):
    code = '''import importlib.metadata as m,json,re
items={}
for d in m.distributions():
 name=re.sub(r"[-_.]+","-",d.metadata["Name"]).lower()
 items.setdefault(name,d.version)
print(json.dumps(items,sort_keys=True))
'''
    return json.loads(subprocess.check_output([str(python), '-B', '-c', code],
                                             env=environment, text=True, timeout=120))


def validate_closure(before, after, expected_dependencies):
    if any(after.get(name) != version for name, version in PINNED.items()):
        raise ValueError('Actual private runtime must match all five exact package pins')
    if any(after.get(name) != version for name, version in expected_dependencies.items()):
        raise ValueError('Exact original publisher dependency closure required')
    old = {k: v for k, v in before.items() if k not in expected_dependencies}
    new = {k: v for k, v in after.items() if k not in expected_dependencies}
    if old != new:
        raise ValueError('Offline upgrade may change only the exact original nine distributions')
    return {'packages': {k: after[k] for k in PINNED},
            'dependency_closure': expected_dependencies,
            'all_other_distributions_unchanged': True}


def install(python, environment, output, plan):
    python, output = Path(python), Path(output)
    manifest_path = plan['offline_dependency_manifest']
    manifest = controls.verified_json(manifest_path, plan['frozen_files_sha256'][manifest_path])
    archive = manifest['archive']
    if archive != plan['offline_dependency_archive']:
        raise ValueError('Frozen dependency archive descriptor differs')
    controls.regular(archive['path'], archive['sha256'])
    before = inventory(python, environment)
    for name, version in PINNED.items():
        if name != 'vllm' and before.get(name) != version:
            raise ValueError('Verified base runtime dependency differs before offline upgrade')
    local = python.parents[2]
    wheels = local / 'wheels'
    wheels.mkdir(exist_ok=False)
    rows = manifest['wheels']
    expected = {row['name']: row['version'] for row in rows}
    if expected != plan['offline_dependency_versions'] or len(rows) != 9:
        raise ValueError('Exact original nine-wheel dependency manifest required')
    expected_files = {row['filename']: row for row in rows}
    with tarfile.open(archive['path']) as bundle:
        members = bundle.getmembers()
        if ({m.name for m in members} != set(expected_files) or len(members) != 9
                or any(not m.isfile() or Path(m.name).name != m.name
                       or m.size != expected_files[m.name]['bytes'] for m in members)):
            raise ValueError('Dependency archive contains unexpected paths, types or sizes')
        bundle.extractall(wheels, filter='data')
    for row in rows:
        controls.regular(wheels / row['filename'], row['sha256'])
    report = output / 'pip_install_report.json'
    if report.exists():
        raise FileExistsError('Preserve prior private installation receipt')
    command = [str(python), '-B', '-m', 'pip', '--isolated', '--disable-pip-version-check',
               'install', '--no-index', '--no-deps', '--no-cache-dir', '--no-compile',
               '--upgrade', '--break-system-packages',
               *[str(wheels / row['filename']) for row in rows], '--report', str(report)]
    with (output / 'runtime_install.log').open('x') as log:
        subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT,
                       check=True, timeout=1200)
    installed = json.loads(report.read_bytes()).get('install', [])
    observed = {row['metadata']['name'].lower().replace('_', '-'): row for row in installed}
    if set(observed) != set(expected):
        raise ValueError('Only the exact nine pinned wheels may be installed')
    for row in rows:
        item = observed[row['name']]
        if (item['metadata']['version'] != row['version']
                or item['download_info']['archive_info']['hashes']['sha256'] != row['sha256']):
            raise ValueError('Installed dependency wheel identity differs')
    after = inventory(python, environment)
    info = validate_closure(before, after, expected)
    with (output / 'pip_check.log').open('x') as log:
        subprocess.run([str(python), '-B', '-m', 'pip', '--isolated', '--disable-pip-version-check', 'check'],
                       env=environment, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
    controls.durable_json(output / 'installed_package_identity.json', {
        'at_pacific': protocol.now(), **info, 'distribution_inventory_before': before,
        'distribution_inventory_after': after, 'offline_install_command': command,
        'wheelhouse_sha256': archive['sha256'], 'pip_install_report_sha256': protocol.sha(report),
        'pip_check_passed': True, 'new_network_calls': 0, 'model_forwards': 0})
    return info
