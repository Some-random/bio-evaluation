"""One admitted TP1 allocation: artificial2 -> fixed22 -> sealed native AAR."""
from __future__ import annotations
import argparse
import ast
import fcntl
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import types
import urllib.error
import urllib.parse
import urllib.request
import protocol
import admission
import preparation_contract as contract
import runtime_controls as controls
import server_identity as server_guard
import offline_runtime

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]


def load(name, path, extra=None):
    if extra:
        sys.path.insert(0, str(extra))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def read(path):
    return json.loads(Path(path).read_bytes())


def validate(plan_path, plan_sha, admission_path=None, admission_sha=None, **kwargs):
    return admission.validate(plan_path, plan_sha, admission_path, admission_sha, **kwargs)


def hardware_check(torch, plan, runtime):
    source = Path(plan['vetted_neutral_hardware_source'])
    tree = ast.parse(controls.regular(source, plan['frozen_files_sha256'][str(source)], read=True))
    functions = [item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name == 'check_hardware']
    if len(functions) != 1:
        raise ValueError('Pinned neutral hardware interface missing')
    namespace = {'contract': types.SimpleNamespace(now=protocol.now, write_json=lambda path,value:protocol.write(path,value,exclusive=False)),
                 'subprocess': subprocess}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(source), 'exec'), namespace)
    return namespace['check_hardware'](torch, runtime, plan)


def private_local(job):
    # Never inherit a site TMPDIR/gettempdir choice for the IPC root.
    local = Path(tempfile.mkdtemp(prefix='bp40-' + job + '-', dir='/tmp'))
    local.chmod(0o700)
    return local


def runtime_environment(shared, common, local, plan):
    environment = shared.clean_environment(common, local)
    # No inherited vLLM topology, dev endpoints, engine, or cache switches.
    for name in list(environment):
        if name.startswith('VLLM_'):
            environment.pop(name)
    environment.update(PYTHONPATH=str(HERE), PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1',
        HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1',
        VLLM_USE_V2_MODEL_RUNNER='0', VLLM_USE_RUST_FRONTEND='0', VLLM_SERVER_DEV_MODE='0',
        VLLM_NO_USAGE_STATS='1', DO_NOT_TRACK='1', VLLM_RPC_BASE_PATH=str(local/'cache/tmp'))
    site = load('p40_pinned_site_tools', plan['site_tools_helper'])
    return site.bind_site_tools(environment)


def restore_base(local, plan, runtime):
    archive = plan['base_runtime']
    controls.regular(archive['path'], archive['sha256'])
    before = Path(archive['path']).stat()
    with tarfile.open(archive['path']) as bundle:
        members = bundle.getmembers()
        for member in members:
            parts = PurePosixPath(member.name).parts
            if (not parts or PurePosixPath(member.name).is_absolute() or '..' in parts
                    or parts[0] not in ['python', 'runtime_manifest.json']
                    or not (member.isfile() or member.isdir() or member.issym() or member.islnk())):
                raise ValueError('Unexpected pinned runtime archive member')
            tarfile.data_filter(member, str(local))
        size = sum(m.size for m in members if m.isfile())
        if shutil.disk_usage('/tmp').free < size + 12 * 1024**3:
            raise ValueError('Full private runtime plus scratch margin required')
        bundle.extractall(local, members=members, filter='data')
    after = Path(archive['path']).stat()
    key = lambda s: (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
    if key(before) != key(after):
        raise ValueError('Runtime archive changed within local extraction observation')
    if local.stat().st_mode & 0o777 != 0o700:
        raise ValueError('Private runtime root mode changed')
    protocol.write(runtime/'base_archive_receipt.json', {'archive_sha256':archive['sha256'],
        'members':len(members),'uncompressed_file_bytes':size,'local_prefix':str(local),
        'source_identity_unchanged_in_this_host':True})


def own_server(identity, plan):
    if (identity['job_id'] != os.environ['SLURM_JOB_ID'] or identity['hostname'] != socket.gethostname()):
        raise PermissionError('Owned dedicated server allocation changed')
    process = server_guard.process_identity(identity['pid'],identity['proc_start_ticks'],
        identity['server_command'],identity['python_executable'])
    listener = server_guard.owned_listener(identity['pid'],identity['proc_start_ticks'],plan['endpoint'])
    return process, listener


def run_phases(plan, identity, local, plan_path, plan_sha, root_release):
    runtime = Path(plan['runtime_root'])
    opener = server_guard.loopback_opener()
    identity_sha = protocol.sha(runtime/'server_identity.json')
    def transport(body):
        controls.no_stop()
        controls.regular(runtime/'server_identity.json',identity_sha)
        own_server(identity,plan)
        if body['model'] != plan['model'] or body['max_tokens'] != 16384:
            raise PermissionError('Exact frozen model and output budget required')
        request = urllib.request.Request(plan['endpoint']+'/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
        try:
            with opener.open(request,timeout=1800) as response:
                return response.read(16*1024*1024+1)
        except urllib.error.HTTPError as error:
            raise protocol.TransportFailure(error.code,error.read(16*1024*1024+1)) from None
        except (urllib.error.URLError,TimeoutError,OSError):
            raise protocol.TransportFailure() from None
    def phase(name, expected=None):
        controls.no_stop()
        rows = protocol.cases(plan,name)
        protocol.write(runtime/'status.json',{'at_pacific':protocol.now(),'stage':name+'_generation',
            'job_id':os.environ['SLURM_JOB_ID'],'planned':len(rows),
            'direct_progress_path':str(runtime/name/'progress.json'),'no_automatic_retry':True},exclusive=False)
        return protocol.run_phase(rows,runtime/name,transport,phase=name,plan_sha=plan_sha,expected=expected)
    artificial = protocol.read_frozen(plan['development_inputs'],plan['frozen_files_sha256'])
    dev = phase('development',artificial['expected_sequences'])
    protocol.verify_phase(plan,runtime/'development',plan_sha,'development')
    if dev['exact_copy_gate_passed'] is not True:
        raise RuntimeError('Artificial exact-copy gate failed; stop without benchmark')
    benchmark = phase('benchmark')
    protocol.verify_phase(plan,runtime/'benchmark',plan_sha,'benchmark')
    if root_release['native_scoring_after_full_prediction_seal_authorized'] is not True:
        raise PermissionError('Separate scoring-after-seal release required')
    protocol.write(runtime/'scoring_attempt.json',{'at_pacific':protocol.now(),
        'prediction_lock_sha256':benchmark['prediction_lock_sha256'],'sole_scoring_attempt':True,
        'reference_access_only_after_all22_delivered':True})
    # score_locked itself refuses reference access unless all22 delivery is valid.
    subprocess.run([str(local/'python/bin/python3.12'),str(HERE/'score_locked.py'),
        '--plan',str(plan_path),'--plan-sha256',plan_sha,'--phase',str(runtime/'benchmark'),
        '--output',str(runtime/'benchmark/scores.json')],check=True,timeout=180)
    return {'development':dev,'benchmark':benchmark,'score':read(runtime/'benchmark/scores.json')}


def main():
    if sys.flags.optimize:
        raise PermissionError('Optimized execution forbidden')
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--plan-sha256',required=True)
    parser.add_argument('--admission',type=Path);parser.add_argument('--admission-sha256')
    parser.add_argument('--release',type=Path);parser.add_argument('--release-sha256')
    parser.add_argument('--runtime-dir',type=Path);parser.add_argument('--check-only',action='store_true')
    args = parser.parse_args()
    plan = validate(args.plan,args.plan_sha256)
    if args.check_only:
        print(json.dumps({'planned':22,'development':2,'independent_and_root_release_required':True,
            'model_calls':0,'GPU_allocations':0}));return
    kwargs = dict(release_path=args.release,release_sha=args.release_sha256,require_job=True)
    plan = validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256,**kwargs)
    release = controls.root_release(plan,args.plan_sha256,args.admission_sha256,args.release,args.release_sha256)
    runtime = Path(plan['runtime_root']);runtime.mkdir(exist_ok=True)
    protocol.set_artifact_boundary(runtime)
    shared = load('p40_vetted_v06_runtime_helpers',plan['vetted_V06_worker'],Path(plan['vetted_V06_worker']).parent)
    common = shared.common_module(plan)
    if args.runtime_dir is None:
        lock = (runtime/'allocation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (runtime/'allocation_started.json').exists():
            raise PermissionError('Sole allocation already claimed; no automatic retry')
        current_shared = controls.shared_configuration(plan)
        with Path(current_shared['shared_submission_lock']).open('a') as global_lock:
            fcntl.flock(global_lock,fcntl.LOCK_EX)
            validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256,**kwargs)
            audit = controls.capacity(plan,addition=0,own=True)
            protocol.write(runtime/'gpu_budget_audit.json',audit)
            protocol.write(runtime/'allocation_started.json',{'at_pacific':protocol.now(),
                'job_id':os.environ['SLURM_JOB_ID'],'plan_sha256':args.plan_sha256,
                'admission_sha256':args.admission_sha256,'release_sha256':args.release_sha256})
        if shutil.disk_usage('/tmp').free < 32*1024**3:
            raise ValueError('At least32GiB private scratch required')
        local = private_local(os.environ['SLURM_JOB_ID'])
        protocol.write(runtime/'private_runtime_claim.json',{'local_prefix':str(local),
            'job_id':os.environ['SLURM_JOB_ID'],'owner_uid':os.getuid(),'mode':'0700'})
        restore_base(local,plan,runtime)
        controls.regular(plan['cuda_overlay']['path'],plan['cuda_overlay']['sha256'])
        protocol.write(runtime/'archive_receipt.json',{'local_prefix':str(local),**common.apply_overlay(local)})
        environment, tools = runtime_environment(shared,common,local,plan)
        ipc = controls.ipc_preflight(local,environment,bind=True)
        protocol.write(runtime/'site_tool_binding.json',{'tools':tools,'IPC_preflight':ipc})
        offline_runtime.install(local/'python/bin/python3.12',environment,runtime,plan)
        command = [str(local/'python/bin/python3.12'),str(HERE/'worker.py'),*sys.argv[1:],'--runtime-dir',str(local)]
        os.execve(command[0],command,environment)
    local = args.runtime_dir
    controls.ipc_preflight(local,os.environ,bind=True)
    claim = read(runtime/'private_runtime_claim.json')
    if claim['local_prefix'] != str(local) or claim['job_id'] != os.environ['SLURM_JOB_ID']:
        raise PermissionError('Exact claimed local runtime required')
    lock = (runtime/'protocol.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if any((runtime/name).exists() for name in ['development','benchmark','terminal_receipt.json']):
        raise PermissionError('Partial or completed phase may never be repeated')
    current_shared = controls.shared_configuration(plan)
    with Path(current_shared['shared_submission_lock']).open('a') as global_lock:
        fcntl.flock(global_lock,fcntl.LOCK_EX)
        validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256,**kwargs)
        protocol.write(runtime/'gpu_budget_audit_at_server_start.json',controls.capacity(plan,addition=0,own=True))
    inventory = offline_runtime.inventory(local/'python/bin/python3.12',dict(os.environ))
    installed = read(runtime/'installed_package_identity.json')
    offline_runtime.validate_closure(installed['distribution_inventory_before'],inventory,plan['offline_dependency_versions'])
    protocol.write(runtime/'installed_identity.json',{'packages':{n:inventory[n] for n in offline_runtime.PINNED},
        'offline_closure_sha256':protocol.sha(runtime/'installed_package_identity.json')})
    if any(os.environ.get(k) != v for k,v in {'VLLM_USE_V2_MODEL_RUNNER':'0','VLLM_USE_RUST_FRONTEND':'0','VLLM_SERVER_DEV_MODE':'0'}.items()):
        raise ValueError('Exact Python DP1 nondevelopment server environment required')
    # Exact granted validator remains v2; consumed v3 plan retains its input basis.
    cpu_environment=dict(os.environ);cpu_environment['CUDA_VISIBLE_DEVICES']=''
    cpu_environment.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    with (runtime/'tokenizer_preflight.stdout').open('x') as out,(runtime/'tokenizer_preflight.stderr').open('x') as err:
        subprocess.run([str(local/'python/bin/python3.12'),plan['runtime_tokenizer_preflight'],
            '--plan',str(args.plan),'--plan-sha256',args.plan_sha256,'--output',str(runtime/'tokenizer_preflight.json')],
            env=cpu_environment,stdout=out,stderr=err,check=True,timeout=300)
    checked=read(runtime/'tokenizer_preflight.json')
    manifest,_,_=contract.verify_input_boundary(plan['input_preparation_manifest'],plan['positive_scope_review'],plan['independent_positive_scope_review'])
    contract.validate_cpu_receipt(checked,plan,manifest,exact_runtime=True,expected_plan_sha256=args.plan_sha256)
    if checked['packages']['vllm']!='0.32.0' or checked['actual0_32_API_recheck_required_before_neural_phases'] is not False:
        raise ValueError('Actual exact0.32 full24 API/context gate required')
    import torch
    hardware = hardware_check(torch,plan,runtime)
    model = common.validate_checkpoint(plan['model'],plan['model_revision'])
    if str(model) != plan['model_directory']:
        raise ValueError('Original pinned model directory differs')
    controls.no_stop()
    port=urllib.parse.urlparse(plan['endpoint']).port
    with socket.socket() as probe:
        probe.bind(('127.0.0.1',port))
    command = [str(local/'python/bin/python3.12'),'-m','vllm.entrypoints.cli.main','serve',str(model),
        '--served-model-name',plan['model'],'--host','127.0.0.1','--port',str(port),
        '--dtype','bfloat16','--tensor-parallel-size','1','--data-parallel-size','1',
        '--gpu-memory-utilization','0.95','--max-model-len','65536','--max-num-seqs','2',
        '--max-num-batched-tokens','8192','--reasoning-parser','qwen3','--enable-prefix-caching',
        '--limit-mm-per-prompt','{"image":0,"video":0}','--no-enable-log-requests','--disable-uvicorn-access-log']
    server = None
    try:
        protocol.write(runtime/'status.json',{'at_pacific':protocol.now(),'stage':'starting_dedicated_P40_server',
            'job_id':os.environ['SLURM_JOB_ID'],'endpoint':plan['endpoint']},exclusive=False)
        with (runtime/'server.log').open('x') as log:
            server = subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,cwd=local)
        ticks = server_guard.start_ticks(server.pid)
        opener = server_guard.loopback_opener();deadline = time.monotonic()+1800
        while time.monotonic() < deadline:
            if server.poll() is not None:
                raise RuntimeError('Own server exited before readiness')
            server_guard.process_identity(server.pid,ticks,command,command[0])
            # Before the first listen there is nothing to query; any occupied
            # frozen port must already be held by our original root process.
            if not server_guard.listener_inodes(plan['endpoint'],server_pid=server.pid):
                time.sleep(3);continue
            server_guard.owned_listener(server.pid,ticks,plan['endpoint'])
            try:
                with opener.open('http://127.0.0.1:'+str(port)+'/health',timeout=3) as response:
                    if response.status == 200:break
            except (OSError,urllib.error.URLError):
                time.sleep(3)
        else:
            raise TimeoutError('Own dedicated server startup timed out; no retry')
        process = server_guard.process_identity(server.pid,ticks,command,command[0])
        listener = server_guard.owned_listener(server.pid,ticks,plan['endpoint'])
        with opener.open(plan['endpoint']+'/models',timeout=5) as response:
            models = server_guard.verify_models_reply(json.load(response),plan)
        identity = {'at_pacific':protocol.now(),'task_id':'P40','condition':protocol.CONDITION,
            'model':plan['model'],'revision':plan['model_revision'],'dtype':'bfloat16','tensor_parallel_size':1,
            'job_id':os.environ['SLURM_JOB_ID'],'hostname':socket.gethostname(),'pid':server.pid,
            'proc_start_ticks':ticks,'endpoint':plan['endpoint'],'plan_sha256':args.plan_sha256,
            'admission_sha256':args.admission_sha256,'release_sha256':args.release_sha256,
            'GPU_uuid':hardware['GPU_uuid'],'server_command':command,'python_executable':command[0],
            'observed_process':process,'observed_listener':listener,'observed_models_card':models,
            'checkpoint_audit_sha256':plan['frozen_files_sha256'][plan['checkpoint_audit']],
            'package_receipt_sha256':protocol.sha(runtime/'installed_package_identity.json'),
            'tokenizer_preflight_sha256':protocol.sha(runtime/'tokenizer_preflight.json'),
            'native_full60_or_historical_equivalence':False,'binding_or_function_assessed':False}
        protocol.write(runtime/'server_identity.json',identity)
        result = run_phases(plan,identity,local,args.plan,args.plan_sha256,release)
        packager = load('p40_public_output_packager',plan['packager'])
        receipt = packager.package(plan,runtime,args.plan_sha256)
        protocol.write(runtime/'terminal_receipt.json',{'at_pacific':protocol.now(),
            'stage':'remaining22_outcomes_native_AAR_sealed_local_bundle_ready',
            'benchmark_completion_sha256':protocol.sha(runtime/'benchmark/completion.json'),
            'score_sha256':protocol.sha(runtime/'benchmark/scores.json'),'archive_sha256':receipt['sha256'],
            'native_full60_or_historical_equivalence':False,'public_upload_performed':False})
        protocol.write(runtime/'status.json',{'at_pacific':protocol.now(),'stage':'remaining22_scoring_terminal',
            'primary_metric':'native_macro_CDRH3_AAR','primary_metric_value':result['score']['primary_metric_value'],
            'native_full60_or_historical_equivalence':False,'binding_or_function_assessed':False},exclusive=False)
    finally:
        if server is not None and server.poll() is None:
            # Only signal the still-identical original server process group.
            server_guard.process_identity(server.pid,ticks,command,command[0])
            os.killpg(server.pid,signal.SIGTERM)
            try:server.wait(timeout=60)
            except subprocess.TimeoutExpired:
                server_guard.process_identity(server.pid,ticks,command,command[0])
                os.killpg(server.pid,signal.SIGKILL);server.wait(timeout=10)
        protocol.write(runtime/'server_terminal.json',{'at_pacific':protocol.now(),
            'own_server_stopped':True,'other_project_runtimes_changed':False})


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        # Never print exception repr/str/traceback containing a real input_value.
        print(json.dumps({'task_id':'P40','stage':'stopped_for_review_no_retry',
            'error_type':type(error).__name__,'raw_error_suppressed':True,
            'missing_progress_is_not_zero_attempts':True}),flush=True)
        raise SystemExit(2)
