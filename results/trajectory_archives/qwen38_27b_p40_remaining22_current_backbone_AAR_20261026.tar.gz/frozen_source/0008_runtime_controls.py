"""Exact P40 release, shared resource, portable filesystem and IPC guards."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import socket
import stat
import time
import protocol

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
OWNER = '/root/p40_runtime_preparation'


def durable_json(path, value):
    path = Path(path)
    if path.is_symlink() or path.absolute() != path.resolve():
        raise ValueError('Ordinary exact durable output path required')
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def regular(path, digest, *, read=False):
    """Compare mount identity only inside this host's open/read race window."""
    path = Path(path)
    if path.is_symlink() or path.absolute() != path.resolve():
        raise ValueError('Frozen path alias forbidden: ' + path.name)
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError('Ordinary frozen file required: ' + path.name)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(descriptor)
        identity = lambda item: (item.st_dev, item.st_ino, item.st_uid, item.st_size, item.st_mtime_ns)
        if identity(before) != identity(opened):
            raise ValueError('Frozen file changed during open')
        h = hashlib.sha256()
        chunks = [] if read else None
        with os.fdopen(descriptor, 'rb', closefd=False) as stream:
            for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
                h.update(block)
                if read:
                    chunks.append(block)
        if identity(opened) != identity(path.lstat()) or h.hexdigest() != digest:
            raise ValueError('Frozen file changed: ' + path.name)
        return b''.join(chunks) if read else None
    finally:
        os.close(descriptor)


def verified_json(path, digest):
    return json.loads(regular(path, digest, read=True))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def shared_configuration(plan):
    path = plan['shared_resource_binding']
    shared = verified_json(path, plan['frozen_files_sha256'][path])
    required = {'role': 'shared_resource_configuration_only_no_dispatch_authority',
                'approved': True, 'project_GPU_ceiling': 8,
                'requires_fresh_locked_audit_per_submission': True,
                'requires_fresh_own_allocation_audit_at_startup': True,
                'unknown_pending_and_running_jobs_remain_counted': True,
                'no_blanket_workdir_exclusions': True, 'dispatch_authorized_by_configuration': False}
    if any(shared.get(k) != v for k, v in required.items()):
        raise PermissionError('Exact independently reviewed shared resource configuration required')
    if shared.get('shared_submission_lock') != str(ROOT / '.local/evaluation_GPU_submission.lock'):
        raise ValueError('Exact shared submission/startup lock required')
    for ref in [shared['resource_adapter'], shared['additional_proof_binding'], *shared['additional_root_proofs']]:
        regular(ref['path'], ref['sha256'])
        if plan['frozen_files_sha256'].get(ref['path']) != ref['sha256']:
            raise ValueError('All current resource evidence must be frozen')
    return shared


def require_capacity(value, addition, *, own=False, script=None):
    before = value.get('project_requested_GPUs')
    after = value.get('project_requested_GPUs_with_addition')
    if (type(before) is not int or before < 0 or type(after) is not int
            or type(value.get('additional_GPUs')) is not int or value['additional_GPUs'] != addition
            or after != before + addition or after > 8 or value.get('project_GPU_ceiling') != 8
            or value.get('capacity_available') is not True):
        raise PermissionError('Fresh exact shared project GPU limit required')
    if own:
        rows = [r for r in value['jobs'] if r['job_id'] == os.environ.get('SLURM_JOB_ID')]
        if (value.get('own_allocation_verified') is not True or len(rows) != 1
                or type(rows[0]['gpus']) is not int or rows[0]['gpus'] != 1
                or rows[0]['command'].split()[0] != str(script or HERE / 'worker.sbatch')
                or Path(rows[0]['workdir']).resolve() != ROOT
                or rows[0].get('counted_toward_evaluation_project') is not True):
            raise PermissionError('Exact own counted one-GPU allocation required')
    return value


def capacity(plan, *, addition, own=False):
    shared = shared_configuration(plan)
    site = load('p40_current_site_tools', plan['site_tools_helper'])
    environment, _ = site.bind_site_tools(dict(os.environ))
    os.environ['PATH'] = environment['PATH']
    helper = load('p40_current_shared_v5', shared['resource_adapter']['path'])
    value = helper.capacity_audit(additional=addition, override=False, require_own_job=own,
        additional_root_proofs=shared['additional_root_proofs'],
        additional_proof_binding=shared['additional_proof_binding'])
    return require_capacity(value, addition, own=own)


def no_stop():
    for path in [HERE / 'STOP', HERE.parent / 'STOP']:
        if os.path.lexists(path):
            raise PermissionError('Current explicit P40 scheduling STOP is active')


def root_release(plan, plan_sha, admission_sha, release_path, release_sha):
    if Path(release_path).resolve() != HERE / 'root_runtime_release.json':
        raise PermissionError('Exact detached root runtime release path required')
    value = verified_json(release_path, release_sha)
    required = {'issuer': '/root', 'approved': True,
                'role': 'root_exact_P40_remaining22_one_GPU_runtime_release',
                'owner': OWNER, 'task_id': 'P40', 'condition': protocol.CONDITION,
                'plan_sha256': plan_sha, 'independent_admission_sha256': admission_sha,
                'planned': 22, 'gpu_count': 1, 'project_GPU_ceiling': 8,
                'one_allocation_only': True, 'no_retries': True,
                'native_scoring_after_full_prediction_seal_authorized': True,
                'scientific_condition_unchanged': True, 'STOP_clearance_authorized': True,
                'old_priority_holds_superseded_for_exact22': True,
                'root_scientific_adoption_sha256': plan['frozen_files_sha256'][plan['root_scientific_adoption']],
                'shared_resource_binding_sha256': plan['frozen_files_sha256'][plan['shared_resource_binding']]}
    if any(value.get(k) != v for k, v in required.items()):
        raise PermissionError('Separate exact root scheduling/model runtime release required')
    no_stop()
    return value


def expected_submission(plan_path, plan_sha, grant_path, grant_sha, release_path, release_sha):
    return ['sbatch', '--parsable', '--export=NONE', '--no-requeue', str(HERE / 'worker.sbatch'),
            '--plan', str(Path(plan_path).resolve()), '--plan-sha256', plan_sha,
            '--admission', str(Path(grant_path).resolve()), '--admission-sha256', grant_sha,
            '--release', str(Path(release_path).resolve()), '--release-sha256', release_sha]


def verify_submission(plan_path, plan_sha, grant_path, grant_sha, release_path, release_sha):
    job = os.environ.get('SLURM_JOB_ID', '')
    if not re.fullmatch(r'[0-9]{1,20}', job):
        raise PermissionError('Actual own Slurm allocation required')
    deadline = time.monotonic() + 60
    while True:
        try:
            receipt = json.loads((HERE / 'submission_receipt.json').read_bytes())
            break
        except (FileNotFoundError, json.JSONDecodeError):
            if time.monotonic() >= deadline:
                raise PermissionError('Exact once-submission receipt unavailable')
            time.sleep(.2)
    if (receipt.get('job_id') != job or receipt.get('plan_sha256') != plan_sha
            or receipt.get('admission_sha256') != grant_sha or receipt.get('release_sha256') != release_sha
            or receipt.get('command') != expected_submission(plan_path, plan_sha, grant_path, grant_sha, release_path, release_sha)):
        raise PermissionError('Own allocation differs from sole durable submission')
    attempt = verified_json(HERE / 'submission_attempt.json', receipt['submission_attempt_sha256'])
    if (attempt.get('command') != receipt['command'] or attempt.get('plan_sha256') != plan_sha
            or attempt.get('admission_sha256') != grant_sha or attempt.get('release_sha256') != release_sha
            or attempt.get('ambiguous_submission_must_not_be_retried') is not True):
        raise PermissionError('Sole durable intent differs from exact submission receipt')
    regular(HERE / 'gpu_budget_before_submission.json', attempt['preallocation_audit_sha256'])
    return receipt


def ipc_preflight(local=None, environment=None, *, bind=False):
    if Path('/tmp').resolve() != Path('/tmp'):
        raise ValueError('Canonical short local /tmp required')
    maximum_path = Path('/tmp') / ('bp40-' + '9' * 20 + '-' + 'x' * 8) / 'cache/tmp' / ('f' * 36)
    maximum = len(os.fsencode(maximum_path))
    if maximum > 107:
        raise ValueError('Worst-case private IPC socket path too long')
    result = {'maximum_socket_path_bytes': maximum, 'limit_bytes': 107,
              'actual_bind_passed': False}
    if local is None:
        return result
    local = Path(local)
    if (local.parent != Path('/tmp') or local.resolve() != local
            or not re.fullmatch(r'bp40-[0-9]{1,20}-[a-z0-9_]{8}', local.name)):
        raise ValueError('Exact short private runtime path required')
    observed = local.lstat()
    if (not stat.S_ISDIR(observed.st_mode) or observed.st_uid != os.getuid()
            or stat.S_IMODE(observed.st_mode) != 0o700):
        raise ValueError('Private runtime owner or mode changed')
    temporary = local / 'cache/tmp'
    if (environment.get('TMPDIR') != str(temporary)
            or environment.get('VLLM_RPC_BASE_PATH') != str(temporary)
            or temporary.resolve() != temporary or not temporary.is_dir()):
        raise ValueError('Actual IPC environment must equal reviewed private directory')
    path = temporary / ('f' * 36)
    if len(os.fsencode(path)) > maximum:
        raise ValueError('Actual private IPC path exceeds bound')
    if bind:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as probe:
            probe.bind(str(path))
            created = path.lstat()
            try:
                if not stat.S_ISSOCK(created.st_mode) or created.st_uid != os.getuid():
                    raise ValueError('Owned IPC probe changed')
                result.update(actual_bind_passed=True, actual_socket_path_bytes=len(os.fsencode(path)))
            finally:
                now = path.lstat()
                if (created.st_dev, created.st_ino, created.st_uid) != (now.st_dev, now.st_ino, now.st_uid):
                    raise ValueError('IPC inode changed in this namespace')
                path.unlink()
    return result
