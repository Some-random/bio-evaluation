"""Synthetic exception containment; no actual packets or ML imports."""
from pathlib import Path
import contextlib
import io
import json
import os
import sys
import tempfile
import unittest
from unittest.mock import patch
import check_inputs_cpu
import protocol
import safe_cpu_cli


class SafeCliTests(unittest.TestCase):
    def test_third_party_exception_and_incidental_logs_expose_no_payload(self):
        with tempfile.TemporaryDirectory() as root:
            p = Path(root) / 'plan.json'
            p.write_text('{}')
            def fail(*args, **kwargs):
                self.assertEqual(os.environ['CUDA_VISIBLE_DEVICES'], '')
                self.assertEqual(os.environ['HF_HUB_OFFLINE'], '1')
                self.assertEqual(os.environ['TRANSFORMERS_OFFLINE'], '1')
                print('INVENTED_PRIVATE_INPUT_ON_STDOUT')
                print('INVENTED_PRIVATE_INPUT_ON_STDERR',file=sys.stderr)
                raise ValueError('input_value=INVENTED_PRIVATE_INPUT_IN_EXCEPTION')
            capture = io.StringIO()
            errors = io.StringIO()
            with contextlib.redirect_stdout(capture), contextlib.redirect_stderr(errors), patch.dict(os.environ), \
                 patch.object(check_inputs_cpu, 'check', side_effect=fail):
                result = safe_cpu_cli.run(p, protocol.sha(p), Path(root) / 'never.json')
                self.assertEqual(os.environ['CUDA_VISIBLE_DEVICES'], '')
                self.assertEqual(os.environ['HF_HUB_OFFLINE'], '1')
            self.assertEqual(result, 2)
            self.assertNotIn('INVENTED_PRIVATE', capture.getvalue())
            self.assertEqual(errors.getvalue(), '')
            self.assertEqual(json.loads(capture.getvalue())['error_type'], 'ValueError')

    def test_wrong_plan_hash_stops_before_checker(self):
        with tempfile.TemporaryDirectory() as root:
            p = Path(root) / 'plan.json'
            p.write_text('{}')
            capture = io.StringIO()
            with contextlib.redirect_stdout(capture), patch.dict(os.environ), \
                 patch.object(check_inputs_cpu, 'check', side_effect=AssertionError('Must not run')) as checker:
                self.assertEqual(safe_cpu_cli.run(p, '0' * 64, Path(root) / 'never.json'), 2)
                checker.assert_not_called()
            self.assertEqual(json.loads(capture.getvalue())['error_type'], 'ValueError')


if __name__ == '__main__':
    unittest.main()
