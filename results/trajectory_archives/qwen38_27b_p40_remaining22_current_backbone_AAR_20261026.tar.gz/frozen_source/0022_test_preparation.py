"""Artificial input isolation and full-denominator metric contract fixtures."""
from pathlib import Path
import copy
import importlib.util
import json
import unittest
import prepare

class InputTests(unittest.TestCase):
    def packet(self):
        residue={'role':'heavy','chain_id':'H','ordinal':0,'number':1,'insertion_code':'','aa':'A',
            'backbone':{a:[1.,2.,3.]for a in prepare.BACKBONE},'protected_reference':'NEVER_EXPORT','source':'/private'}
        target={**residue,'ordinal':1,'number':105,'aa':'[MASK]','backbone':None}
        return {'residues':[residue,target],'requested_output':{'length':1},'target_heavy_positions':[1],'case_id':'private-identity'}
    def test_allowlisted_compact_packet_drops_identity_and_extras(self):
        result=prepare.compact_packet(self.packet());body=json.dumps(result)
        self.assertNotIn('NEVER_EXPORT',body);self.assertNotIn('/private',body);self.assertNotIn('private-identity',body)
        self.assertEqual(result['residues'][1][5:],['[MASK]',None])
    def test_masked_target_coordinate_is_rejected(self):
        packet=self.packet();packet['residues'][1]['backbone']={'CA':[1,2,3]}
        with self.assertRaises(ValueError):prepare.compact_packet(packet)
    def test_masked_antigen_or_wrong_count_rejected(self):
        for change in ['role','length']:
            packet=self.packet()
            if change=='role':packet['residues'][1]['role']='antigen'
            else:packet['requested_output']['length']=2
            with self.assertRaises(ValueError):prepare.compact_packet(packet)
    def test_context_coordinates_exact_not_rounded(self):
        packet=self.packet();packet['residues'][0]['backbone']['N']=[1.123456789,-2.4,0]
        result=prepare.compact_packet(packet);self.assertEqual(result['residues'][0][-1][0],[1.123456789,-2.4,0])
    def test_nonfinite_bool_or_incomplete_backbone_rejected(self):
        for value in [[float('nan'),0,0],[True,0,0],[0,0]]:
            packet=self.packet();packet['residues'][0]['backbone']['N']=value
            with self.assertRaises(ValueError):prepare.compact_packet(packet)
        packet=self.packet();del packet['residues'][0]['backbone']['O']
        with self.assertRaises(KeyError):prepare.compact_packet(packet)
    def test_message_preserves_all_context_and_fixed_length(self):
        packet=prepare.compact_packet(self.packet());message=prepare.messages(packet)
        self.assertEqual(len(message),1);self.assertEqual(message[0]['role'],'user')
        self.assertIn('exactly 1 canonical amino-acid letters',message[0]['content'])
        self.assertTrue(message[0]['content'].endswith(json.dumps(packet,separators=(',',':'))))

if __name__=='__main__':unittest.main()
