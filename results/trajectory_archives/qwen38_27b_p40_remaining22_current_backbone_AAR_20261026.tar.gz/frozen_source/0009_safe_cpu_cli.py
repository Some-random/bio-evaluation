"""CPU-only entrypoint with offline imports and payload-free error reporting."""
from pathlib import Path
import argparse
import contextlib
import json
import os
import protocol


def run(plan_path, plan_sha256, output):
    # These settings apply only to this dedicated CPU-validation process.
    os.environ.update(CUDA_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1',
                      TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1')
    try:
        plan_path = Path(plan_path)
        if plan_path.is_symlink() or protocol.sha(plan_path) != plan_sha256:
            raise ValueError('Exact consumed plan bytes required')
        plan = json.loads(plan_path.read_bytes())
        # Third-party exceptions may embed input_value. Neither their text nor
        # incidental Python logging is exposed by this entrypoint.
        with open(os.devnull, 'w') as sink, contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
            import check_inputs_cpu
            result = check_inputs_cpu.check(plan, output, input_plan_sha256=plan_sha256)
        print(json.dumps({'task_id': 'P40', 'stage': 'CPU_full24_tokenizer_API_check_passed',
                          'cases': len(result['cases']), 'all_full_inputs_fit': result['all_full_inputs_fit'],
                          'model_forwards': 0, 'GPU_allocations': 0,
                          'receipt_sha256': protocol.sha(output)}))
        return 0
    except BaseException as error:
        print(json.dumps({'task_id': 'P40', 'stage': 'CPU_validation_stopped_no_retry',
                          'error_type': type(error).__name__, 'raw_error_suppressed': True,
                          'model_forwards': 0, 'GPU_allocations': 0}))
        return 2


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    raise SystemExit(run(args.plan, args.plan_sha256, args.output))
