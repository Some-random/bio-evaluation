"""Invented metadata/packets only; no benchmark inputs, model or network."""
from pathlib import Path
from types import ModuleType, SimpleNamespace
import copy
import json
import os
import sys
import tempfile
import unittest
from unittest.mock import patch
import check_inputs_cpu
import preparation_contract as contract
import protocol


class MetadataFixture:
    def __init__(self, root):
        self.root = Path(root)
        self.solver = self.root / 'solver'
        self.solver.mkdir()
        self.reference = self.root / 'protected' / 'opaque.bin'
        self.reference.parent.mkdir()
        self.reference.write_bytes(b'Invented protected bytes that must never be parsed')
        self.ids = ['invented_' + str(i) for i in range(22)]
        self.rows = []
        self.evidence = []
        for case_id in self.ids:
            p = self.solver / (case_id + '.json')
            p.write_text(json.dumps({'case_id': case_id, 'condition_id': protocol.CONDITION,
                                   'target_length': 2, 'messages': [{'role': 'user', 'content': 'Invented complete packet.'}]}))
            digest = protocol.sha(p)
            self.rows.append({'case_id': case_id, 'solver_path': str(p), 'solver_sha256': digest,
                              'target_length': 2, 'all_target_identities_and_coordinates_removed': True})
            self.evidence.append({'case_id': case_id, 'solver_sha256': digest,
                                  'all_fields_checked': True, 'target_identity_and_coordinates_absent': True})
        self.manifest = {'task_id': 'P40', 'condition_id': protocol.CONDITION,
                         'prepared': 22, 'planned': 22, 'failures': [],
                         'fixed_remaining_cohort': self.ids, 'cases': self.rows,
                         'scorer_only_reference_path': str(self.reference),
                         'scorer_only_reference_sha256': protocol.sha(self.reference)}
        self.manifest_path = self.write('manifest.json', self.manifest)
        self.preparation = {'input_preparation_admitted': True, 'allowed_case_ids': self.ids,
                            'condition': protocol.CONDITION}
        self.preparation_path = self.write('preparation.json', self.preparation)
        self.complete = {'task_id': 'P40', 'condition_id': protocol.CONDITION,
                         'reviewer': contract.FULL_REVIEWER, 'planned': 22, 'reviewed': 22,
                         'approved_for_exact_solver_input_review': True,
                         'complete_source_and_input_fields_reviewed': True,
                         'full_real_solver_input_review_complete': True,
                         'solver_input_isolation_review_passed': True,
                         'all_old38_disjoint_and_unchanged': True,
                         'no_held_or_interrupted_scope_reopened': True,
                         'fixed_case_ids': self.ids, 'case_evidence': self.evidence,
                         'manifest_sha256': protocol.sha(self.manifest_path),
                         'protected_reference_sha256': protocol.sha(self.reference)}
        self.complete_path = self.write('complete.json', self.complete)
        self.development_path = self.write('development.json', {'cases': [
            {'case_id': 'artificial_' + str(i), 'condition_id': protocol.CONDITION,
             'target_length': 2, 'messages': [{'role': 'user', 'content': 'Invented artificial packet.'}]} for i in range(2)]})
        self.tokenizer = self.root / 'tokenizer.json'
        self.tokenizer.write_text('Invented tokenizer support')
        self.validator = self.root / 'validator.py'
        self.validator.write_text('# Invented validator support\n')
        self.plan = {'task_id': 'P40', 'condition': protocol.CONDITION,
                     'model': protocol.MODEL, 'model_revision': contract.MODEL_REVISION,
                     'model_directory': str(self.root), 'generation': protocol.GENERATION,
                     'input_preparation_manifest': str(self.manifest_path),
                     'positive_scope_review': str(self.preparation_path),
                     'independent_positive_scope_review': str(self.complete_path),
                     'fixed_case_ids': self.ids, 'cases': self.rows,
                     'development_inputs': str(self.development_path),
                     'tokenizer_files_sha256': {str(self.tokenizer): protocol.sha(self.tokenizer)},
                     'validator_files_sha256': {str(self.validator): protocol.sha(self.validator)},
                     'private_runtime_packages': {'vllm': '0.32.0', 'transformers': '5.17.0', 'torch': '2.13.0'},
                     'frozen_files_sha256': {str(self.development_path): protocol.sha(self.development_path),
                                             **{r['solver_path']: r['solver_sha256'] for r in self.rows}}}
        self.grant = {'issuer': '/root', 'approved': True, 'task_id': 'P40', 'condition': protocol.CONDITION,
                      'CPU_full_packet_tokenization_authorized': True, 'model_forwards_authorized': False,
                      'GPU_allocations_authorized': False, 'benchmark_dispatch_authorized': False,
                      'protected_reference_access_authorized': False, 'planned_solver_inputs': 22,
                      'planned_artificial_inputs': 2, 'fixed_case_ids': self.ids,
                      'manifest_sha256': protocol.sha(self.manifest_path),
                      'complete_input_review_sha256': protocol.sha(self.complete_path),
                      'model': protocol.MODEL, 'model_revision': contract.MODEL_REVISION,
                      'model_directory': str(self.root), 'generation': protocol.GENERATION,
                      'context_limit': contract.CONTEXT_LIMIT, 'max_output_tokens': contract.OUTPUT_LIMIT,
                      'tokenizer_files_sha256': self.plan['tokenizer_files_sha256'],
                      'validator_files_sha256': self.plan['validator_files_sha256'],
                      'input_basis_sha256': contract.input_basis_sha256(self.plan)}
        self.update_grant()

    def write(self, name, value):
        p = self.root / name
        p.write_text(json.dumps(value))
        return p

    def update_grant(self):
        p = self.write('grant.json', self.grant)
        self.plan.update(cpu_validation_authorization=str(p), cpu_validation_authorization_sha256=protocol.sha(p))

    def boundary(self):
        return contract.verify_input_boundary(self.manifest_path, self.preparation_path, self.complete_path)

    def check(self):
        class Tokenizer:
            def apply_chat_template(self, messages, *, tokenize, **kwargs):
                if tokenize:
                    assert kwargs['truncation'] is False
                    return {'input_ids': list(range(20))}
                return '<invented>' + messages[0]['content']
        modules = {name: ModuleType(name) for name in [
            'transformers', 'vllm', 'vllm.entrypoints', 'vllm.entrypoints.openai',
            'vllm.entrypoints.openai.chat_completion', 'vllm.entrypoints.openai.chat_completion.protocol',
            'vllm.sampling_params']}
        modules['transformers'].AutoTokenizer = SimpleNamespace(from_pretrained=lambda *a, **kw: Tokenizer())
        modules['vllm.entrypoints.openai.chat_completion.protocol'].ChatCompletionRequest = SimpleNamespace(
            model_validate=lambda body: SimpleNamespace(structured_outputs=SimpleNamespace(**body['structured_outputs'])))
        modules['vllm.sampling_params'].StructuredOutputsParams = lambda **kw: SimpleNamespace(**kw)
        versions = {'vllm': '0.32.0', 'transformers': '5.17.0', 'torch': '2.13.0'}
        output = self.root / 'CPU_receipt.json'
        plan_path = self.write('CPU_plan.json', self.plan)
        with patch.dict(sys.modules, modules), patch.dict(os.environ, {'CUDA_VISIBLE_DEVICES': ''}), \
             patch.object(check_inputs_cpu.metadata, 'version', side_effect=versions.__getitem__):
            return check_inputs_cpu.check(self.plan, output,input_plan_sha256=protocol.sha(plan_path))


class ContractTests(unittest.TestCase):
    def test_exact_boundary_and_opaque_reference_only(self):
        with tempfile.TemporaryDirectory() as root:
            f = MetadataFixture(root)
            f.boundary()
            self.assertEqual(f.reference.read_bytes(), b'Invented protected bytes that must never be parsed')

    def test_preparation_alias_or_incomplete_review_cannot_stand_in(self):
        with tempfile.TemporaryDirectory() as root:
            f = MetadataFixture(root)
            with self.assertRaises(ValueError):
                contract.verify_input_boundary(f.manifest_path, f.preparation_path, f.preparation_path)
            for key in ['full_real_solver_input_review_complete', 'solver_input_isolation_review_passed']:
                changed = {**f.complete, key: False}
                f.write('complete.json', changed)
                with self.assertRaises(PermissionError):
                    f.boundary()

    def test_changed_packet_reference_order_and_manifest_fail(self):
        for change in ['packet', 'reference', 'order', 'manifest']:
            with self.subTest(change=change), tempfile.TemporaryDirectory() as root:
                f = MetadataFixture(root)
                if change == 'packet':
                    Path(f.rows[0]['solver_path']).write_bytes(b'changed opaque bytes')
                elif change == 'reference':
                    f.reference.write_bytes(b'changed opaque protected bytes')
                elif change == 'order':
                    f.complete['case_evidence'].reverse()
                    f.write('complete.json', f.complete)
                else:
                    f.manifest['prepared'] = 21
                    f.write('manifest.json', f.manifest)
                with self.assertRaises(ValueError):
                    f.boundary()

    def test_cpu_grant_cannot_authorize_inference_or_different_bytes(self):
        for key, value in [('issuer', '/root/p40_runtime_preparation'), ('model_forwards_authorized', True),
                           ('manifest_sha256', '0' * 64), ('complete_input_review_sha256', '0' * 64),
                           ('GPU_allocations_authorized', True), ('benchmark_dispatch_authorized', True)]:
            with self.subTest(key=key), tempfile.TemporaryDirectory() as root:
                f = MetadataFixture(root)
                f.grant[key] = value
                f.update_grant()
                with self.assertRaises(PermissionError):
                    contract.verify_cpu_authority(f.plan)

    def test_missing_grant_stops_before_real_packet_parse_or_tokenizer_import(self):
        with tempfile.TemporaryDirectory() as root:
            f = MetadataFixture(root)
            f.plan.pop('cpu_validation_authorization')
            with patch.dict(os.environ, {'CUDA_VISIBLE_DEVICES': ''}), \
                 patch.object(protocol, 'cases', side_effect=AssertionError('Must not parse packets')):
                with self.assertRaises(PermissionError):
                    check_inputs_cpu.check(f.plan, f.root / 'never.json',input_plan_sha256='0'*64)
            self.assertFalse((f.root / 'never.json').exists())

    def test_synthetic_full24_checker_and_tampered_receipts(self):
        with tempfile.TemporaryDirectory() as root:
            f = MetadataFixture(root)
            receipt = f.check()
            contract.validate_cpu_receipt(receipt, f.plan, f.manifest, exact_runtime=True)
            self.assertEqual(len(receipt['cases']), 24)
            for change in ['duplicate', 'order', 'count_bool', 'oversize', 'source', 'request_digest', 'budget', 'API', 'reference']:
                bad = copy.deepcopy(receipt)
                if change == 'duplicate': bad['cases'][2] = bad['cases'][3]
                elif change == 'order': bad['cases'].reverse()
                elif change == 'count_bool': bad['cases'][0]['prompt_tokens'] = True
                elif change == 'oversize': bad['cases'][0]['prompt_tokens'] = 65536
                elif change == 'source': bad['cases'][0]['source_sha256'] = '0' * 64
                elif change == 'request_digest': bad['cases'][0]['request_sha256'] = ''
                elif change == 'budget': bad['max_output_tokens'] = 1
                elif change == 'API': bad['packages']['vllm'] = 'different'
                else: bad['references_read'] = True
                with self.subTest(change=change), self.assertRaises(ValueError):
                    contract.validate_cpu_receipt(bad, f.plan, f.manifest, exact_runtime=True)

    def test_changed_tokenizer_support_or_validator_bytes_fail(self):
        for name in ['tokenizer', 'validator']:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as root:
                f = MetadataFixture(root)
                getattr(f, name).write_text('Changed support')
                with self.assertRaises(ValueError):
                    contract.verify_cpu_authority(f.plan)


if __name__ == '__main__':
    unittest.main()
