"""One exact reviewed allocation; a durable ambiguous sbatch is never retried."""
from pathlib import Path
import argparse
import fcntl
import json
import os
import re
import subprocess
import sys
import admission
import protocol
import runtime_controls as controls

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]


def submit(plan_path, plan_sha, admission_path, admission_sha, release_path, release_sha):
    if sys.flags.optimize:
        raise PermissionError('Optimized execution forbidden')
    kwargs = dict(release_path=release_path,release_sha=release_sha)
    plan = admission.validate(plan_path,plan_sha,admission_path,admission_sha,**kwargs)
    shared = controls.shared_configuration(plan)
    with Path(shared['shared_submission_lock']).open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        plan = admission.validate(plan_path,plan_sha,admission_path,admission_sha,**kwargs)
        if any(os.path.lexists(HERE/name) for name in ['submission_attempt.json','submission_receipt.json',
                'gpu_budget_before_submission.json','runtime']):
            raise PermissionError('Prior allocation preparation/attempt exists; no automatic retry')
        ipc = controls.ipc_preflight()
        audit = controls.capacity(plan,addition=1,own=False)
        audit_path = HERE/'gpu_budget_before_submission.json'
        controls.durable_json(audit_path,audit)
        # The query can be slow; use current authority and STOP observation.
        admission.validate(plan_path,plan_sha,admission_path,admission_sha,**kwargs)
        command = controls.expected_submission(plan_path,plan_sha,admission_path,admission_sha,release_path,release_sha)
        controls.durable_json(HERE/'submission_attempt.json',{'at_pacific':protocol.now(),
            'command':command,'plan_sha256':plan_sha,'admission_sha256':admission_sha,
            'release_sha256':release_sha,'preallocation_audit_sha256':protocol.sha(audit_path),
            'IPC_preflight':ipc,'ambiguous_submission_must_not_be_retried':True})
        admission.validate(plan_path,plan_sha,admission_path,admission_sha,**kwargs)
        # Sole scheduler mutation; exclusive durable intent already exists.
        result = subprocess.run(command,check=False,text=True,capture_output=True,cwd=ROOT)
        controls.durable_json(HERE/'submission_scheduler_response.json',{'at_pacific':protocol.now(),
            'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
            'no_automatic_retry':True})
        if result.returncode or not re.fullmatch(r'[0-9]{1,20}(?:;[A-Za-z0-9._-]+)?\n?',result.stdout):
            raise RuntimeError('Scheduler result failed or ambiguous; preserve sole attempt without retry')
        job = result.stdout.strip().split(';',1)[0]
        receipt = {'at_pacific':protocol.now(),'job_id':job,'command':command,'plan_sha256':plan_sha,
            'admission_sha256':admission_sha,'release_sha256':release_sha,
            'submission_attempt_sha256':protocol.sha(HERE/'submission_attempt.json'),
            'gpu_count':1,'project_GPU_ceiling':8,'no_automatic_retry':True}
        controls.durable_json(HERE/'submission_receipt.json',receipt)
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--plan-sha256',required=True)
    parser.add_argument('--admission',type=Path,required=True);parser.add_argument('--admission-sha256',required=True)
    parser.add_argument('--release',type=Path,required=True);parser.add_argument('--release-sha256',required=True)
    args = parser.parse_args()
    print(json.dumps(submit(args.plan,args.plan_sha256,args.admission,args.admission_sha256,args.release,args.release_sha256)))


if __name__ == '__main__':
    try:main()
    except BaseException as error:
        print(json.dumps({'stage':'P40_submission_stopped_no_retry','error_type':type(error).__name__}),flush=True)
        raise SystemExit(2)
