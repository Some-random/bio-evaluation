"""Fixed22 masked-backbone sequence recovery; no reference access in delivery."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,re,os

CONDITION='P40_REMAINING22_CURRENT_IMGT_MASKED_BACKBONE_TEXT_AAR_V1'
MODEL='Qwen/Qwen3.8-27B'
GENERATION={'temperature':0,'top_p':1,'seed':42,'max_tokens':16384,'chat_template_kwargs':{'enable_thinking':False}}
ALPHABET='ACDEFGHIKLMNPQRSTVWY'
ARTIFACT_BOUNDARY=None
def set_artifact_boundary(path):
    global ARTIFACT_BOUNDARY
    ARTIFACT_BOUNDARY=Path(path).resolve()
def sync_parents(path):
    parent=Path(path).parent
    boundary=ARTIFACT_BOUNDARY.parent if ARTIFACT_BOUNDARY is not None else parent
    if not parent.is_relative_to(boundary):raise ValueError('Runtime write left admitted ancestry')
    while True:
        descriptor=os.open(parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(descriptor)
        finally:os.close(descriptor)
        if parent==boundary:return
        parent=parent.parent
def now():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
def write(path,value,*,exclusive=True):
    path=Path(path)
    if path.is_symlink()or path.absolute()!=path.resolve():raise ValueError('Ordinary exact artifact path required')
    temporary=path if exclusive else path.with_suffix('.tmp')
    with temporary.open('x')as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    sync_parents(temporary)
    if not exclusive:temporary.replace(path);sync_parents(path)
def read_frozen(path,pins):
    path=Path(path)
    if path.is_symlink():raise ValueError('Exact ordinary input required')
    body=path.read_bytes()
    if hashlib.sha256(body).hexdigest()!=pins[str(path)]:raise ValueError('Frozen input bytes changed')
    return json.loads(body)
def output_regex(length):
    if type(length)is not int or not 1<=length<=64:raise ValueError('Fixed measured CDR length required')
    return r'\{"sequence":"['+ALPHABET+']{'+str(length)+r'}"\}'
def payload(case):
    if set(case)!={'case_id','condition_id','target_length','messages'}or case['condition_id']!=CONDITION:raise ValueError('Exact input schema required')
    messages=case['messages']
    if len(messages)!=1 or set(messages[0])!={'role','content'}or messages[0]['role']!='user'or not isinstance(messages[0]['content'],str):raise ValueError('One unchanged complete user message required')
    return {'model':MODEL,'messages':messages,**GENERATION,'structured_outputs':{'regex':output_regex(case['target_length'])},'stream':False,'n':1}
def cases(plan,phase):
    rows=[]
    if phase=='development':
        data=read_frozen(plan['development_inputs'],plan['frozen_files_sha256']);rows=data['cases']
        if len(rows)!=2:raise ValueError('Fixed artificial2 required')
    elif phase=='benchmark':
        for row in plan['cases']:
            case=read_frozen(row['solver_path'],plan['frozen_files_sha256'])
            if case['case_id']!=row['case_id']or case['target_length']!=row['target_length']:raise ValueError('Input identity changed')
            rows.append(case)
        if len(rows)!=22 or [r['case_id']for r in rows]!=plan['fixed_case_ids']:raise ValueError('Exactly original fixed22 order required')
    else:raise ValueError('Explicit phase required')
    for row in rows:payload(row)
    return rows
def parse_reply(raw,length):
    out={'observed_final':False,'empty_final':False,'sequence':None,'http_errors':0,'transport_errors':0,'server_errors':0,'response_errors':0,'truncation':False,'refusal':False,'reasoning_present':False,'tool_calls_present':False}
    try:
        body=json.loads(raw)
        if not isinstance(body,dict)or not isinstance(body.get('choices'),list)or len(body['choices'])!=1 or not isinstance(body['choices'][0],dict):raise ValueError('Exactly one choice mapping required')
        choice=body['choices'][0];message=choice['message']
        if not isinstance(message,dict):raise ValueError('Message mapping required')
        text=message['content'];out.update(observed_final=text is None or isinstance(text,str),finish_reason=choice.get('finish_reason'),truncation=choice.get('finish_reason')=='length',refusal=bool(message.get('refusal')),reasoning_present=bool(message.get('reasoning_content')or message.get('reasoning')),tool_calls_present=bool(message.get('tool_calls')))
        if text is None or isinstance(text,str)and not text.strip():return {**out,'status':'invalid_observed_empty','empty_final':True}
        if not isinstance(text,str):raise ValueError('Final is not a string')
        if choice.get('finish_reason')!='stop'or out['refusal']or out['reasoning_present']or out['tool_calls_present']:return {**out,'status':'invalid_delivery'}
        if not re.fullmatch(output_regex(length),text):raise ValueError('Exact compact whole fixed-length JSON required')
        return {**out,'status':'delivered','sequence':json.loads(text)['sequence']}
    except (ValueError,TypeError,KeyError,IndexError):return {**out,'status':'invalid_schema'if out['observed_final']else'invalid_envelope','response_errors':1}

class TransportFailure(Exception):
    def __init__(self,code=None,body=None):super().__init__('HTTP/transport failure');self.code=code;self.body=body

def counts(outcomes,planned):
    attempted=[o for o in outcomes if o['attempted']]
    return {'planned':planned,'attempted_confirmed':len(attempted),'terminal':len(attempted),'outcomes_recorded':len(outcomes),
        'responses_saved':sum(o.get('response_saved',False)for o in attempted),'delivery_passed':sum(o['status']=='delivered'for o in attempted),
        'not_dispatched':sum(o['not_dispatched']for o in outcomes),'observed_empty_finals':sum(o['empty_final']for o in attempted),
        'unknown_finals':sum(not o['observed_final']for o in attempted),
        **{k:sum(o.get(k,0)for o in attempted)for k in ['transport_errors','http_errors','server_errors','response_errors','truncation','refusal','reasoning_present','tool_calls_present']}}

def run_phase(rows,folder,transport,*,phase,plan_sha,expected=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False);outcomes=[];halted=False
    if len({r['case_id']for r in rows})!=len(rows):raise ValueError('Unique fixed cases required')
    for index,case in enumerate(rows):
        directory=folder/('case_'+str(index).zfill(4));directory.mkdir()
        if halted:
            out={'status':'prior_delivery_failure_not_dispatched','attempted':False,'not_dispatched':True,'observed_final':False,'empty_final':False,'sequence':None}
        else:
            body=payload(case);write(directory/'request.json',body)
            # Request exists before transport; progress is explicitly an unsealed lower bound.
            write(folder/'progress.json',{'at_pacific':now(),'phase':phase,'role':'direct_unsealed_lower_bound','request_created_next_case':case['case_id'],**counts(outcomes,len(rows))},exclusive=False)
            try:
                raw=transport(body)
                if not isinstance(raw,bytes):raise TypeError('Trusted transport must return bytes')
                with(directory/'response.raw.json').open('xb')as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
                sync_parents(directory/'response.raw.json')
                out=parse_reply(raw,case['target_length'])if len(raw)<=16*1024*1024 else {'status':'response_size_limit','observed_final':False,'empty_final':False,'sequence':None,'response_errors':1}
                out['response_saved']=True;out['raw_capture_complete']=len(raw)<=16*1024*1024
            except TransportFailure as error:
                code=error.code
                if error.body is not None:
                    with(directory/'http_error.raw').open('xb')as stream:stream.write(error.body);stream.flush();os.fsync(stream.fileno())
                    sync_parents(directory/'http_error.raw')
                write(directory/'transport_error.json',{'http_status':code,'server_acceptance_unknown':True,'one_attempt_only':True})
                out={'status':'HTTP_failure'if code is not None else'transport_failure','observed_final':False,'empty_final':False,'sequence':None,
                    'http_errors':int(code is not None),'server_errors':int(code is not None and 500<=code<=599),'transport_errors':int(code is None)}
            out.update(attempted=True,not_dispatched=False)
            if expected is not None:
                out['artificial_exact_copy_passed']=out['status']=='delivered'and out['sequence']==expected[index]
                if out['status']=='delivered'and not out['artificial_exact_copy_passed']:out['status']='invalid_artificial_copy'
            if out['status']!='delivered':halted=True
        out['case_id']=case['case_id'];write(directory/'outcome.json',out);outcomes.append(out)
        write(folder/'progress.json',{'at_pacific':now(),'phase':phase,'role':'direct_unsealed_lower_bound',**counts(outcomes,len(rows))},exclusive=False)
    locked={str(p.relative_to(folder)):sha(p)for p in sorted(folder.glob('case_*/*'))if p.is_file()}
    write(folder/'prediction_lock.json',{'condition':CONDITION,'phase':phase,'plan_sha256':plan_sha,'planned':len(rows),'case_ids':[c['case_id']for c in rows],'files_sha256':locked,'reference_access_by_generation':False})
    complete={'at_pacific':now(),'condition':CONDITION,'phase':phase,'plan_sha256':plan_sha,**counts(outcomes,len(rows)),
        'all_delivered':len(outcomes)==len(rows)and all(o['status']=='delivered'for o in outcomes),
        'exact_copy_gate_passed':all(o.get('artificial_exact_copy_passed')is True for o in outcomes)if expected is not None else None,
        'prediction_lock_sha256':sha(folder/'prediction_lock.json')}
    write(folder/'completion.json',complete);return complete

def verify_phase(plan,folder,plan_sha,phase):
    """Reconstruct outcomes from locked exact requests/raw, before references."""
    folder=Path(folder);rows=cases(plan,phase);complete=json.loads((folder/'completion.json').read_bytes());lock=json.loads((folder/'prediction_lock.json').read_bytes())
    if (complete['prediction_lock_sha256']!=sha(folder/'prediction_lock.json')or lock['condition']!=CONDITION or lock['phase']!=phase or lock['plan_sha256']!=plan_sha
        or complete['condition']!=CONDITION or complete['phase']!=phase or complete['plan_sha256']!=plan_sha
        or lock['planned']!=len(rows)or lock['case_ids']!=[r['case_id']for r in rows]):raise ValueError('Exact prediction seal differs')
    actual={str(p.relative_to(folder))for p in folder.glob('case_*/*')if p.is_file()}
    if actual!=set(lock['files_sha256']):raise ValueError('Unsealed/missing case file')
    for name,digest in lock['files_sha256'].items():
        p=Path(name)
        if p.is_absolute()or'..'in p.parts or(folder/p).is_symlink()or sha(folder/p)!=digest:raise ValueError('Unsafe/changed locked artifact')
    outcomes=[]
    for index,case in enumerate(rows):
        directory=folder/('case_'+str(index).zfill(4));saved=json.loads((directory/'outcome.json').read_bytes())
        if (type(saved.get('attempted'))is not bool or type(saved.get('not_dispatched'))is not bool
            or saved['attempted']==saved['not_dispatched']):raise ValueError('Attempted/not-dispatched flags contradict')
        if not saved['attempted']and(saved['status']!='prior_delivery_failure_not_dispatched'or saved.get('sequence')is not None or saved.get('observed_final')or saved.get('empty_final')):
            raise ValueError('Unattempted slot cannot contain a delivered/final response')
        allowed={'outcome.json'}
        if saved['attempted']:
            allowed.add('request.json')
            if json.loads((directory/'request.json').read_bytes())!=payload(case):raise ValueError('Actual request differs from complete frozen solver input')
            if saved.get('response_saved'):
                allowed.add('response.raw.json');raw=(directory/'response.raw.json').read_bytes()
                if saved['status']=='delivered'and(len(raw)>16*1024*1024 or saved.get('raw_capture_complete')is not True):raise ValueError('Delivered output needs complete bounded raw capture')
                if len(raw)<=16*1024*1024:
                    derived=parse_reply(raw,case['target_length'])
                    if saved['status']=='delivered'and derived['status']!='delivered':raise ValueError('Delivered output must independently derive from raw reply')
                    for key,value in derived.items():
                        if saved.get(key)!=value and not(phase=='development'and key=='status'and saved.get(key)=='invalid_artificial_copy'):raise ValueError('Parsed outcome differs from sealed raw response')
            else:
                if saved['status']=='delivered':raise ValueError('Delivered output cannot be proven without raw response')
                allowed.add('transport_error.json')
                if(directory/'http_error.raw').exists():allowed.add('http_error.raw')
        if {p.name for p in directory.iterdir()}!=allowed:raise ValueError('Unexpected case artifact')
        if saved['case_id']!=case['case_id']:raise ValueError('Case identity changed')
        outcomes.append(saved)
    if any(complete.get(k)!=v for k,v in counts(outcomes,len(rows)).items()):raise ValueError('Completion counters differ from locked outcomes')
    if complete['all_delivered']!=all(o['status']=='delivered'for o in outcomes):raise ValueError('Delivery completion differs')
    if phase=='development':
        fixture=read_frozen(plan['development_inputs'],plan['frozen_files_sha256']);expected=fixture['expected_sequences']
        exact=all(o['attempted']and o['status']=='delivered'and o['sequence']==expected[i]for i,o in enumerate(outcomes))
        if complete['exact_copy_gate_passed']!=exact:raise ValueError('Artificial exact-copy completion differs from raw outputs')
    return complete,lock,outcomes
