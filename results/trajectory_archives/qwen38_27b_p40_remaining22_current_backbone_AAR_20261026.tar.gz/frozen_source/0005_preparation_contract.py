"""Fail-closed metadata bindings. This module never parses biological packets."""
from pathlib import Path
import hashlib
import json
import protocol

FULL_REVIEWER = '/root/independent_review'
MODEL_REVISION = '1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0'
CONTEXT_LIMIT = 65536
OUTPUT_LIMIT = 16384


def input_basis_sha256(plan):
    keys = ['task_id', 'condition', 'model', 'model_revision', 'model_directory',
            'generation', 'fixed_case_ids', 'cases', 'input_preparation_manifest',
            'positive_scope_review', 'independent_positive_scope_review', 'development_inputs',
            'tokenizer_files_sha256', 'validator_files_sha256', 'frozen_files_sha256']
    # Artifact identities below also cover metadata changes, without circular plan/grant hashes.
    basis = {k: plan[k] for k in keys if k != 'frozen_files_sha256'}
    basis['input_files_sha256'] = {plan[k]: protocol.sha(plan[k]) for k in
                                  ['input_preparation_manifest', 'positive_scope_review',
                                   'independent_positive_scope_review', 'development_inputs']}
    return hashlib.sha256(json.dumps(basis, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def read_metadata(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError('Ordinary exact metadata file required')
    return json.loads(path.read_bytes())


def verify_input_boundary(manifest_path, preparation_review_path, complete_review_path,
                          *, verify_opaque_hashes=True):
    """Check existing receipts and opaque bytes without a fresh content review."""
    paths = [Path(p).resolve() for p in
             [manifest_path, preparation_review_path, complete_review_path]]
    if len(set(paths)) != 3:
        raise ValueError('Preparation and independent complete-input reviews must differ')
    manifest, preparation, complete = map(read_metadata, paths)
    ids = manifest.get('fixed_remaining_cohort')
    if (manifest.get('task_id') != 'P40' or manifest.get('condition_id') != protocol.CONDITION
            or manifest.get('prepared') != 22 or manifest.get('planned') != 22
            or manifest.get('failures') != [] or not isinstance(ids, list)
            or len(ids) != 22 or len(set(ids)) != 22):
        raise ValueError('Exact complete fixed22 manifest required')
    if (preparation.get('input_preparation_admitted') is not True
            or preparation.get('allowed_case_ids') != ids
            or preparation.get('condition') != protocol.CONDITION):
        raise ValueError('Exact preparation scope required')
    required = {'task_id': 'P40', 'condition_id': protocol.CONDITION,
                'reviewer': FULL_REVIEWER, 'planned': 22, 'reviewed': 22,
                'approved_for_exact_solver_input_review': True,
                'complete_source_and_input_fields_reviewed': True,
                'full_real_solver_input_review_complete': True,
                'solver_input_isolation_review_passed': True,
                'all_old38_disjoint_and_unchanged': True,
                'no_held_or_interrupted_scope_reopened': True}
    if any(complete.get(k) != v for k, v in required.items()):
        raise PermissionError('Exact independent complete-input/source/isolation receipt required')
    if (complete.get('fixed_case_ids') != ids
            or complete.get('manifest_sha256') != protocol.sha(paths[0])
            or complete.get('protected_reference_sha256') != manifest.get('scorer_only_reference_sha256')):
        raise ValueError('Independent review must bind exact manifest and protected opaque digest')
    rows = manifest.get('cases', [])
    reviewed = complete.get('case_evidence', [])
    if ([r.get('case_id') for r in rows] != ids
            or [r.get('case_id') for r in reviewed] != ids):
        raise ValueError('Fixed ordered22 receipt evidence required')
    solver_paths = []
    for row, evidence in zip(rows, reviewed):
        solver = Path(row['solver_path'])
        if (row.get('solver_sha256') != evidence.get('solver_sha256')
                or evidence.get('all_fields_checked') is not True
                or evidence.get('target_identity_and_coordinates_absent') is not True
                or row.get('all_target_identities_and_coordinates_removed') is not True):
            raise ValueError('Exact reviewed isolated packet hashes required')
        if solver.is_symlink() or not solver.is_file():
            raise ValueError('Ordinary exact solver file required')
        if verify_opaque_hashes and protocol.sha(solver) != row['solver_sha256']:
            raise ValueError('Reviewed packet bytes changed')
        solver_paths.append(solver.resolve())
    reference = Path(manifest['scorer_only_reference_path'])
    if (reference.is_symlink() or not reference.is_file()
            or reference.resolve() in solver_paths
            or any(reference.resolve().parent == p.parent for p in solver_paths)):
        raise ValueError('Protected reference must remain physically separate')
    if verify_opaque_hashes and protocol.sha(reference) != manifest['scorer_only_reference_sha256']:
        raise ValueError('Protected opaque bytes changed')
    if verify_opaque_hashes:
        for name, digest in manifest.get('source_pins_sha256', {}).items():
            source = Path(name)
            if source.is_symlink() or not source.is_file() or protocol.sha(source) != digest:
                raise ValueError('Reviewed source or preparation metadata bytes changed')
    return manifest, preparation, complete


def verify_cpu_authority(plan):
    """Require a narrow exact root grant before parsing any real solver packet."""
    path = plan.get('cpu_validation_authorization')
    if not path or protocol.sha(path) != plan.get('cpu_validation_authorization_sha256'):
        raise PermissionError('Exact root CPU full-packet tokenizer authorization required')
    grant = read_metadata(path)
    required = {'approved': True, 'task_id': 'P40', 'condition': protocol.CONDITION,
                'CPU_full_packet_tokenization_authorized': True,
                'model_forwards_authorized': False, 'GPU_allocations_authorized': False,
                'benchmark_dispatch_authorized': False, 'protected_reference_access_authorized': False,
                'planned_solver_inputs': 22, 'planned_artificial_inputs': 2,
                'model': protocol.MODEL, 'model_revision': MODEL_REVISION,
                'model_directory': plan['model_directory'], 'generation': protocol.GENERATION,
                'context_limit': CONTEXT_LIMIT, 'max_output_tokens': OUTPUT_LIMIT,
                'input_basis_sha256': input_basis_sha256(plan)}
    if (grant.get('issuer') not in ['/root', 'root']
            or plan.get('model') != protocol.MODEL or plan.get('model_revision') != MODEL_REVISION
            or plan.get('generation') != protocol.GENERATION
            or any(grant.get(k) != v for k, v in required.items())
            or grant.get('fixed_case_ids') != plan.get('fixed_case_ids')
            or grant.get('manifest_sha256') != protocol.sha(plan['input_preparation_manifest'])
            or grant.get('complete_input_review_sha256') != protocol.sha(plan['independent_positive_scope_review'])):
        raise PermissionError('CPU tokenization grant must bind exact reviewed22 and exclude model work')
    for key in ['tokenizer_files_sha256', 'validator_files_sha256']:
        pins = grant.get(key)
        if not isinstance(pins, dict) or not pins or plan.get(key) != pins:
            raise ValueError('CPU grant must bind exact tokenizer and validator files')
        for name, digest in pins.items():
            p = Path(name)
            if p.is_symlink() or not p.is_file() or protocol.sha(p) != digest:
                raise ValueError('CPU-only validation support bytes changed')
    return grant


def expected_cases(plan, manifest):
    development_path = Path(plan['development_inputs'])
    pins = plan.get('frozen_files_sha256', {})
    if pins.get(str(development_path)) != protocol.sha(development_path):
        raise ValueError('Exact artificial fixture pin required')
    development = read_metadata(development_path).get('cases', [])
    if len(development) != 2 or len({r['case_id'] for r in development}) != 2:
        raise ValueError('Exactly two distinct artificial fixtures required')
    if any(r['case_id'] in manifest['fixed_remaining_cohort'] for r in development):
        raise ValueError('Artificial and benchmark identities must be disjoint')
    return [dict(phase='development', case_id=r['case_id'], target_length=r['target_length'],
                 source_sha256=protocol.sha(development_path)) for r in development] + [
        dict(phase='benchmark', case_id=r['case_id'], target_length=r['target_length'],
             source_sha256=r['solver_sha256']) for r in manifest['cases']]


def validate_cpu_receipt(receipt, plan, manifest, *, exact_runtime=False, expected_plan_sha256=None):
    required = {'task_id': 'P40', 'condition': protocol.CONDITION,
                'all_full_inputs_fit': True, 'references_read': False,
                'model_forwards': 0, 'GPU_allocations': 0,
                'context_limit': CONTEXT_LIMIT, 'max_output_tokens': OUTPUT_LIMIT,
                'input_truncation': False, 'model': protocol.MODEL,
                'model_directory': plan['model_directory'],
                'model_revision': MODEL_REVISION, 'generation': protocol.GENERATION,
                'manifest_sha256': protocol.sha(plan['input_preparation_manifest']),
                'complete_input_review_sha256': protocol.sha(plan['independent_positive_scope_review']),
                'CPU_authorization_sha256': plan['cpu_validation_authorization_sha256'],
                'input_basis_sha256': input_basis_sha256(plan),
                'tokenizer_files_sha256': plan['tokenizer_files_sha256'],
                'validator_files_sha256': plan['validator_files_sha256']}
    if any(receipt.get(k) != v for k, v in required.items()):
        raise ValueError('Full CPU receipt must bind exact model, protocol, authority and reviewed inputs')
    if expected_plan_sha256 is not None and receipt.get('input_plan_sha256') != expected_plan_sha256:
        raise ValueError('CPU receipt must bind exact consumed plan bytes')
    rows = receipt.get('cases', [])
    expected = expected_cases(plan, manifest)
    if len(rows) != 24:
        raise ValueError('All ordered2+22 actual tokenizer records required')
    for row, wanted in zip(rows, expected):
        if any(row.get(k) != v for k, v in wanted.items()):
            raise ValueError('Tokenizer receipt identities/order/source digests differ')
        tokens = row.get('prompt_tokens')
        digest = row.get('full_rendered_prompt_sha256', '')
        if (type(tokens) is not int or tokens < 10 or tokens + OUTPUT_LIMIT > CONTEXT_LIMIT
                or len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest)
                or row.get('native_HTTP_regex_preserved') is not True):
            raise ValueError('Each complete prompt must fit without truncation and retain HTTP regex')
        for key in ['request_sha256', 'token_ids_sha256']:
            value = row.get(key, '')
            if len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
                raise ValueError('Per-case request and token identity digests required')
    packages = receipt.get('packages', {})
    if not all(isinstance(packages.get(k), str) and packages[k] for k in ['vllm', 'transformers', 'torch']):
        raise ValueError('Actual tokenizer/API package versions required')
    if exact_runtime and any(packages.get(k) != v for k, v in
                             plan['private_runtime_packages'].items() if k in packages):
        raise ValueError('Allocated tokenizer/API runtime identity differs')
    return receipt
