"""Artificial delivery, raw-seal, native metric and admission regression tests."""
from pathlib import Path
from types import SimpleNamespace
import ast,copy,json,tempfile,unittest
from unittest.mock import patch,MagicMock
import protocol,score_locked,admission,worker
import package
HERE=Path(__file__).resolve().parent
NATIVE=HERE.parent/'current38_input_preparation_v1/prepared/source/native_generate.py'

def reply(sequence='AA',**message):
    return json.dumps({'choices':[{'finish_reason':'stop','message':{'content':json.dumps({'sequence':sequence},separators=(',',':')),**message}}]}).encode()
def case(index=0,length=2):return {'case_id':'artificial_'+str(index),'condition_id':protocol.CONDITION,'target_length':length,'messages':[{'role':'user','content':'Complete artificial packet only.'}]}

class Fixture:
    def __init__(self,root):
        self.root=Path(root);self.rows=[case(i)for i in range(22)];paths=[]
        for row in self.rows:
            p=self.root/(row['case_id']+'.json');p.write_text(json.dumps(row));paths.append(p)
        self.references=self.root/'protected.json';self.references.write_text(json.dumps({'cases':[{'case_id':row['case_id'],'target_sequence':'AA','target_length':2}for row in self.rows]}))
        self.plan={'cases':[{'case_id':row['case_id'],'target_length':2,'solver_path':str(path)}for row,path in zip(self.rows,paths)],'fixed_case_ids':[r['case_id']for r in self.rows],
            'references':str(self.references),'native_metric_source':str(NATIVE),'frozen_files_sha256':{str(p):protocol.sha(p)for p in [*paths,self.references,NATIVE]}}
    def run(self,transport=None):
        self.phase=self.root/'benchmark'
        return protocol.run_phase(self.rows,self.phase,transport or(lambda body:reply()),phase='benchmark',plan_sha='fixture')

class DeliveryTests(unittest.TestCase):
    def test_exact_full_length_compact_sequence(self):
        self.assertEqual(protocol.parse_reply(reply(),2)['status'],'delivered')
        for value in ['A','AAA','AX','aa']:
            self.assertNotEqual(protocol.parse_reply(reply(value),2)['status'],'delivered')
    def test_unknown_final_is_not_observed_empty(self):
        for raw in [b'not-json',b'{}',b'[]',b'{"choices":[{"message":{"content":{}}}]}']:
            parsed=protocol.parse_reply(raw,2);self.assertFalse(parsed['observed_final']);self.assertFalse(parsed['empty_final'])
    def test_null_or_blank_final_observed_empty(self):
        for content in [None,'','  ']:
            raw=json.dumps({'choices':[{'finish_reason':'stop','message':{'content':content}}]}).encode();parsed=protocol.parse_reply(raw,2)
            self.assertTrue(parsed['observed_final']);self.assertTrue(parsed['empty_final'])
    def test_both_reasoning_fields_tools_and_refusal_rejected(self):
        for field,value in [('reasoning','hidden'),('reasoning_content','hidden'),('tool_calls',[{}]),('refusal','refused')]:
            self.assertNotEqual(protocol.parse_reply(reply(**{field:value}),2)['status'],'delivered')
    def test_length_finish_and_whitespace_not_silently_repaired(self):
        body=json.loads(reply());body['choices'][0]['finish_reason']='length'
        self.assertTrue(protocol.parse_reply(json.dumps(body).encode(),2)['truncation'])
        body=json.loads(reply());body['choices'][0]['message']['content']=' {"sequence":"AA"}'
        self.assertNotEqual(protocol.parse_reply(json.dumps(body).encode(),2)['status'],'delivered')
    def test_first_delivery_failure_stops_new_sends_preserves_all22(self):
        with tempfile.TemporaryDirectory()as root:
            f=Fixture(root);calls=[]
            def failed(body):calls.append(body);raise protocol.TransportFailure(503,b'artificial failure')
            result=f.run(failed);self.assertEqual(len(calls),1);self.assertEqual(result['not_dispatched'],21)
            self.assertEqual(result['http_errors'],1);self.assertEqual(result['server_errors'],1);self.assertEqual(result['observed_empty_finals'],0)
            protocol.verify_phase(f.plan,f.phase,'fixture','benchmark')
    def test_wrong_artificial_copy_stops_second_send(self):
        with tempfile.TemporaryDirectory()as root:
            calls=[]
            def transport(body):calls.append(body);return reply('CC')
            result=protocol.run_phase([case(0),case(1)],Path(root)/'dev',transport,phase='development',plan_sha='fixture',expected=['AA','AA'])
            self.assertEqual(len(calls),1);self.assertFalse(result['exact_copy_gate_passed']);self.assertEqual(result['not_dispatched'],1)
    def test_oversized_raw_response_still_sealed_unknown(self):
        with tempfile.TemporaryDirectory()as root:
            f=Fixture(root);result=f.run(lambda body:b'x'*(16*1024*1024+1))
            self.assertEqual(result['attempted_confirmed'],1);self.assertEqual(result['responses_saved'],1);self.assertEqual(result['unknown_finals'],1)
            protocol.verify_phase(f.plan,f.phase,'fixture','benchmark')
    def test_full22_raw_scoring_native_metric(self):
        with tempfile.TemporaryDirectory()as root:
            f=Fixture(root);f.run();out=score_locked.score(f.plan,'fixture',f.phase,Path(root)/'score.json')
            self.assertEqual(out['primary_metric_value'],1);self.assertEqual(len(out['cases']),22)
            with self.assertRaises(FileExistsError):score_locked.score(f.plan,'fixture',f.phase,Path(root)/'score.json')
    def test_incomplete22_has_undefined_primary_without_reference_load(self):
        with tempfile.TemporaryDirectory()as root:
            f=Fixture(root);f.references.write_text('THIS MUST NOT BE PARSED');f.plan['frozen_files_sha256'][str(f.references)]=protocol.sha(f.references)
            f.run(lambda body:reply('A'));out=score_locked.score(f.plan,'fixture',f.phase,Path(root)/'score.json')
            self.assertIsNone(out['primary_metric_value']);self.assertFalse(out['reference_access_after_complete_raw_seal']);self.assertEqual(out['planned'],22)
    def test_changed_frozen_input_after_startup_is_rejected(self):
        with tempfile.TemporaryDirectory()as root:
            f=Fixture(root);Path(f.plan['cases'][0]['solver_path']).write_text('{}')
            with self.assertRaises(ValueError):protocol.cases(f.plan,'benchmark')
    def test_sealed_requests_raw_outcomes_and_no_extra_files(self):
        for mutation in ['request','raw','outcome','extra','traversal']:
            with self.subTest(mutation=mutation),tempfile.TemporaryDirectory()as root:
                f=Fixture(root);f.run();directory=f.phase/'case_0000';lockpath=f.phase/'prediction_lock.json'
                if mutation=='extra':(directory/'protected_reference.csv').write_text('never publish')
                elif mutation=='traversal':
                    lock=json.loads(lockpath.read_text());lock['files_sha256']['../outside']='0'*64;lockpath.write_text(json.dumps(lock))
                else:(directory/{'request':'request.json','raw':'response.raw.json','outcome':'outcome.json'}[mutation]).write_text('{}')
                with self.assertRaises(ValueError):protocol.verify_phase(f.plan,f.phase,'fixture','benchmark')
    def test_forged_parsed_output_even_with_relocked_hash_is_rejected(self):
        with tempfile.TemporaryDirectory()as root:
            f=Fixture(root);f.run();p=f.phase/'case_0000/outcome.json';out=json.loads(p.read_text());out['sequence']='CC';p.write_text(json.dumps(out))
            lockpath=f.phase/'prediction_lock.json';lock=json.loads(lockpath.read_text());lock['files_sha256']['case_0000/outcome.json']=protocol.sha(p);lockpath.write_text(json.dumps(lock))
            completed=f.phase/'completion.json';obj=json.loads(completed.read_text());obj['prediction_lock_sha256']=protocol.sha(lockpath);completed.write_text(json.dumps(obj))
            with self.assertRaises(ValueError):protocol.verify_phase(f.plan,f.phase,'fixture','benchmark')
    def test_native_aar_macro_is_not_pooled_residue_accuracy(self):
        import statistics
        compute=score_locked.native_aar(NATIVE.read_bytes(),protocol.sha(NATIVE))
        self.assertEqual(compute('AC','AA'),.5);self.assertEqual(compute('A','A'),1)
        self.assertEqual(statistics.mean([compute('AC','AA'),compute('A','A')]),.75)
        with self.assertRaises(ValueError):compute('A','AA')
    def test_actual_endpoint_probe_server_and_health_share_port(self):
        source=Path(worker.__file__).read_text();self.assertNotIn('8427',source)
        self.assertIn("port=urllib.parse.urlparse(plan['endpoint']).port",source)
        self.assertIn("probe.bind(('127.0.0.1',port))",source);self.assertIn("'--port',str(port)",source)
        self.assertIn("str(port)+'/health'",source)
    def test_cpu_tokenizer_recheck_hides_cuda_and_actual032_required(self):
        source=Path(worker.__file__).read_text();self.assertIn("cpu_environment['CUDA_VISIBLE_DEVICES']=''",source)
        self.assertIn("checked['packages']['vllm']!='0.32.0'",source)
    def test_reduced_plan_cannot_admit_even_with_authorized_peer(self):
        with tempfile.TemporaryDirectory()as root:
            root=Path(root)
            plan={'task_id':'P40','condition':protocol.CONDITION,'model':protocol.MODEL,'planned':22,'development_planned':2,'gpus_requested':1,
                'native_full60_or_historical_equivalence':False,'coordinate_metrics_available':False,'binding_or_function_assessed':False,
                'new_training':False,'paid_model_calls':False,'automatic_retries':False,'owner':'/root/p40_runtime_preparation','context_limit':65536,'frozen_files_sha256':{}}
            path=root/'plan.json';path.write_text(json.dumps(plan));grant=root/'grant.json'
            grant.write_text(json.dumps({'reviewer':'/root/update_preparation_audit','admitted':True}))
            with self.assertRaisesRegex(ValueError,'required linked execution artifact'):
                admission.validate(path,protocol.sha(path),grant,protocol.sha(grant))
    def test_package_rechecks_public_source_and_uses_only_locked_artifacts(self):
        with tempfile.TemporaryDirectory()as root:
            f=Fixture(root);f.run();score_locked.score(f.plan,'fixture',f.phase,Path(root)/'benchmark/scores.json')
            devinputs=Path(root)/'devinputs.json';devinputs.write_text(json.dumps({'cases':[case(100),case(101)],'expected_sequences':['AA','AA']}))
            f.plan['development_inputs']=str(devinputs);f.plan['frozen_files_sha256'][str(devinputs)]=protocol.sha(devinputs)
            protocol.run_phase([case(100),case(101)],Path(root)/'development',lambda body:reply(),phase='development',plan_sha='fixture',expected=['AA','AA'])
            for name in ['hardware_gate.json','server_identity.json','installed_identity.json','tokenizer_preflight.json']:(Path(root)/name).write_text('{}')
            source=Path(root)/'artificial_source.py';source.write_text('x=1\n');f.plan.update(model_revision='artificial',scientific_differences=['Artificial fixture only.'],public_code_paths=[str(source)],task_id='P40',condition=protocol.CONDITION,planned=22,model=protocol.MODEL,generation=protocol.GENERATION)
            f.plan['frozen_files_sha256'][str(source)]=protocol.sha(source)
            source.write_text('x=2\n')
            with self.assertRaises(ValueError):package.package(f.plan,Path(root),'fixture')
    def test_neutral_hardware_receipt_repeated_updates_do_not_require_exclusive_create(self):
        source=HERE.parents[1]/'P35/standalone_v2/execute_native.py'
        fake=MagicMock();fake.__version__='artificial';fake.version.cuda='artificial';fake.cuda.device_count.return_value=1
        fake.cuda.get_device_properties.return_value=SimpleNamespace(uuid='GPU-artificial',name='A100 artificial fixture',total_memory=80_000_000_000)
        x=MagicMock();y=MagicMock();fake.arange.return_value.reshape.return_value=x
        x.__matmul__.return_value.__add__.return_value=y;y.__getitem__.return_value.item.return_value=15
        fake.isfinite.return_value.all.return_value=True
        observed=SimpleNamespace(stdout='GPU-artificial,A100 artificial,610,81920,30,0,0')
        with tempfile.TemporaryDirectory()as root,patch.object(worker.subprocess,'run',return_value=observed):
            receipt=worker.hardware_check(fake,{'vetted_neutral_hardware_source':str(source),'frozen_files_sha256':{str(source):protocol.sha(source)}},Path(root))
            self.assertTrue(receipt['neutral_cuda_arithmetic_passed']);self.assertEqual(receipt['pretrained_model_forwards_by_this_check'],0)
    def test_no_raw_or_oversized_cannot_be_resealed_as_delivered_before_references(self):
        for mutation in ['missing_raw','oversized','contradictory_flags']:
            with self.subTest(mutation=mutation),tempfile.TemporaryDirectory()as root:
                f=Fixture(root);f.run();directory=f.phase/'case_0000';p=directory/'outcome.json';out=json.loads(p.read_bytes())
                if mutation=='missing_raw':
                    (directory/'response.raw.json').unlink();(directory/'transport_error.json').write_text('{}');out['response_saved']=False
                elif mutation=='oversized':(directory/'response.raw.json').write_bytes(b'X'*(16*1024*1024+1))
                else:out['not_dispatched']=True
                p.write_text(json.dumps(out));lockpath=f.phase/'prediction_lock.json';lock=json.loads(lockpath.read_bytes())
                lock['files_sha256']={str(path.relative_to(f.phase)):protocol.sha(path)for path in f.phase.glob('case_*/*')};lockpath.write_text(json.dumps(lock))
                completepath=f.phase/'completion.json';complete=json.loads(completepath.read_bytes());complete['prediction_lock_sha256']=protocol.sha(lockpath);completepath.write_text(json.dumps(complete))
                original=protocol.read_frozen;reference_reads=[]
                def protected_read(path,pins):
                    if str(path)==str(f.references):reference_reads.append(path);raise AssertionError('References must remain unopened')
                    return original(path,pins)
                with patch.object(protocol,'read_frozen',side_effect=protected_read),self.assertRaises(ValueError):score_locked.score(f.plan,'fixture',f.phase,Path(root)/'score.json')
                self.assertEqual(reference_reads,[])

if __name__=='__main__':unittest.main()
