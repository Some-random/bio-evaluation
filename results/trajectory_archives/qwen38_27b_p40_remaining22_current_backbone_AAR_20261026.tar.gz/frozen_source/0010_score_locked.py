"""Sole native AAR scoring only after exact complete raw22 prediction seal."""
from pathlib import Path
from types import SimpleNamespace
import argparse,ast,hashlib,json,statistics
import protocol

def native_aar(source,source_sha):
    if hashlib.sha256(source).hexdigest()!=source_sha:raise ValueError('Frozen native metric source changed')
    tree=ast.parse(source);function=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='eval_one')
    start=next(i for i,n in enumerate(function.body)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='origin_seq'for t in n.targets))
    end=next(i for i,n in enumerate(function.body)if isinstance(n,ast.Assign)and any(isinstance(t,ast.Subscript)and isinstance(t.value,ast.Name)and t.value.id=='summary'and isinstance(t.slice,ast.Constant)and t.slice.value=='AAR'for t in n.targets))
    selected=function.body[start:end+1]
    if any(isinstance(n,(ast.Import,ast.ImportFrom,ast.With,ast.Try))for item in selected for n in ast.walk(item)):raise ValueError('Unexpected native scalar metric source')
    arguments=ast.arguments(posonlyargs=[],args=[ast.arg(arg=n)for n in ['cplx','seq','cdr','summary']],vararg=None,kwonlyargs=[],kw_defaults=[],kwarg=None,defaults=[])
    wrapped=ast.FunctionDef(name='compute_native_aar',args=arguments,body=selected+[ast.Return(value=ast.Subscript(value=ast.Name(id='summary',ctx=ast.Load()),slice=ast.Constant(value='AAR'),ctx=ast.Load()))],decorator_list=[])
    namespace={};exec(compile(ast.fix_missing_locations(ast.Module(body=[wrapped],type_ignores=[])),'pinned_native_AAR','exec'),namespace)
    def compute(predicted,target):
        if len(predicted)!=len(target)or not target or any(c not in protocol.ALPHABET for c in predicted+target):raise ValueError('Whole canonical equal-length target/prediction required')
        complex=SimpleNamespace(get_cdr=lambda cdr:SimpleNamespace(get_seq=lambda:target))
        return namespace['compute_native_aar'](complex,predicted,'H3',{})
    # Native equal-case averaging is source-defined, not pooled residue accuracy.
    matching=[n for n in ast.walk(tree)if isinstance(n,ast.Assign)and isinstance(n.value,ast.Tuple)and any(isinstance(x,ast.Call)and isinstance(x.func,ast.Attribute)and isinstance(x.func.value,ast.Name)and x.func.value.id=='np'and x.func.attr=='mean'and len(x.args)==1 and isinstance(x.args[0],ast.Name)and x.args[0].id=='aars'for x in n.value.elts)]
    if len(matching)!=1:raise ValueError('Native macro AAR aggregation contract changed')
    return compute

def score(plan,plan_sha,phase,output):
    complete,lock,outcomes=protocol.verify_phase(plan,phase,plan_sha,'benchmark')
    if len(outcomes)!=22:raise ValueError('Original declared22 denominator required')
    result={'task_id':'P40','condition':protocol.CONDITION,'at_pacific':protocol.now(),'plan_sha256':plan_sha,'planned':22,
        'prediction_lock_sha256':protocol.sha(Path(phase)/'prediction_lock.json'),'primary_metric':'native_macro_CDRH3_AAR',
        'primary_metric_value':None,'native_full60_or_historical_equivalence':False,'reference_access_after_complete_raw_seal':False,
        'scope':'Fixed independently reviewed remaining22 current-structure cases, all retained; no favorable-case metric.',
        'coordinate_metrics_available':False,'binding_or_function_assessed':False,'sole_scoring_attempt':True}
    if complete['all_delivered']is not True or complete['delivery_passed']!=22 or complete['attempted_confirmed']!=22:
        result.update(status='undefined_incomplete_delivery_full22_denominator_preserved',reason='A full22 native AAR is undefined when any complete canonical output is missing; targets were not opened.')
        protocol.write(output,result);return result
    # The only path opening protected target contents is below the full raw-lock gate.
    protected=protocol.read_frozen(plan['references'],plan['frozen_files_sha256'])
    targets=protected['cases']
    if [row['case_id']for row in targets]!=plan['fixed_case_ids']:raise ValueError('Exact protected reference case order differs')
    metric_path=Path(plan['native_metric_source']);source=metric_path.read_bytes()
    compute=native_aar(source,plan['frozen_files_sha256'][str(metric_path)])
    records=[]
    for outcome,target in zip(outcomes,targets):
        if outcome['case_id']!=target['case_id']or len(outcome['sequence'])!=target['target_length']:raise ValueError('Whole expected-length output required')
        value=compute(outcome['sequence'],target['target_sequence'])
        records.append({'case_id':target['case_id'],'target_length':target['target_length'],'native_AAR':value})
    result.update(status='native_AAR_scored_complete_remaining22',primary_metric_value=statistics.mean(row['native_AAR']for row in records),
        reference_access_after_complete_raw_seal=True,native_aggregation='Equal-weight mean of all22 per-case positional hit fractions; MEAN generate.py eval_one AAR and rabd_test np.mean(aars).',
        cases=records)
    protocol.write(output,result);return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--plan-sha256',required=True);parser.add_argument('--phase',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if protocol.sha(args.plan)!=args.plan_sha256:raise ValueError('Exact frozen plan required')
    score(json.loads(args.plan.read_bytes()),args.plan_sha256,args.phase,args.output)
