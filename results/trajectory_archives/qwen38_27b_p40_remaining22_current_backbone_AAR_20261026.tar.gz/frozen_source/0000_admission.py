"""Exact frozen science/input/CPU contract and separate independent/root releases."""
from pathlib import Path
import json
import protocol
import preparation_contract as contract
import runtime_controls as controls
import offline_runtime

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
OWNER = controls.OWNER


def equal_fields(value, required, message, error=ValueError):
    if any(value.get(k) != v for k, v in required.items()):
        raise error(message)


def validate(plan_path, plan_sha, grant_path=None, grant_sha=None, *,
             release_path=None, release_sha=None, require_job=False):
    p = controls.verified_json(plan_path, plan_sha)
    equal_fields(p, {'task_id': 'P40', 'condition': protocol.CONDITION, 'model': protocol.MODEL,
        'owner': OWNER, 'planned': 22, 'development_planned': 2, 'gpus_requested': 1,
        'native_full60_or_historical_equivalence': False, 'coordinate_metrics_available': False,
        'binding_or_function_assessed': False, 'new_training': False, 'paid_model_calls': False,
        'automatic_retries': False, 'context_limit': 65536}, 'Only fixed remaining22 is eligible')
    mandatory = ['positive_scope_review', 'independent_positive_scope_review', 'input_preparation_manifest',
        'root_scientific_adoption', 'cpu_validation_authorization', 'CPU_input_plan',
        'CPU_baseline_tokenizer_validation', 'CPU_tokenizer_validation', 'CPU_v032_dependency_receipt',
        'development_inputs', 'native_metric_source', 'runtime_tokenizer_preflight', 'packager',
        'runtime_common', 'checkpoint_audit', 'vetted_V06_worker', 'site_tools_helper',
        'vetted_neutral_hardware_source', 'shared_resource_binding', 'offline_dependency_manifest',
        'metadata_scope_proposal', 'references']
    if any(not isinstance(p.get(k), str) or not p[k] for k in mandatory):
        raise ValueError('Every required linked execution artifact must be declared')
    equal_fields(p, {'model_directory': '/dfs/scratch0/tchen/models/Qwen3.8-27B',
        'model_revision': contract.MODEL_REVISION, 'private_runtime_packages': offline_runtime.PINNED,
        'generation': protocol.GENERATION, 'endpoint': 'http://127.0.0.1:8450/v1'},
        'Exact model/generation/endpoint/package contract required')
    if Path(p['runtime_root']).resolve() != HERE / 'runtime':
        raise ValueError('Exact private remaining22 output root required')
    core = ['admission.py', 'build_plan.py', 'runtime_controls.py', 'server_identity.py',
        'offline_runtime.py', 'protocol.py', 'worker.py', 'worker.sbatch',
        'submit_once.py', 'score_locked.py', 'package.py']
    needed = {p[k] for k in mandatory} | {str(HERE / name) for name in core}
    needed |= set(p['validator_files_sha256']) | set(p['tokenizer_files_sha256'])
    if not needed <= set(p.get('frozen_files_sha256', {})):
        raise ValueError('Every linked source/input/review/authority file must be frozen')
    for path, digest in p['frozen_files_sha256'].items():
        controls.regular(path, digest)
    metadata = lambda path: controls.verified_json(path, p['frozen_files_sha256'][str(path)])
    manifest, preparation, _ = contract.verify_input_boundary(
        p['input_preparation_manifest'], p['positive_scope_review'], p['independent_positive_scope_review'])
    if (p['fixed_case_ids'] != manifest['fixed_remaining_cohort'] or p['cases'] != manifest['cases']
            or p['references'] != manifest['scorer_only_reference_path']
            or p['frozen_files_sha256'][p['references']] != manifest['scorer_only_reference_sha256']):
        raise ValueError('Exact reviewed22 manifest and opaque target binding required')
    if (p['metadata_scope_proposal'] != preparation['proposal_path']
            or Path(p['metadata_scope_proposal']).name != 'remaining22_metadata_scope_proposal_v2.json'
            or p['frozen_files_sha256'][p['metadata_scope_proposal']] != preparation['proposal_sha256']):
        raise ValueError('Accepted v2 scope proposal must replace stale v1 support pin')
    contract.verify_cpu_authority(p)
    cpu_sha = protocol.sha(p['CPU_input_plan'])
    for key in ['CPU_baseline_tokenizer_validation', 'CPU_tokenizer_validation']:
        contract.validate_cpu_receipt(metadata(p[key]), p, manifest,
                                      expected_plan_sha256=cpu_sha)
    checked = metadata(p['CPU_tokenizer_validation'])
    if (checked['packages']['vllm'] != '0.32.0'
            or checked['actual0_32_API_recheck_required_before_neural_phases'] is not False):
        raise ValueError('Actual vllm0.32 full24 API/context CPU gate required')
    equal_fields(metadata(p['CPU_v032_dependency_receipt']), {
        'packages': offline_runtime.PINNED, 'dependency_closure': p['offline_dependency_versions'],
        'pip_check_passed': True, 'all_other_distributions_unchanged': True},
        'Actual exact nine-wheel dependency/pip-check receipt required')
    adopted = metadata(p['root_scientific_adoption'])
    equal_fields(adopted, {'issuer': '/root', 'approved': True, 'task_id': 'P40',
        'role': 'exact_root_scientific_adoption_for_reviewed_P40_remaining22',
        'condition': protocol.CONDITION, 'planned': 22, 'development_planned': 2,
        'fixed_case_ids': p['fixed_case_ids'], 'model': protocol.MODEL,
        'model_revision': p['model_revision'], 'model_directory': p['model_directory'],
        'generation': protocol.GENERATION, 'precision': 'bfloat16', 'tensor_parallel_size': 1,
        'context_limit': 65536, 'existing38_unchanged': True, 'pooled_full60_metric_adopted': False,
        'automatic_retries': False, 'GPU_allocation_or_runtime_dispatch_admitted': False,
        'input_manifest_sha256': p['frozen_files_sha256'][p['input_preparation_manifest']],
        'independent_complete_input_review_sha256': p['frozen_files_sha256'][p['independent_positive_scope_review']],
        'CPU_validation_receipt_sha256': p['frozen_files_sha256'][p['CPU_baseline_tokenizer_validation']]},
        'Separate exact root scientific adoption required', PermissionError)
    equal_fields(adopted.get('artificial_delivery_gate', {}), {'planned': 2,
        'all_must_pass_before_any_fixed22_neural_attempt': True, 'one_attempt_each_no_automatic_retry': True},
        'Two artificial exact-copy delivery controls must precede fixed22 calls', PermissionError)
    controls.shared_configuration(p)
    controls.no_stop()
    if grant_path is not None:
        grant = controls.verified_json(grant_path, grant_sha)
        reviewer = grant.get('reviewer', grant.get('issuer'))
        if reviewer not in ['/root', '/root/classification_docs_review'] or reviewer == OWNER:
            raise PermissionError('Exact replacement independent reviewer or root required')
        equal_fields(grant, {'admitted': True, 'task_id': 'P40', 'condition': protocol.CONDITION,
            'plan_sha256': plan_sha, 'planned': 22, 'gpu_count': 1, 'project_gpu_ceiling': 8,
            'root_scientific_adoption_sha256': p['frozen_files_sha256'][p['root_scientific_adoption']],
            'shared_resource_binding_sha256': p['frozen_files_sha256'][p['shared_resource_binding']],
            'one_allocation_only': True, 'one_attempt_per_case': True,
            'allow_benchmark_only_after_artificial2': True, 'actual_v032_CPU_gate_passed': True,
            'source_adaptation_accepted': True, 'new_training': False, 'paid_model_calls': False,
            'native_full60_or_historical_equivalence': False, 'binding_or_function_assessed': False},
            'Exact independent implementation/runtime/resource admission required', PermissionError)
    elif require_job:
        raise PermissionError('Runtime/model work requires detached independent admission')
    if release_path is not None:
        controls.root_release(p, plan_sha, grant_sha, release_path, release_sha)
    elif require_job:
        raise PermissionError('Separate detached root scheduling/runtime release required')
    if require_job:
        controls.verify_submission(plan_path, plan_sha, grant_path, grant_sha, release_path, release_sha)
    return p


def current_project_audit(plan):
    return controls.capacity(plan, addition=0, own=True)
