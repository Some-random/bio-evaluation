"""All24 actual rendered messages and installed structured-regex API, CPU only."""
from pathlib import Path
import argparse,hashlib,importlib.metadata as metadata,json,os
import protocol
import preparation_contract as contract
HERE=Path(__file__).resolve().parent

def check(plan,output,*,input_plan_sha256):
    if os.environ.get('CUDA_VISIBLE_DEVICES')!='':raise ValueError('CPU-only validation requires hidden CUDA')
    # Read only metadata and opaque bytes until exact root CPU authority passes.
    manifest,_,_=contract.verify_input_boundary(plan['input_preparation_manifest'],plan['positive_scope_review'],plan['independent_positive_scope_review'])
    contract.verify_cpu_authority(plan)
    expected=contract.expected_cases(plan,manifest)
    from transformers import AutoTokenizer
    from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest
    from vllm.sampling_params import StructuredOutputsParams
    tokenizer=AutoTokenizer.from_pretrained(plan['model_directory'],local_files_only=True,trust_remote_code=False)
    records=[]
    for phase in ['development','benchmark']:
        for case in protocol.cases(plan,phase):
            body=protocol.payload(case);parsed=ChatCompletionRequest.model_validate(body)
            regex=protocol.output_regex(case['target_length'])
            if parsed.structured_outputs.regex!=regex or StructuredOutputsParams(regex=regex).regex!=regex:raise ValueError('Exact native HTTP regex not preserved')
            rendered=tokenizer.apply_chat_template(body['messages'],tokenize=False,add_generation_prompt=True,**body['chat_template_kwargs'])
            if body['messages'][0]['content']not in rendered:raise ValueError('Full structural input not preserved verbatim')
            encoded=tokenizer.apply_chat_template(body['messages'],tokenize=True,return_dict=True,truncation=False,add_generation_prompt=True,**body['chat_template_kwargs'])
            ids=encoded['input_ids'];ids=ids[0]if ids and isinstance(ids[0],list)else ids
            if len(ids)<10 or len(ids)+16384>65536:raise ValueError('Full structural input cannot fit untruncated')
            source=expected[len(records)]
            if (source['phase'],source['case_id'],source['target_length'])!=(phase,case['case_id'],case['target_length']):raise ValueError('Exact ordered full24 required')
            digest=lambda value:hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
            records.append({**source,'prompt_tokens':len(ids),'full_rendered_prompt_sha256':hashlib.sha256(rendered.encode()).hexdigest(),'request_sha256':digest(body),'token_ids_sha256':digest(ids),'native_HTTP_regex_preserved':True})
    result={'task_id':'P40','condition':protocol.CONDITION,'at_pacific':protocol.now(),'stage':'all24_actual_tokenizer_native_API_passed','all_full_inputs_fit':True,'references_read':False,'cases':records,
        'model':protocol.MODEL,'model_revision':contract.MODEL_REVISION,'model_directory':plan['model_directory'],'generation':protocol.GENERATION,'context_limit':contract.CONTEXT_LIMIT,'max_output_tokens':contract.OUTPUT_LIMIT,'input_truncation':False,
        'manifest_sha256':protocol.sha(plan['input_preparation_manifest']),'complete_input_review_sha256':protocol.sha(plan['independent_positive_scope_review']),
        'CPU_authorization_sha256':plan['cpu_validation_authorization_sha256'],'input_plan_sha256':input_plan_sha256,'input_basis_sha256':contract.input_basis_sha256(plan),'tokenizer_files_sha256':plan['tokenizer_files_sha256'],'validator_files_sha256':plan['validator_files_sha256'],
        'packages':{name:metadata.version(name)for name in ['vllm','transformers','torch']},'actual0_32_API_recheck_required_before_neural_phases':metadata.version('vllm')!='0.32.0','model_forwards':0,'GPU_allocations':0}
    contract.validate_cpu_receipt(result,plan,manifest,expected_plan_sha256=input_plan_sha256)
    protocol.write(output,result);return result
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--plan-sha256',required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    if args.plan.is_symlink()or protocol.sha(args.plan)!=args.plan_sha256:raise ValueError('Exact consumed CPU input-plan bytes required')
    result=check(json.loads(args.plan.read_bytes()),args.output,input_plan_sha256=args.plan_sha256)
    print(json.dumps({'task_id':'P40','cases':len(result['cases']),'all_full_inputs_fit':True,'model_forwards':0,'GPU_allocations':0,'output_sha256':protocol.sha(args.output)}))
