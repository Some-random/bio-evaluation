"""Target-isolated structural-input packaging; no files, reviews or dispatch.

This is an explicit proposed coordinate-JSON adapter, not certification of
Qwen's structural capability or an unchanged native neural tensor interface.
Only already normalized context is accepted.  Real eligibility is a separate
gate and is not established by these pure synthetic checks.
"""
from __future__ import annotations

import math

BACKBONE = ("N", "CA", "C", "O")
AMINO_ACIDS = set("ACDEFGHIKLMNPQRSTVWY")


def _coordinate(value):
    if not isinstance(value, (tuple, list)) or len(value) != 3:
        raise ValueError("Backbone coordinate must have three components")
    if not all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) for x in value):
        raise ValueError("Backbone coordinates must be finite numeric values")
    return [float(x) for x in value]


def package_case(case_id, chains, target_positions, antigen_context_keys):
    """Create a whitelisted packet from an independently gated case.

    chains is a dict with heavy/light/antigen lists of normalized residues.
    Each residue has chain_id, ordinal, number, insertion_code, aa, atoms.
    Antigen indices are supplied by the separately audited native metadata
    builder; this function never looks at masked target geometry to select them.
    """
    if not isinstance(case_id, str) or not case_id:
        raise ValueError("Missing case identity")
    if set(chains) != {"heavy", "light", "antigen"}:
        raise ValueError("Expected exact heavy, light and antigen roles")
    targets = set(target_positions)
    if len(targets) != len(target_positions) or not targets:
        raise ValueError("Target positions must be unique and nonempty")
    if any(isinstance(i, bool) or not isinstance(i, int) or not 0 <= i < len(chains["heavy"]) for i in targets):
        raise ValueError("Target position outside heavy chain")
    if sorted(targets) != list(range(min(targets), max(targets) + 1)):
        raise ValueError("The P40 CDRH3 target is one contiguous interval")
    context = list(antigen_context_keys)
    if len(context) != len(set(context)):
        raise ValueError("Antigen context keys must be unique")
    antigen = {(r["chain_id"], r["ordinal"]): r for r in chains["antigen"]}
    if len(antigen) != len(chains["antigen"]) or any(k not in antigen for k in context):
        raise ValueError("Unknown or duplicate antigen identity")

    def visible(residue, role, masked=False):
        # Explicit allowlist drops gold, source file paths, annotations, sidechain
        # coordinates and any additional fields supplied in a normalized row.
        out = {"role": role, "chain_id": residue["chain_id"], "ordinal": residue["ordinal"],
               "number": residue["number"], "insertion_code": residue.get("insertion_code", "")}
        if masked:
            out.update(aa="[MASK]", backbone=None)
        else:
            if residue["aa"] not in AMINO_ACIDS:
                raise ValueError("Unrecognized visible residue identity")
            atoms = residue["atoms"]
            if any(a not in atoms for a in BACKBONE):
                raise ValueError("Visible context needs all four backbone atoms")
            out.update(aa=residue["aa"], backbone={a: _coordinate(atoms[a]) for a in BACKBONE})
        return out

    rows = []
    for role in ("heavy", "light"):
        keys = [(r["chain_id"], r["ordinal"]) for r in chains[role]]
        if len(keys) != len(set(keys)):
            raise ValueError("Duplicate context residue identity")
        rows.extend(visible(r, role, role == "heavy" and i in targets) for i, r in enumerate(chains[role]))
    rows.extend(visible(antigen[key], "antigen") for key in context)
    return {"case_id": case_id, "adapter_variant": "P40_TARGET_ISOLATED_BACKBONE_JSON_PREPARATION_V1",
            "coordinates": "experimental context backbone in Angstrom; target atoms withheld",
            "requested_output": {"kind": "CDRH3 amino-acid sequence", "length": len(targets)},
            "target_heavy_positions": sorted(targets), "residues": rows}


def sequence_recovery(predicted, scorer_only_reference):
    """AAR only; caller keeps the reference outside the solver packet."""
    if not isinstance(scorer_only_reference, str) or not scorer_only_reference or any(c not in AMINO_ACIDS for c in scorer_only_reference):
        raise ValueError("Reference must be a nonempty canonical target sequence")
    valid = isinstance(predicted, str) and len(predicted) == len(scorer_only_reference) and all(c in AMINO_ACIDS for c in predicted)
    return {"valid_output": valid, "target_residues": len(scorer_only_reference),
            "correct_residues": sum(a == b for a, b in zip(predicted, scorer_only_reference)) if valid else 0,
            "residue_recovery": sum(a == b for a, b in zip(predicted, scorer_only_reference)) / len(scorer_only_reference) if valid else 0.0}
