"""Freeze the accepted fixed22 science and actual0.32 CPU/runtime source candidate."""
from pathlib import Path
import argparse
import json
import unittest
import protocol
import preparation_contract as contract
import runtime_controls as controls
import offline_runtime

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
ROOT = HERE.parents[4]
V2 = TASK/'remaining22_runtime_preparation_v2'


def build():
    if any((HERE/name).exists() for name in ['plan.json','CPU_validation_receipt.json']):
        raise FileExistsError('Preserve frozen candidate and validation history')
    cpu_path = V2/'CPU_precheck_plan.json'
    cpu = controls.verified_json(cpu_path,'faa739ca7da83dae2b19a5267f451981c3641e1d025d18d73363717f67599014')
    manifest,preparation,_ = contract.verify_input_boundary(cpu['input_preparation_manifest'],cpu['positive_scope_review'],cpu['independent_positive_scope_review'])
    contract.verify_cpu_authority(cpu)
    full32 = HERE/'actual_v032_CPU_tokenizer_validation.json'
    checked = controls.verified_json(full32,'6a7ef1b1969928c2f2e8f4891d51e505ed26d333867e2ceea50f56bd1647e5b8')
    contract.validate_cpu_receipt(checked,cpu,manifest,exact_runtime=True,expected_plan_sha256=protocol.sha(cpu_path))
    if checked['packages']['vllm'] != '0.32.0' or checked['actual0_32_API_recheck_required_before_neural_phases'] is not False:
        raise ValueError('Actual0.32 full24 gate remains mandatory')
    dependency = HERE/'actual_v032_closed_runtime_validation.json'
    closed = controls.verified_json(dependency,'f879c01d3d4132fb186b1f8a65342f68a494c91cda00cf1701dc9591a2b519ce')
    if closed['packages'] != offline_runtime.PINNED or not closed['pip_check_passed'] or not closed['all_other_distributions_unchanged']:
        raise ValueError('Exact installed0.32 dependency closure required')
    root_adoption = TASK/'remaining_coverage_20261022/root_scientific_adoption.json'
    controls.regular(root_adoption,'503ab6232504efd8f13b94ce42d58c6075c3c81e89e64f52f62ae1e0dbeae695')
    proposal = Path(preparation['proposal_path'])
    if proposal.name != 'remaining22_metadata_scope_proposal_v2.json':
        raise ValueError('Accepted v2 proposal support binding required')
    controls.regular(proposal,preparation['proposal_sha256'])
    preserved = json.loads((HERE/'preserved_v2_source_pins.json').read_bytes())
    for path,digest in preserved.items():controls.regular(path,digest)
    suite = unittest.defaultTestLoader.discover(str(HERE),pattern='test_*.py')
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    if not result.wasSuccessful():raise ValueError('Synthetic source/runtime tests failed')
    validation = {'at_pacific':protocol.now(),'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'actual_full24_v032_receipt_sha256':protocol.sha(full32),'dependency_receipt_sha256':protocol.sha(dependency),
        'model_forwards':0,'GPU_allocations':0,'benchmark_or_scheduler_dispatch':False,
        'maximum_prompt_tokens':max(r['prompt_tokens'] for r in checked['cases']),
        'all22_reviewed_inputs_unchanged':True,'original_v2_sources_unchanged':True}
    protocol.write(HERE/'CPU_validation_receipt.json',validation)
    prior_path = TASK/'current38_execution_v1/plan.json'
    prior = json.loads(prior_path.read_bytes())
    plan = {k:prior[k] for k in ['model_revision','model_directory','base_runtime','cuda_overlay','runtime_common',
        'checkpoint_audit','vetted_V06_worker','site_tools_helper','vetted_neutral_hardware_source']}
    plan.update({k:cpu[k] for k in ['cpu_validation_authorization','cpu_validation_authorization_sha256',
        'tokenizer_files_sha256','validator_files_sha256','input_preparation_manifest','positive_scope_review',
        'independent_positive_scope_review','development_inputs']})
    wheel_manifest = HERE/'offline_runtime_wheelhouse.json'
    wheels = controls.verified_json(wheel_manifest,'b7284fdc53ad13931f240f6648631e14ece17650832be258915061fa44300327')
    shared_path = ROOT/'.local/goal_restore_20261024/shared_resource_binding.json'
    shared = controls.verified_json(shared_path,'cb881370f7dac295d7d153f72baddcbf604c0fce0cc651ee82c557e5efcad6f9')
    license_path = HERE/'native_MEAN_LICENSE'
    if not license_path.exists():license_path.write_bytes((TASK/'current38_execution_v1/native_MEAN_LICENSE').read_bytes())
    native_source = Path(cpu['input_preparation_manifest']).parent/'source/native_generate.py'
    plan.update({'at_pacific':protocol.now(),'role':'frozen_P40_remaining22_runtime_candidate_requires_independent_and_root_releases',
        'owner':controls.OWNER,'task_id':'P40','condition':protocol.CONDITION,'model':protocol.MODEL,
        'generation':protocol.GENERATION,'private_runtime_packages':offline_runtime.PINNED,
        'planned':22,'development_planned':2,'fixed_case_ids':manifest['fixed_remaining_cohort'],'cases':manifest['cases'],
        'references':manifest['scorer_only_reference_path'],'metadata_scope_proposal':str(proposal),
        'root_scientific_adoption':str(root_adoption),'CPU_input_plan':str(cpu_path),
        'CPU_baseline_tokenizer_validation':str(V2/'CPU_tokenizer_validation.json'),
        'CPU_tokenizer_validation':str(full32),'CPU_v032_dependency_receipt':str(dependency),
        'runtime_tokenizer_preflight':str(V2/'safe_cpu_cli.py'),'native_metric_source':str(native_source),
        'native_metric':'MEAN per-case exact positional CDRH3 AAR; equal-case mean over fixed22; undefined unless all22 delivered',
        'packager':str(HERE/'package.py'),'runtime_root':str(HERE/'runtime'),'endpoint':'http://127.0.0.1:8450/v1',
        'context_limit':65536,'gpus_requested':1,'GPU_type':'A100_80GB','project_GPU_ceiling':8,
        'shared_resource_binding':str(shared_path),'project_gpu_audit_helper':shared['resource_adapter']['path'],
        'offline_dependency_manifest':str(wheel_manifest),'offline_dependency_archive':wheels['archive'],
        'offline_dependency_versions':{r['name']:r['version'] for r in wheels['wheels']},
        'new_training':False,'paid_model_calls':False,'automatic_retries':False,
        'native_full60_or_historical_equivalence':False,'coordinate_metrics_available':False,'binding_or_function_assessed':False,
        'one_allocation_only':True,'one_attempt_per_case':True,'all_artificial2_pass_before_fixed22':True,
        'runtime_repeats_exact_v032_CPU_full24_before_any_model':True,
        'scientific_differences':manifest['material_differences']+['Current public benchmark pretraining exposure is unknown; no contamination-free or explanation-support claim.']})
    local = sorted(HERE.glob('*.py'))+[HERE/'worker.sbatch',license_path]
    public = [*local,native_source,TASK/'remaining22_input_preparation_v1/prepare.py',
        TASK/'remaining22_input_preparation_v1/test_preparation.py',TASK/'engineering_20261020/structural_adapter.py']
    plan['public_code_paths'] = [str(p) for p in public]
    refs = [shared['resource_adapter'],shared['additional_proof_binding'],shared['root_authorization'],*shared['additional_root_proofs']]
    files = [*local,*public,Path(plan['references']),Path(plan['input_preparation_manifest']),Path(plan['positive_scope_review']),
        Path(plan['independent_positive_scope_review']),Path(plan['development_inputs']),root_adoption,proposal,cpu_path,
        Path(plan['cpu_validation_authorization']),Path(plan['CPU_baseline_tokenizer_validation']),full32,dependency,wheel_manifest,
        HERE/'CPU_validation_receipt.json',HERE/'preserved_v2_source_pins.json',prior_path,shared_path,
        V2/'CPU_preparation_final_checkpoint.json',V2/'independent_CPU_full24_receipt_review.json',
        HERE/'independent_actual_v032_CPU_receipt_review.json',
        *[Path(p) for p in plan['tokenizer_files_sha256']],*[Path(p) for p in plan['validator_files_sha256']],
        *[Path(r['path']) for r in refs],*[Path(r['solver_path']) for r in manifest['cases']],
        *[Path(plan[k]) for k in ['runtime_common','checkpoint_audit','vetted_V06_worker','site_tools_helper','vetted_neutral_hardware_source']],
        TASK.parent/'V06/local_execution_v2/v06_runner.py',
        *[ROOT/'.local/litqa2_replay'/name for name in ['runtime_archive.json','cuda_overlay_archive.json','cuda_overlay_deletions.json','publisher_verification.json']]]
    # Shared adapters themselves verify their constant hash-pinned ancestors.
    files.extend((ROOT/'.local/resource_accounting_20261022').glob('*.py'))
    plan['frozen_files_sha256'] = {str(p):protocol.sha(p) for p in sorted(set(files))}
    protocol.write(HERE/'plan.json',plan)
    print(json.dumps({'task_id':'P40','plan_sha256':protocol.sha(HERE/'plan.json'),
        'frozen_files':len(plan['frozen_files_sha256']),'tests_run':result.testsRun,'model_calls':0,'GPU_allocations':0}))
    return plan


if __name__ == '__main__':
    argparse.ArgumentParser(description=__doc__).parse_args()
    build()
