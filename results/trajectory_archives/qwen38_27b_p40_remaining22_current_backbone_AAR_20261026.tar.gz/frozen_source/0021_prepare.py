"""Prepare fixed remaining22 reference-isolated backbone-text inputs, CPU only.

Trusted projection reads only independently scope-admitted structures. Target
identities enter the separate scorer-only artifact; none enter the solver packet.
This is a declared text adapter, not MEAN/TorchDrug graph-model replication.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import hashlib
import importlib.util
import json
import math
import sys
import tarfile

ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
HERE=Path(__file__).resolve().parent
TASK=HERE.parent
CONDITION='P40_REMAINING22_CURRENT_IMGT_MASKED_BACKBONE_TEXT_AAR_V1'
AA3=dict(zip('ALA CYS ASP GLU PHE GLY HIS ILE LYS LEU MET ASN PRO GLN ARG SER THR VAL TRP TYR'.split(),'ACDEFGHIKLMNPQRSTVWY'))
BACKBONE=('N','CA','C','O')
SOURCE_ARCHIVE=ROOT/'.local/source_recovery_round2_2026-10-19/structural/source_archives/THUNLP-MT__MEAN.tar.gz'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x')as stream:json.dump(obj,stream,indent=2,allow_nan=False);stream.write('\n')
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def finite_point(values):
    if len(values)!=3 or not all(isinstance(v,(int,float))and not isinstance(v,bool)and math.isfinite(v)for v in values):
        raise ValueError('Nonfinite/malformed context coordinate')
    return list(values)

def compact_packet(packet):
    """Losslessly compact the existing allowlisted masked packet."""
    rows=[]
    for residue in packet['residues']:
        masked=residue['aa']=='[MASK]'
        if masked:
            if residue['role']!='heavy' or residue['backbone']is not None:raise ValueError('Target identity/coordinate isolation failed')
            atoms=None
        else:
            if residue['aa']not in AA3.values():raise ValueError('Noncanonical visible residue')
            atoms=[finite_point(residue['backbone'][a])for a in BACKBONE]
        rows.append([residue[k]for k in ['role','chain_id','ordinal','number','insertion_code','aa']]+[atoms])
    masked_rows=[row for row in rows if row[5]=='[MASK]']
    if len(masked_rows)!=packet['requested_output']['length']:raise ValueError('Fixed target mask length changed')
    return {'coordinate_unit':'angstrom','row_columns':['role','chain','ordinal','IMGT_or_source_number','insertion_code','aa','backbone'],
            'backbone_atom_order':list(BACKBONE),'backbone_coordinate_order':['x','y','z'],
            'target_heavy_positions':packet['target_heavy_positions'],'target_length':packet['requested_output']['length'],
            'residues':rows}

def messages(packet):
    instruction=('Reconstruct the amino-acid identities of the masked heavy-chain CDRH3 residues from the supplied antibody and antigen structural context. '
        'This is sequence reconstruction against an experimental reference, not a request to establish binding or biological activity. '
        'All masked residues have their amino-acid identities and backbone coordinates withheld. The remaining rows contain only context residues. '
        'Rows retain source order; backbone coordinates use N, CA, C, O atom order and x, y, z in angstroms. '
        'Return only compact JSON with the single key "sequence", giving exactly '+str(packet['target_length'])+
        ' canonical amino-acid letters, one for each masked heavy-chain residue in increasing ordinal order. No explanations.\n\n')
    return [{'role':'user','content':instruction+json.dumps(packet,separators=(',',':'),allow_nan=False)}]

def normalized_residue(chain_id,ordinal,residue,lookup):
    key=(chain_id,residue.number,residue.insertion)
    if key not in lookup:raise ValueError('Native selected residue missing from coordinate lookup')
    actual=lookup[key]
    if actual.name!=residue.name or residue.name not in AA3:raise ValueError('Canonical source identity differs')
    atoms={}
    for atom in actual:
        if atom.name in BACKBONE and atom.name not in atoms:
            atoms[atom.name]=finite_point([atom.pos.x,atom.pos.y,atom.pos.z])
    # No imputation: the packet adapter verifies every visible backbone atom.
    return {'chain_id':chain_id,'ordinal':ordinal,'number':residue.number,'insertion_code':residue.insertion,
            'aa':AA3[residue.name],'atoms':atoms}

def prepare(output):
    recovered=ROOT/'.local/source_recovery_round2_2026-10-19/rabd_imgt'
    sys.path.insert(0,str(recovered/'python_deps'))
    import gemmi
    helper_path=ROOT/'scripts/prepare_p40_structure_metadata_20261020.py'
    helper=load('p40_existing_native_metadata',helper_path)
    adapter_path=TASK/'engineering_20261020/structural_adapter.py'
    adapter=load('p40_allowlisted_packet',adapter_path)
    scope_path=TASK/'remaining_coverage_20261022/case_scope_review.json'
    scope=read(scope_path);ids=scope['allowed_case_ids']
    if scope.get('input_preparation_admitted')is not True or len(ids)!=22 or len(set(ids))!=22:raise ValueError('Exact independently admitted remaining22 required')
    old=read(TASK/'current38_execution_v1/plan.json')['fixed_case_ids']
    remaining=read(TASK/'independent_scope_metadata_v1/positive38_preparation_scope_review.json')['outside_this_positive_condition']
    if ids!=remaining or set(ids)&set(old):raise ValueError('Exact source-order untouched22, disjoint prior38 required')
    with tarfile.open(SOURCE_ARCHIVE)as tar:
        source=tar.extractfile(next(m for m in tar.getmembers()if m.name.endswith('/data/pdb_utils.py'))).read()
        native_score=tar.extractfile(next(m for m in tar.getmembers()if m.name.endswith('/generate.py'))).read()
    numbering=helper.native_mask_function(source)
    # Preserve exact metric source for audit, without executing upstream imports.
    source_dir=output/'source';source_dir.mkdir(parents=True,exist_ok=False)
    (source_dir/'native_generate.py').write_bytes(native_score)
    rows={r['case_id']:r for r in read(TASK/'metadata/current_structure_index.json')['cases']}
    refs={r['case_id']:r for r in read(TASK/'scorer_only/reference_coordinate_manifest.json')['cases']}
    records=[];gold=[];failures=[]
    for case_id in ids:
        meta=rows[case_id];ref=refs[case_id];path=ROOT/ref['full_unmasked_coordinate_path']
        if sha(path)!=ref['sha256']:raise ValueError('Pinned current structure changed')
        try:
            chains,_=helper.parse_chains(path,gemmi)
            contract=meta['current_chain_contract'];h,l=contract['heavy_chain'],contract['light_chain']
            selected,cdr=numbering(type('C',(),{'heavy_chain':h,'light_chain':l})(),chains,'imgt')
            structure=gemmi.read_structure(str(path));structure.merge_chain_parts()
            lookup={}
            for chain in structure[0]:
                for residue in chain:
                    if residue.het_flag!='A':continue
                    key=(chain.name,residue.seqid.num,residue.seqid.icode.strip())
                    if key in lookup:raise ValueError('Duplicate coordinate residue identity')
                    lookup[key]=residue
            normalized={role:[normalized_residue(c,i,r,lookup)for i,r in enumerate(selected[c].residues)]for role,c in [('heavy',h),('light',l)]}
            normalized['antigen']=[normalized_residue(c,i,r,lookup)for c in contract['antigen_chains']for i,r in enumerate(chains[c].residues)]
            start,end=cdr['CDR-H3'];targets=list(range(start,end+1))
            if [start,end]!=meta['heavy_chain']['cdrh3_zero_based_inclusive']:raise ValueError('Native frozen CDR mask changed')
            antigen=[(c,i)for c,indices in meta['antigen_interface_zero_based_indices'].items()for i in indices]
            packet=compact_packet(adapter.package_case(case_id,normalized,targets,antigen))
            record={'case_id':case_id,'condition_id':CONDITION,'target_length':len(targets),'messages':messages(packet)}
            solver_path=output/'solver_inputs'/f'{case_id}.json';save(solver_path,record)
            # Read only by the trusted future scorer after the complete prediction seal.
            target=''.join(normalized['heavy'][i]['aa']for i in targets)
            gold.append({'case_id':case_id,'target_sequence':target,'target_length':len(target),'source_sha256':ref['sha256']})
            records.append({'case_id':case_id,'target_length':len(targets),'solver_path':str(solver_path),
                'solver_sha256':sha(solver_path),'context_residue_count':len(packet['residues']),
                'antigen_context_count':len(antigen),'source_coordinate_sha256':ref['sha256'],
                'all_target_identities_and_coordinates_removed':True})
        except (ValueError,KeyError,AssertionError)as exc:
            failures.append({'case_id':case_id,'error_type':type(exc).__name__,'reason':str(exc)})
    save(output/'scorer_only/targets.json',{'role':'protected_reference_only_not_solver_input','condition_id':CONDITION,'cases':gold})
    manifest={'task_id':'P40','condition_id':CONDITION,'original_roster_count':60,'fixed_remaining_cohort':ids,'planned':22,
        'prepared':len(records),'failures':failures,'cases':records,'source_pins_sha256':{str(p):sha(p)for p in [scope_path,helper_path,adapter_path,TASK/'metadata/current_structure_index.json',TASK/'scorer_only/reference_coordinate_manifest.json',SOURCE_ARCHIVE,source_dir/'native_generate.py']},
        'scorer_only_reference_path':str(output/'scorer_only/targets.json'),'scorer_only_reference_sha256':sha(output/'scorer_only/targets.json'),
        'metric_contract':'Native per-case exact CDRH3 AAR and equal-weight arithmetic mean across all22 cases. A full22 metric is undefined if a complete valid prediction is missing; no favorable-case denominator.',
        'material_differences':['Independently reviewed remaining22 of original60 source entries; old38 is a disjoint previously completed condition; no scores pooled.',
            'Current official SAbDab IMGT coordinates are not certified historical processed MEAN bytes or graph equivalence.',
            'Qwen consumes losslessly compact JSON backbone context, not a trained MEAN coordinate graph.',
            'Target amino-acid identities and all target atom coordinates are withheld; input carries fixed CDRH3 length.',
            'Native source48-nearest antigen context indices are reused; these indices were computed from the experimental complex, including native target context, as in the released preparation.',
            'Only sequence recovery is scored; no generated-coordinate RMSD, TMscore, likelihood or functional-binding result is claimed.',
            'One prospective local-Qwen output per fixed case; no selective retry or trained head.'],
        'new_model_calls':0,'new_GPU_allocations':0,'benchmark_admitted':False}
    save(output/'manifest.json',manifest)
    status={'task_id':'P40','at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        'stage':'all22_reference_isolated_inputs_prepared'if not failures and len(records)==22 else 'fixed22_preparation_failures_preserved',
        'planned':22,'prepared':len(records),'failures':failures,'new_model_calls':0,'new_GPU_allocations':0,
        'native_full60_or_historical_equivalence_claimed':False,'benchmark_admitted':False,'manifest_sha256':sha(output/'manifest.json')}
    save(output/'status.json',status);return status

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=HERE/'prepared')
    args=parser.parse_args();print(json.dumps(prepare(args.output)))
