"""Recover only nine previously pinned public software wheels; no resolver/ML."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
import shutil
import tarfile
import urllib.parse
import urllib.request
import zipfile
import protocol

HERE = Path(__file__).resolve().parent
REPORT = HERE.parent / 'current38_execution_v1/runtime/pip_install_report.json'
REPORT_SHA = 'a2f4452d40ae4305040a11a464196fdc4fa8353311af643eb7004ab9595023c7'
EXPECTED = {'vllm': '0.32.0', 'humming-kernels': '0.1.17', 'nvidia-cutlass-dsl': '4.8.0',
            'nvidia-cutlass-dsl-libs-base': '4.8.0', 'nvidia-cutlass-dsl-libs-core': '4.8.0',
            'nvidia-cutlass-dsl-libs-cu12': '4.8.0', 'nvidia-cutlass-dsl-libs-cu13': '4.8.0',
            'tokenspeed-mla': '0.2.15', 'xgrammar': '0.2.8'}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def prepare():
    if protocol.sha(REPORT) != REPORT_SHA:
        raise ValueError('Original successful pinned installation report changed')
    report = json.loads(REPORT.read_bytes())
    if {i['metadata']['name'].lower(): i['metadata']['version'] for i in report['install']} != EXPECTED:
        raise ValueError('Exact original nine-wheel closure required')
    local = Path('/tmp/bioeval_p40_26129_cpu_restore_7r1ybuqz/pinned_wheelhouse')
    local.mkdir(mode=0o700)
    protocol.write(HERE / 'pinned_software_source_acquisition_intent.json', {
        'at_pacific': protocol.now(), 'role': 'fixed_public_software_dependency_source_recovery_no_model_calls',
        'standing_scope': 'Public source acquisition and reversible local runtime preparation',
        'original_report_sha256': REPORT_SHA, 'exact_versions': EXPECTED,
        'host_allowlist': ['files.pythonhosted.org'], 'resolver_or_online_fallback': False,
        'automatic_retry': False, 'local_directory': str(local), 'model_forwards': 0, 'GPU_allocations': 0})
    opener = urllib.request.build_opener(NoRedirect())

    def one(item):
        name = item['metadata']['name'].lower()
        info = item['download_info']
        url = info['url']
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != 'https' or parsed.hostname != 'files.pythonhosted.org' or parsed.username or parsed.password:
            raise ValueError('Only exact recorded official software artifact URLs permitted')
        expected = info['archive_info']['hashes']['sha256']
        target = local / Path(parsed.path).name
        if not target.name.endswith('.whl'):
            raise ValueError('Only recorded wheel artifacts permitted')
        cache_key = hashlib.sha224(url.encode()).hexdigest()
        cached = Path('/sailhome/dongweij/.cache/pip/http-v2') / Path(*cache_key[:5]) / (cache_key + '.body')
        network = not cached.is_file()
        h = hashlib.sha256()
        with target.open('xb') as output:
            source = opener.open(url, timeout=180) if network else cached.open('rb')
            with source:
                while chunk := source.read(8 * 1024 * 1024):
                    h.update(chunk)
                    output.write(chunk)
            output.flush()
            os.fsync(output.fileno())
        if h.hexdigest() != expected:
            raise ValueError('Recorded publisher artifact digest differs')
        with zipfile.ZipFile(target) as bundle:
            if bundle.testzip() is not None:
                raise ValueError('Pinned wheel archive integrity failed')
        return {'name': name, 'version': item['metadata']['version'], 'filename': target.name,
                'publisher_url': url, 'sha256': expected, 'bytes': target.stat().st_size,
                'source_was_existing_cache': not network, 'software_artifact_GET_requests': int(network)}

    with ThreadPoolExecutor(max_workers=2) as executor:
        rows = list(executor.map(one, report['install']))
    archive = local.parent / 'offline_runtime_wheelhouse.tar'
    with tarfile.open(archive, 'x') as bundle:
        for row in rows:
            bundle.add(local / row['filename'], arcname=row['filename'], recursive=False)
    support = HERE / 'support'
    support.mkdir()
    destination = support / archive.name
    shutil.copyfile(archive, destination)
    digest = protocol.sha(archive)
    if protocol.sha(destination) != digest:
        raise ValueError('Frozen single-file dependency wheelhouse copy differs')
    result = {'at_pacific': protocol.now(), 'role': 'exact_nine_original_publisher_wheels_for_offline_private_runtime',
              'prior_successful_install_report': str(REPORT), 'prior_report_sha256': REPORT_SHA,
              'archive': {'path': str(destination), 'sha256': digest, 'bytes': destination.stat().st_size},
              'wheels': rows, 'software_artifact_GET_requests': sum(r['software_artifact_GET_requests'] for r in rows),
              'resolver_or_online_runtime_fallback': False, 'model_forwards': 0, 'GPU_allocations': 0,
              'biological_packets_or_protected_targets_read': False, 'local_wheel_directory': str(local)}
    protocol.write(HERE / 'offline_runtime_wheelhouse.json', result)
    return {'wheelhouse_sha256': digest, 'wheels': len(rows),
            'software_artifact_GET_requests': result['software_artifact_GET_requests'],
            'model_forwards': 0, 'GPU_allocations': 0}


if __name__ == '__main__':
    print(json.dumps(prepare()))
