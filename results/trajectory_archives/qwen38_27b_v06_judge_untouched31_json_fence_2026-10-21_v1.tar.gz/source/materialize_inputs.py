"""Exact local V06 input/reference packaging. No network or model transport."""
from __future__ import annotations
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
from PIL import Image

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
HERE = Path(__file__).resolve().parent
SOURCE_ROOT = ROOT / '.local/continuation_2026-10-16/source_prep'
SOURCE = SOURCE_ROOT / 'sources/llava_main/data/eval/llava_med_eval_qa50_qa.jsonl'
INPUT_ONLY = SOURCE_ROOT / 'data/V06/input_only_questions.jsonl'
ACQUIRED = ROOT / '.local/source_acquisition_2026-10-19/vision/v06/manifest.json'
ADAPTER = HERE.parent / 'offline_judge_preparation_v1/offline_judge.py'
ADAPTER_PIN = '95477fd9cc01cd8921f302312b560a98903e39e6656ea6adb5a3fe83905fbaf1'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)
        f.write('\n')
    path.chmod(0o600)

def load_adapter():
    if sha(ADAPTER) != ADAPTER_PIN:
        raise ValueError('Previous offline contract changed; review required')
    spec = importlib.util.spec_from_file_location('v06_offline_contract', ADAPTER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def validate_admission(rows, images, admission):
    ids = [row['question_id'] for row in rows]
    if (admission.get('task_id') != 'V06' or admission.get('source_question_sha256') != sha(SOURCE)
            or admission.get('source_image_manifest_sha256') != sha(ACQUIRED)
            or admission.get('source_planned_denominator') != 193
            or admission.get('question_content_reviewed') != len(rows)
            or admission.get('images_visually_reviewed') != len(images)
            or admission.get('admitted_question_ids') != ids
            or admission.get('held_or_interrupted_scope_reused') is not False
            or admission.get('excluded_question_ids') != []):
        raise ValueError('An exact, complete, independent V06 admission is required')
    if ids != list(range(193)):
        raise ValueError('Released source ID/order changed')

def main():
    adapter = load_adapter()
    rows = [json.loads(x) for x in SOURCE.read_text().splitlines() if x.strip()]
    input_only = [json.loads(x) for x in INPUT_ONLY.read_text().splitlines() if x.strip()]
    images = json.loads(ACQUIRED.read_text())
    admission = json.loads((HERE / 'admission.json').read_text())
    validate_admission(rows, images, admission)
    split = adapter.split_source_questions(rows, expected_count=193, expected_ids=list(range(193)))
    if split['solver_inputs'] != input_only:
        raise ValueError('Exact native solver projection differs from prior input-only source')
    pairs = {r['pair_id']: r for r in images}
    if len(pairs) != 50 or set(pairs) != {r['pair_id'] for r in rows}:
        raise ValueError('Exact 193-question/50-image join failed')
    image_records = []
    for pair_id, r in pairs.items():
        image_path = Path(r['image_path'])
        if not (r['status'] == 'verified_exact_article_and_filename'
                and r['exact_source_filename_matched'] is True
                and sha(image_path) == r['image_sha256']
                and sha(r['metadata_path']) == r['metadata_sha256']
                and hashlib.md5(image_path.read_bytes()).hexdigest() == r['official_current_md5']):
            raise ValueError('Image/media provenance verification failed')
        source_names = {q['image'] for q in rows if q['pair_id'] == pair_id}
        if source_names != {pair_id + '.jpg'}:
            raise ValueError('Released image basename changed')
        with Image.open(image_path) as im:
            im.load()
            decoded = {'format': im.format, 'mode': im.mode,
                       'width': im.width, 'height': im.height}
        image_records.append({**r, 'released_image_basename': pair_id + '.jpg',
                              'question_ids': [q['question_id'] for q in rows if q['pair_id'] == pair_id],
                              'decoded': decoded, 'local_packet_relative_path': 'images/' + pair_id + '.jpg'})
    packet_dir = HERE / 'packets'
    packet_dir.mkdir(exist_ok=False)
    (packet_dir / 'images').mkdir()
    for record in image_records:
        target = packet_dir / record['local_packet_relative_path']
        shutil.copyfile(record['image_path'], target)
        target.chmod(0o600)
        if sha(target) != record['image_sha256']:
            raise ValueError('Packet image copy changed bytes')
    for name, value in split.items():
        save(packet_dir / (name + '.json'), value)
    save(packet_dir / 'image_manifest.json', image_records)
    file_pins = {str(p.relative_to(packet_dir)): sha(p) for p in sorted(packet_dir.rglob('*')) if p.is_file()}
    validation = {
        'task_id': 'V06', 'passed': True, 'source_planned_denominator': 193,
        'admitted': 193, 'excluded': 0, 'unique_images': 50,
        'exact_source_projection_matches_prior_input_only': True,
        'question_order_and_text_unchanged': True, 'original_image_marker_preserved': True,
        'solver_only_fields': list(adapter.SOLVER_FIELDS),
        'judge_only_fields': list(adapter.JUDGE_CONTEXT_FIELDS),
        'source_references_not_exposed_to_solver': True,
        'source_image_bytes_copied_without_reencoding': True,
        'verified_source_and_packet_image_hashes': 50,
        'verified_official_current_media_md5': 50,
        'verified_source_metadata_hashes': 50,
        'historical_publisher_image_digest_verified': False,
        'image_provenance_qualification': 'Exact article and original filename; current official NCBI media MD5 verified. Historical publisher bytes were not independently recovered.',
        'question_type_counts': dict(collections.Counter(r['question_type'] for r in split['manifest'])),
        'native_first_true_domain_counts': dict(collections.Counter(r['domain'] for r in split['manifest'])),
        'source_question_sha256': sha(SOURCE), 'prior_input_only_sha256': sha(INPUT_ONLY),
        'source_image_manifest_sha256': sha(ACQUIRED), 'adapter_sha256': sha(ADAPTER),
        'admission_sha256': sha(HERE / 'admission.json'), 'packet_file_sha256': file_pins,
        'packet_bundle_sha256': canonical(file_pins),
        'new_inference_calls': 0, 'judge_calls': 0, 'model_forwards': 0,
        'benchmark_score_computed': False, 'runtime_admission_granted': False,
    }
    save(HERE / 'packet_validation.json', validation)
    print(json.dumps({k: validation[k] for k in ('passed', 'admitted', 'excluded', 'unique_images', 'packet_bundle_sha256')}))

if __name__ == '__main__':
    main()
