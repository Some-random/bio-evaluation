"""V06 one-attempt solver -> closed predictions -> declared local judge.

Network transport exists only in the separately admitted Slurm worker. CPU
verification uses the recording transport and neutral artificial source rows.
"""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import time
from datetime import datetime
from zoneinfo import ZoneInfo

HERE=Path(__file__).resolve().parent
PREP=HERE.parent/'real_input_preparation_v1'
SCORER=HERE.parent/'offline_judge_preparation_v1/offline_judge.py'

def stamp():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as stream:json.dump(value,stream,indent=2,ensure_ascii=False,allow_nan=False);stream.write('\n')
    path.chmod(0o600)
def current(path,value):
    path=Path(path);temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temp.chmod(0o600);temp.replace(path)
def source_modules():
    spec=importlib.util.spec_from_file_location('v06_exact_offline',SCORER);scorer=importlib.util.module_from_spec(spec);spec.loader.exec_module(scorer)
    sys.path.insert(0,str(PREP))
    try:
        spec=importlib.util.spec_from_file_location('v06_exact_render',PREP/'render_envelopes.py');render=importlib.util.module_from_spec(spec);spec.loader.exec_module(render)
    finally:sys.path.pop(0)
    return scorer,render

class TransportFailure(RuntimeError):
    def __init__(self,message,http_status=None,raw=b''):super().__init__(message);self.http_status=http_status;self.raw=raw

class RecordingTransport:
    def __init__(self,callback):self.callback=callback;self.calls=[]
    def send(self,phase,question_id,payload):
        self.calls.append((phase,question_id,copy.deepcopy(payload)))
        result=self.callback(phase,question_id,payload)
        if isinstance(result,Exception):raise result
        if isinstance(result,bytes):return result
        return json.dumps(result,allow_nan=False).encode()

def parse_response(raw):
    final_info={'final_field_observed':False,'observed_empty_final':None,'reasoning_present':False}
    try:
        value=json.loads(raw,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('Nonfinite JSON')))
        choices=value['choices'];choice=choices[0]
        if len(choices)!=1 or not isinstance(choice['message'],dict):raise ValueError('Exactly one completion required')
        message=choice['message'];content=message.get('content');finish=choice.get('finish_reason')
        final_info['reasoning_present']=bool(message.get('reasoning_content') or message.get('reasoning'))
        if 'content' in message and (isinstance(content,str) or content is None):
            final_info.update(final_field_observed=True,observed_empty_final=content is None or not content.strip())
        refusal=message.get('refusal')
        if refusal or finish in ['content_filter','safety']:
            return {'status':'refusal','text':content if isinstance(content,str) else None,'finish_reason':finish,'response_saved':True,'stop':True,**final_info}
        if not isinstance(content,str) or finish not in ['stop','length']:raise ValueError('Invalid content or finish reason')
        if re.match(r"^\s*(?:i(?:'m|’m| am) sorry[,!.]?\s*)?i (?:cannot|can't|can’t|am unable to)\b",content,re.I):
            return {'status':'refusal','text':content,'finish_reason':finish,'response_saved':True,'stop':True,**final_info}
        if finish=='length':return {'status':'truncated','text':content,'finish_reason':finish,'response_saved':True,'stop':False,**final_info}
        if not content.strip():raise ValueError('Empty normal final')
        return {'status':'completed','text':content,'finish_reason':finish,'response_saved':True,'stop':False,'usage':value.get('usage',{}),**final_info}
    except (KeyError,TypeError,IndexError,ValueError) as error:
        return {'status':'response_error','text':None,'finish_reason':None,'response_saved':True,'stop':True,'error_type':type(error).__name__,'error':str(error),**final_info}

def call_once(folder,phase,index,qid,payload,transport,context_check):
    path=folder/f'{index:03d}';path.mkdir(parents=True,exist_ok=False)
    save(path/'request.json',payload)
    context_check(payload)  # Full unchanged input must fit, before any transport.
    save(path/'transport_intent.json',{'at_pacific':stamp(),'phase':phase,'question_id':qid,'request_sha256':sha(path/'request.json'),
      'meaning':'One permitted local transport invocation about to start; not proof of server delivery'})
    try:
        raw=transport.send(phase,qid,payload)
        with (path/'response.body').open('xb') as stream:stream.write(raw)
        outcome=parse_response(raw)
        outcome.update(raw_response_sha256=sha(path/'response.body'),transport_call_returned=True)
    except TransportFailure as error:
        outcome={'status':'transport_error','text':None,'finish_reason':None,'response_saved':False,'stop':True,
          'transport_call_returned':True,'http_status':error.http_status,'error':str(error)}
        if error.raw:
            with (path/'http_error.body').open('xb') as stream:stream.write(error.raw)
    outcome.update(question_id=qid,at_pacific=stamp(),request_sha256=sha(path/'request.json'))
    save(path/'outcome.json',outcome);return outcome

def summary(rows,planned):
    attempted=[r for r in rows if r.get('transport_call_returned')]
    return {'planned':planned,'attempted_with_observed_outcome':len(attempted),'terminal_observed':len(attempted),
      'responses_saved':sum(r.get('response_saved',False) for r in attempted),
      'transport_errors':sum(r['status']=='transport_error' for r in attempted),
      'http_errors':sum(r.get('http_status') is not None for r in attempted),
      'response_errors':sum(r['status']=='response_error' for r in attempted),
      'refusals':sum(r['status']=='refusal' for r in attempted),
      'truncations':sum(r['status']=='truncated' for r in attempted),
      'empty_finals':sum(r.get('observed_empty_final') is True for r in attempted),
      'final_fields_not_observed_in_saved_response':sum(r.get('response_saved',False) and r.get('final_field_observed') is not True for r in attempted),
      'reasoning_present':sum(r.get('reasoning_present',False) for r in attempted),
      'missing_finals_due_to_transport':sum(r['status']=='transport_error' for r in attempted),
      'not_dispatched_after_stop':sum(r['status']=='not_dispatched_after_stop' for r in rows),
      'attempts_without_outcome_are_unknown_not_retryable':True}

def gate(plan,folder,transport,context_check):
    scorer,render=source_modules();generation=plan['model_configuration'];declaration=plan['judge_declaration']
    neutral=read(plan['neutral_gate_inputs'])
    for phase in ['development_solver','development_judge']:
        rows=[]
        for index,case in enumerate(neutral['cases']):
            payload=copy.deepcopy(case['solver_envelope'])
            if phase=='development_judge':
                packet={**case['judge_packet'],'condition':scorer.CONDITION,'judge_declaration':declaration}
                payload=render.judge_envelope(packet,generation)
            outcome=call_once(folder/phase,phase,index,case['question_id'],payload,transport,context_check)
            if outcome['status']!='completed':raise RuntimeError('Neutral delivery gate failed; no benchmark dispatch')
            if phase=='development_solver' and outcome['text'].strip().lower().rstrip('.')!=case['expected_neutral_solver_final']:
                raise RuntimeError('Neutral image/text delivery contract failed; no benchmark dispatch')
            if phase=='development_judge':render.parse_judge_output(outcome['text'],packet)
            rows.append(outcome)
        save(folder/(phase+'_completion.json'),{'at_pacific':stamp(),'all_passed':True,'planned':len(rows),'terminal':len(rows),
          'delivery_only_not_benchmark_score':True,'outcomes':rows})

def run_protocol(plan,folder,transport,context_check=lambda payload:None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False)
    scorer,render=source_modules();manifest=read(plan['manifest']);inputs=read(plan['solver_inputs']);contexts=read(plan['judge_contexts'])
    ids=scorer.validate_manifest(manifest);scorer.checked_ids(inputs,ids);scorer.checked_ids(contexts,ids)
    if len(ids)!=plan['planned']:raise ValueError('Full source denominator changed')
    if plan['execution_scope']=='retained_V06_real193' and ids!=list(range(193)):raise ValueError('V06 requires unchanged all193 source order')
    if plan['execution_scope']=='artificial_fixture' and type(transport) is not RecordingTransport:raise ValueError('Artificial workflow cannot use live transport')
    save(folder/'run_manifest.json',{'at_pacific':stamp(),'plan_sha256':scorer.digest(plan),'configuration':plan,
      'all_historical_outputs_unchanged':True,'selective_retry':False})
    state={'at_pacific':stamp(),'stage':'neutral_delivery_gates','full_catalog_complete':False}
    current(folder/'progress.json',state)
    try:gate(plan,folder,transport,context_check)
    except Exception as error:
        save(folder/'completion.json',{'at_pacific':stamp(),'stage':'development_failed_no_benchmark_dispatch',
          'error_type':type(error).__name__,'error':str(error),'planned':len(ids),'benchmark_dispatch_by_this_controller':False})
        raise
    predictions=[];outcomes=[];stopped=False
    envelopes=read(plan['solver_envelope_manifest'])['envelopes']
    scorer.checked_ids(envelopes,ids)
    for index,row in enumerate(envelopes):
        if stopped:
            outcomes.append({'question_id':row['question_id'],'status':'not_dispatched_after_stop'});continue
        payload=read(row['path'])
        if sha(row['path'])!=row['sha256'] or payload['max_tokens']!=16384:raise ValueError('Frozen solver envelope changed')
        outcome=call_once(folder/'solver', 'benchmark_solver',index,row['question_id'],payload,transport,context_check)
        outcomes.append(outcome);predictions.append({key:outcome[key] for key in ['question_id','status','text']})
        stopped=outcome['stop']
        current(folder/'progress.json',{'at_pacific':stamp(),'stage':'solver_stopped_for_review' if stopped else 'solver_generation',
          'solver':summary(outcomes,len(ids)),'native_scoring_status':'not_started'})
    save(folder/'solver_outcomes.json',outcomes);save(folder/'predictions.json',predictions)
    save(folder/'solver_summary.json',summary(outcomes,len(ids)))
    if stopped:
        save(folder/'completion.json',{'at_pacific':stamp(),'stage':'solver_stopped_for_review','solver':summary(outcomes,len(ids)),
          'prediction_lock_sealed':False,'judge_calls':0,'benchmark_score_computed':False})
        return read(folder/'completion.json')
    lock=scorer.seal_predictions(manifest,predictions);save(folder/'prediction_lock.json',lock)
    packet_set=scorer.build_review_packets(manifest,inputs,contexts,predictions,lock,plan['judge_declaration'])
    save(folder/'review_packets.json',packet_set)
    packets={scorer.id_key(row['question_id']):row for row in packet_set['packets']};judgements=[];judge_outcomes=[];stopped=False
    for index,qid in enumerate(ids):
        packet=packets.get(scorer.id_key(qid))
        if packet is None:
            judge_outcomes.append({'question_id':qid,'status':'not_applicable_solver_failure'});continue
        if stopped:
            judge_outcomes.append({'question_id':qid,'status':'not_dispatched_after_stop'});continue
        payload=render.judge_envelope(packet,plan['model_configuration'])
        outcome=call_once(folder/'judge','benchmark_judge',index,qid,payload,transport,context_check)
        if outcome['status']=='completed':
            try:judgement=render.parse_judge_output(outcome['text'],packet)
            except (ValueError,TypeError) as error:
                outcome.update(status='response_error',stop=True,error_type=type(error).__name__,error=str(error))
            else:judgements.append(judgement)
        save(folder/'judge'/f'{index:03d}'/'parsed_outcome.json',outcome)
        judge_outcomes.append(outcome);stopped=outcome['stop']
        current(folder/'progress.json',{'at_pacific':stamp(),'stage':'judge_stopped_for_review' if stopped else 'local_judging',
          'solver':summary(outcomes,len(ids)),'judge':summary(judge_outcomes,len(ids)),'native_scoring_status':'waiting_for_judge_closure'})
    save(folder/'judge_outcomes.json',judge_outcomes);save(folder/'judgements.json',judgements)
    save(folder/'judge_lock.json',{'closed':True,'planned':len(ids),'outcomes_sha256':sha(folder/'judge_outcomes.json'),
      'judgements_sha256':sha(folder/'judgements.json'),'prediction_lock_sha256':sha(folder/'prediction_lock.json'),
      'judge_declaration_sha256':scorer.validate_judge_declaration(plan['judge_declaration'])})
    scores=scorer.aggregate_judgements(manifest,predictions,lock,judgements,plan['judge_declaration']);save(folder/'scores.json',scores)
    complete=scores['groups']['overall']['complete']
    result={'at_pacific':stamp(),'stage':'scored_terminal' if complete else 'terminal_incomplete_primary_undefined',
      'solver':summary(outcomes,len(ids)),'judge':summary(judge_outcomes,len(ids)),
      'prediction_lock_sealed':True,'judge_outcome_lock_sealed':True,'benchmark_primary_defined':complete,
      'released_mean_case_ratio_score':scores['groups']['overall']['released_mean_case_ratio_score'],
      'clinical_accuracy_claim':False,'original_GPT4_judge_reproduced':False,'full_catalog_complete':False}
    save(folder/'completion.json',result);current(folder/'progress.json',result);return result
