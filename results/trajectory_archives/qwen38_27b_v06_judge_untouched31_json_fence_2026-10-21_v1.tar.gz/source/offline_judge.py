"""V06 offline human/declared-local-judge adaptation. No model or network calls.

The released GPT-4-0314 judge is not reproduced. The mean of per-case score
ratios is preserved; any missing/invalid case remains in explicit accounting.
All real-data materialization and judging remain separate from synthetic tests.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path

CONDITION = 'LLAVA_MED_QA50_HUMAN_OR_DECLARED_LOCAL_JUDGE_ADAPTATION_V1'
DOMAINS = ('chest_xray', 'mri', 'histology', 'gross', 'ct_scan')
QUESTION_TYPES = ('conversation', 'detailed_description')
SOLVER_FIELDS = ('question_id', 'image', 'pair_id', 'text')
JUDGE_CONTEXT_FIELDS = ('question_id', 'fig_label', 'fig_caption', 'in_text_mention', 'gpt4_answer')
PREDICTION_FIELDS = {'question_id', 'status', 'text'}
JUDGEMENT_FIELDS = {'question_id', 'reference_score', 'candidate_score', 'comment', 'judge_declaration_sha256'}
TERMINAL_STATUSES = {'completed', 'transport_error', 'response_error', 'refusal', 'truncated'}
RUBRIC = {
    'condition': CONDITION,
    'criteria': ['helpfulness', 'relevance', 'accuracy', 'level of detail'],
    'instruction': 'Give each answer an overall score from 1 through 10 under the same criteria. Explain the judgement and avoid answer-order bias.',
    'reference_identity': 'The released GPT-4 teacher answer is a comparator, not independently established clinical ground truth.',
    'judge_backend': 'Human, or a separately declared local judge whose model/version/configuration must be frozen before use.',
    'local_judge_execution_included': False,
    'clinical_correctness_claim': False,
}

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def id_key(value):
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise ValueError('Question IDs must be non-boolean integers or nonempty strings')
    if isinstance(value, str) and not value.strip():
        raise ValueError('Empty question ID')
    return type(value).__name__, value

def checked_ids(rows, expected=None, *, label='records', subset=False):
    if not isinstance(rows, list):
        raise ValueError(label + ' must be a list')
    ids = [id_key(row['question_id']) for row in rows]
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate question ID in ' + label)
    if expected is not None:
        wanted = [id_key(value) for value in expected]
        if len(wanted) != len(set(wanted)):
            raise ValueError('Duplicate expected question ID')
        if subset:
            positions = {value: i for i, value in enumerate(wanted)}
            if any(value not in positions for value in ids):
                raise ValueError('Foreign question ID in ' + label)
            if [positions[value] for value in ids] != sorted(positions[value] for value in ids):
                raise ValueError('Question order mismatch in ' + label)
        elif ids != wanted:
            raise ValueError('Question identity/order/count mismatch in ' + label)
    return ids

def validate_manifest(manifest):
    if not manifest:
        raise ValueError('A nonempty complete manifest is required')
    checked_ids(manifest, label='manifest')
    for row in manifest:
        if set(row) != {'question_id', 'question_type', 'domain'}:
            raise ValueError('Manifest must contain only whitelisted judge metadata')
        if row['question_type'] not in QUESTION_TYPES:
            raise ValueError('Unknown question type')
        if row['domain'] not in DOMAINS and row['domain'] is not None:
            raise ValueError('Unknown image domain')
    return [row['question_id'] for row in manifest]

def split_source_questions(rows, *, expected_count, expected_ids=None):
    """Keep model-visible fields separate from teacher/context metadata."""
    if len(rows) != expected_count or expected_count <= 0:
        raise ValueError('Source question count differs from declared cohort')
    checked_ids(rows, expected_ids, label='source questions')
    solver, contexts, manifest = [], [], []
    for row in rows:
        if not all(isinstance(row.get(k), str) and row[k].strip() for k in ('image', 'text', 'gpt4_answer')):
            raise ValueError('Required image/question/reference answer is empty')
        if row.get('type') not in QUESTION_TYPES:
            raise ValueError('Unknown question type')
        domain = row.get('domain')
        if not isinstance(domain, dict) or any(not isinstance(domain.get(k), bool) for k in DOMAINS):
            raise ValueError('Expected released boolean domain metadata')
        # Same first-true domain priority as released summarize_gpt_review.py.
        group = next((name for name in DOMAINS if domain[name]), None)
        solver.append({k: copy.deepcopy(row[k]) for k in SOLVER_FIELDS if k in row})
        contexts.append({k: copy.deepcopy(row[k]) for k in JUDGE_CONTEXT_FIELDS if k in row})
        manifest.append({'question_id': row['question_id'], 'question_type': row['type'], 'domain': group})
    validate_manifest(manifest)
    return {'solver_inputs': solver, 'judge_contexts': contexts, 'manifest': manifest}

def validate_predictions(manifest, predictions):
    expected = validate_manifest(manifest)
    checked_ids(predictions, expected, label='terminal predictions')
    for row in predictions:
        if set(row) != PREDICTION_FIELDS or row['status'] not in TERMINAL_STATUSES:
            raise ValueError('Expected terminal prediction status and whitelisted fields')
        if row['text'] is not None and not isinstance(row['text'], str):
            raise ValueError('Prediction text must be a string or null')
    return expected

def seal_predictions(manifest, predictions):
    validate_predictions(manifest, predictions)
    return {'condition': CONDITION, 'generation_closed': True,
            'manifest_sha256': digest(manifest), 'predictions_sha256': digest(predictions),
            'planned': len(manifest), 'terminal_records': len(predictions)}

def verify_lock(manifest, predictions, lock):
    if lock != seal_predictions(manifest, predictions):
        raise ValueError('Exact complete prediction lock mismatch')

def delivered(row):
    return row['status'] == 'completed' and isinstance(row['text'], str) and bool(row['text'].strip())

def validate_judge_declaration(declaration):
    required={'condition','kind','identity','rubric_sha256'}
    allowed=required|{'model_configuration_sha256'}
    if not isinstance(declaration,dict) or set(declaration)-allowed or not required.issubset(declaration):
        raise ValueError('A separate whitelisted judge declaration is required')
    if declaration['condition']!=CONDITION or declaration['rubric_sha256']!=digest(RUBRIC):
        raise ValueError('Judge condition/rubric pin mismatch')
    if declaration['kind'] not in ('human','local_model') or not isinstance(declaration['identity'],str) or not declaration['identity'].strip():
        raise ValueError('A human reviewer or exact local-model identity must be declared')
    if declaration['kind']=='local_model':
        pin=declaration.get('model_configuration_sha256')
        if not isinstance(pin,str) or len(pin)!=64 or any(c not in '0123456789abcdef' for c in pin):
            raise ValueError('Local-model configuration must be pinned before judging')
    elif 'model_configuration_sha256' in declaration:
        raise ValueError('Human judging must not masquerade as a model configuration')
    return digest(declaration)

def build_review_packets(manifest, solver_inputs, contexts, predictions, lock, judge_declaration):
    verify_lock(manifest, predictions, lock)
    judge_pin=validate_judge_declaration(judge_declaration)
    expected = validate_manifest(manifest)
    checked_ids(solver_inputs, expected, label='solver inputs')
    checked_ids(contexts, expected, label='judge contexts')
    packets, unavailable = [], []
    for metadata, solver, context, prediction in zip(manifest, solver_inputs, contexts, predictions):
        if set(solver) - set(SOLVER_FIELDS):
            raise ValueError('Scorer-only or unknown field found in solver inputs')
        if set(context) - set(JUDGE_CONTEXT_FIELDS) or not isinstance(context.get('gpt4_answer'), str) or not context['gpt4_answer'].strip():
            raise ValueError('Invalid judge-only context')
        if not delivered(prediction):
            unavailable.append({'question_id': metadata['question_id'], 'reason': 'No normally delivered nonempty candidate answer'})
            continue
        packets.append({'condition': CONDITION, 'question_id': metadata['question_id'],
            'question_type': metadata['question_type'], 'domain': metadata['domain'],
            'question': solver['text'],
            'figure_context': {k: copy.deepcopy(context.get(k)) for k in ('fig_label', 'fig_caption', 'in_text_mention')},
            'reference_answer': context['gpt4_answer'], 'candidate_answer': prediction['text'],
            'rubric': copy.deepcopy(RUBRIC), 'prediction_lock_sha256': digest(lock),
            'judge_declaration':copy.deepcopy(judge_declaration),
            'score_entry': {'question_id':metadata['question_id'],'reference_score': None,
                            'candidate_score': None, 'comment': '', 'judge_declaration_sha256':judge_pin}})
    return {'packets': packets, 'unavailable': unavailable, 'planned': len(manifest),
            'reviewable': len(packets), 'source_generation_failures_or_invalid_answers': len(unavailable)}

def score_value(value):
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        raise ValueError('Scores must be numeric, not boolean or strings')
    if not math.isfinite(value) or not 1 <= value <= 10:
        raise ValueError('Scores must be finite and within 1 through 10')
    return float(value)

def aggregate_judgements(manifest, predictions, lock, judgements, judge_declaration):
    verify_lock(manifest, predictions, lock)
    judge_pin=validate_judge_declaration(judge_declaration)
    expected = validate_manifest(manifest)
    checked_ids(judgements, expected, label='judge records', subset=True)
    predicted = {id_key(row['question_id']): row for row in predictions}
    received = {}
    for row in judgements:
        if set(row) - JUDGEMENT_FIELDS or 'question_id' not in row:
            raise ValueError('Unknown judge metadata field')
        if row.get('judge_declaration_sha256')!=judge_pin:
            raise ValueError('Score record has a missing/wrong judge identity pin')
        if not delivered(predicted[id_key(row['question_id'])]):
            raise ValueError('A missing/failed candidate cannot receive a paired answer score')
        received[id_key(row['question_id'])] = row
    outcomes = []
    for metadata, prediction in zip(manifest, predictions):
        entry = dict(metadata)
        key = id_key(metadata['question_id'])
        if not delivered(prediction):
            entry.update(state='generation_failure_or_invalid_answer', ratio=None)
        elif key not in received:
            entry.update(state='missing_judgement', ratio=None)
        else:
            try:
                row = received[key]
                reference = score_value(row.get('reference_score'))
                candidate = score_value(row.get('candidate_score'))
                if 'comment' in row and not isinstance(row['comment'], str):
                    raise ValueError('Comment must be text')
                entry.update(state='valid', ratio=candidate/reference)
            except ValueError as error:
                entry.update(state='invalid_judgement', ratio=None, reason=str(error))
        outcomes.append(entry)
    def summarize(rows):
        n = len(rows)
        valid = [row['ratio'] for row in rows if row['state'] == 'valid']
        counts = {state: sum(row['state'] == state for row in rows) for state in
                  ('valid', 'generation_failure_or_invalid_answer', 'missing_judgement', 'invalid_judgement')}
        return {'planned': n, **counts, 'complete': len(valid) == n,
                'released_mean_case_ratio_score': 100*sum(valid)/n if len(valid) == n else None,
                'failure_zero_full_denominator_adaptation_score': 100*sum(valid)/n,
                'failure_zero_policy': 'Every missing/invalid generation or judgement contributes zero; this is an explicitly different incomplete-case accounting adaptation.'}
    groups = {'overall': summarize(outcomes)}
    for name in QUESTION_TYPES + DOMAINS:
        selected = [row for row in outcomes if row['question_type'] == name or row['domain'] == name]
        if selected:
            groups[name] = summarize(selected)
    return {'condition': CONDITION, 'judge_declaration':copy.deepcopy(judge_declaration),
            'score_meaning': 'Relative judged answer quality; not clinical accuracy or exact original GPT-4-0314 reproduction',
            'lock_sha256': digest(lock), 'groups': groups, 'per_case_accounting': outcomes,
            'model_calls_by_this_adapter': 0}

def read_json(path):
    return json.loads(Path(path).read_text())

def read_rows(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]

def write_json(path, value):
    p=Path(path)
    with p.open('x') as f:json.dump(value,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
    p.chmod(0o600)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    split=sub.add_parser('split')
    split.add_argument('--source-questions',required=True);split.add_argument('--expected-count',type=int,required=True);split.add_argument('--output-directory',required=True)
    for name in ('seal','packets','score'):
        child=sub.add_parser(name);child.add_argument('--manifest',required=True);child.add_argument('--predictions',required=True)
        if name=='seal':child.add_argument('--output',required=True)
        else:
            child.add_argument('--lock',required=True);child.add_argument('--output',required=True)
            child.add_argument('--judge-declaration',required=True)
            if name=='packets':child.add_argument('--solver-inputs',required=True);child.add_argument('--judge-contexts',required=True)
            else:child.add_argument('--judgements',required=True)
    args=parser.parse_args()
    if args.command=='split':
        values=split_source_questions(read_rows(args.source_questions),expected_count=args.expected_count)
        out=Path(args.output_directory);out.mkdir(parents=True,exist_ok=False)
        for name,value in values.items():write_json(out/(name+'.json'),value)
    else:
        manifest=read_json(args.manifest);predictions=read_json(args.predictions)
        if args.command=='seal':value=seal_predictions(manifest,predictions)
        elif args.command=='packets':value=build_review_packets(manifest,read_json(args.solver_inputs),read_json(args.judge_contexts),predictions,read_json(args.lock),read_json(args.judge_declaration))
        else:value=aggregate_judgements(manifest,predictions,read_json(args.lock),read_json(args.judgements),read_json(args.judge_declaration))
        write_json(args.output,value)

if __name__=='__main__':main()
