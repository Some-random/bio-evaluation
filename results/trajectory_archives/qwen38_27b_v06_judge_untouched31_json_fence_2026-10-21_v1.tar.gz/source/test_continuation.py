from __future__ import annotations
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import continuation_runner as runner
import worker


class ContinuationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.scorer,self.render=runner.original.source_modules()
        self.configuration={'model':'Qwen/Qwen3.8-27B','revision':'artificial-fixture',
            'temperature':0,'top_p':1,'max_tokens':16384,'chat_template_kwargs':{'enable_thinking':False},
            'max_context_tokens':65536}
        self.declaration={'condition':self.scorer.CONDITION,'kind':'local_model',
            'identity':'Artificial recording fixture; no real model calls',
            'rubric_sha256':self.scorer.digest(self.scorer.RUBRIC),
            'model_configuration_sha256':self.scorer.digest(self.configuration)}
        self.manifest=[{'question_id':qid,'question_type':'conversation','domain':'histology'} for qid in range(193)]
        self.predictions=[{'question_id':qid,'status':'completed','text':'Invented neutral answer.'} for qid in range(193)]
        self.lock=self.scorer.seal_predictions(self.manifest,self.predictions)
        self.packets={qid:self.packet(qid) for qid in range(193)}
        self.basis={'manifest':self.manifest,'predictions':self.predictions,'prediction_lock':self.lock,
            'packets':self.packets,'reused_judgements':[self.judgement(qid) for qid in range(162)],
            'reused_outcomes':[{'question_id':qid,'status':'completed','text':json.dumps(self.judgement(qid)),
                'finish_reason':'stop','stop':False,'transport_call_returned':True,'response_saved':True,
                'final_field_observed':True,'observed_empty_final':False,'reused_saved_response':True,
                'source_strict_status':'response_error' if qid==161 else 'completed'} for qid in range(162)],
            'provenance':[{'question_id':qid,'artificial':True} for qid in range(162)]}
        records=[]
        for qid in range(162,193):
            path=self.root/'envelopes'/f'{qid}.json'
            runner.save(path,self.render.judge_envelope(self.packets[qid],self.configuration))
            records.append({'question_id':qid,'path':str(path),'sha256':runner.sha(path)})
        runner.save(self.root/'manifest.json',{'envelopes':records})
        runner.save(self.root/'neutral.json',{'cases':[{'question_id':qid,'judge_packet':self.packet(qid)} for qid in [-2,-1]]})
        self.plan={'execution_scope':'artificial_fixture','condition':'ARTIFICIAL_CONTINUATION_TEST_ONLY',
            'model_configuration':self.configuration,'judge_declaration':self.declaration,
            'judge_envelope_manifest':str(self.root/'manifest.json'),'neutral_gate_inputs':str(self.root/'neutral.json')}

    def packet(self,qid):
        return {'question_id':qid,'condition':self.scorer.CONDITION,'judge_declaration':self.declaration,
            'question':'Invented neutral arithmetic item.','figure_context':{'fig_caption':'Artificial fixture.'},
            'reference_answer':'Invented neutral answer.','candidate_answer':'Invented neutral answer.'}

    def judgement(self,qid):
        return {'question_id':qid,'reference_score':6,'candidate_score':4,'comment':'Artificial assessment only.',
            'judge_declaration_sha256':self.scorer.validate_judge_declaration(self.declaration)}

    def response(self,qid,*,text=None,finish='stop'):
        return {'choices':[{'message':{'content':json.dumps(self.judgement(qid)) if text is None else text},
                            'finish_reason':finish}]}

    def run_case(self,callback=None,context_check=lambda payload:None):
        transport=runner.RecordingTransport(callback or (lambda phase,qid,payload:self.response(qid)))
        result=runner.run_protocol(self.plan,self.root/'output',transport,context_check,artificial_basis=self.basis)
        return result,transport

    def test_full193closure_only31_new_judges_two_neutral(self):
        def callback(phase,qid,payload):
            text=json.dumps(self.judgement(qid))
            return self.response(qid,text='```json\n'+text+'\n```' if qid%2 else text)
        result,transport=self.run_case(callback)
        self.assertTrue(result['benchmark_primary_defined'])
        self.assertAlmostEqual(result['released_mean_case_ratio_score'],100*4/6)
        self.assertEqual([qid for phase,qid,_ in transport.calls if phase=='benchmark_judge_untouched_continuation'],list(range(162,193)))
        self.assertEqual(len(transport.calls),33)
        self.assertEqual(result['new_solver_calls'],0)
        self.assertEqual(result['judge']['responses_saved'],193)
        self.assertEqual(len(runner.read(self.root/'output/judgements.json')),193)
        self.assertTrue(result['source_strict_primary_undefined_preserved'])

    def test_malformed_score_stops_retains_transport_and_native_outcomes(self):
        result,transport=self.run_case(lambda phase,qid,payload:self.response(qid,text='prose '+json.dumps(self.judgement(qid))) if qid==170 else self.response(qid))
        self.assertFalse(result['benchmark_primary_defined'])
        self.assertEqual(result['new_judge']['attempted_with_observed_outcome'],9)
        self.assertEqual(result['new_judge']['response_errors'],1)
        self.assertEqual(result['new_judge']['not_dispatched_after_stop'],22)
        folder=self.root/'output/judge/170'
        self.assertEqual(runner.read(folder/'outcome.json')['status'],'completed')
        self.assertEqual(runner.read(folder/'parsed_outcome.json')['status'],'response_error')
        self.assertEqual(len(runner.read(self.root/'output/judge_outcomes.json')),193)

    def test_transport_failure_is_not_empty_final_no_retry(self):
        def callback(phase,qid,payload):
            return runner.TransportFailure('Artificial transport interruption') if qid==170 else self.response(qid)
        result,transport=self.run_case(callback)
        self.assertEqual(result['new_judge']['transport_errors'],1)
        self.assertEqual(result['new_judge']['empty_finals'],0)
        self.assertEqual(result['new_judge']['not_dispatched_after_stop'],22)
        self.assertEqual(sum(qid==170 for _,qid,_ in transport.calls),1)

    def test_observed_empty_final_separate_and_stops(self):
        result,_=self.run_case(lambda phase,qid,payload:self.response(qid,text='') if qid==162 else self.response(qid))
        self.assertEqual(result['new_judge']['empty_finals'],1)
        self.assertEqual(result['new_judge']['response_errors'],1)
        self.assertEqual(result['new_judge']['not_dispatched_after_stop'],30)

    def test_truncation_retained_invalid_untouched_cases_continue(self):
        result,transport=self.run_case(lambda phase,qid,payload:self.response(qid,text='{',finish='length') if qid==162 else self.response(qid))
        self.assertFalse(result['benchmark_primary_defined'])
        self.assertEqual(result['new_judge']['truncations'],1)
        self.assertEqual(result['new_judge']['attempted_with_observed_outcome'],31)
        self.assertEqual(result['new_judge']['not_dispatched_after_stop'],0)
        self.assertEqual(sum(qid==162 for _,qid,_ in transport.calls),1)

    def test_wrong_question_identity_stops(self):
        result,_=self.run_case(lambda phase,qid,payload:self.response(qid,text=json.dumps(self.judgement(161))) if qid==162 else self.response(qid))
        self.assertEqual(result['new_judge']['response_errors'],1)
        self.assertEqual(result['new_judge']['not_dispatched_after_stop'],30)

    def test_duplicate_key_remains_error_even_fenced(self):
        def callback(phase,qid,payload):
            if qid==162:return self.response(qid,text='```json\n'+json.dumps(self.judgement(qid))[:-1]+',"candidate_score":9}\n```')
            return self.response(qid)
        result,_=self.run_case(callback)
        self.assertEqual(result['new_judge']['response_errors'],1)
        self.assertFalse(result['benchmark_primary_defined'])

    def test_malformed_wrapper_stops_with_full193_accounting(self):
        def callback(phase,qid,payload):
            text='```json\n'+json.dumps(self.judgement(qid))+'\n``` trailing prose'
            return self.response(qid,text=text) if qid==162 else self.response(qid)
        result,transport=self.run_case(callback)
        self.assertEqual(result['new_judge']['response_errors'],1)
        self.assertEqual(result['new_judge']['not_dispatched_after_stop'],30)
        self.assertEqual(sum(qid==162 for _,qid,_ in transport.calls),1)
        folder=self.root/'output/judge/162'
        self.assertEqual(runner.read(folder/'outcome.json')['status'],'completed')
        self.assertEqual(runner.read(folder/'parsed_outcome.json')['status'],'response_error')
        self.assertEqual(len(runner.read(self.root/'output/judge_outcomes.json')),193)
        self.assertTrue(runner.read(self.root/'output/judge_lock.json')['closed'])
        self.assertIsNone(result['released_mean_case_ratio_score'])

    def test_normalizer_exception_is_preserved_native_error_not_uncaught(self):
        normalizer=runner.normalize_outer_json_fence
        def injected(text):
            if 'INVENTED_BAD_WRAPPER' in text:raise ValueError('Artificial normalization failure')
            return normalizer(text)
        callback=lambda phase,qid,payload:self.response(qid,text='INVENTED_BAD_WRAPPER') if qid==162 else self.response(qid)
        with patch.object(runner,'normalize_outer_json_fence',injected):
            result,transport=self.run_case(callback)
        self.assertEqual(result['new_judge']['response_errors'],1)
        self.assertEqual(result['new_judge']['not_dispatched_after_stop'],30)
        self.assertEqual(len(runner.read(self.root/'output/judge_outcomes.json')),193)
        self.assertEqual(runner.read(self.root/'output/judge/162/parsed_outcome.json')['error_type'],'ValueError')
        self.assertEqual(sum(qid==162 for _,qid,_ in transport.calls),1)

    def test_neutral_gate_failure_prevents_benchmark_dispatch(self):
        result,transport=self.run_case(lambda phase,qid,payload:self.response(qid,text='not JSON'))
        self.assertEqual(result['stage'],'development_failed_no_untouched_benchmark_dispatch')
        self.assertEqual(result['new_benchmark_calls_observed'],0)
        self.assertEqual(len(transport.calls),1)

    def test_context_failure_prevents_transport(self):
        def fail(payload):raise ValueError('Artificial full prompt context failure')
        result,transport=self.run_case(context_check=fail)
        self.assertEqual(result['new_benchmark_calls_observed'],0)
        self.assertEqual(transport.calls,[])

    def test_existing_output_forbids_second_attempt(self):
        result,transport=self.run_case()
        with self.assertRaises(FileExistsError):
            runner.run_protocol(self.plan,self.root/'output',transport,artificial_basis=self.basis)
        self.assertEqual(len(transport.calls),33)

    def test_real_scope_cannot_inject_artificial_basis(self):
        plan={**self.plan,'execution_scope':'retained_V06_judge_untouched31_full193closure'}
        transport=runner.RecordingTransport(lambda *args:self.response(args[1]))
        with self.assertRaisesRegex(ValueError,'cannot inject'):
            runner.run_protocol(plan,self.root/'output',transport,artificial_basis=self.basis)
        self.assertEqual(transport.calls,[])

    def test_envelope_hash_mismatch_no_benchmark_call(self):
        manifest=runner.read(self.root/'manifest.json')
        Path(manifest['envelopes'][0]['path']).write_text('{}')
        transport=runner.RecordingTransport(lambda phase,qid,payload:self.response(qid))
        with self.assertRaisesRegex(ValueError,'envelope changed'):
            runner.run_protocol(self.plan,self.root/'output',transport,artificial_basis=self.basis)
        self.assertEqual([phase for phase,_,_ in transport.calls],['development_judge','development_judge'])

    def test_real_Slurm_GPU_strings_and_eight_limit(self):
        audit=worker.parse_owned_gpu_requests('1|RUNNING|1|gres/gpu:a100:1\n2|PENDING|1|gres/gpu:4')
        self.assertEqual(audit['total_requested_gpus'],5)
        with self.assertRaises(ValueError):worker.parse_owned_gpu_requests('1|RUNNING|1|gres/gpu:a100:9')
        with self.assertRaises(ValueError):worker.parse_owned_gpu_requests('1_[1-3]|PENDING|1|gres/gpu:a100:1')

    def test_exact_admission_scope_required(self):
        path=self.root/'admission.json'
        runner.save(path,{'admitted':True,'task_id':'V06','plan_sha256':'a'*64,'gpu_count':1,
            'project_gpu_ceiling':8,'scope':'solver_and_declared_local_judge_all193_once'})
        with self.assertRaisesRegex(ValueError,'separate exact root admission'):
            worker.validate_admission(path,runner.sha(path),'a'*64)


if __name__=='__main__': unittest.main(verbosity=2)
