"""CPU-only exact-envelope context sizing for the31 untouched judge cases."""
from __future__ import annotations
import copy
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
MODEL = Path('/dfs/scratch0/tchen/models/Qwen3.8-27B')


def read(path): return json.loads(Path(path).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    os.umask(0o077)
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '':
        raise ValueError('Explicit CPU-only environment required')
    target = HERE / 'cpu_context_validation.json'
    if target.exists(): raise FileExistsError('CPU context receipt already sealed')
    plan = read(HERE / 'plan_proposed.json')
    manifest = read(HERE / 'judge_envelopes_manifest.json')
    if sha(HERE / 'judge_envelopes_manifest.json') != plan['envelope_manifest_sha256']:
        raise ValueError('Proposed payload manifest changed')
    basis_path = TASK / 'real_input_preparation_v1/cpu_processor_check/completion.json'
    basis = read(basis_path)
    for name, pin in basis['processor_files_sha256'].items():
        if sha(MODEL / name) != pin: raise ValueError('Original CPU processor assets changed')
    import torch
    import transformers
    from transformers import AutoProcessor
    if (torch.__version__ != basis['torch_version'] or transformers.__version__ != basis['transformers_version']
            or torch.version.cuda is not None):
        raise ValueError('Use the original CPU-only processor package versions')
    processor = AutoProcessor.from_pretrained(MODEL, local_files_only=True)
    observations = []
    for record in manifest['envelopes']:
        if sha(record['path']) != record['sha256']: raise ValueError('Untouched judge envelope changed')
        payload = read(record['path'])
        if payload['max_tokens'] != 16384 or payload['chat_template_kwargs'] != {'enable_thinking': False}:
            raise ValueError('Uniform16K/nonthinking settings changed')
        encoded = processor.apply_chat_template(copy.deepcopy(payload['messages']), tokenize=True,
            return_dict=True, return_tensors='pt', add_generation_prompt=True, **payload['chat_template_kwargs'])
        count = int(encoded['input_ids'].shape[-1])
        if encoded.get('image_grid_thw') is not None: raise ValueError('Judging is exact text-only')
        observations.append({'question_id': record['question_id'], 'request_sha256': record['sha256'],
            'actual_input_tokens': count, 'output_reserve': 16384, 'context_limit': 65536,
            'context_fit': count + 16384 <= 65536, 'model_forward': False})
        del encoded
    if [row['question_id'] for row in observations] != list(range(162,193)):
        raise ValueError('Exact untouched31 coverage differs')
    result = {'at_pacific': datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        'role': 'exact_untouched31_CPU_context_preflight_not_dispatch',
        'plan_sha256': sha(HERE / 'plan_proposed.json'), 'cases_checked': len(observations),
        'all_contexts_fit': all(row['context_fit'] for row in observations),
        'maximum_actual_input_tokens': max(row['actual_input_tokens'] for row in observations),
        'processor_path': str(MODEL), 'processor_basis_sha256': sha(basis_path),
        'processor_files_sha256': basis['processor_files_sha256'],
        'torch_version': torch.__version__, 'transformers_version': transformers.__version__,
        'checker_sha256': sha(Path(__file__)), 'cases': observations,
        'new_model_calls': 0, 'model_forwards': 0, 'GPU_allocations': 0, 'runtime_admission_granted': False}
    with target.open('x') as stream: json.dump(result,stream,indent=2); stream.write('\n')
    target.chmod(0o600)
    print(json.dumps({key: result[key] for key in ['cases_checked','all_contexts_fit',
        'maximum_actual_input_tokens','new_model_calls','model_forwards','GPU_allocations']}))


if __name__ == '__main__': main()
