"""One-attempt judging of only31 untouched V06 cases; preserve strict predecessor."""
from __future__ import annotations
import copy
import importlib.util
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
sys.path.insert(0, str(TASK / 'offline_json_fence_audit_v1'))
from json_fence import normalize_outer_json_fence, POLICY
spec = importlib.util.spec_from_file_location('V06_preserved_original_runner', TASK / 'local_execution_v2/v06_runner.py')
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
TransportFailure = original.TransportFailure
RecordingTransport = original.RecordingTransport
current, read, save, sha, stamp = original.current, original.read, original.save, original.sha, original.stamp


def load_basis(plan):
    for source, expected in plan['frozen_files_sha256'].items():
        if sha(source) != expected: raise ValueError('Frozen continuation/source evidence changed')
    scorer, render = original.source_modules()
    source = Path(plan['source_output_root'])
    manifest = read(plan['manifest'])
    predictions = read(source / 'predictions.json')
    lock = read(source / 'prediction_lock.json')
    scorer.verify_lock(manifest, predictions, lock)
    judge_lock = read(source / 'judge_lock.json')
    for file, field in [('judge_outcomes.json', 'outcomes_sha256'), ('judgements.json', 'judgements_sha256'),
                        ('prediction_lock.json', 'prediction_lock_sha256')]:
        if sha(source / file) != judge_lock[field]: raise ValueError('Predecessor judge lock changed')
    old = read(source / 'judge_outcomes.json')
    if [row['question_id'] for row in old] != list(range(193)):
        raise ValueError('Full predecessor denominator changed')
    if [row['question_id'] for row in old if row['status'] == 'not_dispatched_after_stop'] != list(range(162,193)):
        raise ValueError('Only verified untouched31 are eligible')
    for qid in range(162,193):
        folder = source / 'judge' / f'{qid:03d}'
        if any((folder / name).exists() for name in ['request.json','transport_intent.json','response.body','outcome.json','parsed_outcome.json']):
            raise ValueError('Untouched case gained predecessor dispatch evidence')
    strict = read(source / 'judgements.json')
    if scorer.aggregate_judgements(manifest,predictions,lock,strict,plan['judge_declaration']) != read(source / 'scores.json'):
        raise ValueError('Strict predecessor scores changed')
    packets = {row['question_id']: row for row in read(source / 'review_packets.json')['packets']}
    reused, outcomes, provenance = [], [], []
    for row in old[:162]:
        qid = row['question_id']
        raw_path = source / 'judge' / f'{qid:03d}' / 'response.body'
        if sha(raw_path) != row['raw_response_sha256']: raise ValueError('Saved raw judge response changed')
        response = read(raw_path)
        if len(response['choices']) != 1 or response['choices'][0]['finish_reason'] != 'stop':
            raise ValueError('A failed/truncated predecessor reply cannot be recovered')
        text = response['choices'][0]['message']['content']
        normalized, repair = normalize_outer_json_fence(text)
        judgement = render.parse_judge_output(normalized, packets[qid])
        reused.append(judgement)
        outcomes.append({**row, 'status':'completed', 'stop':False, 'source_strict_status':row['status'],
                         'reused_saved_response':True, 'normalization':repair})
        provenance.append({'question_id':qid,'raw_response_path':str(raw_path),'raw_response_sha256':sha(raw_path),
                           'source_strict_status':row['status'],'normalization':repair,
                           'validated_judgement_sha256':scorer.digest(judgement)})
    if reused != read(plan['normalized_saved_judgements_path']):
        raise ValueError('All162 revalidated judgements differ from the sealed offline extraction')
    return {'manifest':manifest,'predictions':predictions,'prediction_lock':lock,'packets':packets,
            'reused_judgements':reused,'reused_outcomes':outcomes,'provenance':provenance}


def validated_judge_call(folder,phase,index,qid,payload,packet,transport,context_check):
    _, render = original.source_modules()
    outcome = original.call_once(folder,phase,index,qid,payload,transport,context_check)
    judgement = None
    normalization = {'operation':'not_applicable_to_failed_transport_or_delivery','removed_outer_fence':False}
    if outcome['status'] == 'completed':
        try:
            normalized, normalization = normalize_outer_json_fence(outcome['text'])
            judgement = render.parse_judge_output(normalized,packet)
        except (ValueError,TypeError) as error:
            outcome.update(status='response_error',stop=True,error_type=type(error).__name__,error=str(error))
    outcome['normalization'] = normalization
    # Transport completion and native validation remain separately immutable.
    save(folder/f'{index:03d}'/'parsed_outcome.json',outcome)
    return outcome, judgement


def judge_delivery_gate(plan,folder,transport,context_check):
    scorer,render = original.source_modules()
    cases = read(plan['neutral_gate_inputs'])['cases']
    if len(cases) != 2: raise ValueError('Exactly two neutral one-attempt judge delivery gates required')
    rows=[]
    for index,case in enumerate(cases):
        packet={**case['judge_packet'],'condition':scorer.CONDITION,'judge_declaration':plan['judge_declaration']}
        payload=render.judge_envelope(packet,plan['model_configuration'])
        outcome,judgement=validated_judge_call(folder/'development_judge','development_judge',index,
            case['question_id'],payload,packet,transport,context_check)
        rows.append(outcome)
        if outcome['status']!='completed' or judgement is None:
            save(folder/'development_judge_completion.json',{'at_pacific':stamp(),'all_passed':False,
                'outcomes':rows,'delivery_only_not_benchmark_score':True})
            raise RuntimeError('Neutral judge gate failed; no untouched benchmark dispatch')
    save(folder/'development_judge_completion.json',{'at_pacific':stamp(),'all_passed':True,
        'planned':2,'terminal':2,'outcomes':rows,'delivery_only_not_benchmark_score':True})


def run_protocol(plan,folder,transport,context_check=lambda payload:None,*,artificial_basis=None):
    if plan['execution_scope']=='artificial_fixture' and type(transport) is not RecordingTransport:
        raise ValueError('Artificial fixtures may use only RecordingTransport')
    if artificial_basis is not None and (plan['execution_scope']!='artificial_fixture' or type(transport) is not RecordingTransport):
        raise ValueError('A real run cannot inject a synthetic basis')
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False)
    basis=artificial_basis if artificial_basis is not None else load_basis(plan)
    scorer,render=original.source_modules()
    manifest,predictions,lock=basis['manifest'],basis['predictions'],basis['prediction_lock']
    scorer.verify_lock(manifest,predictions,lock)
    if scorer.validate_manifest(manifest)!=list(range(193)) or len(basis['reused_judgements'])!=162:
        raise ValueError('Full193 source and reused162 denominator required')
    envelopes=read(plan['judge_envelope_manifest'])['envelopes']
    if [row['question_id'] for row in envelopes]!=list(range(162,193)):
        raise ValueError('Exactly original untouched IDs162–192 required')
    save(folder/'run_manifest.json',{'at_pacific':stamp(),'configuration':plan,
        'plan_canonical_sha256':scorer.digest(plan),'source_solver_and_strict_outputs_unchanged':True,
        'source_judge_responses_reused':162,'new_benchmark_judge_calls_planned':31,
        'new_solver_calls_planned':0,'selective_retry':False,'parser_repair':POLICY})
    save(folder/'reused_judge_provenance.json',basis['provenance'])
    save(folder/'source_prediction_lock.json',lock)
    current(folder/'progress.json',{'at_pacific':stamp(),'stage':'neutral_judge_delivery_gates',
        'reused_judge_responses':162,'new_judge_planned':31,'new_benchmark_calls_observed':0})
    try: judge_delivery_gate(plan,folder,transport,context_check)
    except Exception as error:
        result={'at_pacific':stamp(),'stage':'development_failed_no_untouched_benchmark_dispatch',
            'error_type':type(error).__name__,'error':str(error),'new_benchmark_calls_observed':0,
            'new_judge_planned':31,'source_strict_primary_undefined_preserved':True}
        save(folder/'completion.json',result);return result
    judgements=copy.deepcopy(basis['reused_judgements'])
    all_outcomes=copy.deepcopy(basis['reused_outcomes']);new_outcomes=[];stopped=False
    for record in envelopes:
        qid=record['question_id']
        if stopped:
            outcome={'question_id':qid,'status':'not_dispatched_after_stop'}
        else:
            payload=read(record['path'])
            if sha(record['path'])!=record['sha256'] or payload['max_tokens']!=16384:
                raise ValueError('Frozen untouched envelope changed')
            if payload!=render.judge_envelope(basis['packets'][qid],plan['model_configuration']):
                raise ValueError('Untouched judge prompt differs from predecessor source/configuration')
            outcome,judgement=validated_judge_call(folder/'judge','benchmark_judge_untouched_continuation',
                qid,qid,payload,basis['packets'][qid],transport,context_check)
            if judgement is not None:judgements.append(judgement)
            stopped=outcome['stop']
        new_outcomes.append(outcome);all_outcomes.append(outcome)
        current(folder/'progress.json',{'at_pacific':stamp(),
            'stage':'judge_stopped_for_review' if stopped else 'untouched_judge_generation',
            'new_judge':original.summary(new_outcomes,31),'judge':original.summary(all_outcomes,193),
            'reused_judge_responses':162,'new_solver_calls':0,'native_scoring_status':'waiting_for_complete_judge_closure'})
    if [row['question_id'] for row in all_outcomes]!=list(range(193)):
        raise ValueError('Closure lost full193 outcome order')
    save(folder/'new_judge_outcomes.json',new_outcomes)
    save(folder/'judge_outcomes.json',all_outcomes)
    save(folder/'judgements.json',judgements)
    save(folder/'judge_lock.json',{'closed':True,'planned':193,'reused_raw_responses':162,
        'outcomes_sha256':sha(folder/'judge_outcomes.json'),'judgements_sha256':sha(folder/'judgements.json'),
        'source_prediction_lock_sha256':sha(folder/'source_prediction_lock.json'),
        'judge_declaration_sha256':scorer.validate_judge_declaration(plan['judge_declaration']),
        'execution_condition':plan['condition'],'parser_repair':POLICY})
    scores=scorer.aggregate_judgements(manifest,predictions,lock,judgements,plan['judge_declaration'])
    scores.update(execution_condition=plan['condition'],parser_repair=POLICY,
                  source_strict_primary_undefined_preserved=True)
    save(folder/'scores.json',scores)
    complete=scores['groups']['overall']['complete']
    result={'at_pacific':stamp(),'stage':'scored_terminal' if complete else 'terminal_incomplete_primary_undefined',
        'execution_condition':plan['condition'],'source_solver_responses_reused':193,
        'source_judge_responses_reused':162,'new_solver_calls':0,
        'new_judge':original.summary(new_outcomes,31),'judge':original.summary(all_outcomes,193),
        'benchmark_primary_defined':complete,
        'released_mean_case_ratio_score':scores['groups']['overall']['released_mean_case_ratio_score'],
        'source_strict_primary_undefined_preserved':True,'source_strict_outputs_modified':False,
        'parser_repair':POLICY,'original_GPT4_judge_reproduced':False,'clinical_accuracy_claim':False,
        'full_catalog_complete':False}
    save(folder/'completion.json',result);current(folder/'progress.json',result)
    if artificial_basis is None:load_basis(plan)  # Exact predecessor hashes must still match at closure.
    return result
