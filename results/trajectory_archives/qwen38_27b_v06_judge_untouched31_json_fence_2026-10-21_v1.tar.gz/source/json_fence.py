"""Conservative outer-fence normalization; never extract or repair JSON fields."""
from __future__ import annotations

import re

CONDITION = 'V06_ALL_SAVED_JUDGE_REPLIES_LOSSLESS_OUTER_JSON_FENCE_DIAGNOSTIC_V1'
POLICY = {
    'unchanged_strict_primary': True,
    'accepted_wrapper': 'One complete outer Markdown fence, optional json label, no surrounding prose or inner fences.',
    'normalization': 'Remove outer fence delimiters only; retain every interior character exactly.',
    'field_identity_score_validation': 'Use the original frozen parse_judge_output without modification.',
    'fragment_extraction_or_value_repair': False,
    'new_model_calls': 0,
}


def normalize_outer_json_fence(text):
    if not isinstance(text, str):
        raise TypeError('Saved final text must be a string')
    match = re.fullmatch(r'[ \t\r\n]*```(?:json)?[ \t]*\r?\n(?P<body>[\s\S]*?)\r?\n```[ \t\r\n]*', text, re.IGNORECASE)
    if match is None or '```' in match['body']:
        return text, {'operation': 'identity', 'removed_outer_fence': False}
    return match['body'], {
        'operation': 'remove_single_complete_outer_json_fence', 'removed_outer_fence': True,
        'prefix_characters_removed': match.start('body'),
        'suffix_characters_removed': len(text) - match.end('body'),
        'interior_characters_unchanged': True,
    }
