from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'real_input_preparation_v1'))
from json_fence import normalize_outer_json_fence
spec = importlib.util.spec_from_file_location('fence_test_render', HERE.parent / 'real_input_preparation_v1/render_envelopes.py')
render = importlib.util.module_from_spec(spec)
spec.loader.exec_module(render)
adapter = render.load_adapter()


class FenceTests(unittest.TestCase):
    def setUp(self):
        self.declaration = {'condition': adapter.CONDITION, 'kind': 'human', 'identity': 'artificial rubric fixture',
                            'rubric_sha256': adapter.digest(adapter.RUBRIC)}
        self.packet = {'question_id': 7, 'judge_declaration': self.declaration}
        self.record = {'question_id': 7, 'reference_score': 6, 'candidate_score': 4,
                       'comment': 'Artificial assessment only.',
                       'judge_declaration_sha256': adapter.validate_judge_declaration(self.declaration)}
        self.body = json.dumps(self.record)

    def parse(self, text):
        normalized, metadata = normalize_outer_json_fence(text)
        return render.parse_judge_output(normalized, self.packet), metadata

    def test_plain_json_byte_identical(self):
        value, metadata = normalize_outer_json_fence(self.body)
        self.assertEqual(value, self.body)
        self.assertFalse(metadata['removed_outer_fence'])

    def test_single_json_fence_preserves_interior(self):
        text = '```json\n' + self.body + '\n```'
        normalized, metadata = normalize_outer_json_fence(text)
        self.assertEqual(normalized, self.body)
        self.assertTrue(metadata['interior_characters_unchanged'])
        self.assertEqual(self.parse(text)[0], self.record)
        with self.assertRaises(json.JSONDecodeError):
            render.parse_judge_output(text, self.packet)

    def test_unlabelled_CRLF_wrapper(self):
        self.assertEqual(self.parse(' \r\n```\r\n' + self.body + '\r\n```\r\n')[0], self.record)

    def test_prose_or_fragment_never_extracted(self):
        for text in ['Here is JSON:\n```json\n' + self.body + '\n```',
                     '```json\n' + self.body + '\n```\nTrailing text',
                     '```python\n' + self.body + '\n```',
                     '```json\n' + self.body + '\n```\n```json\n{}\n```']:
            with self.subTest(text=text):
                self.assertEqual(normalize_outer_json_fence(text)[0], text)
                with self.assertRaises(ValueError): self.parse(text)

    def test_inner_fence_never_removed(self):
        record = {**self.record, 'comment': 'Artificial ``` embedded delimiter'}
        text = '```json\n' + json.dumps(record) + '\n```'
        self.assertEqual(normalize_outer_json_fence(text)[0], text)

    def test_duplicate_key_still_rejected(self):
        body = self.body[:-1] + ', "candidate_score": 9}'
        with self.assertRaisesRegex(ValueError, 'Duplicate'): self.parse('```json\n' + body + '\n```')

    def test_wrong_ID_and_pin_still_rejected(self):
        for record in [{**self.record, 'question_id': 8}, {**self.record, 'judge_declaration_sha256': '0' * 64}]:
            with self.subTest(record=record):
                with self.assertRaisesRegex(ValueError, 'identity'): self.parse('```json\n' + json.dumps(record) + '\n```')

    def test_boolean_nonfinite_out_of_range_still_rejected(self):
        for value in [True, float('nan'), float('inf'), 0, 11, '4']:
            with self.subTest(value=value):
                text = '```json\n' + json.dumps({**self.record, 'candidate_score': value}) + '\n```'
                with self.assertRaises(ValueError): self.parse(text)

    def test_missing_extra_fields_or_empty_comment_rejected(self):
        missing = {k: v for k, v in self.record.items() if k != 'candidate_score'}
        for record in [missing, {**self.record, 'extra': 1}, {**self.record, 'comment': ''}]:
            with self.subTest(record=record):
                with self.assertRaises(ValueError): self.parse('```json\n' + json.dumps(record) + '\n```')

    def test_malformed_JSON_is_not_repaired(self):
        with self.assertRaises(json.JSONDecodeError): self.parse('```json\n{"question_id": 7,}\n```')


if __name__ == '__main__': unittest.main(verbosity=2)
