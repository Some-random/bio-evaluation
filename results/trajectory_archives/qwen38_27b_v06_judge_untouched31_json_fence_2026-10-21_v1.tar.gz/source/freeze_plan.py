"""Freeze runnable judge-only continuation; grant neither admission nor dispatch."""
from __future__ import annotations
import copy
from pathlib import Path
import sys
from continuation_runner import read,save,sha,stamp,load_basis

HERE=Path(__file__).resolve().parent
TASK=HERE.parent
AUDIT=TASK/'offline_json_fence_audit_v1'
sys.path.insert(0,str(AUDIT))
from json_fence import POLICY


def main():
    proposal=read(HERE/'plan_proposed.json')
    cpu=read(HERE/'cpu_context_validation.json')
    if cpu['plan_sha256']!=sha(HERE/'plan_proposed.json') or cpu['cases_checked']!=31 or cpu['all_contexts_fit'] is not True:
        raise ValueError('Exact31 CPU preflight required')
    tests=read(HERE/'cpu_validation.json')
    if tests['tests_passed']!=16 or tests['exit_code']!=0 or tests['real_model_calls']!=0:
        raise ValueError('Artificial recording-client guards must pass')
    source_plan=Path(proposal['source_plan_path'])
    if sha(source_plan)!=proposal['source_plan_sha256']:raise ValueError('Predecessor plan changed')
    old=read(source_plan)
    source=Path(old['output_root'])
    if read(source.parent/'server_terminal.json')['own_server_stopped'] is not True:
        raise ValueError('Predecessor server terminal evidence required')
    verification=read(AUDIT/'artifacts/strict_condition_verification.json')
    manifest=read(HERE/'judge_envelopes_manifest.json')
    if [r['question_id'] for r in manifest['envelopes']]!=list(range(162,193)):
        raise ValueError('Only exact untouched31 may be prepared')
    plan=copy.deepcopy(old)
    plan.update(created_at_pacific=stamp(),
        condition='V06_QWEN38_27B_UNIFORM16K_LOSSLESS_JSON_FENCE_UNTOUCHED31_CLOSURE_V1',
        execution_scope='retained_V06_judge_untouched31_full193closure',
        run_id='qwen38_27b_v06_judge_untouched31_json_fence_2026-10-21_v1',
        planned=193,new_judge_planned=31,new_solver_calls_planned=0,
        source_output_root=str(source),output_root=str(HERE/'runtime/run_v1'),
        source_plan_path=str(source_plan),source_plan_sha256=sha(source_plan),
        judge_envelope_manifest=str(HERE/'judge_envelopes_manifest.json'),
        normalized_saved_judgements_path=proposal['normalized_saved_judgements_path'],
        source_solver_responses_reused=193,source_judge_responses_reused=162,
        source_strict_primary_undefined_preserved=True,source_strict_outputs_modified=False,
        parser_repair=POLICY,source_solver_envelope_manifest=old['solver_envelope_manifest'],
        uniform16K_context_preflight_path=str(HERE/'cpu_context_validation.json'),
        closure_proof_path=str(HERE/'closure_proof.json'),
        runtime_admission_granted=False,submission_by_preparation=False,
        infrastructure_version='independent_judge_only_continuation_v1')
    plan.pop('solver_envelope_manifest',None)
    plan.pop('predecessor_zero_model_attempt_boundary',None)
    plan['phase_policy']={**old['phase_policy'],'neutral_solver_calls':0,'neutral_judge_calls':2,
        'solver_attempts_per_case':0,'judge_attempts_per_delivered_case':0,
        'judge_attempts_per_untouched_case':1,'new_benchmark_calls_planned':31,
        'maximum_new_model_calls_including_two_neutral_checks':33,
        'judge_stop_policy':'Preserve all193 outcome records; any missing/invalid judgement leaves new primary undefined.',
        'normalization':'General single complete outer JSON fence only, applied uniformly to all193 saved judge replies; original validators and ratio formula unchanged.'}
    plan['differences']=old['differences']+[
        'Original strict terminal run is preserved, including its parser error and undefined primary.',
        'All193 solver answers and162 saved judge replies are reused; only verified never-dispatched judge IDs162–192 receive one new attempt.',
        'A separately declared lossless single outer JSON fence extraction precedes unchanged original identity/hash/numeric validation on all193 judge replies.']
    pins=dict(old['frozen_files_sha256'])
    pins.update(verification['source_artifact_sha256'])
    for path in [source_plan,source.parent/'terminal_receipt.json',source.parent/'server_terminal.json',
        AUDIT/'completion.json',AUDIT/'json_fence.py',AUDIT/'test_json_fence.py',AUDIT/'audit_saved_replies.py',
        AUDIT/'artifacts/normalized_judgements.json',AUDIT/'artifacts/all_saved_reply_provenance.json',
        AUDIT/'artifacts/strict_condition_verification.json',HERE/'plan_proposed.json',HERE/'closure_proof.json',
        HERE/'judge_envelopes_manifest.json',HERE/'cpu_context_validation.json',HERE/'validate_contexts_cpu.py',
        HERE/'continuation_runner.py',HERE/'worker.py',HERE/'worker.sbatch',HERE/'test_continuation.py',
        HERE/'cpu_validation.json',HERE/'freeze_plan.py']:
        pins[str(path)]=sha(path)
    for row in manifest['envelopes']:pins[row['path']]=row['sha256']
    for source,pin in pins.items():
        if sha(source)!=pin:raise ValueError('Source/input/code pin changed before freeze')
    plan['frozen_files_sha256']=pins
    # Revalidate full193 source locks, saved162 normalization and untouched31 boundary now.
    basis=load_basis(plan)
    if len(basis['reused_judgements'])!=162:raise ValueError('Exact reused162 required')
    save(HERE/'plan.json',plan)
    plan_sha=sha(HERE/'plan.json')
    with (HERE/'plan.sha256').open('x') as stream:stream.write(plan_sha+'\n')
    save(HERE/'admission_NOT_GRANTED_template.json',{'admitted':False,'task_id':'V06','plan_sha256':plan_sha,
        'gpu_count':1,'project_gpu_ceiling':8,'scope':'judge_untouched31_once_reuse_locked193solver_and162judge',
        'gpu_audit_receipt':'ROOT_MUST_SUPPLY_FRESH_CONSERVATIVE_GPU_AUDIT',
        'gpu_audit_receipt_sha256':'ROOT_MUST_SUPPLY_REAL_HASH'})
    receipt={'at_pacific':stamp(),'stage':'runnable_frozen_pending_separate_root_admission',
        'plan_sha256':plan_sha,'frozen_files_checked':len(pins),'full_denominator':193,
        'solver_responses_reused':193,'judge_responses_reused':162,'untouched_judge_calls_planned':31,
        'neutral_judge_checks_planned':2,'new_solver_calls_planned':0,'CPU_contexts_checked':31,
        'maximum_input_tokens':cpu['maximum_actual_input_tokens'],'tests_passed':16,
        'original_strict_outputs_preserved':True,'new_model_calls':0,'GPU_submission':False,
        'review_command':'PYTHONDONTWRITEBYTECODE=1 /dfs/scratch0/dongweij/biomni-da-cpu-runtime-20261021/bin/python '+str(HERE/'test_continuation.py')}
    save(HERE/'freeze_receipt.json',receipt)
    status=HERE/'status.json';status.write_text(__import__('json').dumps(receipt,indent=2)+'\n');status.chmod(0o600)
    print(__import__('json').dumps(receipt))


if __name__=='__main__':main()
