"""Freeze one complete positive3 adaptation only after root scientific adoption."""
from pathlib import Path
import json,unittest
import protocol
HERE=Path(__file__).resolve().parent;TASK=HERE.parent;ROOT=HERE.parents[4]

def build():
 if(HERE/'plan.json').exists():raise FileExistsError('Preserve frozen prospective condition')
 direction_path=TASK/'root_scientific_adoption_resume_20261021.json'
 direction=json.loads(direction_path.read_bytes())
 if direction.get('issuer')!='/root'or direction.get('adopted')is not True or direction.get('condition')!='released_three_demo_full_backbone_text_to_masked_all_CDR_sequence_recovery' or direction.get('max_context_tokens')!=131072 or direction.get('max_output_tokens')!=16384:raise PermissionError('Exact root scientific direction must precede final freeze')
 suite=unittest.defaultTestLoader.discover(str(HERE),pattern='test_*.py');result=unittest.TextTestRunner(verbosity=1).run(suite)
 if not result.wasSuccessful():raise ValueError('Meaningful raw-seal/scorer/closure checks failed')
 prepared=TASK/'positive3_input_preparation_v1/compact_v1';manifest=json.loads((prepared/'manifest.json').read_bytes())
 if protocol.sha(direction['prepared_manifest_path'])!=direction['prepared_manifest_sha256'] or manifest['audited_uncompacted_manifest_sha256']!=direction['prepared_manifest_sha256']:raise ValueError('Exact root-adopted complete3 input projection required')
 if manifest['prepared']!=3 or manifest['planned']!=3 or manifest['failures']or manifest['fixed_positive_cohort']!=['8q7o','8slb','8tg9']:raise ValueError('Entire fixed independently positive3 required')
 checked=json.loads((HERE/'CPU_tokenizer_validation.json').read_bytes())
 if checked['all_full_inputs_fit']is not True or checked['context_limit']!=131072 or len(checked['cases'])!=5 or max(r['prompt_tokens']for r in checked['cases'])+16384>131072:raise ValueError('All complete5 rendered/API contexts required')
 validation={'at_pacific':protocol.now(),'task_id':'P41','tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
  'model_calls':0,'GPU_allocations':0,'all5_CPU_tokenizer_API_sha256':protocol.sha(HERE/'CPU_tokenizer_validation.json'),
  'maximum_prompt_tokens':max(r['prompt_tokens']for r in checked['cases']),'context_limit':131072,'output_budget':16384,
  'CPU_vllm_package':checked['packages']['vllm'],'actual_allocated0_32_API_and_full_context_recheck_required':True,
  'all3_reference_isolated_manifest_sha256':protocol.sha(prepared/'manifest.json')}
 protocol.write(HERE/'CPU_validation_receipt.json',validation)
 prior=json.loads((TASK.parent/'P40/current38_execution_v1/plan.json').read_bytes())
 plan={k:prior[k]for k in ['model_revision','model_directory','base_runtime','cuda_overlay','private_runtime_packages','runtime_common','checkpoint_audit','vetted_V06_worker','site_tools_helper','vetted_neutral_hardware_source','project_gpu_audit_helper']}
 scope=TASK/'independent_scope_metadata_v1/positive3_preparation_scope_review.json'
 peer_scope=TASK/'independent_scope_metadata_v1/independent_positive_metadata_review_preparation_agent_20261021.json'
 source_review=TASK/'source_audits_v1/independent_masking_AAR_source_review_resume_v2.json'
 input_review=TASK/'positive3_input_preparation_v1/independent_input_review_20261021/independent_preparation_technical_review.json'
 compact_review=TASK/'positive3_input_preparation_v1/independent_compact_visible_source_review_resume_v2.json'
 source_receipt=json.loads(source_review.read_bytes());input_receipt=json.loads(input_review.read_bytes());compact_receipt=json.loads(compact_review.read_bytes())
 if source_receipt.get('stage')!='native_masking_and_AAR_source_contract_review_complete_not_scientific_adoption' or source_receipt.get('neutral_AST_checks',{}).get('passed')!=2:raise ValueError('Exact independent native mask/metric source review required')
 if input_receipt.get('passed')is not True:raise ValueError('Exact independent positive input preparation review required')
 if compact_receipt.get('stage')!='independent_compact_serializer_source_review_passed_not_runtime_admission' or compact_receipt.get('neutral_tests_independently_passed')!=5:raise ValueError('Exact independent lossless serializer review required')
 for receipt in [source_receipt,compact_receipt]:
  for name,digest in receipt['source_sha256'].items():
   if protocol.sha(name)!=digest:raise ValueError('Independently reviewed source changed')
 references=Path(manifest['scorer_only_reference_path']);references=references if references.is_absolute()else ROOT/references
 plan.update({'at_pacific':protocol.now(),'role':'frozen_prospective_positive3_condition_not_runtime_or_dispatch','owner':'/root/p41_structure','task_id':'P41',
  'condition':protocol.CONDITION,'model':protocol.MODEL,'generation':protocol.GENERATION,'planned':3,'development_planned':2,
  'fixed_case_ids':manifest['fixed_positive_cohort'],'cases':manifest['cases'],'references':str(references),
  'positive_scope_review':str(scope),'independent_positive_scope_review':str(peer_scope),'scientific_direction_path':str(direction_path),
  'independent_native_mask_metric_review':str(source_review),'independent_input_preparation_review':str(input_review),'independent_serializer_review':str(compact_review),
  'input_preparation_manifest':str(prepared/'manifest.json'),'development_inputs':str(HERE/'development_inputs.json'),'native_metric_source':str(HERE/'native_writer.py'),
  'native_metric':'Source writer.py total masked-position AAR pooled over all complete3 demos; secondary declared equal-case mean; paper aggregation unverified.',
  'runtime_tokenizer_preflight':str(HERE/'check_inputs_cpu.py'),'packager':str(HERE/'package.py'),'runtime_root':str(HERE/'runtime'),'endpoint':'http://127.0.0.1:8441/v1','context_limit':131072,
  'gpus_requested':1,'GPU_type':'A100_80GB','project_GPU_ceiling':8,'new_training':False,'paid_model_calls':False,'automatic_retries':False,
  'native_full_holdout_equivalence':False,'coordinate_metrics_available':False,'binding_or_function_assessed':False,
  'scientific_differences':manifest['material_differences']+['Lossless serialization groups chain metadata and flattens all12 backbone coordinates; exact inverse reproduces every allowed source row.',
   'Prospective131,072-token model context accommodates all complete inputs plus the uniform16,384-token output budget; no input truncation or crop.',
   'Released optional antigen design-point hotspot files are not supplied; full released selected protein docking context is preserved.',
   'One prospective local Qwen output per fixed case after artificial2 delivery; no selective retry, target feedback or trained head.',
   'Public pretraining exposure is unknown; no contamination-free or explanation-support claim.']})
 local=sorted(HERE.glob('*.py'))+[HERE/'worker.sbatch',HERE/'native_ProteoR1_LICENSE']
 prep_source=[TASK/'positive3_input_preparation_v1'/name for name in ['prepare.py','test_preparation.py','compact_visible.py','test_compact_visible.py']]
 plan['public_code_paths']=[str(p)for p in local+prep_source]
 dependencies=[ROOT/'.local/litqa2_replay'/name for name in ['runtime_archive.json','cuda_overlay_archive.json','cuda_overlay_deletions.json','publisher_verification.json']]
 delegation=ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review_resume_v2.json'
 files=[*local,*prep_source,*dependencies,delegation,references,HERE/'development_inputs.json',HERE/'CPU_validation_receipt.json',HERE/'CPU_tokenizer_validation.json',
  scope,peer_scope,direction_path,source_review,input_review,compact_review,prepared/'manifest.json',TASK/'positive3_input_preparation_v1/prepared_v3/manifest.json',
  *[Path(r['solver_path'])for r in manifest['cases']],*[Path(plan[k])for k in ['runtime_common','checkpoint_audit','vetted_V06_worker','site_tools_helper','vetted_neutral_hardware_source','project_gpu_audit_helper']],
  TASK.parent/'V06/local_execution_v2/v06_runner.py']
 plan['frozen_files_sha256']={str(p):protocol.sha(p)for p in sorted(set(files))}
 protocol.write(HERE/'plan.json',plan)
 print(json.dumps({'task_id':'P41','plan_sha256':protocol.sha(HERE/'plan.json'),'frozen_files':len(plan['frozen_files_sha256']),'model_calls':0,'GPU_allocations':0}))

if __name__=='__main__':build()
