"""Publishable narrow source/raw evidence; no protected target artifacts."""
from pathlib import Path
import hashlib,io,json,tarfile
import protocol

def package(plan,runtime,plan_sha):
 runtime=Path(runtime);complete,lock,_=protocol.verify_phase(plan,runtime/'benchmark',plan_sha,'benchmark')
 dev,devlock,_=protocol.verify_phase(plan,runtime/'development',plan_sha,'development')
 if dev['exact_copy_gate_passed']is not True:raise ValueError('Actual artificial delivery gate required')
 scores=json.loads((runtime/'benchmark/scores.json').read_bytes())
 if scores['plan_sha256']!=plan_sha or scores['planned']!=3 or scores['prediction_lock_sha256']!=protocol.sha(runtime/'benchmark/prediction_lock.json'):raise ValueError('Exact entire3 score status required')
 folder=runtime/'publication';folder.mkdir(exist_ok=False)
 result={'task_id':'P41','condition':protocol.CONDITION,'model':protocol.MODEL,'model_revision':plan['model_revision'],'planned':3,
  'primary_metric':scores['primary_metric'],'primary_metric_value':scores['primary_metric_value'],
  'secondary_metric':scores['secondary_metric'],'secondary_metric_value':scores['secondary_metric_value'],'generation':complete,
  'native_full_holdout_equivalence':False,'coordinate_metrics_available':False,'binding_or_function_assessed':False,
  'scientific_differences':plan['scientific_differences'],'plan_sha256':plan_sha,'source_revision':'ffaa787bce5f30e4cb41e2de5d0b0daab0059243'}
 protocol.write(folder/'result.json',result)
 metric='undefined (incomplete delivery)'if scores['primary_metric_value']is None else format(scores['primary_metric_value'],'.6f')
 macro='undefined'if scores['secondary_metric_value']is None else format(scores['secondary_metric_value'],'.6f')
 readme=('# Proteo-R1 released demos: three-case all-CDR sequence recovery\n\n'
  'Qwen3.8-27B reconstructs all Chothia antibody CDR sequences from complete released visible antibody/antigen backbone and sequence context. '
  'This is a separately declared structural-text input and sequence-output adaptation on three independently reviewed ordinary demo complexes.\n\n'
  '| Model | Delivered/planned | Source total-CDR AAR | Declared macro AAR |\n|---|---:|---:|---:|\n| Qwen3.8-27B | '+str(complete['delivery_passed'])+'/3 | '+metric+' | '+macro+' |\n\n'
  'Primary AAR uses the released writer.py total masked-residue recovery calculation pooled over all three complete outputs. The equal-case mean is a declared secondary metric; the paper aggregation has not been verified. '
  'All three cases remain in the planned denominator; incomplete delivery makes the primary metric undefined. Two artificial exact-copy delivery checks precede benchmark dispatch.\n\n'
  'The full SAbDab paper holdout and exact Loop-RMSD/IMP evaluator remain unavailable. No generated-coordinate, binding, biological-function, experimental-validation or paper replication result is claimed.\n\n'
  'Material differences:\n\n'+''.join('- '+v+'\n'for v in plan['scientific_differences']))
 (folder/'README.md').write_text(readme)
 entries={}
 def add(name,path):
  if name.startswith('/')or'..'in Path(name).parts or'.local'in Path(name).parts or name in entries:raise ValueError('Safe unique public alias required')
  path=Path(path)
  if path.is_symlink():raise ValueError('No archive symlinks')
  entries[name]=path.read_bytes()
 for phase,seal in [('development',devlock),('benchmark',lock)]:
  for name in seal['files_sha256']:add(phase+'/'+name,runtime/phase/name)
  for name in ['prediction_lock.json','completion.json']:add(phase+'/'+name,runtime/phase/name)
 for name in ['benchmark/scores.json','hardware_gate.json','server_identity.json','installed_identity.json','tokenizer_preflight.json','scoring_attempt.json']:add('runtime/'+name,runtime/name)
 for name in ['result.json','README.md']:add(name,folder/name)
 source_pins={}
 for index,name in enumerate(plan['public_code_paths']):
  path=Path(name)
  if protocol.sha(path)!=plan['frozen_files_sha256'][str(path)]:raise ValueError('Frozen executable public source changed')
  alias='frozen_source/'+str(index).zfill(4)+'_'+path.name;add(alias,path);source_pins[alias]=protocol.sha(path)
 entries['source_manifest.json']=(json.dumps({'source_sha256':source_pins,'protected_targets_weights_environments_credentials_or_full_GPU_inventory_included':False},indent=2)+'\n').encode()
 entries['condition.json']=(json.dumps({k:plan[k]for k in ['task_id','condition','planned','model','model_revision','generation','context_limit','scientific_differences']},indent=2)+'\n').encode()
 archive=folder/'P41_positive3_allCDR_all_outcomes.tar.gz'
 with tarfile.open(archive,'x:gz')as tar:
  for name,body in sorted(entries.items()):
   info=tarfile.TarInfo(name);info.size=len(body);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(body))
 manifest={'archive':str(archive),'sha256':protocol.sha(archive),'bytes':archive.stat().st_size,'files':{name:{'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}for name,body in entries.items()},
  'planned':3,'native_full_holdout_equivalence':False,'protected_targets_or_unmasked_coordinates_included':False,
  'weights_environments_credentials_full_account_inventory_included':False,'new_model_calls':0}
 protocol.write(folder/'manifest.json',manifest);return manifest
