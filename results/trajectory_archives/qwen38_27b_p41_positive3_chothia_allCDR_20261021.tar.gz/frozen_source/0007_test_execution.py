"""Artificial transport, full-case raw seal, source-metric and leakage gates."""
from pathlib import Path
import json,tempfile,unittest
import protocol,score_locked,admission
HERE=Path(__file__).resolve().parent
NATIVE=HERE/'native_writer.py'

def reply(sequence='AA',**message):
 return json.dumps({'choices':[{'finish_reason':'stop','message':{'content':json.dumps({'sequence':sequence},separators=(',',':')),**message}}]}).encode()
def case(i=0,length=2):return {'case_id':'artificial_'+str(i),'condition_id':protocol.CONDITION,'target_length':length,'messages':[{'role':'user','content':'Complete artificial context.'}]}
class Fixture:
 def __init__(self,root):
  self.root=Path(root);self.rows=[case(i)for i in range(3)];paths=[]
  for row in self.rows:
   p=self.root/(row['case_id']+'.json');p.write_text(json.dumps(row));paths.append(p)
  self.refs=self.root/'protected.json';self.refs.write_text(json.dumps({'cases':[{'case_id':r['case_id'],'target_sequence':'AA','target_length':2}for r in self.rows]}))
  self.plan={'cases':[{'case_id':r['case_id'],'target_length':2,'solver_path':str(p)}for r,p in zip(self.rows,paths)],'fixed_case_ids':[r['case_id']for r in self.rows],
   'references':str(self.refs),'native_metric_source':str(NATIVE),'frozen_files_sha256':{str(p):protocol.sha(p)for p in [*paths,self.refs,NATIVE]}}
 def run(self,transport=None):
  self.phase=self.root/'benchmark';return protocol.run_phase(self.rows,self.phase,transport or(lambda body:reply()),phase='benchmark',plan_sha='fixture')

class Execution(unittest.TestCase):
 def test_authorized_uniform16K_budget_preserved(self):
  self.assertEqual(protocol.GENERATION['max_tokens'],16384)
 def test_all_CDR_lengths_above_single_loop_limit(self):
  self.assertEqual(protocol.parse_reply(reply('A'*100),100)['status'],'delivered')
 def test_whole_canonical_exact_length_only(self):
  for value in ['A','AAA','AX','aa']:
   self.assertNotEqual(protocol.parse_reply(reply(value),2)['status'],'delivered')
 def test_unknown_is_distinct_from_observed_empty(self):
  for raw in [b'{}',b'[]',b'not-json']:
   out=protocol.parse_reply(raw,2);self.assertFalse(out['observed_final']);self.assertFalse(out['empty_final'])
  for value in [None,'',' ']:
   raw=json.dumps({'choices':[{'finish_reason':'stop','message':{'content':value}}]}).encode()
   out=protocol.parse_reply(raw,2);self.assertTrue(out['observed_final']);self.assertTrue(out['empty_final'])
 def test_no_reasoning_tools_or_refusal(self):
  for field,value in [('reasoning','x'),('reasoning_content','x'),('tool_calls',[{}]),('refusal','x')]:
   self.assertNotEqual(protocol.parse_reply(reply(**{field:value}),2)['status'],'delivered')
 def test_no_format_repair_or_truncation_acceptance(self):
  body=json.loads(reply());body['choices'][0]['finish_reason']='length'
  self.assertTrue(protocol.parse_reply(json.dumps(body).encode(),2)['truncation'])
  body=json.loads(reply());body['choices'][0]['message']['content']=' {"sequence":"AA"}'
  self.assertNotEqual(protocol.parse_reply(json.dumps(body).encode(),2)['status'],'delivered')
 def test_failed_transport_preserves_full_denominator_no_retry(self):
  with tempfile.TemporaryDirectory()as root:
   f=Fixture(root);calls=[]
   def failed(body):calls.append(body);raise protocol.TransportFailure(503,b'artificial')
   result=f.run(failed);self.assertEqual(len(calls),1);self.assertEqual(result['not_dispatched'],2);self.assertEqual(result['server_errors'],1)
   protocol.verify_phase(f.plan,f.phase,'fixture','benchmark')
 def test_local_guard_and_nonbytes_seal_unknown_not_empty(self):
  for kind in ['guard','nonbytes']:
   with self.subTest(kind=kind),tempfile.TemporaryDirectory()as root:
    f=Fixture(root);calls=[]
    def transport(body):
     calls.append(body)
     if kind=='guard':raise PermissionError('Artificial owned-server identity changed')
     return {'invalid':'nonbytes'}
    result=f.run(transport)
    self.assertEqual(len(calls),1);self.assertEqual(result['not_dispatched'],2);self.assertEqual(result['client_guard_errors'],1)
    self.assertEqual(result['unknown_finals'],1);self.assertEqual(result['observed_empty_finals'],0)
    protocol.verify_phase(f.plan,f.phase,'fixture','benchmark')
 def test_artificial_failure_stops_before_benchmark(self):
  with tempfile.TemporaryDirectory()as root:
   calls=[]
   def wrong(body):calls.append(body);return reply('CC')
   result=protocol.run_phase([case(),case(1)],Path(root)/'dev',wrong,phase='development',plan_sha='fixture',expected=['AA','AA'])
   self.assertEqual(len(calls),1);self.assertFalse(result['exact_copy_gate_passed'])
 def test_complete3_source_metric_once_only(self):
  with tempfile.TemporaryDirectory()as root:
   f=Fixture(root);f.run();out=score_locked.score(f.plan,'fixture',f.phase,Path(root)/'scores.json')
   self.assertEqual(out['primary_metric_value'],1);self.assertEqual(len(out['cases']),3);self.assertFalse(out['native_paper_aggregation_verified'])
   with self.assertRaises(FileExistsError):score_locked.score(f.plan,'fixture',f.phase,Path(root)/'scores.json')
 def test_primary_source_total_and_secondary_case_mean_are_distinct(self):
  with tempfile.TemporaryDirectory()as root:
   f=Fixture(root);lengths=[2,1,4];predictions=iter(['AC','A','CCCC']);references=[]
   for row,meta,length in zip(f.rows,f.plan['cases'],lengths):
    row['target_length']=length;meta['target_length']=length;p=Path(meta['solver_path']);p.write_text(json.dumps(row));f.plan['frozen_files_sha256'][str(p)]=protocol.sha(p)
    references.append({'case_id':row['case_id'],'target_sequence':'A'*length,'target_length':length})
   f.refs.write_text(json.dumps({'cases':references}));f.plan['frozen_files_sha256'][str(f.refs)]=protocol.sha(f.refs)
   f.run(lambda body:reply(next(predictions)));out=score_locked.score(f.plan,'fixture',f.phase,Path(root)/'scores.json')
   self.assertEqual(out['primary_metric_value'],2/7);self.assertEqual(out['secondary_metric_value'],.5)
 def test_missing_case_does_not_open_targets(self):
  with tempfile.TemporaryDirectory()as root:
   f=Fixture(root);f.refs.write_text('MUST NOT BE PARSED');f.plan['frozen_files_sha256'][str(f.refs)]=protocol.sha(f.refs)
   f.run(lambda body:reply('A'));out=score_locked.score(f.plan,'fixture',f.phase,Path(root)/'scores.json')
   self.assertIsNone(out['primary_metric_value']);self.assertEqual(out['planned'],3);self.assertFalse(out['reference_access_after_complete_raw_seal'])
 def test_raw_seal_and_request_identity(self):
  for file in ['request.json','response.raw.json','outcome.json']:
   with self.subTest(file=file),tempfile.TemporaryDirectory()as root:
    f=Fixture(root);f.run();(f.phase/'case_0000'/file).write_text('{}')
    with self.assertRaises(ValueError):protocol.verify_phase(f.plan,f.phase,'fixture','benchmark')
 def test_forged_parse_with_relocked_hash_rejected(self):
  with tempfile.TemporaryDirectory()as root:
   f=Fixture(root);f.run();p=f.phase/'case_0000/outcome.json';out=json.loads(p.read_text());out['sequence']='CC';p.write_text(json.dumps(out))
   seal=f.phase/'prediction_lock.json';lock=json.loads(seal.read_text());lock['files_sha256']['case_0000/outcome.json']=protocol.sha(p);seal.write_text(json.dumps(lock))
   completion=f.phase/'completion.json';obj=json.loads(completion.read_text());obj['prediction_lock_sha256']=protocol.sha(seal);completion.write_text(json.dumps(obj))
   with self.assertRaises(ValueError):protocol.verify_phase(f.plan,f.phase,'fixture','benchmark')
 def test_source_total_recovers_only_masked_positions(self):
  compute=score_locked.source_total_aar(NATIVE.read_bytes(),protocol.sha(NATIVE))
  self.assertEqual(compute('ACDE','ACAA'),.5);self.assertEqual(compute('A','A'),1)
  with self.assertRaises(ValueError):compute('A','AA')
 def test_modified_source_fails_closed(self):
  with self.assertRaises(ValueError):score_locked.source_total_aar(NATIVE.read_bytes()+b'\n','x')
 def test_private_context_changed_after_startup_rejected(self):
  with tempfile.TemporaryDirectory()as root:
   f=Fixture(root);Path(f.plan['cases'][0]['solver_path']).write_text('{}')
   with self.assertRaises(ValueError):protocol.cases(f.plan,'benchmark')
 def test_owner_cannot_self_admit_and_scope_context_are_fixed(self):
  with tempfile.TemporaryDirectory()as directory:
   root=Path(directory);ids=['artificial_0','artificial_1','artificial_2']
   scope=root/'scope.json';scope.write_text(json.dumps({'positive_preparation_case_ids':ids}))
   direction=root/'direction.json';direction.write_text(json.dumps({'issuer':'/root','condition':'released_three_demo_full_backbone_text_to_masked_all_CDR_sequence_recovery','adopted':True,'max_context_tokens':131072,'max_output_tokens':16384,'artificial_fixture_only':True}))
   audit=root/'audit.json';audit.write_text('{"artificial_fixture_only":true}')
   plan={'task_id':'P41','condition':protocol.CONDITION,'model':protocol.MODEL,'planned':3,'development_planned':2,'gpus_requested':1,'context_limit':131072,
    'native_full_holdout_equivalence':False,'coordinate_metrics_available':False,'binding_or_function_assessed':False,'new_training':False,'paid_model_calls':False,'automatic_retries':False,
    'generation':protocol.GENERATION,'endpoint':'http://127.0.0.1:8441/v1','model_revision':'1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0','runtime_root':str(HERE/'runtime'),
    'fixed_case_ids':ids,'positive_scope_review':str(scope),'scientific_direction_path':str(direction),'frozen_files_sha256':{str(p):protocol.sha(p)for p in [scope,direction]}}
   path=root/'plan.json';path.write_text(json.dumps(plan));digest=protocol.sha(path)
   grant={'admitted':True,'task_id':'P41','plan_sha256':digest,'condition':protocol.CONDITION,'planned':3,'gpu_count':1,'project_gpu_ceiling':8,'context_limit':131072,
    'native_full_holdout_equivalence':False,'coordinate_metrics_available':False,'binding_or_function_assessed':False,'source_adaptation_accepted':True,'one_attempt_per_case':True,'new_training':False,'paid_model_calls':False,
    'gpu_audit_receipt':str(audit),'gpu_audit_receipt_sha256':protocol.sha(audit),'delegation_sha256':admission.POLICY_SHA}
   g=root/'grant.json'
   for reviewer in [admission.OWNER,'/root/unauthorized_peer']:
    g.write_text(json.dumps({**grant,'reviewer':reviewer}))
    with self.assertRaises(PermissionError):admission.validate(path,digest,g,protocol.sha(g))
   g.write_text(json.dumps({**grant,'reviewer':'/root/p37_delivery'}));admission.validate(path,digest,g,protocol.sha(g))
   g.write_text(json.dumps({**grant,'reviewer':'/root/p37_delivery','context_limit':65536}))
   with self.assertRaises(ValueError):admission.validate(path,digest,g,protocol.sha(g))
if __name__=='__main__':unittest.main()
