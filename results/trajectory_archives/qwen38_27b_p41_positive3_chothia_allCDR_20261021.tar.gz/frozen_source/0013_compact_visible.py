"""Lossless serialization of existing allowed packets; never opens references."""
from pathlib import Path
import argparse,copy,hashlib,json
from prepare import messages,CONDITION

def compact(packet):
 if packet['coordinate_unit']!='milliangstrom' or packet['row_columns']!=['role','chain','position_1based','aa','backbone']:raise ValueError('Exact audited visible packet required')
 chains=[];seen=[]
 for role,cid,pos,aa,atoms in packet['residues']:
  if cid not in seen:
   seen.append(cid);chains.append({'role':role,'chain':cid,'sequence':'','backbone':[]})
  chain=chains[-1]
  if chain['chain']!=cid or chain['role']!=role or pos!=len(chain['backbone'])+1:raise ValueError('Contiguous complete chain order required')
  masked=aa=='[MASK]'
  if masked and atoms is not None:raise ValueError('Target coordinate isolation failed')
  chain['sequence']+='X'if masked else aa
  if atoms is None:chain['backbone'].append(None)
  else:
   if len(atoms)!=4 or any(atom is not None and len(atom)!=3 for atom in atoms):raise ValueError('Full4atom context required')
   chain['backbone'].append([v for atom in atoms for v in (atom if atom is not None else[None]*3)])
 out={'coordinate_unit':packet['coordinate_unit'],'backbone_columns':['N_x','N_y','N_z','CA_x','CA_y','CA_z','C_x','C_y','C_z','O_x','O_y','O_z'],
  'positions':'1-based sequence positions; backbone rows correspond one-to-one to every complete chain sequence position',
  'target_segments':copy.deepcopy(packet['target_segments']),'target_length':packet['target_length'],'chains':chains}
 # An exact inverse proves every allowed original identity/coordinate survives.
 if expand(out)!=packet['residues']:raise ValueError('Lossless visible context inverse failed')
 return out

def expand(packet):
 masked={(s['chain'],p)for s in packet['target_segments']for p in s['positions_1based']};rows=[]
 for chain in packet['chains']:
  if len(chain['sequence'])!=len(chain['backbone']):raise ValueError('Full sequence/backbone coverage differs')
  for index,(aa,flat)in enumerate(zip(chain['sequence'],chain['backbone']),1):
   if(chain['chain'],index)in masked:
    if aa!='X'or flat is not None:raise ValueError('Target identity/coordinate isolation failed')
    aa='[MASK]';atoms=None
   else:
    if flat is None or len(flat)!=12:raise ValueError('Visible atom tuple correspondence differs')
    atoms=[None if flat[i:i+3]==[None]*3 else flat[i:i+3]for i in range(0,12,3)]
   rows.append([chain['role'],chain['chain'],index,aa,atoms])
 return rows

def run(source,output):
 source=source.resolve();output=output.resolve();manifest=json.loads((source/'manifest.json').read_bytes());records=[]
 if manifest['prepared']!=3 or manifest['failures']:raise ValueError('Exactly complete audited positive3 source required')
 output.mkdir(exist_ok=False)
 for row in manifest['cases']:
  path=Path(row['solver_path']);path=path if path.is_absolute()else Path('/dfs/scratch0/dongweij/bio-evaluation')/path
  raw=path.read_bytes()
  if hashlib.sha256(raw).hexdigest()!=row['solver_sha256']:raise ValueError('Existing allowed packet bytes changed')
  case=json.loads(raw);text=case['messages'][0]['content'];prefix,payload=text.split('\n\n',1);packet=json.loads(payload);new=compact(packet)
  instruction=prefix.replace('All masked identities and coordinates are withheld.','All masked identities and coordinates are withheld. Each chain sequence uses X at the target positions; its backbone array includes exactly one row per complete sequence position. Backbone columns name all12 coordinates explicitly.').replace('Backbone atom order is N, CA, C, O','Backbone atom order is N, CA, C, O')
  case['messages']=[{'role':'user','content':instruction+'\n\n'+json.dumps(new,separators=(',',':'),allow_nan=False)}]
  target=output/(row['case_id']+'.json');target.write_text(json.dumps(case,indent=2,allow_nan=False)+'\n')
  records.append({**row,'solver_path':str(target),'solver_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'lossless_visible_packet_inverse_passed':True})
 result={**manifest,'cases':records,'audited_uncompacted_manifest_path':str(source/'manifest.json'),'audited_uncompacted_manifest_sha256':hashlib.sha256((source/'manifest.json').read_bytes()).hexdigest(),
  'role':'lossless_visible_packet_serialization_no_reference_reads','source_rendering_code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 (output/'manifest.json').write_text(json.dumps(result,indent=2)+'\n');return result

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();print(json.dumps({'prepared':len(run(a.source,a.output)['cases']),'model_calls':0,'reference_reads':0}))
