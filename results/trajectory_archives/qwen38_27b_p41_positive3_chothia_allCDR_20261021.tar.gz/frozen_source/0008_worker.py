"""One independently admitted TP1 allocation: artificial2 -> masked3 -> native AAR.

Preparation never creates an admission or submits this worker. All current
frozen evaluation queues and all other jobs remain unchanged.
"""
from __future__ import annotations
import argparse
import ast
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import types
import urllib.error
import urllib.parse
import urllib.request

HERE = Path(__file__).resolve().parent
SOURCE = HERE
ROOT = HERE.parents[4]
sys.path.insert(0, str(SOURCE))
import protocol
import admission


def load(name, path, extra=None):
    if extra:
        sys.path.insert(0, str(extra))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec);sys.modules[name] = module;spec.loader.exec_module(module)
    return module


def read(path):
    return json.loads(Path(path).read_text())


def validate(plan_path,plan_sha,admission_path=None,admission_sha=None):
    return admission.validate(plan_path,plan_sha,admission_path,admission_sha,require_job=admission_path is not None)

def gpu_audit(plan):
    return admission.current_project_audit(plan)


def hardware_check(torch, plan, runtime):
    # Reuse only the unchanged neutral hardware-check function; never execute
    # the native ProtST module/imports/model path from the surrounding file.
    source = Path(plan['vetted_neutral_hardware_source'])
    tree = ast.parse(source.read_text())
    functions = [item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name == 'check_hardware']
    if len(functions) != 1:
        raise ValueError('Pinned neutral hardware interface missing')
    namespace = {'contract': types.SimpleNamespace(now=protocol.now, write_json=lambda path,value:protocol.write(path,value,exclusive=False)),
                 'subprocess': subprocess}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(source), 'exec'), namespace)
    return namespace['check_hardware'](torch, runtime, plan)


def run_phases(plan,identity,common,local,plan_path,plan_sha):
    runtime=Path(plan['runtime_root']);opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    identity_sha=protocol.sha(runtime/'server_identity.json')
    def transport(body):
        if (protocol.sha(runtime/'server_identity.json')!=identity_sha or identity['job_id']!=os.environ['SLURM_JOB_ID']
                or identity['hostname']!=socket.gethostname() or common.start_ticks(identity['pid'])!=identity['proc_start_ticks']):
            raise PermissionError('Exact owned dedicated server identity changed')
        request=urllib.request.Request(plan['endpoint']+'/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
        try:
            with opener.open(request,timeout=1800)as response:return response.read(16*1024*1024+1)
        except urllib.error.HTTPError as error:
            raise protocol.TransportFailure(error.code,error.read(16*1024*1024+1))from error
        except(urllib.error.URLError,TimeoutError,OSError)as error:raise protocol.TransportFailure()from error
    def phase(name,expected=None):
        rows=protocol.cases(plan,name) # exact consumed input buffers rehashed after long startup
        protocol.write(runtime/'status.json',{'at_pacific':protocol.now(),'stage':name+'_generation','job_id':os.environ['SLURM_JOB_ID'],'planned':len(rows),'direct_progress_path':str(runtime/name/'progress.json'),'no_automatic_retry':True},exclusive=False)
        return protocol.run_phase(rows,runtime/name,transport,phase=name,plan_sha=plan_sha,expected=expected)
    artificial=protocol.read_frozen(plan['development_inputs'],plan['frozen_files_sha256'])
    dev=phase('development',artificial['expected_sequences'])
    protocol.verify_phase(plan,runtime/'development',plan_sha,'development')
    if dev['exact_copy_gate_passed']is not True:raise RuntimeError('Actual artificial exact-copy delivery failed; no benchmark')
    benchmark=phase('benchmark')
    protocol.verify_phase(plan,runtime/'benchmark',plan_sha,'benchmark')
    protocol.write(runtime/'scoring_attempt.json',{'at_pacific':protocol.now(),'plan_sha256':plan_sha,'prediction_lock_sha256':benchmark['prediction_lock_sha256'],'sole_scoring_attempt':True,'reference_access_only_after_all3_delivered':True})
    subprocess.run([str(local/'python/bin/python3.12'),str(HERE/'score_locked.py'),'--plan',str(plan_path),'--plan-sha256',plan_sha,'--phase',str(runtime/'benchmark'),'--output',str(runtime/'benchmark/scores.json')],check=True,timeout=180)
    return {'development':dev,'benchmark':benchmark,'score':read(runtime/'benchmark/scores.json')}


def main():
    parser = argparse.ArgumentParser();parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha256', required=True);parser.add_argument('--admission', type=Path)
    parser.add_argument('--admission-sha256');parser.add_argument('--runtime-dir', type=Path)
    parser.add_argument('--check-only', action='store_true');args = parser.parse_args()
    plan = validate(args.plan, args.plan_sha256)
    if args.check_only:
        print(json.dumps({'planned': 3, 'development': 2, 'root_admission_required': True,
                          'model_calls': 0, 'GPU_allocations': 0}));return
    if args.admission is None or args.admission_sha256 is None:
        raise ValueError('Root admission is mandatory')
    validate(args.plan, args.plan_sha256, args.admission, args.admission_sha256)
    runtime = Path(plan['runtime_root']);runtime.mkdir(exist_ok=True)
    shared = load('p41_vetted_v06_runtime_helpers', plan['vetted_V06_worker'], Path(plan['vetted_V06_worker']).parent)
    common = shared.common_module(plan)
    if args.runtime_dir is None:
        lock = (runtime / 'allocation.lock').open('a');fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if (runtime / 'allocation_started.json').exists():
            raise ValueError('No automatic reallocation or repeated calls')
        protocol.write(runtime / 'gpu_budget_audit.json', gpu_audit(plan), exclusive=True)
        protocol.write(runtime / 'allocation_started.json', {'at_pacific': protocol.now(),
            'job_id': os.environ['SLURM_JOB_ID'], 'plan_sha256': args.plan_sha256}, exclusive=True)
        if shutil.disk_usage('/tmp').free < 32 * 1024 ** 3:
            raise ValueError('At least32GiB private scratch is required')
        for field in ['base_runtime', 'cuda_overlay']:
            if protocol.sha(plan[field]['path']) != plan[field]['sha256']:
                raise ValueError('Cached dependency archive changed')
        local = Path(tempfile.mkdtemp(prefix='bio-p41-' + os.environ['SLURM_JOB_ID'] + '-'))
        with tarfile.open(plan['base_runtime']['path']) as archive:
            archive.extractall(local, filter='data')
        protocol.write(runtime / 'archive_receipt.json', {'local_prefix': str(local), **common.apply_overlay(local)}, exclusive=True)
        environment = shared.clean_environment(common, local)
        site = load('p41_pinned_site_tools', plan['site_tools_helper'])
        environment, tools = site.bind_site_tools(environment)
        environment.update(PYTHONPATH=str(SOURCE), VLLM_USE_V2_MODEL_RUNNER='0')
        protocol.write(runtime / 'site_tool_binding.json', {'tools': tools}, exclusive=True)
        shared.install_private_runtime(local / 'python/bin/python3.12', environment, runtime)
        command = [str(local / 'python/bin/python3.12'), str(Path(__file__).resolve()),
                   *sys.argv[1:], '--runtime-dir', str(local)]
        os.execve(command[0], command, environment)
    local = args.runtime_dir.resolve()
    if not local.name.startswith('bio-p41-' + os.environ['SLURM_JOB_ID'] + '-'):
        raise ValueError('Private prefix ownership changed')
    lock = (runtime / 'protocol.lock').open('a');fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if any((runtime / name).exists() for name in ['development', 'benchmark', 'terminal_receipt.json']):
        raise ValueError('No existing partial or complete phase may be repeated')
    audit = gpu_audit(plan);protocol.write(runtime / 'gpu_budget_audit_at_server_start.json', audit, exclusive=True)
    import importlib.metadata as metadata
    import torch
    packages = {'packages': {name: metadata.version(name) for name in shared.PINNED_PACKAGES}}
    shared.verify_package_identity(packages)
    protocol.write(runtime / 'installed_identity.json', packages, exclusive=True)
    if os.environ.get('VLLM_USE_V2_MODEL_RUNNER') != '0':
        raise ValueError('Exact tested legacy V1 server runner required')
    hardware = hardware_check(torch, plan, runtime)
    model = common.validate_checkpoint(plan['model'], plan['model_revision'])
    if str(model) != plan['model_directory']:
        raise ValueError('Original pinned model directory differs')
    # Repeat the actual native tokenizer check in this exact restored runtime.
    cpu_environment=dict(os.environ);cpu_environment['CUDA_VISIBLE_DEVICES']=''
    subprocess.run([str(local / 'python/bin/python3.12'), plan['runtime_tokenizer_preflight'],
                    '--plan', str(args.plan), '--output', str(runtime / 'tokenizer_preflight.json')],env=cpu_environment,check=True,timeout=180)
    checked=read(runtime/'tokenizer_preflight.json')
    if checked['packages']['vllm']!='0.32.0'or checked['actual0_32_API_recheck_required_before_neural_phases']is not False:
        raise ValueError('Actual exact0.32 HTTP regex/full-context gate required before neural phases')
    port=urllib.parse.urlparse(plan['endpoint']).port
    with socket.socket() as probe:
        probe.bind(('127.0.0.1',port))
    command = [str(local / 'python/bin/python3.12'), '-m', 'vllm.entrypoints.cli.main', 'serve', str(model),
        '--served-model-name', plan['model'], '--host', '127.0.0.1', '--port',str(port),
        '--dtype', 'bfloat16', '--tensor-parallel-size', '1', '--gpu-memory-utilization', '0.95',
        '--max-model-len', str(plan['context_limit']), '--max-num-seqs', '1', '--max-num-batched-tokens', '8192',
        '--reasoning-parser', 'qwen3', '--enable-prefix-caching', '--limit-mm-per-prompt', '{"image":0,"video":0}']
    server = None
    try:
        protocol.write(runtime / 'status.json', {'at_pacific': protocol.now(), 'stage': 'starting_dedicated_P41_server',
            'job_id': os.environ['SLURM_JOB_ID'], 'endpoint': plan['endpoint']}, exclusive=False)
        with (runtime / 'server.log').open('x') as log:
            server = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                      start_new_session=True, cwd=local)
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}));deadline = time.monotonic() + 1800
        while time.monotonic() < deadline:
            if server.poll() is not None:
                raise RuntimeError('Own server exited before readiness')
            try:
                with opener.open('http://127.0.0.1:'+str(port)+'/health', timeout=3) as response:
                    if response.status == 200:
                        break
            except (OSError, urllib.error.URLError):
                time.sleep(3)
        else:
            raise TimeoutError('Dedicated server startup timed out; no retry')
        with opener.open(plan['endpoint'] + '/models', timeout=5) as response:
            models = json.load(response)
        if [row['id'] for row in models['data']] != [plan['model']]:
            raise ValueError('Actual served model identity differs')
        identity = {'at_pacific': protocol.now(), 'task_id': 'P41', 'condition': protocol.CONDITION,
            'model': plan['model'], 'revision': plan['model_revision'], 'dtype': 'bfloat16',
            'job_id': os.environ['SLURM_JOB_ID'], 'hostname': socket.gethostname(),
            'pid': server.pid, 'proc_start_ticks': common.start_ticks(server.pid),
            'endpoint': plan['endpoint'], 'plan_sha256': args.plan_sha256,
            'admission_sha256': args.admission_sha256, 'GPU_uuid': hardware['GPU_uuid'],
            'native_full_holdout_equivalence': False, 'binding_or_function_assessed': False}
        protocol.write(runtime / 'server_identity.json', identity, exclusive=True)
        result = run_phases(plan, identity, common, local, args.plan, args.plan_sha256)
        package = load('p41_public_output_packager', plan['packager'])
        receipt = package.package(plan, runtime, args.plan_sha256)
        protocol.write(runtime / 'terminal_receipt.json', {'at_pacific': protocol.now(),
            'stage': 'positive3_outcomes_and_declared_source_AAR_status_sealed_local_bundle_ready',
            'benchmark_completion_sha256': protocol.sha(runtime / 'benchmark/completion.json'),
            'score_sha256': protocol.sha(runtime / 'benchmark/scores.json'),
            'archive_sha256': receipt['sha256'], 'native_full_holdout_equivalence': False,
            'public_upload_performed': False}, exclusive=True)
        protocol.write(runtime / 'status.json', {'at_pacific': protocol.now(), 'stage': 'positive3_scoring_terminal',
            'primary_metric': 'source_totalCDR_AAR', 'primary_metric_value': result['score']['primary_metric_value'],
            'native_full_holdout_equivalence': False, 'binding_or_function_assessed': False}, exclusive=False)
    except Exception as error:
        protocol.write(runtime / 'status.json', {'at_pacific': protocol.now(), 'stage': 'stopped_for_review_no_retry',
            'error_type': type(error).__name__, 'error': str(error), 'missing_progress_is_not_zero_attempts': True}, exclusive=False)
        raise
    finally:
        if server is not None and server.poll() is None:
            os.killpg(server.pid, signal.SIGTERM)
            try:
                server.wait(timeout=60)
            except subprocess.TimeoutExpired:
                os.killpg(server.pid, signal.SIGKILL);server.wait(timeout=10)
        protocol.write(runtime / 'server_terminal.json', {'at_pacific': protocol.now(),
            'own_server_stopped': True, 'other_project_runtimes_changed': False}, exclusive=True)


if __name__ == '__main__':
    main()
