import copy,unittest
from prepare import project
from test_preparation import fixture
from compact_visible import compact,expand

class Compact(unittest.TestCase):
 def test_lossless_every_sequence_position_and_coordinate(self):
  packet,_,_=project(*fixture());snapshot=copy.deepcopy(packet);out=compact(packet)
  self.assertEqual(expand(out),packet['residues']);self.assertEqual(packet,snapshot)
  self.assertEqual(sum(len(c['sequence'])for c in out['chains']),30)
 def test_source_missing_atom_and_unknown_identity_survive(self):
  f=list(fixture());f[2][('H',1)]={};f[0]['sequences'][2]['proteinChain']['sequence']='XCDEFGHIKL'
  packet,_,_=project(*f);self.assertEqual(expand(compact(packet)),packet['residues'])
 def test_masked_coordinate_or_identity_rejected(self):
  packet,_,_=project(*fixture());out=compact(packet);out['chains'][0]['sequence']='A'*10
  with self.assertRaises(ValueError):expand(out)
 def test_source_target_coordinates_rejected(self):
  packet,_,_=project(*fixture());next(r for r in packet['residues']if r[3]=='[MASK]')[4]=[[0,0,0]]*4
  with self.assertRaises(ValueError):compact(packet)
 def test_dropped_context_position_rejected(self):
  packet,_,_=project(*fixture());packet['residues'].pop(0)
  with self.assertRaises(ValueError):compact(packet)

if __name__=='__main__':unittest.main()
