"""CPU-only projection of three independently metadata-admitted demo complexes.

Full released protein context is retained. All Chothia CDR identities and
coordinates enter only the separate trusted scorer artifact. No model loads.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse,hashlib,importlib.util,json,math,os,sys

ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
HERE=Path(__file__).resolve().parent
TASK=HERE.parent
CONDITION='P41_RELEASED_POSITIVE3_CHOTHIA_ALLCDR_BACKBONE_TEXT_RECOVERY_V1'
NATIVE=ROOT/'.local/source_acquisition_2026-10-19/protocols/smiles724__Proteo-R1/files/proteor1/cdr_eval/cdr_masking.py'
SOURCE=ROOT/'.local/source_recovery_round2_2026-10-19/structural/source/smiles724__Proteo-R1/data/demo'
AA3=dict(zip('ALA CYS ASP GLU PHE GLY HIS ILE LYS LEU MET ASN PRO GLN ARG SER THR VAL TRP TYR'.split(),'ACDEFGHIKLMNPQRSTVWY'))
AA=set(AA3.values());BACKBONE=['N','CA','C','O']
IDS=['8q7o','8slb','8tg9']

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('x')as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
def now():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module

def check_domain_identity(sequence,ab_chain,expected,start):
 """Independent strict role/offset check for native single-domain blind spots."""
 allowed={'H'}if expected=='H'else{'K','L'}if expected=='L'else set()
 if ab_chain.chain_type not in allowed:raise ValueError('Actual numbered domain role differs from released chain contract')
 domain=ab_chain.seq
 if not domain or sequence.find(domain)!=start or sequence.find(domain,start+1)!=-1:raise ValueError('Variable domain must have one exact unambiguous full-sequence location')
 return True

def messages(packet):
 instruction=('Reconstruct the masked antibody CDR amino-acid identities from this experimental antibody-antigen structural context. '
  'This is reference sequence reconstruction; binding or biological activity is not established. '
  'Every antibody Chothia CDR1, CDR2 and CDR3 is masked. All masked identities and coordinates are withheld. '
  'Full released antibody and antigen chains are preserved without cropping. Backbone atom order is N, CA, C, O in milliangstroms (divide by 1000 for angstroms); '
  'null for a visible atom means that atom was absent from the released structure. '
  'The ordered target_segments specify which positions to reconstruct. Concatenate the amino-acid letters for each segment, '
  'in the listed segment and position order. Return exactly '+str(packet['target_length'])+' canonical amino-acid letters '
  'as one compact JSON object with the single key "sequence". Do not explain.\n\n')
 return [{'role':'user','content':instruction+json.dumps(packet,separators=(',',':'),allow_nan=False)}]

def project(native_json,regions_by_chain,coordinates,roles):
 """Pure allowlisted target isolation; never serialize extra input fields."""
 targets=[];rows=[];target_sequence='';coordinate_gold={}
 entities=native_json['sequences'];seen=[]
 for entity in entities:
  if set(entity)!={'proteinChain'}:raise ValueError('Protein-only single-copy context required')
  chain=entity['proteinChain'];ids=chain.get('auth_asym_id',[])
  if len(ids)!=1 or chain.get('count',1)!=1:raise ValueError('Exact one-copy chain required')
  cid=ids[0];seen.append(cid);sequence=chain['sequence']
  if cid not in roles or not sequence or any(a not in AA|{'X'}for a in sequence):raise ValueError('Invalid complete chain')
  regions=regions_by_chain.get(cid,{})
  if roles[cid] in ['heavy','light']and set(regions)!={'cdr1','cdr2','cdr3'}:raise ValueError('All three CDR masks required')
  if roles[cid]=='antigen'and regions:raise ValueError('Antigen must stay unmasked')
  masked=[]
  for name in ['cdr1','cdr2','cdr3']:
   if name not in regions:continue
   indices=regions[name]
   if not indices or indices!=sorted(set(indices))or any(type(i)is not int or not 0<=i<len(sequence)for i in indices):raise ValueError('Invalid CDR indices')
   if any(sequence[i]not in AA for i in indices):raise ValueError('Canonical target identity required')
   masked.extend(indices);targets.append({'role':roles[cid],'chain':cid,'region':name,'positions_1based':[i+1 for i in indices]})
   target_sequence+=''.join(sequence[i]for i in indices)
  if len(masked)!=len(set(masked)):raise ValueError('Overlapping CDR regions')
  masked=set(masked)
  for index,aa in enumerate(sequence):
   atoms=coordinates.get((cid,index+1),{})
   if any(k not in BACKBONE for k in atoms):raise ValueError('Backbone-only projection required')
   points=[]
   for atom in BACKBONE:
    value=atoms.get(atom)
    if value is not None and(len(value)!=3 or any(type(v)not in [int,float]or not math.isfinite(v)for v in value)):raise ValueError('Finite backbone coordinates required')
    if value is not None:
     compact=[round(v*1000)for v in value]
     if any(abs(v-c/1000)>1e-8 for v,c in zip(value,compact)):raise ValueError('Source precision exceeds exact milliangstrom representation')
     value=compact
    points.append(value)
   if index in masked:
    rows.append([roles[cid],cid,index+1,'[MASK]',None]);coordinate_gold[cid+':'+str(index+1)]=points
   else:rows.append([roles[cid],cid,index+1,aa,points])
 if len(seen)!=len(set(seen))or set(seen)!=set(roles):raise ValueError('Exact complete chain roster required')
 packet={'coordinate_unit':'milliangstrom','row_columns':['role','chain','position_1based','aa','backbone'],
  'backbone_atom_order':BACKBONE,'backbone_coordinate_order':['x','y','z'],'target_segments':targets,
  'target_length':len(target_sequence),'residues':rows}
 if sum(row[3]=='[MASK]'for row in rows)!=len(target_sequence):raise ValueError('Target isolation differs')
 return packet,target_sequence,coordinate_gold

def coordinate_map(path,native_json,gemmi):
 """Map atom_site label_seq_id to the native full entity sequence index."""
 block=gemmi.cif.read_file(str(path)).sole_block()
 names=['auth_asym_id','label_entity_id','label_seq_id','label_comp_id','label_atom_id','label_alt_id','occupancy','Cartn_x','Cartn_y','Cartn_z']
 values={name:list(block.find_values('_atom_site.'+name))for name in names}
 if not values['auth_asym_id']or len({len(v)for v in values.values()})!=1:raise ValueError('Complete atom-site mapping required')
 seqs={e['proteinChain']['auth_asym_id'][0]:e['proteinChain']['sequence']for e in native_json['sequences']}
 # Native get_sequences iterates _entity_poly_seq rows; source label_seq_id
 # may start late or skip numbers in these already-extracted released CIFs.
 # Use the exact entity-table row ordinal, never assume label_seq_id - 1.
 poly={name:list(block.find_values('_entity_poly_seq.'+name))for name in ['entity_id','num','mon_id']}
 if not poly['num']or len({len(v)for v in poly.values()})!=1:raise ValueError('Exact native polymer table required')
 entity_ordinals={}
 for entity,num in zip(poly['entity_id'],poly['num']):
  mapping=entity_ordinals.setdefault(entity,{})
  if num not in mapping:mapping[num]=len(mapping)+1
 chain_entities={cid:{values['label_entity_id'][i]for i,c in enumerate(values['auth_asym_id'])if c==cid and values['label_seq_id'][i]not in ['.','?'] and values['label_entity_id'][i]in entity_ordinals}for cid in seqs}
 if any(len(entities)!=1 for entities in chain_entities.values()):raise ValueError('Each author chain must map to one source entity')
 for cid,entities in chain_entities.items():
  entity=next(iter(entities))
  if len(entity_ordinals.get(entity,{}))!=len(seqs[cid]):raise ValueError('Native sequence and full entity-table ordinal lengths differ')
 chosen={};observed=set()
 for i,cid in enumerate(values['auth_asym_id']):
  if cid not in seqs:continue
  label=values['label_seq_id'][i];atom=values['label_atom_id'][i];comp=values['label_comp_id'][i]
  if label in ['.','?']or atom not in BACKBONE:continue
  entity=values['label_entity_id'][i]
  if label not in entity_ordinals[entity]:raise ValueError('Atom residue absent from exact native polymer table')
  index=entity_ordinals[entity][label];sequence=seqs[cid]
  if not 1<=index<=len(sequence):raise ValueError('Coordinate index outside complete native sequence')
  if comp not in AA3 or sequence[index-1]!=AA3[comp]:raise ValueError('Coordinate/native sequence identity mismatch')
  observed.add((cid,index));point=[float(values[k][i])for k in ['Cartn_x','Cartn_y','Cartn_z']]
  if not all(math.isfinite(v)for v in point):raise ValueError('Nonfinite source coordinate')
  alt=values['label_alt_id'][i];occ=float(values['occupancy'][i]);rank=(occ,alt in ['.','?'],alt=='A',alt)
  key=(cid,index,atom)
  if key not in chosen or rank>chosen[key][0]:chosen[key]=(rank,point)
 result={}
 for(cid,index,atom),(_,point)in chosen.items():result.setdefault((cid,index),{})[atom]=point
 if any(not any(c==cid for c,_ in observed)for cid in seqs):raise ValueError('Every selected chain needs observed coordinates')
 return result

def prepare(output):
 import gemmi
 from abnumber import Chain
 from proteor1.cdr_eval import cdr_masking as native
 if sha(NATIVE)!='1d4d32f0866216c6a909fb160d014cf7a4f73bf003b69de1deb3eb86dc25b15b':raise ValueError('Exact native masking changed')
 if sha(Path(native.__file__))!=sha(NATIVE):raise ValueError('Imported native masking identity differs')
 scope_path=TASK/'independent_scope_metadata_v1/positive3_preparation_scope_review.json'
 peer_path=TASK/'independent_scope_metadata_v1/independent_positive_metadata_review_preparation_agent_20261021.json'
 scope=read(scope_path);peer=read(peer_path)
 if scope['positive_preparation_case_ids']!=IDS or peer['passed']is not True or peer['positive_preparation_case_ids']!=IDS:raise ValueError('Fixed independent positive3 required')
 roster={row['case_id']:row for row in read(TASK/'independent_scope_metadata_v1/released_demo_roster.json')['cases']}
 records=[];references=[];failures=[]
 for case_id in IDS:
  row=roster[case_id];record_id=row['released_record_id'];path=SOURCE/record_id/(record_id+'.cif');contract=row['original_chain_contract']
  try:
   ids=native.get_entry_chain_ids(contract['heavy_chain'],contract['light_chain']or None,contract['antigen_chains'])
   original=native.cif_to_protenix_json(path,sample_name=case_id,save_entity_and_asym_id=True,get_entity_seq_with_coords=False)
   filtered=native.filter_json_by_chains(original,ids,protein_only=True,case_insensitive=False)
   # Preserve native entity order and the covalent-bond remapping returned by its filter.
   roles={cid:'antigen'for cid in contract['antigen_chains']};roles[contract['heavy_chain']]='heavy'
   if contract['light_chain']:roles[contract['light_chain']]='light'
   regions={};numbering=[]
   for cid,role in roles.items():
    if role=='antigen':continue
    entity,sequence=native.find_entity_by_chain_id(filtered,cid,case_insensitive=False)
    if entity is None:raise ValueError('Exact required antibody chain absent')
    indices,info,start=native.get_cdr_indices_from_sequence(sequence,scheme='chothia',expected_chain_type='H'if role=='heavy'else'L')
    if indices is None:raise ValueError('Native Chothia numbering failed: '+str(info))
    numbered=Chain(sequence,scheme='chothia',use_anarcii=False)
    check_domain_identity(sequence,numbered,'H'if role=='heavy'else'L',start)
    regions[cid]={name:info[name]['indices']for name in ['cdr1','cdr2','cdr3']}
    if indices!=sorted(i for region in regions[cid].values()for i in region):raise ValueError('Native per-region indices disagree')
    numbering.append({'chain':cid,'role':role,'domain_start':start,'complete_sequence_length':len(sequence),'cdr_lengths':{name:len(indices)for name,indices in regions[cid].items()}})
   coords=coordinate_map(path,filtered,gemmi)
   packet,gold,target_coordinates=project(filtered,regions,coords,roles)
   # Native masking projection independently checks all target sequence identities are replaced.
   adapter=load('p41_masked_solver_adapter',TASK/'engineering_20261020/released_demo_adapter.py')
   masked=adapter.masked_solver_json(filtered,regions)
   if sum(e['proteinChain']['sequence'].count('X')for e in masked['sequences'])<len(gold):raise ValueError('Native masking agreement failed')
   solver={'case_id':case_id,'condition_id':CONDITION,'target_length':len(gold),'messages':messages(packet)}
   solver_path=output/'solver_inputs'/(case_id+'.json');save(solver_path,solver)
   references.append({'case_id':case_id,'target_sequence':gold,'target_length':len(gold),'target_segments':packet['target_segments'],
    'target_backbone_coordinates':target_coordinates,'full_unmasked_native_json':filtered,'source_coordinate_sha256':sha(path)})
   records.append({'case_id':case_id,'released_record_id':record_id,'solver_path':str(solver_path),'solver_sha256':sha(solver_path),'target_length':len(gold),
    'context_residue_count':len(packet['residues']),'complete_chain_lengths':{e['proteinChain']['auth_asym_id'][0]:len(e['proteinChain']['sequence'])for e in filtered['sequences']},
    'numbering':numbering,'source_coordinate_sha256':sha(path),'target_identities_coordinates_withheld':True,
    'missing_visible_backbone_atoms_retained_as_null':sum(v is None for r in packet['residues']if r[3]!='[MASK]'for v in r[4])})
  except Exception as error:failures.append({'case_id':case_id,'error_type':type(error).__name__,'reason':str(error)})
 target_path=output/'scorer_only/targets.json';save(target_path,{'role':'protected_reference_not_solver_input','condition':CONDITION,'cases':references})
 manifest={'at_pacific':now(),'task_id':'P41','condition_id':CONDITION,'fixed_positive_cohort':IDS,'released_demo_count':5,'planned':3,'prepared':len(records),'cases':records,'failures':failures,
  'source_revision':'ffaa787bce5f30e4cb41e2de5d0b0daab0059243','source_pins_sha256':{str(p):sha(p)for p in [NATIVE,scope_path,peer_path,Path(__file__)]},
  'scorer_only_reference_path':str(target_path),'scorer_only_reference_sha256':sha(target_path),'new_model_calls':0,'GPU_allocations':0,'benchmark_admitted':False,
  'material_differences':['Three independently metadata-reviewed ordinary complexes from the five released demos; neither full paper holdout nor a random sample.',
   'Released native Chothia all-CDR masks; case-sensitive author chain selection; complete released selected protein chains with no crop.',
   'Pinned Qwen reads losslessly compact visible backbone/sequence JSON, not Proteo-R1 learned structural tensors; missing source atoms explicitly remain null.',
   'Every target CDR identity and atom coordinate is withheld; target segments and native lengths are supplied.',
   'Positional all-CDR amino-acid recovery and macro aggregation are a separately declared adaptation; exact paper Loop-RMSD/IMP/evaluator/aggregation are unavailable.',
   'No binding, function, experimental-validation or contamination-free claim.']}
 save(output/'manifest.json',manifest)
 status={'at_pacific':now(),'task_id':'P41','stage':'positive3_reference_isolated_inputs_prepared'if len(records)==3 and not failures else'preparation_failures_preserved',
  'planned':3,'prepared':len(records),'failures':failures,'model_calls':0,'GPU_allocations':0,'benchmark_admitted':False,'manifest_sha256':sha(output/'manifest.json')}
 save(output/'status.json',status);return status

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'prepared');args=p.parse_args();print(json.dumps(prepare(args.output)))
