import copy,json,unittest
from types import SimpleNamespace
from prepare import project,messages,check_domain_identity

def fixture():
 native={'hidden_reference':'NEVER','sequences':[{'proteinChain':{'sequence':'ACDEFGHIKL','auth_asym_id':[cid],'count':1,'hidden':'NEVER'}}for cid in ['H','L','a']]}
 regions={cid:{'cdr1':[1],'cdr2':[3],'cdr3':[5]}for cid in ['H','L']}
 roles={'H':'heavy','L':'light','a':'antigen'}
 coords={(cid,i+1):{a:[float(i),1.125,2.25]for a in ['N','CA','C','O']}for cid in roles for i in range(10)}
 return native,regions,coords,roles

class Preparation(unittest.TestCase):
 def test_domain_role_and_prefix_offset(self):
  self.assertTrue(check_domain_identity('PPACDE',SimpleNamespace(seq='ACDE',chain_type='H'),'H',2))
  self.assertTrue(check_domain_identity('PPACDE',SimpleNamespace(seq='ACDE',chain_type='K'),'L',2))
 def test_domain_wrong_role_rejected(self):
  with self.assertRaises(ValueError):check_domain_identity('ACDE',SimpleNamespace(seq='ACDE',chain_type='K'),'H',0)
 def test_domain_duplicate_location_rejected(self):
  with self.assertRaises(ValueError):check_domain_identity('ACDEACDE',SimpleNamespace(seq='ACDE',chain_type='H'),'H',0)
 def test_domain_incorrect_offset_rejected(self):
  with self.assertRaises(ValueError):check_domain_identity('PPACDE',SimpleNamespace(seq='ACDE',chain_type='H'),'H',0)
 def test_complete_context_and_all_six_cdrs(self):
  original,regions,coords,roles=fixture();snapshot=copy.deepcopy(original)
  packet,gold,_=project(original,regions,coords,roles)
  self.assertEqual(original,snapshot);self.assertEqual(len(packet['residues']),30);self.assertEqual(len(packet['target_segments']),6)
  self.assertEqual(gold,'CEGCEG');self.assertEqual(sum(r[3]=='[MASK]'for r in packet['residues']),6)
  for row in packet['residues']:
   if row[3]=='[MASK]':self.assertIsNone(row[4])
  self.assertNotIn('NEVER',json.dumps(packet));self.assertNotIn('target_sequence',json.dumps(packet))
 def test_case_sensitive_antigen(self):
  data=list(fixture());data[3]['A']=data[3].pop('a')
  with self.assertRaises(ValueError):project(*data)
 def test_exact_coordinate_representation(self):
  packet,_,_=project(*fixture());visible=next(r for r in packet['residues']if r[3]!='[MASK]')
  self.assertEqual(visible[4][0],[0,1125,2250])
 def test_source_missing_atoms_stay_null(self):
  data=list(fixture());data[2][('H',1)]={}
  packet,_,_=project(*data);self.assertEqual(packet['residues'][0][4],[None]*4)
 def test_extra_coordinate_fields_rejected(self):
  data=list(fixture());data[2][('H',1)]['CB']=[1,2,3]
  with self.assertRaises(ValueError):project(*data)
 def test_overlap_rejected(self):
  data=list(fixture());data[1]['H']['cdr2']=[1]
  with self.assertRaises(ValueError):project(*data)
 def test_noncannonical_target_rejected(self):
  data=list(fixture());data[0]['sequences'][0]['proteinChain']['sequence']='AXDEFGHIKL'
  with self.assertRaises(ValueError):project(*data)
 def test_unrepresentable_precision_rejected(self):
  data=list(fixture());data[2][('H',1)]['CA']=[0.12345,0,0]
  with self.assertRaises(ValueError):project(*data)
 def test_full_instruction_has_no_reference(self):
  packet,_,_=project(*fixture());msg=messages(packet)
  self.assertEqual(len(msg),1);self.assertIn('exactly 6 canonical',msg[0]['content']);self.assertNotIn('CEGCEG',msg[0]['content'])

if __name__=='__main__':unittest.main()
