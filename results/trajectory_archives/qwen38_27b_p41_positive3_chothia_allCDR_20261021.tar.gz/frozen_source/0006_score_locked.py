"""Once-only source-derived allmaskedresidue AAR, declared macro aggregation."""
from pathlib import Path
import argparse,ast,hashlib,json,statistics
import protocol

def source_total_aar(source,source_sha):
 if hashlib.sha256(source).hexdigest()!=source_sha:raise ValueError('Exact released scalar metric source changed')
 tree=ast.parse(source);functions=[n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='calculate_aar']
 if len(functions)!=1 or any(isinstance(n,(ast.Import,ast.ImportFrom,ast.With,ast.Try))for n in ast.walk(functions[0])):raise ValueError('Unexpected native pure metric source')
 namespace={};exec(compile(ast.fix_missing_locations(ast.Module(body=functions,type_ignores=[])),'pinned_native_totalAAR','exec'),namespace)
 def compute(predicted,target):
  if not target or len(predicted)!=len(target)or any(c not in protocol.ALPHABET for c in predicted+target):raise ValueError('Whole equal-length canonical output required')
  # Concatenating the ordered CDR target residues and setting all mask bits is
  # mathematically identical for the source total-AAR accumulation. H/L
  # segment summaries are intentionally unused (nanobody L is absent).
  return namespace['calculate_aar'](predicted,target,'1'*len(target))[1]
 return compute

def score(plan,plan_sha,phase,output):
 complete,lock,outcomes=protocol.verify_phase(plan,phase,plan_sha,'benchmark')
 if len(outcomes)!=3:raise ValueError('Entire fixed positive3 denominator required')
 result={'task_id':'P41','condition':protocol.CONDITION,'at_pacific':protocol.now(),'plan_sha256':plan_sha,'planned':3,
  'prediction_lock_sha256':protocol.sha(Path(phase)/'prediction_lock.json'),'primary_metric':'source_totalCDR_AAR','primary_metric_value':None,
  'secondary_metric':'declared_macro_source_totalCDR_AAR','secondary_metric_value':None,
  'native_full_holdout_equivalence':False,'reference_access_after_complete_raw_seal':False,'coordinate_metrics_available':False,
  'binding_or_function_assessed':False,'sole_scoring_attempt':True,'native_paper_aggregation_verified':False}
 if complete['all_delivered']is not True or complete['delivery_passed']!=3 or complete['attempted_confirmed']!=3:
  result.update(status='undefined_incomplete_delivery_full3_denominator_preserved',reason='Missing complete outputs leave all3 planned cases in the denominator; protected references were not opened.')
  protocol.write(output,result);return result
 protected=protocol.read_frozen(plan['references'],plan['frozen_files_sha256']);targets=protected['cases']
 if [r['case_id']for r in targets]!=plan['fixed_case_ids']:raise ValueError('Exact reference case order required')
 source=Path(plan['native_metric_source']);compute=source_total_aar(source.read_bytes(),plan['frozen_files_sha256'][str(source)])
 records=[];total_matches=0;total_length=0
 for outcome,target in zip(outcomes,targets):
  if outcome['case_id']!=target['case_id']or len(outcome['sequence'])!=target['target_length']:raise ValueError('Whole expected-length case output required')
  predicted=outcome['sequence'];truth=target['target_sequence'];value=compute(predicted,truth)
  correct=sum(a==b for a,b in zip(predicted,truth));total_matches+=correct;total_length+=len(truth)
  records.append({'case_id':target['case_id'],'target_length':len(truth),'correct_residues':correct,'source_totalCDR_AAR':value})
 result.update(status='source_totalCDR_AAR_scored_complete_positive3',primary_metric_value=total_matches/total_length,
  secondary_metric_value=statistics.mean(r['source_totalCDR_AAR']for r in records),
  reference_access_after_complete_raw_seal=True,source_per_case_metric='Released writer.py calculate_aar total_accuracy over all masked positions; source H/L summaries unused.',
  declared_aggregation='Equal-weight arithmetic mean over exactly all3 released positive demo cases; not verified as paper aggregation.',
  primary_aggregation='Released total masked-position hit fraction pooled across all3 complete outputs; no verified paper-level aggregation equivalence.',
  total_correct_residues=total_matches,total_target_residues=total_length,cases=records)
 protocol.write(output,result);return result

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--plan-sha256',required=True);p.add_argument('--phase',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 if protocol.sha(args.plan)!=args.plan_sha256:raise ValueError('Exact frozen plan required')
 plan=json.loads(args.plan.read_bytes());phase=args.phase.resolve()
 if phase!=Path(plan['runtime_root']).resolve()/'benchmark' or args.output.resolve()!=phase/'scores.json':raise ValueError('Exact one-time canonical benchmark scoring location required')
 attempt=json.loads((phase.parent/'scoring_attempt.json').read_bytes())
 if attempt.get('plan_sha256')!=args.plan_sha256 or attempt.get('sole_scoring_attempt')is not True or attempt.get('prediction_lock_sha256')!=protocol.sha(phase/'prediction_lock.json'):raise ValueError('Exact sole-scoring attempt must be frozen before reference access')
 score(plan,args.plan_sha256,phase,args.output)
