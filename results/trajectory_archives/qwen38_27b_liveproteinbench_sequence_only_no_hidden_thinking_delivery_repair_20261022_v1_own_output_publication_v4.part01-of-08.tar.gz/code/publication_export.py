"""Our derived answer/delivery export: no native text, wire objects or token arrays."""
import hashlib
import json
import math
import re

TASKS=frozenset(('EC_number','GO_biological_process','GO_cellular_component','GO_molecular_function',
    'active_site','catalytic_activity','cofactor','motif_position','pathway','ph','temperature','transmembrane'))
FILES=frozenset(('attempt.json','request.json','outcome.json','response.raw.json',
    'http_error.raw','http_error.partial','response.partial'))
FLAGS=('response_saved','transport_error','http_error','response_error','refusal','truncated','empty_final')
COUNTS=('responses_saved','transport_errors','http_errors','response_errors','refusals','truncations','empty_finals','parsed')
SOURCE='https://github.com/Rongdingyi/LiveProteinBench'
SOURCE_COMMIT='8b9710932511f816651fc1a7e8a1bc85c3c77767'
RUN_ID='qwen38_27b_liveproteinbench_sequence_only_no_hidden_thinking_delivery_repair_20261022_v1'
MODEL=dict(dtype='bfloat16',name='Qwen/Qwen3.8-27B',revision='1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0')
SCORER='LPB_EXPLICIT_FINAL_ANSWER_V2'
OMISSION='All free-form generated text, native input content and token arrays remain local; only extracted choices and derived metadata are exported.'


def digest(data):return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value,sort_keys=True,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()


def loads(data):
    def pairs(rows):
        result={}
        for key,value in rows:
            if key in result:raise ValueError('Duplicate key')
            result[key]=value
        return result
    return json.loads(data,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('Nonfinite number')))


def count(value,maximum=1736):
    if type(value)is not int or not 0<=value<=maximum:raise ValueError('Bounded integer count required')
    return value


def completion_metadata(completion,captured_sha):
    result=dict(role='derived_public_delivery_summary',planned=1736,attempted_confirmed=1736,terminal=1736,
        not_dispatched=0)
    if captured_sha is not None:
        if not re.fullmatch('[0-9a-f]{64}',captured_sha):raise ValueError('Opaque original hash required')
        result['native_completion_sha256']=captured_sha
    for name in COUNTS:result[name]=count(completion[name])
    return result


def public_scores(scores,*,run_id,model,scorer,native_score_sha):
    if (run_id!=RUN_ID or model!=MODEL or scorer!=SCORER
            or not re.fullmatch('[0-9a-f]{64}',str(native_score_sha))):
        raise ValueError('Exact own model/run/scorer and opaque source hash required')
    if set(scores['per_task'])!=TASKS:raise ValueError('Exact task identities required')
    grouped={}
    for task,row in scores['per_task'].items():
        if set(row)!={'planned','correct','parsed','invalid','accuracy'}:raise ValueError('Aggregate fields only')
        clean={name:count(row[name]) for name in ('planned','correct','parsed','invalid')}
        accuracy=row['accuracy']
        if (clean['planned']==0 or type(accuracy)not in(int,float) or not math.isfinite(accuracy)
                or not math.isclose(accuracy,clean['correct']/clean['planned'],abs_tol=1e-12,rel_tol=0)):
            raise ValueError('Exact finite aggregate accuracy required')
        clean['accuracy']=accuracy;grouped[task]=clean
    if sum(row['planned'] for row in grouped.values())!=1736:raise ValueError('Full denominator required')
    for name,expected in [('micro_accuracy',sum(r['correct']for r in grouped.values())/1736),
            ('macro_task_accuracy',sum(r['accuracy']for r in grouped.values())/12)]:
        value=scores[name]
        if type(value)not in(int,float)or not math.isfinite(value)or not math.isclose(value,expected,abs_tol=1e-12,rel_tol=0):
            raise ValueError('Exact aggregate score required')
    return dict(role='derived_public_native_score_summary',benchmark='LiveProteinBench',run_id=run_id,model=model,
        scorer=scorer,planned=1736,source_case_count=1797,unadmitted_cases=61,full_source_benchmark_complete=False,
        metric='four_choice_accuracy',micro_accuracy=scores['micro_accuracy'],macro_task_accuracy=scores['macro_task_accuracy'],
        per_task=grouped,native_score_sha256=native_score_sha,reference_answers_or_per_case_correctness_included=False)


def export_records(native,case_ids,identities,scores,completion,*,source_commit,run_id,model,scorer):
    if len(case_ids)!=1736 or len(set(case_ids))!=1736 or set(identities)!=set(case_ids):
        raise ValueError('Exact admitted source order required')
    if source_commit!=SOURCE_COMMIT:raise ValueError('Pinned official source commit required')
    exported={};records=[]
    for case_id in case_ids:
        task=identities[case_id]
        if not re.fullmatch('[A-Za-z0-9_-]+',case_id)or task not in TASKS:raise ValueError('Admitted source IDs only')
        prefix='cases/'+case_id+'/'
        files={name[len(prefix):]:body for name,body in native.items() if name.startswith(prefix)}
        if not {'attempt.json','request.json','outcome.json'}<=set(files)or not set(files)<=FILES:
            raise ValueError('Exact original local file inventory required')
        outcome=loads(files['outcome.json'])
        if outcome.get('case_id')!=case_id or outcome.get('task_id')!=task or outcome.get('attempted')is not True:
            raise ValueError('Own outcome identity differs')
        flags={name:outcome[name] for name in FLAGS}
        if any(type(value)is not bool for value in flags.values()):raise ValueError('Boolean categories only')
        choice=outcome.get('parsed_answer')
        if choice not in(None,'A','B','C','D'):raise ValueError('Extracted model choice only')
        # Preserve this original27B condition's scoring rule: a length finish
        # may receive credit if its final choice parsed. It is not the4B rule.
        if any(flags[name]for name in ('transport_error','http_error','response_error','refusal')):choice=None
        reason=outcome.get('finish_reason')
        if reason not in(None,'stop','length'):raise ValueError('Known own finish-reason enum required')
        hashes={name:digest(body)for name,body in files.items()}
        public=dict(case_id=case_id,task_id=task,attempted=True,extracted_choice=choice,delivery=flags,
            finish_reason=reason,content_omitted=True,omission_reason=OMISSION,local_artifact_sha256=hashes,
            official_source=SOURCE+'/tree/'+source_commit+'/dataset/QA',
            reference_answer_or_correctness_exported=False)
        body=json_bytes(public);exported[prefix+'delivery.json']=body
        records.append(dict(case_id=case_id,task_id=task,public_delivery_sha256=digest(body),local_artifact_sha256=hashes))
    exported['scores.json']=json_bytes(public_scores(scores,run_id=run_id,model=model,scorer=scorer,native_score_sha=digest(native['scores.json'])))
    exported['completion.json']=json_bytes(completion_metadata(completion,digest(native['completion.json'])))
    exported['prediction_lock.json']=json_bytes(dict(role='derived_public_source_hash_index_not_native_prediction_lock',
        benchmark='LiveProteinBench',run_id=run_id,planned=1736,source_case_count=1797,unadmitted_cases=61,
        native_prediction_lock_sha256=digest(native['prediction_lock.json']),records=records,
        native_input_or_generated_text_included=False,token_arrays_included=False))
    return exported
