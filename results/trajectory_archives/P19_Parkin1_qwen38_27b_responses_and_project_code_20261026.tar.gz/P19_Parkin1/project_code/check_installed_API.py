"""Exact installed .32 CPU API/tokenizer/plugin gate, no weights or inference."""
from pathlib import Path
import argparse
import importlib.metadata as metadata
import json
import os

import admission
import runner
import worker


def check(plan,output,gate_plan_sha256=None):
    if os.environ.get("CUDA_VISIBLE_DEVICES") != "":
        raise PermissionError("CPU_only_API_tokenizer_gate_required")
    expected={"vllm":"0.32.0","torch":"2.13.0","transformers":"5.17.0","triton":"3.7.1","flashinfer-python":"0.7.0.post1","xgrammar":"0.2.8"}
    packages={name:metadata.version(name) for name in expected}
    if packages!=expected:raise PermissionError("exact_pinned_runtime_versions_required")
    from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest
    from vllm.v1.sample.logits_processor import AdapterLogitsProcessor
    import p19_unique40_logits
    if not issubclass(p19_unique40_logits.P19Unique40LogitsProcessor,AdapterLogitsProcessor):
        raise PermissionError("actual_installed_unique40V4_plugin_ABI_required")
    counts={};checks=[]
    for phase,count in (("development",3),("benchmark",1)):
        config,cases,contexts=runner.load_contract(Path(plan[phase+"_config"]))
        if len(cases)!=count:raise PermissionError("exact_phase_denominator_required")
        counts[phase]=runner.count_tokens(config,cases,plan["model_directory"],65536)
        for case in cases:
            request=runner.payload(case,contexts,config)
            parsed=ChatCompletionRequest.model_validate(request)
            if (parsed.structured_outputs is None or
                    request["messages"]!=case["messages"] or
                    request["vllm_xargs"]["p19_unique40_condition"]!=runner.DECODER_CONDITION or
                    not all(isinstance(value,str) for value in request["vllm_xargs"].values())):
                raise PermissionError("actual_structured_request_mapping_changed")
            checks.append(dict(case_id=case["case_id"],request_sha256=runner.canonical_sha256(request),complete_native_messages_preserved=True))
    old=Path(__file__).resolve().parent.parent/"human_enzyme2_execution_v1"
    for name in ("unique40_core.py","p19_unique40_logits.py","request_contract.py","bound_request.py"):
        if worker.sha(Path(__file__).resolve().parent/name)!=worker.sha(old/name):
            raise PermissionError("accepted_output_control_changed")
    worker.save(output,dict(role="actual_installed_CPU_API_tokenizer_plugin_and_source_isolation_not_model_delivery",passed=True,packages=packages,native_T1_scorer_dependencies="Pinned official native scorer uses stdlib+router only; unused numpy/pandas/scipy readiness requirements removed",gate_plan_sha256=gate_plan_sha256,phase_config_sha256={phase:worker.sha(plan[phase+"_config"]) for phase in ("development","benchmark")},phase_counts=counts,request_checks=checks,native_cases_checked=1,artificial_cases_checked=3,model_weights_loaded=False,model_forwards=0,model_calls=0,protected_target_rows_opened=False,GPU_allocations=0))


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--plan",type=Path,required=True);parser.add_argument("--output",type=Path,required=True);args=parser.parse_args()
    try:check(admission.read(args.plan),args.output,worker.sha(args.plan))
    except Exception as error:
        print(json.dumps(dict(error_code="Parkin1_CPU_API_gate_failed",error_type=type(error).__name__,model_calls=0)));raise SystemExit(2)
