"""Separate TP1 P19 allocation: existing synthetic3 gate -> activity2 -> scorer.

Never submitted by preparation. A frozen root admission and Slurm allocation
are mandatory before runtime extraction or server startup. Original P19
generation/runner/scorer bytes remain unchanged.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request
from datetime import datetime
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
sys.path.insert(0, str(HERE))
import protocol
import admission
import resource_contract as resource
from durable import persist, sync_directory


def stamp(): return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def read(path): return json.loads(Path(path).read_text())


def sha(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file(): raise ValueError('Pinned ordinary file required')
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8*1024*1024), b''): value.update(chunk)
    return value.hexdigest()


def save(path, value, exclusive=True):
    path = Path(path);path.parent.mkdir(parents=True, exist_ok=True)
    if exclusive:
        with path.open('x') as stream:
            json.dump(value, stream, indent=2);stream.write('\n');persist(stream, path)
    else:
        temp = path.with_name(path.name+'.tmp')
        with temp.open('w') as stream:
            json.dump(value, stream, indent=2);stream.write('\n');persist(stream, temp)
        temp.chmod(0o600);temp.replace(path);sync_directory(path.parent)
    path.chmod(0o600)


def load_module(name, path, extra_path=None):
    if extra_path: sys.path.insert(0, str(extra_path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec);sys.modules[name] = module;spec.loader.exec_module(module)
    return module


def validate_plan(path, expected):
    if Path(path).resolve()!=HERE/'plan.json' or sha(path) != expected: raise ValueError('Exact frozen Parkin1 execution plan required')
    plan = read(path)
    admission.scientific_adoption()
    if (plan.get('root_scientific_adoption_sha256') != admission.ADOPTION_SHA or plan.get('independent_actual_input_review_sha256') != admission.ACTUAL_REVIEW_SHA or plan.get('independent_prospective_controls_review_sha256') != admission.PROSPECTIVE_REVIEW_SHA):raise PermissionError('exact_independent_source_and_controls_reviews_required')
    if (plan.get('task_id') != 'P19' or plan.get('scope') != protocol.SCOPE or plan.get('planned') != 1 or
            plan.get('synthetic_development_planned') != 3 or plan.get('gpus_requested') != 1 or
            plan.get('native_panel_assays') != 123 or plan.get('held_assays') != 12 or plan.get('not_reviewed_assays') != 64 or plan.get('prior_scored_assays') != 45 or plan.get('outside_current_scope_assays') != 1):
        raise ValueError('Only the exact separately adopted human Parkin1 subset is eligible')
    if plan.get('generation') != admission.scientific_adoption()['generation']:raise PermissionError('frozen_generation_must_equal_actual_root_adoption')
    if (plan['generation']['max_tokens'] != 16384 or plan['generation']['chat_template_kwargs'] != {'enable_thinking': False} or
            plan['endpoint'] != 'http://127.0.0.1:8419/v1' or Path(plan['runtime_root']).resolve() != HERE/'runtime'):
        raise ValueError('Uniform16K condition or dedicated runtime identity changed')
    if (plan.get('condition') != protocol.CONDITION or
            plan.get('mandatory_model_runner') != 'legacy_V1_explicit' or
            plan.get('custom_logits_processor') != 'p19_unique40_logits:P19Unique40LogitsProcessor'):
        raise ValueError('Exact mandatory V3 generation constraint is required')
    for name, expected_file in plan['frozen_files_sha256'].items():
        if sha(name) != expected_file: raise ValueError('Frozen P19/V06 runtime dependency changed: '+name)
    return plan


def helpers(plan):
    path = Path(plan['vetted_V06_worker'])
    return load_module('p19_vetted_V06_runtime_helpers', path, path.parent)


def resource_audit(plan, additional=0, require_own_job=False):
    if (additional, require_own_job) not in {(1,False),(0,True)}:
        raise ValueError('only_locked_preallocation_or_own_startup_audit_allowed')
    return resource.fresh_startup_audit(plan) if require_own_job else resource.audit(plan,startup=False)



def project_gpu_audit(plan):
    return resource_audit(plan, additional=0, require_own_job=True)


def check_root_admission(path, expected, plan_sha, plan, require_allocation=True):
    if plan.get('root_scientific_adoption_sha256') != admission.ADOPTION_SHA:
        raise PermissionError('exact_root_scientific_adoption_pin_required')
    return admission.validate_execution_grant(path,expected,HERE/'plan.json',plan_sha,require_job=require_allocation)



def require_no_prior_case_requests(plan):
    """Filename-only once-only audit; never read requests, responses or labels."""
    scope = read(HERE/'source_scope.json')
    selected = set(scope['approved_case_ids'])
    expected = {hashlib.sha256(case_id.encode()).hexdigest() + '.json' for case_id in selected}
    if len(selected) != 1:
        raise ValueError('Historical attempt check requires the exact one-case cohort')
    task_root = HERE.parent
    matches = []
    checked = []
    for request_dir in sorted(task_root.glob('**/runtime/**/requests')):
        if not request_dir.is_dir():
            continue
        checked.append(str(request_dir))
        matches.extend(str(request_dir/name) for name in expected if (request_dir/name).exists())
    if matches:
        raise ValueError('Prior or ambiguous request exists for proposed Parkin1 case: ' + ','.join(matches))
    return {'checked_request_directories': checked, 'case_count': 1,
            'matching_prior_request_files': [], 'request_response_or_label_bodies_opened': False}


def activate_private_runtime(shared, common, local, runtime, argv, executor=None):
    receipts = common.apply_overlay(local)
    save(runtime/'runtime_archive_receipt.json', {'local_prefix': str(local), **receipts})
    environment = shared.clean_environment(common, local)
    site = admission.load('Parkin1_site_tools',read(HERE/'plan.json')['site_tools_helper'])
    environment, tools = site.bind_site_tools(environment)
    ipc = local/'ipc';ipc.mkdir(mode=0o700)
    environment.update(VLLM_USE_V2_MODEL_RUNNER='0',PYTHONPATH=str(HERE),VLLM_RPC_BASE_PATH=str(ipc),TMPDIR=str(local))
    save(runtime/'site_tool_binding.json',tools)
    save(runtime/'private_runtime_identity.json',{'path':str(local),'job_id':os.environ['SLURM_JOB_ID'],'plan_sha256':sha(HERE/'plan.json'),'IPC_path':str(ipc)})
    shared.install_private_runtime(local/'python/bin/python3.12', environment, runtime)
    cpu = dict(environment);cpu['CUDA_VISIBLE_DEVICES']=''
    with (runtime/'installed_API_check.log').open('x') as log:
        subprocess.run([str(local/'python/bin/python3.12'),str(HERE/'check_installed_API.py'),'--plan',str(HERE/'plan.json'),'--output',str(runtime/'installed_API_check.json')],env=cpu,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
    command = [str(local/'python/bin/python3.12'), str(Path(__file__).resolve()), *argv, '--runtime-dir', str(local)]
    (executor or os.execve)(command[0], command, environment)



def verify_runtime_identity(shared, package_info, visible_gpus):
    shared.verify_package_identity(package_info)
    if visible_gpus != 1:
        raise ValueError('Exactly one Slurm-visible GPU required after the verified pinned install')
    return package_info


def phase_grant(plan, config, identity_path, admission_path, phase, dev_completion=None):
    if phase == 'benchmark' and dev_completion is None:
        raise ValueError('Actual sealed development completion required')
    root = Path(plan['runtime_root'])
    grant = {'authorized': True, 'task_id': 'P19', 'run_id': config['run_id'],
        'config_sha256': sha(plan[phase+'_config']), 'endpoint': plan['endpoint'],
        'server_identity_file': str(identity_path), 'server_identity_sha256': sha(identity_path),
        'root_admission_sha256': sha(admission_path), 'root_admission_file':str(admission_path), 'execution_plan_file':str(HERE/'plan.json'), 'execution_plan_sha256':sha(HERE/'plan.json'), 'phase': phase,
        'planned': config['planned'], 'one_attempt_per_case': True,
        'source_scope_sha256': plan['source_scope_sha256']}
    if phase == 'benchmark':
        if dev_completion is None: raise ValueError('Actual sealed development completion required')
        grant['development_completion_sha256'] = sha(dev_completion)
        grant['development_prediction_lock_sha256'] = read(dev_completion)['prediction_lock_sha256']
    target = root/(phase+'_runtime_grant.json');save(target, grant)
    return target


def execute_phases(plan, python, identity_path, admission_path):
    runtime = Path(plan['runtime_root'])
    dev_config, bench_config = read(plan['development_config']), read(plan['benchmark_config'])
    runner = load_module('p19_exact_existing_runner', plan['runner'], ROOT/'scripts')
    def phase(name, config, development=None):
        output = runtime/name
        if output.exists(): raise ValueError('A phase output already exists; no automatic resume or retry')
        if name == 'benchmark':
            runner.validate_development(config, development)
            save(runtime/'benchmark_once_only_preflight.json', require_no_prior_case_requests(plan))
        grant = phase_grant(plan, config, identity_path, admission_path, name, development)
        command = [python, plan['runner'], '--config', plan[name+'_config'], '--output', str(output),
            '--grant', str(grant), '--model-path', plan['model_directory'], '--context-limit', '65536',
            '--concurrency', '1', '--timeout', '1800']
        if development is not None: command += ['--development-completion', str(development)]
        save(runtime/'status.json', {'at_pacific': stamp(), 'stage': name+'_generation',
            'job_id': os.environ['SLURM_JOB_ID'], 'planned': config['planned'],
            'progress_path': str(output/'progress.json'), 'no_automatic_retry': True}, exclusive=False)
        subprocess.run(command, check=True)
        return read(output/'completion.json')
    def dev(): return phase('development', dev_config)
    def benchmark(done): return phase('benchmark', bench_config, runtime/'development/completion.json')
    def score(done):
        output = runtime/'benchmark/scores.json'
        save(runtime/'scoring_attempt.json', {'at_pacific': stamp(), 'sole_native_scoring_attempt': True,
            'benchmark_prediction_lock_sha256': done['prediction_lock_sha256'], 'planned_assays': 1,
            'native_panel_assays': 123, 'reference_access_after_prediction_seal_only': True})
        subprocess.run([python, plan['scorer'], '--run', str(runtime/'benchmark'),
            '--config', plan['benchmark_config'], '--references', plan['scorer_only_manifest'],
            '--output', str(output),'--plan',str(HERE/'plan.json'),'--plan-sha256',sha(HERE/'plan.json'),'--admission',str(admission_path),'--admission-sha256',sha(admission_path)], check=True)
        return read(output)
    return protocol.run_order(plan, dev, benchmark, score)


def owned_local(path, job):
    path=Path(path)
    if (path.is_symlink() or path != path.resolve() or path.parent != Path('/tmp') or
            not path.name.startswith('bio-p19-Parkin1-'+job+'-') or not path.is_dir() or
            path.stat().st_uid != os.getuid() or path.stat().st_mode & 0o077):
        raise PermissionError('exact_owned_private_direct_tmp_runtime_required')
    return path


def create_local_runtime(job):
    return owned_local(Path(tempfile.mkdtemp(prefix='bio-p19-Parkin1-'+job+'-',dir='/tmp')),job)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True);parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--admission', type=Path);parser.add_argument('--admission-sha256')
    parser.add_argument('--runtime-dir', type=Path);parser.add_argument('--check-only', action='store_true')
    os.umask(0o077)
    args = parser.parse_args();plan = validate_plan(args.plan, args.plan_sha256)
    if args.check_only:
        print(json.dumps({'task_id': 'P19', 'planned': 1, 'development': 3, 'uniform_output_tokens': 16384,
            'root_admission_required': True, 'GPU_allocations': 0, 'model_calls': 0}));return
    if args.admission is None or args.admission_sha256 is None: raise ValueError('Root admission arguments required')
    check_root_admission(args.admission, args.admission_sha256, args.plan_sha256, plan)
    runtime = Path(plan['runtime_root']);runtime.mkdir(mode=0o700,exist_ok=True)
    if runtime.is_symlink() or runtime.stat().st_mode & 0o077:raise PermissionError('private_runtime_directory_required')
    shared = helpers(plan);common = shared.common_module(plan)
    if args.runtime_dir is None:
        lock = (runtime/'allocation.lock').open('a');fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
        if (runtime/'allocation_started.json').exists(): raise ValueError('This allocation already started; no automatic resubmission')
        audit = project_gpu_audit(plan)
        own = [r for r in audit['jobs'] if r['job_id'] == os.environ['SLURM_JOB_ID']]
        if len(own) != 1 or own[0]['gpus'] != 1: raise ValueError('Actual own singleGPU Slurm accounting is missing')
        save(runtime/'gpu_budget_audit.json', audit)
        save(runtime/'allocation_started.json', {'at_pacific': stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
            'plan_sha256': args.plan_sha256, 'admission_sha256': args.admission_sha256})
        if shutil.disk_usage('/tmp').free < 32*1024**3: raise ValueError('Verified runtime needs at least32GiB local scratch')
        for name in ['base_runtime','cuda_overlay']:
            if sha(plan[name]['path']) != plan[name]['sha256']: raise ValueError('Vetted runtime archive changed')
        local = create_local_runtime(os.environ['SLURM_JOB_ID'])
        with tarfile.open(plan['base_runtime']['path']) as archive: archive.extractall(local, filter='data')
        activate_private_runtime(shared, common, local, runtime, sys.argv[1:])
    local = owned_local(args.runtime_dir,os.environ['SLURM_JOB_ID'])
    private = read(runtime/'private_runtime_identity.json')
    if private.get('path') != str(local) or private.get('job_id') != os.environ['SLURM_JOB_ID'] or private.get('plan_sha256') != args.plan_sha256:
        raise PermissionError('exact_first_stage_private_runtime_identity_required')
    lock = (runtime/'protocol.lock').open('a');fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
    if any((runtime/name).exists() for name in ['development','benchmark','terminal_receipt.json']):
        raise ValueError('Phase outputs already exist; no repeated calls')
    save(runtime/'gpu_budget_audit_at_server_start.json', project_gpu_audit(plan))
    import importlib.metadata as metadata
    import torch
    if not torch.cuda.is_bf16_supported():raise PermissionError('native_BF16_required')
    resource.compatible_GPU(torch.cuda.get_device_name(0),torch.cuda.get_device_capability(0),torch.cuda.get_device_properties(0).total_memory)
    installed = verify_runtime_identity(shared, {'packages': {name: metadata.version(name) for name in shared.PINNED_PACKAGES}}, torch.cuda.device_count())
    save(runtime/'post_exec_package_identity.json', installed)
    if os.environ.get('VLLM_USE_V2_MODEL_RUNNER') != '0' or os.environ.get('PYTHONPATH') != str(HERE):
        raise ValueError('Mandatory isolated V3 legacy runner/plugin environment differs')
    import p19_unique40_logits
    from vllm.v1.sample.logits_processor import AdapterLogitsProcessor
    if not issubclass(p19_unique40_logits.P19Unique40LogitsProcessor, AdapterLogitsProcessor):
        raise ValueError('Actual installed V1 plugin ABI is incompatible')
    save(runtime/'mandatory_plugin_import.json', {'at_pacific':stamp(),
        'model_runner':'legacy_V1_explicit','VLLM_USE_V2_MODEL_RUNNER':'0',
        'custom_logits_processor':plan['custom_logits_processor'],
        'plugin_sha256':sha(HERE/'p19_unique40_logits.py'),'actual_installed_vllm_import_succeeded':True,
        'source_inputs_or_target_rows_read_by_import':False})
    model_dir = common.validate_checkpoint(plan['model'], plan['model_revision'])
    if str(model_dir) != plan['model_directory']: raise ValueError('Pinned checkpoint directory changed')
    runner = load_module('p19_preflight_existing_runner', plan['runner'], ROOT/'scripts')
    for name in ['development','benchmark']:
        config, cases, _ = runner.load_contract(Path(plan[name+'_config']))
        result = runner.count_tokens(config, cases, model_dir, 65536)
        save(runtime/(name+'_tokenizer_preflight.json'), result)
    save(runtime/'environment.json', {'at_pacific': stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
        'hostname': socket.gethostname(), 'visibleGPUcount': 1, 'dtype': 'bfloat16', 'tensor_parallel_size': 1,
        'vllm': metadata.version('vllm'), 'torch': torch.__version__, 'transformers': metadata.version('transformers'),
        'model_directory': str(model_dir), 'checkpoint_audit_sha256': sha(plan['checkpoint_audit'])})
    with socket.socket() as probe: probe.bind(('127.0.0.1', 8419))
    python = str(local/'python/bin/python3.12')
    command = [python, '-m','vllm.entrypoints.cli.main','serve',str(model_dir),'--served-model-name',plan['model'],
        '--host','127.0.0.1','--port','8419','--dtype','bfloat16','--tensor-parallel-size','1',
        '--gpu-memory-utilization','0.95','--max-model-len','65536','--max-num-seqs','4',
        '--max-num-batched-tokens','8192','--reasoning-parser','qwen3','--enable-prefix-caching',
        '--limit-mm-per-prompt','{"image":0,"video":0}',
        '--logits-processors',plan['custom_logits_processor']]
    server = None
    try:
        save(runtime/'status.json', {'at_pacific': stamp(), 'stage': 'starting_independent_P19_server',
            'job_id': os.environ['SLURM_JOB_ID'], 'endpoint': plan['endpoint']}, exclusive=False)
        with (runtime/'server.log').open('x') as log:
            server = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True, cwd=local)
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}));deadline = time.monotonic()+1800
        while time.monotonic() < deadline:
            if server.poll() is not None: raise RuntimeError('Own P19 server exited before readiness')
            try:
                with opener.open('http://127.0.0.1:8419/health', timeout=3) as response:
                    if response.status == 200: break
            except (OSError, urllib.error.URLError): time.sleep(3)
        else: raise TimeoutError('Own P19 readiness timeout; no model retry')
        with opener.open(plan['endpoint']+'/models', timeout=5) as response: models = json.load(response)
        if [r['id'] for r in models['data']] != [plan['model']]: raise ValueError('Served model identity differs')
        identity = {'at_pacific': stamp(), 'task_id': 'P19', 'job_id': os.environ['SLURM_JOB_ID'],
            'hostname': socket.gethostname(), 'pid': server.pid, 'proc_start_ticks': common.start_ticks(server.pid),
            'model': plan['model'], 'revision': plan['model_revision'], 'dtype': 'bfloat16',
            'tensor_parallel_size': 1, 'dedicated_gpu_count': 1, 'endpoint': plan['endpoint'],
            'max_model_len': 65536, 'plan_sha256': args.plan_sha256,
            'admission_sha256': args.admission_sha256, 'server_command': command,
            'condition':plan['condition'],'model_runner':'legacy_V1_explicit',
            'custom_logits_processor':plan['custom_logits_processor'],
            'plugin_sha256':sha(HERE/'p19_unique40_logits.py'),
            'gpu_processes': common.own_gpu_processes(server.pid)}
        identity_path = runtime/'server_identity.json';save(identity_path, identity)
        result = execute_phases(plan, python, identity_path, args.admission)
        save(runtime/'terminal_receipt.json', {'at_pacific': stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
            'Parkin1_condition_terminal': True, 'full_native123_complete': False, 'full_catalog_complete': False,
            'development_completion_sha256': sha(runtime/'development/completion.json'),
            'benchmark_completion_sha256': sha(runtime/'benchmark/completion.json'),
            'prediction_lock_sha256': read(runtime/'benchmark/completion.json')['prediction_lock_sha256'],
            'native_score_sha256': sha(runtime/'benchmark/scores.json'),
            'native_scoring_status': result['score']['native_scoring_status']})
        save(runtime/'status.json', {'at_pacific': stamp(), 'stage': 'Parkin1_scoring_terminal',
            'native_scoring_status': result['score']['native_scoring_status'],
            'planned_assays': 1, 'native_panel_assays': 123, 'full_native_benchmark_complete': False}, exclusive=False)
    except Exception as error:
        save(runtime/'status.json', {'at_pacific': stamp(), 'stage': 'stopped_for_review',
            'error_type': type(error).__name__, 'no_automatic_retry': True,
            'missing_progress_is_not_zero_attempts': True}, exclusive=False)
        raise
    finally:
        if server is not None and server.poll() is None:
            os.killpg(server.pid, signal.SIGTERM)
            try: server.wait(timeout=60)
            except subprocess.TimeoutExpired: os.killpg(server.pid, signal.SIGKILL);server.wait(timeout=10)
        save(runtime/'server_terminal.json', {'at_pacific': stamp(), 'own_server_stopped': True,
            'other_project_runtimes_changed': False}, exclusive=False)


if __name__ == '__main__': main()
