"""Read-only shared-v5 accounting; scheduler mutations exist only in submit_once."""
from pathlib import Path
import contextlib
import fcntl
import os

import admission

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
SHARED_BINDING = ROOT / ".local/goal_restore_20261024/shared_resource_binding.json"
SHARED_SHA = "cb881370f7dac295d7d153f72baddcbf604c0fce0cc651ee82c557e5efcad6f9"
ADAPTER_SHA = "d7464059bdf95ab61fe0a2699cc4fb510252b9502aeb2c869d612f9d5d3d5f42"
LOCK = ROOT / ".local/evaluation_GPU_submission.lock"


@contextlib.contextmanager
def shared_lock():
    with LOCK.open("a") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        yield


def binding():
    admission.regular(SHARED_BINDING, SHARED_SHA)
    value = admission.read(SHARED_BINDING)
    if (value.get("approved") is not True or value.get("project_GPU_ceiling") != 8
            or value.get("role") != "shared_resource_configuration_only_no_dispatch_authority"
            or value.get("shared_submission_lock") != str(LOCK)
            or value.get("resource_adapter", {}).get("sha256") != ADAPTER_SHA
            or value.get("unknown_pending_and_running_jobs_remain_counted") is not True):
        raise PermissionError("exact_current_shared_resource_configuration_required")
    for record in [value["resource_adapter"], value["additional_proof_binding"], *value["additional_root_proofs"]]:
        admission.regular(record["path"], record["sha256"])
    return value


def audit(plan, *, startup=False, runner=None):
    value = binding()
    site = admission.load("Parkin1_site_tools", plan["site_tools_helper"])
    environment, _ = site.bind_site_tools(dict(os.environ))
    os.environ["PATH"] = environment["PATH"]
    module = admission.load("Parkin1_current_shared_v5", value["resource_adapter"]["path"])
    result = module.capacity_audit(additional=0 if startup else 1,
        require_own_job=startup, runner=runner,
        additional_root_proofs=value["additional_root_proofs"],
        additional_proof_binding=value["additional_proof_binding"])
    count = result.get("project_requested_GPUs")
    addition = 0 if startup else 1
    if (type(count) is not int or count < 0 or
            result.get("project_requested_GPUs_with_addition") != count + addition or
            result.get("capacity_available") is not (count + addition <= 8)):
        raise PermissionError("fresh_conservative_shared_GPU_accounting_inconsistent")
    if startup and not result["capacity_available"]:
        raise PermissionError("fresh_conservative_shared_GPU_capacity_unavailable")
    if startup:
        own = [row for row in result["jobs"] if row["job_id"] == os.environ.get("SLURM_JOB_ID")]
        if len(own) != 1 or own[0]["gpus"] != 1 or Path(own[0]["workdir"]).resolve() != ROOT or own[0]["command"].split()[0] != str(HERE / "worker.sbatch"):
            raise PermissionError("exact_own_single_GPU_worker_identity_required")
    return result


def fresh_startup_audit(plan):
    with shared_lock():
        return audit(plan, startup=True)


def compatible_GPU(name, capability, memory_bytes):
    # Frozen BF16/TP1 requires native BF16 and >=78GiB. No precision fallback.
    pair = tuple(capability)
    kind = "A100" if "A100" in name else "B200" if "B200" in name else None
    if kind is None or pair != ((8, 0) if kind == "A100" else (10, 0)) or memory_bytes < 78 * 1024 ** 3:
        raise PermissionError("only_compatible_A100_or_B200_BF16_single_GPU_allowed")
    return kind
