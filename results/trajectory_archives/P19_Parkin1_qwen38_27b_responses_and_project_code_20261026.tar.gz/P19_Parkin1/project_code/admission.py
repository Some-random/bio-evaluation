"""Exact Parkin scientific and independent runtime bindings; no calls on import."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import sys

import protocol

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
OWNER = "/root/pfarena_remaining_metadata"
CASE_ID = "P19::MAVEDB_urn_mavedb_00001274-a-1"
ADOPTION = HERE.parent / "parkin_native_condition_candidate_20261026_v1/root_scientific_adoption.json"
ADOPTION_SHA = "8a9e8ffd8e78e4dd8dd919496a335bb81bbf9c5d581cdcec06bd44642c2e9a3a"
ACTUAL_REVIEW_SHA = "69a22ac40738689266099a5fc01ac3c9305ad82998ecab87f356ebb41dd83927"
PROSPECTIVE_REVIEW_SHA = "cffcb09ce9954875d1e1b661dba48b356253d1cc85de263c9ae766d690e23b59"
PREDECESSOR = HERE.parent / "parkin1_execution_preparation_20261026_v1"
ZERO_REVIEW = PREDECESSOR / "startup_failure_252850/independent_positive_zero_dispatch_review.json"
ZERO_REVIEW_SHA = "cf362679d1b7beb5cd50653660a2d4130294748ab95a5aff8ba8d06a09d0718a"
IMPORT_DIAG = PREDECESSOR / "startup_failure_252850/CPU_import_name_result.json"
IMPORT_DIAG_SHA = "ee6ef48d234c0d4c75de20a7068911198ceb49ef24e968db2e13e821ff086338"


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def regular(path, expected):
    path = Path(path)
    if (not isinstance(expected, str) or len(expected) != 64 or
            path.is_symlink() or path != path.resolve() or
            not path.is_file() or sha(path) != expected):
        raise PermissionError("exact_pinned_regular_file_required")
    return path


def read(path):
    return json.loads(Path(path).read_text())


def load(name, path, extra=None):
    if extra is not None:
        sys.path.insert(0, str(extra))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def scientific_adoption():
    adopted = read(regular(ADOPTION, ADOPTION_SHA))
    if (adopted.get("issuer") != "/root" or
            adopted.get("scientific_scope_adopted") is not True or
            adopted.get("task_id") != "P19" or
            adopted.get("condition_id") != protocol.CONDITION or
            adopted.get("sole_owner") != OWNER or
            adopted.get("allowed_case_ids") != [CASE_ID] or
            adopted.get("planned") != 1 or
            adopted.get("native_panel_assays") != 123 or
            adopted.get("synthetic_development_planned") != 3 or
            adopted.get("selective_or_ambiguous_retry_authorized") is not False):
        raise PermissionError("exact_root_one_assay_scientific_adoption_required")
    for key in ("configuration_candidate", "prospective_handoff",
                "independent_actual_input_source_isolation_review", "input",
                "delivery_context", "source_objective",
                "known_registry_attempt_alias_review"):
        pin = adopted[key]
        regular(pin["path"], pin["sha256"])
    if adopted["independent_actual_input_source_isolation_review"]["sha256"] != ACTUAL_REVIEW_SHA:
        raise PermissionError("exact_actual_full_input_review_required")
    review = read(adopted["independent_actual_input_source_isolation_review"]["path"])
    if (review.get("input_review_approved") is not True or
            review.get("independent_actual_full_input_source_isolation_review_passed") is not True or
            review.get("allowed_case_ids") != [CASE_ID] or
            review.get("reviewer") == OWNER):
        raise PermissionError("independent_actual_input_review_does_not_admit_exact_case")
    proposal = read(adopted["configuration_candidate"]["path"])
    if (adopted.get("generation") != proposal.get("generation") or
            adopted.get("model") != proposal.get("model") or
            adopted.get("model_revision") != proposal.get("model_revision") or
            adopted.get("dtype") != "bfloat16"):
        raise PermissionError("root_science_differs_from_reviewed_prospective_recipe")
    return adopted


def predecessor_zero_and_diagnosis():
    zero=read(regular(ZERO_REVIEW,ZERO_REVIEW_SHA))
    diagnosis=read(regular(IMPORT_DIAG,IMPORT_DIAG_SHA))
    if (zero.get("original_native_and_artificial_model_attempts_remain_positively_unattempted") is not True or
            zero.get("review_result") != "PASS_positive_zero_server_model_and_scoring_dispatch" or
            diagnosis.get("modules",[])[-1] != {"module":"pandas","imported":False,"error_type":"ModuleNotFoundError","missing_module":"pandas"}):
        raise PermissionError("exact_positive_zero_predecessor_and_measured_unused_import_failure_required")


def validate_execution_grant(path, expected, plan_path, plan_sha, *, require_job=True):
    """No allocation/request/target access follows from scientific adoption alone."""
    scientific_adoption()
    predecessor_zero_and_diagnosis()
    plan = read(regular(plan_path, plan_sha))
    grant = read(regular(path, expected))
    protocol.validate_admission_data(grant, plan_sha, plan["source_scope_sha256"])
    reviewer = grant.get("reviewer", grant.get("issuer"))
    if (not isinstance(reviewer, str) or not reviewer.startswith("/root/") or
            reviewer == OWNER or reviewer.startswith(OWNER + "/") or
            grant.get("runtime_engineering_review_passed") is not True or
            grant.get("native_scoring_admitted") is not True or
            grant.get("allowed_case_ids") != [CASE_ID] or
            grant.get("root_scientific_adoption_sha256") != ADOPTION_SHA or
            grant.get("independent_actual_input_review_sha256") != ACTUAL_REVIEW_SHA or
            grant.get("independent_prospective_controls_review_sha256") != PROSPECTIVE_REVIEW_SHA or
            grant.get("predecessor_positive_zero_review_sha256") != ZERO_REVIEW_SHA or
            grant.get("measured_CPU_import_diagnosis_sha256") != IMPORT_DIAG_SHA or
            grant.get("unchanged_science_operational_repair_approved") is not True or
            grant.get("actual_repaired_complete_CPU_gate_sha256") != plan.get("actual_repaired_complete_CPU_gate",{}).get("sha256") or
            grant.get("automatic_or_selective_retries") is not False):
        raise PermissionError("independent_exact_runtime_and_sole_scoring_admission_required")
    gate_pin=plan.get("actual_repaired_complete_CPU_gate",{})
    gate=read(regular(gate_pin["path"],gate_pin["sha256"]))
    if (gate.get("passed") is not True or gate.get("native_cases_checked") != 1 or gate.get("artificial_cases_checked") != 3 or gate.get("model_calls") != 0 or
            gate.get("phase_config_sha256") != {phase:plan[phase+"_config_sha256"] for phase in ("development","benchmark")}):
        raise PermissionError("actual_complete_repaired_CPU_gate_must_bind_exact_native_and_artificial_configs")
    if require_job and not os.environ.get("SLURM_JOB_ID"):
        raise PermissionError("actual_owned_Slurm_allocation_required")
    return grant
