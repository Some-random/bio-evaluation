"""Seal the exact reviewed38 outcomes and executable source; no target export."""
from pathlib import Path
import hashlib,io,json,tarfile
import protocol

def package(plan,runtime,plan_sha):
    runtime=Path(runtime);complete,lock,outcomes=protocol.verify_phase(plan,runtime/'benchmark',plan_sha,'benchmark')
    dev,devlock,_=protocol.verify_phase(plan,runtime/'development',plan_sha,'development')
    if dev['exact_copy_gate_passed']is not True:raise ValueError('Actual artificial gate required')
    scores=json.loads((runtime/'benchmark/scores.json').read_bytes())
    if scores['plan_sha256']!=plan_sha or scores['planned']!=38 or scores['prediction_lock_sha256']!=protocol.sha(runtime/'benchmark/prediction_lock.json'):raise ValueError('Exact full38 score status required')
    result={'task_id':'P40','condition':protocol.CONDITION,'model':protocol.MODEL,'model_revision':plan['model_revision'],'planned':38,
        'primary_metric':scores['primary_metric'],'primary_metric_value':scores['primary_metric_value'],'generation':complete,
        'native_full60_or_historical_equivalence':False,'coordinate_metrics_available':False,'binding_or_function_assessed':False,
        'scientific_differences':plan['scientific_differences'],'plan_sha256':plan_sha,'native_source_revision':'a510ceef282cc24c8f658c14c2bfca10a95c23c0'}
    folder=runtime/'publication';folder.mkdir(exist_ok=False);protocol.write(folder/'result.json',result)
    metric='undefined (complete delivery was not achieved)'if scores['primary_metric_value']is None else format(scores['primary_metric_value'],'.6f')
    readme=('# RAbD: reviewed38 masked-backbone sequence recovery\n\n'
        'Qwen3.8-27B reconstructs CDRH3 sequences from current official SAbDab IMGT context. This is a separately declared backbone-text adaptation on38of the60released entries, not a trained MEAN or full historical-cohort replication.\n\n'
        '| Model | Cases delivered/planned | Native macro CDRH3 AAR |\n|---|---:|---:|\n| Qwen3.8-27B | '+str(complete['delivery_passed'])+'/38 | '+metric+' |\n\n'
        'Both artificial long-context exact-copy delivery checks passed before benchmark dispatch. Native AAR is the equal-weight mean of positional sequence recovery per case. Missing complete outputs retain the entire38-case denominator and make the primary metric undefined. No RMSD, TMscore, perplexity, binding or biological-function result is claimed.\n\n'
        'Material differences:\n\n'+''.join('- '+difference+'\n'for difference in plan['scientific_differences']))
    (folder/'README.md').write_text(readme)
    entries={}
    def add(name,path):
        if name.startswith('/')or'..'in Path(name).parts or'.local'in Path(name).parts or name in entries:raise ValueError('Safe unique public alias required')
        path=Path(path)
        if path.is_symlink():raise ValueError('No archive links')
        entries[name]=path.read_bytes()
    for phase,seal in [('development',devlock),('benchmark',lock)]:
        for name in seal['files_sha256']:add(phase+'/'+name,runtime/phase/name)
        for name in ['prediction_lock.json','completion.json']:add(phase+'/'+name,runtime/phase/name)
    for name in ['benchmark/scores.json','hardware_gate.json','server_identity.json','installed_identity.json','tokenizer_preflight.json']:
        add('runtime/'+name,runtime/name)
    for name in ['result.json','README.md']:add(name,folder/name)
    source_pins={}
    for index,name in enumerate(plan['public_code_paths']):
        path=Path(name)
        if protocol.sha(path)!=plan['frozen_files_sha256'][str(path)]:raise ValueError('Frozen public executable source changed')
        alias='frozen_source/'+str(index).zfill(4)+'_'+path.name
        add(alias,path);source_pins[alias]=plan['frozen_files_sha256'][str(path)]
    entries['source_manifest.json']=(json.dumps({'source_sha256':source_pins,'weights_environments_protected_targets_full_GPU_inventory_included':False},indent=2)+'\n').encode()
    entries['condition.json']=(json.dumps({key:plan[key]for key in ['task_id','condition','planned','model','model_revision','generation','scientific_differences']},indent=2)+'\n').encode()
    archive=folder/'P40_reviewed38_masked_backbone_all_outcomes.tar.gz'
    with tarfile.open(archive,'x:gz')as tar:
        for name,body in sorted(entries.items()):
            info=tarfile.TarInfo(name);info.size=len(body);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(body))
    manifest={'archive':str(archive),'sha256':protocol.sha(archive),'bytes':archive.stat().st_size,'files':{name:{'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}for name,body in entries.items()},
        'planned':38,'native_full60_or_historical_equivalence':False,'protected_target_sequences_or_unmasked_coordinates_included':False,
        'weights_or_environments_or_credentials_or_full_account_inventory_included':False,'new_model_calls':0}
    protocol.write(folder/'manifest.json',manifest);return manifest
