"""Exact independent technical grant and actual own-job resource guards."""
from pathlib import Path
import importlib.util,json,os
import protocol
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
OWNER='/root/new_2026_benchmarks'
POLICY=ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review.json'
POLICY_SHA='f70edf39692d5915f05bd4869b2290d9a7576bd5a89906c004aec137d7e29717'
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def validate(plan_path,plan_sha,grant_path=None,grant_sha=None,*,require_job=False):
 if protocol.sha(plan_path)!=plan_sha:raise ValueError('Exact frozen P40 plan required')
 p=json.loads(Path(plan_path).read_bytes())
 required={'task_id':'P40','condition':protocol.CONDITION,'model':protocol.MODEL,'planned':38,'development_planned':2,'gpus_requested':1,'native_full60_or_historical_equivalence':False,'coordinate_metrics_available':False,'binding_or_function_assessed':False,'new_training':False,'paid_model_calls':False,'automatic_retries':False}
 if any(p.get(k)!=v for k,v in required.items()):raise ValueError('Only the fixed current38 masked-backbone text/AAR condition is eligible')
 if (p.get('generation')!=protocol.GENERATION or p.get('endpoint')!='http://127.0.0.1:8440/v1'
     or p.get('model_revision')!='1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0'
     or Path(p['runtime_root']).resolve()!=HERE/'runtime'
     or len(p['fixed_case_ids'])!=38 or len(set(p['fixed_case_ids']))!=38):raise ValueError('Exact endpoint/model/generation/unique fixed38 contract required')
 for name,digest in p['frozen_files_sha256'].items():
  path=Path(name)
  if path.is_symlink()or protocol.sha(path)!=digest:raise ValueError('Frozen source/input/helper changed: '+path.name)
 scope=json.loads(Path(p['positive_scope_review']).read_bytes())
 if p['fixed_case_ids']!=scope['positive_preparation_case_ids']:raise ValueError('Independent source-positive condition changed')
 if grant_path is not None:
  if protocol.sha(grant_path)!=grant_sha:raise ValueError('Detached admission bytes changed')
  g=json.loads(Path(grant_path).read_bytes());reviewer=g.get('reviewer',g.get('issuer'))
  required_grant={'admitted':True,'task_id':'P40','plan_sha256':plan_sha,'condition':protocol.CONDITION,'planned':38,'gpu_count':1,'project_gpu_ceiling':8,'native_full60_or_historical_equivalence':False,'coordinate_metrics_available':False,'binding_or_function_assessed':False,'source_adaptation_accepted':True,'one_attempt_per_case':True,'new_training':False,'paid_model_calls':False}
  if any(g.get(k)!=v for k,v in required_grant.items()):raise ValueError('Exact independent technical/model/scope/resource admission required')
  if reviewer==OWNER:raise PermissionError('Owner may not self-approve')
  if reviewer!='root'and reviewer!='/root':
   if protocol.sha(POLICY)!=POLICY_SHA or g.get('delegation_sha256')!=POLICY_SHA:raise PermissionError('Bounded review delegation changed')
   policy=json.loads(POLICY.read_bytes())
   if reviewer not in policy['authorized_reviewers']or'P40'not in policy['authorized_task_ids']:raise PermissionError('Different authorized independent reviewer required')
  if protocol.sha(g['gpu_audit_receipt'])!=g['gpu_audit_receipt_sha256']:raise ValueError('Resource review receipt changed')
 elif require_job:raise PermissionError('Model/runtime work requires detached admission')
 if require_job and not os.environ.get('SLURM_JOB_ID'):raise PermissionError('Actual Slurm job required')
 return p

def current_project_audit(plan):
 site=load('p40_frozen_site_tools',plan['site_tools_helper']);env,tools=site.bind_site_tools(dict(os.environ));os.environ['PATH']=env['PATH']
 helper=load('p40_frozen_project_gpu_audit',plan['project_gpu_audit_helper']);audit=helper.conservative_project_gpu_audit(require_own_job=True)
 own=[r for r in audit['jobs']if r['job_id']==os.environ.get('SLURM_JOB_ID')]
 if len(own)!=1 or own[0]['gpus']!=1 or own[0]['command'].split()[0]!=str(HERE/'worker.sbatch')or Path(own[0]['workdir']).resolve()!=ROOT:raise PermissionError('Exact P40 own one-GPU allocation required')
 return audit
