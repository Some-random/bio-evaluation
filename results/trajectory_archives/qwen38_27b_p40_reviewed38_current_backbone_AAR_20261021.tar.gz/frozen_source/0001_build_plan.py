"""Freeze current38 source/inputs/native scalar scorer after real CPU checks."""
from pathlib import Path
import json,tarfile,unittest
import protocol
HERE=Path(__file__).resolve().parent;TASK=HERE.parent;ROOT=HERE.parents[4]

def build():
    if(HERE/'plan.json').exists():raise FileExistsError('Preserve frozen proposal')
    suite=unittest.defaultTestLoader.discover(str(HERE),pattern='test_*.py');result=unittest.TextTestRunner(verbosity=1).run(suite)
    if not result.wasSuccessful():raise ValueError('Artificial closure/native-metric checks failed')
    prepared=TASK/'current38_input_preparation_v1/prepared';manifest=json.loads((prepared/'manifest.json').read_bytes())
    if manifest['prepared']!=38 or manifest['failures']or manifest['planned']!=38:raise ValueError('All fixed38 reference-isolated inputs required')
    checked=json.loads((HERE/'CPU_tokenizer_validation.json').read_bytes())
    if checked['all_full_inputs_fit']is not True or len(checked['cases'])!=40 or max(row['prompt_tokens']for row in checked['cases'])+16384>65536:raise ValueError('Actual full40 CPU context/regex API checks required')
    native_source=prepared/'source/native_generate.py'
    source_archive=ROOT/'.local/source_recovery_round2_2026-10-19/structural/source_archives/THUNLP-MT__MEAN.tar.gz'
    license_path=HERE/'native_MEAN_LICENSE'
    with tarfile.open(source_archive)as tar:
        matches=[m for m in tar.getmembers()if Path(m.name).name in ['LICENSE','LICENSE.txt']and len(Path(m.name).parts)==2]
        if len(matches)!=1:raise ValueError('Exact native source license unavailable')
        if license_path.exists():raise FileExistsError('Preserve source license')
        license_path.write_bytes(tar.extractfile(matches[0]).read())
    validation={'at_pacific':protocol.now(),'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'model_forwards':0,'GPU_allocations':0,'actual_full40_tokenizer_API_receipt_sha256':protocol.sha(HERE/'CPU_tokenizer_validation.json'),
        'all38_reference_isolated_inputs_sha256':protocol.sha(prepared/'manifest.json'),'maximum_prompt_tokens':max(row['prompt_tokens']for row in checked['cases']),
        'CPU_package_vllm':checked['packages']['vllm'],'actual_allocated_vllm032_API_required_before_model_phases':True,
        'preparation_is_not_benchmark_score':True}
    protocol.write(HERE/'CPU_validation_receipt.json',validation)
    prior=json.loads((TASK.parent/'P27/independent_available_v1/execution_v1/plan.json').read_bytes())
    scope=TASK/'independent_scope_metadata_v1/positive38_preparation_scope_review.json'
    peer_scope=TASK/'independent_scope_metadata_v1/independent_positive_metadata_review_preparation_agent_20261021.json'
    plan={key:prior[key]for key in ['model_revision','model_directory','base_runtime','cuda_overlay','private_runtime_packages','runtime_common','checkpoint_audit','vetted_V06_worker','site_tools_helper','vetted_neutral_hardware_source','project_gpu_audit_helper']}
    plan.update({'at_pacific':protocol.now(),'role':'frozen_reviewed38_current_structure_text_proposal_not_runtime_or_dispatch','owner':'/root/new_2026_benchmarks','task_id':'P40',
        'condition':protocol.CONDITION,'model':protocol.MODEL,'generation':protocol.GENERATION,'planned':38,'development_planned':2,
        'fixed_case_ids':manifest['fixed_positive_cohort'],'cases':manifest['cases'],'references':manifest['scorer_only_reference_path'],
        'positive_scope_review':str(scope),'independent_positive_scope_review':str(peer_scope),'input_preparation_manifest':str(prepared/'manifest.json'),
        'development_inputs':str(HERE/'development_inputs.json'),'native_metric_source':str(native_source),'native_metric':'MEAN per-case CDRH3 AAR; macro average over fixed38',
        'runtime_tokenizer_preflight':str(HERE/'check_inputs_cpu.py'),'packager':str(HERE/'package.py'),'runtime_root':str(HERE/'runtime'),'endpoint':'http://127.0.0.1:8440/v1','context_limit':65536,
        'gpus_requested':1,'GPU_type':'A100_80GB','project_GPU_ceiling':8,'new_training':False,'paid_model_calls':False,'automatic_retries':False,
        'native_full60_or_historical_equivalence':False,'coordinate_metrics_available':False,'binding_or_function_assessed':False,
        'scientific_differences':manifest['material_differences']+['Current public benchmark pretraining exposure is unknown; no contamination-free or explanation-support claim.'],
        'CPU_API_version_preparation_qualification':{'observed':checked['packages']['vllm'],'required':'Actual isolated installedvLLM0.32 API/full rendered context recheck before all neural phases; CPU-only preparation is not engine or grammar execution.'}})
    local=sorted(HERE.glob('*.py'))+[HERE/'worker.sbatch',license_path]
    plan['public_code_paths']=[str(p)for p in [*local,native_source,TASK/'current38_input_preparation_v1/prepare.py',TASK/'current38_input_preparation_v1/test_preparation.py',TASK/'engineering_20261020/structural_adapter.py']]
    files=[*local,native_source,Path(plan['references']),HERE/'development_inputs.json',HERE/'CPU_validation_receipt.json',HERE/'CPU_tokenizer_validation.json',
        prepared/'manifest.json',scope,peer_scope,TASK/'current_structure_condition.json',TASK/'metadata/current_structure_index.json',
        TASK/'current38_input_preparation_v1/prepare.py',TASK/'current38_input_preparation_v1/test_preparation.py',TASK/'engineering_20261020/structural_adapter.py',
        *[Path(row['solver_path'])for row in manifest['cases']],*[Path(plan[key])for key in ['runtime_common','checkpoint_audit','vetted_V06_worker','site_tools_helper','vetted_neutral_hardware_source','project_gpu_audit_helper']],
        TASK.parent/'V06/local_execution_v2/v06_runner.py',
        *[ROOT/'.local/litqa2_replay'/name for name in ['runtime_archive.json','cuda_overlay_archive.json','cuda_overlay_deletions.json','publisher_verification.json']],
        ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review.json']
    plan['frozen_files_sha256']={str(p):protocol.sha(p)for p in sorted(set(files))}
    protocol.write(HERE/'plan.json',plan)
    print(json.dumps({'task_id':'P40','plan_sha256':protocol.sha(HERE/'plan.json'),'source_input_support_pins':len(plan['frozen_files_sha256']),'tests_run':result.testsRun,'model_calls':0,'GPU_allocations':0}))

if __name__=='__main__':build()
