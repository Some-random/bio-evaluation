"""All40 actual rendered messages and installed structured-regex API, CPU only."""
from pathlib import Path
import argparse,hashlib,importlib.metadata as metadata,json,os
import protocol
HERE=Path(__file__).resolve().parent

def check(plan,output):
    if os.environ.get('CUDA_VISIBLE_DEVICES')!='':raise ValueError('CPU-only validation requires hidden CUDA')
    from transformers import AutoTokenizer
    from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest
    from vllm.sampling_params import StructuredOutputsParams
    tokenizer=AutoTokenizer.from_pretrained(plan['model_directory'],local_files_only=True,trust_remote_code=False)
    records=[]
    for phase in ['development','benchmark']:
        for case in protocol.cases(plan,phase):
            body=protocol.payload(case);parsed=ChatCompletionRequest.model_validate(body)
            regex=protocol.output_regex(case['target_length'])
            if parsed.structured_outputs.regex!=regex or StructuredOutputsParams(regex=regex).regex!=regex:raise ValueError('Exact native HTTP regex not preserved')
            rendered=tokenizer.apply_chat_template(body['messages'],tokenize=False,add_generation_prompt=True,**body['chat_template_kwargs'])
            if body['messages'][0]['content']not in rendered:raise ValueError('Full structural input not preserved verbatim')
            encoded=tokenizer.apply_chat_template(body['messages'],tokenize=True,return_dict=True,truncation=False,add_generation_prompt=True,**body['chat_template_kwargs'])
            ids=encoded['input_ids'];ids=ids[0]if ids and isinstance(ids[0],list)else ids
            if len(ids)<10 or len(ids)+16384>65536:raise ValueError('Full structural input cannot fit untruncated')
            records.append({'phase':phase,'case_id':case['case_id'],'target_length':case['target_length'],'prompt_tokens':len(ids),'full_rendered_prompt_sha256':hashlib.sha256(rendered.encode()).hexdigest(),'native_HTTP_regex_preserved':True})
    result={'task_id':'P40','at_pacific':protocol.now(),'stage':'all40_actual_tokenizer_native_API_passed','all_full_inputs_fit':True,'references_read':False,'cases':records,
        'packages':{name:metadata.version(name)for name in ['vllm','transformers','torch']},'actual0_32_API_recheck_required_before_neural_phases':metadata.version('vllm')!='0.32.0','model_forwards':0,'GPU_allocations':0}
    protocol.write(output,result);return result
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    print(json.dumps(check(json.loads(args.plan.read_bytes()),args.output)))
