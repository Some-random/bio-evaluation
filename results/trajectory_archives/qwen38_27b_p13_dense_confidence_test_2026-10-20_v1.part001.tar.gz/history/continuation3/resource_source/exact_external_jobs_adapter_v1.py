"""Versioned read-only GPU accounting with exact root-reviewed external jobs.

The original helper, queue and running plans are unchanged. Exclusions require
every current scheduler identity and source/configuration byte check below.
Unknown, changed or unavailable identities remain counted. This module never
submits, cancels or changes any job and performs no inference.
"""
from datetime import datetime
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import stat
import subprocess
from zoneinfo import ZoneInfo

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
PROOF = ROOT / '.local/resource_accounting_20261022/root_external_web_filter_jobs_review.json'
PROOF_SHA256 = '9c7ea1d9327d2aceed5e8aceef2c97134e6002cfa88be632ecf008b7847bd4e0'
QUEUE = ROOT / '.local/qwen35_4b_comparison_20261022/queue/controller.py'
QUEUE_SHA256 = 'e0c371e8a0639c90436790e0f69eaca527ca2db2af3e587ac276fa4bce3aeafb'
HELPER = ROOT / 'scripts/project_gpu_audit_20261021.py'
HELPER_SHA256 = '9045eaf578e27dedcd5aba285b5a6253240244d70f52b7ad93e0dd7c0ecf9cc9'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def regular(path, digest):
    path = Path(path)
    return (path.is_absolute() and path == path.resolve() and not path.is_symlink() and
        stat.S_ISREG(path.stat().st_mode) and sha(path) == digest)

def field(raw, name):
    match = re.search(r'(?:^|\s)' + re.escape(name) + r'=([^\s]+)', raw)
    return match.group(1) if match else None

def load_module(name, path, digest):
    if not regular(path, digest): raise ValueError('Pinned regular source changed: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def root_proof():
    if not regular(PROOF, PROOF_SHA256): raise ValueError('Exact root resource proof unavailable or changed')
    proof = json.loads(PROOF.read_text())
    if (proof.get('issuer') != '/root' or proof.get('approved') is not True or
            proof.get('role') != 'resource_only_exact_external_job_classification_and_bounded_adapter_authority' or
            proof.get('evaluation_project_GPU_ceiling') != 8 or proof.get('unknown_jobs_remain_counted') is not True or
            proof.get('no_blanket_workdir_exclusion') is not True):
        raise ValueError('Root-authorized exact identity resource proof required')
    rows = proof['jobs']
    if len({r['job_id'] for r in rows}) != len(rows): raise ValueError('Duplicate root identities')
    for row in rows:
        if (row.get('belongs_to_bio_evaluation_project') is not False or row.get('gpus_requested') != 1 or
                type(row.get('worker_id')) is not int or not re.fullmatch('[0-9]+', row['job_id'])):
            raise ValueError('Invalid bounded root identity')
    return proof

def resolve_from(workdir, value):
    path = Path(value)
    return str((path if path.is_absolute() else Path(workdir) / path).resolve())

def exact_external_identity(row, raw, identity):
    """Return (verified, reason) from one fresh exact scheduler record."""
    try:
        if not regular(identity['command'], identity['command_sha256']): return False, 'command_bytes_or_type_changed'
        if not regular(identity['phase_config'], identity['phase_config_sha256']): return False, 'phase_config_bytes_or_type_changed'
        expected = {'JobId': identity['job_id'], 'JobName': identity['name'],
            'WorkDir': identity['workdir'], 'Command': identity['command']}
        if any(field(raw, name) != value for name, value in expected.items()): return False, 'scheduler_identity_mismatch'
        if (row['job_id'], row['name'], row['workdir'], row['command'], row['gpus']) != (
                identity['job_id'], identity['name'], identity['workdir'], identity['command'], 1):
            return False, 'inventory_and_fresh_scheduler_mismatch'
        if field(raw, 'UserId') != 'dongweij(' + str(identity['UID']) + ')': return False, 'owner_UID_mismatch'
        gpu = re.search(r'(?:^|,)gres/gpu=([0-9]+)(?:,|$)', field(raw, 'ReqTRES') or '')
        if gpu is None or int(gpu.group(1)) != 1 or field(raw, 'NumNodes') != '1': return False, 'one_GPU_request_not_verified'
        submit = re.search(r'(?:^|\s)SubmitLine=(.*?)\s+WorkDir=', raw)
        if submit is None: return False, 'exact_SubmitLine_unavailable'
        args = shlex.split(submit.group(1))
        if len(args) != 11 or args[:4] != ['sbatch', '--hold', '--parsable', '--job-name=' + identity['name']]:
            return False, 'unexpected_SubmitLine_shape_or_name'
        if resolve_from(identity['workdir'], args[4]) != identity['command']: return False, 'submitted_script_mismatch'
        if args[5] != '--phase-config' or resolve_from(identity['workdir'], args[6]) != identity['phase_config']:
            return False, 'submitted_phase_config_mismatch'
        if args[7:9] != ['--phase-config-sha256', identity['phase_config_sha256']]: return False, 'submitted_phase_config_digest_mismatch'
        if args[9:11] != ['--worker-id', str(identity['worker_id'])]: return False, 'submitted_worker_id_mismatch'
        if identity.get('allow_same_job_scheduler_requeue_under_identical_source_and_config') is not True:
            if field(raw, 'StartTime') != identity['original_observed_start']: return False, 'unapproved_requeue_or_start_change'
        return True, 'exact_root_UID_name_workdir_command_config_SubmitLine_worker_and_one_GPU_verified'
    except (OSError, ValueError, KeyError, TypeError):
        return False, 'identity_or_source_verification_unavailable'

def overlay_inventory(audit, proof, fresh_raw):
    result = copy.deepcopy(audit)
    by_id = {r['job_id']: r for r in proof['jobs']}
    verified = []
    observations = []
    for row in result['jobs']:
        identity = by_id.get(row['job_id'])
        if identity is None: continue
        raw = fresh_raw.get(row['job_id'])
        matched, reason = exact_external_identity(row, raw, identity) if isinstance(raw, str) else (False, 'fresh_scheduler_query_unavailable')
        observations.append({'job_id': row['job_id'], 'verified_unrelated': matched, 'reason': reason})
        if matched:
            row['counted_toward_evaluation_project'] = False
            row['scope_basis'] = 'exact_root_20261022_external_web_filter_identity_and_current_source_config_bytes'
            verified.append(row['job_id'])
    count = sum(row['gpus'] for row in result['jobs'] if row['counted_toward_evaluation_project'])
    addition = result['additional_GPUs']
    result.update(at_pacific=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        role='read_only_exact_root_external_job_GPU_accounting_not_dispatch',
        conservative_project_requested_GPUs_before_new_identity_review=audit['project_requested_GPUs'],
        project_requested_GPUs=count, project_requested_GPUs_with_addition=count + addition,
        project_GPU_ceiling=8, capacity_available=count + addition <= 8,
        all_account_requested_GPUs=sum(row['gpus'] for row in result['jobs']),
        verified_new_unrelated_job_ids=verified, exact_identity_observations=observations,
        root_resource_proof=str(PROOF), root_resource_proof_sha256=PROOF_SHA256,
        original_queue_sha256=QUEUE_SHA256, original_helper_sha256=HELPER_SHA256,
        unknown_jobs_remain_counted=True, scheduler_mutations=0, model_calls=0)
    return result

def capacity_audit(additional=1, override=False, runner=None, require_own_job=False):
    if type(additional) is not int or additional < 0 or additional > 8: raise ValueError('Invalid bounded GPU addition')
    if override is not False: raise ValueError('246310 override is not authorized by this adapter')
    runner = runner or subprocess.run
    proof = root_proof()
    queue = load_module('_exact_external_original_queue', QUEUE, QUEUE_SHA256)
    helper = load_module('_exact_external_original_helper', HELPER, HELPER_SHA256)
    audit = queue.capacity_audit(additional=additional, override=False, runner=runner)
    reviewed_ids = {row['job_id'] for row in proof['jobs']}
    fresh = {}
    for row in audit['jobs']:
        if row['job_id'] not in reviewed_ids: continue
        try:
            query = runner(['scontrol', 'show', 'job', '-o', row['job_id']],
                capture_output=True, text=True, check=True, timeout=30)
            fresh[row['job_id']] = query.stdout
        except (OSError, subprocess.SubprocessError): fresh[row['job_id']] = None
    result = overlay_inventory(audit, proof, fresh)
    if require_own_job:
        own = os.environ.get('SLURM_JOB_ID')
        if not own: raise ValueError('A real own Slurm allocation is required')
        verified = helper.evaluate_inventory(result['jobs'], own_job_id=own, additional_gpus=additional)
        result.update(own_job_id=verified['own_job_id'], own_allocation_verified=True)
    return result

if __name__ == '__main__': print(json.dumps(capacity_audit(additional=0), indent=2))
