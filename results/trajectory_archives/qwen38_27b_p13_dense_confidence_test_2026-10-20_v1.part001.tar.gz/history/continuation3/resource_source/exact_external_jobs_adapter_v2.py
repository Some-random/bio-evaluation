"""Additive, read-only root-reviewed classifier5 plus teacher1 accounting.

Version1 is preserved. The second root proof has a distinct two-GPU, exact
SubmitLine condition; it never inherits the classifier's worker/config flags.
"""
from datetime import datetime
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
from zoneinfo import ZoneInfo

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
V1_PATH = ROOT / '.local/resource_accounting_20261022/exact_external_jobs_adapter_v1.py'
V1_SHA256 = '867d663ff3117e18dfd3f22792e61abb7eb5f1aebd0d46e0e410cfee3f48c2f4'
TEACHER_PROOF = ROOT / '.local/resource_accounting_20261022/root_external_teacher_delivery_job_review.json'
TEACHER_PROOF_SHA256 = 'c48559825b686f427ac7334952fbd0137b061c72642574ce501bbbf65d67829d'

def load_v1():
    import hashlib
    if (V1_PATH != V1_PATH.resolve() or V1_PATH.is_symlink() or not V1_PATH.is_file() or
            hashlib.sha256(V1_PATH.read_bytes()).hexdigest() != V1_SHA256):
        raise ValueError('Preserved version1 source changed')
    spec = importlib.util.spec_from_file_location('_exact_external_jobs_v1_preserved', V1_PATH)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def teacher_proof(v1):
    if not v1.regular(TEACHER_PROOF, TEACHER_PROOF_SHA256): raise ValueError('Exact teacher root proof unavailable or changed')
    proof = json.loads(TEACHER_PROOF.read_text())
    if (proof.get('issuer') != '/root' or proof.get('approved') is not True or
            proof.get('role') != 'resource_only_exact_external_job_classification_and_bounded_adapter_authority' or
            proof.get('evaluation_project_GPU_ceiling') != 8 or proof.get('unknown_jobs_remain_counted') is not True or
            proof.get('no_blanket_workdir_exclusion') is not True or len(proof.get('jobs', [])) != 1):
        raise ValueError('Exact additive root teacher identity required')
    identity = proof['jobs'][0]
    if (identity.get('belongs_to_bio_evaluation_project') is not False or identity.get('gpus_requested') != 2 or
            'worker_id' in identity or identity.get('allow_same_job_scheduler_requeue_under_identical_source_and_config') is not False):
        raise ValueError('Teacher identity must keep its distinct two-GPU/nonrequeue schema')
    return proof

def exact_teacher_identity(row, raw, identity, v1):
    try:
        if not v1.regular(identity['command'], identity['command_sha256']): return False, 'teacher_command_changed'
        if not v1.regular(identity['phase_config'], identity['phase_config_sha256']): return False, 'teacher_config_changed'
        expected = {'JobId': identity['job_id'], 'JobName': identity['name'], 'Command': identity['command'],
            'WorkDir': identity['workdir'], 'UserId': 'dongweij(' + str(identity['UID']) + ')',
            'StartTime': identity['original_observed_start'], 'NumNodes': '1'}
        if any(v1.field(raw, key) != value for key, value in expected.items()): return False, 'teacher_scheduler_identity_or_start_mismatch'
        if (row['job_id'], row['name'], row['workdir'], row['command'], row['gpus']) != (
                identity['job_id'], identity['name'], identity['workdir'], identity['command'], 2):
            return False, 'teacher_inventory_identity_mismatch'
        match = re.search(r'(?:^|,)gres/gpu=([0-9]+)(?:,|$)', v1.field(raw, 'ReqTRES') or '')
        if match is None or int(match.group(1)) != 2: return False, 'teacher_two_GPU_request_mismatch'
        submit = re.search(r'(?:^|\s)SubmitLine=(.*?)\s+WorkDir=', raw)
        if submit is None or submit.group(1) != identity['exact_submitline']: return False, 'teacher_exact_SubmitLine_mismatch'
        source = Path(identity['command']).read_text()
        relative_config = str(Path(identity['phase_config']).relative_to(identity['workdir']))
        if identity['phase_config_sha256'] not in source or relative_config not in source:
            return False, 'teacher_script_does_not_bind_root_config_digest'
        return True, 'exact_root_teacher_UID_name_workdir_command_config_StartTime_SubmitLine_and_two_GPUs_verified'
    except (OSError, ValueError, KeyError, TypeError):
        return False, 'teacher_identity_or_source_verification_unavailable'

def capacity_audit(additional=1, override=False, runner=None, require_own_job=False):
    v1 = load_v1()
    if type(additional) is not int or not 0 <= additional <= 8: raise ValueError('Invalid GPU addition')
    if override is not False: raise ValueError('246310 remains conservatively counted')
    runner = runner or subprocess.run
    result = v1.capacity_audit(additional=additional, override=False, runner=runner, require_own_job=False)
    proof = teacher_proof(v1)
    identity = proof['jobs'][0]
    for row in result['jobs']:
        if row['job_id'] != identity['job_id']: continue
        try:
            raw = runner(['scontrol', 'show', 'job', '-o', row['job_id']],
                capture_output=True, text=True, check=True, timeout=30).stdout
            matched, reason = exact_teacher_identity(row, raw, identity, v1)
        except (OSError, subprocess.SubprocessError): matched, reason = False, 'fresh_teacher_scheduler_query_unavailable'
        result['exact_identity_observations'].append({'job_id': row['job_id'], 'verified_unrelated': matched, 'reason': reason})
        if matched:
            row['counted_toward_evaluation_project'] = False
            row['scope_basis'] = 'exact_additive_root_teacher_identity_current_source_config_and_StartTime'
            result['verified_new_unrelated_job_ids'].append(row['job_id'])
    count = sum(row['gpus'] for row in result['jobs'] if row['counted_toward_evaluation_project'])
    result.update(at_pacific=datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        project_requested_GPUs=count, project_requested_GPUs_with_addition=count + additional,
        capacity_available=count + additional <= 8, resource_adapter_version=2,
        additive_root_teacher_proof=str(TEACHER_PROOF), additive_root_teacher_proof_sha256=TEACHER_PROOF_SHA256)
    if require_own_job:
        own = os.environ.get('SLURM_JOB_ID')
        if not own: raise ValueError('Actual own Slurm job required')
        helper = v1.load_module('_exact_resource_own_helper', v1.HELPER, v1.HELPER_SHA256)
        verified = helper.evaluate_inventory(result['jobs'], own_job_id=own, additional_gpus=additional)
        result.update(own_job_id=verified['own_job_id'], own_allocation_verified=True)
    return result

if __name__ == '__main__': print(json.dumps(capacity_audit(additional=0), indent=2))
