"""Stable additive exact-root-proof interface for future operational bindings.

Preserves v1/v2. Additional records are explicitly supplied with their expected
hashes by a separately reviewed caller, never discovered by folder or job name.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
V2_PATH = ROOT / '.local/resource_accounting_20261022/exact_external_jobs_adapter_v2.py'
V2_SHA256 = 'f24859abc120e69000943a846c1332f9cea633c8869a153940614ed0107e9bac'

def additional_binding(specification, proofs, v1):
    if set(specification) != {'path', 'sha256'}:
        raise ValueError('Exact independent resource-proof binding path and digest required')
    path = Path(specification['path'])
    if not path.is_relative_to(ROOT) or not v1.regular(path, specification['sha256']):
        raise ValueError('Independent additional-proof binding changed')
    binding = json.loads(path.read_text())
    if (binding.get('issuer') not in ['/root', '/root/independent_review', '/root/new2026_bixbench'] or
            binding.get('approved') is not True or
            binding.get('role') != 'delegated_resource_only_additional_root_proof_binding' or
            binding.get('root_delegation_sha256') != v1.PROOF_SHA256 or
            binding.get('adapter_sha256') != v1.sha(Path(__file__).resolve()) or
            binding.get('additional_root_proofs') != list(proofs)):
        raise ValueError('Only the named root delegates may bind exact additional root proofs')
    return binding

def load_v2():
    if (V2_PATH != V2_PATH.resolve() or V2_PATH.is_symlink() or not V2_PATH.is_file() or
            hashlib.sha256(V2_PATH.read_bytes()).hexdigest() != V2_SHA256): raise ValueError('Preserved v2 source changed')
    spec = importlib.util.spec_from_file_location('_exact_external_jobs_v2_preserved', V2_PATH)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

def extra_proof(specification, v1):
    if set(specification) != {'path', 'sha256'}: raise ValueError('Explicit proof path and digest required')
    path = Path(specification['path'])
    if not path.is_relative_to(ROOT) or not v1.regular(path, specification['sha256']): raise ValueError('Additional pinned root proof changed')
    proof = json.loads(path.read_text())
    if (proof.get('issuer') != '/root' or proof.get('approved') is not True or
            proof.get('role') != 'resource_only_exact_external_job_classification_and_bounded_adapter_authority' or
            proof.get('evaluation_project_GPU_ceiling') != 8 or proof.get('unknown_jobs_remain_counted') is not True or
            proof.get('no_blanket_workdir_exclusion') is not True or not proof.get('jobs')):
        raise ValueError('Additional proof is not a bounded root resource identity record')
    ids = [row.get('job_id') for row in proof['jobs']]
    if len(set(ids)) != len(ids): raise ValueError('Duplicate extra identities')
    for row in proof['jobs']:
        if (type(row.get('job_id')) is not str or not re.fullmatch('[0-9]+', row['job_id']) or
                row.get('belongs_to_bio_evaluation_project') is not False or
                type(row.get('gpus_requested')) is not int or not 1 <= row['gpus_requested'] <= 8 or
                type(row.get('exact_submitline')) is not str or not row['exact_submitline']):
            raise ValueError('Exact additional job identity and SubmitLine required')
    return proof

def exact_additional_identity(row, raw, identity, v1):
    try:
        for key, digest_key in [('command', 'command_sha256'), ('phase_config', 'phase_config_sha256')]:
            if not v1.regular(identity[key], identity[digest_key]): return False, 'extra_current_source_or_config_changed'
        expected = {'JobId': identity['job_id'], 'JobName': identity['name'], 'WorkDir': identity['workdir'],
            'Command': identity['command'], 'UserId': 'dongweij(' + str(identity['UID']) + ')', 'NumNodes': '1'}
        if any(v1.field(raw, key) != value for key, value in expected.items()): return False, 'extra_scheduler_identity_mismatch'
        if (row['job_id'], row['name'], row['workdir'], row['command'], row['gpus']) != (
                identity['job_id'], identity['name'], identity['workdir'], identity['command'], identity['gpus_requested']):
            return False, 'extra_inventory_identity_mismatch'
        gpu = re.search(r'(?:^|,)gres/gpu=([0-9]+)(?:,|$)', v1.field(raw, 'ReqTRES') or '')
        if gpu is None or int(gpu.group(1)) != identity['gpus_requested']: return False, 'extra_GPU_request_mismatch'
        submit = re.search(r'(?:^|\s)SubmitLine=(.*?)\s+WorkDir=', raw)
        if submit is None or submit.group(1) != identity['exact_submitline']: return False, 'extra_exact_SubmitLine_mismatch'
        if identity.get('allow_same_job_scheduler_requeue_under_identical_source_and_config') is not True:
            if v1.field(raw, 'StartTime') != identity['original_observed_start']: return False, 'extra_start_or_requeue_mismatch'
        source = Path(identity['command']).read_text()
        config = str(Path(identity['phase_config']).relative_to(identity['workdir']))
        bound_text = source + '\n' + submit.group(1)
        if config not in bound_text or identity['phase_config_sha256'] not in bound_text:
            return False, 'extra_source_or_SubmitLine_lacks_bound_configuration'
        return True, 'exact_additional_root_identity_SubmitLine_current_source_config_and_GPU_request_verified'
    except (OSError, ValueError, KeyError, TypeError): return False, 'extra_identity_verification_unavailable'

def capacity_audit(additional=1, override=False, runner=None, require_own_job=False, additional_root_proofs=(), additional_proof_binding=None):
    v2 = load_v2(); v1 = v2.load_v1(); runner = runner or subprocess.run
    if additional_root_proofs:
        if additional_proof_binding is None: raise ValueError('Additional proofs require an exact independent delegated binding')
        additional_binding(additional_proof_binding, additional_root_proofs, v1)
    elif additional_proof_binding is not None:
        raise ValueError('A binding without additional proofs is invalid')
    result = v2.capacity_audit(additional=additional, override=override, runner=runner, require_own_job=False)
    seen = {r['job_id'] for p in [v1.root_proof(), v2.teacher_proof(v1)] for r in p['jobs']}
    records = []
    for specification in additional_root_proofs:
        proof = extra_proof(specification, v1)
        records.append(dict(specification))
        for identity in proof['jobs']:
            if identity['job_id'] in seen: raise ValueError('Extra proof duplicates an already overlaid identity')
            seen.add(identity['job_id'])
            for row in result['jobs']:
                if row['job_id'] != identity['job_id']: continue
                try:
                    raw = runner(['scontrol', 'show', 'job', '-o', row['job_id']],
                        capture_output=True, text=True, check=True, timeout=30).stdout
                    matched, reason = exact_additional_identity(row, raw, identity, v1)
                except (OSError, subprocess.SubprocessError): matched, reason = False, 'fresh_extra_scheduler_query_unavailable'
                result['exact_identity_observations'].append({'job_id': row['job_id'], 'verified_unrelated': matched, 'reason': reason})
                if matched:
                    row['counted_toward_evaluation_project'] = False
                    row['scope_basis'] = 'additional_hash_bound_exact_root_identity_and_current_source_config'
                    result['verified_new_unrelated_job_ids'].append(row['job_id'])
    count = sum(row['gpus'] for row in result['jobs'] if row['counted_toward_evaluation_project'])
    result.update(project_requested_GPUs=count, project_requested_GPUs_with_addition=count + additional,
        capacity_available=count + additional <= 8, resource_adapter_version=3, additional_root_proofs=records,
        additional_proof_binding=additional_proof_binding)
    if require_own_job:
        own = os.environ.get('SLURM_JOB_ID')
        if not own: raise ValueError('Actual own Slurm allocation required')
        helper = v1.load_module('_exact_resource_v3_own_helper', v1.HELPER, v1.HELPER_SHA256)
        verified = helper.evaluate_inventory(result['jobs'], own_job_id=own, additional_gpus=additional)
        result.update(own_job_id=verified['own_job_id'], own_allocation_verified=True)
    return result

def conservative_project_gpu_audit(*, require_own_job=False, additional_gpus=0, additional_root_proofs=(), additional_proof_binding=None):
    return capacity_audit(additional=additional_gpus, override=False, require_own_job=require_own_job,
        additional_root_proofs=additional_root_proofs, additional_proof_binding=additional_proof_binding)
