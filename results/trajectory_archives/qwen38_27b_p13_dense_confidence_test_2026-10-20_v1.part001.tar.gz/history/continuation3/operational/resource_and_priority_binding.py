"""P13's exact reviewed resource API binding, shared by preallocation and startup.

The preserved adapter performs fresh exact-root-proof exclusions. This binding
preserves the original caller's exception-on-capacity-refusal contract. It never
modifies adapter modules, a scheduler, request permissions or inference settings.
"""
import hashlib,importlib.util,os,json
from pathlib import Path
ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
ADAPTER=ROOT/'.local/resource_accounting_20261022/exact_external_jobs_adapter_v4.py'
ADAPTER_SHA='843ab31b4a4c28169c0ae60188cafef67f1cf84f253881f80cbf742aee383664'
HERE=Path(__file__).resolve().parent
MANIFEST=HERE/'manifest.json'
PRIORITY=ROOT/'.local/priority_results_20261023/root_scope.json'
PRIORITY_SHA='50296e691e085aba9e0488d26f1e1dc7582b6ba1c3015584a64bf214b81004b8'
ISSUERS={'/root/independent_review','/root/new2026_bixbench'}
ADDITIONAL_ROOT_PROOFS=({'path':str(ROOT/'.local/resource_accounting_20261022/root_external_repaired_web_filter_job_review.json'),'sha256':'f70f981e4ea599293abbdd1ae6f1ce864718d3aa1643980ced0d4fb067bc153c'},)
ADDITIONAL_PROOF_BINDING={'path':str(ROOT/'.local/resource_accounting_20261022/additional_repaired_job_binding_v1.json'),'sha256':'8fd4aa6c7f75a5233874d04e35510950a6fbddba2e15e0fefe7e1b4a77bca170'}
def load_adapter():
 if ADAPTER.is_symlink() or ADAPTER.resolve()!=ADAPTER or not ADAPTER.is_file() or hashlib.sha256(ADAPTER.read_bytes()).hexdigest()!=ADAPTER_SHA:raise ValueError('Exact reviewed resource adapter changed')
 s=importlib.util.spec_from_file_location('P13_exact_resource_adapter_v3',ADAPTER);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def enforce(result,additional_gpus,require_own_job=False):
 if (type(additional_gpus) is not int or not 0<=additional_gpus<=8
     or result.get('project_GPU_ceiling')!=8
     or type(result.get('project_requested_GPUs')) is not int or result['project_requested_GPUs']<0
     or type(result.get('project_requested_GPUs_with_addition')) is not int
     or result['project_requested_GPUs_with_addition']!=result['project_requested_GPUs']+additional_gpus
     or type(result.get('capacity_available')) is not bool):raise ValueError('Resource capacity fields missing, unknown or inconsistent')
 if result['capacity_available'] is not True or result['project_requested_GPUs_with_addition']>8:raise ValueError('Evaluation project GPU requests exceed eight')
 if require_own_job and (not os.environ.get('SLURM_JOB_ID') or result.get('own_job_id')!=os.environ['SLURM_JOB_ID'] or result.get('own_allocation_verified') is not True):raise ValueError('Exact own oneGPU startup audit not verified')
 return result
def regular_read(path):
 path=Path(path)
 if path.is_symlink() or path.resolve()!=path or not path.is_file():raise PermissionError('Exact priority authority path absent or changed')
 return json.loads(path.read_text())
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def verify_priority_release():
 # This preparation manifest never grants execution. A later exact root release,
 # independent binding and separately recorded STOP retirement are mandatory.
 priority=regular_read(PRIORITY)
 if digest(PRIORITY)!=PRIORITY_SHA or not str(priority.get('other_evaluations','')).startswith('hold new submissions;'):
  raise PermissionError('Exact later Oct23 priority scope changed; new review required')
 manifest=regular_read(MANIFEST);manifest_sha=digest(MANIFEST)
 if (manifest.get('execution_authorized') is not False
     or manifest.get('role')!='held_P13_actual_early_drain_operational_rebind'
     or manifest.get('task_ids')!=['P13']
     or manifest.get('P13_config_sha256')!='d3915c12cb72599cd5c2a0737bfa3fd72c0705fe4819e688ebd5493adede80dc'
     or manifest.get('gpu_audit_helper')!=str(Path(__file__).resolve())
     or manifest.get('files_sha256',{}).get(str(Path(__file__).resolve()))!=digest(Path(__file__))):
  raise PermissionError('Not the exact preparation-only operational rebind')
 for stop,expected in manifest['held_stop_records_sha256'].items():
  p=Path(stop)
  if p.exists() or p.is_symlink():
   if p.is_symlink() or digest(p)!=expected:raise PermissionError('Held STOP identity changed')
   raise PermissionError('Current lower-priority STOP remains; execution is forbidden')
 admission=regular_read(manifest['engineering_admission'])
 if (admission.get('issuer') not in ISSUERS or admission.get('approved') is not True
     or admission.get('manifest_sha256')!=manifest_sha
     or admission.get('root_decision_sha256')!=manifest['root_decision_sha256']
     or admission.get('maximum_new_GPU_allocations')!=1
     or admission.get('conditional_on_current_priority_release') is not True):
  raise PermissionError('Exact conditional engineering admission absent or changed')
 release=regular_read(HERE/'priority_release.json');binding=regular_read(HERE/'priority_release_admission.json')
 if (release.get('issuer')!='/root' or release.get('approved') is not True
     or release.get('task_id')!='P13' or release.get('manifest_sha256')!=manifest_sha
     or release.get('priority_record_sha256')!=PRIORITY_SHA
     or release.get('release_new_P13_allocation') is not True
     or release.get('retired_stop_records_sha256')!=manifest['held_stop_records_sha256']
     or release.get('preserved_boundary')!={'planned':3416,'saved':2588,'terminal':2592,'ambiguous':4,'untouched':824}
     or binding.get('issuer') not in ISSUERS or binding.get('approved') is not True
     or binding.get('scope')!='P13_later_Oct23_priority_release_binding_only'
     or binding.get('manifest_sha256')!=manifest_sha
     or binding.get('priority_record_sha256')!=PRIORITY_SHA
     or binding.get('priority_release_sha256')!=digest(HERE/'priority_release.json')):
  raise PermissionError('No exact later root release/independent binding/STOP retirement')
 return {'root_priority_sha256':PRIORITY_SHA,'root_priority_release_sha256':digest(HERE/'priority_release.json'),
         'priority_release_binding_sha256':digest(HERE/'priority_release_admission.json')}
def conservative_project_gpu_audit(*,require_own_job=False,additional_gpus=0):
 priority_binding=verify_priority_release()
 result=load_adapter().conservative_project_gpu_audit(require_own_job=require_own_job,additional_gpus=additional_gpus,additional_root_proofs=ADDITIONAL_ROOT_PROOFS,additional_proof_binding=ADDITIONAL_PROOF_BINDING)
 result=enforce(result,additional_gpus,require_own_job)
 result.update(P13_priority_release_verified=True,**priority_binding)
 return result
