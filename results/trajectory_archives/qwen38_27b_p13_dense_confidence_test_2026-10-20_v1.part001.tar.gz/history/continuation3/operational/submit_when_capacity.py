"""Submit exactly one admitted P13 continuation when safe capacity exists."""
import argparse
import datetime
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import time
from zoneinfo import ZoneInfo

PACKET = Path(__file__).resolve().parent
# Shared original once-only claim prevents a second allocation through another packet.
HERE = PACKET.parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')


def load():
    spec = importlib.util.spec_from_file_location('p13_frozen_successor', PACKET / 'continue_p13.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def create(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    parent_fd = os.open(Path(path).parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(parent_fd)
    finally:
        os.close(parent_fd)


def comparison_priority_wait():
    """Read existing accepted tickets; never intake, edit, cancel or resubmit them."""
    queue = ROOT/'.local/qwen35_4b_comparison_20261022/queue'
    import hashlib
    waiting=[]
    with (queue/'intake.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_SH)
        for path in sorted((queue/'accepted').glob('*.json')):
            ticket=json.loads(path.read_text());request=ticket['request']
            digest=hashlib.sha256(json.dumps({k:v for k,v in request.items() if k!='admission'},sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
            if digest!=ticket['request_digest'] or path.name!=request['request_id']+'.json':
                raise ValueError('Existing admitted comparison ticket identity changed')
            state=json.loads((queue/'states'/path.name).read_text())
            if state.get('request_id')!=request['request_id']:
                raise ValueError('Existing comparison ticket state identity differs')
            if state.get('submission_attempts')==0 and state.get('stage') in {'accepted_not_submitted','accepted','waiting_gate','waiting_capacity'}:
                waiting.append(request['request_id'])
    return waiting


def submit_once(manifest_path, manifest_sha):
    c = load()
    m = c.validate_manifest(manifest_path, manifest_sha)
    c.validate_admission(m, manifest_sha)
    c.require_current_execution_release(m)
    try:
        predecessor = c.predecessor_terminal(m['original_job_id'])
    except ValueError as error:
        if 'has not finished:' not in str(error):
            raise
        return {'stage': 'waiting_for_predecessor_terminal', 'predecessor_job_id': m['original_job_id']}
    activation = c.validate_activation(m)
    try:
        c.assert_predecessor_locks_free(m)
    except BlockingIOError:
        return {'stage':'waiting_for_predecessor_pool_or_output_lock'}
    # Lock freedom is checked before requesting another GPU and again before model calls.
    output = Path(m['output_folder'])
    with (output / '.runner.lock').open('a') as runner_lock:
        try:
            fcntl.flock(runner_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return {'stage': 'waiting_for_predecessor_runner_lock'}
        if (output / 'completion.json').exists():
            return {'stage': 'terminal_without_new_allocation', 'completion_sha256': c.sha(output / 'completion.json')}
    with (ROOT / '.local/evaluation_GPU_submission.lock').open('a') as cap_lock:
        fcntl.flock(cap_lock, fcntl.LOCK_EX)
        if (HERE / 'submission_claim.json').exists():
            raise ValueError('Submission already claimed; never replay')
        spec = importlib.util.spec_from_file_location('p13_submission_GPU_audit', m['gpu_audit_helper'])
        audit = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(audit)
        try:
            observation = audit.conservative_project_gpu_audit(additional_gpus=1)
        except ValueError as error:
            if str(error) == 'Evaluation project GPU requests exceed eight':
                return {'stage': 'waiting_capacity', 'reason': str(error)}
            raise
        c.write(HERE / 'last_safe_gpu_audit.json', observation)
        priority = comparison_priority_wait()
        if priority:
            return {'stage':'waiting_existing_admitted_comparison_tickets','request_ids':priority}
        c.validate_activation(m)
        c.predecessor_terminal(m['original_job_id'])
        try:
            c.assert_predecessor_locks_free(m)
        except BlockingIOError:
            return {'stage':'waiting_for_predecessor_pool_or_output_lock'}
        # Revalidate every frozen support byte immediately before the single attempt.
        c.validate_manifest(manifest_path, manifest_sha)
        c.validate_admission(m, manifest_sha)
        command = ['sbatch', '--parsable', '--dependency=afterany:' + m['original_job_id'],
                   m['batch_script'], manifest_sha]
        c.require_current_execution_release(m)  # Final STOP/release check before the sole durable claim.
        create(HERE / 'submission_claim.json', {'at_pacific': c.stamp(), 'manifest_sha256': manifest_sha,
               'command': command, 'predecessor_state': predecessor,
               'GPU_audit_sha256': c.sha(HERE / 'last_safe_gpu_audit.json'), 'automatic_replay': False})
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=60)
        except Exception as error:
            create(HERE / 'submission_uncertain.json', {'at_pacific': c.stamp(), 'type': type(error).__name__,
                                                       'automatic_replay': False})
            raise
        stdout = result.stdout.strip()
        valid = result.returncode == 0 and re.fullmatch(r'[0-9]+(?:;[A-Za-z0-9_.-]+)?', stdout)
        receipt = {'at_pacific': c.stamp(), 'stage': 'submitted' if valid else 'failed_or_uncertain_no_retry',
                   'manifest_sha256': manifest_sha, 'returncode': result.returncode,
                   'job_id': stdout.split(';')[0] if valid else None,
                   'stdout': stdout, 'stderr': result.stderr, 'new_GPU_requests': 1,
                   'automatic_further_allocations': False, 'automatic_replay': False}
        create(HERE / 'submission_receipt.json', receipt)
        if not valid:
            raise RuntimeError('One submission attempt failed or uncertain; no replay')
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--once', action='store_true')
    args = parser.parse_args()
    c = load()
    with (HERE / 'capacity_waiter.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        while not any((HERE / name).exists() for name in ('STOP_SUBMISSION','STOP_SUBMISSION_PRIORITY_V5')) and not (PACKET / 'STOP_SUBMISSION').exists():
            try:
                state = submit_once(args.manifest, args.manifest_sha256)
                c.write(HERE / 'capacity_waiter_status.json', dict(state, at_pacific=c.stamp(), pid=os.getpid(),
                        new_inference_calls=0, count_source='fresh_locked_conservative_all_project_GPU_accounting'))
                if state['stage'] in {'submitted', 'terminal_without_new_allocation'} or args.once:
                    return
            except Exception as error:
                c.write(HERE / 'capacity_waiter_error.json', {'at_pacific': c.stamp(), 'pid': os.getpid(),
                        'type': type(error).__name__, 'error': str(error), 'automatic_replay': False})
                raise
            time.sleep(30)


if __name__ == '__main__':
    main()
