"""Invented successor metadata and directories; no real scheduler/runtime calls."""
from datetime import datetime
import importlib.util,json,os,tempfile,threading,unittest
from pathlib import Path
from unittest.mock import patch,Mock
HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('artificial_successor_late_drain',HERE/'late_drain_for_successor.py');d=importlib.util.module_from_spec(s);s.loader.exec_module(d)
class SuccessorLateDrainTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup);self.root=Path(self.t.name);self.runtime=self.root/'runtime';self.runtime.mkdir();self.output=self.root/'out';self.output.mkdir();self.authority=self.root/'authority.json';self.authority.write_text('{}');self.m={'root':str(self.root),'batch_script':str(self.root/'invented.sbatch'),'output_folder':str(self.output),'P13_config_sha256':'invented-config','runtime_root':str(self.runtime),'root_decision':str(self.authority),'predecessor_drain_helper':'invented'}
 def raw(self,**change):
  f={'JobId':'999999','UserId':'dongweij(26129)','JobName':'bio-P13-continue3','WorkDir':str(self.root),'Command':self.m['batch_script'],'TimeLimit':'3-00:00:00','Requeue':'0','Restarts':'0','JobState':'RUNNING','NodeList':'invented','StartTime':'2026-10-23T14:00:00','EndTime':'2026-10-26T14:00:00','ReqTRES':'cpu=10,gres/gpu=1','AllocTRES':'cpu=10,gres/gpu=1'};f.update(change);return ' '.join(k+'='+v for k,v in f.items())
 def boundary(self):
  with patch.object(d.socket,'gethostname',return_value='invented.example'):return d.job_fields(self.raw(),self.m,'999999')
 def test_exact_actual_job_derives_fixed72h_drain_boundary(self):
  b=self.boundary();self.assertEqual(b['job_end_pacific'],'2026-10-26T14:00:00-07:00');self.assertEqual(b['drain_before_end_seconds'],1800);self.assertEqual(b['minimum_end_margin_seconds'],960)
 def test_foreign_job_UID_source_resources_or_time_is_rejected(self):
  for k,v in [('JobId','247052'),('UserId','foreign(123)'),('JobName','foreign'),('WorkDir','/foreign'),('Command','/foreign'),('TimeLimit','1-00:00:00'),('NodeList','foreign'),('ReqTRES','gres/gpu=2'),('AllocTRES','gres/gpu=2'),('Requeue','1'),('Restarts','1'),('EndTime','2026-10-24T14:00:00')]:
   with self.subTest(k=k),patch.object(d.socket,'gethostname',return_value='invented.example'),self.assertRaises(ValueError):d.job_fields(self.raw(**{k:v}),self.m,'999999')
 def test_fresh_runtime_required_and_inflight_client_unmodified(self):
  b=self.boundary();now=datetime.fromisoformat('2026-10-26T13:30:00-07:00');identity={'job_id':'999999','hostname':'invented.example','pid':123};state={'job_id':'999999','hostname':'invented.example','server_pid':123,'active_clients':['P13_benchmark_continuation3'],'stage':'serving_task_queue','updated_at_pacific':now.isoformat()};(self.runtime/'server_identity.json').write_text(json.dumps(identity));path=self.runtime/'status.json';path.write_text(json.dumps(state));self.assertEqual(d.verify_runtime(self.m,b,now),identity)
  state['active_clients']=['foreign'];path.write_text(json.dumps(state))
  with self.assertRaises(ValueError):d.verify_runtime(self.m,b,now)
 def test_absent_scheduler_record_never_proves_terminal(self):
  with patch.object(d.subprocess,'run',return_value=Mock(returncode=1)),self.assertRaises(ValueError):d.observe(self.m,'999999')
 def test_full_generation_terminal_exits_without_permission_call(self):
  (self.output/'completion.json').write_text(json.dumps({'config_sha256':'invented-config','terminal':3416,'planned':3416}));fake=Mock();fake.drain_once.side_effect=AssertionError('must not drain')
  with patch.dict(os.environ,{'SLURM_JOB_ID':'999999'}),patch.object(d,'observe',return_value=self.boundary()):d.run(self.m,'invented','invented',threading.Event(),Mock(),Mock(),lambda*a:fake)
  fake.drain_once.assert_not_called();self.assertEqual(json.loads((self.runtime/'late_drain/status.json').read_text())['stage'],'full_generation_terminal_no_permission_change')
 def test_denied_parent_or_changed_source_never_drains(self):
  fake=Mock();fake.due.return_value=True
  with patch.dict(os.environ,{'SLURM_JOB_ID':'999999'}),patch.object(d,'observe',return_value=self.boundary()),patch.object(d,'datetime') as clock,patch.object(d,'verify_runtime') as runtime:
   clock.now.return_value=datetime.fromisoformat('2026-10-26T13:30:00-07:00');clock.fromisoformat.side_effect=datetime.fromisoformat
   d.run(self.m,'invented','invented',threading.Event(),Mock(side_effect=ValueError('invented changed source')),Mock(),lambda*a:fake)
  fake.drain_once.assert_not_called();runtime.assert_not_called()
 def test_one_derived_boundary_claim_blocks_restarted_timer(self):
  record=self.runtime/'late_drain';record.mkdir();(record/'boundary.json').write_text('invented prior claim');fake=Mock()
  with patch.dict(os.environ,{'SLURM_JOB_ID':'999999'}),patch.object(d,'observe',return_value=self.boundary()):d.run(self.m,'invented','invented',threading.Event(),Mock(),Mock(),lambda*a:fake)
  fake.drain_once.assert_not_called();self.assertEqual(json.loads((record/'status.json').read_text())['stage'],'guard_error_no_automatic_replay')
if __name__=='__main__':unittest.main()
