#!/usr/bin/env python3
"""One bounded P13-only operational successor; every scientific byte stays frozen."""
import argparse
from contextlib import ExitStack
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import socket
import stat
import subprocess
import sys
import threading
import time
from types import SimpleNamespace
from zoneinfo import ZoneInfo

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
BASE = ROOT / '.local/catalog_execution_2026-10-20'
SCOPE = ('P13',)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def stamp():
    return datetime.datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, data):
    p = Path(path)
    temp = p.with_suffix(p.suffix + '.tmp')
    temp.write_text(json.dumps(data, indent=2) + '\n')
    temp.replace(p)


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_manifest(path, digest):
    if sha(path) != digest:
        raise ValueError('Continuation manifest hash changed')
    m = read(path)
    if sha(__file__) != m['wrapper_sha256'] or tuple(m['task_ids']) != SCOPE:
        raise ValueError('Continuation wrapper or task scope changed')
    if m['original_job_id'] != '247052' or m['extra_simultaneous_gpus'] != 0:
        raise ValueError('Unexpected predecessor or GPU scope')
    for path, expected in m['files_sha256'].items():
        if sha(path) != expected:
            raise ValueError('Changed frozen continuation support: ' + path)
    decision = read(m['root_decision'])
    if (decision['task_id'] != 'P13' or decision['predecessor_job_id'] != '247052'
            or decision['max_walltime_hours'] != 72
            or decision['automatic_further_allocations'] is not False or decision.get('adopted') is not True or decision.get('issuer') != '/root'):
        raise ValueError('Bounded root decision differs')
    original = read(m['original_pool_plan'])
    successor = read(m['pool_plan'])
    expected = dict(original, queue_root=str(Path(m['runtime_root']) / 'queue'),
                    authorized_task_ids=list(SCOPE))
    if successor != expected:
        raise ValueError('Successor changes frozen model, runtime or serving parameters')
    entries = read(m['dispatch_plan'])['tasks']
    for e in entries:
        if e['task_id'] not in SCOPE:
            continue
        for pathkey, hashkey in [('runner', 'runner_sha256'), ('benchmark_config', 'benchmark_config_sha256'),
                                 ('development_config', 'development_config_sha256'), ('scorer', 'scorer_sha256')]:
            if sha(e[pathkey]) != e[hashkey]:
                raise ValueError('Frozen task changed: ' + e['task_id'])
    return m


def validate_admission(manifest, digest):
    grant = read(manifest['engineering_admission'])
    if (grant.get('approved') is not True or grant.get('manifest_sha256') != digest
            or grant.get('issuer') not in ['/root/independent_review', '/root/new2026_bixbench']
            or grant.get('task_ids') != ['P13']
            or grant.get('root_decision_sha256') != sha(manifest['root_decision'])
            or grant.get('maximum_new_GPU_allocations') != 1):
        raise ValueError('Exact independent plan-bound engineering admission required')


def predecessor_terminal(job_id):
    if job_id != '247052':
        raise ValueError('Only exact predecessor247052 is authorized')
    terminal = {'COMPLETED', 'TIMEOUT', 'CANCELLED', 'FAILED', 'NODE_FAIL',
                'PREEMPTED', 'BOOT_FAIL', 'OUT_OF_MEMORY', 'DEADLINE', 'REVOKED'}
    expected = {'JobId': job_id, 'UserId': 'dongweij(26129)', 'JobName': 'bio-P13-continue2',
                'StartTime': '2026-10-22T13:02:33', 'WorkDir': str(ROOT),
                'Command': str(BASE / 'continuation_v2/pool.sbatch'), 'TimeLimit': '1-00:00:00'}
    result = subprocess.run(['scontrol', 'show', 'job', '-o', job_id],
                            capture_output=True, text=True, timeout=30)
    if result.returncode == 0 and result.stdout.strip():
        fields = dict(x.split('=',1) for x in result.stdout.split() if '=' in x)
        if any(fields.get(k) != v for k,v in expected.items()):
            raise ValueError('Exact predecessor project/UID/start/command ownership differs')
        state = fields.get('JobState', '').split('+',1)[0]
        if state not in terminal:
            raise ValueError('Predecessor has not finished: ' + str(state))
        return state
    # Require actual unique exact owned accounting after live-cache expiry.
    result = subprocess.run(['sacct', '-n', '-P', '-X', '-j', job_id,
                             '--format=JobIDRaw,State,WorkDir%300,UID,User,Start,JobName%100,TimelimitRaw'],
                            capture_output=True, text=True, timeout=30)
    rows = [line.split('|') for line in result.stdout.splitlines() if line.strip()]
    exact = [row for row in rows if len(row) >= 8 and row[0] == job_id]
    if result.returncode or len(exact) != 1 or len(rows) != 1:
        raise ValueError('Cannot verify unique terminal predecessor accounting')
    row = exact[0]
    if row[2:8] != [str(ROOT), '26129', 'dongweij', '2026-10-22T13:02:33', 'bio-P13-continue2', '1440']:
        raise ValueError('Exact predecessor accounting UID/start/project differs')
    state = row[1].split()[0].rstrip('+')
    if state not in terminal:
        raise ValueError('Predecessor has not finished: ' + state)
    return state


def verify_prior_progress(m):
    """Required explicit old-condition identity/errors before allocation or restoration.

    Missing metadata remains unknown; it never proves zero attempts or errors.
    This reads metadata only, never biological references or model payloads.
    """
    output = Path(m['output_folder'])
    config_sha = m['P13_config_sha256']
    run = read(output/'run_manifest.json')
    progress = read(output/'progress.json')
    if (run.get('config_sha256') != config_sha
            or progress.get('config_sha256') != config_sha
            or progress.get('task_id') != 'P13' or progress.get('planned') != 3416
            or progress.get('run_id') != m['run_id']):
        raise ValueError('Prior P13 run/progress identity differs or is unknown')
    for key in ('transport_errors','http_errors','response_errors','refusals'):
        value = progress.get(key)
        if type(value) is not int or value < 0:
            raise ValueError('Prior P13 error/refusal metadata unknown: '+key)
        if value:
            raise ValueError('Prior P13 error/refusal requires review: '+key)
    return progress


def require_current_execution_release(m):
    guard = load_module(m['gpu_audit_helper'], 'P13_exact_current_priority_release')
    return guard.verify_priority_release()


def verify_rebound_predecessor(m):
    for pathkey,hashkey in [('predecessor_drain_manifest','predecessor_drain_manifest_sha256'),
                            ('predecessor_drain_receipt','predecessor_drain_receipt_sha256'),
                            ('predecessor_terminal_closure','predecessor_terminal_closure_sha256')]:
        if sha(m[pathkey]) != m[hashkey]:
            raise ValueError('Actual predecessor drain provenance changed: '+pathkey)
    operation=read(m['predecessor_drain_manifest']);receipt=read(m['predecessor_drain_receipt'])
    closure=read(m['predecessor_terminal_closure'])
    if (operation.get('job_id')!='247052' or operation.get('config_sha256')!=m['P13_config_sha256']
        or receipt.get('manifest_sha256')!=m['predecessor_drain_manifest_sha256']
        or receipt.get('active_calls_interrupted_by_this_operation') is not False
        or receipt.get('historical_files_changed') is not False
        or closure.get('job_id')!='247052' or closure.get('all_four_inflight_responses_settled_valid') is not True
        or closure.get('P13_successor_stopped') is not True or closure.get('new_P13_submission_present') is not False):
        raise ValueError('Actual early-drain predecessor identity/preservation closure differs')
    for key,expected in {'planned':3416,'saved_responses':2588,'terminal_outcomes':2592,
                         'request_claims':2592,'inherited_ambiguous_outcomes':4,'untouched_cases':824}.items():
        if type(closure.get(key)) is not int or closure[key]!=expected:
            raise ValueError('Actual early-drain boundary differs: '+key)
    return closure


def validate_activation(m):
    require_current_execution_release(m)
    verify_rebound_predecessor(m)
    progress=verify_prior_progress(m)
    if sha(Path(m['output_folder'])/'progress.json')!=m['preserved_progress_sha256_before_activation']:
        raise ValueError('Preserved preallocation/startup progress changed; new review required')
    for key,expected in {'planned':3416,'responses_saved':2588,'terminal':2592,
                         'attempted_confirmed':2592,'ambiguous_attempts':4,'not_dispatched':824}.items():
        if type(progress.get(key)) is not int or progress[key]!=expected:
            raise ValueError('Preserved preallocation/startup count differs: '+key)
    result = read(m['same_job_extension_result'])
    allowed = {'scheduler_denied_no_retry', 'uncertain_no_retry'}
    if (result.get('stage') not in allowed
            or Path(m['same_job_extension_verified']).exists()
            or not Path(m['same_job_extension_attempt_claim']).is_file()):
        raise ValueError('No actual denied/ambiguous once-only extension prerequisite')
    claim = read(m['same_job_extension_attempt_claim'])
    if claim.get('command') != ['scontrol','update','JobId=247052','TimeLimit=3-00:00:00']:
        raise ValueError('Different predecessor scheduler amendment attempt')
    output = Path(m['output_folder'])
    if (output/'scores.json').exists() or (output/'completion.json').exists():
        raise ValueError('Existing terminal/scored condition never receives another allocation')
    cfg = read(BASE/'tasks/P13/test_config.json')
    # Exact case IDs are task inputs only; never reference values or model outputs.
    cases = [json.loads(line) for line in (ROOT / cfg['input_file']).read_text().splitlines() if line.strip()]
    untouched = [case['case_id'] for case in cases
                 if not (output/'requests'/(hashlib.sha256(case['case_id'].encode()).hexdigest()+'.json')).exists()
                 and not (output/'outcomes'/(hashlib.sha256(case['case_id'].encode()).hexdigest()+'.json')).exists()]
    if not untouched:
        raise ValueError('No untouched P13 cases remain; no allocation')
    return {'role':'input_request_identity_boundary_not_attempt_total',
            'untouched_case_count_observed':len(untouched), 'planned':3416,
            'request_file_absence_is_not_a_claim_about_other_missing_progress':True}


def assert_predecessor_locks_free(m):
    """Probe both actual old pool ownership and task-output locks, without waiting."""
    paths = [Path(m['output_folder'])/'.runner.lock', Path(m['predecessor_pool_lock'])]
    with ExitStack() as stack:
        for path in paths:
            if path.is_symlink() or not path.is_file():
                raise ValueError('Exact predecessor lock is missing or a symlink')
            lock = stack.enter_context(path.open('rb'))
            if os.fstat(lock.fileno()).st_uid != os.getuid():
                raise ValueError('Predecessor lock is not owned')
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)


def snapshot_boundary(folder, config_sha, m):
    """Read only after the predecessor is terminal and the runner lock is free."""
    folder = Path(folder)
    if (folder / 'completion.json').exists():
        return None
    folder.mkdir(parents=True, exist_ok=True)
    pool_lock_path = Path(m['predecessor_pool_lock'])
    if pool_lock_path.is_symlink() or not pool_lock_path.is_file():
        raise ValueError('Exact predecessor pool lock missing or symlink')
    with (folder / '.runner.lock').open('a') as lock, pool_lock_path.open('rb') as old_pool_lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if os.fstat(old_pool_lock.fileno()).st_uid != os.getuid():
            raise ValueError('Predecessor pool lock is not owned')
        fcntl.flock(old_pool_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        restoration = restore_drained_request_permission(folder, config_sha, m)
        if (folder / 'run_manifest.json').exists():
            if read(folder / 'run_manifest.json')['config_sha256'] != config_sha:
                raise ValueError('Existing output belongs to another condition')
        progress = read(folder / 'progress.json') if (folder / 'progress.json').exists() else {}
        for key in ('transport_errors', 'http_errors', 'response_errors', 'refusals'):
            if progress.get(key, 0):
                raise ValueError('Existing task needs review after error: ' + key)
        files = {}
        for category in ('requests', 'responses', 'outcomes', 'errors'):
            for p in sorted((folder / category).glob('*')):
                if p.is_file():
                    files[str(p.relative_to(folder))] = sha(p)
        if (folder / 'run_manifest.json').exists():
            files['run_manifest.json'] = sha(folder / 'run_manifest.json')
        return {'at_pacific': stamp(), 'config_sha256': config_sha,
                'existing_files_sha256': files, 'previous_progress_observation': progress,
                'request_permission_restoration': restoration,
                'never_retry_attempted_requests': True,
                'missing_outcomes_for_existing_requests_remain_ambiguous': True}


def portable_drain_directory_identity(receipt, observed, request_dir):
    # st_dev is local to a mount namespace: head56 need not equal compute81.
    # Exact owned nonsymlink path is established by the frozen anchored-FD helper;
    # stable inode plus receipt/config/provenance binds the same retained object.
    if (receipt.get('request_directory') != str(request_dir)
        or type(receipt.get('target_device')) is not int or receipt['target_device'] < 0
        or type(receipt.get('target_inode')) is not int or receipt['target_inode'] != observed.st_ino
        or observed.st_uid != os.getuid() or not stat.S_ISDIR(observed.st_mode)
        or stat.S_IMODE(observed.st_mode) != 0o500):
        raise ValueError('No exact owned path/inode/mode for portable predecessor drain')
    return {'recorded_namespace_device':receipt['target_device'],
            'current_namespace_device':observed.st_dev,'stable_inode':observed.st_ino}


def restore_drained_request_permission(folder, config_sha, m):
    """Only after actual predecessor terminal and runner lock; preserve all file bytes."""
    require_current_execution_release(m)
    verify_rebound_predecessor(m)
    verify_prior_progress(m)
    expected = BASE/'tasks/P13/runtime/benchmark'
    if Path(folder).resolve() != expected or config_sha != m['P13_config_sha256']:
        raise ValueError('Foreign P13 restoration output/configuration')
    helper = load_module(m['predecessor_drain_helper'], 'frozen_owned_directory_FD_helper')
    request_dir = expected/'requests'
    descriptor = helper.open_owned_directory(ROOT, request_dir)
    try:
        observed = os.fstat(descriptor)
        mode = stat.S_IMODE(observed.st_mode)
        if mode == 0o700:
            return {'at_pacific':stamp(), 'mode':mode, 'restoration_performed':False,
                    'historical_file_bytes_changed':False}
        if mode != 0o500:
            raise ValueError('Unexpected request directory mode; never repair implicitly')
        receipt_path = Path(m['predecessor_drain_receipt'])
        receipt = read(receipt_path)
        portable_drain_directory_identity(receipt, observed, request_dir)
        drain_manifest = read(m['predecessor_drain_manifest'])
        if (receipt.get('manifest_sha256') != m['predecessor_drain_manifest_sha256']
                or drain_manifest.get('job_id') != '247052'
                or drain_manifest.get('config_sha256') != config_sha
                or receipt.get('request_directory') != str(request_dir)
                or receipt.get('original_mode') != 0o700 or receipt.get('drained_mode') != 0o500
                or receipt.get('changed_directory_fd_fsynced') is not True
                or receipt.get('active_calls_interrupted_by_this_operation') is not False
                or receipt.get('historical_files_changed') is not False):
            raise ValueError('No exact actual owned predecessor drain receipt')
        # Do not follow a swapped literal path when restoring the reviewed inode.
        check = helper.open_owned_directory(ROOT, request_dir)
        try:
            actual = os.fstat(check)
            if (actual.st_dev, actual.st_ino) != (observed.st_dev, observed.st_ino):
                raise ValueError('Request directory inode changed before restoration')
        finally:
            os.close(check)
        os.fchmod(descriptor, 0o700)
        os.fsync(descriptor)
        if stat.S_IMODE(os.fstat(descriptor).st_mode) != 0o700:
            raise ValueError('Owned request permission restoration did not complete')
        return {'at_pacific':stamp(), 'receipt_sha256':sha(receipt_path),
                'original_mode_restored':0o700, 'restoration_performed':True,
                'target_device':observed.st_dev, 'target_inode':observed.st_ino,
                'directory_FD_fsynced':True, 'historical_file_bytes_changed':False}
    finally:
        os.close(descriptor)


def verify_boundary(folder, boundary):
    for name, expected in boundary['existing_files_sha256'].items():
        if sha(Path(folder) / name) != expected:
            raise ValueError('Historical output changed across continuation: ' + name)


def identity_valid(m, identity):
    plan = read(m['pool_plan'])
    if (identity['model'] != plan['model'] or identity['revision'] != plan['revision']
            or identity['dtype'] != 'bfloat16' or identity['dedicated_gpu_count'] != 1
            or identity['max_model_len'] != 65536
            or identity['job_id'] != os.environ.get('SLURM_JOB_ID')
            or identity['job_id'] == m['original_job_id']
            or identity['hostname'] != socket.gethostname()):
        raise ValueError('Successor server identity differs from the frozen baseline')
    ticks = Path('/proc').joinpath(str(identity['pid']), 'stat').read_text().rsplit(')', 1)[1].split()[19]
    if ticks != identity['proc_start_ticks']:
        raise ValueError('Successor server process identity changed')
    runtime = read(Path(m['runtime_root']) / 'runtime_version_manifest.json')
    if (runtime['packages'] != m['runtime_versions']['packages']
            or runtime['python'] != m['runtime_versions']['python']
            or runtime['torch_cuda'] != m['runtime_versions']['torch_cuda']):
        raise ValueError('Successor packages or CUDA runtime differ from the frozen condition')


def create_grant(m, entry, identity, boundary):
    runtime = Path(m['runtime_root'])
    identity_file = runtime / 'server_identity.json'
    task = entry['task_id']
    output = BASE / 'tasks' / task / 'runtime/benchmark'
    grant_path = runtime / 'queue' / (task + '_benchmark_continuation3.grant.json')
    development = output.parent / 'development/completion.json'
    value = {'authorized': True, 'task_id': task, 'run_id': read(entry['benchmark_config'])['run_id'],
             'phase': 'benchmark', 'runner': entry['runner'], 'runner_sha256': entry['runner_sha256'],
             'config': entry['benchmark_config'], 'config_sha256': entry['benchmark_config_sha256'],
             'endpoint': identity['endpoint'], 'server_identity_file': str(identity_file),
             'server_identity_sha256': sha(identity_file), 'development_completion': str(development),
             'development_completion_sha256': sha(development), 'created_at_pacific': stamp(),
             'original_job_id': m['original_job_id'], 'historical_results_immutable': True,
             'continuation_boundary_sha256': sha(runtime / (task + '_boundary.json')),
             'argv': ['--config', entry['benchmark_config'], '--output', str(output),
                      '--grant', str(grant_path), '--development-completion', str(development),
                      '--concurrency', str(entry.get('concurrency', 4)), '--resume-unattempted']}
    with grant_path.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def score_one(m, entry, manifest_path, manifest_sha):
    require_current_execution_release(m)
    task = entry['task_id']
    score_path = Path(entry['score_output'])
    status = BASE / 'control' / (task + '_scoring_status.json')
    if score_path.exists():
        return
    if status.exists():
        raise ValueError('Existing native scoring attempt needs separate review')
    completion = read(score_path.parent / 'completion.json')
    if completion['terminal'] != completion['planned']:
        return
    with (score_path.parent / '.runner.lock').open('a') as runner_lock:
        fcntl.flock(runner_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if score_path.exists() or status.exists():
            raise ValueError('Scoring race requires review')
        with status.open('x') as f:
            json.dump({'stage': 'one_attempt_started', 'started_at_pacific': stamp(),
                       'prediction_lock_sha256': sha(score_path.parent / 'prediction_lock.json'),
                       'continuation_job_id': os.environ['SLURM_JOB_ID']}, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        with (BASE / 'control' / (task + '_scoring.log')).open('x') as log:
            result = subprocess.run(['/usr/bin/python3', __file__, '--manifest', str(manifest_path),
                                     '--manifest-sha256', manifest_sha, '--score', task],
                                    cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
        write(status, {'stage': 'completed' if result.returncode == 0 and score_path.exists() else 'failed_no_retry',
                       'finished_at_pacific': stamp(), 'exit_code': result.returncode,
                       'score_sha256': sha(score_path) if score_path.exists() else None})
        if result.returncode or not score_path.exists():
            raise ValueError('One native scoring entry failed; no automatic retry')


def control(m, manifest_path, manifest_sha, done):
    runtime = Path(m['runtime_root'])
    entries = [e for e in read(m['dispatch_plan'])['tasks'] if e['task_id'] in SCOPE]
    errors = {}
    while not done.is_set():
        try:
            state = read(runtime / 'status.json') if (runtime / 'status.json').exists() else {}
            if state.get('stage') == 'serving_task_queue':
                identity = read(runtime / 'server_identity.json')
                identity_valid(m, identity)
                for e in entries:
                    task = e['task_id']
                    output = BASE / 'tasks' / task / 'runtime/benchmark'
                    grant = runtime / 'queue' / (task + '_benchmark_continuation3.grant.json')
                    if (output / 'completion.json').exists():
                        boundary_path = runtime / (task + '_boundary.json')
                        if boundary_path.exists():
                            verify_boundary(output, read(boundary_path))
                        completion = read(output / 'completion.json')
                        if completion['terminal'] != completion['planned']:
                            raise ValueError('Runner sealed incomplete condition; no retry')
                        score_one(m, e, manifest_path, manifest_sha)
                        write(runtime / 'terminal_scored_receipt.json', {
                            'at_pacific': stamp(), 'task_id': task, 'planned': completion['planned'],
                            'terminal': completion['terminal'], 'score_path': e['score_output'],
                            'score_sha256': sha(e['score_output']), 'further_allocation_authorized': False})
                        (runtime / 'STOP').touch()
                    elif grant.exists():
                        finished = grant.with_name(grant.name.replace('.grant.json', '.finished.json'))
                        rejected = grant.with_name(grant.name.replace('.grant.json', '.rejected.json'))
                        if finished.exists() or rejected.exists():
                            raise ValueError('Runner ended without complete seal; preserve and review')
                    elif task not in errors:
                        try:
                            boundary = snapshot_boundary(output, e['benchmark_config_sha256'], m)
                            if boundary is not None:
                                write(runtime / (task + '_boundary.json'), boundary)
                                create_grant(m, e, identity, boundary)
                        except (ValueError, BlockingIOError) as exc:
                            errors[task] = str(exc)
                write(runtime / 'continuation_control_status.json', {
                    'at_pacific': stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
                    'stage': 'watching_unchanged_task_conditions', 'held_tasks': errors,
                    'task_ids': list(SCOPE), 'new_inference_calls_by_controller': 0})
        except OSError:
            pass
        except Exception as exc:
            write(runtime / 'continuation_control_error.json', {
                'at_pacific': stamp(), 'error_type': type(exc).__name__, 'error': str(exc)})
            (runtime / 'STOP').touch()
            return
        done.wait(15)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--score', choices=SCOPE)
    args = parser.parse_args()
    m = validate_manifest(args.manifest, args.manifest_sha256)
    validate_admission(m, args.manifest_sha256)
    require_current_execution_release(m)
    predecessor = None if args.score else predecessor_terminal(m['original_job_id'])
    if not args.score:
        validate_activation(m)
        assert_predecessor_locks_free(m)
    if not os.environ.get('SLURM_JOB_ID') or os.environ['SLURM_JOB_ID'] == m['original_job_id']:
        raise ValueError('A separate dependent one-GPU allocation is required')
    runtime = Path(m['runtime_root'])
    if args.score:
        helper = load_module(m['scoring_helper'], 'continuation_frozen_scoring_helper')
        helper.BASE = runtime.parent
        sys.argv = [m['scoring_helper'], '--plan', m['dispatch_plan'],
                    '--plan-sha256', m['dispatch_plan_sha256'], '--task', args.score]
        helper.main()
        return
    audit = load_module(m['gpu_audit_helper'], 'frozen_P13_followon_GPU_audit')
    observation = audit.conservative_project_gpu_audit(require_own_job=True)
    runtime.mkdir(parents=True, exist_ok=True)
    write(runtime / 'startup_gpu_audit.json', observation)
    (runtime / 'queue').mkdir(exist_ok=True)
    write(runtime / 'predecessor_terminal_receipt.json', {
        'at_pacific': stamp(), 'original_job_id': m['original_job_id'],
        'original_job_state': predecessor, 'successor_job_id': os.environ['SLURM_JOB_ID'],
        'new_inference_calls': 0})
    pool = load_module(m['pool_worker'], 'continuation_frozen_pool_worker')
    pool.BASE = runtime
    def stop(signum, frame):
        raise SystemExit('Stopped by Slurm or operator')
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    done = threading.Event()
    thread = threading.Thread(target=control, args=(m, args.manifest, args.manifest_sha256, done), daemon=True)
    thread.start()
    late_module = load_module(m['late_drain_helper'], 'source_admitted_actual_successor_late_drain')
    late_thread = threading.Thread(target=late_module.run, args=(m, args.manifest, args.manifest_sha256, done, validate_manifest, validate_admission, load_module), daemon=True)
    late_thread.start()
    try:
        pool.execute(SimpleNamespace(plan=Path(m['pool_plan']), plan_sha256=m['pool_plan_sha256']))
    finally:
        done.set()
        thread.join(timeout=30)
        late_thread.join(timeout=35)


if __name__ == '__main__':
    main()
