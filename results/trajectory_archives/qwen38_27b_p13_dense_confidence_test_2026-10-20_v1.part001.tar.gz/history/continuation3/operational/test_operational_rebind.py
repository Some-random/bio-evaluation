"""Invented metadata only; no live permission, scheduler, model or scorer calls."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch, Mock

HERE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


guard = load('guard', HERE/'resource_and_priority_binding.py')
wrapper = load('wrapper', HERE/'continue_p13.py')


class Guards(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.stop = Path(self.temp.name)/'invented_stop'
        self.self_path = str(Path(guard.__file__).resolve())
        self.m = {'execution_authorized':False,'role':'held_P13_actual_early_drain_operational_rebind',
                  'task_ids':['P13'],'P13_config_sha256':'d3915c12cb72599cd5c2a0737bfa3fd72c0705fe4819e688ebd5493adede80dc',
                  'gpu_audit_helper':self.self_path,'files_sha256':{self.self_path:'self-sha'},
                  'engineering_admission':str(Path(self.temp.name)/'admission.json'),
                  'root_decision_sha256':'root-decision-sha','held_stop_records_sha256':{str(self.stop):'stop-sha'}}
        self.a = {'issuer':'/root/independent_review','approved':True,'manifest_sha256':'manifest-sha',
                  'root_decision_sha256':'root-decision-sha','maximum_new_GPU_allocations':1,
                  'conditional_on_current_priority_release':True}
        self.r = {'issuer':'/root','approved':True,'task_id':'P13','manifest_sha256':'manifest-sha',
                  'priority_record_sha256':guard.PRIORITY_SHA,'release_new_P13_allocation':True,
                  'retired_stop_records_sha256':self.m['held_stop_records_sha256'],
                  'preserved_boundary':{'planned':3416,'saved':2588,'terminal':2592,'ambiguous':4,'untouched':824}}
        self.b = {'issuer':'/root/independent_review','approved':True,
                  'scope':'P13_later_Oct23_priority_release_binding_only','manifest_sha256':'manifest-sha',
                  'priority_record_sha256':guard.PRIORITY_SHA,'priority_release_sha256':'release-sha'}
        self.values={str(guard.PRIORITY):{'other_evaluations':'hold new submissions; invented'},
                     str(guard.MANIFEST):self.m,self.m['engineering_admission']:self.a,
                     str(guard.HERE/'priority_release.json'):self.r,
                     str(guard.HERE/'priority_release_admission.json'):self.b}
        def read(path):
            if str(path) not in self.values: raise FileNotFoundError('Invented missing record')
            return copy.deepcopy(self.values[str(path)])
        def digest(path):
            return {str(guard.PRIORITY):guard.PRIORITY_SHA,str(guard.MANIFEST):'manifest-sha',
                    self.self_path:'self-sha',str(guard.HERE/'priority_release.json'):'release-sha',
                    str(guard.HERE/'priority_release_admission.json'):'binding-sha',
                    str(self.stop):'stop-sha'}[str(path)]
        self.read = patch.object(guard,'regular_read',side_effect=read); self.read.start();self.addCleanup(self.read.stop)
        self.digest = patch.object(guard,'digest',side_effect=digest);self.digest.start();self.addCleanup(self.digest.stop)

    def test_exact_invented_future_release_metadata_only(self):
        with patch.object(guard,'load_adapter',side_effect=AssertionError('No live adapter/scheduler')):
            result=guard.verify_priority_release()
        self.assertEqual(result['root_priority_sha256'],guard.PRIORITY_SHA)
        self.assertFalse(self.m['execution_authorized'])
    def test_present_stop_blocks_even_fake_release(self):
        self.stop.write_text('invented')
        with self.assertRaises(PermissionError):guard.verify_priority_release()
    def test_symlink_stop_blocks(self):
        self.stop.symlink_to(Path(self.temp.name)/'absent')
        with self.assertRaises(PermissionError):guard.verify_priority_release()
    def test_missing_root_release_blocks(self):
        del self.values[str(guard.HERE/'priority_release.json')]
        with self.assertRaises(FileNotFoundError):guard.verify_priority_release()
    def test_missing_independent_release_blocks(self):
        del self.values[str(guard.HERE/'priority_release_admission.json')]
        with self.assertRaises(FileNotFoundError):guard.verify_priority_release()
    def test_missing_conditional_engineering_blocks(self):
        del self.values[self.m['engineering_admission']]
        with self.assertRaises(FileNotFoundError):guard.verify_priority_release()
    def test_wrong_scope_blocks(self):
        self.b['scope']='P13_priority_release_binding_only'
        with self.assertRaises(PermissionError):guard.verify_priority_release()
    def test_old_priority_release_blocks(self):
        self.r['priority_record_sha256']='old-Oct22-priority'
        with self.assertRaises(PermissionError):guard.verify_priority_release()
    def test_wrong_manifest_release_blocks(self):
        self.r['manifest_sha256']='other-manifest'
        with self.assertRaises(PermissionError):guard.verify_priority_release()
    def test_ambiguities_not_dropped(self):
        self.r['preserved_boundary']['ambiguous']=0
        with self.assertRaises(PermissionError):guard.verify_priority_release()
    def test_no_implicit_stop_retirement(self):
        self.r['retired_stop_records_sha256']={}
        with self.assertRaises(PermissionError):guard.verify_priority_release()
    def test_manifest_true_does_not_grant_execution(self):
        self.m['execution_authorized']=True
        with self.assertRaises(PermissionError):guard.verify_priority_release()
    def test_expanded_allocation_admission_blocks(self):
        self.a['maximum_new_GPU_allocations']=2
        with self.assertRaises(PermissionError):guard.verify_priority_release()


class EntryGuards(unittest.TestCase):
    def test_allocation_activation_rejects_before_inputs(self):
        with patch.object(wrapper,'require_current_execution_release',side_effect=PermissionError('held')),patch.object(wrapper,'verify_prior_progress',side_effect=AssertionError('No runtime inputs')):
            with self.assertRaises(PermissionError):wrapper.validate_activation({})
    def test_restoration_rejects_before_permission_or_input(self):
        with patch.object(wrapper,'require_current_execution_release',side_effect=PermissionError('held')),patch.object(wrapper.os,'fchmod',side_effect=AssertionError('No permission mutation')),patch.object(wrapper,'verify_prior_progress',side_effect=AssertionError('No runtime reads')):
            with self.assertRaises(PermissionError):wrapper.restore_drained_request_permission('invented','invented',{})
    def test_score_rejects_before_score_path(self):
        with patch.object(wrapper,'require_current_execution_release',side_effect=PermissionError('held')):
            with self.assertRaises(PermissionError):wrapper.score_one({}, {}, 'invented','invented')
    def test_main_rejects_before_scheduler(self):
        with patch.object(wrapper.sys,'argv',['invented','--manifest','invented','--manifest-sha256','invented']),patch.object(wrapper,'validate_manifest',return_value={}),patch.object(wrapper,'validate_admission',return_value=None),patch.object(wrapper,'require_current_execution_release',side_effect=PermissionError('held')),patch.object(wrapper.subprocess,'run',side_effect=AssertionError('No scheduler')):
            with self.assertRaises(PermissionError):wrapper.main()
    def test_actual_early_receipt_required(self):
        m={key:'invented-'+key for key in ['predecessor_drain_manifest','predecessor_drain_manifest_sha256','predecessor_drain_receipt','predecessor_drain_receipt_sha256','predecessor_terminal_closure','predecessor_terminal_closure_sha256']}
        with patch.object(wrapper,'sha',return_value='not-the-frozen-sha'):
            with self.assertRaises(ValueError):wrapper.verify_rebound_predecessor(m)
    def synthetic_chain(self):
        m={'P13_config_sha256':'invented-config'}
        for name in ['predecessor_drain_manifest','predecessor_drain_receipt','predecessor_terminal_closure']:
            m[name]=name;m[name+'_sha256']=name+'-sha'
        rows={'predecessor_drain_manifest':{'job_id':'247052','config_sha256':'invented-config'},
              'predecessor_drain_receipt':{'manifest_sha256':'predecessor_drain_manifest-sha','active_calls_interrupted_by_this_operation':False,'historical_files_changed':False},
              'predecessor_terminal_closure':{'job_id':'247052','all_four_inflight_responses_settled_valid':True,'P13_successor_stopped':True,'new_P13_submission_present':False,'planned':3416,'saved_responses':2588,'terminal_outcomes':2592,'request_claims':2592,'inherited_ambiguous_outcomes':4,'untouched_cases':824}}
        return m,rows
    def test_exact_invented_early_chain_accepted_without_action(self):
        m,rows=self.synthetic_chain()
        with patch.object(wrapper,'sha',side_effect=lambda p:p+'-sha'),patch.object(wrapper,'read',side_effect=lambda p:copy.deepcopy(rows[p])),patch.object(wrapper.os,'fchmod',side_effect=AssertionError('No permission action')),patch.object(wrapper.subprocess,'run',side_effect=AssertionError('No scheduler')):
            self.assertEqual(wrapper.verify_rebound_predecessor(m)['untouched_cases'],824)
    def test_rebound_chain_cannot_drop_four_invalids(self):
        m,rows=self.synthetic_chain();rows['predecessor_terminal_closure']['inherited_ambiguous_outcomes']=0
        with patch.object(wrapper,'sha',side_effect=lambda p:p+'-sha'),patch.object(wrapper,'read',side_effect=lambda p:copy.deepcopy(rows[p])):
            with self.assertRaises(ValueError):wrapper.verify_rebound_predecessor(m)


class SourceInvariance(unittest.TestCase):
    def functions(self,p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    def test_unchanged_scientific_and_native_operational_functions(self):
        old=self.functions(HERE.parent/'continue_p13_guarded_v2.py');new=self.functions(HERE/'continue_p13.py')
        changed={'validate_activation','restore_drained_request_permission','score_one','main'}
        for key in old.keys()-changed:self.assertEqual(old[key],new[key],key)
    def test_same_resource_adapter_and_capacity_contract(self):
        old=self.functions(HERE.parent/'resource_and_priority_binding_v5.py');new=self.functions(HERE/'resource_and_priority_binding.py')
        for key in ['load_adapter','enforce','conservative_project_gpu_audit','regular_read','digest']:self.assertEqual(old[key],new[key],key)
    def test_shared_original_once_only_claim_namespace(self):
        source=(HERE/'submit_when_capacity.py').read_text()
        self.assertIn('HERE = PACKET.parent',source)
        self.assertIn("(HERE / 'submission_claim.json').exists()",source)
        self.assertIn("create(HERE / 'submission_claim.json'",source)
        self.assertIn("c.require_current_execution_release(m)",source)
    def test_same_slurm_resource_bound(self):
        old=[x for x in (HERE.parent/'pool_resource_priority_v5.sbatch').read_text().splitlines() if x.startswith('#SBATCH') and not x.startswith('#SBATCH --output=')]
        new=[x for x in (HERE/'pool.sbatch').read_text().splitlines() if x.startswith('#SBATCH') and not x.startswith('#SBATCH --output=')]
        self.assertEqual(old,new)
    def test_never_change_old_sources_in_source_bundle(self):
        self.assertNotIn('write_text',(HERE/'resource_and_priority_binding.py').read_text())


class PortableNamespaceIdentity(unittest.TestCase):
    def fixture(self):
        path=Path('/invented/project/requests')
        receipt={'request_directory':str(path),'target_device':56,'target_inode':4321}
        observed=SimpleNamespace(st_dev=81,st_ino=4321,st_uid=wrapper.os.getuid(),st_mode=0o40500)
        return receipt,observed,path
    def test_head56_compute81_accepted_without_permission_action(self):
        receipt,observed,path=self.fixture()
        with patch.object(wrapper.os,'fchmod',side_effect=AssertionError('No permission action')):
            result=wrapper.portable_drain_directory_identity(receipt,observed,path)
        self.assertEqual((result['recorded_namespace_device'],result['current_namespace_device']),(56,81))
    def test_wrong_inode_rejected(self):
        receipt,observed,path=self.fixture();observed.st_ino=9999
        with self.assertRaises(ValueError):wrapper.portable_drain_directory_identity(receipt,observed,path)
    def test_wrong_path_rejected(self):
        receipt,observed,path=self.fixture();receipt['request_directory']='/invented/other'
        with self.assertRaises(ValueError):wrapper.portable_drain_directory_identity(receipt,observed,path)
    def test_wrong_owner_rejected(self):
        receipt,observed,path=self.fixture();observed.st_uid+=1
        with self.assertRaises(ValueError):wrapper.portable_drain_directory_identity(receipt,observed,path)
    def test_wrong_mode_rejected(self):
        receipt,observed,path=self.fixture();observed.st_mode=0o40700
        with self.assertRaises(ValueError):wrapper.portable_drain_directory_identity(receipt,observed,path)
    def test_regular_file_rejected(self):
        receipt,observed,path=self.fixture();observed.st_mode=0o100500
        with self.assertRaises(ValueError):wrapper.portable_drain_directory_identity(receipt,observed,path)
    def test_unknown_recorded_namespace_device_rejected(self):
        receipt,observed,path=self.fixture();receipt['target_device']=None
        with self.assertRaises(ValueError):wrapper.portable_drain_directory_identity(receipt,observed,path)
    def test_same_namespace_double_open_race_guard_retained(self):
        source=(HERE/'continue_p13.py').read_text()
        self.assertIn('if (actual.st_dev, actual.st_ino) != (observed.st_dev, observed.st_ino):',source)
        self.assertIn('Request directory inode changed before restoration',source)
    def test_final_stop_prevents_claim_and_scheduler(self):
        tree=ast.parse((HERE/'submit_when_capacity.py').read_text())
        fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='submit_once')
        cap=next(n for n in fn.body if isinstance(n,ast.With) and 'cap_lock' in ast.unparse(n.items[0].optional_vars))
        indexes=[i for i,n in enumerate(cap.body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='c.validate_manifest']
        tail=cap.body[indexes[-1]:]
        probe=ast.FunctionDef(name='probe',args=ast.arguments(posonlyargs=[],args=[],kwonlyargs=[],kw_defaults=[],defaults=[]),body=tail,decorator_list=[])
        module=ast.fix_missing_locations(ast.Module(body=[probe],type_ignores=[]))
        c=SimpleNamespace(validate_manifest=Mock(),validate_admission=Mock(),require_current_execution_release=Mock(side_effect=PermissionError('Invented final STOP')))
        create=Mock(side_effect=AssertionError('No durable submission claim'))
        scheduler=SimpleNamespace(run=Mock(side_effect=AssertionError('No scheduler call')))
        namespace={'c':c,'m':{'original_job_id':'invented','batch_script':'invented'},'manifest_path':'invented','manifest_sha':'invented','create':create,'subprocess':scheduler,'HERE':Path('/invented')}
        exec(compile(module,'<invented-final-stop-check>','exec'),namespace)
        with self.assertRaises(PermissionError):namespace['probe']()
        create.assert_not_called();scheduler.run.assert_not_called()


if __name__=='__main__':unittest.main()
