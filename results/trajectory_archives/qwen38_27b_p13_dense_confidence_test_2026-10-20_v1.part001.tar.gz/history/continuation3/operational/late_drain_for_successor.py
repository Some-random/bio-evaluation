"""CPU-only same-allocation late-request drain; admitted with the parent manifest.

Derives and seals the one actual successor's 72h scheduler identity. Never
allocates, scores, retries, restores, signals a model/client or changes files.
"""
from datetime import datetime,timedelta
import hashlib,json,os,socket,stat,subprocess
from pathlib import Path
from zoneinfo import ZoneInfo
PACIFIC=ZoneInfo('America/Los_Angeles')
TERMINAL={'COMPLETED','FAILED','TIMEOUT','CANCELLED','NODE_FAIL','OUT_OF_MEMORY','PREEMPTED','BOOT_FAIL','DEADLINE','REVOKED'}
def stamp():return datetime.now(PACIFIC).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def create(p,value):
 with Path(p).open('x') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 fd=os.open(Path(p).parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def write(p,value):
 p=Path(p);t=p.with_suffix('.json.tmp');t.write_text(json.dumps(dict(value,at_pacific=stamp(),new_GPU_allocations=0,new_model_or_score_calls=0,automatic_permission_restoration=False),indent=2)+'\n');t.replace(p)
def job_fields(raw,m,job_id):
 f=dict(x.split('=',1) for x in raw.split() if '=' in x)
 expected={'JobId':job_id,'UserId':'dongweij(26129)','JobName':'bio-P13-continue3','WorkDir':m['root'],'Command':m['batch_script'],'TimeLimit':'3-00:00:00','Requeue':'0','Restarts':'0'}
 if any(f.get(k)!=v for k,v in expected.items()):raise ValueError('Actual successor scheduler ownership/source/walltime differs')
 if f.get('JobState') in TERMINAL:return None
 if f.get('JobState')!='RUNNING' or f.get('NodeList')!=socket.gethostname().split('.')[0]:raise ValueError('Successor is not running on the owned host')
 for key in ['ReqTRES','AllocTRES']:
  fields=dict(x.split('=',1)for x in f.get(key,'').split(',')if'='in x)
  if fields.get('gres/gpu')!='1':raise ValueError('Expected exact existing one-GPU successor allocation')
 start=datetime.fromisoformat(f['StartTime']).replace(tzinfo=PACIFIC);end=datetime.fromisoformat(f['EndTime']).replace(tzinfo=PACIFIC)
 if end-start!=timedelta(hours=72):raise ValueError('Scheduler start/end are not the admitted72h operational bound')
 return {'job_id':job_id,'job_start_local':f['StartTime'],'job_end_local':f['EndTime'],'job_end_pacific':end.isoformat(),'job_time_limit':f['TimeLimit'],'hostname':socket.gethostname(),'job_uid':os.getuid(),'job_command':m['batch_script'],'root':m['root'],'drain_before_end_seconds':1800,'minimum_end_margin_seconds':960,'frozen_request_timeout_seconds':900,'request_directory':str(Path(m['output_folder'])/'requests'),'task_ids':['P13'],'config_sha256':m['P13_config_sha256'],'planned_denominator':3416}
def observe(m,job_id):
 r=subprocess.run(['scontrol','show','job','-o',job_id],capture_output=True,text=True,timeout=30)
 if r.returncode:raise ValueError('Fresh actual successor live scheduler observation unavailable; no drain')
 return job_fields(r.stdout,m,job_id)
def verify_runtime(m,boundary,now):
 runtime=Path(m['runtime_root']);identity=read(runtime/'server_identity.json');state=read(runtime/'status.json')
 age=(now-datetime.fromisoformat(state['updated_at_pacific'])).total_seconds()
 if (state.get('job_id')!=boundary['job_id'] or identity.get('job_id')!=boundary['job_id'] or state.get('hostname')!=boundary['hostname'] or identity.get('hostname')!=boundary['hostname'] or state.get('server_pid')!=identity.get('pid') or state.get('active_clients')!=['P13_benchmark_continuation3'] or state.get('stage')!='serving_task_queue' or not 0<=age<=120):raise ValueError('Fresh exact owned successor client/server/runtime required')
 return identity

def run(m,manifest_path,manifest_sha,done,validate_manifest,validate_admission,load_module):
 runtime=Path(m['runtime_root']);record=runtime/'late_drain';record.mkdir(parents=True,exist_ok=True);status=record/'status.json'
 try:
  job_id=os.environ.get('SLURM_JOB_ID')
  if not job_id or job_id=='247052' or not job_id.isdigit():raise ValueError('Only one actual new successor allocation allowed')
  boundary=observe(m,job_id)
  if boundary is None:write(status,{'stage':'already_terminal_no_permission_change'});return
  boundary.update(parent_manifest_sha256=manifest_sha,root_adoption_sha256=sha(m['root_decision']),derivation='exact_running_owned_oneGPU72h_job_from_reviewed_parent_source',new_GPU_allocations=0,new_model_or_score_calls=0)
  create(record/'boundary.json',boundary);boundary_sha=sha(record/'boundary.json')
  helper=load_module(m['predecessor_drain_helper'],'frozen_permission_only_drain_FD_implementation')
  while not done.is_set():
   complete=Path(m['output_folder'])/'completion.json'
   if complete.exists():
    value=read(complete)
    if value.get('config_sha256')!=m['P13_config_sha256'] or value.get('terminal')!=3416 or value.get('planned')!=3416:raise ValueError('Unexpected incomplete terminal artifact')
    write(status,{'stage':'full_generation_terminal_no_permission_change'});return
   fresh=observe(m,job_id)
   if fresh is None:write(status,{'stage':'owned_job_terminal_no_permission_change'});return
   # Actual source-bound start/end/resource identity may never drift silently.
   if any(fresh[k]!=boundary[k] for k in fresh):raise ValueError('Owned successor scheduler binding changed')
   now=datetime.now(PACIFIC);end=datetime.fromisoformat(boundary['job_end_pacific']);latest=end-timedelta(seconds=960)
   if now>latest:write(status,{'stage':'safe_window_elapsed_no_permission_change'});return
   if helper.due(boundary,now):
    validate_manifest(manifest_path,manifest_sha);validate_admission(m,manifest_sha)
    verify_runtime(m,boundary,now)
    if sha(record/'boundary.json')!=boundary_sha:raise ValueError('Exact derived scheduler drain boundary changed')
    helper.drain_once(Path(m['root']),boundary['request_directory'],record,boundary_sha,boundary)
    write(status,{'stage':'late_new_request_creation_drained','boundary_sha256':boundary_sha,'job_id':job_id,'active_calls_not_interrupted':True,'historical_files_changed':False});return
   write(status,{'stage':'waiting_fixed_actual_successor_late_boundary','job_id':job_id,'drain_at_pacific':(end-timedelta(seconds=1800)).isoformat(),'latest_at_pacific':latest.isoformat(),'request_permissions_changed':False})
   done.wait(60)
  write(status,{'stage':'owned_pool_exited_no_permission_change'})
 except Exception as e:
  write(status,{'stage':'guard_error_no_automatic_replay','error_type':type(e).__name__,'error':str(e),'durable_claim_present':(record/'drain_claim.json').exists(),'operation_may_already_have_completed':(record/'drain_claim.json').exists(),'automatic_replay':False})
