"""Artificial metadata/launch tests; every subprocess launch is mocked."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch, Mock

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('publication_watcher_v4', HERE/'watch_assembly.py')
watcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(watcher)


class ReadinessTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.out = Path(self.folder.name)
        self.status = self.out/'status.json'
        self.base_patch=patch.object(watcher,'BASE',self.out);self.base_patch.start();self.addCleanup(self.base_patch.stop)

    def write(self, name, value):
        (self.out/name).write_text(json.dumps(value))

    def complete(self):
        self.write('prediction_lock.json', {'config_sha256': watcher.CONFIG_SHA, 'reference_labels_opened': False})
        common = {'config_sha256': watcher.CONFIG_SHA, 'planned': 3416,
                  'prediction_lock_sha256': watcher.sha(self.out/'prediction_lock.json')}
        self.write('completion.json', dict(common, terminal=3416))
        self.write('scores.json', dict(common, predictions_locked_before_reference_read=True))
        self.write('status.json', {'stage': 'completed', 'score_sha256': watcher.sha(self.out/'scores.json')})
        terminal=self.out/'continuation_v3/runtime/terminal_scored_receipt.json'
        terminal.parent.mkdir(parents=True,exist_ok=True)
        terminal.write_text(json.dumps({'task_id':'P13','planned':3416,'terminal':3416,
            'at_pacific':'2026-10-24T18:00:00-07:00','score_path':str(self.out/'scores.json'),
            'score_sha256':watcher.sha(self.out/'scores.json'),'further_allocation_authorized':False}))
        queue=terminal.parent/'queue';queue.mkdir()
        self.grant=queue/'P13_benchmark_continuation3.grant.json'
        self.grant.write_text(json.dumps({'task_id':'P13','phase':'benchmark','authorized':True,
            'run_id':watcher.metadata.RUN,'config_sha256':watcher.CONFIG_SHA}))
        self.grant_sha=watcher.sha(self.grant)
        self.started=queue/'P13_benchmark_continuation3.started.json'
        self.started.write_text(json.dumps({'task_id':'P13','phase':'benchmark',
            'grant_sha256':self.grant_sha,'started_at_pacific':'2026-10-24T12:00:00-07:00'}))
        self.finished=queue/'P13_benchmark_continuation3.finished.json'
        for key,value in [('GRANT_SHA',self.grant_sha),('STARTED_SHA',watcher.sha(self.started))]:
            binding=patch.object(watcher.metadata,key,value);binding.start();self.addCleanup(binding.stop)

    def finish(self, **changes):
        value={'exit_code':0,'finished_at_pacific':'2026-10-24T17:59:00-07:00','grant_sha256':self.grant_sha}
        value.update(changes);self.finished.write_text(json.dumps(value))

    def test_missing_optional_finished_ready_with_explicit_absence(self):
        self.complete()
        evidence=watcher.readiness(self.out,self.status)
        observation=evidence['packaging_closure']['pool_finished_observation']
        self.assertFalse(observation['observed_at_capture'])
        self.assertNotIn('exit_code',observation)
        self.assertNotIn('sha256',observation)
        self.assertEqual(evidence['score_path'],str(self.out/'scores.json'))
        self.assertEqual(evidence['terminal_scored_receipt_sha256'],watcher.sha(self.out/'continuation_v3/runtime/terminal_scored_receipt.json'))

    def test_present_exact_finished_accepted(self):
        self.complete();self.finish()
        evidence=watcher.readiness(self.out,self.status)
        observation=evidence['packaging_closure']['pool_finished_observation']
        self.assertTrue(observation['observed_at_capture'])
        self.assertEqual(observation['sha256'],watcher.sha(self.finished))
        self.assertEqual(observation['exit_code'],0)

    def test_wrong_finished_grant_rejected(self):
        self.complete();self.finish(grant_sha256='wrong')
        with self.assertRaises(ValueError):watcher.readiness(self.out,self.status)

    def test_nonzero_or_boolean_finished_exit_rejected(self):
        self.complete()
        for code in [1,False,'0']:
            self.finish(exit_code=code)
            with self.subTest(code=code),self.assertRaises(ValueError):watcher.readiness(self.out,self.status)

    def test_missing_or_timezone_free_finished_timestamp_rejected(self):
        self.complete()
        for timestamp in ['',None,'2026-10-24T18:00:00']:
            self.finish(finished_at_pacific=timestamp)
            with self.subTest(timestamp=timestamp),self.assertRaises(ValueError):watcher.readiness(self.out,self.status)

    def test_symlink_finished_rejected(self):
        self.complete();self.finish()
        renamed=self.finished.with_suffix('.real');self.finished.rename(renamed);self.finished.symlink_to(renamed)
        with self.assertRaises(ValueError):watcher.readiness(self.out,self.status)

    def test_wrong_owner_finished_rejected(self):
        self.complete();self.finish()
        original=watcher.metadata.os.getuid
        with patch.object(watcher.metadata.os,'getuid',return_value=original()+1):
            with self.assertRaises(ValueError):watcher.readiness(self.out,self.status)

    def test_changed_started_or_grant_rejected(self):
        self.complete();self.grant.write_text('{}')
        with self.assertRaises(ValueError):watcher.readiness(self.out,self.status)

    def test_wrong_terminal_score_path_rejected(self):
        self.complete()
        p=self.out/'continuation_v3/runtime/terminal_scored_receipt.json'
        value=json.loads(p.read_text());value['score_path']='foreign/scores.json';p.write_text(json.dumps(value))
        with self.assertRaises(ValueError):watcher.readiness(self.out,self.status)

    def test_mismatch_finished_stops_before_assembly_claim(self):
        self.complete();self.finish(exit_code=1)
        assembler=self.out/'assemble_publication.py';assembler.write_text('# Never executed\n')
        original_readiness=watcher.readiness
        with patch.object(watcher,'HERE',self.out),patch.object(watcher,'ROOT',self.out), \
                patch.object(watcher,'readiness',side_effect=lambda:original_readiness(self.out,self.status)), \
                patch.object(sys,'argv',['invented','--assembler-sha256',watcher.sha(assembler)]), \
                patch.object(watcher.subprocess,'run') as run:
            with self.assertRaises(ValueError):watcher.main()
            run.assert_not_called()
        self.assertFalse((self.out/'publication_assembly_claim.json').exists())

    def test_missing_terminal_receipt_waits(self):
        self.complete()
        (self.out/'continuation_v3/runtime/terminal_scored_receipt.json').unlink()
        self.assertIsNone(watcher.readiness(self.out,self.status))

    def test_wrong_terminal_receipt_rejected(self):
        self.complete()
        p=self.out/'continuation_v3/runtime/terminal_scored_receipt.json'
        value=json.loads(p.read_text());value['score_sha256']='wrong';p.write_text(json.dumps(value))
        with self.assertRaises(ValueError):watcher.readiness(self.out,self.status)

    def test_score_before_completed_status_waits(self):
        self.complete()
        self.write('status.json', {'stage': 'running'})
        self.assertIsNone(watcher.readiness(self.out, self.status))

    def test_missing_status_waits(self):
        self.complete()
        self.status.unlink()
        self.assertIsNone(watcher.readiness(self.out, self.status))

    def test_exact_completed_metadata_ready(self):
        self.complete()
        self.assertEqual(watcher.readiness(self.out, self.status)['score_sha256'], watcher.sha(self.out/'scores.json'))

    def test_complete_status_mismatched_hash_rejected(self):
        self.complete()
        self.write('status.json', {'stage': 'completed', 'score_sha256': 'invented'})
        with self.assertRaises(ValueError):
            watcher.readiness(self.out, self.status)

    def test_partial_denominator_rejected(self):
        self.complete()
        done = json.loads((self.out/'completion.json').read_text())
        done['terminal'] -= 1
        self.write('completion.json', done)
        with self.assertRaises(ValueError):
            watcher.readiness(self.out, self.status)

    def test_single_assembly_launch_exact_v3_source(self):
        assembler = self.out/'assemble_publication.py'
        assembler.write_text('# Artificial source, never executed\n')
        evidence = {'score_sha256': 'artificial-score', 'prediction_lock_sha256': 'artificial-lock',
                    'scoring_status_sha256': 'artificial-status'}
        with patch.object(watcher, 'HERE', self.out), patch.object(watcher, 'ROOT', self.out), \
                patch.object(watcher, 'readiness', return_value=evidence), \
                patch.object(sys, 'argv', ['invented', '--assembler-sha256', watcher.sha(assembler)]), \
                patch.object(watcher.subprocess, 'run', return_value=Mock(returncode=0)) as run:
            watcher.main()
            self.assertEqual(run.call_args.args[0], ['/usr/bin/python3', str(assembler)])
            run.assert_called_once()
            watcher.main()
            run.assert_called_once()
        claim = json.loads((self.out/'publication_assembly_claim.json').read_text())
        self.assertEqual(claim['score_sha256'], evidence['score_sha256'])
        self.assertEqual(claim['new_model_or_score_calls'], 0)


if __name__ == '__main__':
    unittest.main()
