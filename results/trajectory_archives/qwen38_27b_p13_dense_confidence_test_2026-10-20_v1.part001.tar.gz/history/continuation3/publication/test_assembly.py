"""Invented source-only tests for privacy, frozen binding and full reconstruction."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('p13_publication_v3', HERE/'assemble_publication.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)


class PublicationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root/'invented.txt'
        self.raw = b'Artificial first line.\nArtificial second line.\n'
        self.source.write_bytes(self.raw)
        self.originals = {'source/invented.txt': {'path': str(self.source), 'sha256': p.sha(self.source), 'bytes': len(self.raw)}}

    def archives(self, changed_piece=None):
        with patch.object(p, 'MEMBER_MAX', 8), patch.object(p, 'PART_MAX', 17):
            pieces = p.split_members(self.originals)
            groups = p.group_parts(pieces)
        inventory = {}
        for number, rows in enumerate(groups):
            filename = f'artificial.part{number:03}.tar.gz'
            members = {}
            with tarfile.open(self.root/filename, 'w:gz') as archive:
                for row in rows:
                    data = self.raw[row['offset']:row['offset']+row['bytes']]
                    if row['offset'] == changed_piece:
                        data = bytes([data[0] ^ 1]) + data[1:]
                    item = tarfile.TarInfo(row['archive_name'])
                    item.size = len(data)
                    archive.addfile(item, io.BytesIO(data))
                    # Even a tamper with a freshly recomputed piece + archive
                    # hash must fail against the original frozen full-file hash.
                    members[item.name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                                         'original_member_name': row['original_member_name'],
                                         'original_sha256': row['sha256'], 'original_bytes': row['original_bytes'],
                                         'byte_offset': row['offset']}
            inventory[filename] = {'sha256': p.sha(self.root/filename), 'members': members}
        return inventory

    def test_split_pieces_reconstruct_full_original(self):
        inventory = self.archives()
        self.assertGreater(len(inventory), 1)
        p.verify_reconstruction(self.root, inventory, self.originals)
        p.recheck_originals(self.originals)

    def test_rehashed_piece_tamper_still_rejected_by_full_hash(self):
        with self.assertRaisesRegex(ValueError, 'full hash'):
            p.verify_reconstruction(self.root, self.archives(changed_piece=8), self.originals)

    def test_gap_or_overlap_rejected(self):
        inventory = self.archives()
        first = next(iter(next(iter(inventory.values()))['members'].values()))
        first['byte_offset'] = 1
        with self.assertRaisesRegex(ValueError, 'Gap, overlap'):
            p.verify_reconstruction(self.root, inventory, self.originals)

    def test_post_capture_original_tamper_rejected(self):
        inventory = self.archives()
        p.verify_reconstruction(self.root, inventory, self.originals)
        self.source.write_bytes(b'changed source')
        with self.assertRaisesRegex(ValueError, 'Source changed'):
            p.recheck_originals(self.originals)

    def test_archive_tamper_rejected(self):
        inventory = self.archives()
        archive = self.root/next(iter(inventory))
        archive.write_bytes(archive.read_bytes() + b'changed')
        with self.assertRaisesRegex(ValueError, 'Archive changed'):
            p.verify_reconstruction(self.root, inventory, self.originals)

    def test_target_weight_environment_account_files_excluded(self):
        target = self.root/'scorer_references.jsonl'
        for filename in ['scorer_references.jsonl', 'model.safetensors', '.env',
                         'startup_gpu_audit.json', 'last_safe_gpu_audit.json']:
            source = self.root/filename
            source.write_bytes(b'Invented placeholder only')
            with self.subTest(filename=filename), self.assertRaises(ValueError):
                p.permitted_source('sources/'+filename, source, target, self.root)

    def test_foreign_and_traversal_sources_excluded(self):
        with self.assertRaises(ValueError):
            p.permitted_source('../foreign', self.source, self.root/'targets', self.root)
        link = self.root/'linked.txt'
        link.symlink_to(self.source)
        with self.assertRaises(ValueError):
            p.permitted_source('sources/linked.txt', link, self.root/'targets', self.root)

    def test_runtime_whitelist_is_narrow(self):
        self.assertTrue(p.permitted_runtime_member('requests/'+'a'*64+'.json'))
        for name in ['../targets.json', 'scorer_references.jsonl', 'P14/responses/x.json', 'requests/unknown.json']:
            with self.subTest(name=name):
                self.assertFalse(p.permitted_runtime_member(name))

    def test_exact_frozen_runner_http_error_suffix(self):
        self.assertTrue(p.permitted_runtime_member('errors/'+'a'*64+'.http'))
        self.assertFalse(p.permitted_runtime_member('errors/'+'a'*64+'.json'))
        self.assertFalse(p.permitted_runtime_member('responses/'+'a'*64+'.http'))

    def artificial_contract(self):
        here = self.root/'contract'
        here.mkdir()
        config = self.root/'.local/catalog_execution_2026-10-20/tasks/P13/test_config.json'
        config.parent.mkdir(parents=True)
        config.write_text(json.dumps({'scorer_reference_file': 'never-opened-scorer-target.jsonl'}))
        manifest = {'task_ids': ['P13'], 'files_sha256': {str(self.source): p.sha(self.source), str(config): p.sha(config)}}
        (here/'manifest.json').write_text(json.dumps(manifest))
        manifest_sha = p.sha(here/'manifest.json')
        (here/'engineering_review.json').write_text(json.dumps({'artificial_review': True}))
        review_sha = p.sha(here/'engineering_review.json')
        (here/'engineering_admission.json').write_text(json.dumps({'approved': True, 'manifest_sha256': manifest_sha,
                                                                'engineering_review_sha256': review_sha}))
        admission_sha = p.sha(here/'engineering_admission.json')
        contract = {'task_id': 'P13', 'reviewed_manifest_sha256': manifest_sha,
                    'engineering_admission_sha256': admission_sha, 'engineering_review_sha256': review_sha,
                    'sources': {'source/invented.txt': {'path': 'invented.txt', 'bytes': len(self.raw), 'sha256': p.sha(self.source)}}}
        (here/'source_contract.json').write_text(json.dumps(contract))
        return {'root': self.root, 'here': here, 'ops':here, 'contract_sha': p.sha(here/'source_contract.json'),
                'manifest_sha': manifest_sha, 'admission_sha': admission_sha, 'review_sha': review_sha}

    def test_bound_artificial_contract_without_target_file(self):
        arguments = self.artificial_contract()
        selected, target = p.bind_source_contract(**arguments)
        self.assertEqual(len(selected), 1)
        self.assertFalse(target.exists())

    def test_changed_frozen_source_rejected_before_import(self):
        arguments = self.artificial_contract()
        self.source.write_bytes(b'Changed artificial file')
        with self.assertRaisesRegex(ValueError, 'Changed admitted frozen source'):
            p.bind_source_contract(**arguments)

    def test_source_contract_change_rejected(self):
        arguments = self.artificial_contract()
        (arguments['here']/'source_contract.json').write_text('{}')
        with self.assertRaisesRegex(ValueError, 'Changed exact'):
            p.bind_source_contract(**arguments)

    def test_duplicate_copy_requires_captured_hash(self):
        with self.assertRaisesRegex(ValueError, 'Published duplicate differs'):
            p.create_verified(self.root/'output.txt', self.source, 'invented wrong hash')


if __name__ == '__main__':
    unittest.main()
