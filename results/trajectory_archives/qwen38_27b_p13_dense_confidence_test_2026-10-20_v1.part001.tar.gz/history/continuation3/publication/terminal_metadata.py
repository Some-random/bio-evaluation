"""Packaging-only terminal metadata; absence is never a fabricated pool receipt."""
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
from zoneinfo import ZoneInfo

CONFIG_SHA = 'd3915c12cb72599cd5c2a0737bfa3fd72c0705fe4819e688ebd5493adede80dc'
GRANT_SHA = '9ffc510cd0d84268654112bafde7cecfeb2e4ccfe1988e60348acfc10b939de2'
STARTED_SHA = 'cbcf867e858210708932ad49bc8882c9b73a76a309ecdece3da4ae709aa7218d'
RUN = 'qwen38_27b_p13_dense_confidence_test_2026-10-20_v1'


def snapshot(path, missing_allowed=False):
    """Read one owned regular nonsymlink metadata file, retaining exact bytes hash."""
    path = Path(path)
    for parent in path.parents:
        if parent.is_symlink():
            raise ValueError('Symlink metadata parent forbidden')
    try:
        before = path.lstat()
    except FileNotFoundError:
        if missing_allowed:
            return None
        raise
    if not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid():
        raise ValueError('Metadata must be an owned regular nonsymlink file')
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, 'rb') as stream:
        opened = os.fstat(stream.fileno())
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
            raise ValueError('Metadata identity changed before capture')
        raw = stream.read()
        after_fd = os.fstat(stream.fileno())
    after = path.lstat()
    identity = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns,
                              value.st_ctime_ns, value.st_uid, value.st_mode)
    if identity(before) != identity(after_fd) or identity(before) != identity(after):
        raise ValueError('Metadata changed during capture')
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError('Metadata object required')
    return value, hashlib.sha256(raw).hexdigest()


def valid_timestamp(value):
    if not isinstance(value, str) or not value:
        return False
    try:
        return datetime.fromisoformat(value).tzinfo is not None
    except ValueError:
        return False


def capture_closure(base, out, score_sha, lock_sha, status_path, status_sha,
                    grant_sha=None, started_sha=None):
    """Bind a real scored terminal seal and strict optional pool-finished observation.

    The pool producer may stop before its next client poll. Missing finished is
    qualified at this capture only and does not assert process exit or an exit code.
    """
    grant_sha = GRANT_SHA if grant_sha is None else grant_sha
    started_sha = STARTED_SHA if started_sha is None else started_sha
    base, out, status_path = Path(base), Path(out), Path(status_path)
    runtime = base/'continuation_v3/runtime'
    grant_path = runtime/'queue/P13_benchmark_continuation3.grant.json'
    started_path = runtime/'queue/P13_benchmark_continuation3.started.json'
    terminal_path = runtime/'terminal_scored_receipt.json'
    finished_path = runtime/'queue/P13_benchmark_continuation3.finished.json'
    grant, observed_grant_sha = snapshot(grant_path)
    started, observed_started_sha = snapshot(started_path)
    terminal, terminal_sha = snapshot(terminal_path)
    score_path = out/'scores.json'
    if (observed_grant_sha != grant_sha or observed_started_sha != started_sha
            or grant.get('authorized') is not True or grant.get('task_id') != 'P13'
            or grant.get('run_id') != RUN or grant.get('phase') != 'benchmark'
            or grant.get('config_sha256') != CONFIG_SHA
            or started.get('task_id') != 'P13' or started.get('phase') != 'benchmark'
            or started.get('grant_sha256') != grant_sha
            or not valid_timestamp(started.get('started_at_pacific'))
            or terminal.get('task_id') != 'P13' or terminal.get('planned') != 3416
            or terminal.get('terminal') != 3416 or terminal.get('score_path') != str(score_path)
            or terminal.get('score_sha256') != score_sha
            or not valid_timestamp(terminal.get('at_pacific'))
            or terminal.get('further_allocation_authorized') is not False):
        raise ValueError('Scored terminal/current grant lineage differs')
    score, captured_score_sha = snapshot(score_path)
    completion_path, lock_path = out/'completion.json', out/'prediction_lock.json'
    completion, completion_sha = snapshot(completion_path)
    lock, captured_lock_sha = snapshot(lock_path)
    status, captured_status_sha = snapshot(status_path)
    if (captured_score_sha != score_sha or captured_lock_sha != lock_sha
            or captured_status_sha != status_sha or status.get('stage') != 'completed'
            or status.get('score_sha256') != score_sha
            or any(value.get('config_sha256') != CONFIG_SHA for value in (score, completion, lock))
            or completion.get('planned') != 3416 or completion.get('terminal') != 3416
            or score.get('planned') != 3416
            or completion.get('prediction_lock_sha256') != lock_sha
            or score.get('prediction_lock_sha256') != lock_sha
            or lock.get('reference_labels_opened') is not False
            or score.get('predictions_locked_before_reference_read') is not True):
        raise ValueError('Scored terminal lacks exact full generation/score seal')
    finished = snapshot(finished_path, missing_allowed=True)
    observation = {'path': str(finished_path), 'observed_at_capture': finished is not None}
    if finished is not None:
        value, digest = finished
        if (set(value) != {'exit_code', 'finished_at_pacific', 'grant_sha256'}
                or type(value['exit_code']) is not int or value['exit_code'] != 0
                or value['grant_sha256'] != grant_sha
                or not valid_timestamp(value['finished_at_pacific'])):
            raise ValueError('Observed pool-finished receipt differs from exact producer/grant')
        observation.update({'sha256': digest, 'exit_code': 0,
                            'finished_at_pacific': value['finished_at_pacific'], 'grant_sha256': grant_sha})
    else:
        observation['qualification'] = ('Pool-finished receipt not observed at this metadata capture; '
            'the original producer can stop before its next client poll. No original pool receipt or exit code is synthesized.')
    return {'role': 'packaging_metadata_snapshot_not_original_pool_finished_receipt',
            'at_pacific': datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
            'task_id': 'P13', 'run_id': RUN, 'config_sha256': CONFIG_SHA,
            'planned': 3416, 'terminal': 3416,
            'score_path': str(score_path), 'score_sha256': score_sha,
            'completion_path': str(completion_path), 'completion_sha256': completion_sha,
            'prediction_lock_path': str(lock_path), 'prediction_lock_sha256': lock_sha,
            'scoring_status_path': str(status_path), 'scoring_status_sha256': status_sha,
            'grant_path': str(grant_path), 'grant_sha256': grant_sha,
            'started_path': str(started_path), 'started_sha256': started_sha,
            'terminal_scored_receipt_path': str(terminal_path), 'terminal_scored_receipt_sha256': terminal_sha,
            'pool_finished_observation': observation, 'new_model_or_score_calls': 0,
            'full_scored_terminal_evidence_verified': True, 'pool_process_exit_independently_verified': False}
