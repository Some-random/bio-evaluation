"""Freeze the exact P13-only publication whitelist after real successor startup.

Never opens scorer targets. No inference, score, assembly or publication calls.
Historical sources reuse the independently accepted 67-source whitelist exactly.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
BASE = ROOT/'.local/catalog_execution_2026-10-20'
HERE = Path(__file__).resolve().parent
OPS = BASE/'continuation_v3/early_drain_operational_rebind_v2'
MANIFEST_SHA = '946924b70894d72b5f0e4d2cfaf1852f68dff62120747c076202cddee6328ff8'
ADMISSION_SHA = 'cf7c2c0705ff2bcd77b648360c39a4b78c390d70a6979b0e21963708c3dff537'
REVIEW_SHA = '98d593fc15a0656645bdc36d2110f88b89739231fc6a8914736f16396e67dde3'
OLD_CONTRACT_SHA = '94e097e82b66126c23106874c6d3f34e7b290c813ed65b0a24b45d79557c3965'
EARLY = ROOT/'.local/independent_runtime_audit_20261023/p13_priority_early_drain'

EXTRA = {
    'continuation3/pool_plan.json': BASE/'continuation_v3/pool_plan.json',
    'continuation3/root_decision.json': BASE/'continuation_v3/root_operational_adoption_20261022.json',
    'continuation3/submission_claim.json': BASE/'continuation_v3/submission_claim.json',
    'continuation3/submission_receipt.json': BASE/'continuation_v3/submission_receipt.json',
    'continuation3/actual_early_drain/operation_manifest.json': EARLY/'operation_manifest.json',
    'continuation3/actual_early_drain/drain_receipt.json': EARLY/'drain_receipt.json',
    'continuation3/actual_early_drain/root_instruction_record.json': EARLY/'root_instruction_record.json',
    'continuation3/actual_early_drain/terminal_closure.json': EARLY/'terminal_closure.json',
    'continuation3/operational/manifest.json': OPS/'manifest.json',
    'continuation3/operational/engineering_admission.json': OPS/'engineering_admission.json',
    'continuation3/operational/engineering_review.json': OPS/'engineering_review.json',
    'continuation3/operational/continue_p13.py': OPS/'continue_p13.py',
    'continuation3/operational/resource_and_priority_binding.py': OPS/'resource_and_priority_binding.py',
    'continuation3/operational/submit_when_capacity.py': OPS/'submit_when_capacity.py',
    'continuation3/operational/pool.sbatch': OPS/'pool.sbatch',
    'continuation3/operational/test_operational_rebind.py': OPS/'test_operational_rebind.py',
    'continuation3/operational/priority_release.json': OPS/'priority_release.json',
    'continuation3/operational/priority_release_admission.json': OPS/'priority_release_admission.json',
    'continuation3/operational/stop_retirement_proposal.json': OPS/'stop_retirement_proposal.json',
    'continuation3/operational/stop_retirement_admission.json': OPS/'stop_retirement_admission.json',
    'continuation3/operational/stop_retirement_receipt.json': OPS/'stop_retirement_receipt.json',
    'continuation3/operational/retired_STOPs/1_STOP_SUBMISSION': OPS/'retired_scheduling_STOPs/1_STOP_SUBMISSION',
    'continuation3/operational/retired_STOPs/2_STOP_SUBMISSION_PRIORITY_V5': OPS/'retired_scheduling_STOPs/2_STOP_SUBMISSION_PRIORITY_V5',
    'continuation3/operational/retired_STOPs/3_STOP_SUBMISSION': OPS/'retired_scheduling_STOPs/3_STOP_SUBMISSION',
    'continuation3/operational/late_drain_for_successor.py': BASE/'continuation_v3/late_drain_for_successor.py',
    'continuation3/operational/test_late_drain.py': BASE/'continuation_v3/test_late_drain.py',
    'continuation3/runtime/predecessor_terminal_receipt.json': BASE/'continuation_v3/runtime/predecessor_terminal_receipt.json',
    'continuation3/runtime/runtime_version_manifest.json': BASE/'continuation_v3/runtime/runtime_version_manifest.json',
    'continuation3/runtime/server_identity.json': BASE/'continuation_v3/runtime/server_identity.json',
    'continuation3/runtime/P13_boundary.json': BASE/'continuation_v3/runtime/P13_boundary.json',
    'continuation3/runtime/P13.grant.json': BASE/'continuation_v3/runtime/queue/P13_benchmark_continuation3.grant.json',
    'continuation3/runtime/P13.started.json': BASE/'continuation_v3/runtime/queue/P13_benchmark_continuation3.started.json',
    'continuation3/publication/prepare_source_contract.py': HERE/'prepare_source_contract.py',
    'continuation3/publication/watch_assembly.py': HERE/'watch_assembly.py',
    'continuation3/publication/test_assembly.py': HERE/'test_assembly.py',
    'continuation3/publication/test_readiness.py': HERE/'test_readiness.py',
    'continuation3/publication/terminal_metadata.py': HERE/'terminal_metadata.py',
    'continuation3/resource_source/exact_external_jobs_adapter_v4.py': ROOT/'.local/resource_accounting_20261022/exact_external_jobs_adapter_v4.py',
    'continuation3/resource_source/exact_external_jobs_adapter_v3.py': ROOT/'.local/resource_accounting_20261022/exact_external_jobs_adapter_v3.py',
    'continuation3/resource_source/exact_external_jobs_adapter_v2.py': ROOT/'.local/resource_accounting_20261022/exact_external_jobs_adapter_v2.py',
    'continuation3/resource_source/exact_external_jobs_adapter_v1.py': ROOT/'.local/resource_accounting_20261022/exact_external_jobs_adapter_v1.py',
}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def main():
    old_path = BASE/'continuation_v2/publication_source_contract_v2.json'
    if sha(old_path) != OLD_CONTRACT_SHA:
        raise ValueError('Historical reviewed publication contract changed')
    for filename, expected in [('manifest.json', MANIFEST_SHA),
                               ('engineering_admission.json', ADMISSION_SHA),
                               ('engineering_review.json', REVIEW_SHA)]:
        if sha(OPS/filename) != expected:
            raise ValueError('Current admitted operational source changed')
    manifest = read(OPS/'manifest.json')
    expected = dict(manifest['files_sha256'])
    old = read(old_path)
    sources = dict(old['sources'])
    for name, row in sources.items():
        p = ROOT/row['path']
        if p.is_symlink() or sha(p) != row['sha256'] or p.stat().st_size != row['bytes']:
            raise ValueError('Historical approved source changed: '+name)
    config_path = BASE/'tasks/P13/test_config.json'
    config = read(config_path)
    target = (ROOT/config['scorer_reference_file']).resolve()
    for name, p in EXTRA.items():
        if (name in sources or p.is_symlink() or not p.is_file()
                or p.resolve() == target or not p.resolve().is_relative_to(ROOT)
                or p.name in {'startup_gpu_audit.json','last_safe_gpu_audit.json'}):
            raise ValueError('Absent, duplicate, foreign or forbidden source: '+name)
        digest = sha(p)
        if str(p) in expected and digest != expected[str(p)]:
            raise ValueError('Current frozen source changed: '+name)
        sources[name] = {'path':str(p.relative_to(ROOT)), 'sha256':digest, 'bytes':p.stat().st_size}
    runtime = BASE/'continuation_v3/runtime'
    grant = read(runtime/'queue/P13_benchmark_continuation3.grant.json')
    identity = read(runtime/'server_identity.json')
    boundary = read(runtime/'P13_boundary.json')
    if (grant['task_id'] != 'P13' or grant['config_sha256'] != sha(config_path)
            or grant['continuation_boundary_sha256'] != sha(runtime/'P13_boundary.json')
            or grant['server_identity_sha256'] != sha(runtime/'server_identity.json')
            or identity['job_id'] != '249544'
            or boundary.get('config_sha256') != grant['config_sha256']):
        raise ValueError('Actual current successor provenance differs')
    payload = {'task_id':'P13','purpose':'explicit complete P13 scientific/source/trajectory publication whitelist; no execution authority',
               'reviewed_manifest_sha256':MANIFEST_SHA,'engineering_admission_sha256':ADMISSION_SHA,
               'engineering_review_sha256':REVIEW_SHA,'historical_contract_sha256':OLD_CONTRACT_SHA,
               'sources':dict(sorted(sources.items())), 'scorer_target_values_included':False,
               'full_account_metadata_included':False,'weights_credentials_or_environment_archives_included':False,
               'unrelated_job_proofs_or_other_task_inputs_included':False,
               'current_successor_job_id':'249544','full_planned_denominator':3416,
               'four_historical_ambiguous_outcomes_preserved_invalid':True}
    output = HERE/'source_contract.json'
    with output.open('x') as stream:
        json.dump(payload,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps({'source_count':len(sources),'sha256':sha(output)}))


if __name__ == '__main__':
    main()
