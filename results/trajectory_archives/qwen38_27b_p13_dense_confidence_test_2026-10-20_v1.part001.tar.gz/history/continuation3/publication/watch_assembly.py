"""Wait for a completed score status before the sole CPU packaging claim.

No inference, references, scoring, aggregate report edits, or publication.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
BASE = ROOT / '.local/catalog_execution_2026-10-20'
OUT = BASE / 'tasks/P13/runtime/benchmark'
CONFIG_SHA = 'd3915c12cb72599cd5c2a0737bfa3fd72c0705fe4819e688ebd5493adede80dc'
METADATA_SHA = '1c9203179bd78357d1b8eca8c6cf2768996082693396d0f505331895dbf5a1e5'


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


if sha(HERE/'terminal_metadata.py') != METADATA_SHA:
    raise ValueError('Frozen packaging-only metadata helper changed')
spec = importlib.util.spec_from_file_location('p13_packaging_terminal_metadata', HERE/'terminal_metadata.py')
metadata = importlib.util.module_from_spec(spec)
spec.loader.exec_module(metadata)


def write(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def stamp():
    return datetime.datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def readiness(out=OUT, status_path=BASE / 'control/P13_scoring_status.json'):
    """Inspect metadata only; return None until the final status is durable."""
    paths = {name: Path(out) / name for name in ('scores.json', 'completion.json', 'prediction_lock.json')}
    if not Path(status_path).is_file() or not all(path.is_file() for path in paths.values()):
        return None
    status = json.loads(Path(status_path).read_text())
    if status.get('stage') != 'completed':
        return None
    score_sha = sha(paths['scores.json'])
    if status.get('score_sha256') != score_sha:
        raise ValueError('Completed score status has a different score hash')
    score = json.loads(paths['scores.json'].read_text())
    done = json.loads(paths['completion.json'].read_text())
    lock = json.loads(paths['prediction_lock.json'].read_text())
    lock_sha = sha(paths['prediction_lock.json'])
    if (any(value.get('config_sha256') != CONFIG_SHA for value in (score, done, lock))
            or done.get('planned') != 3416 or done.get('terminal') != 3416
            or score.get('planned') != 3416
            or done.get('prediction_lock_sha256') != lock_sha
            or score.get('prediction_lock_sha256') != lock_sha
            or lock.get('reference_labels_opened') is not False
            or score.get('predictions_locked_before_reference_read') is not True):
        raise ValueError('Completed score lacks the exact full frozen generation seal')
    terminal_path=BASE/'continuation_v3/runtime/terminal_scored_receipt.json'
    if not terminal_path.is_file():return None
    closure=metadata.capture_closure(BASE, out, score_sha, lock_sha, status_path, sha(status_path))
    return {'score_sha256': score_sha, 'score_path': closure['score_path'],
            'prediction_lock_sha256': lock_sha, 'scoring_status_sha256': sha(status_path),
            'terminal_scored_receipt_sha256': closure['terminal_scored_receipt_sha256'],
            'grant_sha256': closure['grant_sha256'], 'started_sha256': closure['started_sha256'],
            'packaging_closure': closure}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--assembler-sha256', required=True)
    args = parser.parse_args()
    start = time.monotonic()
    status_path = HERE / 'watcher_status.json'
    try:
        while time.monotonic() - start < 72 * 3600:
            if (HERE / 'STOP_ASSEMBLY').exists():
                write(status_path, {'stage': 'stopped_by_owner', 'at_pacific': stamp(),
                                    'new_model_or_score_calls': 0})
                return
            if sha(HERE / 'assemble_publication.py') != args.assembler_sha256:
                raise ValueError('Frozen assembler source changed')
            evidence = readiness()
            if evidence is not None:
                claim = HERE / 'publication_assembly_claim.json'
                if claim.exists():
                    write(status_path, {'stage': 'prior_assembly_claim_preserved', 'at_pacific': stamp(),
                                        'new_model_or_score_calls': 0})
                    return
                with claim.open('x') as stream:
                    json.dump({'at_pacific': stamp(), 'assembler_sha256': args.assembler_sha256,
                               **evidence, 'new_model_or_score_calls': 0}, stream)
                    stream.flush()
                    os.fsync(stream.fileno())
                with (HERE / 'publication_assembly.log').open('xb') as log:
                    result = subprocess.run(['/usr/bin/python3', str(HERE / 'assemble_publication.py')],
                                            cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=7200)
                write(status_path, {'stage': 'assembled_for_independent_publication_review'
                                    if result.returncode == 0 else 'assembly_failed_no_retry',
                                    'at_pacific': stamp(), 'exit_code': result.returncode,
                                    'publication_authorized': False, 'new_model_or_score_calls': 0})
                return
            write(status_path, {'stage': 'waiting_for_completed_native_score_status',
                                'at_pacific': stamp(), 'pid': os.getpid(),
                                'new_model_or_score_calls': 0, 'automatic_publication': False})
            time.sleep(60)
        write(status_path, {'stage': 'bounded_wait_expired_without_assembly', 'at_pacific': stamp(),
                            'new_model_or_score_calls': 0})
    except Exception as error:
        write(status_path, {'stage': 'stopped_metadata_or_assembly_error_no_retry', 'at_pacific': stamp(),
                            'error_type': type(error).__name__, 'error': str(error),
                            'new_model_or_score_calls': 0, 'publication_authorized': False})
        raise


if __name__ == '__main__':
    main()
