"""Submit exactly one admitted P13 continuation when safe capacity exists."""
import argparse
import datetime
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import time
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')


def load():
    spec = importlib.util.spec_from_file_location('p13_frozen_successor', HERE / 'continue_p13.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def create(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    parent_fd = os.open(Path(path).parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(parent_fd)
    finally:
        os.close(parent_fd)


def submit_once(manifest_path, manifest_sha):
    c = load()
    m = c.validate_manifest(manifest_path, manifest_sha)
    c.validate_admission(m, manifest_sha)
    try:
        predecessor = c.predecessor_terminal(m['original_job_id'])
    except ValueError as error:
        if 'has not finished:' not in str(error):
            raise
        return {'stage': 'waiting_for_predecessor_terminal', 'predecessor_job_id': m['original_job_id']}
    # Lock freedom is checked before requesting another GPU and again before model calls.
    output = Path(m['output_folder'])
    with (output / '.runner.lock').open('a') as runner_lock:
        try:
            fcntl.flock(runner_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return {'stage': 'waiting_for_predecessor_runner_lock'}
        if (output / 'completion.json').exists():
            return {'stage': 'terminal_without_new_allocation', 'completion_sha256': c.sha(output / 'completion.json')}
    with (ROOT / '.local/evaluation_GPU_submission.lock').open('a') as cap_lock:
        fcntl.flock(cap_lock, fcntl.LOCK_EX)
        if (HERE / 'submission_claim.json').exists():
            raise ValueError('Submission already claimed; never replay')
        spec = importlib.util.spec_from_file_location('p13_submission_GPU_audit', m['gpu_audit_helper'])
        audit = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(audit)
        try:
            observation = audit.conservative_project_gpu_audit(additional_gpus=1)
        except ValueError as error:
            if str(error) == 'Evaluation project GPU requests exceed eight':
                return {'stage': 'waiting_capacity', 'reason': str(error)}
            raise
        c.write(HERE / 'last_safe_gpu_audit.json', observation)
        # Revalidate every frozen support byte immediately before the single attempt.
        c.validate_manifest(manifest_path, manifest_sha)
        c.validate_admission(m, manifest_sha)
        command = ['sbatch', '--parsable', '--dependency=afterany:' + m['original_job_id'],
                   str(HERE / 'pool.sbatch'), manifest_sha]
        create(HERE / 'submission_claim.json', {'at_pacific': c.stamp(), 'manifest_sha256': manifest_sha,
               'command': command, 'predecessor_state': predecessor,
               'GPU_audit_sha256': c.sha(HERE / 'last_safe_gpu_audit.json'), 'automatic_replay': False})
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=60)
        except Exception as error:
            create(HERE / 'submission_uncertain.json', {'at_pacific': c.stamp(), 'type': type(error).__name__,
                                                       'automatic_replay': False})
            raise
        stdout = result.stdout.strip()
        valid = result.returncode == 0 and re.fullmatch(r'[0-9]+(?:;[A-Za-z0-9_.-]+)?', stdout)
        receipt = {'at_pacific': c.stamp(), 'stage': 'submitted' if valid else 'failed_or_uncertain_no_retry',
                   'manifest_sha256': manifest_sha, 'returncode': result.returncode,
                   'job_id': stdout.split(';')[0] if valid else None,
                   'stdout': stdout, 'stderr': result.stderr, 'new_GPU_requests': 1,
                   'automatic_further_allocations': False, 'automatic_replay': False}
        create(HERE / 'submission_receipt.json', receipt)
        if not valid:
            raise RuntimeError('One submission attempt failed or uncertain; no replay')
        return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--once', action='store_true')
    args = parser.parse_args()
    c = load()
    with (HERE / 'capacity_waiter.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        while not (HERE / 'STOP_SUBMISSION').exists():
            try:
                state = submit_once(args.manifest, args.manifest_sha256)
                c.write(HERE / 'capacity_waiter_status.json', dict(state, at_pacific=c.stamp(), pid=os.getpid(),
                        new_inference_calls=0, count_source='fresh_locked_conservative_all_project_GPU_accounting'))
                if state['stage'] in {'submitted', 'terminal_without_new_allocation'} or args.once:
                    return
            except Exception as error:
                c.write(HERE / 'capacity_waiter_error.json', {'at_pacific': c.stamp(), 'pid': os.getpid(),
                        'type': type(error).__name__, 'error': str(error), 'automatic_replay': False})
                raise
            time.sleep(30)


if __name__ == '__main__':
    main()
