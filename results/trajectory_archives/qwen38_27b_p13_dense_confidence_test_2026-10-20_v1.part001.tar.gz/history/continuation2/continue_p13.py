#!/usr/bin/env python3
"""One bounded P13-only operational successor; every scientific byte stays frozen."""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import socket
import stat
import subprocess
import sys
import threading
import time
from types import SimpleNamespace
from zoneinfo import ZoneInfo

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
BASE = ROOT / '.local/catalog_execution_2026-10-20'
SCOPE = ('P13',)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def stamp():
    return datetime.datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, data):
    p = Path(path)
    temp = p.with_suffix(p.suffix + '.tmp')
    temp.write_text(json.dumps(data, indent=2) + '\n')
    temp.replace(p)


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate_manifest(path, digest):
    if sha(path) != digest:
        raise ValueError('Continuation manifest hash changed')
    m = read(path)
    if sha(__file__) != m['wrapper_sha256'] or tuple(m['task_ids']) != SCOPE:
        raise ValueError('Continuation wrapper or task scope changed')
    if m['original_job_id'] != '243499' or m['extra_simultaneous_gpus'] != 0:
        raise ValueError('Unexpected predecessor or GPU scope')
    for path, expected in m['files_sha256'].items():
        if sha(path) != expected:
            raise ValueError('Changed frozen continuation support: ' + path)
    decision = read(m['root_decision'])
    if (decision['task_id'] != 'P13' or decision['predecessor_job_id'] != '243499'
            or decision['maximum_walltime_hours'] != 24
            or decision['automatic_further_allocations'] is not False):
        raise ValueError('Bounded root decision differs')
    original = read(m['original_pool_plan'])
    successor = read(m['pool_plan'])
    expected = dict(original, queue_root=str(Path(m['runtime_root']) / 'queue'),
                    authorized_task_ids=list(SCOPE))
    if successor != expected:
        raise ValueError('Successor changes frozen model, runtime or serving parameters')
    entries = read(m['dispatch_plan'])['tasks']
    for e in entries:
        if e['task_id'] not in SCOPE:
            continue
        for pathkey, hashkey in [('runner', 'runner_sha256'), ('benchmark_config', 'benchmark_config_sha256'),
                                 ('development_config', 'development_config_sha256'), ('scorer', 'scorer_sha256')]:
            if sha(e[pathkey]) != e[hashkey]:
                raise ValueError('Frozen task changed: ' + e['task_id'])
    return m


def validate_admission(manifest, digest):
    grant = read(manifest['engineering_admission'])
    if (grant.get('approved') is not True or grant.get('manifest_sha256') != digest
            or grant.get('issuer') not in ['/root/independent_review', '/root/new2026_bixbench']
            or grant.get('task_ids') != ['P13']
            or grant.get('root_decision_sha256') != sha(manifest['root_decision'])
            or grant.get('maximum_new_GPU_allocations') != 1):
        raise ValueError('Exact independent plan-bound engineering admission required')


def predecessor_terminal(job_id):
    if job_id != '243499':
        raise ValueError('Only exact predecessor243499 is authorized')
    terminal = {'COMPLETED', 'TIMEOUT', 'CANCELLED', 'FAILED', 'NODE_FAIL',
                'PREEMPTED', 'BOOT_FAIL', 'OUT_OF_MEMORY', 'DEADLINE'}
    result = subprocess.run(['scontrol', 'show', 'job', '-o', job_id],
                            capture_output=True, text=True, timeout=30)
    if result.returncode == 0 and result.stdout.strip():
        fields = dict(re.findall(r'(?:^|\s)(JobId|JobState|WorkDir|Command)=(\S+)', result.stdout))
        if (fields.get('JobId') != job_id or fields.get('WorkDir') != str(ROOT)
                or fields.get('Command') != str(BASE / 'continuation_v1/pool.sbatch')):
            raise ValueError('Exact predecessor project ownership differs')
        state = fields.get('JobState')
        if state not in terminal:
            raise ValueError('Predecessor has not finished: ' + str(state))
        return state
    # Slurm purges its live cache; missing live metadata alone proves nothing.
    result = subprocess.run(['sacct', '-n', '-P', '-X', '-j', job_id,
                             '--format=JobIDRaw,State,WorkDir%300'],
                            capture_output=True, text=True, timeout=30)
    rows = [line.split('|') for line in result.stdout.splitlines() if line.strip()]
    exact = [row for row in rows if len(row) >= 3 and row[0] == job_id]
    if result.returncode or len(exact) != 1 or len(rows) != 1:
        raise ValueError('Cannot verify unique terminal predecessor accounting')
    row = exact[0]
    state = row[1].split()[0].rstrip('+')
    if row[2] != str(ROOT):
        raise ValueError('Predecessor accounting project ownership differs')
    if state not in terminal:
        raise ValueError('Predecessor has not finished: ' + state)
    return state


def snapshot_boundary(folder, config_sha):
    """Read only after the predecessor is terminal and the runner lock is free."""
    folder = Path(folder)
    if (folder / 'completion.json').exists():
        return None
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / '.runner.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        restoration = restore_drained_request_permission(folder, config_sha)
        if (folder / 'run_manifest.json').exists():
            if read(folder / 'run_manifest.json')['config_sha256'] != config_sha:
                raise ValueError('Existing output belongs to another condition')
        progress = read(folder / 'progress.json') if (folder / 'progress.json').exists() else {}
        for key in ('transport_errors', 'http_errors', 'response_errors', 'refusals'):
            if progress.get(key, 0):
                raise ValueError('Existing task needs review after error: ' + key)
        files = {}
        for category in ('requests', 'responses', 'outcomes', 'errors'):
            for p in sorted((folder / category).glob('*')):
                if p.is_file():
                    files[str(p.relative_to(folder))] = sha(p)
        if (folder / 'run_manifest.json').exists():
            files['run_manifest.json'] = sha(folder / 'run_manifest.json')
        return {'at_pacific': stamp(), 'config_sha256': config_sha,
                'existing_files_sha256': files, 'previous_progress_observation': progress,
                'request_permission_restoration': restoration,
                'never_retry_attempted_requests': True,
                'missing_outcomes_for_existing_requests_remain_ambiguous': True}


def restore_drained_request_permission(folder, config_sha):
    """Only after predecessor termination and lock acquisition, restore a recorded owner drain."""
    receipt = BASE / 'continuation_v1/request_permission_drain.json'
    if not receipt.exists():
        return None
    rows = read(receipt)['tasks']
    matches = [row for row in rows if row['output_folder'] == str(Path(folder).resolve())]
    if not matches:
        return None
    if len(matches) != 1:
        raise ValueError('Ambiguous request permission restoration')
    row = matches[0]
    allowed = [BASE / 'tasks' / task / 'runtime/benchmark' for task in SCOPE]
    request_dir = Path(folder) / 'requests'
    if (Path(folder).resolve() not in allowed or row['config_sha256'] != config_sha
            or row['original_mode'] != 0o700 or row['blocked_mode'] != 0o500
            or request_dir.stat().st_uid != os.getuid()):
        raise ValueError('Drain receipt scope, config, ownership or permissions differ')
    mode = stat.S_IMODE(request_dir.stat().st_mode)
    if mode not in {row['original_mode'], row['blocked_mode']}:
        raise ValueError('Unexpected requests directory permissions')
    if mode == row['blocked_mode']:
        request_dir.chmod(row['original_mode'])
    return {'at_pacific': stamp(), 'receipt_sha256': sha(receipt),
            'original_mode_restored': row['original_mode'], 'historical_files_changed': False}


def verify_boundary(folder, boundary):
    for name, expected in boundary['existing_files_sha256'].items():
        if sha(Path(folder) / name) != expected:
            raise ValueError('Historical output changed across continuation: ' + name)


def identity_valid(m, identity):
    plan = read(m['pool_plan'])
    if (identity['model'] != plan['model'] or identity['revision'] != plan['revision']
            or identity['dtype'] != 'bfloat16' or identity['dedicated_gpu_count'] != 1
            or identity['max_model_len'] != 65536
            or identity['job_id'] != os.environ.get('SLURM_JOB_ID')
            or identity['job_id'] == m['original_job_id']
            or identity['hostname'] != socket.gethostname()):
        raise ValueError('Successor server identity differs from the frozen baseline')
    ticks = Path('/proc').joinpath(str(identity['pid']), 'stat').read_text().rsplit(')', 1)[1].split()[19]
    if ticks != identity['proc_start_ticks']:
        raise ValueError('Successor server process identity changed')
    runtime = read(Path(m['runtime_root']) / 'runtime_version_manifest.json')
    if (runtime['packages'] != m['runtime_versions']['packages']
            or runtime['python'] != m['runtime_versions']['python']
            or runtime['torch_cuda'] != m['runtime_versions']['torch_cuda']):
        raise ValueError('Successor packages or CUDA runtime differ from the frozen condition')


def create_grant(m, entry, identity, boundary):
    runtime = Path(m['runtime_root'])
    identity_file = runtime / 'server_identity.json'
    task = entry['task_id']
    output = BASE / 'tasks' / task / 'runtime/benchmark'
    grant_path = runtime / 'queue' / (task + '_benchmark_continuation2.grant.json')
    development = output.parent / 'development/completion.json'
    value = {'authorized': True, 'task_id': task, 'run_id': read(entry['benchmark_config'])['run_id'],
             'phase': 'benchmark', 'runner': entry['runner'], 'runner_sha256': entry['runner_sha256'],
             'config': entry['benchmark_config'], 'config_sha256': entry['benchmark_config_sha256'],
             'endpoint': identity['endpoint'], 'server_identity_file': str(identity_file),
             'server_identity_sha256': sha(identity_file), 'development_completion': str(development),
             'development_completion_sha256': sha(development), 'created_at_pacific': stamp(),
             'original_job_id': m['original_job_id'], 'historical_results_immutable': True,
             'continuation_boundary_sha256': sha(runtime / (task + '_boundary.json')),
             'argv': ['--config', entry['benchmark_config'], '--output', str(output),
                      '--grant', str(grant_path), '--development-completion', str(development),
                      '--concurrency', str(entry.get('concurrency', 4)), '--resume-unattempted']}
    with grant_path.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')


def score_one(m, entry, manifest_path, manifest_sha):
    task = entry['task_id']
    score_path = Path(entry['score_output'])
    status = BASE / 'control' / (task + '_scoring_status.json')
    if score_path.exists():
        return
    if status.exists():
        raise ValueError('Existing native scoring attempt needs separate review')
    completion = read(score_path.parent / 'completion.json')
    if completion['terminal'] != completion['planned']:
        return
    with (score_path.parent / '.runner.lock').open('a') as runner_lock:
        fcntl.flock(runner_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if score_path.exists() or status.exists():
            raise ValueError('Scoring race requires review')
        with status.open('x') as f:
            json.dump({'stage': 'one_attempt_started', 'started_at_pacific': stamp(),
                       'prediction_lock_sha256': sha(score_path.parent / 'prediction_lock.json'),
                       'continuation_job_id': os.environ['SLURM_JOB_ID']}, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
        with (BASE / 'control' / (task + '_scoring.log')).open('x') as log:
            result = subprocess.run(['/usr/bin/python3', __file__, '--manifest', str(manifest_path),
                                     '--manifest-sha256', manifest_sha, '--score', task],
                                    cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
        write(status, {'stage': 'completed' if result.returncode == 0 and score_path.exists() else 'failed_no_retry',
                       'finished_at_pacific': stamp(), 'exit_code': result.returncode,
                       'score_sha256': sha(score_path) if score_path.exists() else None})
        if result.returncode or not score_path.exists():
            raise ValueError('One native scoring entry failed; no automatic retry')


def control(m, manifest_path, manifest_sha, done):
    runtime = Path(m['runtime_root'])
    entries = [e for e in read(m['dispatch_plan'])['tasks'] if e['task_id'] in SCOPE]
    errors = {}
    while not done.is_set():
        try:
            state = read(runtime / 'status.json') if (runtime / 'status.json').exists() else {}
            if state.get('stage') == 'serving_task_queue':
                identity = read(runtime / 'server_identity.json')
                identity_valid(m, identity)
                for e in entries:
                    task = e['task_id']
                    output = BASE / 'tasks' / task / 'runtime/benchmark'
                    grant = runtime / 'queue' / (task + '_benchmark_continuation2.grant.json')
                    if (output / 'completion.json').exists():
                        boundary_path = runtime / (task + '_boundary.json')
                        if boundary_path.exists():
                            verify_boundary(output, read(boundary_path))
                        completion = read(output / 'completion.json')
                        if completion['terminal'] != completion['planned']:
                            raise ValueError('Runner sealed incomplete condition; no retry')
                        score_one(m, e, manifest_path, manifest_sha)
                        write(runtime / 'terminal_scored_receipt.json', {
                            'at_pacific': stamp(), 'task_id': task, 'planned': completion['planned'],
                            'terminal': completion['terminal'], 'score_path': e['score_output'],
                            'score_sha256': sha(e['score_output']), 'further_allocation_authorized': False})
                        (runtime / 'STOP').touch()
                    elif grant.exists():
                        finished = grant.with_name(grant.name.replace('.grant.json', '.finished.json'))
                        rejected = grant.with_name(grant.name.replace('.grant.json', '.rejected.json'))
                        if finished.exists() or rejected.exists():
                            raise ValueError('Runner ended without complete seal; preserve and review')
                    elif task not in errors:
                        try:
                            boundary = snapshot_boundary(output, e['benchmark_config_sha256'])
                            if boundary is not None:
                                write(runtime / (task + '_boundary.json'), boundary)
                                create_grant(m, e, identity, boundary)
                        except (ValueError, BlockingIOError) as exc:
                            errors[task] = str(exc)
                write(runtime / 'continuation_control_status.json', {
                    'at_pacific': stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
                    'stage': 'watching_unchanged_task_conditions', 'held_tasks': errors,
                    'task_ids': list(SCOPE), 'new_inference_calls_by_controller': 0})
        except OSError:
            pass
        except Exception as exc:
            write(runtime / 'continuation_control_error.json', {
                'at_pacific': stamp(), 'error_type': type(exc).__name__, 'error': str(exc)})
            (runtime / 'STOP').touch()
            return
        done.wait(15)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--score', choices=SCOPE)
    args = parser.parse_args()
    m = validate_manifest(args.manifest, args.manifest_sha256)
    validate_admission(m, args.manifest_sha256)
    predecessor = None if args.score else predecessor_terminal(m['original_job_id'])
    if not os.environ.get('SLURM_JOB_ID') or os.environ['SLURM_JOB_ID'] == m['original_job_id']:
        raise ValueError('A separate dependent one-GPU allocation is required')
    runtime = Path(m['runtime_root'])
    if args.score:
        helper = load_module(m['scoring_helper'], 'continuation_frozen_scoring_helper')
        helper.BASE = runtime.parent
        sys.argv = [m['scoring_helper'], '--plan', m['dispatch_plan'],
                    '--plan-sha256', m['dispatch_plan_sha256'], '--task', args.score]
        helper.main()
        return
    audit = load_module(m['gpu_audit_helper'], 'frozen_P13_followon_GPU_audit')
    observation = audit.conservative_project_gpu_audit(require_own_job=True)
    runtime.mkdir(parents=True, exist_ok=True)
    write(runtime / 'startup_gpu_audit.json', observation)
    (runtime / 'queue').mkdir(exist_ok=True)
    write(runtime / 'predecessor_terminal_receipt.json', {
        'at_pacific': stamp(), 'original_job_id': m['original_job_id'],
        'original_job_state': predecessor, 'successor_job_id': os.environ['SLURM_JOB_ID'],
        'new_inference_calls': 0})
    pool = load_module(m['pool_worker'], 'continuation_frozen_pool_worker')
    pool.BASE = runtime
    def stop(signum, frame):
        raise SystemExit('Stopped by Slurm or operator')
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    done = threading.Event()
    thread = threading.Thread(target=control, args=(m, args.manifest, args.manifest_sha256, done), daemon=True)
    thread.start()
    try:
        pool.execute(SimpleNamespace(plan=Path(m['pool_plan']), plan_sha256=m['pool_plan_sha256']))
    finally:
        done.set()
        thread.join(timeout=30)


if __name__ == '__main__':
    main()
