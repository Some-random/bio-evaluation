"""Synthetic-only boundary, admission, once-only scoring and cap gates."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
sys.path.insert(0, str(ROOT / 'scripts'))
sys.path.insert(0, str(ROOT / 'tests'))
spec = importlib.util.spec_from_file_location('p13_successor', HERE / 'continue_p13.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
spec = importlib.util.spec_from_file_location('p13_waiter', HERE / 'submit_when_capacity.py')
w = importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)
from test_continue_seven_catalog_20261020 import ContinuationTests

class P13ContinuationTests(unittest.TestCase):
    def test_active_predecessor_blocks(self):
        with patch.object(c.subprocess, 'run', return_value=SimpleNamespace(returncode=0, stdout='JobId=243499 JobState=RUNNING WorkDir=' + str(ROOT) + ' Command=' + str(ROOT / '.local/catalog_execution_2026-10-20/continuation_v1/pool.sbatch'))):
            with self.assertRaisesRegex(ValueError, 'has not finished'):
                c.predecessor_terminal('243499')

    def test_terminal_accounting_fallback_and_ambiguity(self):
        absent=SimpleNamespace(returncode=1,stdout='')
        good=SimpleNamespace(returncode=0,stdout='243499|TIMEOUT|'+str(ROOT)+'|\n')
        with patch.object(c.subprocess,'run',side_effect=[absent,good]):
            self.assertEqual(c.predecessor_terminal('243499'),'TIMEOUT')
        for output in ['', '243499|RUNNING|'+str(ROOT)+'|\n',
                       '243499|TIMEOUT|/other|\n',
                       '243499|TIMEOUT|'+str(ROOT)+'|\n243499|TIMEOUT|'+str(ROOT)+'|\n']:
            with patch.object(c.subprocess,'run',side_effect=[absent,SimpleNamespace(returncode=0,stdout=output)]):
                with self.assertRaises(ValueError): c.predecessor_terminal('243499')

    def test_exact_independent_admission(self):
        value = {'approved': True, 'manifest_sha256':'fixed', 'issuer':'/root/independent_review',
                 'task_ids':['P13'], 'root_decision_sha256':'decision', 'maximum_new_GPU_allocations':1}
        with patch.object(c, 'read', return_value=value), patch.object(c, 'sha', return_value='decision'):
            c.validate_admission({'engineering_admission':'grant','root_decision':'root'}, 'fixed')
            with self.assertRaises(ValueError):
                c.validate_admission({'engineering_admission':'grant','root_decision':'root'}, 'changed')
            value['issuer'] = '/root/deepfri_p13_completion'
            with self.assertRaises(ValueError):
                c.validate_admission({'engineering_admission':'grant','root_decision':'root'}, 'fixed')

    def test_no_native_scorer_reentry_when_prior_claim_exists(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d); (base/'control').mkdir()
            (base/'control/P13_scoring_status.json').write_text('{"stage":"failed_no_retry"}')
            with patch.object(c,'BASE',base):
                with self.assertRaisesRegex(ValueError, 'needs separate review'):
                    c.score_one({}, {'task_id':'P13','score_output':str(base/'scores.json')}, 'manifest', 'digest')

    def test_boundary_preserves_historical_and_ambiguous_requests(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d); (out/'requests').mkdir()
            (out/'requests/attempt.json').write_text('{}')
            boundary=c.snapshot_boundary(out,'fixed')
            self.assertIn('requests/attempt.json',boundary['existing_files_sha256'])
            self.assertTrue(boundary['missing_outcomes_for_existing_requests_remain_ambiguous'])
            c.verify_boundary(out,boundary)
            (out/'requests/attempt.json').write_text('changed')
            with self.assertRaises(ValueError): c.verify_boundary(out,boundary)

    def test_once_only_claim_and_durable_parent(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'claim.json'
            w.create(p,{'synthetic':True})
            with self.assertRaises(FileExistsError): w.create(p,{})

    def test_waiting_predecessor_never_allocates(self):
        fake=SimpleNamespace(validate_manifest=lambda*a:{'original_job_id':'243499'},
                             validate_admission=lambda*a:None,
                             predecessor_terminal=lambda*a:(_ for _ in ()).throw(ValueError('Predecessor has not finished: RUNNING')))
        with patch.object(w,'load',return_value=fake),patch.object(w.subprocess,'run',side_effect=AssertionError('must not submit')):
            self.assertEqual(w.submit_once('manifest','fixed')['stage'],'waiting_for_predecessor_terminal')

if __name__=='__main__': unittest.main()
