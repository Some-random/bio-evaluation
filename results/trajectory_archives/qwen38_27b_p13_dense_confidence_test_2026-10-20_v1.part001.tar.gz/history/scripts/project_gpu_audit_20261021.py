"""Read-only Slurm GPU accounting for this evaluation project's eight-GPU cap.

Keep the complete account inventory in private operational receipts. Exclude
only exact job/workdir/command identities independently verified as unrelated.
Unknown or changing identities remain counted. This module never allocates or
stops a job, reads job environments, or performs model inference.
"""
from datetime import datetime
import json
import os
from pathlib import Path
import re
import subprocess
from zoneinfo import ZoneInfo

PROJECT = Path('/dfs/scratch0/dongweij/bio-evaluation')
REVIEWED_UNRELATED = {
    '244121': ('/dfs/scratch0/dongweij/paper-extraction-lab',
               '/dfs/scratch0/dongweij/paper-extraction-lab/scripts/run_b200_four_gpu_confirmation_2026-10-20.sbatch'),
    '245115': ('/dfs/scratch0/dongweij/paper-extraction-lab',
               '/dfs/scratch0/dongweij/paper-extraction-lab/scripts/run_web_biology_parallel_b200_2026-10-21.sbatch'),
    '245143': ('/dfs/scratch0/dongweij/paper-extraction-lab',
               '/dfs/scratch0/dongweij/paper-extraction-lab/scripts/run_web_biology_parallel_rtx4_bound_2026-10-21.sbatch'),
}


def field(raw, name):
    match = re.search(r'(?:^|\s)' + re.escape(name) + r'=([^\s]+)', raw)
    return match.group(1) if match else None


def classify_row(job_id, name, state, gpu_request, raw):
    requested = field(raw, 'ReqTRES')
    match = re.search(r'(?:^|,)gres/gpu=(\d+)(?:,|$)', requested or '')
    if match:
        gpus = int(match.group(1))
    else:
        counts = re.findall(r'gpu(?::[A-Za-z][A-Za-z0-9_.-]*)?:(\d+)', gpu_request)
        nodes = field(raw, 'NumNodes')
        if not counts or not nodes or not nodes.isdigit():
            raise ValueError('GPU accounting unavailable or ambiguous for job ' + job_id)
        gpus = sum(map(int, counts)) * int(nodes)
    if gpus < 1:
        raise ValueError('Expected a positive GPU request for job ' + job_id)
    workdir, command = field(raw, 'WorkDir'), field(raw, 'Command')
    excluded = (job_id in REVIEWED_UNRELATED and
                (workdir, command) == REVIEWED_UNRELATED[job_id])
    return {'job_id': job_id, 'name': name, 'state': state, 'gpus': gpus,
            'workdir': workdir, 'command': command,
            'counted_toward_evaluation_project': not excluded,
            'scope_basis': 'exact_root_verified_unrelated_job_and_paths' if excluded
                           else 'project_or_unknown_conservatively_counted'}


def evaluate_inventory(jobs, own_job_id=None, additional_gpus=0):
    if type(additional_gpus) is not int or additional_gpus < 0:
        raise ValueError('Invalid additional GPU request')
    total = sum(row['gpus'] for row in jobs)
    project = sum(row['gpus'] for row in jobs if row['counted_toward_evaluation_project'])
    if project + additional_gpus > 8:
        raise ValueError('Evaluation project GPU requests exceed eight')
    if own_job_id is not None:
        own = [row for row in jobs if row['job_id'] == str(own_job_id)]
        if len(own) != 1 or own[0]['gpus'] != 1 or not own[0]['counted_toward_evaluation_project']:
            raise ValueError('Actual own one-GPU project allocation is missing')
        if own[0]['state'] not in {'RUNNING', 'COMPLETING'}:
            raise ValueError('Own Slurm allocation is not running')
        for key in ('workdir', 'command'):
            value = own[0].get(key)
            if not value or not Path(value).is_relative_to(PROJECT):
                raise ValueError('Own allocation is not bound to the evaluation workspace')
    return {'at_pacific': datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
            'role': 'read_only_project_GPU_request_audit_not_model_delivery',
            'jobs': jobs, 'all_account_requested_GPUs': total,
            'project_requested_GPUs': project, 'project_requested_GPUs_with_addition': project + additional_gpus,
            'verified_unrelated_requested_GPUs': total - project,
            'additional_GPUs_reviewed': additional_gpus, 'project_GPU_ceiling': 8,
            'own_job_id': str(own_job_id) if own_job_id is not None else None,
            'unrelated_jobs_changed': False, 'model_calls': 0}


def conservative_project_gpu_audit(*, require_own_job=False, additional_gpus=0):
    own = os.environ.get('SLURM_JOB_ID') if require_own_job else None
    if require_own_job and not own:
        raise ValueError('A real Slurm job is required')
    def command(argv):
        return subprocess.run(argv, capture_output=True, text=True, check=True, timeout=30).stdout
    queue = command(['squeue', '-h', '-u', 'dongweij', '-o', '%i|%j|%T|%b'])
    jobs = []
    for line in queue.splitlines():
        parts = line.split('|')
        if len(parts) != 4:
            raise ValueError('Malformed squeue accounting row')
        job_id, name, state, resource = parts
        if resource in {'N/A', '(null)', ''}:
            continue
        if 'gpu' not in resource:
            continue
        if not re.fullmatch(r'[0-9]+(?:_[0-9]+)?', job_id):
            raise ValueError('Expanded exact Slurm job IDs required for GPU audit')
        raw = command(['scontrol', 'show', 'job', '-o', job_id])
        jobs.append(classify_row(job_id, name, state, resource, raw))
    return evaluate_inventory(jobs, own, additional_gpus)


if __name__ == '__main__':
    print(json.dumps(conservative_project_gpu_audit()))
