# PFArena additional human SOD1 activity: two assays

Qwen3.8-27B: NMS@40 = 0.8759601688031643; Recall@40 = 0.025 on the separately reviewed 2/123 assays. Native mean illegal predictions within budget = 2.0; duplicate, missing and incomplete counts = 0. All 3 development and 2 benchmark responses were delivered. Delivery success alone does not validate biological correctness. Complete approved inputs, original visible raw outputs and unchanged code are retained. Protected measurement tables, other cases, models, environments and private resource inventories are excluded.
