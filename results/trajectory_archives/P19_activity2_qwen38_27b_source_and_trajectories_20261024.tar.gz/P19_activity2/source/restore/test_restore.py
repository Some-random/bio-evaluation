"""Invented authority/inventory tests; no case, label, scheduler or model access."""
import ast
import fcntl
import json
from pathlib import Path
import socket
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import restore_authority as r

HERE=Path(__file__).resolve().parent

def function(source,name):
    return next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name==name)

class RestoreTests(unittest.TestCase):
    def setUp(self):
        for name in ('run','Popen','check_output','check_call'):
            guard=patch.object(subprocess,name,side_effect=AssertionError('Real subprocess forbidden'))
            guard.start();self.addCleanup(guard.stop)
        guard=patch.object(socket,'socket',side_effect=AssertionError('Network forbidden'))
        guard.start();self.addCleanup(guard.stop)

    def test_both_capacity_boundaries_use_same_v5_and_proofs(self):
        calls=[]
        def audit(**kwargs):
            calls.append(kwargs)
            return dict(project_requested_GPUs=1,project_requested_GPUs_with_addition=1+kwargs['additional'],
                capacity_available=True,own_allocation_verified=True)
        adapter=SimpleNamespace(capacity_audit=audit)
        spec=SimpleNamespace(loader=SimpleNamespace(exec_module=lambda module:None))
        shared=dict(additional_root_proofs=[dict(path='/invented/proof.json',sha256='a'*64)],
                    additional_proof_binding=dict(path='/invented/binding.json',sha256='b'*64))
        with patch.object(r,'authorize'),patch.object(r,'pinned',return_value=Path('/synthetic.py')), \
                patch.object(r,'shared_resource_binding',return_value=shared), \
                patch.object(r.importlib.util,'spec_from_file_location',return_value=spec), \
                patch.object(r.importlib.util,'module_from_spec',return_value=adapter):
            r.capacity_audit('synthetic',additional=1,require_own_job=False)
            r.capacity_audit('synthetic',additional=0,require_own_job=True)
        self.assertEqual([(x['additional'],x['require_own_job'])for x in calls],[(1,False),(0,True)])
        for call in calls:
            self.assertIs(call['override'],False)
            self.assertEqual(call['additional_root_proofs'],shared['additional_root_proofs'])
            self.assertEqual(call['additional_proof_binding'],shared['additional_proof_binding'])
        self.assertEqual(r.ADAPTER_SHA,'d7464059bdf95ab61fe0a2699cc4fb510252b9502aeb2c869d612f9d5d3d5f42')

    def test_both_STOPs_block_before_authority_reads(self):
        for side in ('HERE','ORIGINAL'):
            with tempfile.TemporaryDirectory() as name:
                root=Path(name);new=root/'restore';old=root/'original';new.mkdir();old.mkdir()
                (new if side=='HERE' else old).joinpath('STOP').write_text('invented hold')
                with patch.multiple(r,HERE=new,ORIGINAL=old),patch.object(r,'read',side_effect=AssertionError('Held')):
                    with self.assertRaises(PermissionError):r.authorize('synthetic')

    def test_shared_resource_binding_is_exact_before_adapter_import(self):
        shared=dict(resource_adapter=dict(path=str(r.ADAPTER),sha256=r.ADAPTER_SHA),
            root_authorization=dict(path=str(r.AUTHORIZATION),sha256=r.AUTHORIZATION_SHA),project_GPU_ceiling=8,
            additional_root_proofs=[dict(path='/invented/proof',sha256='a'*64)],
            additional_proof_binding=dict(path='/invented/binding',sha256='b'*64))
        with patch.object(r,'pinned',side_effect=lambda path,digest:Path(path)) as pinned, \
                patch.object(r,'read',return_value=shared):
            self.assertIs(r.shared_resource_binding(),shared)
            self.assertEqual(pinned.call_args_list[0].args,(r.SHARED_RESOURCE_BINDING,r.SHARED_RESOURCE_BINDING_SHA))
            bad=dict(shared,root_authorization=dict(path=str(r.AUTHORIZATION),sha256='old'))
            with patch.object(r,'read',return_value=bad),self.assertRaises(PermissionError):r.shared_resource_binding()

    def test_new_root_and_independent_exact_binding_are_required(self):
        binding=dict(scope=r.RESTORE_SCOPE,plan_sha256=r.PLAN_SHA,engineering_admission_sha256=r.ENGINEERING_SHA,
            root_authorization_sha256=r.AUTHORIZATION_SHA,
            shared_resource_binding=dict(path=str(r.SHARED_RESOURCE_BINDING),sha256=r.SHARED_RESOURCE_BINDING_SHA),project_GPU_ceiling=8,
            scientific_changes=False,automatic_retry=False)
        release=dict(issuer='/root',prepared_by=r.OWNER,approved=True,scope=r.RESTORE_SCOPE,
            root_authorization_sha256=r.AUTHORIZATION_SHA,plan_sha256=r.PLAN_SHA,
            engineering_admission_sha256=r.ENGINEERING_SHA,scheduling_STOP_clearance_only=True,
            scientific_changes=False,automatic_retry=False)
        review=dict(reviewer=r.REVIEWER,approved=True,admitted=True,scope=r.RESTORE_SCOPE,
            plan_sha256=r.PLAN_SHA,engineering_admission_sha256=r.ENGINEERING_SHA,
            root_authorization_sha256=r.AUTHORIZATION_SHA,restore_binding_sha256='binding',root_release_sha256='release',
            scheduling_STOP_clearance_only=True)
        r.validate_values(review,binding,release,'binding','release')
        for bad in (dict(review,reviewer=r.OWNER),dict(review,root_authorization_sha256='old'),
                    dict(review,restore_binding_sha256='changed')):
            with self.assertRaises(PermissionError):r.validate_values(bad,binding,release,'binding','release')

    def test_late_STOP_blocks_claim_and_synthetic_scheduler(self):
        source=(HERE/'submit_once.py').read_text()
        with tempfile.TemporaryDirectory() as name:
            root=Path(name);old=root/'original';new=root/'restore';old.mkdir();new.mkdir();(root/'.local').mkdir()
            writes=[];submissions=[]
            def authorize(digest):
                if (old/'STOP').exists()or(new/'STOP').exists():raise PermissionError('Invented late STOP')
            def audit(plan,additional,require_own_job):
                (old/'STOP').write_text('invented STOP after capacity')
                return dict(capacity_available=True,project_requested_GPUs=0)
            worker=SimpleNamespace(validate_plan=lambda *args:{},check_root_admission=lambda *args,**kwargs:None,
                resource_audit=audit,save=lambda path,value:writes.append(path.name),stamp=lambda:'synthetic')
            namespace=dict(HERE=old,RESTORE=new,ROOT=root,Path=Path,worker=worker,authorize_restore=authorize,
                fcntl=fcntl,subprocess=SimpleNamespace(run=lambda *args,**kwargs:submissions.append(args)),
                re=__import__('re'))
            exec(compile(ast.Module(body=[function(source,'submit')],type_ignores=[]),'<synthetic submit>','exec'),namespace)
            with self.assertRaises(PermissionError):namespace['submit'](old/'plan.json','plan',old/'grant.json','grant','restore')
            self.assertEqual(writes,[]);self.assertEqual(submissions,[])

    def test_scientific_worker_body_and_existing_guards_preserved(self):
        old=(r.ORIGINAL/'worker.py').read_text();new=(HERE/'worker.py').read_text()
        boundary="    runtime = Path(plan['runtime_root']);runtime.mkdir(exist_ok=True)"
        self.assertEqual(old.split(boundary,1)[1],new.split(boundary,1)[1])
        for name in ('validate_plan','check_root_admission','require_no_prior_case_requests','execute_phases','activate_private_runtime'):
            self.assertEqual(ast.dump(function(old,name)),ast.dump(function(new,name)))
        self.assertIn('HERE = ORIGINAL',new)
        submit=(HERE/'submit_once.py').read_text()
        self.assertIn("claim.exists() or receipt.exists()",submit)
        self.assertIn("worker.resource_audit(plan,additional=1,require_own_job=False)",submit)
        batch=(HERE/'worker.sbatch').read_text()
        self.assertIn(str(HERE/'worker.py'),batch)
        self.assertIn(str(r.ORIGINAL/'plan.json'),batch)
        self.assertIn('--restore-admission-sha256 "$4"',batch)

if __name__=='__main__':unittest.main(verbosity=2)
