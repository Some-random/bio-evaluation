"""One exact P19 sbatch attempt under the shared project GPU lock."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import subprocess
import sys

from restore_authority import HERE as RESTORE, ORIGINAL, authorize as authorize_restore
HERE = ORIGINAL
ROOT = HERE.parents[4]
sys.path.insert(0,str(RESTORE))
import worker


def submit(plan_path, plan_sha, grant_path, grant_sha, restore_admission_sha, run=subprocess.run, audit=None):
    worker._RESTORE_ADMISSION_SHA=restore_admission_sha
    authorize_restore(restore_admission_sha)
    if (HERE/'STOP').exists(): raise PermissionError('New P19 submission paused by existing STOP control')
    plan=worker.validate_plan(plan_path,plan_sha)
    # Admission is checked without pretending that login preparation is allocated.
    worker.check_root_admission(grant_path,grant_sha,plan_sha,plan,require_allocation=False)
    claim=HERE/'submission_attempt.json';receipt=HERE/'submission_receipt.json'
    with (ROOT/'.local/evaluation_GPU_submission.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if (HERE/'STOP').exists(): raise PermissionError('New P19 submission paused by existing STOP control')
        if claim.exists() or receipt.exists(): raise FileExistsError('Prior or uncertain submission cannot be replayed')
        result=(audit(additional=1,override=False) if audit else
                worker.resource_audit(plan,additional=1,require_own_job=False))
        if not result['capacity_available']:
            return 75,{'stage':'capacity_only_wait','sbatch_invoked':False,'submission_attempt_started':False,
                'project_requested_GPUs':result['project_requested_GPUs'],'project_GPU_ceiling':8}
        authorize_restore(restore_admission_sha)
        worker.save(HERE/'private_submission_GPU_audit.json',result)
        # Durable intent precedes sbatch. Any exception or malformed response ends the attempt.
        argv=['sbatch','--parsable',str(RESTORE/'worker.sbatch'),plan_sha,str(grant_path),grant_sha,restore_admission_sha]
        authorize_restore(restore_admission_sha)
        worker.save(claim,{'at_pacific':worker.stamp(),'plan_sha256':plan_sha,'grant_sha256':grant_sha,
            'command':argv,'restore_admission_sha256':restore_admission_sha,'sbatch_result_unknown_until_receipt':True,'automatic_retry':False})
        completed=run(argv,capture_output=True,text=True,timeout=60)
        evidence={'at_pacific':worker.stamp(),'plan_sha256':plan_sha,'grant_sha256':grant_sha,
            'command':argv,'returncode':completed.returncode,'stdout':completed.stdout,'stderr':completed.stderr,
            'automatic_retry':False,'role':'submission_receipt_not_model_dispatch_evidence','requested_gpus':1}
        ident=completed.stdout.strip()
        if completed.returncode == 0 and re.fullmatch(r'[0-9]+(?:;[A-Za-z0-9_.-]+)?',ident):
            evidence['job_id']=ident.split(';')[0]
        worker.save(receipt,evidence)
        if 'job_id' not in evidence: raise ValueError('Failed or uncertain sbatch outcome: preserved, never retried')
        return 0,evidence


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan',type=Path,required=True);p.add_argument('--plan-sha256',required=True)
    p.add_argument('--grant',type=Path,required=True);p.add_argument('--grant-sha256',required=True)
    p.add_argument('--restore-admission-sha256',required=True)
    a=p.parse_args();code,result=submit(a.plan,a.plan_sha256,a.grant,a.grant_sha256,a.restore_admission_sha256)
    print(json.dumps(result),flush=True);return code


if __name__=='__main__':sys.exit(main())
