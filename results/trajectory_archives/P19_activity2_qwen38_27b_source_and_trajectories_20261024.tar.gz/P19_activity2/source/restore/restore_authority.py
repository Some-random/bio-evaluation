"""Operational restoration of one frozen P19 lane; no data/model reads on import."""
from pathlib import Path
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE.parent / 'human_enzyme2_execution_v1'
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
PLAN_SHA = '6c97fc69b4864f9f2fd17ba688bfce39548b094781ffbdc25d5daf4544b85d84'
ENGINEERING_SHA = '4b988276c2cff3e306c495d3ad5d3a0a141bb04ee26c4a9822f9f69bbe027e3e'
AUTHORIZATION = ROOT / '.local/goal_restore_20261024/root_authorization.json'
AUTHORIZATION_SHA = 'bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
OWNER = '/root/priority_runtime_review/lpb398_verifier_tests/joint_restart_review'
REVIEWER = '/root/priority_runtime_review'
RESTORE_SCOPE = 'P19_additional2_exact_frozen_plan_restore'
ADAPTER = ROOT / '.local/resource_accounting_20261022/exact_external_checkpoint_jobs_adapter_v5.py'
ADAPTER_SHA = 'd7464059bdf95ab61fe0a2699cc4fb510252b9502aeb2c869d612f9d5d3d5f42'
SHARED_RESOURCE_BINDING = ROOT / '.local/goal_restore_20261024/shared_resource_binding.json'
SHARED_RESOURCE_BINDING_SHA = 'cb881370f7dac295d7d153f72baddcbf604c0fce0cc651ee82c557e5efcad6f9'
SOURCES = frozenset(('restore_authority.py','worker.py','submit_once.py','worker.sbatch','test_restore.py'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pinned(path, digest):
    path = Path(path)
    if path.is_symlink() or path.resolve() != path or not path.is_file() or sha(path) != digest:
        raise PermissionError('Exact pinned restore source/authority required')
    return path


def read(path):
    return json.loads(Path(path).read_text())


def validate_values(review, binding, release, binding_sha, release_sha):
    if (review.get('reviewer') != REVIEWER or review.get('approved') is not True
            or review.get('admitted') is not True or review.get('scope') != RESTORE_SCOPE
            or review.get('plan_sha256') != PLAN_SHA
            or review.get('engineering_admission_sha256') != ENGINEERING_SHA
            or review.get('root_authorization_sha256') != AUTHORIZATION_SHA
            or review.get('restore_binding_sha256') != binding_sha
            or review.get('root_release_sha256') != release_sha
            or review.get('scheduling_STOP_clearance_only') is not True):
        raise PermissionError('Independent exact restore admission required')
    if (binding.get('scope') != RESTORE_SCOPE or binding.get('plan_sha256') != PLAN_SHA
            or binding.get('engineering_admission_sha256') != ENGINEERING_SHA
            or binding.get('root_authorization_sha256') != AUTHORIZATION_SHA
            or binding.get('shared_resource_binding') != dict(path=str(SHARED_RESOURCE_BINDING),sha256=SHARED_RESOURCE_BINDING_SHA)
            or binding.get('project_GPU_ceiling') != 8 or binding.get('scientific_changes') is not False
            or binding.get('automatic_retry') is not False):
        raise PermissionError('Exact unchanged-science restore binding required')
    if (release.get('issuer') != '/root' or release.get('prepared_by') != OWNER
            or release.get('approved') is not True or release.get('scope') != RESTORE_SCOPE
            or release.get('root_authorization_sha256') != AUTHORIZATION_SHA
            or release.get('plan_sha256') != PLAN_SHA
            or release.get('engineering_admission_sha256') != ENGINEERING_SHA
            or release.get('scheduling_STOP_clearance_only') is not True
            or release.get('scientific_changes') is not False or release.get('automatic_retry') is not False):
        raise PermissionError('Exact subsequent delegated root scheduling release required')


def authorize(admission_sha, allow_stop=False):
    if not allow_stop and any((folder/'STOP').exists() for folder in (HERE,ORIGINAL)):
        raise PermissionError('P19 scheduling STOP remains active')
    authorization = read(pinned(AUTHORIZATION, AUTHORIZATION_SHA))
    if (authorization.get('issuer') != '/root' or authorization.get('approved') is not True
            or authorization.get('project_GPU_ceiling') != 8
            or 'P19_additional2' not in authorization.get('restore_already_reviewed_local_lanes', [])
            or authorization.get('owners',{}).get('P19') != OWNER
            or authorization.get('no_new_cohorts_or_protocols_adopted') is not True):
        raise PermissionError('Explicit exact P19 restoration authorization required')
    review = read(pinned(HERE/'independent_restore_admission.json', admission_sha))
    binding_path, release_path = HERE/'restore_binding.json', HERE/'root_priority_release.json'
    binding_sha, release_sha = review.get('restore_binding_sha256'), review.get('root_release_sha256')
    binding = read(pinned(binding_path,binding_sha));release = read(pinned(release_path,release_sha))
    validate_values(review,binding,release,binding_sha,release_sha)
    sources = binding.get('source_sha256',{})
    if set(sources) != SOURCES:raise PermissionError('Complete restore source inventory required')
    for name,digest in sources.items():pinned(HERE/name,digest)
    pinned(ORIGINAL/'plan.json',PLAN_SHA);pinned(ORIGINAL/'engineering_admission.json',ENGINEERING_SHA)
    for path,digest in binding['original_source_sha256'].items():pinned(path,digest)
    shared_resource_binding()
    return binding


def shared_resource_binding():
    value=read(pinned(SHARED_RESOURCE_BINDING,SHARED_RESOURCE_BINDING_SHA))
    if (value.get('resource_adapter') != dict(path=str(ADAPTER),sha256=ADAPTER_SHA)
            or value.get('root_authorization') != dict(path=str(AUTHORIZATION),sha256=AUTHORIZATION_SHA)
            or value.get('project_GPU_ceiling') != 8):
        raise PermissionError('Same exact reviewed shared restoration resource binding required')
    pinned(ADAPTER,ADAPTER_SHA)
    proofs=value.get('additional_root_proofs')
    proof_binding=value.get('additional_proof_binding')
    if not isinstance(proofs,list) or not proofs or not isinstance(proof_binding,dict):
        raise PermissionError('Explicit reviewed resource proofs and binding required')
    for evidence in [*proofs,proof_binding]:pinned(evidence['path'],evidence['sha256'])
    return value


def capacity_audit(admission_sha, additional=0, require_own_job=False):
    authorize(admission_sha)
    if (type(additional) is not int or type(require_own_job) is not bool
            or (additional,require_own_job) not in {(1,False),(0,True)}):
        raise ValueError('Only locked preallocation +1 and own startup +0 are supported')
    resource=shared_resource_binding()
    path=pinned(ADAPTER,ADAPTER_SHA)
    spec=importlib.util.spec_from_file_location('p19_restore_exact_v5',path)
    adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
    result=adapter.capacity_audit(additional=additional,override=False,require_own_job=require_own_job,
        additional_root_proofs=resource['additional_root_proofs'],additional_proof_binding=resource['additional_proof_binding'])
    count=result.get('project_requested_GPUs')
    if (type(count) is not int or count<0
            or result.get('project_requested_GPUs_with_addition') != count+additional
            or result.get('capacity_available') is not (count+additional<=8)
            or (require_own_job and (not result['capacity_available']
                                     or result.get('own_allocation_verified') is not True))):
        raise ValueError('Fresh conservative project accounting or own allocation failed')
    return result
