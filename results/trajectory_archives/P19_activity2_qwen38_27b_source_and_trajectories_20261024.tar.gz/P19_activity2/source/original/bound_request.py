"""Exact frozen input/context binding before the prospective request overlay."""
import hashlib
import json

from request_contract import prospective_request

MODEL = "Qwen/Qwen3.8-27B"


def canonical_sha256(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def build_bound_request(case, context, base_generation, *, case_sha256,
                        context_sha256, base_generation_sha256):
    """No files/network: caller must obtain the three pins from a root-frozen plan.

    This does not create those trusted pins or grant permission to dispatch.
    It binds the processor's sequence to the exact complete native user prompt,
    the independently frozen delivery context and the frozen base sampling.
    """
    for value, expected in [(case, case_sha256), (context, context_sha256),
                            (base_generation, base_generation_sha256)]:
        if canonical_sha256(value) != expected:
            raise ValueError("changed_frozen_input_context_or_base_generation")
    if set(case) != {"task_id", "case_id", "messages"} or case["task_id"] != "P19":
        raise ValueError("unexpected_case_fields")
    if set(context) != {"case_id", "wildtype_sequence", "sequence_length"}:
        raise ValueError("unexpected_context_fields_or_reference_payload")
    if context["case_id"] != case["case_id"]:
        raise ValueError("case_context_identity_mismatch")
    messages = case["messages"]
    if not isinstance(messages, list) or len(messages) != 1 or set(messages[0]) != {"role", "content"} or messages[0]["role"] != "user":
        raise ValueError("native_fresh_user_message_required")
    sequence = context["wildtype_sequence"]
    if not isinstance(sequence, str) or len(sequence) != context["sequence_length"]:
        raise ValueError("complete_sequence_length_mismatch")
    text = messages[0]["content"]
    if not isinstance(text, str) or "`" + sequence + "`" not in text:
        raise ValueError("processor_sequence_not_present_complete_in_native_prompt")
    original = {"model": MODEL, "messages": messages, **base_generation}
    result = prospective_request(original, sequence)
    if result["messages"] != case["messages"]:
        raise ValueError("native_prompt_changed")
    return result
