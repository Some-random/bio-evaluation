"""Pure prospective request overlay; never dispatches or reads target rows."""
from __future__ import annotations

import copy
import hashlib

from unique40_core import CONDITION, Unique40Language


def prospective_request(original_request: dict, sequence: str) -> dict:
    """Preserve native messages/sampling; change only declared output controls.

    A future reviewed worker must bind `sequence` to the exact approved input's
    native sequence and its pinned delivery context before invoking this pure
    function. This module creates no dispatch grant.
    """
    language = Unique40Language(sequence)
    result = copy.deepcopy(original_request)
    if result.get("n", 1) != 1:
        raise ValueError("single_output_only")
    if "vllm_xargs" in result:
        raise ValueError("refuse_preexisting_custom_arguments")
    original = result.get("structured_outputs", {})
    if set(original) != {"json"}:
        raise ValueError("expected_original_JSON_structured_output_contract")
    result["structured_outputs"] = {
        "json": {
            "type": "object",
            "properties": {"ranking": {
                "type": "array", "minItems": 40, "maxItems": 40,
                "items": {"type": "string", "enum": sorted(language.allowed)},
            }},
            "required": ["ranking"], "additionalProperties": False,
        }
    }
    # Values are flat strings: exact vLLM0.32 HTTP vllm_xargs forbids dictionaries.
    result["vllm_xargs"] = {
        "p19_unique40_condition": CONDITION,
        "p19_unique40_sequence": sequence,
        "p19_unique40_sequence_sha256": hashlib.sha256(sequence.encode()).hexdigest(),
    }
    return result
