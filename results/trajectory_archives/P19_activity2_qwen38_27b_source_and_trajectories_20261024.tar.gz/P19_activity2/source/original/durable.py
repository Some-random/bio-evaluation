"""Durable local file claims; no model, scheduler or source-data operations."""
import os
from pathlib import Path

def sync_directory(path):
    fd = os.open(str(Path(path)), os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)

def persist(handle, path):
    handle.flush(); os.fsync(handle.fileno()); sync_directory(Path(path).parent)
