"""Reference-free delivery contract for the prospective P19 T1 condition.

T1 generates new single substitutions; it is not a closed candidate permutation.
Validation uses only the wild-type sequence already present in the native prompt.
No mutation is repaired, reordered, filled, or selected using measurements.
"""
from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass

AMINO_ACIDS = "ACDEFGHIKLMNPQRSTVWY"
MUTATION = re.compile(r"([ACDEFGHIKLMNPQRSTVWY])([1-9][0-9]*)([ACDEFGHIKLMNPQRSTVWY])\Z")
OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {"ranking": {
        "type": "array", "minItems": 40, "maxItems": 40,
        "items": {"type": "string", "pattern": "^[ACDEFGHIKLMNPQRSTVWY][1-9][0-9]*[ACDEFGHIKLMNPQRSTVWY]$"},
    }},
    "required": ["ranking"], "additionalProperties": False,
}
GENERATION = {
    "max_tokens": 16384, "temperature": 1.0, "top_p": 0.95,
    "top_k": 20, "seed": 42, "n": 1,
    "chat_template_kwargs": {"enable_thinking": False},
    "structured_outputs": {"json": OUTPUT_SCHEMA},
}


@dataclass(frozen=True)
class GenerationAudit:
    delivery_passed: bool
    delivered_count: int | None
    errors: tuple[str, ...]
    ranking: tuple[str, ...] | None

    def to_dict(self):
        return asdict(self)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate_json_object_key")
        result[key] = value
    return result


def audit_generation(sequence: str, final: object) -> GenerationAudit:
    """Reject malformed/duplicate/no-op/wrong-WT substitutions without repair."""
    if not isinstance(sequence, str) or not sequence or set(sequence) - set(AMINO_ACIDS):
        raise ValueError("Frozen input is not a complete standard-amino-acid sequence")
    if not isinstance(final, str):
        return GenerationAudit(False, None, ("final_not_text",), None)
    try:
        value = json.loads(final, object_pairs_hook=unique_object)
    except (ValueError, TypeError):
        return GenerationAudit(False, None, ("invalid_or_duplicate_key_json",), None)
    if not isinstance(value, dict) or set(value) != {"ranking"}:
        return GenerationAudit(False, None, ("unexpected_object_schema",), None)
    ranking = value["ranking"]
    if not isinstance(ranking, list):
        return GenerationAudit(False, None, ("ranking_not_list",), None)
    errors = []
    if len(ranking) != 40:
        errors.append("ranking_size_not_40")
    seen = set()
    for index, mutation in enumerate(ranking):
        match = MUTATION.fullmatch(mutation) if isinstance(mutation, str) else None
        if not match:
            errors.append(f"malformed_mutation:{index}")
            continue
        before, position, after = match.groups()
        position = int(position)
        if not 1 <= position <= len(sequence):
            errors.append(f"position_out_of_range:{index}")
        elif before != sequence[position - 1]:
            errors.append(f"wildtype_mismatch:{index}")
        if before == after:
            errors.append(f"no_op:{index}")
        if mutation in seen:
            errors.append(f"duplicate_mutation:{index}")
        seen.add(mutation)
    return GenerationAudit(not errors, len(ranking), tuple(errors),
                           tuple(ranking) if all(isinstance(x, str) for x in ranking) else None)
