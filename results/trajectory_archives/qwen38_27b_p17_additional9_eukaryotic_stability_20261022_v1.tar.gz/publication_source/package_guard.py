"""Verify the exact independent CPU-source review before offline packaging."""
from pathlib import Path
import argparse,os,runpy,sys

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--freeze',type=Path,required=True);parser.add_argument('--freeze-sha256',required=True);args=parser.parse_args()
 here=Path(__file__).resolve().parent;sys.path.insert(0,str(here));import watch
 watch.source_check(args.freeze,args.freeze_sha256)
 os.environ['CUDA_VISIBLE_DEVICES']=''
 runpy.run_path(str(here/'package.py'),run_name='__main__')
if __name__=='__main__':main()
