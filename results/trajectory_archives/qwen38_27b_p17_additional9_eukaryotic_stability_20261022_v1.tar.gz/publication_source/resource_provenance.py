"""Offline provenance for one exact resource-only operational amendment.

Actual manifest/admission hashes must come from the independently reviewed
source-freeze binding. This module cannot audit capacity or submit a job.
"""
from pathlib import Path
import hashlib,json,re
ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
P17=ROOT/'.local/catalog_execution_2026-10-20/tasks/P17'
EXECUTION=P17/'additional9_eukaryotic_stability_v3'
OPERATION=P17/'additional9_restore_20261024_v1'
PLAN=EXECUTION/'plan.json'
PLAN_SHA='7f7907abc333cf28bdecfda7da586dd6f3eec791ac4d96fb393674c33f03cb30'
MANIFEST_SHA='b2320d15e5459f05a894808abc393c5877901ff67ae412c24745f6b5130ef4cb'
POLICY=ROOT/'.local/goal_restore_20261024/root_authorization.json'
POLICY_SHA='bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
OWNER='/root/main_docs_refresh'
PUBLIC_SOURCE_NAMES=('resource_contract.py','wait_capacity.py','worker.py','worker.sbatch','test_restore.py','waiter.sbatch')
BINDING_KEYS={'original_scientific_plan_sha256','amendment_manifest_path','amendment_manifest_sha256','amendment_admission_path','amendment_admission_sha256'}
AUDIT_MANIFEST_FIELD='operational_resource_amendment_sha256'
AUDIT_GRANT_FIELD='operational_resource_admission_sha256'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_bytes())
def regular(path,digest=None):
 path=Path(path)
 if not path.is_absolute()or path!=path.resolve()or not path.is_file():raise ValueError('Exact regular non-symlinked provenance file required')
 if digest is not None and(not isinstance(digest,str)or not re.fullmatch(r'[0-9a-f]{64}',digest)or sha(path)!=digest):raise ValueError('Exact pinned provenance file changed')
 return path

def binding_from_freeze(freeze):
 binding=freeze.get('operational_resource_binding')
 if not isinstance(binding,dict)or set(binding)!=BINDING_KEYS:raise ValueError('Later exact manifest/admission source-freeze binding is required')
 if (binding['original_scientific_plan_sha256']!=PLAN_SHA or binding['amendment_manifest_sha256']!=MANIFEST_SHA
     or binding['amendment_manifest_path']!=str(OPERATION/'manifest.json')
     or binding['amendment_admission_path']!=str(OPERATION/'engineering_admission.json')):raise ValueError('Only this fixed restored operational directory and original science are eligible')
 for key in ['amendment_manifest_sha256','amendment_admission_sha256']:
  if not isinstance(binding[key],str)or not re.fullmatch(r'[0-9a-f]{64}',binding[key]):raise ValueError('Unknown operational manifest/admission hash cannot activate publication')
 return binding

def verify_static_binding(binding):
 binding=binding_from_freeze({'operational_resource_binding':binding})
 regular(PLAN,PLAN_SHA);plan=read(PLAN)
 manifest_path=regular(binding['amendment_manifest_path'],binding['amendment_manifest_sha256']);manifest=read(manifest_path)
 if (manifest.get('task_id')!='P17'or manifest.get('role')!='P17_additional9_restored_operational_amendment'
     or manifest.get('original_plan_path')!=str(PLAN)or manifest.get('original_plan_sha256')!=PLAN_SHA
     or manifest.get('original_frozen_file_count')!=71 or len(plan.get('frozen_files_sha256',{}))!=71
     or manifest.get('original_frozen_files_sha256')!=plan['frozen_files_sha256']
     or manifest.get('scientific_files_unchanged')is not True or manifest.get('original_claim_receipt_and_runtime_paths_preserved')is not True
     or manifest.get('gpus_requested')!=1 or manifest.get('project_gpu_ceiling')!=8
     or manifest.get('new_scientific_or_case_permission')is not False or manifest.get('no_automatic_retry')is not True):raise ValueError('Resource-only amendment must preserve the original scientific closure')
 pins=manifest.get('files_sha256')
 if not isinstance(pins,dict)or not pins:raise ValueError('Complete exact admitted resource source closure required')
 for name,digest in pins.items():regular(name,digest)
 for name in PUBLIC_SOURCE_NAMES:
  path=OPERATION/name
  if str(path)not in pins:raise ValueError('Every actual operational worker source must be pinned')
 for field in ['resource_adapter','shared_resource_binding','root_authorization','additional_proof_binding']:
  descriptor=manifest.get(field)
  if not isinstance(descriptor,dict)or descriptor.get('path')not in pins or pins[descriptor['path']]!=descriptor.get('sha256'):raise ValueError('Exact adapter/review/proof binding must be inside the admitted source closure')
 for proof in manifest.get('additional_root_proofs',[]):
  if proof.get('path')not in pins or pins[proof['path']]!=proof.get('sha256'):raise ValueError('Every explicit external proof remains exactly bound and private')
 admission=regular(binding['amendment_admission_path'],binding['amendment_admission_sha256']);grant=read(admission)
 regular(POLICY,POLICY_SHA);policy=read(POLICY)
 if (grant.get('reviewer')==OWNER or grant.get('reviewer')!=policy['independent_review_delegation']['P17_P19_scalar184']
     or grant.get('approved')is not True or grant.get('role')!='independent_P17_restored_operational_admission'
     or grant.get('manifest_sha256')!=binding['amendment_manifest_sha256']or grant.get('root_authorization_sha256')!=POLICY_SHA
     or grant.get('shared_resource_binding_sha256')!=manifest['shared_resource_binding']['sha256']
     or grant.get('original_plan_sha256')!=PLAN_SHA
     or grant.get('original_engineering_admission_sha256')!=manifest.get('original_engineering_admission_sha256')
     or grant.get('scientific_scope_unchanged')is not True or grant.get('priority_release_required')is not True):raise ValueError('A different delegated peer must admit the exact resource-only amendment')
 return manifest

def expected_command(binding,manifest):
 return ['sbatch','--parsable',str(OPERATION/'worker.sbatch'),
  '--plan',str(PLAN),'--plan-sha256',PLAN_SHA,
  '--admission',str(EXECUTION/'engineering_admission.json'),'--admission-sha256',manifest['original_engineering_admission_sha256'],
  '--resource-amendment',str(OPERATION/'manifest.json'),'--resource-amendment-sha256',binding['amendment_manifest_sha256'],
  '--resource-admission',str(OPERATION/'engineering_admission.json'),'--resource-admission-sha256',binding['amendment_admission_sha256']]

def terminal_projection(binding,receipt):
 """Call only after successful actual job, server stop and sealed native score."""
 manifest=verify_static_binding(binding)
 if (receipt.get('stage')!='submitted'or receipt.get('returncode')!=0 or receipt.get('plan_sha256')!=PLAN_SHA
     or not re.fullmatch(r'[0-9]+',str(receipt.get('job_id','')))):raise ValueError('Original exact successful once-only submission is required')
 sole_path=regular(OPERATION/'sole_command.json');sole=read(sole_path)
 audit_paths=[EXECUTION/'submission_v1/GPU_audit_at_submission.json',EXECUTION/'runtime/private_GPU_audit_at_start.json',EXECUTION/'runtime/private_GPU_audit_at_model_start.json']
 audits=[read(regular(path))for path in audit_paths];audit_sha=sha(audit_paths[0])
 command=expected_command(binding,manifest)
 if (receipt.get('command')!=command or sole.get('command')!=command
     or sole.get('resource_amendment_sha256')!=binding['amendment_manifest_sha256']
     or sole.get('resource_admission_sha256')!=binding['amendment_admission_sha256']
     or sole.get('GPU_audit_sha256')!=audit_sha or receipt.get('GPU_audit_sha256')!=audit_sha):raise ValueError('Actual scheduler command and original audit must retain the exact operational binding')
 for audit in audits:
  if (audit.get(AUDIT_MANIFEST_FIELD)!=binding['amendment_manifest_sha256']
      or audit.get(AUDIT_GRANT_FIELD)!=binding['amendment_admission_sha256']
      or audit.get('exact_resource_adapter')!=manifest['resource_adapter']
      or audit.get('shared_resource_binding')!=manifest['shared_resource_binding']
      or audit.get('additional_root_proofs')!=manifest['additional_root_proofs']
      or audit.get('additional_proof_binding')!=manifest['additional_proof_binding']):raise ValueError('Submission and both startup checks require identical resource provenance')
 release_path=regular(OPERATION/'priority_release.json');release=read(release_path)
 if (release.get('issuer')!='/root'or release.get('approved')is not True
     or release.get('role')!='exact_P17_restored_scheduling_release'
     or release.get('resource_amendment_sha256')!=binding['amendment_manifest_sha256']
     or release.get('original_plan_sha256')!=PLAN_SHA
     or release.get('prepared_by')!=OWNER or release.get('root_authorization_sha256')!=POLICY_SHA
     or release.get('resource_admission_sha256')!=binding['amendment_admission_sha256']
     or release.get('scheduling_only')is not True or release.get('project_GPU_ceiling')!=8
     or release.get('one_original_P17_allocation_only')is not True
     ):raise ValueError('The actual lower-priority run requires its exact root priority release')
 verify_restored_launch_proof(binding,release_path,manifest)
 return {'role':'resource_only_operational_provenance_not_new_scientific_condition','original_scientific_plan_sha256':PLAN_SHA,
  'actual_job_id':str(receipt['job_id']),'amendment_manifest_sha256':binding['amendment_manifest_sha256'],
  'amendment_admission_sha256':binding['amendment_admission_sha256'],
  'shared_resource_adapter':{'filename':Path(manifest['resource_adapter']['path']).name,'sha256':manifest['resource_adapter']['sha256'],'independent_shared_binding_sha256':manifest['shared_resource_binding']['sha256']},
  'durable_actual_command':command,'durable_actual_command_sha256':sha(sole_path),'private_submission_GPU_audit_sha256':audit_sha,
  'root_priority_release_sha256':sha(release_path),'operational_source_files_sha256':{name:manifest['files_sha256'][str(OPERATION/name)]for name in PUBLIC_SOURCE_NAMES},
  'same_resource_binding_verified_at_submission_and_both_startup_checks':True,
  'original_scientific_plan_inputs_protocol_scorer_and_runtime_paths_preserved':True,
  'full_account_GPU_rows_external_proofs_credentials_or_measurements_included':False,
  'model_calls_by_provenance_check':0,'scheduler_mutations_by_provenance_check':0}

def verify_restored_launch_proof(binding,release_path,manifest):
 review_path=regular(OPERATION/'launch_review.json');review=read(review_path)
 clearance_path=regular(OPERATION/'STOP_clearance_receipt.json');clearance=read(clearance_path)
 if (review.get('approved')is not True or review.get('reviewer')!=read(POLICY)['independent_review_delegation']['P17_P19_scalar184']
     or review.get('role')!='independent_P17_restored_launch_and_STOP_clearance_review'
     or review.get('manifest_sha256')!=binding['amendment_manifest_sha256']
     or review.get('engineering_admission_sha256')!=binding['amendment_admission_sha256']
     or review.get('priority_release_sha256')!=sha(release_path)or review.get('root_authorization_sha256')!=POLICY_SHA
     or review.get('new_STOP_sha256')!=manifest['new_scheduling_STOP_sha256']
     or review.get('may_clear_new_scheduling_STOP_only')is not True or review.get('one_allocation_only')is not True
     or clearance.get('owner')!=OWNER or clearance.get('launch_review_sha256')!=sha(review_path)
     or clearance.get('manifest_sha256')!=binding['amendment_manifest_sha256']
     or clearance.get('priority_release_sha256')!=sha(release_path)or clearance.get('root_authorization_sha256')!=POLICY_SHA
     or clearance.get('removed_STOP_sha256')!=manifest['new_scheduling_STOP_sha256']
     or clearance.get('legacy_STOPs_preserved')is not True):raise ValueError('Exact independent restored scheduling/STOP clearance history required')
 for name,digest in manifest['preserved_legacy_STOPs_sha256'].items():regular(name,digest)


def archive_sources(binding):
 manifest=verify_static_binding(binding)
 return {'operational_resource_source/'+name:regular(OPERATION/name,manifest['files_sha256'][str(OPERATION/name)])for name in PUBLIC_SOURCE_NAMES}

def private_evidence(binding):
 manifest=verify_static_binding(binding)
 return [Path(binding['amendment_manifest_path']),Path(binding['amendment_admission_path']),OPERATION/'sole_command.json',OPERATION/'priority_release.json',OPERATION/'launch_review.json',OPERATION/'STOP_clearance_receipt.json',EXECUTION/'submission_v1/GPU_audit_at_submission.json',EXECUTION/'runtime/private_GPU_audit_at_start.json',EXECUTION/'runtime/private_GPU_audit_at_model_start.json',*(Path(name)for name in manifest['files_sha256'])]
