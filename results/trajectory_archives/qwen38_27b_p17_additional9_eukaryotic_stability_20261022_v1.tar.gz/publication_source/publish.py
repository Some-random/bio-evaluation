"""Offline by default; publish only an independently reviewed fixed whitelist."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import tarfile
import tempfile

ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
HERE=Path(__file__).resolve().parent
OWNER='/root/main_docs_refresh'
POLICY=ROOT/'.local/goal_restore_20261024/root_authorization.json'
POLICY_SHA='bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
REPOSITORY='Some-random/bio-evaluation'
URL='https://github.com/'+REPOSITORY+'.git'
RUN_ID='qwen38_27b_p17_additional9_eukaryotic_stability_20261022_v1'
PREFIX='results/runs/'+RUN_ID+'/'
RAW='results/trajectory_archives/qwen38_27b_p17_additional9_eukaryotic_stability_20261022_v1.tar.gz'
REPORT='reports/P17_ADDITIONAL9_EUKARYOTIC_DOMAIN_STABILITY_RESULT.md'
ALLOWED={PREFIX+n for n in ['result.json','scores.json','completion.json','prediction_lock.json','README.md']}|{RAW,RAW.replace('.tar.gz','.manifest.json'),REPORT}



def sha(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):value.update(chunk)
    return value.hexdigest()
def read(path):return json.loads(Path(path).read_text())
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def validate_paths(paths):
    if set(paths)!=ALLOWED:raise ValueError('Only the exact eight scoped publication paths are supported')
    for name in paths:
        path=Path(name)
        if path.is_absolute() or '..' in path.parts or '.local' in path.parts or 'docs' in path.parts:
            raise ValueError('Unsafe or website publication path')


def verify_archive(path,expected):
    observed={}
    with tarfile.open(path) as archive:
        for item in archive.getmembers():
            name=Path(item.name)
            if name.is_absolute() or '..' in name.parts or '.local' in name.parts:
                raise ValueError('Unsafe archive member')
            if item.isdir():continue
            if not item.isfile() or item.name in observed:raise ValueError('Archive links, special or duplicate files are forbidden')
            data=archive.extractfile(item).read()
            observed[item.name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    if observed!=expected:raise ValueError('Exact independently reviewed archive members changed')


def validate_summary(result,scores,done,lock):
    import math
    if (result['planned']!=16000 or scores['planned_variants']!=16000 or done['planned']!=16000
        or not 0<=done['delivery_passed']<=done['responses_saved']<=done['terminal']<=done['attempted_confirmed']<=16000
        or scores['reviewed_assays']!=9 or scores['native_release_assays']!=217
        or scores['prediction_lock_sha256']!=lock or done['prediction_lock_sha256']!=lock
        or result['primary_metric']!='native_Spearman'or result['primary_metric_value']!=scores['primary_native_Spearman']
        or scores['full_native_benchmark_complete']is not False):raise ValueError('Exact full16000 denominator and native metric status required')
    value=scores['primary_native_Spearman']
    if value is not None and(isinstance(value,bool)or not isinstance(value,(int,float))or not math.isfinite(value)):raise ValueError('Only a finite native metric or explicit undefined status')
    if done['delivery_passed']!=16000 and(value is not None or scores['references_opened']is not False):raise ValueError('Incomplete cohort cannot access measurements or yield a primary score')


def validate_resource_summary(result):
    resource=result.get('operational_resource_provenance')
    if (not isinstance(resource,dict)or resource.get('role')!='resource_only_operational_provenance_not_new_scientific_condition'
        or resource.get('original_scientific_plan_sha256')!='7f7907abc333cf28bdecfda7da586dd6f3eec791ac4d96fb393674c33f03cb30'
        or not str(resource.get('actual_job_id','')).isdigit()or resource.get('actual_job_id')!=result.get('allocation',{}).get('job_id')
        or resource.get('full_account_GPU_rows_external_proofs_credentials_or_measurements_included')is not False
        or resource.get('original_scientific_plan_inputs_protocol_scorer_and_runtime_paths_preserved')is not True):
        raise ValueError('Exact bounded resource-only result provenance required')


def check(manifest_path,digest):
    if sha(manifest_path)!=digest:raise ValueError('Reviewed publication manifest changed')
    manifest=read(manifest_path)
    if (manifest['task_id']!='P17'or manifest['repository']!=REPOSITORY or manifest['visibility']!='public'
        or manifest['planned']!=16000 or manifest['full_native_benchmark_complete']is not False
        or manifest['reviewed_assays']!=9 or manifest['native_release_assays']!=217
        or manifest.get('no_pooled_metric_with_old30')is not True or manifest.get('scoring_calls')!=0
        or manifest['model_calls']!=0 or manifest['website_or_schedule_changes']is not False or manifest['shared_aggregate_paths_modified']is not False):raise ValueError('Exact additional9 pointwise stability adaptation only')
    validate_paths(manifest['files_sha256'])
    for mapping in ['support_sha256','private_evidence_sha256']:
        for name,expected in manifest[mapping].items():
            if Path(name).is_symlink()or sha(name)!=expected:raise ValueError('Frozen publication support/evidence changed')
    scanner=load('p17_narrow_secret_scanner',ROOT/'scripts/daily_backup.py');stage=HERE/'stage'
    for name,expected in manifest['files_sha256'].items():
        path=stage/name
        if path.is_symlink()or not path.is_file()or path.stat().st_size>=90*1024**2 or sha(path)!=expected:raise ValueError('Frozen public artifact changed or exceeds Git boundary')
        scanner.scan_file(path)
    result=read(stage/(PREFIX+'result.json'));scores=read(stage/(PREFIX+'scores.json'));done=read(stage/(PREFIX+'completion.json'));lock=sha(stage/(PREFIX+'prediction_lock.json'))
    validate_summary(result,scores,done,lock)
    validate_resource_summary(result)
    if sha(stage/RAW)!=manifest['raw_archive_sha256']:raise ValueError('Exact all-outcome/source archive required')
    meta=read(stage/RAW.replace('.tar.gz','.manifest.json'))
    if meta['archive_sha256']!=manifest['raw_archive_sha256']:raise ValueError('Archive seal differs')
    verify_archive(stage/RAW,meta['files']);return manifest


def validate_review(path,digest,manifest,manifest_sha):
    if path is None or digest is None or sha(path)!=digest:raise PermissionError('Exact independent publication review required')
    review=read(path);policy_path=POLICY
    policy=read(policy_path);reviewer=review.get('reviewer')
    if (reviewer==OWNER or reviewer not in ['/root',policy['independent_review_delegation']['P17_P19_scalar184']]
            or review.get('approved') is not True or review.get('manifest_sha256')!=manifest_sha
            or review.get('repository')!=REPOSITORY or review.get('visibility')!='public'
            or review.get('paths_sha256')!=manifest['files_sha256']
            or review.get('secret_archive_scans_verified') is not True
            or review.get('exclusions_verified') is not True):
        raise PermissionError('A different authorized reviewer must approve the concrete exact whitelist')
    if reviewer!='/root' and (sha(policy_path)!=manifest['delegated_review_policy_sha256']
            or review.get('delegation_sha256')!=manifest['delegated_review_policy_sha256']
            or sha(policy_path)!=POLICY_SHA or policy.get('owners',{}).get('P17')!=OWNER):
        raise PermissionError('Bounded delegated review conditions differ')
    return review


def durable_save(path,value):
    """Persist an exclusive claim before credentials, network or Git side effects."""
    path=Path(path)
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
        stream.flush();os.fsync(stream.fileno())
    descriptor=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(descriptor)
    finally:os.close(descriptor)


def safe_checkout_target(checkout,name):
    """Reject an escaping or symlinked parent before creating/copying a target."""
    checkout=Path(checkout);target=checkout/name;base=checkout.resolve()
    if checkout!=base or target!=target.resolve() or not target.resolve().is_relative_to(base):
        raise ValueError('Publication checkout target has a symlinked parent or escapes its checkout')
    return target


def verify_staged_bytes(checkout,expected):
    """Git clean filters/attributes must not alter any reviewed staged byte."""
    for name,digest in expected.items():
        safe_checkout_target(checkout,name)
        staged=subprocess.run(['git','show',':'+name],cwd=checkout,capture_output=True,check=True).stdout
        if hashlib.sha256(staged).hexdigest()!=digest:
            raise ValueError('Git staging transformed the exact reviewed publication bytes')


def check_previous_publication_attempts():
    # This separate condition has a separate immutable namespace. Old reviewed30
    # publication must remain untouched and does not authorize this publication.
    if any((HERE/name).exists() for name in ['attempt_started.json','publication_receipt.json']):
        raise FileExistsError('Preserve this condition publication attempt; reconcile before retry')


def publish(manifest,manifest_sha,review_path,review_sha):
    validate_review(review_path,review_sha,manifest,manifest_sha)
    receipt=HERE/'publication_receipt.json'
    if receipt.exists() or (HERE/'attempt_started.json').exists():
        raise FileExistsError('Preserve prior publication attempt; no automatic ambiguous push retry')
    with (ROOT/'.local/catalog_report_generation.lock').open('a') as generation:
        fcntl.flock(generation,fcntl.LOCK_EX)
        with (ROOT/'.local/evaluation_publication.lock').open('a') as publication:
            fcntl.flock(publication,fcntl.LOCK_EX)
            check_previous_publication_attempts()
            check(HERE/'manifest.json',manifest_sha)
            durable_save(HERE/'attempt_started.json',{'at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
                'manifest_sha256':manifest_sha,'independent_review_sha256':review_sha,'model_calls':0})
            helper=load('p17_narrow_git_helper',ROOT/'.local/litqa2_replay/incremental_upload.py')
            if helper.URL!=URL or helper.REPOSITORY!=REPOSITORY:raise ValueError('Exact GitHub helper destination required')
            destination=helper.confirm_destination()
            if destination['repository']!=REPOSITORY or destination['visibility']!='public' or destination['push_permission'] is not True:
                raise ValueError('Actual GitHub identity/public visibility/push permission differs')
            paths=sorted(ALLOWED)
            with tempfile.TemporaryDirectory(prefix='p17-additional9-publication-') as directory:
                checkout=Path(directory)
                def git(*args):return helper.git(*args,cwd=checkout)
                git('init','--quiet');git('remote','add','origin',URL)
                git('config','remote.origin.promisor','true');git('config','remote.origin.partialclonefilter','blob:none')
                git('sparse-checkout','init','--no-cone');git('sparse-checkout','set','--no-cone',*('/'+n for n in paths))
                git('fetch','--filter=blob:none','--depth=1','origin','main');before=git('rev-parse','FETCH_HEAD').stdout.strip()
                git('checkout','--detach','FETCH_HEAD');git('config','user.name','Codex');git('config','user.email','codex@localhost')
                for name in paths:
                    source=HERE/'stage'/name;target=safe_checkout_target(checkout,name)
                    if sha(source)!=manifest['files_sha256'][name]:raise ValueError('Captured local bytes changed')
                    if target.is_symlink() or target.exists() and sha(target)!=manifest['files_sha256'][name]:
                        raise ValueError('Existing immutable scoped public artifact differs')
                    target.parent.mkdir(parents=True,exist_ok=True);safe_checkout_target(checkout,name);shutil.copyfile(source,target)
                git('add','-f','--sparse','--',*paths)
                changed=set(git('diff','--cached','--name-only').stdout.splitlines())
                if not changed or not changed<=ALLOWED:raise ValueError('Unexpected paths or existing identical publication requires review')
                git('diff','--cached','--check','--',*paths)
                verify_staged_bytes(checkout,manifest['files_sha256'])
                git('commit','-m','Publish additional9 ProteinGym domain stability with exact sealed trajectories')
                helper.confirm_destination();git('push','origin','HEAD:refs/heads/main')
                commit=git('rev-parse','HEAD').stdout.strip();git('fetch','--filter=blob:none','origin','main')
                head=git('rev-parse','FETCH_HEAD').stdout.strip()
                for name in paths:
                    remote=subprocess.run(['git','show','FETCH_HEAD:'+name],cwd=checkout,capture_output=True,check=True).stdout
                    if hashlib.sha256(remote).hexdigest()!=manifest['files_sha256'][name]:raise ValueError('Remote committed bytes differ')
                value={'at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),'stage':'published',
                    'repository':REPOSITORY,'visibility':'public','push_permission_verified':True,
                    'previous_main_head':before,'commit_sha':commit,'verified_remote_main_head':head,
                    'remote_bytes_verified':True,'published_path_count':len(paths),'paths_sha256':manifest['files_sha256'],
                    'task_id':'P17','planned':16000,'full_native_benchmark_complete':False,'reviewed_assays':9,'native_release_assays':217,
                    'manifest_sha256':manifest_sha,'independent_review_sha256':review_sha,
                    'model_weights_environments_credentials_references_or_full_account_metadata_published':False,
                    'shared_aggregate_reports_modified':False,'website_or_schedule_changed':False,'new_model_calls':0}
                durable_save(receipt,value)
                print(json.dumps({k:value[k] for k in ['stage','commit_sha','published_path_count','remote_bytes_verified']}))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--publish',action='store_true');parser.add_argument('--review',type=Path);parser.add_argument('--review-sha256')
    args=parser.parse_args();manifest=check(HERE/'manifest.json',args.manifest_sha256)
    if not args.publish:
        print(json.dumps({'stage':'offline_P17_additional9_publication_checks_passed','public_paths':len(ALLOWED),
            'exact_sealed_actual_attempt_archive_verified':True,'published':False,'network_calls':0,'model_calls':0}));return
    publish(manifest,args.manifest_sha256,args.review,args.review_sha256)


if __name__=='__main__':main()
