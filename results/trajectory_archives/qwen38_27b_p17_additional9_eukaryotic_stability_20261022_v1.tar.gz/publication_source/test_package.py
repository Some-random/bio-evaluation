"""Artificial boundary checks only; no benchmark payload, scorer or network."""
from pathlib import Path
import hashlib,json,tempfile,unittest
from unittest.mock import patch
import package,publish,watch

def dump(path,value):path.write_text(json.dumps(value))
def key(i):return hashlib.sha256(str(i).encode()).hexdigest()

class PinTests(unittest.TestCase):
 def test_exact_source_pins_and_required_sources(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);pins={}
   for i in range(71):
    p=root/str(i);p.write_bytes(b'artificial pinned source');pins[str(p)]=publish.sha(p)
   plan={'frozen_files_sha256':pins,'input_manifest':str(root/'0'),'native_formula_source':str(root/'1')}
   package.verify_plan_pins(plan)
   (root/'0').write_bytes(b'changed')
   with self.assertRaises(ValueError):package.verify_plan_pins(plan)
   with self.assertRaises(ValueError):package.verify_plan_pins({**plan,'input_manifest':str(root/'unbound')})
 def test_archive_size_checked_before_capture(self):
  class Scanner:MAX_ARCHIVE_SCAN=2
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);source=root/'source';source.write_bytes(b'artificial')
   with self.assertRaises(ValueError):package.create_archive(root/'out',{'source/artificial':source},Scanner())
   self.assertFalse((root/'out').exists())

class SubmissionTests(unittest.TestCase):
 def fixture(self,root):
  claim=root/'submission_claim.json';dump(claim,{'plan_sha256':package.PLAN_SHA})
  value={'stage':'submitted','returncode':0,'job_id':'123456','plan_sha256':package.PLAN_SHA,'automatic_retry':False,'new_requested_GPUs':1,'submission_claim_sha256':publish.sha(claim),'command':['sbatch','--plan-sha256',package.PLAN_SHA]}
  path=root/'submission_receipt.json';dump(path,value);return path,value
 def test_job_is_taken_from_exact_condition_receipt_only(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);path,value=self.fixture(root);self.assertEqual(package.submission_identity(path)[0],'123456')
   for field,bad in [('stage','submitted_unknown'),('job_id','123456;foreign'),('plan_sha256','0'*64),('returncode',1),('automatic_retry',True),('new_requested_GPUs',2)]:
    dump(path,{**value,field:bad})
    with self.assertRaises(ValueError):package.submission_identity(path)
 def test_receipt_cannot_rebind_claim_or_command(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);path,value=self.fixture(root)
   dump(path,{**value,'command':['sbatch','--plan-sha256','wrong']})
   with self.assertRaises(ValueError):package.submission_identity(path)
   dump(path,value);dump(root/'submission_claim.json',{'plan_sha256':'other'})
   with self.assertRaises(ValueError):package.submission_identity(path)
 def test_terminal_accounting_must_be_successful_exact_parent_job(self):
  for output,valid in [('JobID|State|ExitCode|Elapsed\n123456|COMPLETED|0:0|00:01:00|\n',True),('123456|RUNNING|0:0|00:01:00|\n',False),('123456|FAILED|1:0|00:01:00|\n',False),('123456.batch|COMPLETED|0:0|00:01:00|\n',False)]:
   with patch.object(package.subprocess,'check_output',return_value=output):
    if valid:self.assertEqual(package.accounting_success('123456')[1][1],'COMPLETED')
    else:
     with self.assertRaises(ValueError):package.accounting_success('123456')

class PhaseTests(unittest.TestCase):
 def fixture(self,root,phase='development',count=3,valid=3):
  files={}
  for directory in ['requests','responses','outcomes']:
   (root/directory).mkdir()
   for i in range(count):
    suffix='.raw.json'if directory=='responses'else'.json';p=root/directory/(key(i)+suffix);p.write_bytes(b'artificial exact original');files[str(p.relative_to(root))]=publish.sha(p)
  total=3 if phase=='development' else 16000
  lock={'task_id':'P17','phase':phase,'planned':total,'plan_sha256':package.PLAN_SHA,'reference_labels_opened':False,'files_sha256':files};dump(root/'prediction_lock.json',lock)
  done={'task_id':'P17','phase':phase,'planned':total,'plan_sha256':package.PLAN_SHA,'prediction_lock_sha256':publish.sha(root/'prediction_lock.json'),'one_attempt_per_case':True,'all_delivered':valid==total,'not_dispatched':total-count,'artificial_exact_copy_gate_passed':phase=='development','attempted_confirmed':count,'terminal':count,'responses_saved':count,'delivery_passed':valid}
  done.update({k:0 for k in ['empty_finals','unknown_finals','http_errors','server_errors','transport_errors','response_errors','truncations','refusals','reasoning_present','tool_calls_present']});dump(root/'completion.json',done);return done
 def test_copy_gate_and_original_member_hash_required(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);self.fixture(root);self.assertEqual(len(package.sealed_phase(root,'development')[2]),11)
   (root/'requests'/(key(0)+'.json')).write_bytes(b'changed')
   with self.assertRaises(ValueError):package.sealed_phase(root,'development')
 def test_sealed_partial_benchmark_keeps_full_denominator(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);done=self.fixture(root,'benchmark',count=2,valid=1)
   self.assertEqual(package.sealed_phase(root,'benchmark')[0]['not_dispatched'],15998)
   dump(root/'completion.json',{**done,'planned':2})
   with self.assertRaises(ValueError):package.sealed_phase(root,'benchmark')
 def test_unsealed_extra_and_bad_development_gate_rejected(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);done=self.fixture(root);extra=root/'responses/foreign.json';extra.write_bytes(b'artificial')
   with self.assertRaises(ValueError):package.sealed_phase(root,'development')
   extra.unlink();dump(root/'completion.json',{**done,'artificial_exact_copy_gate_passed':False})
   with self.assertRaises(ValueError):package.sealed_phase(root,'development')
 def test_live_runtime_is_not_read_before_terminal_markers(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d)
   with patch.object(package,'SUBMISSION',root/'submission.json'),patch.object(package,'RUNTIME',root/'runtime'),patch.object(package,'sealed_phase')as output,patch.object(package,'terminal_identity')as terminal:
    self.assertIsNone(watch.runtime_ready());output.assert_not_called();terminal.assert_not_called()

class TerminalTests(unittest.TestCase):
 def fixture(self,root):
  (root/'benchmark').mkdir();dump(root/'benchmark/scores.json',{'artificial':True})
  values={'terminal_receipt.json':{'task_id':'P17','job_id':'123456','additional9_condition_terminal':True,'full_native217_complete':False,'planned_native_variants':16000,'native_score_sha256':publish.sha(root/'benchmark/scores.json'),'prediction_lock_sha256':'seal'},'allocation_started.json':{'job_id':'123456','plan_sha256':package.PLAN_SHA},'server_identity.json':{'job_id':'123456','plan_sha256':package.PLAN_SHA},'server_terminal.json':{'own_server_stopped':True},'scoring_attempt_started.json':{'sole_attempt':True,'protected_measurements_not_yet_opened':True,'prediction_lock_sha256':'seal'}}
  for name,value in values.items():dump(root/name,value)
  return values
 def test_server_stop_sole_score_and_actual_job_required(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);values=self.fixture(root);package.terminal_identity('123456',root)
   for filename,field,bad in [('server_terminal.json','own_server_stopped',False),('allocation_started.json','job_id','654321'),('scoring_attempt_started.json','sole_attempt',False)]:
    dump(root/filename,{**values[filename],field:bad})
    with self.assertRaises(ValueError):package.terminal_identity('123456',root)
    dump(root/filename,values[filename])
 def test_watcher_stops_on_failed_actual_or_CPU_job(self):
  for value,expected in [('123456|RUNNING|0:0|00:00:01|\n',False),('123456|COMPLETED|0:0|00:00:01|\n',True)]:
   with patch.object(watch.subprocess,'check_output',return_value=value):self.assertEqual(watch.job_state('123456'),expected)
  with patch.object(watch.subprocess,'check_output',return_value='123456|FAILED|1:0|00:00:01|\n'):
   with self.assertRaises(RuntimeError):watch.job_state('123456')
 def test_durable_claim_is_exclusive_and_fsynced(self):
  with tempfile.TemporaryDirectory()as d:
   path=Path(d)/'claim.json'
   with patch.object(watch.os,'fsync',wraps=watch.os.fsync)as fsync:
    watch.durable_save(path,{'artificial':True});self.assertEqual(fsync.call_count,2)
   with self.assertRaises(FileExistsError):watch.durable_save(path,{})

if __name__=='__main__':unittest.main()
