"""Artificial metadata only: exact resource provenance, no model/scorer/GPU."""
from pathlib import Path
import copy,json,tempfile,unittest
from unittest.mock import patch
import resource_provenance as provenance
import publish,watch,package

def dump(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value))

class ResourceBindingTests(unittest.TestCase):
 def fixture(self,root):
  execution=root/'execution';operation=root/'resource_v2';plan=execution/'plan.json';pins={}
  for i in range(71):
   path=execution/('artificial_source_'+str(i)+'.txt');path.parent.mkdir(parents=True,exist_ok=True);path.write_text('artificial original '+str(i));pins[str(path)]=provenance.sha(path)
  dump(plan,{'frozen_files_sha256':pins});plan_sha=provenance.sha(plan)
  policy=root/'policy.json';dump(policy,{'independent_review_delegation':{'P17_P19_scalar184':'/root/priority_runtime_review'}});policy_sha=provenance.sha(policy)
  descriptors={};support={}
  for field,name in [('resource_adapter','adapter_v4.py'),('shared_resource_binding','shared_binding.json'),('additional_proof_binding','proof_binding.json')]:
   path=root/name;path.write_text('artificial metadata/source '+field);descriptors[field]={'path':str(path),'sha256':provenance.sha(path)};support[str(path)]=provenance.sha(path)
  proof=root/'private_external_proof.json';dump(proof,{'private_external_job_rows':'DO_NOT_PUBLISH_EXTERNAL_ROWS'});proof_descriptor={'path':str(proof),'sha256':provenance.sha(proof)};support[str(proof)]=provenance.sha(proof)
  descriptors['root_authorization']={'path':str(policy),'sha256':policy_sha};support[str(policy)]=policy_sha
  for name in provenance.PUBLIC_SOURCE_NAMES:
   path=operation/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('# artificial operational source '+name+'\n');support[str(path)]=provenance.sha(path)
  manifest={'task_id':'P17','role':'P17_additional9_restored_operational_amendment','original_plan_path':str(plan),'original_plan_sha256':plan_sha,'original_engineering_admission_sha256':'a'*64,'original_frozen_file_count':71,'original_frozen_files_sha256':pins,'scientific_files_unchanged':True,'original_claim_receipt_and_runtime_paths_preserved':True,'new_scheduling_STOP_sha256':'d'*64,'preserved_legacy_STOPs_sha256':{},'gpus_requested':1,'project_gpu_ceiling':8,'new_scientific_or_case_permission':False,'no_automatic_retry':True,'priority_record_sha256':'e'*64,'additional_root_proofs':[proof_descriptor],'files_sha256':support,**descriptors}
  dump(operation/'manifest.json',manifest);manifest_sha=provenance.sha(operation/'manifest.json')
  grant={'reviewer':'/root/priority_runtime_review','approved':True,'role':'independent_P17_restored_operational_admission','manifest_sha256':manifest_sha,'root_authorization_sha256':policy_sha,'shared_resource_binding_sha256':descriptors['shared_resource_binding']['sha256'],'original_plan_sha256':plan_sha,'original_engineering_admission_sha256':'a'*64,'scientific_scope_unchanged':True,'priority_release_required':True};dump(operation/'engineering_admission.json',grant)
  binding={'original_scientific_plan_sha256':plan_sha,'amendment_manifest_path':str(operation/'manifest.json'),'amendment_manifest_sha256':manifest_sha,'amendment_admission_path':str(operation/'engineering_admission.json'),'amendment_admission_sha256':provenance.sha(operation/'engineering_admission.json')}
  constants={'EXECUTION':execution,'OPERATION':operation,'PLAN':plan,'PLAN_SHA':plan_sha,'MANIFEST_SHA':manifest_sha,'POLICY':policy,'POLICY_SHA':policy_sha}
  with patch.multiple(provenance,**constants):command=provenance.expected_command(binding,manifest)
  audit={provenance.AUDIT_MANIFEST_FIELD:manifest_sha,provenance.AUDIT_GRANT_FIELD:binding['amendment_admission_sha256'],'exact_resource_adapter':manifest['resource_adapter'],'shared_resource_binding':manifest['shared_resource_binding'],'additional_root_proofs':manifest['additional_root_proofs'],'additional_proof_binding':manifest['additional_proof_binding'],'jobs':[{'private_account_row':'DO_NOT_PUBLISH_ACCOUNT_ROWS'}]}
  audit_paths=[execution/'submission_v1/GPU_audit_at_submission.json',execution/'runtime/private_GPU_audit_at_start.json',execution/'runtime/private_GPU_audit_at_model_start.json']
  for path in audit_paths:dump(path,audit)
  audit_sha=provenance.sha(audit_paths[0]);dump(operation/'sole_command.json',{'command':command,'resource_amendment_sha256':manifest_sha,'resource_admission_sha256':binding['amendment_admission_sha256'],'GPU_audit_sha256':audit_sha})
  release={'issuer':'/root','approved':True,'role':'exact_P17_restored_scheduling_release','resource_amendment_sha256':manifest_sha,'original_plan_sha256':plan_sha,'prepared_by':provenance.OWNER,'root_authorization_sha256':policy_sha,'resource_admission_sha256':binding['amendment_admission_sha256'],'scheduling_only':True,'project_GPU_ceiling':8,'one_original_P17_allocation_only':True,'original_engineering_admission_sha256':'a'*64};dump(operation/'priority_release.json',release)
  review={'approved':True,'reviewer':'/root/priority_runtime_review','role':'independent_P17_restored_launch_and_STOP_clearance_review','manifest_sha256':manifest_sha,'engineering_admission_sha256':binding['amendment_admission_sha256'],'priority_release_sha256':provenance.sha(operation/'priority_release.json'),'root_authorization_sha256':policy_sha,'new_STOP_sha256':'d'*64,'may_clear_new_scheduling_STOP_only':True,'one_allocation_only':True};dump(operation/'launch_review.json',review)
  dump(operation/'STOP_clearance_receipt.json',{'owner':provenance.OWNER,'launch_review_sha256':provenance.sha(operation/'launch_review.json'),'manifest_sha256':manifest_sha,'priority_release_sha256':provenance.sha(operation/'priority_release.json'),'root_authorization_sha256':policy_sha,'removed_STOP_sha256':'d'*64,'legacy_STOPs_preserved':True})
  receipt={'stage':'submitted','returncode':0,'job_id':'123456','plan_sha256':plan_sha,'command':command,'GPU_audit_sha256':audit_sha}
  return binding,receipt,constants
 def test_full_projection_and_archive_keep_private_proofs_and_audits_out(self):
  with tempfile.TemporaryDirectory()as d:
   binding,receipt,constants=self.fixture(Path(d))
   with patch.multiple(provenance,**constants):
    result=provenance.terminal_projection(binding,receipt);sources=provenance.archive_sources(binding)
   self.assertEqual(result['actual_job_id'],'123456');self.assertEqual(len(sources),6)
   self.assertNotIn('DO_NOT_PUBLISH',json.dumps(result));self.assertTrue(all(path.suffix in {'.py','.sbatch'}for path in sources.values()))
   self.assertNotIn('private_external_proof.json',json.dumps(result))
 def test_changed_or_missing_restored_launch_and_STOP_clearance_history_rejected(self):
  for artifact in ['launch_review.json','STOP_clearance_receipt.json']:
   for mode in ['missing','changed']:
    with tempfile.TemporaryDirectory()as d:
     binding,receipt,constants=self.fixture(Path(d));path=constants['OPERATION']/artifact
     if mode=='missing':path.unlink()
     else:
      value=json.loads(path.read_bytes());value['manifest_sha256']='0'*64;dump(path,value)
     with patch.multiple(provenance,**constants):
      with self.assertRaises(ValueError):provenance.terminal_projection(binding,receipt)
 def test_unknown_manifest_or_grant_source_binding_is_rejected(self):
  for binding in [None,{}, {'amendment_admission_sha256':None}]:
   with self.assertRaises(ValueError):provenance.binding_from_freeze({'operational_resource_binding':binding})
 def test_changed_scientific_plan_or_bound_operational_source_is_rejected(self):
  for changed in ['PLAN','worker.py','engineering_admission.json']:
   with tempfile.TemporaryDirectory()as d:
    binding,receipt,constants=self.fixture(Path(d));path=constants['PLAN']if changed=='PLAN'else constants['OPERATION']/changed;path.write_bytes(b'changed')
    with patch.multiple(provenance,**constants):
     with self.assertRaises(ValueError):provenance.terminal_projection(binding,receipt)
 def test_owner_cannot_issue_its_own_resource_admission(self):
  with tempfile.TemporaryDirectory()as d:
   binding,receipt,constants=self.fixture(Path(d));path=constants['OPERATION']/'engineering_admission.json';grant=json.loads(path.read_bytes());grant['reviewer']=provenance.OWNER;dump(path,grant);binding['amendment_admission_sha256']=provenance.sha(path)
   with patch.multiple(provenance,**constants):
    with self.assertRaises(ValueError):provenance.verify_static_binding(binding)
 def test_actual_receipt_cannot_silently_use_old_worker_or_other_plan(self):
  with tempfile.TemporaryDirectory()as d:
   binding,receipt,constants=self.fixture(Path(d));receipt['command']=receipt['command'].copy();receipt['command'][2]=str(constants['EXECUTION']/'worker.sbatch')
   with patch.multiple(provenance,**constants):
    with self.assertRaises(ValueError):provenance.terminal_projection(binding,receipt)
 def test_actual_command_scalar_names_and_original_audit_digest_required(self):
  for field in ['resource_amendment_sha256','resource_admission_sha256','GPU_audit_sha256']:
   with tempfile.TemporaryDirectory()as d:
    binding,receipt,constants=self.fixture(Path(d));path=constants['OPERATION']/'sole_command.json';sole=json.loads(path.read_bytes());sole[field]='0'*64;dump(path,sole)
    with patch.multiple(provenance,**constants):
     with self.assertRaises(ValueError):provenance.terminal_projection(binding,receipt)
 def test_both_startup_observations_must_retain_same_proof_bindings(self):
  for name in ['private_GPU_audit_at_start.json','private_GPU_audit_at_model_start.json']:
   with tempfile.TemporaryDirectory()as d:
    binding,receipt,constants=self.fixture(Path(d));path=constants['EXECUTION']/'runtime'/name;audit=json.loads(path.read_bytes());audit['additional_proof_binding']={'changed':True};dump(path,audit)
    with patch.multiple(provenance,**constants):
     with self.assertRaises(ValueError):provenance.terminal_projection(binding,receipt)
 def test_missing_or_owner_priority_release_rejected(self):
  for mode in ['missing','owner']:
   with tempfile.TemporaryDirectory()as d:
    binding,receipt,constants=self.fixture(Path(d));path=constants['OPERATION']/'priority_release.json'
    if mode=='missing':path.unlink()
    else:
     release=json.loads(path.read_bytes());release['issuer']=provenance.OWNER;dump(path,release)
    with patch.multiple(provenance,**constants):
     with self.assertRaises(ValueError):provenance.terminal_projection(binding,receipt)
 def test_additional_root_proof_stays_pinned_but_is_never_archived(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);binding,receipt,constants=self.fixture(root)
   with patch.multiple(provenance,**constants):sources=provenance.archive_sources(binding)
   self.assertNotIn(root/'private_external_proof.json',sources.values());(root/'private_external_proof.json').write_text('changed')
   with patch.multiple(provenance,**constants):
    with self.assertRaises(ValueError):provenance.verify_static_binding(binding)
 def test_symlinked_operational_parent_rejected(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);binding,receipt,constants=self.fixture(root);source=constants['OPERATION']/'worker.py';source.unlink();source.symlink_to(root/'adapter_v4.py')
   with patch.multiple(provenance,**constants):
    with self.assertRaises(ValueError):provenance.verify_static_binding(binding)

class IntegrationTests(unittest.TestCase):
 def test_publisher_requires_exact_resource_projection_and_real_job(self):
  resource={'role':'resource_only_operational_provenance_not_new_scientific_condition','original_scientific_plan_sha256':package.PLAN_SHA,'actual_job_id':'123456','full_account_GPU_rows_external_proofs_credentials_or_measurements_included':False,'original_scientific_plan_inputs_protocol_scorer_and_runtime_paths_preserved':True}
  result={'allocation':{'job_id':'123456'},'operational_resource_provenance':resource};publish.validate_resource_summary(result)
  for field,bad in [('actual_job_id',None),('full_account_GPU_rows_external_proofs_credentials_or_measurements_included',True),('original_scientific_plan_sha256','0'*64)]:
   with self.assertRaises(ValueError):publish.validate_resource_summary({**result,'operational_resource_provenance':{**resource,field:bad}})
 def test_source_review_must_bind_same_future_resource_grant_as_freeze(self):
  with tempfile.TemporaryDirectory()as d:
   here=Path(d);files={}
   for name in ['watch.py','package.py','package_guard.py','package_CPU.sbatch','publish.py','resource_provenance.py','watcher.sbatch']:
    path=here/name;path.write_text('# artificial source');files[str(path)]=publish.sha(path)
   binding={'original_scientific_plan_sha256':provenance.PLAN_SHA,'amendment_manifest_path':str(provenance.OPERATION/'manifest.json'),'amendment_manifest_sha256':provenance.MANIFEST_SHA,'amendment_admission_path':str(provenance.OPERATION/'engineering_admission.json'),'amendment_admission_sha256':'b'*64}
   peer={'approved':True,'reviewer':'/root/priority_runtime_review','runtime_plan_sha256':package.PLAN_SHA,'files_sha256':files,'operational_resource_binding':{**binding,'amendment_admission_sha256':'c'*64}};review=here/'source_review.json';dump(review,peer)
   freeze={'task_id':'P17','runtime_plan_sha256':package.PLAN_SHA,'runtime_submission_receipt':str(package.SUBMISSION),'model_calls':0,'scoring_calls':0,'GPUs_requested':0,'publishes':False,'files_sha256':{**files,str(review):publish.sha(review)},'source_review':str(review),'source_review_sha256':publish.sha(review),'operational_resource_binding':binding};path=here/'source_freeze.json';dump(path,freeze)
   with patch.object(watch,'HERE',here),patch.object(provenance,'verify_static_binding')as gate:
    with self.assertRaises(PermissionError):watch.source_check(path,publish.sha(path))
    gate.assert_not_called()

if __name__=='__main__':unittest.main()
