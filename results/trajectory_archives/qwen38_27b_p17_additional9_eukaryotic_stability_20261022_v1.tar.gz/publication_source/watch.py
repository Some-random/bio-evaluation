"""Prepared CPU-only continuation: sealed result -> package -> peer review -> publish.

This source is inert until explicitly launched with an independently reviewed
source freeze. It never allocates a GPU, invokes the benchmark/scorer, reads
unfinished request/response files, changes the queue, or retries a submission.
"""
from pathlib import Path
import argparse,fcntl,json,os,re,subprocess,time
import package,publish
import resource_provenance
HERE=Path(__file__).resolve().parent

def durable_save(path,value):
 path=Path(path)
 with path.open('x')as stream:
  json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n');stream.flush();os.fsync(stream.fileno())
 fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)

def source_check(path,digest):
 if Path(path)!=HERE/'source_freeze.json':raise ValueError('Only this exact successor source-freeze path is eligible')
 if publish.sha(package.regular(path))!=digest:raise ValueError('Exact independently reviewed source freeze changed')
 freeze=package.read(path)
 if (freeze.get('task_id')!='P17'or freeze.get('runtime_plan_sha256')!=package.PLAN_SHA
     or freeze.get('runtime_submission_receipt')!=str(package.SUBMISSION)
     or freeze.get('model_calls')!=0 or freeze.get('scoring_calls')!=0
     or freeze.get('GPUs_requested')!=0 or freeze.get('publishes')is not False):
  raise ValueError('Frozen CPU publication-only source required')
 for name,expected in freeze['files_sha256'].items():
  if publish.sha(package.regular(name))!=expected:raise ValueError('Frozen publication source/support changed')
 for name in ['watch.py','package.py','package_guard.py','package_CPU.sbatch','publish.py','resource_provenance.py','watcher.sbatch']:
  if str(HERE/name)not in freeze['files_sha256']:raise ValueError('Every executable source must be pinned')
 review=Path(freeze['source_review']);review_sha=freeze['source_review_sha256']
 if publish.sha(package.regular(review))!=review_sha:raise ValueError('Exact independent source review changed')
 peer=package.read(review);policy=package.read(publish.POLICY)
 if (peer.get('approved')is not True or peer.get('reviewer')==publish.OWNER
     or peer.get('reviewer')not in ['/root',policy['independent_review_delegation']['P17_P19_scalar184']]
     or publish.sha(publish.POLICY)!=publish.POLICY_SHA
     or peer.get('runtime_plan_sha256')!=package.PLAN_SHA
     or peer.get('files_sha256')!={k:v for k,v in freeze['files_sha256'].items()if k!=str(review)}):
  raise PermissionError('A different authorized peer must approve the exact publication source')
 binding=resource_provenance.binding_from_freeze(freeze)
 if peer.get('operational_resource_binding')!=binding:raise PermissionError('Independent source review must bind the exact resource manifest/admission')
 resource_provenance.verify_static_binding(binding)
 return freeze

def job_state(job):
 output=subprocess.check_output(['sacct','-j',job,'--format=JobID,State,ExitCode,Elapsed','-P'],text=True)
 rows=[line.split('|') for line in output.splitlines() if line.startswith(job+'|')]
 if len(rows)!=1:raise ValueError('Exact actual allocation accounting unavailable')
 row=rows[0];state=row[1].split()[0].rstrip('+')
 if state in {'COMPLETED','FAILED','CANCELLED','TIMEOUT','OUT_OF_MEMORY','NODE_FAIL','PREEMPTED','BOOT_FAIL','DEADLINE','REVOKED'}:
  if state!='COMPLETED'or row[2]!='0:0':raise RuntimeError('Actual job failed; no automatic retry or publication')
  return True
 return False

def runtime_ready():
 # These terminal metadata checks precede all actual output payload reads.
 if not package.SUBMISSION.exists():return None
 job,_=package.submission_identity()
 if not job_state(job):return None
 if not(package.RUNTIME/'terminal_receipt.json').exists():raise RuntimeError('Completed actual job lacks native terminal receipt; owner review required')
 package.terminal_identity(job)
 return job

def submit_packager(freeze_path,freeze_sha,runtime_job):
 if any((HERE/name).exists()for name in ['packaging_submission_claim.json','packaging_submission.json','packaging_submission_error.json']):
  raise FileExistsError('Existing CPU submission or ambiguity must not be retried')
 source_check(freeze_path,freeze_sha)
 durable_save(HERE/'packaging_submission_claim.json',{'at_pacific':package.now(),'runtime_job_id':runtime_job,'source_freeze_sha256':freeze_sha,'sole_CPU_submission':True,'GPU_requests':0,'model_calls':0,'scoring_calls':0})
 command=['sbatch','--parsable',str(HERE/'package_CPU.sbatch'),'--freeze',str(freeze_path),'--freeze-sha256',freeze_sha]
 try:
  result=subprocess.run(command,capture_output=True,text=True,timeout=90)
  receipt={'at_pacific':package.now(),'returncode':result.returncode,'stdout':result.stdout.strip(),'stderr':result.stderr.strip(),'command':command,'runtime_job_id':runtime_job,'source_freeze_sha256':freeze_sha,'automatic_retry':False,'model_calls':0,'scoring_calls':0,'GPU_requests':0}
  if result.returncode==0 and re.fullmatch(r'[0-9]+(?:;[A-Za-z0-9_.-]+)?',result.stdout.strip()):receipt.update(stage='submitted_CPU_only_packaging',job_id=result.stdout.strip().split(';')[0])
  else:receipt['stage']='CPU_submission_failed_or_ambiguous_requires_review'
  durable_save(HERE/'packaging_submission.json',receipt)
  if 'job_id'not in receipt:raise RuntimeError('CPU submission failed or ambiguous; no retry')
  return receipt
 except Exception as error:
  if not(HERE/'packaging_submission_error.json').exists():durable_save(HERE/'packaging_submission_error.json',{'at_pacific':package.now(),'error_type':type(error).__name__,'automatic_retry':False})
  raise

def status(stage,**extra):
 value={'at_pacific':package.now(),'stage':stage,'pid':os.getpid(),'model_calls':0,'scoring_calls':0,'GPU_requests':0,**extra}
 path=HERE/'watch_status.json';temporary=HERE/'watch_status.tmp';temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.replace(path)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--freeze',type=Path,required=True);ap.add_argument('--freeze-sha256',required=True)
 ap.add_argument('--publish-after-peer-review',action='store_true');args=ap.parse_args()
 os.umask(0o077);os.environ['CUDA_VISIBLE_DEVICES']=''
 with(HERE/'watch.lock').open('a')as own:
  fcntl.flock(own,fcntl.LOCK_EX|fcntl.LOCK_NB);source_check(args.freeze,args.freeze_sha256)
  while not(HERE/'STOP').exists():
   if(HERE/'publication_receipt.json').exists():status('published_terminal',receipt_sha256=publish.sha(HERE/'publication_receipt.json'));return
   if not(HERE/'packaging_submission.json').exists():
    if(HERE/'packaging_submission_claim.json').exists():raise FileExistsError('Prior ambiguous CPU claim requires reconciliation')
    job=runtime_ready()
    if job is None:status('waiting_exact_runtime_seal_score_server_stop_and_successful_actual_job');time.sleep(30);continue
    receipt=submit_packager(args.freeze,args.freeze_sha256,job);status('CPU_packaging_submitted',job_id=receipt['job_id'])
   receipt=package.read(HERE/'packaging_submission.json')
   if receipt.get('stage')!='submitted_CPU_only_packaging':raise RuntimeError('CPU packaging submission did not succeed')
   if not job_state(receipt['job_id']):status('waiting_CPU_packager_terminal',job_id=receipt['job_id']);time.sleep(30);continue
   manifest=HERE/'manifest.json';packaging=HERE/'packaging_receipt.json'
   if not manifest.exists()or not packaging.exists():raise RuntimeError('Successful CPU packaging has no sealed artifacts')
   digest=publish.sha(manifest);m=publish.check(manifest,digest)
   peer=HERE/'publication_review.json'
   if not peer.exists():status('actual_bundle_requires_independent_peer_review',manifest_sha256=digest);time.sleep(30);continue
   peer_sha=publish.sha(peer);publish.validate_review(peer,peer_sha,m,digest)
   if not args.publish_after_peer_review:status('exact_bundle_peer_reviewed_ready_to_publish',manifest_sha256=digest,review_sha256=peer_sha);return
   source_check(args.freeze,args.freeze_sha256);publish.publish(m,digest,peer,peer_sha)
   status('published_terminal',receipt_sha256=publish.sha(HERE/'publication_receipt.json'));return
if __name__=='__main__':
 try:main()
 except Exception as error:
  status('stopped_for_review_no_automatic_retry',error_type=type(error).__name__)
  raise
