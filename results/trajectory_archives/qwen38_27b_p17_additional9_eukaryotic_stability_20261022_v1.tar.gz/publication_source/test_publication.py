"""Artificial publication boundaries; no credentials, network or git writes."""
from contextlib import redirect_stdout
from pathlib import Path
import hashlib
import io
import json
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch
import publish


class PublicationTests(unittest.TestCase):
    def test_only_eight_exact_paths_no_shared_reports_or_website(self):
        publish.validate_paths(publish.ALLOWED)
        self.assertEqual(len(publish.ALLOWED),8)
        for added in ['reports/RESULTS_AND_REMAINING_WORK.md','docs/index.html','../escape','/tmp/unrelated']:
            with self.assertRaises(ValueError):publish.validate_paths(publish.ALLOWED|{added})

    def test_exact_regular_archive_bytes_required(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'fixture.tar.gz';body=b'artificial output';meta={'safe.json':{'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}}
            with tarfile.open(path,'w:gz') as tar:
                item=tarfile.TarInfo('safe.json');item.size=len(body);tar.addfile(item,io.BytesIO(body))
            publish.verify_archive(path,meta)
            with self.assertRaises(ValueError):publish.verify_archive(path,{'safe.json':{'bytes':len(body),'sha256':'0'*64}})

    def test_extra_reference_file_link_or_duplicate_is_rejected(self):
        for kind in ['extra','link','duplicate','traversal']:
            with tempfile.TemporaryDirectory() as d:
                path=Path(d)/'fixture.tar.gz';body=b'artificial'
                with tarfile.open(path,'w:gz') as tar:
                    item=tarfile.TarInfo('safe.json');item.size=len(body);tar.addfile(item,io.BytesIO(body))
                    item=tarfile.TarInfo({'extra':'protected_reference.csv','link':'link','duplicate':'safe.json','traversal':'../outside'}[kind])
                    if kind=='link':item.type=tarfile.SYMTYPE;item.linkname='/private'
                    else:item.size=len(body)
                    tar.addfile(item,None if kind=='link' else io.BytesIO(body))
                expected={'safe.json':{'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}}
                with self.assertRaises(ValueError):publish.verify_archive(path,expected)

    def test_owner_cannot_approve_or_change_reviewed_whitelist(self):
        policy_path=publish.POLICY
        policy=publish.read(policy_path);manifest={'files_sha256':{'artificial':'hash'},'delegated_review_policy_sha256':publish.sha(policy_path)}
        self.assertEqual(publish.OWNER,'/root/main_docs_refresh')
        self.assertEqual(policy_path.name,'root_authorization.json')
        review={'reviewer':'/root/priority_runtime_review','approved':True,'manifest_sha256':'manifest',
            'repository':publish.REPOSITORY,'visibility':'public','paths_sha256':manifest['files_sha256'],
            'secret_archive_scans_verified':True,'exclusions_verified':True,'delegation_sha256':publish.sha(policy_path)}
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'review.json';path.write_text(json.dumps(review));publish.validate_review(path,publish.sha(path),manifest,'manifest')
            for field,value in [('reviewer',publish.OWNER),('approved',False),('manifest_sha256','changed'),('paths_sha256',{}),('exclusions_verified',False),('delegation_sha256','changed')]:
                bad={**review,field:value};path.write_text(json.dumps(bad))
                with self.assertRaises(PermissionError):publish.validate_review(path,publish.sha(path),manifest,'manifest')

    def test_default_command_never_enters_network_or_publish(self):
        with patch.object(sys,'argv',['publish.py','--manifest-sha256','artificial']),patch.object(publish,'check',return_value={}),patch.object(publish,'publish') as network:
            with redirect_stdout(io.StringIO()) as output:publish.main()
            self.assertFalse(json.loads(output.getvalue())['published']);network.assert_not_called()

    def test_this_condition_ambiguous_push_is_never_retried(self):
        with tempfile.TemporaryDirectory() as directory:
            base=Path(directory)
            with patch.object(publish,'HERE',base):
                publish.check_previous_publication_attempts()
                for name in ['attempt_started.json','publication_receipt.json']:
                    path=base/name;path.write_text('{}')
                    with self.assertRaises(FileExistsError):publish.check_previous_publication_attempts()
                    path.unlink()


class NativeSummaryTests(unittest.TestCase):
    def test_missing_delivery_never_produces_native_score_or_reference_access(self):
        result={'planned':16000,'primary_metric':'native_Spearman','primary_metric_value':None}
        score={'planned_variants':16000,'reviewed_assays':9,'native_release_assays':217,'prediction_lock_sha256':'seal','primary_native_Spearman':None,'full_native_benchmark_complete':False,'references_opened':False}
        done={'planned':16000,'delivery_passed':12,'responses_saved':13,'terminal':13,'attempted_confirmed':13,'prediction_lock_sha256':'seal'}
        publish.validate_summary(result,score,done,'seal')
        for k,v in [('planned_variants',13),('references_opened',True),('primary_native_Spearman',0.5)]:
            with self.assertRaises(ValueError):publish.validate_summary(result,{**score,k:v},done,'seal')
        with self.assertRaises(ValueError):publish.validate_summary(result,score,{**done,'planned':13},'seal')

    def test_complete_delivery_with_undefined_native_assay_metric_is_preserved(self):
        result={'planned':16000,'primary_metric':'native_Spearman','primary_metric_value':None}
        score={'planned_variants':16000,'reviewed_assays':9,'native_release_assays':217,'prediction_lock_sha256':'seal','primary_native_Spearman':None,'full_native_benchmark_complete':False,'references_opened':True}
        done={'planned':16000,'delivery_passed':16000,'responses_saved':16000,'terminal':16000,'attempted_confirmed':16000,'prediction_lock_sha256':'seal'}
        publish.validate_summary(result,score,done,'seal')



class DurableAndStagingTests(unittest.TestCase):
    def root_fixture(self,root):
        (root/'.local').mkdir();here=root/'publication';here.mkdir();return here

    def test_claim_file_and_parent_fsync_before_any_credential_helper(self):
        import os
        from types import SimpleNamespace
        for failure_at in [None,1,2]:
            with tempfile.TemporaryDirectory() as directory:
                root=Path(directory);here=self.root_fixture(root);events=[]
                def fsync(fd):
                    events.append('fsync')
                    if failure_at==len(events):raise OSError('artificial fsync failure')
                def load(*args):
                    self.assertEqual(events,['fsync','fsync']);events.append('credentials')
                    raise RuntimeError('artificial stop before credentials are read')
                with patch.object(publish,'ROOT',root),patch.object(publish,'HERE',here),patch.object(publish,'validate_review'),patch.object(publish,'check_previous_publication_attempts'),patch.object(publish,'check'),patch.object(publish.os,'fsync',side_effect=fsync),patch.object(publish,'load',side_effect=load) as helper:
                    with self.assertRaises(OSError if failure_at else RuntimeError):publish.publish({},'artificial',None,None)
                self.assertEqual(helper.call_count,0 if failure_at else 1)
                self.assertTrue((here/'attempt_started.json').is_file())

    def test_claim_is_exclusive_and_prevents_second_side_effect(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'claim.json';publish.durable_save(path,{'artificial':True})
            with self.assertRaises(FileExistsError):publish.durable_save(path,{})

    def test_parent_symlink_is_rejected_before_directory_creation_or_copy(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);checkout=root/'checkout';outside=root/'outside';checkout.mkdir();outside.mkdir()
            (checkout/'reports').symlink_to(outside,target_is_directory=True)
            with self.assertRaises(ValueError):publish.safe_checkout_target(checkout,'reports/new/result.md')
            self.assertFalse((outside/'new').exists())
            with self.assertRaises(ValueError):publish.safe_checkout_target(checkout,'../outside/result.md')
            (checkout/'reports').unlink();inside=checkout/'inside';inside.mkdir();(checkout/'reports').symlink_to(inside,target_is_directory=True)
            with self.assertRaises(ValueError):publish.safe_checkout_target(checkout,'reports/result.md')
            self.assertEqual(publish.safe_checkout_target(checkout,'results/new.json'),checkout/'results/new.json')

    def test_real_git_clean_filter_transformation_fails_before_commit(self):
        import subprocess,shlex
        with tempfile.TemporaryDirectory() as directory:
            checkout=Path(directory)
            def git(*args):return subprocess.run(['git',*args],cwd=checkout,capture_output=True,check=True)
            git('init','--quiet')
            original=b'artificial reviewed lower case\n';path=checkout/'result.md';path.write_bytes(original)
            (checkout/'.gitattributes').write_text('*.md filter=artificial_upper\n')
            script='import sys; sys.stdout.buffer.write(sys.stdin.buffer.read().upper())'
            git('config','filter.artificial_upper.clean',shlex.quote(sys.executable)+' -c '+shlex.quote(script))
            git('add','--','result.md')
            self.assertNotEqual(git('show',':result.md').stdout,original)
            with self.assertRaises(ValueError):publish.verify_staged_bytes(checkout,{'result.md':hashlib.sha256(original).hexdigest()})
            with self.assertRaises(subprocess.CalledProcessError):git('rev-parse','--verify','HEAD')
            git('config','filter.artificial_upper.clean','cat');git('add','--renormalize','--','result.md')
            publish.verify_staged_bytes(checkout,{'result.md':hashlib.sha256(original).hexdigest()})

if __name__=='__main__':unittest.main()
