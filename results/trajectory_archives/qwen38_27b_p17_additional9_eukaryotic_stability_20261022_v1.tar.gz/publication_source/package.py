"""Offline packaging of the sealed additional9 result, never generation/scoring.

A terminal undefined primary metric is publishable with the complete planned
16,000 denominator and exact actual attempts. No old30 outputs are combined.
"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import fcntl,gzip,hashlib,importlib.util,json,os,re,shutil,subprocess,sys,tarfile
import publish
import resource_provenance
ROOT=publish.ROOT
HERE=Path(__file__).resolve().parent
EXECUTION=HERE.parent/'additional9_eukaryotic_stability_v3'
RUNTIME=EXECUTION/'runtime'
PLAN_SHA='7f7907abc333cf28bdecfda7da586dd6f3eec791ac4d96fb393674c33f03cb30'
SUBMISSION=EXECUTION/'submission_v1/submission_receipt.json'
SOURCE_NAMES=('protocol.py','prepare_inputs.py','runner.py','scorer.py','worker.py','admission.py',
 'check_installed_API.py','scorer_runtime.py','restore_cpu_numeric.py','check_scorer_runtime.py',
 'freeze.py','worker.sbatch','CPU_validation.json','CPU_terminal.json','test_contract.py',
 'test_scoring.py','test_runner.py','test_worker.py','test_provenance.py','test_scorer_runtime.py',
 'check_cpu.py','CPU.sbatch','submission_v1/wait_capacity.py','submission_v1/admission_validation.py')
RECEIPT_NAMES=('CPU_scorer_preflight.json','installed_API_check.json','model_environment.json',
 'server_identity.json','server_terminal.json','scoring_attempt_started.json','terminal_receipt.json','allocation_started.json')
PUBLICATION_SOURCES=('package.py','publish.py','package_guard.py','package_CPU.sbatch','watch.py',
 'test_package.py','test_publication.py','resource_provenance.py','test_resource_provenance.py','watcher.sbatch','source_freeze.json')
SUPPORT=(ROOT/'scripts/daily_backup.py',ROOT/'.local/litqa2_replay/incremental_upload.py',
 ROOT/'scripts/publication_destination.py',ROOT/'configs/publication_destination.json',
 ROOT/'.local/litqa2_replay/github_credential_helper.py',publish.POLICY)

def now():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def read(path):return json.loads(Path(path).read_bytes())
def save(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('x')as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
def regular(path):
 path=Path(path)
 if path.is_symlink()or not path.is_file():raise ValueError('Regular original file required')
 return path

def verify_plan_pins(plan):
 pins=plan['frozen_files_sha256']
 if len(pins)!=71:raise ValueError('Exact frozen71 source pins required')
 for key in ['input_manifest','native_formula_source']:
  if str(Path(plan[key]))not in pins:raise ValueError('Required source missing from exact plan')
 for name,digest in pins.items():
  path=Path(name)
  if not path.is_absolute()or publish.sha(regular(path))!=digest:raise ValueError('Exact frozen source pin changed')

def submission_identity(path=SUBMISSION):
 receipt=read(regular(path));job=receipt.get('job_id')
 if (receipt.get('stage')!='submitted'or receipt.get('returncode')!=0
     or receipt.get('plan_sha256')!=PLAN_SHA or not isinstance(job,str)or not re.fullmatch(r'[0-9]+',job)
     or receipt.get('automatic_retry')is not False or receipt.get('new_requested_GPUs')!=1):
  raise ValueError('Exact successful immutable additional9 submission receipt required')
 claim=Path(path).parent/'submission_claim.json'
 if publish.sha(regular(claim))!=receipt['submission_claim_sha256']:raise ValueError('Sole submission claim changed')
 if read(claim).get('plan_sha256')!=PLAN_SHA:raise ValueError('Sole claim plan differs')
 command=receipt.get('command',[])
 if '--plan-sha256'not in command or command[command.index('--plan-sha256')+1]!=PLAN_SHA:
  raise ValueError('Submitted command was not exact frozen condition')
 return job,receipt

def accounting_success(job):
 output=subprocess.check_output(['sacct','-j',job,'--format=JobID,State,ExitCode,Elapsed','-P'],text=True)
 rows=[line.split('|')for line in output.splitlines()if line.startswith(job+'|')]
 if len(rows)!=1 or rows[0][1:3]!=['COMPLETED','0:0']:raise ValueError('Exact successful actual allocation must be terminal')
 return output,rows[0]

def terminal_identity(job,root=RUNTIME):
 terminal=read(regular(root/'terminal_receipt.json'));allocation=read(regular(root/'allocation_started.json'))
 server=read(regular(root/'server_terminal.json'));identity=read(regular(root/'server_identity.json'))
 attempt=read(regular(root/'scoring_attempt_started.json'))
 if (terminal.get('task_id')!='P17'or terminal.get('job_id')!=job
     or allocation.get('job_id')!=job or allocation.get('plan_sha256')!=PLAN_SHA
     or identity.get('job_id')!=job or identity.get('plan_sha256')!=PLAN_SHA
     or server.get('own_server_stopped')is not True or server.get('server_never_started')is True
     or terminal.get('additional9_condition_terminal')is not True
     or terminal.get('full_native217_complete')is not False or terminal.get('planned_native_variants')!=16000
     or terminal.get('native_score_sha256')!=publish.sha(regular(root/'benchmark/scores.json'))
     or attempt.get('sole_attempt')is not True or attempt.get('protected_measurements_not_yet_opened')is not True
     or attempt.get('prediction_lock_sha256')!=terminal.get('prediction_lock_sha256')):
  raise ValueError('Exact own server stopped and sole sealed native scoring completion required')
 return terminal

def sealed_phase(folder,phase):
 folder=Path(folder);done=read(regular(folder/'completion.json'));lock=read(regular(folder/'prediction_lock.json'))
 total=16000 if phase=='benchmark'else 3
 if (phase not in ['development','benchmark']or done.get('task_id')!='P17'or done.get('phase')!=phase
     or lock.get('task_id')!='P17'or lock.get('phase')!=phase or done.get('planned')!=total
     or lock.get('planned')!=total or done.get('plan_sha256')!=PLAN_SHA or lock.get('plan_sha256')!=PLAN_SHA
     or done.get('prediction_lock_sha256')!=publish.sha(folder/'prediction_lock.json')
     or done.get('one_attempt_per_case')is not True or lock.get('reference_labels_opened')is not False):
  raise ValueError('Exact whole planned once-only phase seal required')
 actual={str(regular(path).relative_to(folder))for directory in ['requests','responses','outcomes']for path in (folder/directory).iterdir()}
 if set(lock['files_sha256'])!=actual:raise ValueError('Unsealed extra or missing attempt file')
 kinds={'requests':set(),'outcomes':set(),'responses':set()};members={}
 for name,digest in lock['files_sha256'].items():
  path=Path(name)
  if path.is_absolute()or'..'in path.parts or len(path.parts)!=2 or path.parts[0]not in kinds or publish.sha(folder/path)!=digest:
   raise ValueError('Unsafe or changed sealed original member')
  kind,filename=path.parts
  suffix='.json'if kind!='responses'else'.raw.json'if filename.endswith('.raw.json')else'.http_error.raw'
  if not filename.endswith(suffix):raise ValueError('Unknown attempt filename')
  key=filename[:-len(suffix)]
  if not re.fullmatch(r'[0-9a-f]{64}',key)or key in kinds[kind]:raise ValueError('Duplicate/foreign attempt identity')
  kinds[kind].add(key);members[phase+'/'+name]=folder/path
 if kinds['requests']!=kinds['outcomes']or not kinds['responses']<=kinds['requests']:
  raise ValueError('Every actual request needs one terminal outcome, no foreign response')
 attempted=len(kinds['requests']);raw=sum(name.endswith('.raw.json')for name in actual)
 if (done.get('attempted_confirmed')!=attempted or done.get('terminal')!=attempted
     or done.get('responses_saved')!=raw or done.get('not_dispatched')!=total-attempted
     or not 0<=done['delivery_passed']<=raw<=attempted<=total):raise ValueError('Full denominator and exact actual attempts differ')
 clean=done['delivery_passed']==total and all(done.get(k)==0 for k in ['empty_finals','unknown_finals','http_errors','server_errors','transport_errors','response_errors','truncations','refusals','reasoning_present','tool_calls_present'])
 if done.get('all_delivered')is not (done['delivery_passed']==total):raise ValueError('Delivery completion claim differs')
 if phase=='development'and(not clean or done.get('artificial_exact_copy_gate_passed')is not True):raise ValueError('Actual artificial3 copy gate must pass')
 for name in ['completion.json','prediction_lock.json']:members[phase+'/'+name]=folder/name
 return done,lock,members

def archive_sources(plan):
 members={}
 for name in SOURCE_NAMES:
  path=regular(EXECUTION/name)
  if publish.sha(path)!=plan['frozen_files_sha256'][str(path)]:raise ValueError('Frozen source differs')
  members['source/'+name]=path
 members['source/plan.json']=regular(EXECUTION/'plan.json')
 members['source/native_performance_DMS_benchmarks.py']=regular(Path(plan['native_formula_source']))
 members['source/input_manifest.original.json']=regular(Path(plan['input_manifest']))
 inputs=read(plan['input_manifest'])
 if len(inputs['assays'])!=9 or inputs['planned_native_variants']!=16000:raise ValueError('Exact nine inputs only')
 for assay in inputs['assays']:
  path=regular(assay['input_path'])
  if publish.sha(path)!=assay['input_sha256']:raise ValueError('Original reviewed input changed')
  key='prepared/'+path.name
  if key in members:raise ValueError('Duplicate input member')
  members[key]=path
 for name in RECEIPT_NAMES:members['runtime_receipts/'+name]=regular(RUNTIME/name)
 members['submission/submission_receipt.json']=regular(SUBMISSION)
 for name in PUBLICATION_SOURCES:members['publication_source/'+name]=regular(HERE/name)
 # Native ZIP/measurements, model assets, environments, credentials and whole-
 # account GPU audits are deliberately absent from this exact source whitelist.
 return members

def create_archive(target,members,scanner):
 projected=sum(regular(path).stat().st_size for path in members.values())
 if projected>scanner.MAX_ARCHIVE_SCAN:raise ValueError('Archive exceeds final scanner limit')
 metadata={};target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('xb')as output:
  with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0,compresslevel=6)as compressed:
   with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT)as archive:
    for name,path in sorted(members.items()):
     scanner.safe_archive_member(name);regular(path);scanner.scan_file(path)
     digest=publish.sha(path);size=path.stat().st_size;item=tarfile.TarInfo(name);item.size=size;item.mode=0o644;item.mtime=0
     with path.open('rb')as source:archive.addfile(item,source)
     if publish.sha(path)!=digest:raise ValueError('Source changed during capture')
     metadata[name]={'bytes':size,'sha256':digest}
 return metadata

def verify_raw_predictions(plan,lock,done):
 # Reuse only the pinned scorer's input/raw/outcome validator. This does not
 # call score(), native_aggregate(), SciPy, or any native reference loader.
 sys.path.insert(0,str(EXECUTION))
 try:
  scorer=publish.load('p17_add9_original_provenance_only',EXECUTION/'scorer.py')
  manifest=read(plan['input_manifest']);assays=[]
  for record in manifest['assays']:
   cases=[json.loads(line)for line in Path(record['input_path']).read_text().splitlines()]
   assays.append({**record,'cases':cases})
  predictions=scorer.verified_predictions(assays,RUNTIME/'benchmark',lock,done)
  if len(predictions)!=done['delivery_passed']:raise ValueError('Independent raw prediction count differs')
 finally:sys.path.pop(0)

def main():
 with(HERE/'packaging.lock').open('a')as own:
  fcntl.flock(own,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if any((HERE/name).exists()for name in ['manifest.json','packaging_started.json','stage']):raise FileExistsError('Preserve prior packaging attempt')
  if publish.sha(regular(EXECUTION/'plan.json'))!=PLAN_SHA:raise ValueError('Exact final runtime plan required')
  plan=read(EXECUTION/'plan.json');verify_plan_pins(plan)
  resource_binding=resource_provenance.binding_from_freeze(read(HERE/'source_freeze.json'))
  resource_provenance.verify_static_binding(resource_binding)
  job,submission=submission_identity();accounting,row=accounting_success(job)
  terminal=terminal_identity(job)
  operational_provenance=resource_provenance.terminal_projection(resource_binding,submission)
  dev,_,members=sealed_phase(RUNTIME/'development','development')
  done,lock,benchmark=sealed_phase(RUNTIME/'benchmark','benchmark');members.update(benchmark)
  score=read(regular(RUNTIME/'benchmark/scores.json'))
  if (score.get('condition')!=plan['condition']or score.get('prediction_lock_sha256')!=done['prediction_lock_sha256']
      or terminal['prediction_lock_sha256']!=done['prediction_lock_sha256']
      or terminal['native_scoring_status']!=score['native_scoring_status']or terminal['primary_native_Spearman']!=score['primary_native_Spearman']):
   raise ValueError('Exact sole native score and lock required')
  verify_raw_predictions(plan,lock,done)
  result={'task_id':'P17','run_id':publish.RUN_ID,'condition':plan['condition'],'model':plan['model'],
   'model_revision':plan['model_revision'],'dtype':'bfloat16','tensor_parallel_size':1,'generation':plan['generation'],
   'planned':16000,'attempted':done['attempted_confirmed'],'responses_saved':done['responses_saved'],'delivered':done['delivery_passed'],
   'not_dispatched':done['not_dispatched'],'reviewed_assays':9,'earlier_completed_assays_immutable':30,
   'native_release_assays':217,'other_assays_unadmitted':178,'primary_metric':'native_Spearman',
   'primary_metric_value':score['primary_native_Spearman'],'native_scoring_status':score['native_scoring_status'],
   'full_native_benchmark_complete':False,'frozen_additional9_condition_terminal':True,'no_pooled_metric_with_old30':True,
   'artificial_exact_copy_gate_passed':True,'prediction_lock_sha256':done['prediction_lock_sha256'],'runtime_plan_sha256':PLAN_SHA,
   'native_archive_sha256':plan['native_archive_sha256'],'native_formula_sha256':plan['native_formula_sha256'],
   'native_aggregation':plan['native_aggregation'],'declared_adaptations':plan['declared_adaptations'],
   'one_attempt_per_variant':True,'native_scoring_attempts':1,'new_training':False,'paid_model_calls':False,
   'mechanism_reference_assessment':'unassessed','prior_public_benchmark_exposure':'unknown',
   'paper_comparison':'Separate nine-assay pointwise text adaptation, not full217 or historical ProtST/GEMME replication; no matched paper scalar established.',
   'allocation':{'job_id':job,'state':row[1],'exit_code':row[2],'elapsed':row[3],'gpus':1},
   'submission_receipt_sha256':publish.sha(SUBMISSION),'operational_resource_provenance':operational_provenance,
   'delivery_errors':{k:done[k]for k in ['empty_finals','unknown_finals','http_errors','server_errors','transport_errors','response_errors','truncations','refusals']}}
  publish.validate_summary(result,score,done,done['prediction_lock_sha256'])
  members.update(archive_sources(plan));members.update(resource_provenance.archive_sources(resource_binding));members['benchmark/scores.json']=RUNTIME/'benchmark/scores.json'
  save(HERE/'packaging_started.json',{'at_pacific':now(),'job_id':os.environ.get('SLURM_JOB_ID'),'runtime_job_id':job,'model_calls':0,'scoring_calls':0,'source_members':len(members)})
  stage=HERE/'stage';stage.mkdir()
  provenance_path=HERE/'operational_resource_provenance.json';save(provenance_path,operational_provenance)
  members['operational_resource_provenance.json']=provenance_path
  scanner=publish.load('p17_add9_secret_scanner',ROOT/'scripts/daily_backup.py')
  metadata=create_archive(stage/publish.RAW,members,scanner);archive_sha=publish.sha(stage/publish.RAW)
  save(stage/publish.RAW.replace('.tar.gz','.manifest.json'),{'task_id':'P17','run_id':publish.RUN_ID,'archive_sha256':archive_sha,
   'files':metadata,'members':len(metadata),'original_source_and_actual_attempt_bytes_preserved':True,
   'reference_measurement_rows_weights_environments_credentials_full_account_metadata_included':False})
  base=stage/publish.PREFIX;base.mkdir(parents=True);save(base/'result.json',result)
  for name in ['scores.json','completion.json','prediction_lock.json']:shutil.copyfile(RUNTIME/'benchmark'/name,base/name)
  value=score['primary_native_Spearman'];formatted='undefined'if value is None else format(value,'.8f')
  report=('# ProteinGym additional nine eukaryotic domain-stability assays\n\n'
   f'Qwen3.8-27B saved **{done["responses_saved"]:,}/16,000** outputs, with **{done["delivery_passed"]:,}** valid scalar predictions across the fixed nine-assay condition. '
   f'Native Spearman: **{formatted}** ({score["native_scoring_status"]}). '
   f'Confirmed attempts: {done["attempted_confirmed"]:,}; not dispatched: {done["not_dispatched"]:,}. All planned variants remain in the denominator.\n\n'
   'This is a separate addition to the earlier completed 30 assays. Their outputs and metrics remain unchanged; no pooled 39-assay score is claimed. '
   'The other 178 ProteinGym assays remain outside these two conditions. This does not complete the full 217-assay benchmark.\n\n'
   'The declared pointwise text adaptation supplies full reference and variant sequences, native substitution identities and the isolated-domain stability objective. '
   'Temperature 0, seed 42, thinking disabled, 16,384 output-token ceiling, pinned original BF16 Qwen3.8-27B, one TP1 GPU. '
   'Three artificial exact-copy HTTP checks passed before biological dispatch. No training or paid model calls occurred.\n\n'
   'The native formula rounds each per-assay Spearman to three decimals, then averages by UniProt and selection type. All nine primary assay metrics must be defined. '
   'Missing or invalid predictions keep the whole-cohort primary metric undefined without opening reference measurements; constant predictions can also make the metric undefined. '
   'The worker stops creating new requests after a fatal delivery error, drains outstanding calls and never retries an attempted variant. '
   'Protected measurements remain outside solver requests and this public archive. A numerical score does not validate explanations or establish contamination-free evaluation.\n\n'
   f'Own server stopped and actual allocation **{job}** completed successfully before packaging. The complete sealed condition received one native scoring attempt. '
   'An independently admitted resource-accounting amendment changed only allocation accounting and startup provenance; the scientific plan, inputs, generation and scoring remain fixed. '
   'The archive contains the actual amended worker source and a small resource-provenance projection, while full account audits, external-job proofs and private resource manifests stay local. '
   'The archive contains every actual original request, raw response and outcome, permitted input records, exact source and selected execution receipts; saved outputs are not silently equated with 16,000 completed predictions.\n\n'
   '[Native scoring source](https://github.com/OATML-Markslab/ProteinGym/blob/1f8de974dead8ff7501eff087b725d14a965e9f9/proteingym/performance_DMS_benchmarks.py). '
   f'[Scores](../{publish.PREFIX}scores.json), [result](../{publish.PREFIX}result.json), [sealed trajectories/source archive](../{publish.RAW}), '
   f'[member hashes](../{publish.RAW.replace(".tar.gz",".manifest.json")}).\n')
  (stage/publish.REPORT).parent.mkdir(parents=True,exist_ok=True);(stage/publish.REPORT).write_text(report)
  (base/'README.md').write_text(report.replace('../results/','../../'))
  support=[HERE/name for name in PUBLICATION_SOURCES]+list(SUPPORT)
  evidence=[EXECUTION/'plan.json',SUBMISSION,SUBMISSION.parent/'submission_claim.json',RUNTIME/'terminal_receipt.json',RUNTIME/'server_terminal.json',RUNTIME/'scoring_attempt_started.json',RUNTIME/'benchmark/completion.json',RUNTIME/'benchmark/prediction_lock.json',RUNTIME/'benchmark/scores.json']
  evidence.extend(resource_provenance.private_evidence(resource_binding))
  files={name:publish.sha(stage/name)for name in sorted(publish.ALLOWED)}
  manifest={'at_pacific':now(),'task_id':'P17','repository':publish.REPOSITORY,'visibility':'public','planned':16000,
   'reviewed_assays':9,'native_release_assays':217,'full_native_benchmark_complete':False,'no_pooled_metric_with_old30':True,
   'model_calls':0,'scoring_calls':0,'website_or_schedule_changes':False,'shared_aggregate_paths_modified':False,
   'files_sha256':files,'raw_archive_sha256':archive_sha,'delegated_review_policy_sha256':publish.sha(publish.POLICY),
   'support_sha256':{str(path):publish.sha(path)for path in support},'private_evidence_sha256':{str(path):publish.sha(path)for path in evidence}}
  save(HERE/'manifest.json',manifest);publish.check(HERE/'manifest.json',publish.sha(HERE/'manifest.json'))
  save(HERE/'packaging_receipt.json',{'at_pacific':now(),'stage':'sealed_result_packaged_requires_independent_actual_bundle_review',
   'manifest_sha256':publish.sha(HERE/'manifest.json'),'archive_sha256':archive_sha,'archive_members':len(metadata),'public_paths':len(files),
   'model_calls':0,'scoring_calls':0,'network_calls':0,'runtime_job_id':job,'allocation_accounting':accounting,
   'per_member_secret_scans_passed':True,'final_archive_secret_scan_passed':True})
  print(json.dumps({'stage':'packaged_not_published','manifest_sha256':publish.sha(HERE/'manifest.json'),'archive_members':len(metadata)}))
if __name__=='__main__':main()
