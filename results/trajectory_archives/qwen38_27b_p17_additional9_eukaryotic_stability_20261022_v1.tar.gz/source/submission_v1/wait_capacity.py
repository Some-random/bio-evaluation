"""Submit this one admitted native condition once, behind accepted comparisons.

Lock order is the shared GPU lock, then a nonblocking shared intake lock.
The existing comparison controller releases intake before invoking GPU children.
The durable sole claim is created while both locks protect the final snapshot;
intake is released before sbatch while the shared GPU lock remains held.
"""
from pathlib import Path
import argparse, fcntl, hashlib, importlib.util, json, os, re, subprocess, sys, time

HERE = Path(__file__).resolve().parent
EXECUTION = HERE.parent
ROOT = EXECUTION.parents[4]
QUEUE = ROOT / '.local/qwen35_4b_comparison_20261022/queue'
sys.path.insert(0, str(EXECUTION))
import admission, protocol, runner

FINAL = {'completed', 'terminal_failure_requires_review', 'error_requires_review'}


def write_once(path, value):
    """Persist a sole operational claim before any external side effect."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def comparison_snapshot(queue=None):
    """Caller holds intake.lock; inspect metadata only, never run queue code."""
    queue = QUEUE if queue is None else queue
    pins, blockers = {}, []
    accepted = queue / 'accepted'
    if not accepted.is_dir() or accepted.is_symlink():
        raise ValueError('Existing comparison intake metadata is unavailable')
    for path in sorted(accepted.glob('*.json')):
        if path.is_symlink() or not path.is_file():
            raise ValueError('Regular exact accepted ticket required')
        ticket = json.loads(path.read_bytes())
        request = ticket['request']
        request_id = request['request_id']
        if not re.fullmatch(r'[A-Za-z0-9_.-]+', request_id) or path.name != request_id + '.json':
            raise ValueError('Exact safe accepted request identity required')
        digest = hashlib.sha256(json.dumps({k: v for k, v in request.items() if k != 'admission'}, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
        if ticket['request_digest'] != digest:
            raise ValueError('Accepted comparison ticket digest changed')
        state_path = queue / 'states' / (request_id + '.json')
        if state_path.is_symlink() or not state_path.is_file():
            raise ValueError('Every accepted comparison needs observed state metadata')
        state = json.loads(state_path.read_bytes())
        if state.get('request_id') != request_id or not isinstance(state.get('stage'), str):
            raise ValueError('Comparison state identity is unknown')
        pins[str(path)] = protocol.sha(path)
        pins[str(state_path)] = protocol.sha(state_path)
        if state['stage'] not in FINAL:
            job = str(state.get('job_id', ''))
            receipt = Path(request['receipt_path'])
            if not re.fullmatch(r'[0-9]+', job) or not receipt.is_file() or receipt.is_symlink():
                blockers.append(request_id)
                continue
            native = json.loads(receipt.read_bytes())
            receipt_job = str(native.get('job_id') or str(native.get('stdout', '')).strip().split(';')[0])
            if (receipt_job != job or native.get('returncode', 0) != 0 or
                    protocol.sha(receipt) != state.get('actual_submission_receipt_sha256')):
                raise ValueError('Claimed comparison submission lacks its matching native receipt')
            for key in ('plan', 'grant'):
                if key + '_sha256' in native and native[key + '_sha256'] != request['artifacts'][key]['sha256']:
                    raise ValueError('Comparison native receipt changed its admitted plan/grant')
            pins[str(receipt)] = protocol.sha(receipt)
    return {'file_sha256': pins, 'unsubmitted_nonfinal_comparison_requests': blockers}


def attempt(plan_path, plan_sha, grant_path, grant_sha, *, audit_fn=None, run=None):
    plan = admission.validate(plan_path, plan_sha, grant_path, grant_sha)
    if (HERE / 'submission_claim.json').exists() or (HERE / 'submission_receipt.json').exists():
        raise FileExistsError('No repeat after a prior or ambiguous sole submission claim')
    audit_fn = audit_fn or admission.load('p17_additional9_gpu_audit', plan['project_gpu_audit_helper']).conservative_project_gpu_audit
    run = run or subprocess.run
    with (ROOT / '.local/evaluation_GPU_submission.lock').open('a') as gpu_lock:
        fcntl.flock(gpu_lock, fcntl.LOCK_EX)
        # Capacity failure is preclaim; unknown accounting stops rather than grants.
        try:
            audit = audit_fn(additional_gpus=1)
        except ValueError as error:
            if str(error) == 'Evaluation project GPU requests exceed eight':
                return {'stage': 'waiting_capacity', 'model_calls': 0, 'submission_attempts': 0}
            raise
        if audit['project_requested_GPUs_with_addition'] > 8 or audit['additional_GPUs_reviewed'] != 1:
            raise PermissionError('Fresh conservative one-GPU capacity not established')
        with (QUEUE / 'intake.lock').open('a') as intake_lock:
            try:
                fcntl.flock(intake_lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
            except BlockingIOError:
                return {'stage': 'waiting_coherent_comparison_intake', 'model_calls': 0, 'submission_attempts': 0}
            snapshot = comparison_snapshot()
            if snapshot['unsubmitted_nonfinal_comparison_requests']:
                return {'stage': 'waiting_behind_admitted_comparisons', 'request_ids': snapshot['unsubmitted_nonfinal_comparison_requests'], 'model_calls': 0, 'submission_attempts': 0}
            admission.validate(plan_path, plan_sha, grant_path, grant_sha)
            for p in [EXECUTION / 'runtime/allocation_started.json', EXECUTION / 'runtime/benchmark', EXECUTION / 'runtime/development']:
                if p.exists():
                    raise FileExistsError('An existing runtime or attempt must not be duplicated')
            write_once(HERE / 'GPU_audit_at_submission.json', audit)
            claim = {
                'at_pacific': runner.now(), 'stage': 'sole_submission_claim_not_runtime_evidence',
                'plan_sha256': plan_sha, 'peer_admission_sha256': grant_sha,
                'comparison_priority_snapshot': snapshot,
                'GPU_audit_sha256': protocol.sha(HERE / 'GPU_audit_at_submission.json'),
                'one_requested_GPU': True, 'no_automatic_retry': True,
                'claim_held_shared_GPU_and_intake_locks': True, 'model_calls': 0
            }
            write_once(HERE / 'submission_claim.json', claim)
        command = ['sbatch', '--parsable', str(EXECUTION / 'worker.sbatch'),
                   '--plan', str(plan_path), '--plan-sha256', plan_sha,
                   '--admission', str(grant_path), '--admission-sha256', grant_sha]
        try:
            result = run(command, capture_output=True, text=True, timeout=90)
            receipt = {
                'at_pacific': runner.now(), 'stage': 'submission_failed_or_ambiguous_no_retry',
                'command': command, 'returncode': result.returncode,
                'stdout': result.stdout.strip(), 'stderr': result.stderr.strip(),
                'plan_sha256': plan_sha, 'peer_admission_sha256': grant_sha,
                'submission_claim_sha256': protocol.sha(HERE / 'submission_claim.json'),
                'GPU_audit_sha256': claim['GPU_audit_sha256'], 'model_dispatch_verified': False,
                'new_requested_GPUs': 1, 'automatic_retry': False
            }
            if result.returncode == 0 and re.fullmatch(r'[0-9]+(?:;[A-Za-z0-9_.-]+)?', result.stdout.strip()):
                receipt.update(stage='submitted', job_id=result.stdout.strip().split(';')[0])
            write_once(HERE / 'submission_receipt.json', receipt)
            return receipt
        except Exception as error:
            write_once(HERE / 'submission_error.json', {
                'at_pacific': runner.now(), 'error_type': type(error).__name__,
                'automatic_retry': False, 'submission_ambiguity_preserved': True, 'model_dispatch_verified': False
            })
            raise


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--plan', type=Path, required=True)
    ap.add_argument('--plan-sha256', required=True)
    ap.add_argument('--admission', type=Path, required=True)
    ap.add_argument('--admission-sha256', required=True)
    args = ap.parse_args()
    os.umask(0o077)
    with (HERE / 'controller.lock').open('a') as own_lock:
        fcntl.flock(own_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        while True:
            if (HERE / 'STOP').exists():
                return
            state = attempt(args.plan, args.plan_sha256, args.admission, args.admission_sha256)
            state.update(at_pacific=runner.now(), pid=os.getpid(), role='single_P17_capacity_waiter_not_generation_counts')
            runner.save(HERE / 'status.json', state, exclusive=False)
            if not state['stage'].startswith('waiting_'):
                return
            time.sleep(30)


if __name__ == '__main__':
    main()
