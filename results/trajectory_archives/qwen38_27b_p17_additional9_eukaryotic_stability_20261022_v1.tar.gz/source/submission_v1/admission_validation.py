"""Separate peer technical approval from actual future one-GPU submission proof."""
from pathlib import Path
import json, time


def _read_complete_receipt(path, *, timeout=120, clock=time.monotonic, sleep=time.sleep):
    """A Slurm job may start while its parent's sole receipt is still writing."""
    deadline = clock() + min(120, max(0, timeout))
    while True:
        if path.is_symlink():
            raise PermissionError('An exact regular native submission receipt is required')
        try:
            value = json.loads(path.read_bytes())
        except (FileNotFoundError, json.JSONDecodeError, UnicodeDecodeError):
            remaining = deadline - clock()
            if remaining <= 0:
                raise PermissionError('Timed out before exact native submission receipt became complete')
            sleep(min(0.05, remaining))
            continue
        if not isinstance(value, dict):
            raise PermissionError('A complete native receipt must be a JSON object')
        return value


def validate_resource_delegation(plan, grant, plan_sha, grant_sha, sha, *, execution, job_id=None):
    execution = Path(execution)
    actuator = execution / 'submission_v1/wait_capacity.py'
    if (grant.get('conditional_single_submission') is not True or
            grant.get('submission_actuator_sha256') != sha(actuator) or
            plan['frozen_files_sha256'].get(str(actuator)) != sha(actuator) or
            grant.get('comparison_priority_and_fresh_locked_GPU_audit_required') is not True):
        raise PermissionError('Peer approval must bind the exact bounded priority/capacity actuator')
    if job_id is None:
        return
    directory = execution / 'submission_v1'
    paths = {name: directory / name for name in ('submission_receipt.json', 'submission_claim.json', 'GPU_audit_at_submission.json')}
    receipt = _read_complete_receipt(paths['submission_receipt.json'])
    for path in paths.values():
        if path.is_symlink() or not path.is_file():
            raise PermissionError('Actual exact native submission proof is missing')
    claim = json.loads(paths['submission_claim.json'].read_bytes())
    audit = json.loads(paths['GPU_audit_at_submission.json'].read_bytes())
    if (receipt.get('stage') != 'submitted' or str(receipt.get('job_id')) != str(job_id) or
            receipt.get('returncode') != 0 or receipt.get('new_requested_GPUs') != 1 or
            receipt.get('plan_sha256') != plan_sha or receipt.get('peer_admission_sha256') != grant_sha or
            receipt.get('submission_claim_sha256') != sha(paths['submission_claim.json']) or
            receipt.get('GPU_audit_sha256') != sha(paths['GPU_audit_at_submission.json'])):
        raise PermissionError('Slurm job must match its sole independently admitted native submission')
    if (claim.get('plan_sha256') != plan_sha or claim.get('peer_admission_sha256') != grant_sha or
            claim.get('GPU_audit_sha256') != receipt['GPU_audit_sha256'] or
            claim.get('one_requested_GPU') is not True or
            claim.get('no_automatic_retry') is not True or
            claim.get('claim_held_shared_GPU_and_intake_locks') is not True or
            claim.get('comparison_priority_snapshot', {}).get('unsubmitted_nonfinal_comparison_requests') != []):
        raise PermissionError('Exact once-only claim and coherent cleared comparison priority required')
    before = audit.get('project_requested_GPUs')
    after = audit.get('project_requested_GPUs_with_addition')
    if (type(before) is not int or type(after) is not int or not 0 <= before <= 7 or
            after != before + 1 or after > 8 or audit.get('additional_GPUs_reviewed') != 1 or
            audit.get('project_GPU_ceiling') != 8):
        raise PermissionError('Native submission must preserve the conservative eight-GPU ceiling')
