"""Freeze the root-adopted disjoint nine-assay condition; never dispatch."""
from pathlib import Path
import json
import admission, protocol, runner

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
OLD = HERE.parent / 'runtime_repair_v2'
ADOPTION = HERE.parent / 'remaining_coverage_20261022/root_additional9_scientific_adoption_20261022.json'
ADOPTION_SHA = '921425baa99eac8b2755ef12fd0050358999f42a437c269082996f6918fbfe6c'
METADATA_REVIEW = HERE.parent / 'remaining_coverage_20261022/independent_metadata_review.json'
METADATA_REVIEW_SHA = 'c40389967524565ca8d0f3ad4cf7b22a41290014a111f85f71a563c14c61c4a8'


def main():
    if (HERE / 'plan.json').exists():
        raise FileExistsError('An existing frozen proposal must remain immutable')
    if protocol.sha(ADOPTION) != ADOPTION_SHA or protocol.sha(METADATA_REVIEW) != METADATA_REVIEW_SHA:
        raise ValueError('Exact root scientific adoption and independent metadata review required')
    adoption = json.loads(ADOPTION.read_bytes())
    manifest = HERE / 'prepared/input_manifest.json'
    m = json.loads(manifest.read_bytes())
    cpu = json.loads((HERE / 'CPU_validation.json').read_bytes())
    terminal = json.loads((HERE / 'CPU_terminal.json').read_bytes())
    if (m['planned_native_variants'], m['positive_preparation_assays'], cpu['native_variants_checked']) != (16000, 9, 16000):
        raise ValueError('The complete nine-assay / 16000-variant cohort must be checked')
    if cpu['max_prompt_tokens'] + 16384 > 65536 or not cpu['all_intact_inputs_plus_uniform16384_output_fit65536']:
        raise ValueError('All complete native inputs must fit without clipping')
    if terminal['state'] != 'COMPLETED' or terminal['exit_code'] != '0:0' or terminal['validation_sha256'] != protocol.sha(HERE / 'CPU_validation.json'):
        raise ValueError('Actual CPU-only terminal closure required')
    if {a['DMS_id'] for a in m['assays']} != set(adoption['assay_ids']) or len({a['UniProt_ID'] for a in m['assays']}) != 9:
        raise ValueError('Exact adopted assay IDs and unique native protein groups required')
    old_manifest = json.loads((OLD / 'prepared/input_manifest.json').read_bytes())
    if {a['DMS_id'] for a in m['assays']} & {a['DMS_id'] for a in old_manifest['assays']}:
        raise ValueError('Never repeat an earlier reviewed30 native case')
    source = json.loads((OLD / 'plan.json').read_bytes())
    batch = '''#!/bin/bash
#SBATCH --job-name=bio-p17-additional9-stability
#SBATCH --partition=il
#SBATCH --account=infolab
#SBATCH --gres=gpu:a100:1
#SBATCH --cpus-per-task=10
#SBATCH --mem=96G
#SBATCH --time=12:00:00
#SBATCH --chdir=/dfs/scratch0/dongweij/bio-evaluation
#SBATCH --output=''' + str(HERE / 'slurm-%j.log') + '''
set -euo pipefail
umask 077
unset OPENAI_API_KEY ANTHROPIC_API_KEY GEMINI_API_KEY GOOGLE_API_KEY AZURE_OPENAI_API_KEY HF_TOKEN HUGGING_FACE_HUB_TOKEN
unset OPENAI_BASE_URL OPENAI_ORG_ID OPENAI_ORGANIZATION OPENAI_PROJECT_ID PYTHONPATH PYTHONHOME VIRTUAL_ENV SSH_AUTH_SOCK
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONNOUSERSITE=1
exec /usr/bin/python3 ''' + str(HERE / 'worker.py') + ''' "$@"
'''
    (HERE / 'worker.sbatch').write_text(batch)
    files = list(HERE.glob('*.py')) + [HERE / name for name in (
        'input_preparation_scope.json', 'CPU.sbatch', 'CPU_plan.json',
        'CPU_submission_attempt.json', 'CPU_submission_receipt.json',
        'CPU_validation.json', 'CPU_terminal.json', 'CPU-247538.log', 'worker.sbatch')]
    files += [manifest, ADOPTION, METADATA_REVIEW, admission.POLICY]
    files += list((HERE / 'submission_v1').glob('*.py'))
    files += [HERE / 'operational_admission_revision.json', HERE / 'operational_admission_tests.log', HERE / 'submission_v1/tests.log']
    files += [HERE / 'runtime_revision.json', HERE.parent / 'additional9_eukaryotic_stability_v1/plan.json', HERE.parent / 'additional9_eukaryotic_stability_v1/unadmitted_candidate_closure.json']
    files += [HERE.parent / 'additional9_eukaryotic_stability_v2/plan.json', HERE.parent / 'additional9_eukaryotic_stability_v2/unadmitted_candidate_closure.json']
    files += list((HERE / 'CPU_original_source_snapshot').glob('*.py'))
    files += [Path(a['input_path']) for a in m['assays']]
    files += [Path(source[k]) for k in ('runtime_common', 'vetted_V06_worker', 'project_gpu_audit_helper', 'site_tools_helper', 'native_formula_source')]
    files += [Path(source['vetted_V06_worker']).parent / 'v06_runner.py',
              Path(source['CPU_scorer_libraries']['path']), Path(source['CPU_scorer_library_manifest']),
              OLD / 'runtime_repair_CPU_validation.json', OLD / 'runtime_repair_CPU_terminal.json', OLD / 'CPU_scorer_archive_scan.json']
    from prepare_inputs import META, ZIP, META_SHA, ZIP_SHA
    files += [META, ZIP]
    files += [Path(source['model_directory']) / n for n in ('tokenizer.json', 'tokenizer_config.json', 'config.json', 'generation_config.json')]
    pins = {str(p): protocol.sha(p) for p in files}
    if pins[str(META)] != META_SHA or pins[str(ZIP)] != ZIP_SHA:
        raise ValueError('Exact native metadata/archive release required')
    plan = {
        'created_at_pacific': runner.now(), 'task_id': 'P17', 'owner': admission.OWNER,
        'condition': protocol.CONDITION, 'role': 'frozen_additional9_condition_not_dispatch',
        'execution_revision': 'P17_ADDITIONAL9_PERSISTENT_SUBMISSION_FAST_START_V3',
        'model': protocol.MODEL, 'model_directory': source['model_directory'],
        'model_revision': source['model_revision'], 'generation': protocol.GENERATION,
        'compact_structured_output_regex': protocol.SCALAR_REGEX,
        'reviewed_assays': 9, 'native_release_assays': 217, 'planned_benchmark_variants': 16000,
        'earlier_completed_assays_immutable': 30, 'other_assays_unadmitted': 178,
        'development_planned': 3, 'gpus_requested': 1, 'project_GPU_ceiling': 8,
        'GPU_memory_minimum_GiB': 78, 'endpoint': 'http://127.0.0.1:8417/v1', 'context_limit': 65536,
        'runtime_root': str(HERE / 'runtime'), 'input_manifest': str(manifest),
        'CPU_validation': str(HERE / 'CPU_validation.json'),
        'source_scope_sha256': protocol.sha(HERE / 'input_preparation_scope.json'),
        'source_scope_independent_review_sha256': METADATA_REVIEW_SHA,
        'root_scientific_adoption': str(ADOPTION), 'root_scientific_adoption_sha256': ADOPTION_SHA,
        'native_archive': str(ZIP), 'native_archive_sha256': ZIP_SHA,
        'native_formula_source': source['native_formula_source'], 'native_formula_sha256': source['native_formula_sha256'],
        'native_aggregation': 'Per-assay SciPy Spearman rounded to three decimals, then native per-UniProt / Stability means; all nine must be defined.',
        'primary_metric': 'native_Spearman',
        'native_reference_access': 'Only after exact complete locked predictions and independent raw/request/outcome validation; no measured scores enter the solver.',
        'declared_adaptations': [
            'Pointwise uncalibrated scalar Qwen predictions from whole reference and variant sequences plus native substitutions; no native ProteinGym LLM prompt exists.',
            'Nine additional ordinary eukaryotic isolated-domain stability assays; exact complete native variants; separate result from completed30 and not the full217 benchmark.',
            'Same frozen numeric JSON / nonthinking recipe as reviewed30 with the root-adopted vertebrate-to-eukaryotic input wording change.',
            'All-case denominator is preserved; a missing/invalid or constant assay keeps the whole nine-assay primary metric undefined.'
        ],
        'new_training': False, 'paid_model_calls': False, 'automatic_retries': False, 'automatic_resume': False,
        'one_attempt_per_native_variant': True, 'scoring_attempts': 1, 'full_native_benchmark_complete': False,
        'no_pooled_metric_with_old30': True, 'runtime_admission_granted': False, 'new_model_calls': 0,
        'frozen_files_sha256': pins,
        'queue_priority': 'Wait for every already-accepted nonfinal comparison request to receive an actual submission before claiming native GPU capacity.'
    }
    for key in ('base_runtime', 'cuda_overlay', 'runtime_common', 'vetted_V06_worker', 'project_gpu_audit_helper', 'site_tools_helper', 'CPU_scorer_libraries', 'CPU_scorer_library_manifest'):
        plan[key] = source[key]
    runner.save(HERE / 'plan.json', plan)
    digest = protocol.sha(HERE / 'plan.json')
    (HERE / 'plan.sha256').write_text(digest + '\n')
    admission.validate(HERE / 'plan.json', digest)
    runner.save(HERE / 'freeze_receipt.json', {
        'at_pacific': runner.now(), 'plan_sha256': digest, 'pins': len(pins),
        'reviewed_assays': 9, 'native_variants': 16000, 'earlier_completed_assays_immutable': 30,
        'admitted': False, 'model_calls': 0, 'GPU_allocations': 0
    })
    print(json.dumps({'plan_sha256': digest, 'pins': len(pins), 'admitted': False}))


if __name__ == '__main__':
    main()
