import copy,json,math,unittest
import protocol
from prepare_inputs import selected_metadata
class Tests(unittest.TestCase):
 def case(self):return {'case_id':'artificial:1','DMS_id':'artificial','UniProt_ID':'ARTIFICIAL','mutant':'A1C:D3E','reference_sequence':'ACDE','mutated_sequence':'CCEE','objective':'isolated_domain_folding_stability'}
 def reply(self,text,finish='stop',**fields):return json.dumps({'choices':[{'finish_reason':finish,'message':{'content':text,**fields}}]}).encode()
 def test_reference_variant_mutation_identity(self):
  c=self.case();self.assertIs(protocol.validate_input(c),c)
  for field,value in [('mutant','A2C'),('mutant','A1C:A1D'),('mutant','A9C'),('mutant','A0C'),('mutated_sequence','CCE'),('mutated_sequence','CCEX'),('reference_sequence','XCDE')]:
   with self.subTest(field=field,value=value),self.assertRaises(ValueError):protocol.validate_input({**c,field:value})
 def test_complete_sequences_and_mutants_retained(self):
  c=self.case();q=protocol.question(c)
  for value in [c['reference_sequence'],c['mutated_sequence'],c['mutant']]:self.assertIn(value,q)
 def test_target_and_extra_fields_fail_before_payload(self):
  for name in ['DMS_score','DMS_score_bin','answer','target','reference_measurement']:
   with self.assertRaises(ValueError):protocol.payload({**self.case(),name:'PROTECTED_SENTINEL'})
  self.assertNotIn('PROTECTED_SENTINEL',json.dumps(protocol.payload(self.case())))
 def test_objective_does_not_accept_function_or_fitness_scope(self):
  for obj in ['pathogen_fitness','receptor_activity','expression','unknown']:
   with self.assertRaises(ValueError):protocol.validate_input({**self.case(),'objective':obj})
 def test_compact_finite_numeric_parse_and_no_repair(self):
  for value in ['0','-1','12345.678901','-999999.999999']:self.assertTrue(math.isfinite(protocol.parse_reply(self.reply('{"score":'+value+'}'))))
  for text in ['{"score":NaN}','{"score":1e3}','{"score": 0}',' {"score":0}','{"score":1000000}','{"score":1.1234567}','{"score":0,"answer":2}','{"score":true}','```{"score":0}```']:
   with self.assertRaises(ValueError):protocol.parse_reply(self.reply(text))
 def test_truncation_refusal_reasoning_tool_calls_invalid(self):
  with self.assertRaises(ValueError):protocol.parse_reply(self.reply('{"score":0}','length'))
  for name in ['reasoning','reasoning_content','tool_calls','refusal']:
   with self.assertRaises(ValueError):protocol.parse_reply(self.reply('{"score":0}',**{name:'present'}))
 def test_full_metadata_roster_fixed_without_outcome_filtering(self):
  rows=selected_metadata();self.assertEqual(len(rows),9);self.assertEqual(sum(int(r['DMS_total_number_mutants'])for r in rows),16000)
  self.assertEqual({r['source_organism']for r in rows},{'Saccharomyces cerevisiae','Arabidopsis thaliana','Antirrhinum majus','Chlamydomonas reinhardtii'})
  self.assertEqual({r['coarse_selection_type']for r in rows},{'Stability'})
  self.assertEqual(len({r['DMS_id']for r in rows}),9)
 def test_model_sampling_is_frozen_and_no_tools(self):
  p=protocol.payload(self.case());self.assertEqual(p['model'],protocol.MODEL);self.assertEqual(p['max_tokens'],16384)
  self.assertEqual(p['structured_outputs']['regex'],protocol.SCALAR_REGEX);self.assertNotIn('tools',p)
 def test_CPU_counter_counts_actual_ids_not_BatchEncoding_fields(self):
  from check_cpu import count_prompt_tokens
  class Fake:
   def apply_chat_template(self,*args,**kwargs):
    if kwargs.get('tokenize')is not False:raise AssertionError('No implicit BatchEncoding length')
    return 'full artificial chat'
   def encode(self,text,add_special_tokens=False):return list(range(57))
  self.assertEqual(count_prompt_tokens(Fake(),protocol.payload(self.case())),57)
  class Wrong(Fake):
   def encode(self,*a,**k):return {'input_ids':[1,2],'attention_mask':[1,1]}
  with self.assertRaises(ValueError):count_prompt_tokens(Wrong(),protocol.payload(self.case()))
if __name__=='__main__':unittest.main()
