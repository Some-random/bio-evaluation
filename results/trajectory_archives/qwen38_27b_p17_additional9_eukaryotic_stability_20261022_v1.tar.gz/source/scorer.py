"""Sole offline native Spearman after a complete exact prediction seal.

References remain in the original archive and are not opened until every
planned raw final has been independently parsed. The pinned native source
rounds per-assay metrics to3 decimals before UniProt/function averaging.
"""
from pathlib import Path
import argparse,csv,hashlib,io,json,math,sys,zipfile
import protocol
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]

def native_aggregate(assays,predictions,reference_loader):
 from scipy.stats import spearmanr
 import numpy as np
 expected={case['case_id']for assay in assays for case in assay['cases']}
 if len(expected)!=sum(len(a['cases'])for a in assays):raise ValueError('Duplicate frozen native case IDs')
 if set(predictions)-expected:raise ValueError('Foreign prediction ID')
 missing=expected-set(predictions);invalid=[k for k,v in predictions.items()if isinstance(v,bool)or not isinstance(v,(int,float))or not math.isfinite(v)]
 if missing or invalid:return {'native_scoring_status':'undefined_incomplete_full_cohort_delivery','primary_native_Spearman':None,'references_opened':False,'planned_variants':len(expected),'missing_predictions':len(missing),'invalid_predictions':len(invalid)}
 per=[];groups={};undefined=[]
 for assay in assays:
  references=reference_loader(assay)
  if set(references)!={r['case_id']for r in assay['cases']}:raise ValueError('Reference exact native identity/denominator mismatch')
  gold=[];values=[]
  for case in assay['cases']:
   v=references[case['case_id']]
   if isinstance(v,bool)or not isinstance(v,(int,float))or not math.isfinite(v):raise ValueError('Finite native measurement required')
   gold.append(v);values.append(predictions[case['case_id']])
  corr=float(spearmanr(gold,values)[0]);defined=math.isfinite(corr)
  rounded=float(np.round(corr,3))if defined else None
  if not defined:undefined.append(assay['DMS_id'])
  per.append({'DMS_id':assay['DMS_id'],'UniProt_ID':assay['UniProt_ID'],'planned_variants':len(gold),'native_per_assay_Spearman_unrounded':corr if defined else None,'native_per_assay_Spearman_source_rounded':rounded})
  groups.setdefault(assay['UniProt_ID'],[]).append(rounded)
 groupmeans={key:sum(vals)/len(vals)if all(v is not None for v in vals)else None for key,vals in groups.items()}
 complete=not undefined
 # All proposed assays are native Selection Type=Stability. Thus the pinned
 # UniProt -> Selection Type -> final mean reduces to this UniProt mean.
 return {'native_scoring_status':'completed_native_scored_reviewed_subset'if complete else'undefined_constant_or_insufficient_native_assays','primary_native_Spearman':sum(groupmeans.values())/len(groupmeans)if complete else None,'references_opened':True,'planned_variants':len(expected),'planned_assays':len(assays),'per_assay':per,'per_UniProt_mean_Spearman':groupmeans,'native_selection_types':['Stability'],'undefined_assays':undefined,'strict_full_cohort_defined':complete,'native_aggregation':'Pinned per-assay Spearman rounded3 -> per-UniProt mean -> Stability selection-type mean -> final mean; all planned assays must be defined, no silent NaN dropping.'}

def verified_predictions(assays,run,lock,done):
 import runner
 cases=[case for assay in assays for case in assay['cases']]
 expected={hashlib.sha256(c['case_id'].encode()).hexdigest():c for c in cases}
 if len(expected)!=len(cases):raise ValueError('Duplicate frozen case identity')
 kinds={'requests':{},'outcomes':{},'raw':{},'http':{}}
 for rel,digest in lock['files_sha256'].items():
  path=run/rel;parts=Path(rel).parts
  if len(parts)!=2 or Path(rel).is_absolute()or'..'in parts or path.is_symlink()or protocol.sha(path)!=digest:raise ValueError('Unsafe or changed sealed attempt member')
  directory,name=parts
  if directory=='requests'and name.endswith('.json'):kind='requests';key=name[:-5]
  elif directory=='outcomes'and name.endswith('.json'):kind='outcomes';key=name[:-5]
  elif directory=='responses'and name.endswith('.raw.json'):kind='raw';key=name[:-9]
  elif directory=='responses'and name.endswith('.http_error.raw'):kind='http';key=name[:-15]
  else:raise ValueError('Unknown sealed request/outcome/response member')
  if key not in expected or key in kinds[kind]:raise ValueError('Foreign or duplicate sealed attempt ID')
  kinds[kind][key]=path
 if set(kinds['requests'])!=set(kinds['outcomes'])or set(kinds['raw'])&set(kinds['http'])or not(set(kinds['raw'])|set(kinds['http']))<=set(kinds['requests']):raise ValueError('Exact request/attempt/outcome one-to-one provenance required')
 if done['planned']!=len(cases)or done['attempted_confirmed']!=len(kinds['requests'])or done['terminal']!=len(kinds['outcomes'])or done['responses_saved']!=len(kinds['raw']):raise ValueError('Sealed attempt counts differ from complete frozen denominator')
 predictions={}
 for key,path in kinds['outcomes'].items():
  case=expected[key];request=json.loads(kinds['requests'][key].read_bytes());outcome=json.loads(path.read_bytes())
  if request!={'case_id':case['case_id'],'payload':protocol.payload(case)}:raise ValueError('Sealed wire request does not contain the exact frozen whole question and settings')
  if outcome.get('case_id')!=case['case_id']or outcome.get('attempted')is not True or outcome.get('not_dispatched')is not False or bool(outcome.get('response_saved'))!=(key in kinds['raw']):raise ValueError('Case attempt/outcome provenance mismatch')
  if key in kinds['raw']:
   raw=kinds['raw'][key].read_bytes()
   if len(raw)>runner.MAX_CAPTURE_BYTES:
    if outcome.get('status')!='response_size_exceeded'or outcome.get('raw_capture_complete')is not False or outcome.get('observed_final')is not False or outcome.get('empty_final')is not False or outcome.get('score')is not None:raise ValueError('Exact oversized unknown-final provenance required')
    continue
   parsed=runner.outcome_from_raw(raw)
   for field in ['status','observed_final','empty_final','truncation','reasoning_present','tool_calls_present','refusal','score']:
    if outcome.get(field)!=parsed.get(field):raise ValueError('Sealed raw final differs from recorded outcome')
   if parsed['status']=='delivered':predictions[case['case_id']]=parsed['score']
  elif outcome.get('status')=='delivered':raise ValueError('No delivered prediction without exact sealed original raw final')
 return predictions

def score_sealed_assays(assays,run,lock,done,reference_loader):
 # Request and attempt provenance is checked before native_aggregate can call
 # the reference loader, even if a wrong request was subsequently resealed.
 predictions=verified_predictions(assays,run,lock,done)
 return native_aggregate(assays,predictions,reference_loader)

def score(plan,run):
 done=json.loads((run/'completion.json').read_bytes());lock=json.loads((run/'prediction_lock.json').read_bytes())
 if done.get('task_id')!='P17'or done.get('phase')!='benchmark'or done.get('planned')!=16000 or lock.get('phase')!='benchmark'or lock.get('planned')!=16000:raise ValueError('Only exact complete frozen benchmark denominator may be scored')
 if protocol.sha(run/'prediction_lock.json')!=done['prediction_lock_sha256']or lock['plan_sha256']!=protocol.sha(HERE/'plan.json')or lock['reference_labels_opened']is not False:raise ValueError('Exact immutable prediction seal required')
 manifest=json.loads(Path(plan['input_manifest']).read_bytes());assays=[];predictions={}
 for record in manifest['assays']:
  if protocol.sha(record['input_path'])!=record['input_sha256']:raise ValueError('Exact frozen native inputs changed')
  cases=[json.loads(line)for line in Path(record['input_path']).read_text().splitlines()]
  assays.append({**record,'cases':cases})
 if sum(len(a['cases'])for a in assays)!=16000 or len(assays)!=9:raise ValueError('Whole fixed9/16000 cohort required')
 archive_verified=False
 def load_references(assay):
  nonlocal archive_verified
  if not archive_verified:
   if protocol.sha(plan['native_archive'])!=plan['native_archive_sha256']:raise ValueError('Native archive changed')
   archive_verified=True
  values={};cases=assay['cases']
  with zipfile.ZipFile(plan['native_archive'])as archive:
   with archive.open(assay['source_archive_member'])as stream:
    for n,row in enumerate(csv.DictReader(io.TextIOWrapper(stream))):
     if n>=len(cases)or row['mutant']!=cases[n]['mutant']or row['mutated_sequence']!=cases[n]['mutated_sequence']:raise ValueError('Native reference/input exact join changed')
     values[cases[n]['case_id']]=float(row['DMS_score'])
  if len(values)!=len(cases):raise ValueError('Full native reference denominator required')
  return values
 result=score_sealed_assays(assays,run,lock,done,load_references)
 result.update(task_id='P17',condition=protocol.CONDITION,native_release_assays=217,reviewed_assays=9,full_native_benchmark_complete=False,prediction_lock_sha256=done['prediction_lock_sha256'],source_native_formula_sha256=plan['native_formula_sha256'],no_new_training=True,no_native_LLM_prompt_or_historical_ProtST_replication=True)
 with(run/'scores.json').open('x')as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--run',type=Path,required=True);a=p.parse_args();print(json.dumps(score(json.loads(a.plan.read_bytes()),a.run)))
