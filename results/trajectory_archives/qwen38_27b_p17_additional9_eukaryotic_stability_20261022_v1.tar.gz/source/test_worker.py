from pathlib import Path
import ast,json,os,tempfile,unittest
from unittest.mock import patch
import admission,protocol,worker
class Tests(unittest.TestCase):
 def plan(self,d):
  p=Path(d)/'plan.json';p.write_text(json.dumps({'task_id':'P17','condition':protocol.CONDITION,'model':protocol.MODEL,'planned_benchmark_variants':16000,'reviewed_assays':9,'native_release_assays':217,'development_planned':3,'gpus_requested':1,'new_training':False,'paid_model_calls':False,'automatic_retries':False,'full_native_benchmark_complete':False,'frozen_files_sha256':{},'source_scope_sha256':'artificial','root_scientific_adoption_sha256':'921425baa99eac8b2755ef12fd0050358999f42a437c269082996f6918fbfe6c'}));return p
 def test_fixed_whole_cohort_and_unchanged_pins_required(self):
  with tempfile.TemporaryDirectory()as d:
   p=self.plan(d);admission.validate(p,protocol.sha(p));obj=json.loads(p.read_text());obj['planned_benchmark_variants']=15999;p.write_text(json.dumps(obj))
   with self.assertRaises(PermissionError):admission.validate(p,protocol.sha(p))
   obj['planned_benchmark_variants']=16000;f=Path(d)/'frozen';f.write_text('original');obj['frozen_files_sha256']={str(f):protocol.sha(f)};p.write_text(json.dumps(obj));f.write_text('changed')
   with self.assertRaises(ValueError):admission.validate(p,protocol.sha(p))
 def test_owner_cannot_admit_and_model_path_needs_real_job(self):
  with tempfile.TemporaryDirectory()as d:
   p=self.plan(d);audit=Path(d)/'audit';audit.write_text('{}');g=Path(d)/'grant';g.write_text(json.dumps({'admitted':True,'task_id':'P17','condition':protocol.CONDITION,'plan_sha256':protocol.sha(p),'reviewed_assays':9,'planned_benchmark_variants':16000,'gpu_count':1,'project_gpu_ceiling':8,'one_attempt_per_case':True,'new_training':False,'paid_model_calls':False,'source_scope_sha256':'artificial','reviewer':admission.OWNER,'gpu_audit_receipt':str(audit),'gpu_audit_receipt_sha256':protocol.sha(audit)}))
   with self.assertRaises(PermissionError):admission.validate(p,protocol.sha(p),g,protocol.sha(g))
   with patch.dict(os.environ,{},clear=True),self.assertRaises(PermissionError):admission.validate(p,protocol.sha(p),require_job=True)
 def test_endpoint_server_and_health_derive_same_fixed_port(self):
  self.assertEqual(worker.bind_address('http://127.0.0.1:8417/v1'),('127.0.0.1',8417))
  for bad in ['http://127.0.0.1:8418/v1','http://foreign:8417/v1','https://127.0.0.1:8417/v1','http://127.0.0.1:8417/wrong']:
   with self.assertRaises(ValueError):worker.bind_address(bad)
 def test_private_installer_precedes_exec_and_actual_API_check_before_models(self):
  t=Path(worker.__file__).read_text();tree=ast.parse(t)
  lines={}
  for node in ast.walk(tree):
   if isinstance(node,ast.Call):
    fn=ast.unparse(node.func)
    if fn in ['shared.install_private_runtime','os.execve','shared.verify_package_identity','common.validate_checkpoint']:lines[fn]=node.lineno
  self.assertLess(lines['shared.install_private_runtime'],lines['os.execve']);self.assertLess(lines['os.execve'],lines['shared.verify_package_identity']);self.assertLess(lines['shared.verify_package_identity'],lines['common.validate_checkpoint'])
  self.assertIn("VLLM_USE_V2_MODEL_RUNNER='0'",t);self.assertIn("cpu['CUDA_VISIBLE_DEVICES']=''",t)
  self.assertLess(t.index('check_installed_API.py'),t.index('import torch'))
 def test_benchmark_guard_and_once_only_scoring_are_explicit(self):
  t=Path(worker.__file__).read_text();self.assertLess(t.index("dev['artificial_exact_copy_gate_passed']"),t.index("stage':'benchmark_generation"));self.assertLess(t.index("'scoring_attempt_started.json',"),t.index("runtime/'native_scoring.log'"));self.assertIn("'benchmark','scoring_attempt_started.json','terminal_receipt.json'",t)
if __name__=='__main__':unittest.main()
