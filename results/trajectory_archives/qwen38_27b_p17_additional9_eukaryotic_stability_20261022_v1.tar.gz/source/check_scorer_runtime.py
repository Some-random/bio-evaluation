"""Actual isolated numeric binary imports and native scorer fixtures, no labels."""
from pathlib import Path
import argparse,importlib.metadata as metadata,json,os
import protocol,runner,scorer_runtime

def check(site,output):
 if os.environ.get('CUDA_VISIBLE_DEVICES')!='':raise PermissionError('Scoring preflight must hide CUDA')
 import scipy,numpy
 for name,module in [('scipy',scipy),('numpy',numpy)]:
  if metadata.version(name)!=scorer_runtime.PINNED[name]or not Path(module.__file__).resolve().is_relative_to(site.resolve()):raise ValueError('Exact CPU sidecar versions/namespace required')
 from scorer import native_aggregate
 assays=[{'DMS_id':'artificial_A','UniProt_ID':'A','cases':[{'case_id':'a'+str(i)}for i in range(4)]},{'DMS_id':'artificial_B','UniProt_ID':'B','cases':[{'case_id':'b'+str(i)}for i in range(4)]}]
 values={letter+str(i):float(i)for letter in'ab'for i in range(4)}
 def refs(assay):return {row['case_id']:float(i)for i,row in enumerate(assay['cases'])}
 result=native_aggregate(assays,values,refs)
 if result['primary_native_Spearman']!=1.0:raise ValueError('Actual native SciPy numeric fixture failed')
 missing=dict(values);missing.pop('a0')
 def forbidden(assay):raise AssertionError('Native labels accessed despite incomplete delivery')
 partial=native_aggregate(assays,missing,forbidden)
 if partial['references_opened']is not False or partial['primary_native_Spearman']is not None:raise ValueError('Native reference isolation fixture failed')
 runner.save(output,{'at_pacific':runner.now(),'stage':'actual_isolated_CPU_scorer_binary_and_native_formula_gate_passed','packages':{k:metadata.version(k)for k in scorer_runtime.PINNED},'CPU_scorer_site':str(site),'CUDA_visible_devices':os.environ['CUDA_VISIBLE_DEVICES'],'actual_SciPy_native_fixture':1.0,'incomplete_delivery_reference_loader_blocked':True,'model_calls':0,'model_forwards':0,'measurement_rows_read':False})
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--site',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();check(a.site,a.output)
