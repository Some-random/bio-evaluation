"""Materialize only input columns from an independently positive metadata roster.

PyArrow projection never loads experimental DMS_score or DMS_score_bin columns.
No reference file or model call is created by this preparation command.
"""
from pathlib import Path
import argparse,csv,datetime,hashlib,json,sys,zipfile
from zoneinfo import ZoneInfo
import protocol
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
META=ROOT/'.local/source_acquisition_2026-10-19/prediction_datasets/metadata/ProteinGym/reference_files/DMS_substitutions.csv'
ZIP=ROOT/'.local/source_acquisition_2026-10-19/prediction_datasets/P17/DMS_ProteinGym_substitutions.zip'
META_SHA='a8f498011532a74aa9fe556a50555a75e928c5837d19c06a87592ae04049b308'
ZIP_SHA='3a83766254ac9ac9984ec25cb73c6e010ea4418f5e35f143933e6b6e6473b921'
SPECIES={'Saccharomyces cerevisiae','Arabidopsis thaliana','Antirrhinum majus','Chlamydomonas reinhardtii'}
TITLE='Mega-scale experimental analysis of protein folding stability in biology and design'

def now():return datetime.datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def save(path,value):
 with Path(path).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')

def selected_metadata():
 if protocol.sha(META)!=META_SHA:raise ValueError('Publisher-pinned metadata changed')
 rows=[]
 with META.open()as f:
  for row in csv.DictReader(f):
   if 'Tsuboyama_2023'not in row['DMS_id']or row['source_organism']not in SPECIES:continue
   if row['title']!=TITLE or row['coarse_selection_type']!='Stability'or row['selection_assay']!='Stability'or row['selection_type']!='cDNA display proteolysis':raise ValueError('Positive domain-stability metadata contract changed')
   if not(1<=len(row['target_seq'])<=100)or set(row['target_seq'])-protocol.AA:raise ValueError('Complete ordinary eukaryotic domain required')
   rows.append(row)
 if len(rows)!=9 or sum(int(r['DMS_total_number_mutants'])for r in rows)!=16000:raise ValueError('Frozen metadata denominator changed')
 scope=json.loads((HERE/'input_preparation_scope.json').read_bytes())
 if {r['DMS_id'] for r in rows}!={r['DMS_id'] for r in scope['cases']}:raise ValueError('Exact independently proposed assay identities required')
 return rows

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=HERE/'prepared');a=p.parse_args()
 rows=selected_metadata()
 if protocol.sha(ZIP)!=ZIP_SHA:raise ValueError('Publisher-pinned release archive changed')
 out=a.output;out.mkdir(exist_ok=False)
 import pyarrow as pa,pyarrow.csv as pacsv
 complete=[];total=0
 with zipfile.ZipFile(ZIP)as archive:
  for meta in rows:
   assay=meta['DMS_id'];member='DMS_ProteinGym_substitutions/'+meta['DMS_filename']
   with archive.open(member)as stream:
    table=pacsv.read_csv(stream,convert_options=pacsv.ConvertOptions(include_columns=['mutant','mutated_sequence'],column_types={'mutant':pa.string(),'mutated_sequence':pa.string()}))
   if table.column_names!=['mutant','mutated_sequence']:raise ValueError('Only exact native question-facing columns may be materialized')
   destination=out/(assay+'.inputs.jsonl');seen=set();count=0
   with destination.open('x')as f:
    for n,source in enumerate(table.to_pylist()):
     mutant=source['mutant']
     if mutant in seen:raise ValueError('Duplicate native mutant identifier')
     seen.add(mutant)
     case={'case_id':'P17::'+assay+'::'+str(n).zfill(6)+'::'+mutant,'DMS_id':assay,'UniProt_ID':meta['UniProt_ID'],'mutant':mutant,'reference_sequence':meta['target_seq'],'mutated_sequence':source['mutated_sequence'],'objective':'isolated_domain_folding_stability'}
     protocol.validate_input(case);f.write(json.dumps(case,separators=(',',':'))+'\n');count+=1
   if count!=int(meta['DMS_total_number_mutants']):raise ValueError('Native full-assay denominator changed')
   total+=count;complete.append({'DMS_id':assay,'UniProt_ID':meta['UniProt_ID'],'species':meta['source_organism'],'whole_reference_length':len(meta['target_seq']),'planned_native_variants':count,'source_archive_member':member,'input_path':str(destination.resolve()),'input_sha256':protocol.sha(destination),'reference_measurement_columns_loaded':False})
 if total!=16000:raise ValueError('Full additional9 denominator changed')
 save(out/'input_manifest.json',{'at_pacific':now(),'condition':protocol.CONDITION,'release':'ProteinGym_v1.3','release_archive_sha256':ZIP_SHA,'release_metadata_sha256':META_SHA,'native_release_assays':217,'positive_preparation_assays':9,'assays_outside_this_separate_condition':208,'earlier_completed_assays_immutable':30,'other_assays_unadmitted':178,'planned_native_variants':total,'assays':complete,'model_prompt_is_declared_pointwise_Qwen_adaptation':True,'native_LLM_prompt_or_historical_ProtST_replication_claimed':False,'input_columns_projected':['mutant','mutated_sequence'],'experimental_DMS_score_and_binary_columns_loaded':False,'no_measurements_supplied_to_solver':True,'model_calls':0,'model_forwards':0,'runtime_admission':False})
 print(json.dumps({'prepared_assays':len(complete),'prepared_native_variants':total,'experimental_measurements_loaded':False,'model_calls':0}))
if __name__=='__main__':main()
