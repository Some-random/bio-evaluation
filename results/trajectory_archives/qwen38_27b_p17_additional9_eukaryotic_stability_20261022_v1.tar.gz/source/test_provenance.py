from pathlib import Path
import copy,hashlib,json,tempfile,unittest
import protocol,runner,scorer
class Tests(unittest.TestCase):
 def fixture(self,path):
  case={'case_id':'artificial:1','DMS_id':'artificial','UniProt_ID':'ARTIFICIAL','mutant':'A1C','reference_sequence':'ACDE','mutated_sequence':'CCDE','objective':'isolated_domain_folding_stability'};key=hashlib.sha256(case['case_id'].encode()).hexdigest()
  for n in ['requests','responses','outcomes']:(path/n).mkdir()
  raw=json.dumps({'choices':[{'finish_reason':'stop','message':{'content':'{"score":0}'}}]}).encode();out=runner.outcome_from_raw(raw);out.update(case_id=case['case_id'],attempted=True,not_dispatched=False,response_saved=True)
  runner.save(path/'requests'/(key+'.json'),{'case_id':case['case_id'],'payload':protocol.payload(case)});runner.save(path/'outcomes'/(key+'.json'),out);(path/'responses'/(key+'.raw.json')).write_bytes(raw)
  def lock():return {'files_sha256':{str(p.relative_to(path)):protocol.sha(p)for n in ['requests','responses','outcomes']for p in(path/n).iterdir()}}
  return case,key,lock,{'planned':1,'attempted_confirmed':1,'terminal':1,'responses_saved':1}
 def test_wrong_resealed_question_is_rejected_before_reference_loader(self):
  with tempfile.TemporaryDirectory()as d:
   p=Path(d);c,k,lock,done=self.fixture(p);request=p/'requests'/(k+'.json');body=json.loads(request.read_bytes());body['payload']['messages'][0]['content']='wrong question';request.write_text(json.dumps(body));called=[]
   with self.assertRaises(ValueError):scorer.score_sealed_assays([{'DMS_id':'artificial','UniProt_ID':'ARTIFICIAL','cases':[c]}],p,lock(),done,lambda a:called.append(True))
   self.assertEqual(called,[])
 def test_exact_wire_payload_and_attempt_raw_outcome_are_required(self):
  with tempfile.TemporaryDirectory()as d:
   p=Path(d);c,k,lock,done=self.fixture(p);assays=[{'DMS_id':'artificial','UniProt_ID':'ARTIFICIAL','cases':[c]}]
   self.assertEqual(scorer.verified_predictions(assays,p,lock(),done),{c['case_id']:0.0})
   out=p/'outcomes'/(k+'.json');body=json.loads(out.read_bytes());body['attempted']=False;out.write_text(json.dumps(body))
   with self.assertRaises(ValueError):scorer.verified_predictions(assays,p,lock(),done)
 def test_resealed_outcome_score_cannot_replace_actual_raw_score(self):
  with tempfile.TemporaryDirectory()as d:
   p=Path(d);c,k,lock,done=self.fixture(p);out=p/'outcomes'/(k+'.json');body=json.loads(out.read_bytes());body['score']=999;out.write_text(json.dumps(body))
   with self.assertRaises(ValueError):scorer.verified_predictions([{'cases':[c]}],p,lock(),done)
 def test_missing_wire_member_or_foreign_attempt_fails_before_reference_loader(self):
  for mode in ['missing','foreign']:
   with tempfile.TemporaryDirectory()as d:
    p=Path(d);c,k,lock,done=self.fixture(p)
    if mode=='missing':(p/'requests'/(k+'.json')).unlink()
    else:runner.save(p/'requests'/('0'*64+'.json'),{'case_id':'foreign'})
    called=[]
    with self.assertRaises(ValueError):scorer.score_sealed_assays([{'cases':[c]}],p,lock(),done,lambda a:called.append(True))
    self.assertEqual(called,[])
if __name__=='__main__':unittest.main()

class OversizedProvenance(unittest.TestCase):
 def test_bounded_oversized_capture_remains_unknown_and_never_a_prediction(self):
  with tempfile.TemporaryDirectory()as d:
   p=Path(d);fixture=Tests();case,key,getlock,done=fixture.fixture(p)
   raw=p/'responses'/(key+'.raw.json');raw.write_bytes(b'x'*(runner.MAX_CAPTURE_BYTES+1))
   outcome={'case_id':case['case_id'],'attempted':True,'not_dispatched':False,'response_saved':True,'status':'response_size_exceeded','raw_capture_complete':False,'observed_final':False,'empty_final':False,'score':None}
   (p/'outcomes'/(key+'.json')).write_text(json.dumps(outcome))
   result=scorer.verified_predictions([{'cases':[case]}],p,getlock(),done);self.assertEqual(result,{})
