from pathlib import Path
import hashlib,json,tarfile
HERE=Path(__file__).resolve().parent
ARCHIVE=HERE.parent/'runtime_repair_v2/scorer_libraries/CPU_scorer_libraries.tar.gz'
EXPECTED='377405cb0f01b86c94173e447cc4bda3edc2fe1aad0b376c562cf1b889c6d1af'
if hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()!=EXPECTED:raise ValueError('Frozen numeric archive changed')
target=HERE/'CPU_numeric_libraries'
target.mkdir(exist_ok=False)
with tarfile.open(ARCHIVE) as tar:tar.extractall(target,filter='data')
manifest=json.loads((HERE.parent/'runtime_repair_v2/scorer_libraries/library_manifest.json').read_bytes())
for name,record in manifest['files'].items():
 p=target/'site-packages'/name
 if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest()!=record['sha256']:raise ValueError('Unchanged exact CPU-only numeric library required')
