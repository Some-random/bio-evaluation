from pathlib import Path
import io,json,tempfile,unittest,urllib.error
import runner
class Reply:
 def __init__(self,raw):self.raw=raw
 def __enter__(self):return self
 def __exit__(self,*args):return False
 def read(self,size):return self.raw[:size]
class Tests(unittest.TestCase):
 def raw(self,text='{"score":0}',finish='stop',**extra):return json.dumps({'choices':[{'finish_reason':finish,'message':{'content':text,**extra}}]},separators=(',',':')).encode()+b'\n'
 def test_actual_three_copy_gates_and_original_raw_seal(self):
  raw=[self.raw('{"score":0}'),self.raw('{"score":-2.5}'),self.raw('{"score":123.125}')];calls=[]
  class Opener:
   def open(inner,req,timeout):calls.append(req.data);return Reply(raw[len(calls)-1])
  with tempfile.TemporaryDirectory()as d:
   p=Path(d)/'run';c=runner.run_phase(plan_sha='artificial',endpoint='http://127.0.0.1:1/v1',folder=p,phase='development',cases=runner.development_cases(),assert_owned_server=lambda:None,opener_factory=Opener)
   self.assertTrue(c['artificial_exact_copy_gate_passed']);self.assertEqual(c['attempted_confirmed'],3)
   saved=[x.read_bytes()for x in (p/'responses').iterdir()];self.assertEqual(set(saved),set(raw));self.assertFalse(json.loads((p/'prediction_lock.json').read_bytes())['reference_labels_opened'])
   with self.assertRaises(FileExistsError):runner.run_phase(plan_sha='artificial',endpoint='unused',folder=p,phase='development',cases=runner.development_cases(),assert_owned_server=lambda:None,opener_factory=Opener)
   self.assertEqual(len(calls),3)
 def test_first_failed_artificial_copy_stops_without_sending_other_slots(self):
  calls=[]
  class Opener:
   def open(inner,*a,**k):calls.append(1);return Reply(self.raw('{"score":99}'))
  with tempfile.TemporaryDirectory()as d:
   c=runner.run_phase(plan_sha='artificial',endpoint='http://127.0.0.1:1/v1',folder=Path(d)/'run',phase='development',cases=runner.development_cases(),assert_owned_server=lambda:None,opener_factory=Opener)
   self.assertEqual(len(calls),1);self.assertEqual(c['not_dispatched'],2);self.assertFalse(c['artificial_exact_copy_gate_passed'])
 def test_HTTP_and_transport_unknown_not_empty_no_retry(self):
  for error in [urllib.error.HTTPError('artificial',500,'bad',{},io.BytesIO(b'artificial error')),urllib.error.URLError('artificial')]:
   calls=[]
   class Opener:
    def open(inner,*a,**k):calls.append(1);raise error
   with tempfile.TemporaryDirectory()as d:
    c=runner.run_phase(plan_sha='artificial',endpoint='http://127.0.0.1:1/v1',folder=Path(d)/'run',phase='development',cases=runner.development_cases(),assert_owned_server=lambda:None,opener_factory=Opener)
    self.assertEqual(c['attempted_confirmed'],1);self.assertEqual(len(calls),1);self.assertEqual(c['empty_finals'],0);self.assertEqual(c['unknown_finals'],1)
 def test_observed_empty_reasoning_and_length_are_distinct(self):
  empty=runner.outcome_from_raw(self.raw(''));self.assertTrue(empty['empty_final']);self.assertTrue(empty['observed_final'])
  self.assertTrue(runner.outcome_from_raw(self.raw('{"score":0}','length'))['truncation'])
  for field in ['reasoning','reasoning_content','tool_calls']:
   r=runner.outcome_from_raw(self.raw('{"score":0}',**{field:'present'}));self.assertNotEqual(r['status'],'delivered')
 def test_server_identity_guard_precedes_wire_attempt(self):
  calls=[]
  class Opener:
   def open(inner,*a,**k):calls.append(1);return Reply(self.raw())
  def fail():raise PermissionError('Wrong server')
  with tempfile.TemporaryDirectory()as d:
   with self.assertRaises(PermissionError):runner.run_phase(plan_sha='artificial',endpoint='http://127.0.0.1:1/v1',folder=Path(d)/'run',phase='development',cases=runner.development_cases(),assert_owned_server=fail,opener_factory=Opener)
   self.assertEqual(calls,[])
if __name__=='__main__':unittest.main()

class FurtherDeliveryBoundaries(unittest.TestCase):
 def test_null_is_observed_empty_missing_or_malformed_is_unknown(self):
  def raw(message):return json.dumps({'choices':[{'finish_reason':'stop','message':message}]}).encode()
  null=runner.outcome_from_raw(raw({'content':None}));self.assertTrue(null['observed_final']);self.assertTrue(null['empty_final']);self.assertNotEqual(null['status'],'delivered')
  for message in [{},{'content':[]},{'unexpected':'value'}]:
   result=runner.outcome_from_raw(raw(message));self.assertFalse(result['observed_final']);self.assertFalse(result['empty_final'])
 def test_first_refusal_stops_new_benchmark_sends_and_drains_three_outstanding(self):
  import threading,time
  barrier=threading.Barrier(3);calls=[];lock=threading.Lock()
  class Opener:
   def open(inner,*args,**kwargs):
    with lock:index=len(calls);calls.append(index)
    barrier.wait(timeout=5)
    if index:time.sleep(.05)
    message={'content':'{"score":0}'}
    if index==0:message['refusal']='artificial refusal'
    return Reply(json.dumps({'choices':[{'finish_reason':'stop','message':message}]}).encode())
  base={'DMS_id':'artificial','UniProt_ID':'ARTIFICIAL','mutant':'A1C','reference_sequence':'ACDE','mutated_sequence':'CCDE','objective':'isolated_domain_folding_stability'}
  cases=[{**base,'case_id':'artificial:'+str(i)}for i in range(7)]
  with tempfile.TemporaryDirectory()as d:
   result=runner.run_phase(plan_sha='artificial',endpoint='http://127.0.0.1:1/v1',folder=Path(d)/'run',phase='benchmark',cases=cases,assert_owned_server=lambda:None,opener_factory=Opener,workers=3)
   self.assertEqual(len(calls),3);self.assertEqual(result['attempted_confirmed'],3);self.assertEqual(result['terminal'],3);self.assertEqual(result['not_dispatched'],4);self.assertEqual(result['refusals'],1);self.assertFalse(result['all_delivered'])
 def test_HTTP400_is_also_a_first_delivery_failure_stop(self):
  calls=[]
  class Opener:
   def open(inner,*args,**kwargs):calls.append(1);raise urllib.error.HTTPError('artificial',400,'bad',{},io.BytesIO(b'bad'))
  base={'DMS_id':'artificial','UniProt_ID':'ARTIFICIAL','mutant':'A1C','reference_sequence':'ACDE','mutated_sequence':'CCDE','objective':'isolated_domain_folding_stability'}
  with tempfile.TemporaryDirectory()as d:
   c=runner.run_phase(plan_sha='artificial',endpoint='http://127.0.0.1:1/v1',folder=Path(d)/'run',phase='benchmark',cases=[{**base,'case_id':str(i)}for i in range(4)],assert_owned_server=lambda:None,opener_factory=Opener,workers=1)
   self.assertEqual(c['attempted_confirmed'],1);self.assertEqual(c['not_dispatched'],3);self.assertEqual(c['http_errors'],1);self.assertEqual(len(calls),1)

class FastFailureScheduling(unittest.TestCase):
 def cases(self):
  base={'DMS_id':'artificial','UniProt_ID':'ARTIFICIAL','mutant':'A1C','reference_sequence':'ACDE','mutated_sequence':'CCDE','objective':'isolated_domain_folding_stability'}
  return [{**base,'case_id':'artificial:'+str(i)}for i in range(5)]
 def test_first_future_complete_before_second_submit_stops_at_one(self):
  from concurrent.futures import Future
  from unittest.mock import patch
  calls=[]
  class Immediate:
   def __init__(self,**kwargs):pass
   def __enter__(self):return self
   def __exit__(self,*args):pass
   def submit(self,fn,*args):
    f=Future()
    try:f.set_result(fn(*args))
    except Exception as error:f.set_exception(error)
    return f
  class Opener:
   def open(inner,*args,**kwargs):calls.append(1);return Reply(json.dumps({'choices':[{'finish_reason':'stop','message':{'content':'{"score":0}','refusal':'artificial refusal'}}]}).encode())
  with tempfile.TemporaryDirectory()as d,patch.object(runner,'ThreadPoolExecutor',Immediate):
   result=runner.run_phase(plan_sha='artificial',endpoint='http://127.0.0.1:1/v1',folder=Path(d)/'run',phase='benchmark',cases=self.cases(),assert_owned_server=lambda:None,opener_factory=Opener,workers=3)
   self.assertEqual(len(calls),1);self.assertEqual(result['attempted_confirmed'],1);self.assertEqual(result['terminal'],1);self.assertEqual(result['not_dispatched'],4)
 def test_already_queued_but_unattempted_future_is_skipped_without_fake_attempt(self):
  from concurrent.futures import Future
  from unittest.mock import patch
  calls=[]
  class DelayedFirst:
   def __init__(self,**kwargs):self.first=None
   def __enter__(self):return self
   def __exit__(self,*args):pass
   def submit(self,fn,*args):
    f=Future()
    if self.first is None:self.first=(f,fn,args)
    else:
     first,method,arguments=self.first
     if not first.done():first.set_result(method(*arguments))
     f.set_result(fn(*args))
    return f
  class Opener:
   def open(inner,*args,**kwargs):calls.append(1);return Reply(json.dumps({'choices':[{'finish_reason':'stop','message':{'content':None,'refusal':'artificial refusal'}}]}).encode())
  with tempfile.TemporaryDirectory()as d,patch.object(runner,'ThreadPoolExecutor',DelayedFirst):
   p=Path(d)/'run';result=runner.run_phase(plan_sha='artificial',endpoint='http://127.0.0.1:1/v1',folder=p,phase='benchmark',cases=self.cases(),assert_owned_server=lambda:None,opener_factory=Opener,workers=3)
   self.assertEqual(len(calls),1);self.assertEqual(result['attempted_confirmed'],1);self.assertEqual(result['terminal'],1);self.assertEqual(result['not_dispatched'],4);self.assertEqual(len(list((p/'requests').iterdir())),1)
