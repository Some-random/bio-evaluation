import unittest
from scorer import native_aggregate
class Tests(unittest.TestCase):
 def assays(self):return [{'DMS_id':'artificial_A','UniProt_ID':'U1','cases':[{'case_id':'a'+str(i)}for i in range(4)]},{'DMS_id':'artificial_B','UniProt_ID':'U2','cases':[{'case_id':'b'+str(i)}for i in range(4)]}]
 def values(self):return {letter+str(i):float(i)for letter in'ab'for i in range(4)}
 def gold(self,assay):return {c['case_id']:float(i)for i,c in enumerate(assay['cases'])}
 def test_full_native_coverage_per_assay_and_protein(self):
  r=native_aggregate(self.assays(),self.values(),self.gold);self.assertEqual(r['primary_native_Spearman'],1);self.assertTrue(r['references_opened'])
 def test_missing_invalid_or_foreign_cannot_load_measurements(self):
  for bad in [{k:v for k,v in self.values().items()if k!='a0'},{**self.values(),'a0':float('nan')},{**self.values(),'a0':True}]:
   def no(a):raise AssertionError('Reference loader touched before full prediction coverage')
   r=native_aggregate(self.assays(),bad,no);self.assertIsNone(r['primary_native_Spearman']);self.assertFalse(r['references_opened'])
  with self.assertRaises(ValueError):native_aggregate(self.assays(),{**self.values(),'foreign':0},self.gold)
 def test_native_three_decimal_round_precedes_aggregation(self):
  from scipy.stats import spearmanr
  import numpy as np
  predictions=self.values();predictions.update({'a0':0,'a1':2,'a2':3,'a3':1})
  raw=float(spearmanr([0,1,2,3],[0,2,3,1])[0]);r=native_aggregate(self.assays(),predictions,self.gold)
  self.assertEqual(r['primary_native_Spearman'],(float(np.round(raw,3))+1)/2)
 def test_constant_native_assay_undefined_never_dropped(self):
  p=self.values();p.update({'a'+str(i):0 for i in range(4)});r=native_aggregate(self.assays(),p,self.gold)
  self.assertIsNone(r['primary_native_Spearman']);self.assertEqual(r['undefined_assays'],['artificial_A']);self.assertEqual(r['planned_variants'],8)
 def test_references_require_exact_native_id_coverage(self):
  with self.assertRaises(ValueError):native_aggregate(self.assays(),self.values(),lambda a:{'foreign':1})
 def test_duplicate_case_ids_or_nonfinite_gold_fail(self):
  a=self.assays();a[1]['cases'][0]['case_id']='a0'
  with self.assertRaises(ValueError):native_aggregate(a,self.values(),self.gold)
  def broken(a):return {c['case_id']:float('inf')for c in a['cases']}
  with self.assertRaises(ValueError):native_aggregate(self.assays(),self.values(),broken)
if __name__=='__main__':unittest.main()
