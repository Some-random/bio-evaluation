"""Private CPU-only scorer libraries, never installed into the Qwen namespace."""
from pathlib import Path
import json,os,tarfile
import protocol
PINNED={'numpy':'1.26.4','scipy':'1.14.1'}

def restore(local,plan):
 archive=plan['CPU_scorer_libraries'];manifest=json.loads(Path(plan['CPU_scorer_library_manifest']).read_bytes())
 if protocol.sha(archive['path'])!=archive['sha256']:raise ValueError('Frozen CPU scorer archive changed')
 target=Path(local)/'CPU_scorer_libraries';target.mkdir(exist_ok=False)
 with tarfile.open(archive['path'])as tar:tar.extractall(target,filter='data')
 site=target/'site-packages'
 for name,record in manifest['files'].items():
  path=site/name
  if path.is_symlink()or protocol.sha(path)!=record['sha256']:raise ValueError('Restored exact CPU scorer library changed')
 return site

def environment(base,site,source):
 env=dict(base)
 for name in list(env):
  if any(word in name.upper()for word in ['API_KEY','TOKEN','SECRET','PASSWORD','CREDENTIAL'])or name in ['PYTHONHOME','VIRTUAL_ENV','SSH_AUTH_SOCK','NETRC','KUBECONFIG','CUDA_HOME','CUDA_PATH','CUDACXX','CUDAHOSTCXX','NVCC','CC','CXX','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LIBRARY_PATH','CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','NVCC_PREPEND_FLAGS','NVCC_APPEND_FLAGS']:env.pop(name,None)
 env.update(CUDA_VISIBLE_DEVICES='',PYTHONPATH=str(site)+':'+str(source),PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
 return env
