"""A declared pointwise Qwen adaptation; no native LLM prompt is claimed."""
import hashlib,json,math,re
CONDITION='PROTEINGYM_V13_ADDITIONAL9_EUKARYOTIC_DOMAIN_STABILITY_POINTWISE_QWEN_V1'
MODEL='Qwen/Qwen3.8-27B'
AA=frozenset('ACDEFGHIKLMNPQRSTVWY')
SCALAR_REGEX=r'\{"score":-?(0|[1-9][0-9]{0,5})(\.[0-9]{1,6})?\}'
INPUT_KEYS={'case_id','DMS_id','UniProt_ID','mutant','reference_sequence','mutated_sequence','objective'}
GENERATION={'temperature':0.0,'top_p':1.0,'seed':42,'max_tokens':16384,'chat_template_kwargs':{'enable_thinking':False}}

def sha(path):
 h=hashlib.sha256()
 with open(path,'rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def validate_input(row):
 if set(row)!=INPUT_KEYS or row['objective']!='isolated_domain_folding_stability':raise ValueError('Exact reference-isolated stability input required')
 wt,variant=row['reference_sequence'],row['mutated_sequence']
 if not wt or len(variant)!=len(wt)or set(wt)-AA or set(variant)-AA:raise ValueError('Whole canonical reference and variant required')
 expected=list(wt);positions=set()
 for substitution in row['mutant'].split(':'):
  match=re.fullmatch(r'([ACDEFGHIKLMNPQRSTVWY])([1-9][0-9]*)([ACDEFGHIKLMNPQRSTVWY])',substitution)
  if not match:raise ValueError('Native substitution syntax required')
  before,pos,after=match.groups();index=int(pos)-1
  if index>=len(wt)or index in positions or wt[index]!=before:raise ValueError('Variant/reference binding mismatch')
  positions.add(index);expected[index]=after
 if ''.join(expected)!=variant:raise ValueError('Complete native variant differs from stated substitutions')
 return row

def question(row):
 validate_input(row)
 return ('Predict the folding-stability effect of this complete isolated eukaryotic protein-domain variant relative to its reference sequence. '
  'Return one numerical score: larger means greater folding stability. The score is an uncalibrated prediction for retrospective ranking; it is not a measured free energy or a validated biological function. Do not supply an explanation.\n\n'
  'Reference domain sequence:\n'+row['reference_sequence']+'\n\nNative substitutions:\n'+row['mutant']+'\n\nComplete variant domain sequence:\n'+row['mutated_sequence']+'\n\nReturn exactly a compact JSON object with the single key "score" and a finite number.')

def payload(row):
 return {'model':MODEL,'messages':[{'role':'user','content':question(row)}],**GENERATION,'structured_outputs':{'regex':SCALAR_REGEX}}

def parse_reply(raw):
 obj=json.loads(raw);choices=obj.get('choices')
 if not isinstance(choices,list)or len(choices)!=1:raise ValueError('One completion required')
 choice=choices[0];m=choice.get('message',{})
 if choice.get('finish_reason')!='stop'or any(m.get(k)for k in ['reasoning','reasoning_content','tool_calls','refusal']):raise ValueError('Clean nonreasoning final required')
 text=m.get('content')
 if not isinstance(text,str)or re.fullmatch(SCALAR_REGEX,text)is None:raise ValueError('Exact bounded compact numeric JSON required')
 result=json.loads(text);value=result['score']
 if isinstance(value,bool)or not isinstance(value,(int,float))or not math.isfinite(value):raise ValueError('Finite numeric score required')
 return float(value)
