from pathlib import Path
import unittest
import scorer_runtime,worker
class Tests(unittest.TestCase):
 def test_CPU_scorer_namespace_is_separate_and_never_mutates_Qwen_environment(self):
  original={'PATH':'/private/python/bin:/usr/bin','PYTHONPATH':'/Qwen','CUDA_VISIBLE_DEVICES':'0','CUDA_HOME':'/private/cu13','OPENAI_API_KEY':'artificial-secret','VLLM_USE_V2_MODEL_RUNNER':'0'}
  actual=scorer_runtime.environment(original,Path('/private/CPUscorer/site-packages'),Path('/source'))
  self.assertEqual(original['CUDA_VISIBLE_DEVICES'],'0');self.assertEqual(original['PYTHONPATH'],'/Qwen');self.assertEqual(actual['CUDA_VISIBLE_DEVICES'],'');self.assertEqual(actual['PYTHONPATH'],'/private/CPUscorer/site-packages:/source');self.assertNotIn('OPENAI_API_KEY',actual);self.assertNotIn('CUDA_HOME',actual)
 def test_isolated_scorer_gate_precedes_private_model_exec_and_actual_score_uses_CPU_child(self):
  text=Path(worker.__file__).read_text();self.assertLess(text.index('scorer_runtime.restore(local,plan)'),text.index('os.execve'))
  self.assertLess(text.index("HERE/'check_scorer_runtime.py'"),text.index('os.execve'));self.assertIn('scorer_runtime.environment(os.environ,scorer_site,HERE)',text);self.assertNotIn("from scorer import score",text)
if __name__=='__main__':unittest.main()
