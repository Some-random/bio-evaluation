"""Actual post-install0.32 API and complete prompt checks, before model load."""
from pathlib import Path
import argparse,importlib.metadata as metadata,json,os
import protocol,runner
HERE=Path(__file__).resolve().parent

def check(plan,output):
 if os.environ.get('CUDA_VISIBLE_DEVICES')!='':raise PermissionError('CPU-only API check required')
 if metadata.version('vllm')!='0.32.0':raise ValueError('Actual exact vLLM0.32 required')
 from transformers import AutoTokenizer
 from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest
 from vllm.sampling_params import StructuredOutputsParams
 tok=AutoTokenizer.from_pretrained(plan['model_directory'],local_files_only=True)
 requests=[r['payload']for r in runner.development_cases()]
 manifest=json.loads(Path(plan['input_manifest']).read_bytes())
 for assay in manifest['assays']:
  with open(assay['input_path'])as f:requests.append(protocol.payload(json.loads(next(f))))
 counts=[]
 for body in requests:
  parsed=ChatCompletionRequest.model_validate(body)
  if parsed.structured_outputs.regex!=protocol.SCALAR_REGEX or StructuredOutputsParams(regex=protocol.SCALAR_REGEX).regex!=protocol.SCALAR_REGEX:raise ValueError('Native compact finite numeric regex mapping changed')
  text=tok.apply_chat_template(body['messages'],tokenize=False,add_generation_prompt=True,**body['chat_template_kwargs'])
  if body['messages'][0]['content']not in text:raise ValueError('Full native question omitted')
  ids=tok.encode(text,add_special_tokens=False)
  if not isinstance(ids,list)or len(ids)<10 or len(ids)+16384>65536:raise ValueError('Whole native input does not fit')
  counts.append(len(ids))
 runner.save(output,{'at_pacific':runner.now(),'stage':'actual_exact0_32_API_and_native_tokenizer_gate_passed','packages':{k:metadata.version(k)for k in ['vllm','torch','transformers','numpy']},'native_API_requests_checked':len(counts),'max_prompt_tokens_in_API_panel':max(counts),'all_full16000_CPU_check_sha256':protocol.sha(plan['CPU_validation']),'model_calls':0,'model_weights_loaded':False,'model_forwards':0})
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();check(json.loads(a.plan.read_bytes()),a.output)
