from pathlib import Path
import importlib.util,json,os
import protocol
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[4]
OWNER='/root/proteingym_remaining_coverage'
POLICY=ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review_resume_v2.json'
POLICY_SHA='d41951c26539a30800ff3abbc958a7b92bca924ddc958fd115d612bca412fd08'
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def validate(plan_path,plan_sha,grant_path=None,grant_sha=None,require_job=False):
 if protocol.sha(plan_path)!=plan_sha:raise ValueError('Exact frozen P17 plan required')
 p=json.loads(Path(plan_path).read_bytes())
 expected={'task_id':'P17','condition':protocol.CONDITION,'model':protocol.MODEL,'planned_benchmark_variants':16000,'reviewed_assays':9,'native_release_assays':217,'development_planned':3,'gpus_requested':1,'new_training':False,'paid_model_calls':False,'automatic_retries':False,'full_native_benchmark_complete':False}
 if any(p.get(k)!=v for k,v in expected.items()):raise PermissionError('Only independently positive complete9/16000 ordinary stability cohort is eligible')
 for name,digest in p['frozen_files_sha256'].items():
  path=Path(name)
  if path.is_symlink()or protocol.sha(path)!=digest:raise ValueError('Frozen exact source/input changed: '+path.name)
 if grant_path:
  adoption_path=ROOT/'.local/catalog_execution_2026-10-20/tasks/P17/remaining_coverage_20261022/root_additional9_scientific_adoption_20261022.json'
  adoption_sha='921425baa99eac8b2755ef12fd0050358999f42a437c269082996f6918fbfe6c'
  if protocol.sha(adoption_path)!=adoption_sha or p.get('root_scientific_adoption_sha256')!=adoption_sha:raise PermissionError('Exact root additional9 scientific scope adoption required')
  adopted=json.loads(adoption_path.read_bytes())
  if adopted.get('scientific_scope_adopted') is not True or adopted.get('condition_id')!=protocol.CONDITION or adopted.get('native_variant_count')!=16000:raise PermissionError('Unchanged exact root additional9 scope required')
  if protocol.sha(grant_path)!=grant_sha:raise ValueError('Detached grant changed')
  g=json.loads(Path(grant_path).read_bytes());reviewer=g.get('reviewer',g.get('issuer'))
  required={'admitted':True,'task_id':'P17','condition':protocol.CONDITION,'plan_sha256':plan_sha,'reviewed_assays':9,'planned_benchmark_variants':16000,'gpu_count':1,'project_gpu_ceiling':8,'one_attempt_per_case':True,'new_training':False,'paid_model_calls':False,'source_scope_sha256':p['source_scope_sha256']}
  if any(g.get(k)!=v for k,v in required.items()):raise PermissionError('Plan-bound independent9/16000 admission required')
  if reviewer==OWNER:raise PermissionError('Owner cannot self-admit')
  if reviewer not in ['root','/root']:
   if protocol.sha(POLICY)!=POLICY_SHA or g.get('delegation_sha256')!=POLICY_SHA:raise PermissionError('Delegation changed')
   policy=json.loads(POLICY.read_bytes())
   if reviewer not in policy['authorized_reviewers']or'P17'not in policy['authorized_task_ids']:raise PermissionError('Different authorized peer required')
  capacity=load('p17_additional9_resource_admission',HERE/'submission_v1/admission_validation.py')
  capacity.validate_resource_delegation(p,g,plan_sha,grant_sha,protocol.sha,execution=HERE,job_id=os.environ.get('SLURM_JOB_ID') if require_job else None)
 elif require_job:raise PermissionError('No model/runtime phase without independent admission')
 if require_job and not os.environ.get('SLURM_JOB_ID'):raise PermissionError('Real standalone Slurm job required')
 return p

def current_gpu_audit(plan):
 site=load('p17_exact_site_tools',plan['site_tools_helper']);env,_=site.bind_site_tools(dict(os.environ));os.environ['PATH']=env['PATH']
 helper=load('p17_exact_project_GPU_audit',plan['project_gpu_audit_helper']);audit=helper.conservative_project_gpu_audit(require_own_job=True)
 own=[r for r in audit['jobs']if r['job_id']==os.environ.get('SLURM_JOB_ID')]
 if len(own)!=1 or own[0]['gpus']!=1 or own[0]['command'].split()[0]!=str(HERE/'worker.sbatch')or Path(own[0]['workdir']).resolve()!=ROOT:raise PermissionError('Exact own one-GPU worker allocation required')
 return audit
