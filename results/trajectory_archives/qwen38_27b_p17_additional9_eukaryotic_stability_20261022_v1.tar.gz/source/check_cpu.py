"""CPU input preparation/full tokenizer checks; no model construction or labels."""
from pathlib import Path
import datetime,json,os,subprocess,sys,time
from zoneinfo import ZoneInfo
import protocol
HERE=Path(__file__).resolve().parent

def count_prompt_tokens(tok,request):
 text=tok.apply_chat_template(request['messages'],tokenize=False,add_generation_prompt=True,**request['chat_template_kwargs'])
 if not isinstance(text,str)or not text:raise ValueError('Actual rendered native chat text required')
 ids=tok.encode(text,add_special_tokens=False)
 if not isinstance(ids,list)or not ids or any(type(x)is not int for x in ids):raise ValueError('Actual integer token IDs required, not BatchEncoding field count')
 return len(ids)

def main():
 if not os.environ.get('SLURM_JOB_ID')or os.environ.get('CUDA_VISIBLE_DEVICES')!=''or os.environ.get('SLURM_GPUS'):raise PermissionError('CPU allocation with no visible GPU required')
 plan=json.loads((HERE/'CPU_plan.json').read_bytes())
 for path,digest in plan['file_sha256'].items():
  if protocol.sha(path)!=digest:raise ValueError('Frozen CPU source changed')
 if not(HERE/'prepared/input_manifest.json').exists():subprocess.run([plan['projection_interpreter'],str(HERE/'prepare_inputs.py')],check=True)
 from transformers import AutoTokenizer
 tok=AutoTokenizer.from_pretrained(plan['model_directory'],local_files_only=True)
 manifest=json.loads((HERE/'prepared/input_manifest.json').read_bytes());total=0;per=[];started=time.monotonic()
 for assay in manifest['assays']:
  if protocol.sha(assay['input_path'])!=assay['input_sha256']:raise ValueError('Reused exact projected inputs changed')
  count=0;max_tokens=0
  with open(assay['input_path'])as f:
   for line in f:
    case=json.loads(line);request=protocol.payload(case)
    tokens=count_prompt_tokens(tok,request)
    if tokens+16384>65536:raise ValueError('Intact input does not fit original65K context; no clipping')
    max_tokens=max(max_tokens,tokens);count+=1
  if count!=assay['planned_native_variants']:raise ValueError('Full native assay case count changed')
  total+=count;per.append({'DMS_id':assay['DMS_id'],'native_variants_checked':count,'max_intact_prompt_tokens':max_tokens})
  print(json.dumps({'CPU_checked_assays':len(per),'CPU_checked_variants':total}),flush=True)
 if total!=16000:raise ValueError('Full proposed cohort not checked')
 result={'at_pacific':datetime.datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),'stage':'full_positive9_input_projection_and_CPU_tokenization_passed_not_model_delivery','job_id':os.environ['SLURM_JOB_ID'],'prepared_assays':9,'native_release_assays':217,'native_variants_checked':total,'all_intact_inputs_plus_uniform16384_output_fit65536':True,'max_prompt_tokens':max(x['max_intact_prompt_tokens']for x in per),'per_assay':per,'input_manifest_sha256':protocol.sha(HERE/'prepared/input_manifest.json'),'source_measurement_columns_projected':False,'measurements_or_reference_labels_read':False,'model_calls':0,'model_forwards':0,'model_weights_loaded':False,'GPU_allocations':0,'CPU_tokenization_elapsed_seconds':time.monotonic()-started,'runtime_admission':False,'native_or_historical_ProtST_replication_claimed':False}
 with(HERE/'CPU_validation.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({k:result[k]for k in ['stage','native_variants_checked','max_prompt_tokens','model_calls']}))
if __name__=='__main__':main()
