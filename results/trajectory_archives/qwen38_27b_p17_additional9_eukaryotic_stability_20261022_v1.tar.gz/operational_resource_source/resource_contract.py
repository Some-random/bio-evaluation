"""Exact resource-only amendment; original P17 scientific plan stays unchanged."""
from pathlib import Path
import hashlib, importlib.util, json, os

HERE = Path(__file__).resolve().parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
ORIGINAL = HERE.parent / 'additional9_eukaryotic_stability_v3'
PLAN_SHA = '7f7907abc333cf28bdecfda7da586dd6f3eec791ac4d96fb393674c33f03cb30'
GRANT_SHA = 'a169be9d830c0bade029a5f484aa5df8e6a8b5c1f5e2783931a52618d7671874'
PRIORITY_SHA = '4a7a0af77a9f0031363ef90769505d80a3439c1e6d9a0dab724b153121407229'
DELEGATION_SHA = 'd41951c26539a30800ff3abbc958a7b92bca924ddc958fd115d612bca412fd08'
OWNER = '/root/main_docs_refresh'
RESTORE_SHA = 'bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
SHARED_SHA = 'cb881370f7dac295d7d153f72baddcbf604c0fce0cc651ee82c557e5efcad6f9'
ADAPTER_SHA = 'd7464059bdf95ab61fe0a2699cc4fb510252b9502aeb2c869d612f9d5d3d5f42'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def regular(path, digest):
    path = Path(path)
    if not path.is_file() or path.is_symlink() or path != path.resolve() or sha(path) != digest:
        raise PermissionError('An exact regular resource amendment source changed: ' + str(path))


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def validate(args, *, require_job=False, require_release=False):
    manifest_path = Path(args.resource_amendment)
    if manifest_path != HERE / 'manifest.json':
        raise PermissionError('Only this exact additive resource manifest is eligible')
    regular(manifest_path, args.resource_amendment_sha256)
    manifest = json.loads(manifest_path.read_bytes())
    expected = {'role': 'P17_additional9_restored_operational_amendment',
        'task_id': 'P17', 'original_plan_sha256': PLAN_SHA,
        'original_engineering_admission_sha256': GRANT_SHA,
        'original_frozen_file_count': 71, 'scientific_files_unchanged': True,
        'gpus_requested': 1, 'project_gpu_ceiling': 8,
        'new_scientific_or_case_permission': False, 'no_automatic_retry': True,
        'priority_record_sha256': PRIORITY_SHA}
    if any(manifest.get(k) != v for k, v in expected.items()):
        raise PermissionError('Unchanged scientific condition and bounded resource scope required')
    if (Path(args.plan) != ORIGINAL / 'plan.json' or args.plan_sha256 != PLAN_SHA or
            Path(args.admission) != ORIGINAL / 'engineering_admission.json' or
            args.admission_sha256 != GRANT_SHA):
        raise PermissionError('Original scientific plan and engineering admission must be retained')
    original = json.loads((ORIGINAL / 'plan.json').read_bytes())
    if manifest['original_frozen_files_sha256'] != original['frozen_files_sha256']:
        raise PermissionError('The complete original 71-file science/runtime closure must be retained')
    for path, digest in manifest['files_sha256'].items():
        regular(path, digest)
    for path, digest in manifest['original_frozen_files_sha256'].items():
        regular(path, digest)
    approval = Path(args.resource_admission)
    if approval != HERE / 'engineering_admission.json':
        raise PermissionError('Exact independent amendment admission path required')
    regular(approval, args.resource_admission_sha256)
    grant = json.loads(approval.read_bytes())
    reviewer = grant.get('reviewer')
    authority = restoration_authority(manifest)
    shared_binding(manifest)
    if (reviewer != authority['independent_review_delegation']['P17_P19_scalar184'] or
            reviewer == OWNER or grant.get('approved') is not True or
            grant.get('role') != 'independent_P17_restored_operational_admission' or
            grant.get('manifest_sha256') != args.resource_amendment_sha256 or
            grant.get('root_authorization_sha256') != RESTORE_SHA or
            grant.get('shared_resource_binding_sha256') != SHARED_SHA or
            grant.get('original_plan_sha256') != PLAN_SHA or
            grant.get('original_engineering_admission_sha256') != GRANT_SHA or
            grant.get('scientific_scope_unchanged') is not True or
            grant.get('priority_release_required') is not True):
        raise PermissionError('Exact independently reviewed restored operational admission required')
    for path, digest in manifest['preserved_legacy_STOPs_sha256'].items():
        regular(path, digest)
    regular(ORIGINAL / 'plan.json', PLAN_SHA)
    regular(ORIGINAL / 'engineering_admission.json', GRANT_SHA)
    retired = json.loads(Path(manifest['predecessor_stop_receipt']['path']).read_bytes())
    if (retired.get('process_exit_observed') is not True or
            retired.get('controller_lock_observed_free') is not True or
            retired.get('submission_claim_present') is not False or
            retired.get('submission_receipt_present') is not False):
        raise PermissionError('Predecessor waiter retirement must be verified before its replacement')
    proc = Path('/proc') / str(retired['waiter_pid'])
    if proc.exists() and proc.joinpath('stat').read_text().split()[21] == retired['waiter_start_ticks']:
        raise PermissionError('The exact predecessor capacity waiter is still live')
    if require_release:
        validate_priority_release(manifest, args.resource_amendment_sha256, args.resource_admission_sha256)
    if require_job:
        verify_actual_submission(args, manifest)
    return manifest


def restoration_authority(manifest):
    expected = {'path': str(ROOT / '.local/goal_restore_20261024/root_authorization.json'), 'sha256': RESTORE_SHA}
    if manifest.get('root_authorization') != expected:
        raise PermissionError('Exact explicit user-restoration authority required')
    regular(expected['path'], expected['sha256'])
    value = json.loads(Path(expected['path']).read_bytes())
    if (value.get('issuer') != '/root' or value.get('approved') is not True or
            value.get('role') != 'explicit_user_authorized_restoration_of_reviewed_local_GPU_evaluations' or
            value.get('owners', {}).get('P17') != OWNER or value.get('project_GPU_ceiling') != 8 or
            'P17_additional9_16000_variants' not in value.get('restore_already_reviewed_local_lanes', []) or
            value.get('no_new_cohorts_or_protocols_adopted') is not True or
            value.get('unchanged_restrictions', {}).get('no_attempted_or_ambiguous_retries') is not True or
            value.get('unchanged_restrictions', {}).get('no_new_paid_inference') is not True):
        raise PermissionError('Current explicit root scope does not authorize this exact restored lane')
    return value


def shared_binding(manifest):
    reference = {'path': str(ROOT / '.local/goal_restore_20261024/shared_resource_binding.json'), 'sha256': SHARED_SHA}
    if manifest.get('shared_resource_binding') != reference:
        raise PermissionError('Exact current shared resource binding required')
    regular(reference['path'], reference['sha256'])
    value = json.loads(Path(reference['path']).read_bytes())
    if (value.get('approved') is not True or value.get('reviewer') != '/root/priority_runtime_review' or
            value.get('role') != 'shared_resource_configuration_only_no_dispatch_authority' or
            value.get('project_GPU_ceiling') != 8 or value.get('root_authorization') != manifest['root_authorization'] or
            value.get('resource_adapter') != manifest['resource_adapter'] or
            value['resource_adapter']['sha256'] != ADAPTER_SHA or
            value.get('additional_root_proofs') != manifest['additional_root_proofs'] or
            value.get('additional_proof_binding') != manifest['additional_proof_binding']):
        raise PermissionError('Changed or mismatched independently bound resource configuration')
    for ref in [value['resource_adapter'], value['root_authorization'], value['additional_proof_binding'], *value['additional_root_proofs']]:
        regular(ref['path'], ref['sha256'])
    return value


def validate_priority_release(manifest, manifest_sha, grant_sha):
    restoration_authority(manifest)
    shared_binding(manifest)
    path = HERE / 'priority_release.json'
    if not path.is_file() or path.is_symlink() or path != path.resolve():
        raise PermissionError('The exact restored task-local root release has not been recorded')
    value = json.loads(path.read_bytes())
    if (value.get('issuer') != '/root' or value.get('prepared_by') != OWNER or value.get('approved') is not True or
            value.get('role') != 'exact_P17_restored_scheduling_release' or
            value.get('root_authorization_sha256') != RESTORE_SHA or
            value.get('resource_amendment_sha256') != manifest_sha or
            value.get('resource_admission_sha256') != grant_sha or
            value.get('original_plan_sha256') != PLAN_SHA or
            value.get('original_engineering_admission_sha256') != GRANT_SHA or
            value.get('one_original_P17_allocation_only') is not True or
            value.get('scheduling_only') is not True or value.get('project_GPU_ceiling') != 8):
        raise PermissionError('Root-derived release must bind this exact untouched condition and operational grant')
    review_path = HERE / 'launch_review.json'
    if not review_path.is_file() or review_path.is_symlink():
        raise PermissionError('Independent scheduling-only STOP clearance and launch review required')
    review = json.loads(review_path.read_bytes())
    if (review.get('approved') is not True or review.get('reviewer') != '/root/priority_runtime_review' or
            review.get('role') != 'independent_P17_restored_launch_and_STOP_clearance_review' or
            review.get('manifest_sha256') != manifest_sha or review.get('engineering_admission_sha256') != grant_sha or
            review.get('priority_release_sha256') != sha(path) or review.get('root_authorization_sha256') != RESTORE_SHA or
            review.get('new_STOP_sha256') != manifest['new_scheduling_STOP_sha256'] or
            review.get('may_clear_new_scheduling_STOP_only') is not True or
            review.get('one_allocation_only') is not True):
        raise PermissionError('Exact independent new-STOP clearance and sole-launch approval required')
    if (HERE / 'STOP').exists():
        raise PermissionError('The current successor scheduling STOP remains active')
    clearance_path = HERE / 'STOP_clearance_receipt.json'
    if not clearance_path.is_file() or clearance_path.is_symlink():
        raise PermissionError('Durable authorized STOP-clearance receipt required')
    clearance = json.loads(clearance_path.read_bytes())
    if (clearance.get('owner') != OWNER or clearance.get('launch_review_sha256') != sha(review_path) or
            clearance.get('manifest_sha256') != manifest_sha or clearance.get('priority_release_sha256') != sha(path) or
            clearance.get('root_authorization_sha256') != RESTORE_SHA or
            clearance.get('removed_STOP_sha256') != manifest['new_scheduling_STOP_sha256'] or
            clearance.get('legacy_STOPs_preserved') is not True):
        raise PermissionError('STOP clearance is not bound to this exact reviewed restored launch')
    regular(ROOT / '.local/qwen_priority_20261022.json', PRIORITY_SHA)
    return value


def expected_command(args):
    return ['sbatch', '--parsable', str(HERE / 'worker.sbatch'),
        '--plan', str(ORIGINAL / 'plan.json'), '--plan-sha256', PLAN_SHA,
        '--admission', str(ORIGINAL / 'engineering_admission.json'), '--admission-sha256', GRANT_SHA,
        '--resource-amendment', str(HERE / 'manifest.json'),
        '--resource-amendment-sha256', args.resource_amendment_sha256,
        '--resource-admission', str(HERE / 'engineering_admission.json'),
        '--resource-admission-sha256', args.resource_admission_sha256]


def verify_actual_submission(args, manifest):
    """The existing scientific admission separately verifies the original claim."""
    if not os.environ.get('SLURM_JOB_ID'):
        raise PermissionError('A real admitted standalone Slurm job is required')
    proof = load('p17_original_receipt_wait', ORIGINAL / 'submission_v1/admission_validation.py')
    receipt = proof._read_complete_receipt(ORIGINAL / 'submission_v1/submission_receipt.json')
    audit_path = ORIGINAL / 'submission_v1/GPU_audit_at_submission.json'
    sole_path = HERE / 'sole_command.json'
    for path in (audit_path, sole_path, ORIGINAL / 'submission_v1/submission_receipt.json'):
        if not path.is_file() or path.is_symlink() or path != path.resolve():
            raise PermissionError('Exact regular operational submission proof is required')
    audit = json.loads(audit_path.read_bytes())
    sole = json.loads(sole_path.read_bytes())
    if (receipt.get('command') != expected_command(args) or
            receipt.get('job_id') != os.environ['SLURM_JOB_ID'] or
            audit.get('operational_resource_amendment_sha256') != args.resource_amendment_sha256 or
            audit.get('operational_resource_admission_sha256') != args.resource_admission_sha256 or
            audit.get('exact_resource_adapter') != manifest['resource_adapter'] or
            audit.get('shared_resource_binding') != manifest['shared_resource_binding'] or
            audit.get('additional_root_proofs') != manifest['additional_root_proofs'] or
            audit.get('additional_proof_binding') != manifest['additional_proof_binding'] or
            sole.get('command') != expected_command(args) or
            sole.get('GPU_audit_sha256') != sha(audit_path) or
            sole.get('resource_amendment_sha256') != args.resource_amendment_sha256 or
            sole.get('resource_admission_sha256') != args.resource_admission_sha256):
        raise PermissionError('Actual scheduler command must bind the exact admitted operational amendment')


def require_capacity(audit, addition):
    before = audit.get('project_requested_GPUs')
    after = audit.get('project_requested_GPUs_with_addition')
    if (type(before) is not int or type(after) is not int or
            type(audit.get('additional_GPUs')) is not int or
            audit.get('additional_GPUs') != addition or
            before < 0 or after != before + addition or after > 8 or
            audit.get('project_GPU_ceiling') != 8 or audit.get('capacity_available') is not True):
        raise ValueError('Evaluation project GPU requests exceed eight')
    return audit


def audit(args, *, addition, own=False):
    manifest = validate(args, require_job=own, require_release=True)
    adapter = load('p17_exact_shared_resource_adapter', manifest['resource_adapter']['path'])
    # Both boundaries deliberately call this same explicit adapter with identical proof arguments.
    result = adapter.capacity_audit(additional=addition, override=False,
        require_own_job=own, additional_root_proofs=manifest['additional_root_proofs'],
        additional_proof_binding=manifest['additional_proof_binding'])
    require_capacity(result, addition)
    if 'additional_GPUs_reviewed' in result and (type(result['additional_GPUs_reviewed']) is not int or
            result['additional_GPUs_reviewed'] != addition):
        raise ValueError('Contradictory legacy GPU-addition alias is not eligible')
    # The unchanged P17 sole-claim engine expects this explicit compatibility alias.
    # It mirrors the already verified actual shared API field; no count is overridden.
    result.update(additional_GPUs_reviewed=addition,
        operational_resource_amendment_sha256=args.resource_amendment_sha256,
        operational_resource_admission_sha256=args.resource_admission_sha256,
        exact_resource_adapter=manifest['resource_adapter'],
        shared_resource_binding=manifest['shared_resource_binding'])
    if own:
        rows = [row for row in result['jobs'] if row['job_id'] == os.environ.get('SLURM_JOB_ID')]
        if (len(rows) != 1 or type(rows[0]['gpus']) is not int or rows[0]['gpus'] != 1 or
                rows[0]['command'].split()[0] != str(HERE / 'worker.sbatch') or
                Path(rows[0]['workdir']).resolve() != ROOT or
                rows[0].get('counted_toward_evaluation_project') is not True):
            raise PermissionError('Exact own amended one-GPU allocation must remain counted')
    return result


def current_gpu_audit(plan, args):
    site = load('p17_unchanged_site_binding', plan['site_tools_helper'])
    env, _ = site.bind_site_tools(dict(os.environ))
    os.environ['PATH'] = env['PATH']
    return audit(args, addition=0, own=True)
