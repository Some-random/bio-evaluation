"""Disabled-by-default resource-only actuator using the frozen sole-claim engine."""
from pathlib import Path
import argparse, fcntl, json, os, subprocess, sys, time
import resource_contract as resource

HERE = Path(__file__).resolve().parent
ORIGINAL = resource.ORIGINAL
sys.path.insert(0, str(ORIGINAL))
import runner


def arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--admission', type=Path, required=True)
    parser.add_argument('--admission-sha256', required=True)
    parser.add_argument('--resource-amendment', type=Path, required=True)
    parser.add_argument('--resource-amendment-sha256', required=True)
    parser.add_argument('--resource-admission', type=Path, required=True)
    parser.add_argument('--resource-admission-sha256', required=True)
    return parser.parse_args()


def run_exact(args, base, command, **kwargs):
    original_command = ['sbatch', '--parsable', str(ORIGINAL / 'worker.sbatch'),
        '--plan', str(args.plan), '--plan-sha256', args.plan_sha256,
        '--admission', str(args.admission), '--admission-sha256', args.admission_sha256]
    if command != original_command:
        raise PermissionError('Unchanged scientific submission command required before resource rebinding')
    resource.validate(args, require_release=True)
    command[:] = resource.expected_command(args)
    # The original engine records this same mutated list in its native receipt.
    base.write_once(HERE / 'sole_command.json', {
        'at_pacific': runner.now(), 'command': list(command),
        'resource_amendment_sha256': args.resource_amendment_sha256,
        'resource_admission_sha256': args.resource_admission_sha256,
        'GPU_audit_sha256': resource.sha(ORIGINAL / 'submission_v1/GPU_audit_at_submission.json'),
        'no_automatic_retry': True})
    return subprocess.run(command, **kwargs)


def main():
    args = arguments()
    os.umask(0o077)
    resource.validate(args)
    base = resource.load('p17_frozen_capacity_actuator', ORIGINAL / 'submission_v1/wait_capacity.py')
    original_write_once = base.write_once
    def guarded_write_once(path, value):
        # Authority is checked again under the frozen engine's shared locks,
        # immediately before either audit metadata or the irreversible sole claim.
        if Path(path).name in ('GPU_audit_at_submission.json', 'submission_claim.json'):
            resource.validate(args, require_release=True)
        return original_write_once(path, value)
    base.write_once = guarded_write_once
    with (HERE / 'controller.lock').open('a') as own:
        fcntl.flock(own, fcntl.LOCK_EX | fcntl.LOCK_NB)
        # The old and replacement actuators share the same original ownership lock and claims.
        with (ORIGINAL / 'submission_v1/controller.lock').open('a') as predecessor:
            fcntl.flock(predecessor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            while True:
                if (HERE / 'STOP').exists():
                    return
                resource.validate(args, require_release=True)
                def audit_fn(*, additional_gpus):
                    if additional_gpus != 1:
                        raise PermissionError('Only the original single allocation is eligible')
                    return resource.audit(args, addition=1)
                state = base.attempt(args.plan, args.plan_sha256, args.admission,
                    args.admission_sha256, audit_fn=audit_fn,
                    run=lambda command, **kw: run_exact(args, base, command, **kw))
                state.update(at_pacific=runner.now(), pid=os.getpid(),
                    role='resource_amended_P17_capacity_waiter_not_model_delivery')
                runner.save(HERE / 'status.json', state, exclusive=False)
                if not state['stage'].startswith('waiting_'):
                    return
                time.sleep(30)


if __name__ == '__main__':
    main()
