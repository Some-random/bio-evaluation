"""Invented operational-authority fixtures; no model, scheduler or real case reads."""
from pathlib import Path
import importlib.util,json,sys,tempfile,unittest
from types import SimpleNamespace
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import resource_contract as C
spec=importlib.util.spec_from_file_location('p17_restored_waiter',HERE/'wait_capacity.py');W=importlib.util.module_from_spec(spec);spec.loader.exec_module(W)
class RestoreTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.ops=self.root/'ops';self.ops.mkdir();self.original=self.root/'original';(self.original/'submission_v1').mkdir(parents=True)
  self.patches=[patch.object(C,'ROOT',self.root),patch.object(C,'HERE',self.ops),patch.object(C,'regular',lambda *a:None)]
  for p in self.patches:p.start()
  authpath=self.root/'.local/goal_restore_20261024/root_authorization.json';authpath.parent.mkdir(parents=True)
  self.auth={'issuer':'/root','approved':True,'role':'explicit_user_authorized_restoration_of_reviewed_local_GPU_evaluations','owners':{'P17':C.OWNER},'project_GPU_ceiling':8,'restore_already_reviewed_local_lanes':['P17_additional9_16000_variants'],'no_new_cohorts_or_protocols_adopted':True,'unchanged_restrictions':{'no_attempted_or_ambiguous_retries':True,'no_new_paid_inference':True},'independent_review_delegation':{'P17_P19_scalar184':'/root/priority_runtime_review'}}
  self.authpath=authpath;self.write(authpath,self.auth)
  self.m={'root_authorization':{'path':str(authpath),'sha256':C.RESTORE_SHA},'resource_adapter':{'path':str(self.root/'adapter.py'),'sha256':C.ADAPTER_SHA},'additional_root_proofs':[{'path':str(self.root/'proof.json'),'sha256':'a'*64}],'additional_proof_binding':{'path':str(self.root/'proof-binding.json'),'sha256':'b'*64},'shared_resource_binding':{'path':str(self.root/'.local/goal_restore_20261024/shared_resource_binding.json'),'sha256':C.SHARED_SHA},'new_scheduling_STOP_sha256':'c'*64}
  self.binding={'approved':True,'reviewer':'/root/priority_runtime_review','role':'shared_resource_configuration_only_no_dispatch_authority','project_GPU_ceiling':8,**{k:self.m[k] for k in ['root_authorization','resource_adapter','additional_root_proofs','additional_proof_binding']}}
  self.write(Path(self.m['shared_resource_binding']['path']),self.binding)
 def tearDown(self):
  for p in reversed(self.patches):p.stop()
  self.tmp.cleanup()
 def write(self,p,value):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value))
 def release_fixture(self):
  release={'issuer':'/root','prepared_by':C.OWNER,'approved':True,'role':'exact_P17_restored_scheduling_release','root_authorization_sha256':C.RESTORE_SHA,'resource_amendment_sha256':'d'*64,'resource_admission_sha256':'e'*64,'original_plan_sha256':C.PLAN_SHA,'original_engineering_admission_sha256':C.GRANT_SHA,'one_original_P17_allocation_only':True,'scheduling_only':True,'project_GPU_ceiling':8}
  self.write(self.ops/'priority_release.json',release)
  review={'approved':True,'reviewer':'/root/priority_runtime_review','role':'independent_P17_restored_launch_and_STOP_clearance_review','manifest_sha256':'d'*64,'engineering_admission_sha256':'e'*64,'priority_release_sha256':C.sha(self.ops/'priority_release.json'),'root_authorization_sha256':C.RESTORE_SHA,'new_STOP_sha256':'c'*64,'may_clear_new_scheduling_STOP_only':True,'one_allocation_only':True}
  self.write(self.ops/'launch_review.json',review)
  self.write(self.ops/'STOP_clearance_receipt.json',{'owner':C.OWNER,'launch_review_sha256':C.sha(self.ops/'launch_review.json'),'manifest_sha256':'d'*64,'priority_release_sha256':C.sha(self.ops/'priority_release.json'),'root_authorization_sha256':C.RESTORE_SHA,'removed_STOP_sha256':'c'*64,'legacy_STOPs_preserved':True})
 def test_exact_restore_and_binding_pass(self):
  self.assertEqual(C.restoration_authority(self.m)['owners']['P17'],C.OWNER);self.assertEqual(C.shared_binding(self.m)['project_GPU_ceiling'],8)
 def test_wrong_owner_or_untargeted_scope_rejected(self):
  for key,value in [('owners',{'P17':'unrelated'}),('restore_already_reviewed_local_lanes',[])]:
   a=dict(self.auth);a[key]=value;self.write(self.authpath,a)
   with self.assertRaises(PermissionError):C.restoration_authority(self.m)
 def test_changed_adapter_or_external_proof_rejected(self):
  for key,value in [('resource_adapter',{'path':'other','sha256':'0'*64}),('additional_root_proofs',[])]:
   b=dict(self.binding);b[key]=value;self.write(Path(self.m['shared_resource_binding']['path']),b)
   with self.assertRaises(PermissionError):C.shared_binding(self.m)
 def test_full_release_and_clearance_accepts(self):
  self.release_fixture();self.assertTrue(C.validate_priority_release(self.m,'d'*64,'e'*64)['scheduling_only'])
 def test_current_STOP_blocks_even_with_admissions(self):
  self.release_fixture();(self.ops/'STOP').write_text('new hold')
  with self.assertRaises(PermissionError):C.validate_priority_release(self.m,'d'*64,'e'*64)
 def test_missing_independent_clearance_or_receipt_blocks(self):
  self.release_fixture();(self.ops/'launch_review.json').unlink()
  with self.assertRaises(PermissionError):C.validate_priority_release(self.m,'d'*64,'e'*64)
  self.release_fixture();(self.ops/'STOP_clearance_receipt.json').unlink()
  with self.assertRaises(PermissionError):C.validate_priority_release(self.m,'d'*64,'e'*64)
 def test_late_STOP_guard_before_each_metadata_or_claim_write(self):
  for filename in ['GPU_audit_at_submission.json','submission_claim.json']:
   stopped=self.ops/'STOP';stopped.unlink(missing_ok=True);writes=[]
   base=SimpleNamespace(write_once=lambda p,v:writes.append(str(p)))
   def attempt(*a,**kw):
    stopped.write_text('late hold');base.write_once(self.original/'submission_v1'/filename,{});raise AssertionError('claim guard was skipped')
   base.attempt=attempt
   def validate(*a,**kw):
    if stopped.exists():raise PermissionError('current hold')
   args=SimpleNamespace(plan='p',plan_sha256='s',admission='g',admission_sha256='h')
   with patch.object(W,'HERE',self.ops),patch.object(W,'ORIGINAL',self.original),patch.object(W,'arguments',return_value=args),patch.object(C,'validate',side_effect=validate),patch.object(C,'load',return_value=base),patch.object(W.subprocess,'run',side_effect=AssertionError('no scheduler allowed')):
    with self.assertRaises(PermissionError):W.main()
   self.assertEqual(writes,[])
 def test_worker_science_changes_only_new_prebenchmark_authority_gate(self):
  old=(HERE.parent/'additional9_resource_amendment_v2/worker.py').read_text();new=(HERE/'worker.py').read_text();new=new.replace('\n  resource.validate(a,require_job=True,require_release=True)','',1)
  self.assertEqual(old,new)
if __name__=='__main__':unittest.main()
