"""One admitted TP1 condition: neutral3 -> full16000 once -> native score once."""
from pathlib import Path
import argparse,fcntl,importlib.metadata as metadata,importlib.util,json,os,shutil,signal,socket,subprocess,sys,tarfile,tempfile,time,urllib.error,urllib.parse,urllib.request
OPERATIONAL=Path(__file__).resolve().parent
HERE=OPERATIONAL.parent/'additional9_eukaryotic_stability_v3';ROOT=HERE.parents[4]
sys.path.insert(0,str(HERE))
import admission,protocol,runner,scorer_runtime
import resource_contract as resource

def load(name,path,extra=None):
 if extra:sys.path.append(str(extra))
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

def bind_address(endpoint):
 p=urllib.parse.urlsplit(endpoint)
 if p.scheme!='http'or p.hostname!='127.0.0.1'or p.port!=8417 or p.path!='/v1':raise ValueError('Dedicated exact loopback8417 endpoint required')
 return p.hostname,p.port

def main():
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--plan-sha256',required=True);p.add_argument('--admission',type=Path);p.add_argument('--admission-sha256');p.add_argument('--runtime-dir',type=Path);p.add_argument('--check-only',action='store_true');p.add_argument('--resource-amendment',type=Path,required=True);p.add_argument('--resource-amendment-sha256',required=True);p.add_argument('--resource-admission',type=Path,required=True);p.add_argument('--resource-admission-sha256',required=True);a=p.parse_args()
 resource.validate(a,require_job=not a.check_only,require_release=not a.check_only)
 plan=admission.validate(a.plan,a.plan_sha256);bind_address(plan['endpoint'])
 if a.check_only:print(json.dumps({'reviewed_assays':9,'planned_native_variants':16000,'actual_runtime_admission_required':True,'model_calls':0}));return
 admission.validate(a.plan,a.plan_sha256,a.admission,a.admission_sha256,require_job=True)
 runtime=Path(plan['runtime_root']);runtime.mkdir(exist_ok=True)
 shared=load('p17_vetted_private_runtime',plan['vetted_V06_worker'],Path(plan['vetted_V06_worker']).parent);common=shared.common_module(plan)
 if a.runtime_dir is None:
  own=(runtime/'allocation.lock').open('a');fcntl.flock(own,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if(runtime/'allocation_started.json').exists():raise FileExistsError('Never repeat prior allocation or ambiguous attempts')
  runner.save(runtime/'private_GPU_audit_at_start.json',resource.current_gpu_audit(plan,a))
  runner.save(runtime/'allocation_started.json',{'at_pacific':runner.now(),'job_id':os.environ['SLURM_JOB_ID'],'plan_sha256':a.plan_sha256,'admission_sha256':a.admission_sha256})
  runner.save(runtime/'status.json',{'at_pacific':runner.now(),'stage':'verifying_restoring_and_installing_private_runtime','job_id':os.environ['SLURM_JOB_ID'],'role':'runtime_preparation_not_model_dispatch'})
  if shutil.disk_usage('/tmp').free<32*1024**3:raise ValueError('At least32GiB private local scratch required')
  for k in ['base_runtime','cuda_overlay']:
   if protocol.sha(plan[k]['path'])!=plan[k]['sha256']:raise ValueError('Exact runtime archive changed')
  local=Path(tempfile.mkdtemp(prefix='bio-p17-'+os.environ['SLURM_JOB_ID']+'-'))
  with tarfile.open(plan['base_runtime']['path'])as archive:archive.extractall(local,filter='data')
  runner.save(runtime/'archive_receipt.json',common.apply_overlay(local));env=shared.clean_environment(common,local)
  site=admission.load('p17_runtime_site_tools',plan['site_tools_helper']);env,tools=site.bind_site_tools(env);env.update(PYTHONPATH=str(HERE),VLLM_USE_V2_MODEL_RUNNER='0')
  runner.save(runtime/'site_tool_binding.json',tools);shared.install_private_runtime(local/'python/bin/python3.12',env,runtime)
  scorer_site=scorer_runtime.restore(local,plan)
  runner.save(runtime/'CPU_scorer_site.json',{'site':str(scorer_site),'packages':scorer_runtime.PINNED,'installed_into_Qwen_namespace':False})
  cpu=dict(env);cpu['CUDA_VISIBLE_DEVICES']=''
  with(runtime/'installed_API_check.log').open('x')as log:subprocess.run([str(local/'python/bin/python3.12'),str(HERE/'check_installed_API.py'),'--plan',str(a.plan),'--output',str(runtime/'installed_API_check.json')],env=cpu,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
  with(runtime/'CPU_scorer_preflight.log').open('x')as log:subprocess.run([str(local/'python/bin/python3.12'),str(HERE/'check_scorer_runtime.py'),'--site',str(scorer_site),'--output',str(runtime/'CPU_scorer_preflight.json')],env=scorer_runtime.environment(env,scorer_site,HERE),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
  cmd=[str(local/'python/bin/python3.12'),str(Path(__file__).resolve()),*sys.argv[1:],'--runtime-dir',str(local)];os.execve(cmd[0],cmd,env)
 local=a.runtime_dir.resolve()
 if not local.name.startswith('bio-p17-'+os.environ['SLURM_JOB_ID']+'-'):raise PermissionError('Owned private prefix required')
 own=(runtime/'execution.lock').open('a');fcntl.flock(own,fcntl.LOCK_EX|fcntl.LOCK_NB)
 if any((runtime/k).exists()for k in ['development','benchmark','scoring_attempt_started.json','terminal_receipt.json']):raise FileExistsError('Scientific phases cannot be repeated')
 runner.save(runtime/'private_GPU_audit_at_model_start.json',resource.current_gpu_audit(plan,a))
 shared.verify_package_identity({'packages':{k:metadata.version(k)for k in shared.PINNED_PACKAGES}})
 import torch
 if torch.cuda.device_count()!=1:raise PermissionError('Exactly one allocated visible GPU required')
 if torch.cuda.get_device_properties(0).total_memory<78*1024**3:raise PermissionError('At least78GiB GPU memory required by the frozen80GB condition')
 runner.save(runtime/'model_environment.json',{'at_pacific':runner.now(),'packages':{k:metadata.version(k)for k in shared.PINNED_PACKAGES},'dtype':'bfloat16','tensor_parallel_size':1,'visible_device_count':torch.cuda.device_count(),'device_name':torch.cuda.get_device_name(0)})
 model=common.validate_checkpoint(plan['model'],plan['model_revision'])
 if str(model)!=plan['model_directory']:raise ValueError('Pinned original BF16 checkpoint required')
 host,port=bind_address(plan['endpoint'])
 with socket.socket()as probe:probe.bind((host,port))
 server=None
 try:
  cmd=[str(local/'python/bin/python3.12'),'-m','vllm.entrypoints.cli.main','serve',str(model),'--served-model-name',plan['model'],'--host',host,'--port',str(port),'--dtype','bfloat16','--tensor-parallel-size','1','--gpu-memory-utilization','0.95','--max-model-len','65536','--max-num-seqs','16','--max-num-batched-tokens','8192','--reasoning-parser','qwen3','--limit-mm-per-prompt','{"image":0,"video":0}']
  runner.save(runtime/'status.json',{'at_pacific':runner.now(),'stage':'starting_dedicated_Qwen_server','job_id':os.environ['SLURM_JOB_ID']},exclusive=False)
  with(runtime/'server.log').open('x')as log:server=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,cwd=local)
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));deadline=time.monotonic()+1800
  while time.monotonic()<deadline:
   if server.poll()is not None:raise RuntimeError('Own server exited during startup')
   try:
    with opener.open('http://'+host+':'+str(port)+'/health',timeout=3)as response:
     if response.status==200:break
   except(OSError,urllib.error.URLError):time.sleep(3)
  else:raise TimeoutError('Dedicated server readiness failed')
  with opener.open(plan['endpoint']+'/models',timeout=5)as response:models=json.load(response)
  if [r['id']for r in models['data']]!=[plan['model']]:raise ValueError('Actual model identity differs')
  identity={'at_pacific':runner.now(),'pid':server.pid,'proc_start_ticks':common.start_ticks(server.pid),'job_id':os.environ['SLURM_JOB_ID'],'hostname':socket.gethostname(),'plan_sha256':a.plan_sha256,'endpoint':plan['endpoint'],'model':plan['model'],'revision':plan['model_revision']};runner.save(runtime/'server_identity.json',identity)
  def owned():
   if common.start_ticks(server.pid)!=identity['proc_start_ticks']or server.poll()is not None or identity['job_id']!=os.environ['SLURM_JOB_ID']:raise PermissionError('Exact owned server identity changed')
  runner.save(runtime/'status.json',{'at_pacific':runner.now(),'stage':'actual_artificial_three_copy_delivery','planned':3,'job_id':os.environ['SLURM_JOB_ID']},exclusive=False)
  dev=runner.run_phase(plan_sha=a.plan_sha256,endpoint=plan['endpoint'],folder=runtime/'development',phase='development',cases=runner.development_cases(),assert_owned_server=owned,workers=1)
  if dev['artificial_exact_copy_gate_passed']is not True:raise RuntimeError('Actual neutral copy delivery failed; no benchmark dispatch')
  resource.validate(a,require_job=True,require_release=True)
  admission.validate(a.plan,a.plan_sha256,a.admission,a.admission_sha256,require_job=True)
  manifest=json.loads(Path(plan['input_manifest']).read_bytes());cases=[]
  for assay in manifest['assays']:
   with open(assay['input_path'])as f:cases.extend(json.loads(line)for line in f)
  if len(cases)!=16000:raise ValueError('Frozen full9/16000 cohort changed')
  runner.save(runtime/'status.json',{'at_pacific':runner.now(),'stage':'benchmark_generation','planned':16000,'reviewed_assays':9,'job_id':os.environ['SLURM_JOB_ID'],'progress_path':str(runtime/'benchmark/progress.json')},exclusive=False)
  done=runner.run_phase(plan_sha=a.plan_sha256,endpoint=plan['endpoint'],folder=runtime/'benchmark',phase='benchmark',cases=cases,assert_owned_server=owned,workers=8)
  os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=60);runner.save(runtime/'server_terminal.json',{'at_pacific':runner.now(),'own_server_stopped':True})
  admission.validate(a.plan,a.plan_sha256,a.admission,a.admission_sha256,require_job=True)
  runner.save(runtime/'scoring_attempt_started.json',{'at_pacific':runner.now(),'prediction_lock_sha256':done['prediction_lock_sha256'],'sole_attempt':True,'protected_measurements_not_yet_opened':True})
  scorer_site=local/'CPU_scorer_libraries/site-packages'
  with(runtime/'native_scoring.log').open('x')as log:subprocess.run([sys.executable,str(HERE/'scorer.py'),'--plan',str(a.plan),'--run',str(runtime/'benchmark')],env=scorer_runtime.environment(os.environ,scorer_site,HERE),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=7200)
  result=json.loads((runtime/'benchmark/scores.json').read_bytes())
  runner.save(runtime/'terminal_receipt.json',{'at_pacific':runner.now(),'task_id':'P17','job_id':os.environ['SLURM_JOB_ID'],'additional9_condition_terminal':True,'full_native217_complete':False,'planned_native_variants':16000,'prediction_lock_sha256':done['prediction_lock_sha256'],'native_score_sha256':protocol.sha(runtime/'benchmark/scores.json'),'native_scoring_status':result['native_scoring_status'],'primary_native_Spearman':result['primary_native_Spearman']})
  runner.save(runtime/'status.json',{'at_pacific':runner.now(),'stage':'additional9_condition_terminal_native_scoring_attempt_closed','job_id':os.environ['SLURM_JOB_ID'],'native_scoring_status':result['native_scoring_status'],'primary_native_Spearman':result['primary_native_Spearman'],'full_native217_complete':False},exclusive=False)
 except Exception as error:
  runner.save(runtime/'status.json',{'at_pacific':runner.now(),'stage':'stopped_for_review_no_automatic_retry','error_type':type(error).__name__,'error':str(error),'missing_progress_is_not_zero_attempts':True,'job_id':os.environ['SLURM_JOB_ID']},exclusive=False);raise
 finally:
  if server is not None and server.poll()is None:
   os.killpg(server.pid,signal.SIGTERM)
   try:server.wait(timeout=60)
   except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait(timeout=10)
  if not(runtime/'server_terminal.json').exists():runner.save(runtime/'server_terminal.json',{'at_pacific':runner.now(),'own_server_stopped':True,'server_never_started':server is None})
if __name__=='__main__':main()
