| Evaluation | Qwen3.8-27B | GPT models |
| --- | --- | --- |
| PFArena — anchor-informed ranking,reviewed eukaryote stability subset(5/67 assays) | NDCG=0.8891257994265054; NMS@5=0.8706677244393186; Recall@5=0.4; spearman=0.2411394390341758 | Not evaluated |

This subset result does not complete the native67-assay panel or the retained catalog.
