# Protein-property development delivery archive

This disabled CPU-only exporter is bound to the guarded resource-v4 plan
`c60fe0c5277950bd4c3a94b232880a455da247521b98439b58cb53a0cdf00dd4`.
It does not submit jobs, wait for GPUs, run models, load reference values,
calculate correctness scores, launch a watcher, or publish by default.
The additive restore adapter binds the explicit October24 root restoration and the independently admitted once-only allocation. The original scientific plan and generation code remain frozen.

The future condition contains the existing official panels: 16 thermostability,
12 stability and 64 fluorescence inputs for each of Qwen3.5-4B-Base and
Qwen3.5-4B. Both use nonthinking mode, the same finite-number grammar and a
256-token output limit. Delivery counts, distinct finite predictions and numeric
ranges are diagnostics, not benchmark scores.

Assembly requires either all 184 preserved outcomes with six task completions,
two model completions and the exact pair seal, or a separately verified terminal
job failure. An owner closure, fresh terminal scheduler evidence, absent active
allocation, free worker lock, actual request/response hashes, exact issued grant
and real root priority release are checked again. Request files are observations;
unresolved attempts remain unknown. A missing terminal record never means zero
attempts. No failed call is retried.

The separately closed thinking16K Base condition retains 24 thermostability
responses: 13 finite scalars, seven truncations and four stopped nonnumeric
finals. It is archived as an earlier partial condition, not merged with the new
development condition. Its reference-visibility clarification is preserved:
prior audits hashed three reference files as opaque bytes, without inspecting,
printing, scoring or exposing their values to the solver.

The package includes only explicit approved inputs, exact generation/parsing
source, own raw trajectories and narrow protocol/terminal metadata. It excludes
reference bodies, weights, registry payloads, environments, caches, credentials,
private GPU audits, unrelated resource identities and operational log bodies.
Frozen plans may retain path/hash references to excluded local proofs.

`assemble.py` with no arguments only reports read-only readiness. A manual
`--assemble` requires the exact source-freeze path/hash and a different authorized
peer's source-only review path/hash. It does not upload. No watcher is included
or active for this condition.

`publish.py --manifest-sha256 HASH` checks an already assembled package offline.
Its explicit `--publish --review PATH --review-sha256 HASH` additionally requires
a different authorized review of the concrete manifest and every public path.
Before a push, it verifies the exact public repository and push permission,
uses a fresh isolated checkout, checks staged/committed bytes and regular-file
modes, records a durable push intent, then verifies remote commit ancestry and
bytes. An ambiguous attempt is preserved for manual reconciliation, never
silently retried. A source review remains separate from actual concrete-package publication approval.

Run the three `test_*.py` files with `PYTHONDONTWRITEBYTECODE=1`. Tests use
artificial inputs and mocked scheduler/Git interfaces; they make no network,
model, scoring, GPU or queue calls. Source readiness is preparation only.
The two primary reader-facing documents remain owned by root and are untouched.

Terminal preservation independently rechecks the exact root, config, source,
admission and release bytes even if a generation STOP is present. The publisher
has its own local STOP gate, checked before its attempt and again before push.
No generation entrypoint is called by terminal preservation or publication.

Both owner closure and independent assembly require the existing original worker
lock to be a current regular file, opened through anchored no-follow descriptors.
A missing lock rejects preservation readiness instead of skipping the check.
