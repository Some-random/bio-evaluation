"""Write one owner terminal inventory after fresh scheduler/lock checks.

This records immutable raw-file hashes, without parsing inputs, references or
predictions. Independent assembly repeats scheduler, inventory and semantics.
"""
from pathlib import Path
import argparse
import fcntl
import os
import re
import stat
import subprocess

import assemble as a
import bundle_common as c


def close():
    plan, grant, contract, runtime, grant_path, grant_sha, job, release = a.actual_authority()
    run = c.DEV / 'runtime'
    if os.path.lexists(run / 'owner_terminal_closure.json'):
        raise FileExistsError('Preserve original owner terminal closure')
    record = subprocess.check_output(['sacct', '-n', '-P', '-j', job,
        '--format=JobIDRaw,State,ExitCode'], text=True)
    rows = [line.split('|') for line in record.splitlines() if line.split('|')[0] == job]
    if len(rows) != 1 or rows[0][1].split()[0] not in a.TERMINAL_STATES:
        raise ValueError('An exact terminal scheduler record is required')
    if subprocess.check_output(['squeue', '-h', '-j', job, '-o', '%i|%T'], text=True).strip():
        raise ValueError('Allocation remains active')
    lock_path = run / 'worker.lock'
    fd = c.regular_descriptor(lock_path)
    with os.fdopen(fd, 'rb') as lock:
        if not stat.S_ISREG(os.fstat(lock.fileno()).st_mode):
            raise ValueError('Regular original worker lock required')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        inventory = {'requests': [], 'responses': []}
        observed = {kind:set() for kind in inventory}
        for model in ('base', 'posttrained'):
            for task, maximum in c.TASK_COUNTS.items():
                for kind in inventory:
                    folder = run / model / task / kind
                    paths = list(folder.iterdir()) if folder.exists() else []
                    if folder.exists() and (folder.is_symlink() or folder.resolve() != folder):
                        raise ValueError('Canonical raw directory required')
                    if len(paths) > maximum:
                        raise ValueError('Raw inventory exceeds the frozen development denominator')
                    for path in sorted(paths):
                        if not re.fullmatch('[0-9a-f]{64}\\.json', path.name):
                            raise ValueError('Unexpected raw file identity')
                        inventory[kind].append({'path':str(path),'sha256':c.sha(path)})
                        observed[kind].add(path)
        for response in observed['responses']:
            if response.parent.parent / 'requests' / response.name not in observed['requests']:
                raise ValueError('Response without its original once-only claim')
        unresolved = sorted(str(path) for path in observed['requests']
            if path.parent.parent / 'responses' / path.name not in observed['responses'])
        complete = (run / 'pair_completion.json').is_file()
        if complete and (len(observed['requests']) != 184 or len(observed['responses']) != 184 or unresolved):
            raise ValueError('Pair completion cannot replace all184 saved request/response pairs')
        closure = {'at_pacific':c.stamp(),'job_id':job,'plan_sha256':c.PLAN_SHA,
            'grant_sha256':grant_sha,'root_scope_adoption_sha256':c.SCOPE_SHA,
            'operational_config_sha256':c.OP_CONFIG_SHA,'root_authorization_sha256':c.AUTH_SHA,
            'independent_runtime_admission_sha256':c.OP_ADMISSION_SHA,
            'terminal_verified':True,'active_allocation_absent':True,'worker_lock_verified_free':True,
            'scheduler_state':rows[0][1].split()[0],'scheduler_exit_code':rows[0][2],
            **inventory,'unresolved_claims':unresolved}
        if not complete:
            closure.update(terminal_gate_failure=True,
                failure_reason='Terminal allocation lacks the full184 pair seal; all observed attempts preserved without retry.')
        c.write_json(run / 'owner_terminal_closure.json', closure)
    return {'job_id':job,'scheduler_state':closure['scheduler_state'],
        'requests':len(inventory['requests']),'responses':len(inventory['responses']),
        'unresolved_claims':len(unresolved),'pair_completion_present':complete,
        'owner_terminal_closure_sha256':c.sha(run / 'owner_terminal_closure.json')}


if __name__ == '__main__':
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--close', action='store_true', required=True)
    parser.parse_args()
    print(json.dumps(close(), sort_keys=True))
