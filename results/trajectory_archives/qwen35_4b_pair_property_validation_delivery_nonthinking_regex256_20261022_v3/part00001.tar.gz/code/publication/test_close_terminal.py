"""Invented terminal metadata/files only; scheduler and authority are mocked."""
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import bundle_common as c
import close_terminal as t


class ClosureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.dev = Path(self.temp.name)
        self.run = self.dev / 'runtime'
        self.run.mkdir()
        (self.run / 'worker.lock').write_bytes(b'')
        self.patches = [patch.object(c, 'DEV', self.dev),
            patch.object(t.a, 'actual_authority', return_value=({}, {}, {}, None,
                self.dev/'grant.json', c.GRANT_SHA, '123', {}))]
        for item in self.patches: item.start()
    def tearDown(self):
        for item in reversed(self.patches): item.stop()
        self.temp.cleanup()
    def scheduler(self, active=''):
        return patch.object(t.subprocess, 'check_output',
            side_effect=lambda argv, **kw:'123|FAILED|1:0|\n' if argv[0]=='sacct' else active)
    def test_terminal_partial_keeps_hashes_and_unresolved_claims(self):
        request = self.run / 'base/P06/requests' / ('a'*64+'.json')
        c.write_json(request, {'invented':'scalar request'})
        with self.scheduler(): result = t.close()
        closure = c.read(self.run/'owner_terminal_closure.json')
        self.assertEqual(result['requests'], 1)
        self.assertEqual(result['responses'], 0)
        self.assertEqual(closure['unresolved_claims'], [str(request)])
        self.assertEqual(closure['requests'], [{'path':str(request),'sha256':c.sha(request)}])
        self.assertTrue(closure['terminal_gate_failure'])
        self.assertEqual(closure['operational_config_sha256'], c.OP_CONFIG_SHA)
        with self.scheduler(), self.assertRaises(FileExistsError): t.close()
    def test_active_or_locked_worker_rejects_before_closure(self):
        with self.scheduler('123|RUNNING\n'), self.assertRaises(ValueError): t.close()
        self.assertFalse((self.run/'owner_terminal_closure.json').exists())
        import fcntl
        with (self.run/'worker.lock').open() as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with self.scheduler(), self.assertRaises(BlockingIOError): t.close()
        self.assertFalse((self.run/'owner_terminal_closure.json').exists())
    def test_pair_marker_without184_cannot_close(self):
        c.write_json(self.run/'pair_completion.json', {'invented':True})
        with self.scheduler(), self.assertRaisesRegex(ValueError, 'all184'): t.close()
        self.assertFalse((self.run/'owner_terminal_closure.json').exists())


if __name__ == '__main__': unittest.main()
