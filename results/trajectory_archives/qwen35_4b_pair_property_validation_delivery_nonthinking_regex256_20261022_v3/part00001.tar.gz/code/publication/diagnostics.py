"""Delivery-only diagnostics: never load targets or calculate correctness."""
from collections import Counter
import math

TASK_COUNTS = {'P06': 16, 'P08': 12, 'P07': 64}
MODELS = ('base', 'posttrained')
CONDITION = 'QWEN35_MATCHED_NONTHINKING_REGEX256_OFFICIAL_VALIDATION_DELIVERY_20261022_V3'
NORMALIZED_FIELDS = frozenset({'raw_text', 'token_ids', 'finish_reason', 'stop_reason',
    'final', 'prediction', 'format_errors', 'truncated', 'empty_final',
    'completion_tokens', 'reasoning_expected'})
RESPONSE_FIELDS = NORMALIZED_FIELDS | {'at_pacific', 'case_id', 'task_id',
    'model_key', 'plan_sha256', 'request_file_sha256'}


def distribution(values):
    if any(isinstance(value, bool) or not isinstance(value, (int, float))
           or not math.isfinite(value) for value in values):
        raise ValueError('Numeric delivery diagnostics require finite saved scalars')
    return {'finite_count': len(values), 'distinct_values': len(set(values)),
            'minimum': min(values) if values else None,
            'maximum': max(values) if values else None,
            'biological_correctness_assessed': False}


def validate_response(row, *, task_id, model_key, plan_sha256, case_id,
                      request_sha256, normalize, parser):
    if set(row) != RESPONSE_FIELDS:
        raise ValueError('Unexpected development response schema')
    if (row['task_id'] != task_id or row['model_key'] != model_key
            or row['plan_sha256'] != plan_sha256 or row['case_id'] != case_id
            or row['request_file_sha256'] != request_sha256):
        raise ValueError('Development response no longer binds its exact saved request')
    if (not isinstance(row['raw_text'], str) or not isinstance(row['token_ids'], list)
            or any(isinstance(token, bool) or not isinstance(token, int) or token < 0
                   for token in row['token_ids'])):
        raise ValueError('Raw generated text and integer token IDs must remain available')
    derived = normalize(row['raw_text'], row['token_ids'], row['finish_reason'],
                        row['stop_reason'], parser)
    if {key: row[key] for key in NORMALIZED_FIELDS} != derived:
        raise ValueError('Saved final/diagnostic fields differ from frozen raw normalization')
    return derived


def summarize_task(task_id, responses, *, request_files, terminal_closure,
                   task_complete):
    planned = TASK_COUNTS[task_id]
    if len(set(request_files)) != len(request_files):
        raise ValueError('Duplicate request observations')
    cases = [row['case_id'] for row in responses]
    if len(set(cases)) != len(cases):
        raise ValueError('Duplicate or excessive saved development cases')
    if len(cases) > len(request_files) or len(request_files) > planned:
        raise ValueError('Outcome/request coverage exceeds the fixed development cohort')
    if task_complete and (len(cases) != planned or len(request_files) != planned):
        raise ValueError('Task completion cannot replace missing raw outcomes')
    counts = Counter({'saved_responses_verified': len(responses),
                      'native_finite_scalars': 0, 'truncations': 0,
                      'empty_finals': 0, 'format_error_records': 0})
    values = []
    for row in responses:
        counts['truncations'] += bool(row['truncated'])
        counts['empty_finals'] += bool(row['empty_final'])
        counts['format_error_records'] += bool(row['format_errors'])
        if row['prediction'] is not None:
            if row['format_errors'] or row['finish_reason'] != 'stop':
                raise ValueError('Invalid response cannot be counted as scalar delivery')
            values.append(row['prediction'])
            counts['native_finite_scalars'] += 1
    return {'task_id': task_id, 'planned_development_cases': planned,
            'request_files_observed': len(request_files),
            **dict(counts), 'claimed_files_without_verified_response': len(request_files)-len(cases),
            'request_creation_or_dispatch_count': None,
            'dispatch_count_note': 'Request filenames and missing progress are not model-call counts.',
            'count_scope': 'terminal preserved artifacts' if terminal_closure else 'unsealed lower bounds',
            'task_complete': bool(task_complete), 'biological_correctness_assessed': False,
            'benchmark_score': False, 'numeric_delivery_distribution': distribution(values)}


def pair_summary(models, *, pair_completion_verified, terminal_failure_verified):
    if pair_completion_verified and terminal_failure_verified:
        raise ValueError('A package cannot be both complete184 and a terminal partial failure')
    if not pair_completion_verified and not terminal_failure_verified:
        raise ValueError('No archive before complete184 or an exact terminal failure closure')
    if set(models) != set(MODELS):
        raise ValueError('Both model lanes need explicit records, including unattempted/unknown lanes')
    saved = 0
    for model in MODELS:
        if [row['task_id'] for row in models[model]] != list(TASK_COUNTS):
            raise ValueError('The three fixed development tasks must remain explicit and ordered')
        for row in models[model]:
            saved += row['saved_responses_verified']
            if row.get('benchmark_score') is not False or row.get('biological_correctness_assessed') is not False:
                raise ValueError('Delivery checks do not become correctness scores')
            if pair_completion_verified and not row['task_complete']:
                raise ValueError('Complete184 requires all six complete raw-artifact cohorts')
    if pair_completion_verified and saved != 184:
        raise ValueError('Missing outcomes cannot be counted as complete184')
    return {'condition': CONDITION, 'planned_development_outcomes': 184,
            'saved_development_outcomes_verified': saved,
            'development_pair_complete': bool(pair_completion_verified),
            'terminal_partial_failure': bool(terminal_failure_verified),
            'benchmark_score': False, 'biological_correctness_assessed': False,
            'models': models}
