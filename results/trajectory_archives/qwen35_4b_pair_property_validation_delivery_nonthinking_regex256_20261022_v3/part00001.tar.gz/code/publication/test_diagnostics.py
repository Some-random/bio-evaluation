"""Artificial examples only; delivery coverage never becomes a benchmark score."""
import copy
import math
import unittest
import diagnostics as d


def response(index, *, valid=True):
    return {'case_id': 'fixture-' + str(index), 'prediction': float(index) if valid else None,
            'format_errors': [] if valid else ['not_normally_stopped'],
            'finish_reason': 'stop' if valid else 'length',
            'truncated': not valid, 'empty_final': not valid}


def task(task_id, n=None, *, complete=True):
    n = d.TASK_COUNTS[task_id] if n is None else n
    return d.summarize_task(task_id, [response(i) for i in range(n)],
            request_files=['fixture-' + str(i) for i in range(n)],
            terminal_closure=True, task_complete=complete)


class DiagnosticsTests(unittest.TestCase):
    def test_raw_normalization_and_request_binding_are_recomputed(self):
        normalized = {'raw_text': '3.5<|im_end|>', 'token_ids': [12, 248046],
            'finish_reason': 'stop', 'stop_reason': 248046, 'final': '3.5',
            'prediction': 3.5, 'format_errors': [], 'truncated': False,
            'empty_final': False, 'completion_tokens': 2, 'reasoning_expected': False}
        row = {**normalized, 'at_pacific': 'artificial-only', 'case_id': 'fixture-0',
               'task_id': 'P06', 'model_key': 'base', 'plan_sha256': 'fixture-plan',
               'request_file_sha256': 'fixture-request'}
        args = {'task_id': 'P06', 'model_key': 'base', 'plan_sha256': 'fixture-plan',
                'case_id': 'fixture-0', 'request_sha256': 'fixture-request',
                'normalize': lambda *unused: normalized, 'parser': lambda text: 3.5}
        self.assertEqual(d.validate_response(row, **args), normalized)
        for key, value in [('final', '25'), ('request_file_sha256', 'changed'),
                           ('model_key', 'posttrained'), ('token_ids', [-1]),
                           ('unexpected_provider_field', 'never export')]:
            with self.subTest(key=key):
                changed = {**row, key: value}
                with self.assertRaises(ValueError):
                    d.validate_response(changed, **args)

    def test_complete184_never_claims_correctness(self):
        models = {model: [task(t) for t in d.TASK_COUNTS] for model in d.MODELS}
        result = d.pair_summary(models, pair_completion_verified=True, terminal_failure_verified=False)
        self.assertEqual(result['saved_development_outcomes_verified'], 184)
        self.assertTrue(result['development_pair_complete'])
        self.assertFalse(result['benchmark_score'])
        self.assertFalse(result['biological_correctness_assessed'])

    def test_empty_terminal_failure_keeps_model_attempts_unknown(self):
        models = {model: [task(t, 0, complete=False) for t in d.TASK_COUNTS] for model in d.MODELS}
        result = d.pair_summary(models, pair_completion_verified=False, terminal_failure_verified=True)
        self.assertFalse(result['development_pair_complete'])
        self.assertTrue(result['terminal_partial_failure'])
        self.assertIsNone(models['base'][0]['request_creation_or_dispatch_count'])
        self.assertIsNone(models['base'][0]['numeric_delivery_distribution']['minimum'])

    def test_incomplete_or_ambiguous_artifacts_do_not_trigger_archiving(self):
        with self.assertRaises(ValueError):
            d.pair_summary({}, pair_completion_verified=False, terminal_failure_verified=False)
        with self.assertRaises(ValueError):
            d.pair_summary({}, pair_completion_verified=True, terminal_failure_verified=True)

    def test_fabricated_pair_completion_cannot_replace_missing_cases(self):
        models = {model: [task(t) for t in d.TASK_COUNTS] for model in d.MODELS}
        models['base'][0] = task('P06', 8, complete=False)
        with self.assertRaises(ValueError):
            d.pair_summary(models, pair_completion_verified=True, terminal_failure_verified=False)

    def test_pending_claims_are_preserved_and_not_called_responses(self):
        row = d.summarize_task('P06', [response(0), response(1, valid=False)],
              request_files=['a', 'b', 'c'], terminal_closure=True, task_complete=False)
        self.assertEqual(row['saved_responses_verified'], 2)
        self.assertEqual(row['claimed_files_without_verified_response'], 1)
        self.assertEqual(row['native_finite_scalars'], 1)
        self.assertEqual(row['truncations'], 1)
        self.assertIsNone(row['request_creation_or_dispatch_count'])

    def test_duplicate_or_excessive_cases_fail(self):
        for rows, requests in [([response(0), response(0)], ['a', 'b']),
                               ([response(0)], ['a', 'a']),
                               ([response(0), response(1)], ['a']),
                               ([], [str(i) for i in range(17)])]:
            with self.subTest(rows=len(rows), requests=len(requests)):
                with self.assertRaises(ValueError):
                    d.summarize_task('P06', rows, request_files=requests,
                                     terminal_closure=True, task_complete=False)

    def test_invalid_finals_never_supply_numeric_ranges(self):
        row = response(0, valid=False)
        row['prediction'] = 10.0
        with self.assertRaises(ValueError):
            d.summarize_task('P06', [row], request_files=['a'],
                            terminal_closure=True, task_complete=False)

    def test_nonfinite_or_boolean_diagnostics_are_rejected(self):
        for value in [math.nan, math.inf, -math.inf, True, '3']:
            with self.subTest(value=str(value)):
                with self.assertRaises(ValueError):
                    d.distribution([value])
        self.assertEqual(d.distribution([2.0, -3.0, 2.0])['distinct_values'], 2)

    def test_benchmark_score_flag_or_missing_model_is_rejected(self):
        models = {model: [task(t) for t in d.TASK_COUNTS] for model in d.MODELS}
        changed = copy.deepcopy(models)
        changed['base'][0]['benchmark_score'] = True
        with self.assertRaises(ValueError):
            d.pair_summary(changed, pair_completion_verified=True, terminal_failure_verified=False)
        del models['posttrained']
        with self.assertRaises(ValueError):
            d.pair_summary(models, pair_completion_verified=True, terminal_failure_verified=False)


if __name__ == '__main__':
    unittest.main(verbosity=2)
