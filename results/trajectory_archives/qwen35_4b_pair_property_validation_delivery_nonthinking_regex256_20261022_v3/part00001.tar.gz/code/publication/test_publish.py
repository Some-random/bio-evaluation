"""Artificial publication-boundary tests; no live Git, API or network operations."""
from pathlib import Path
import io
import tempfile
import types
import unittest
from unittest.mock import patch

import assemble
import bundle_common as c
import publish as p


class PublisherTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
    def tearDown(self): self.temp.cleanup()
    def review(self, manifest_sha='a'*64):
        return {'reviewer':'/root/independent_review','approved':True,'pair_id':c.PAIR_ID,
            'manifest_sha256':manifest_sha,'plan_sha256':c.PLAN_SHA,'repository':c.REPOSITORY,
            'visibility':'public','paths_sha256':{c.PREFIX+'delivery_diagnostics.json':'b'*64},
            'secret_archive_scans_verified':True,'exclusions_verified':True,'development_scope_only':True,
            'benchmark_score':False,'biological_correctness_assessed':False,
            'prior_Base24_separate_condition_verified':True, 'operational_config_sha256':c.OP_CONFIG_SHA,
            'root_authorization_sha256':c.AUTH_SHA}

    def test_no_concrete_review_cannot_load_git_helper_or_start_attempt(self):
        with patch.object(c,'HERE',self.root), patch.object(assemble,'check',return_value={'files_sha256':{}}), \
             patch.object(c,'load',side_effect=AssertionError('No network helper')), self.assertRaises(PermissionError):
            p.publish('a'*64,None,None)
        self.assertFalse((self.root/'attempt_started.json').exists())

    def test_source_readiness_review_is_not_concrete_upload_approval(self):
        path=self.root/'review.json'; path.write_bytes(c.json_bytes({'approved':True,'publishing_authorized':False}))
        with self.assertRaises(PermissionError):
            p.validate_review(path,c.sha(path),{'files_sha256':{}},'a'*64)

    def test_exact_scope_and_independent_manifest_bytes_are_required(self):
        review=self.review(); manifest={'files_sha256':review['paths_sha256']}; path=self.root/'review.json'
        path.write_bytes(c.json_bytes(review)); p.validate_review(path,c.sha(path),manifest,'a'*64)
        for change in ({'reviewer':c.EXPORT_AUTHOR},{'reviewer':'/root/qwen35_protein_properties'},
                       {'plan_sha256':'c'*64},{'manifest_sha256':'c'*64},{'paths_sha256':{}},
                       {'benchmark_score':True},{'development_scope_only':False},
                       {'prior_Base24_separate_condition_verified':False},{'exclusions_verified':False},
                       {'secret_archive_scans_verified':False},{'repository':'Other/Repository'}):
            path.write_bytes(c.json_bytes({**review,**change}))
            with self.subTest(change=change),self.assertRaises(PermissionError):
                p.validate_review(path,c.sha(path),manifest,'a'*64)

    def test_existing_or_dangling_attempt_prevents_ambiguous_retry(self):
        with patch.object(c,'HERE',self.root):
            for name in ('publication_receipt.json','attempt_started.json','push_intent.json'):
                path=self.root/name; path.symlink_to(self.root/'missing')
                with self.subTest(name=name),self.assertRaises(FileExistsError):p.no_prior_attempt()
                path.unlink()

    def test_publication_stop_blocks_before_attempt(self):
        with patch.object(c,'HERE',self.root):
            (self.root/'STOP').write_text('invented publication stop')
            with self.assertRaises(PermissionError): p.no_prior_attempt()
            self.assertFalse((self.root/'attempt_started.json').exists())

    def test_actual_exact_public_destination_and_push_permission_are_required(self):
        called=[]
        helper=types.SimpleNamespace(URL='https://example.invalid',REPOSITORY=c.REPOSITORY,
            confirm_destination=lambda:called.append(True))
        with self.assertRaises(ValueError):p.confirm_destination(helper)
        self.assertFalse(called)
        helper.URL=c.URL
        for row in ({'repository':c.REPOSITORY,'visibility':'public','push_permission':False},
                    {'repository':c.REPOSITORY,'visibility':'private','push_permission':True},
                    {'repository':'Other/Repo','visibility':'public','push_permission':True}):
            helper.confirm_destination=lambda:row
            with self.subTest(row=row),self.assertRaises(ValueError):p.confirm_destination(helper)

    def test_pinned_helpers_and_clean_git_environment(self):
        with self.assertRaises(ValueError):p.verify_helpers({'support_sha256':{}})
        with patch.object(c,'sha',return_value='0'*64),self.assertRaises(ValueError):
            p.verify_helpers({'support_sha256':assemble.PINNED_HELPERS})
        env=p.git_environment({'GIT_SSH_COMMAND':'bad','GIT_CONFIG_COUNT':'99','PATH':'/usr/bin','HTTP_PROXY':'artificial'})
        self.assertNotIn('GIT_SSH_COMMAND',env);self.assertNotIn('GIT_CONFIG_COUNT',env)
        self.assertEqual(env['HTTP_PROXY'],'artificial');self.assertEqual(env['GIT_CONFIG_GLOBAL'],'/dev/null')

    def test_bounded_stream_hash_and_invalid_commit_rejected(self):
        body=b'artificial blob\n'*100000; sizes=[]
        class Pipe(io.BytesIO):
            def read(self,size=-1):
                sizes.append(size)
                if not 0<size<=1024**2:raise AssertionError('Unbounded blob read')
                return super().read(size)
        proc=types.SimpleNamespace(stdout=Pipe(body),stderr=io.BytesIO(),wait=lambda:0)
        with patch.object(p.subprocess,'Popen',return_value=proc):
            self.assertEqual(p.git_blob_sha(self.root,':artificial'),c.digest(body))
        self.assertGreater(len(sizes),1)
        for text in ('','short','a'*39,'a'*41,'a'*40+'\n'+'b'*40):
            with self.subTest(text=text),self.assertRaises(ValueError):p.commit_sha(text)

    def test_staged_symlink_wrong_mode_duplicate_missing_or_changed_bytes_rejected(self):
        files={c.PREFIX+'delivery_diagnostics.json':'b'*64};name=next(iter(files));oid='a'*40
        def check(value):
            git=lambda *args:types.SimpleNamespace(stdout=value)
            with patch.object(p,'git_blob_sha',return_value='b'*64):p.verify_index(git,self.root,files)
        check(f'100644 {oid} 0\t{name}\0')
        for value in ('',f'120000 {oid} 0\t{name}\0',f'100644 {oid} 1\t{name}\0',
                      f'100644 {oid} 0\t{name}\0'*2):
            with self.subTest(value=value),self.assertRaises(ValueError):check(value)
        git=lambda *args:types.SimpleNamespace(stdout=f'100644 {oid} 0\t{name}\0')
        with patch.object(p,'git_blob_sha',return_value='c'*64),self.assertRaises(ValueError):
            p.verify_index(git,self.root,files)

    def test_committed_tree_requires_regular_exact_public_bytes(self):
        name=c.PREFIX+'delivery_diagnostics.json';files={name:'b'*64};oid='a'*40
        for value in (f'120000 blob {oid}\t{name}\0',f'100644 tree {oid}\t{name}\0',''):
            git=lambda *args:types.SimpleNamespace(stdout=value)
            with self.subTest(value=value),self.assertRaises(ValueError):p.verify_tree(git,self.root,oid,files)
        git=lambda *args:types.SimpleNamespace(stdout=f'100644 blob {oid}\t{name}\0')
        with patch.object(p,'git_blob_sha',return_value='b'*64):p.verify_tree(git,self.root,oid,files)

    def test_checkout_write_cannot_follow_parent_or_leaf_symlink(self):
        outside=self.root/'outside';outside.mkdir();checkout=self.root/'checkout';checkout.mkdir()
        (checkout/'results').symlink_to(outside)
        with self.assertRaises(OSError):c.write_checkout_file(checkout,'results/file',b'artificial')
        self.assertEqual(list(outside.iterdir()),[])
        (checkout/'results').unlink();(checkout/'results').mkdir();(checkout/'results/file').symlink_to(outside/'file')
        with self.assertRaises(OSError):c.write_checkout_file(checkout,'results/file',b'artificial')

    def test_offline_default_never_calls_publish_or_network(self):
        with patch.object(assemble,'check',return_value={'files_sha256':{'artificial':'a'*64}}), \
             patch.object(p,'publish',side_effect=AssertionError('No publishing')), \
             patch.object(c,'load',side_effect=AssertionError('No network helper')),patch('sys.stdout',new=io.StringIO()) as out:
            p.main(['--manifest-sha256','a'*64])
        self.assertIn('"published": false',out.getvalue())


if __name__=='__main__':unittest.main(verbosity=2)
