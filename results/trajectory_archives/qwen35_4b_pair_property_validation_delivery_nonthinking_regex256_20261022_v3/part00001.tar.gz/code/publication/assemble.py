"""Offline development/raw preservation archive; no inference, scoring or upload."""
from pathlib import Path
import argparse
import fcntl
import gzip
import io
import json
import os
import re
import stat
import subprocess
import tarfile

import bundle_common as c
import diagnostics as d

PINNED_HELPERS = {
    str(c.SCANNER): '528735e220dd6a2b5ab3d5b6b51ec7143b5ffa891fdfcfc211d2a8099ce7093d',
    str(c.GIT_HELPER): '194f143fa81d2409c3f72403c5664f7f9c64b9ca3cc46af9603de0d044cf0160',
    str(c.CREDENTIAL_HELPER): '45a94c6e738c987277f252bb5177e0d1b7b35ce8ea17d438b358f802442192cb',
    str(c.DESTINATION_POLICY): '7af9309f3b860b69301abae590a6c9ac4f03c1d81a6b3269b86fc077b6a10f4a',
    str(c.ROOT / 'configs/publication_destination.json'): '7e3e1cac0321a64aa9bd53daf0e47891f7ca0ce04d3df9c3764d99129f1680d0',
}
TERMINAL_STATES = frozenset(('COMPLETED', 'FAILED', 'CANCELLED', 'TIMEOUT',
    'OUT_OF_MEMORY', 'NODE_FAIL', 'PREEMPTED', 'BOOT_FAIL', 'DEADLINE', 'REVOKED'))
PUBLICATION_SOURCES = ('bundle_common.py', 'diagnostics.py', 'assemble.py', 'publish.py',
                       'test_diagnostics.py', 'test_assemble.py', 'test_publish.py', 'close_terminal.py', 'test_close_terminal.py', 'README.md')


def require_hash(path, digest):
    if c.sha(path) != digest:
        raise ValueError('Exact frozen bytes changed: ' + Path(path).name)


def readiness():
    path = c.DEV / 'runtime/owner_terminal_closure.json'
    return {'at_pacific': c.stamp(), 'role': 'development_archive_readiness_not_dispatch',
            'actual_terminal_closure_present': path.is_file(),
            'runtime_counts': None, 'missing_counts_are_unknown': True,
            'model_calls': 0, 'scoring_attempts': 0, 'published': False}


def verify_freeze(path, digest):
    require_hash(path, digest)
    frozen = c.read(path)
    if (frozen.get('role') != 'exact_development_publication_source_freeze'
            or frozen.get('pair_id') != c.PAIR_ID or frozen.get('plan_sha256') != c.PLAN_SHA
            or frozen.get('scope_sha256') != c.SCOPE_SHA
            or frozen.get('operational_config_sha256') != c.OP_CONFIG_SHA
            or frozen.get('root_authorization_sha256') != c.AUTH_SHA):
        raise ValueError('Exact source freeze for this development condition required')
    for name in PUBLICATION_SOURCES:
        if str(c.HERE / name) not in frozen['files_sha256']:
            raise ValueError('Every publisher/exporter/test source must be frozen')
    for name, expected in {**PINNED_HELPERS, **frozen['files_sha256']}.items():
        require_hash(name, expected)
    return frozen


def source_review(path, digest, freeze_sha):
    require_hash(path, digest)
    row = c.read(path)
    if (row.get('approved') is not True or row.get('reviewer') == c.EXPORT_AUTHOR
            or row.get('reviewer') not in ('/root', '/root/independent_review', '/root/new2026_bixbench', '/root/priority_runtime_review')
            or row.get('source_freeze_sha256') != freeze_sha
            or row.get('plan_sha256') != c.PLAN_SHA or row.get('pair_id') != c.PAIR_ID
            or row.get('publishing_authorized') is not False
            or row.get('operational_config_sha256') != c.OP_CONFIG_SHA
            or row.get('root_authorization_sha256') != c.AUTH_SHA):
        raise ValueError('Different authorized peer must review exact disabled sources/configuration')
    return row


def closed_operational_authority(operational):
    """Recheck immutable authority for preservation, independent of generation STOP."""
    require_hash(c.OP_CONFIG, c.OP_CONFIG_SHA)
    config = c.read(c.OP_CONFIG)
    for path, expected in config['source_sha256'].items():
        require_hash(path, expected)
    shared_pin = config['shared_resource_binding']
    require_hash(shared_pin['path'], shared_pin['sha256'])
    shared = c.read(shared_pin['path'])
    for key in ('resource_adapter', 'additional_root_proofs', 'additional_proof_binding',
                'root_authorization', 'project_GPU_ceiling'):
        if config.get(key) != shared.get(key):
            raise ValueError('Closed lineage differs from exact shared resource authority')
    authority_pin = config['root_authorization']
    if authority_pin['sha256'] != c.AUTH_SHA:
        raise ValueError('Exact later restoration authority is required')
    require_hash(authority_pin['path'], c.AUTH_SHA)
    admission_path = c.HERE.parent / 'independent_runtime_admission.json'
    require_hash(admission_path, c.OP_ADMISSION_SHA)
    operational.check_authority(config, c.read(authority_pin['path']), c.read(admission_path), c.OP_CONFIG_SHA)
    release_pin = config['priority_release']
    require_hash(release_pin['path'], release_pin['sha256'])
    operational.check_release(c.read(release_pin['path']))
    config['_admission_sha256'] = c.OP_ADMISSION_SHA
    return config


def actual_authority():
    """Bind the once-only restored allocation; never call a dispatch entrypoint."""
    for path, digest in ((c.PLAN, c.PLAN_SHA), (c.EXECUTE, c.EXECUTE_SHA),
                         (c.SCOPE, c.SCOPE_SHA), (c.FINAL_PACKET, c.FINAL_PACKET_SHA),
                         (c.OP_CONFIG, c.OP_CONFIG_SHA), (c.OP_RESTORE, c.OP_RESTORE_SHA)):
        require_hash(path, digest)
    run = c.DEV / 'runtime'
    attempt, submitted = [c.read(run / name) for name in ('submission_attempt.json', 'submission.json')]
    attempt_fields = {'at_epoch', 'command', 'operational_config_sha256', 'old_plan_sha256',
        'old_grant_sha256', 'root_authorization_sha256', 'independent_runtime_admission_sha256', 'automatic_retry'}
    receipt_fields = {'at_epoch', 'job_id', 'plan_sha256', 'grant_sha256', 'operational_config_sha256',
        'root_authorization_sha256', 'requested_GPUs', 'automatic_retry',
        'independent_runtime_admission_sha256', 'returncode', 'stdout', 'stderr'}
    expected = {'plan_sha256': c.PLAN_SHA, 'grant_sha256': c.GRANT_SHA,
        'operational_config_sha256': c.OP_CONFIG_SHA, 'root_authorization_sha256': c.AUTH_SHA}
    if (set(attempt) != attempt_fields or set(submitted) != receipt_fields
            or any(submitted.get(k) != v for k, v in expected.items())
            or attempt.get('old_plan_sha256') != c.PLAN_SHA or attempt.get('old_grant_sha256') != c.GRANT_SHA
            or attempt.get('operational_config_sha256') != c.OP_CONFIG_SHA
            or attempt.get('root_authorization_sha256') != c.AUTH_SHA
            or attempt.get('automatic_retry') is not False or submitted.get('automatic_retry') is not False
            or submitted.get('requested_GPUs') != 1 or submitted.get('returncode') != 0
            or submitted.get('stderr') != ''):
        raise ValueError('Unexpected restored submission metadata schema or authority')
    if attempt.get('command') != ['sbatch', '--parsable', '--export=NONE', str(c.OP_WORKER), c.OP_CONFIG_SHA]:
        raise ValueError('Exact once-only restored worker command required')
    job = submitted.get('job_id')
    if (not isinstance(job, str) or not job.isdigit() or int(job) <= 0
            or not re.fullmatch(re.escape(job) + r'(?:;[A-Za-z0-9_.-]+)?', submitted.get('stdout', ''))):
        raise ValueError('An actual allocation identity is required; preparation is not dispatch')
    operational = c.load('scalar184_publication_read_only_authority', c.OP_RESTORE)
    config = closed_operational_authority(operational)
    admission_sha = config['_admission_sha256']
    if (admission_sha != c.OP_ADMISSION_SHA
            or submitted.get('independent_runtime_admission_sha256') != admission_sha
            or attempt.get('independent_runtime_admission_sha256') != admission_sha):
        raise ValueError('Actual independent admission changed after once-only submission')
    runtime, plan, grant, common, contract = operational.old_science(config)
    grant_path = Path(config['old_grant'])
    release = config['priority_release']
    if (run / 'started.json').is_file():
        started = c.read(run / 'started.json')
        if (set(started) != {'at_epoch', 'job_id', 'plan_sha256', 'grant_sha256',
                'operational_config_sha256', 'independent_runtime_admission_sha256', 'root_authorization_sha256'}
                or started.get('job_id') != job or any(started.get(k) != v for k, v in expected.items())
                or started.get('independent_runtime_admission_sha256') != admission_sha):
            raise ValueError('Actual restored worker start no longer binds submission authority')
    return plan, grant, contract, runtime, grant_path, c.GRANT_SHA, job, release


def terminal_inventory(plan, grant_sha, job):
    """An owner terminal proof plus fresh independent scheduler/lock evidence."""
    run = c.DEV / 'runtime'
    path = run / 'owner_terminal_closure.json'
    proof = c.read(path)
    required = {'at_pacific', 'job_id', 'plan_sha256', 'grant_sha256',
        'root_scope_adoption_sha256', 'terminal_verified', 'active_allocation_absent',
        'worker_lock_verified_free', 'scheduler_state', 'scheduler_exit_code',
        'requests', 'responses', 'unresolved_claims', 'operational_config_sha256',
        'root_authorization_sha256', 'independent_runtime_admission_sha256'}
    if not required <= set(proof) or not set(proof) <= required | {'terminal_gate_failure', 'failure_reason'}:
        raise ValueError('Only exact terminal preservation metadata may be exported')
    if (proof.get('job_id') != job or proof.get('plan_sha256') != c.PLAN_SHA
            or proof.get('grant_sha256') != grant_sha
            or proof.get('root_scope_adoption_sha256') != c.SCOPE_SHA
            or proof.get('operational_config_sha256') != c.OP_CONFIG_SHA
            or proof.get('root_authorization_sha256') != c.AUTH_SHA
            or proof.get('independent_runtime_admission_sha256') != c.OP_ADMISSION_SHA
            or proof.get('terminal_verified') is not True
            or proof.get('active_allocation_absent') is not True
            or proof.get('worker_lock_verified_free') is not True):
        raise ValueError('Exact actual development owner terminal closure is required')
    record = subprocess.check_output(['sacct', '-n', '-P', '-j', job,
                                     '--format=JobIDRaw,State,ExitCode'], text=True)
    rows = [line.split('|') for line in record.splitlines() if line.split('|')[0] == job]
    if (len(rows) != 1 or rows[0][1].split()[0] not in TERMINAL_STATES
            or rows[0][1].split()[0] != proof.get('scheduler_state')
            or rows[0][2] != proof.get('scheduler_exit_code')):
        raise ValueError('Fresh scheduler state differs from the exact terminal closure')
    if subprocess.check_output(['squeue', '-h', '-j', job, '-o', '%i|%T'], text=True).strip():
        raise ValueError('The development allocation is still active')
    lock_path = run / 'worker.lock'
    descriptor = c.regular_descriptor(lock_path)
    with os.fdopen(descriptor, 'rb') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    inventory = {}
    for kind in ('requests', 'responses'):
        observed = set()
        for model in d.MODELS:
            for task in d.TASK_COUNTS:
                directory = run / model / task / kind
                if directory.exists():
                    if directory.is_symlink() or directory.resolve() != directory:
                        raise ValueError('Canonical actual runtime directories only')
                    for item in directory.iterdir():
                        if item.suffix != '.json':
                            raise ValueError('Unexpected raw artifact in fixed request/response directory')
                        c.regular_bytes(item)
                        observed.add(item)
        declared = proof.get(kind)
        if (not isinstance(declared, list) or any(not isinstance(row, dict)
                or set(row) != {'path', 'sha256'} for row in declared)
                or len(declared) != len({row['path'] for row in declared})):
            raise ValueError('Terminal closure must enumerate every actual raw file once')
        if observed != {Path(row['path']) for row in declared}:
            raise ValueError('Actual raw inventory differs from terminal preservation proof')
        for row in declared:
            require_hash(row['path'], row['sha256'])
            inventory[Path(row['path'])] = row['sha256']
    if (not isinstance(proof.get('unresolved_claims'), list)
            or any(not isinstance(path, str) for path in proof['unresolved_claims'])):
        raise ValueError('Unresolved claims must remain explicit, including an empty terminal list')
    requests = {path for path in inventory if path.parent.name == 'requests'}
    responses = {path for path in inventory if path.parent.name == 'responses'}
    unresolved = {str(path) for path in requests
                  if path.parent.parent / 'responses' / path.name not in responses}
    if set(proof['unresolved_claims']) != unresolved or len(proof['unresolved_claims']) != len(unresolved):
        raise ValueError('Every unresolved saved claim must match the actual terminal inventory')
    return proof, inventory


def task_artifacts(model, task, plan, runtime, inventory):
    run = c.DEV / 'runtime' / model / task['task_id']
    cases = runtime.read_inputs(task)
    expected = {c.digest(case['case_id'].encode()) + '.json': case for case in cases}
    parser = runtime.load_native_parser(task)
    request_paths = sorted(path for path in inventory if path.parent == run / 'requests')
    response_paths = sorted(path for path in inventory if path.parent == run / 'responses')
    if any(path.name not in expected for path in request_paths + response_paths):
        raise ValueError('Actual development case is outside the exact reviewed panel')
    requests = {}
    request_fields = {'case', 'prompt', 'prompt_token_ids', 'prompt_tokens', 'generation',
                      'model', 'model_revision', 'plan_sha256', 'claimed_at_pacific'}
    for path in request_paths:
        row = c.read(path)
        if (set(row) != request_fields or row['case'] != expected[path.name]
                or row['generation'] != plan['generation'] or row['plan_sha256'] != c.PLAN_SHA
                or row['model'] != c.read(plan['contract_file'])['models'][model]['name']
                or row['model_revision'] != c.read(plan['contract_file'])['models'][model]['revision']
                or not isinstance(row['prompt'], str)
                or expected[path.name]['messages'][0]['content'] not in row['prompt']
                or not isinstance(row['prompt_token_ids'], list)
                or any(type(token) is not int or token < 0 for token in row['prompt_token_ids'])
                or type(row['prompt_tokens']) is not int
                or row['prompt_tokens'] != len(row['prompt_token_ids'])
                or row['prompt_tokens'] + 256 > 65536):
            raise ValueError('Raw request differs from exact full-source development packet')
        requests[path.name] = row
    responses = []
    for path in response_paths:
        request = run / 'requests' / path.name
        if request not in inventory or path.name not in requests:
            raise ValueError('Saved development response lacks its exact source request')
        row = c.read(path)
        d.validate_response(row, task_id=task['task_id'], model_key=model,
            plan_sha256=c.PLAN_SHA, case_id=expected[path.name]['case_id'],
            request_sha256=inventory[request], normalize=runtime.normalize, parser=parser)
        responses.append(row)
    complete_path = run / 'completion.json'
    complete = complete_path.is_file()
    summary = d.summarize_task(task['task_id'], responses,
        request_files=[path.name for path in request_paths], terminal_closure=True,
        task_complete=complete)
    if complete:
        row = c.read(complete_path)
        completion_fields = {'at_pacific', 'task_id', 'model_key', 'planned', 'saved',
            'native_finite_scalar', 'truncations', 'empty_finals', 'format_errors',
            'distinct_predictions', 'prediction_minimum', 'prediction_maximum',
            'nonconstant_prediction_diagnostic', 'numerical_diagnostics_are_not_correctness_metrics',
            'transport_or_server_errors', 'delivery_passed', 'biological_correctness_assessed',
            'benchmark_score', 'plan_sha256'}
        expected_counts = {'saved': summary['saved_responses_verified'],
            'native_finite_scalar': summary['native_finite_scalars'],
            'truncations': summary['truncations'], 'empty_finals': summary['empty_finals'],
            'format_errors': summary['format_error_records']}
        dist = summary['numeric_delivery_distribution']
        if (set(row) != completion_fields or row.get('task_id') != task['task_id'] or row.get('model_key') != model
                or row.get('planned') != task['planned'] or row.get('plan_sha256') != c.PLAN_SHA
                or row.get('biological_correctness_assessed') is not False
                or row.get('benchmark_score') is not False
                or any(row.get(key, 0) != value for key, value in expected_counts.items())
                or row.get('delivery_passed') != (summary['native_finite_scalars'] == task['planned'])
                or row.get('distinct_predictions') != dist['distinct_values']
                or row.get('prediction_minimum') != dist['minimum']
                or row.get('prediction_maximum') != dist['maximum']
                or row.get('nonconstant_prediction_diagnostic') != (dist['distinct_values'] > 1)
                or row.get('numerical_diagnostics_are_not_correctness_metrics') is not True
                or type(row.get('transport_or_server_errors')) is not int
                or row.get('transport_or_server_errors') != 0):
            raise ValueError('Task completion does not reproduce every preserved raw delivery outcome')
    return summary, {path: inventory[path] for path in request_paths + response_paths}


def preserved_old_partial():
    """Rehash prior 24 raw outcomes; never open the full test reference files."""
    closure_path = c.OLD / 'drain_boundary24_v2/terminal_closure.json'
    require_hash(closure_path, '0e4eb24e8c100956e7c23cf6f4a3b73ff866cf49305eba2967e79de6aa4584e3')
    closure = c.read(closure_path)
    plan_path = c.OLD / 'plan_base.json'
    require_hash(plan_path, '047920b73d24c54e9243ec488b10b1df15990fde4bbc8daf945cf5016a30abc6')
    plan = c.read(plan_path)
    scalar_path = c.OLD / 'scalar_lane.py'
    require_hash(scalar_path, plan['pins'][str(scalar_path)])
    scalar = c.load('prior_property_scalar_delivery_only', scalar_path)
    shared_path = Path(plan['shared_runtime_file'])
    require_hash(shared_path, plan['pins'][str(shared_path)])
    shared = c.load('prior_property_shared_raw_normalizer', shared_path)
    require_hash(plan['contract_file'], plan['contract_sha256'])
    contract = c.read(plan['contract_file'])
    task = next(row for row in plan['tasks'] if row['task_id'] == 'P06')
    parser = scalar.load_native_parser(task)
    requests, responses = {}, {}
    members = {'metadata/prior_base24/terminal_closure.json': (closure_path, c.sha(closure_path)),
               'protocol/prior_base24/plan.json': (plan_path, c.sha(plan_path))}
    clarification = c.OLD / 'drain_boundary24_v2/reference_visibility_clarification.json'
    require_hash(clarification, '84c4f27f821b932f576fee64999d37c31a926232deb9ecf828299f0236e20adc')
    members['metadata/prior_base24/reference_visibility_clarification.json'] = (clarification, c.sha(clarification))
    for kind, target in (('requests', requests), ('responses', responses)):
        for row in closure[kind]:
            path = Path(row['path'])
            if path.parent != c.OLD / 'runtime/base/P06' / kind or path.name in target:
                raise ValueError('Prior partial raw identity changed')
            require_hash(path, row['sha256'])
            target[path.name] = c.read(path)
            members['raw/prior_base24/P06/' + kind + '/' + path.name] = (path, row['sha256'])
        actual = {path.name for path in (c.OLD / 'runtime/base/P06' / kind).iterdir()}
        if actual != set(target):
            raise ValueError('Prior partial inventory changed after root-directed closure')
    if len(requests) != 24 or requests.keys() != responses.keys():
        raise ValueError('Every prior 24 claim must retain its saved outcome')
    values, truncated, empty, nonscalar = [], 0, 0, 0
    for name, response in responses.items():
        request = requests[name]
        if (response['request_sha256'] != c.sha(c.OLD / 'runtime/base/P06/requests' / name)
                or response['case_id'] != request['case_id'] or response['task_id'] != 'P06'
                or request['plan_sha256'] != c.digest(c.regular_bytes(plan_path))
                or c.digest(request['case_id'].encode()) + '.json' != name
                or response['status'] != 'response_saved'):
            raise ValueError('Prior partial response/request provenance differs')
        prepared, original = request['prepared'], response['source_normalized_output']
        if prepared['messages'] != request['messages']:
            raise ValueError('Prior complete source messages changed')
        normalized = shared.normalize_output(prepared, original['raw_text'], original['token_ids'],
            original['finish_reason'], contract, usage=original.get('usage'))
        normalized['stop_reason'] = original['stop_reason']
        if (normalized != original or response['final'] != original['final']
                or response['reasoning'] != original['reasoning']
                or response['finish_reason'] != original['finish_reason']):
            raise ValueError('Prior raw generation no longer reproduces saved final normalization')
        value = scalar.parse_prediction(response, parser)
        if value is not None:
            values.append(value)
        truncated += response['finish_reason'] == 'length'
        empty += not bool(response['final'].strip())
        nonscalar += response['finish_reason'] == 'stop' and value is None
    if (len(values), truncated, empty, nonscalar) != (13, 7, 7, 4):
        raise ValueError('Prior preserved 24 delivery counts no longer match exact closure')
    return {'condition': plan['condition'], 'model': plan['model_name'], 'task_id': 'P06',
        'planned_original_task': 1366, 'saved_partial_outcomes': 24,
        'native_finite_scalars': 13, 'truncations': 7, 'empty_finals': 7,
        'normal_stopped_non_scalars': 4, 'numeric_delivery_distribution': d.distribution(values),
        'full_benchmark_complete': False, 'benchmark_score': False,
        'biological_correctness_assessed': False,
        'preservation_note': 'Separate earlier thinking16K condition stopped after 24 saved outcomes.'}, members


def snapshot():
    plan, grant, contract, runtime, grant_path, grant_sha, job, release = actual_authority()
    closure, inventory = terminal_inventory(plan, grant_sha, job)
    models, members = {}, {}
    run = c.DEV / 'runtime'
    for model in d.MODELS:
        folder = run / model
        rows = []
        for task in plan['tasks']:
            summary, actual = task_artifacts(model, task, plan, runtime, inventory)
            rows.append(summary)
            for path, digest in actual.items():
                members['raw/development/' + str(path.relative_to(run))] = (path, digest)
        models[model] = rows
        if (folder / 'completion.json').is_file():
            complete = c.read(folder / 'completion.json')
            if not all(row['task_complete'] for row in rows):
                raise ValueError('Model completion cannot replace missing complete task artifacts')
            totals = {'saved': sum(row['saved_responses_verified'] for row in rows),
                'native_finite_scalar': sum(row['native_finite_scalars'] for row in rows),
                'truncations': sum(row['truncations'] for row in rows),
                'empty_finals': sum(row['empty_finals'] for row in rows),
                'format_errors': sum(row['format_error_records'] for row in rows)}
            model_fields = {'at_pacific', 'model_key', 'planned', 'saved', 'native_finite_scalar',
                'truncations', 'empty_finals', 'format_errors', 'delivery_passed',
                'biological_correctness_assessed', 'benchmark_score', 'plan_sha256'}
            if (set(complete) != model_fields or complete.get('planned') != 92 or complete.get('model_key') != model
                    or complete.get('plan_sha256') != c.PLAN_SHA
                    or complete.get('benchmark_score') is not False
                    or complete.get('biological_correctness_assessed') is not False
                    or any(complete.get(key, 0) != value for key, value in totals.items())
                    or complete.get('delivery_passed') != (totals['native_finite_scalar'] == 92)):
                raise ValueError('Model completion differs from full raw development inventory')
        for name in ('phase_attempt.json', 'session_ready.json', 'full_prompt_preflight.json'):
            path = folder / name
            if path.is_file():
                row = c.read(path)
                schemas = {
                    'phase_attempt.json': {'at_epoch', 'job_id', 'plan_sha256', 'model_key', 'no_automatic_retry', 'operational_config_sha256'},
                    'session_ready.json': {'at_pacific', 'model_key', 'model', 'revision', 'job_id', 'plan_sha256',
                                           'development_only', 'benchmark_score'},
                    'full_prompt_preflight.json': {'at_pacific', 'planned', 'complete_inputs_fit', 'input_truncations', 'targets_read'}}
                if set(row) != schemas[name]:
                    raise ValueError('Unexpected model startup metadata field')
                if name == 'full_prompt_preflight.json' and (row.get('planned') != 92
                        or row.get('complete_inputs_fit') is not True or row.get('input_truncations') != 0
                        or row.get('targets_read') is not False):
                    raise ValueError('Actual full development prompt preflight failed')
                if name == 'session_ready.json' and (row.get('model_key') != model
                        or row.get('development_only') is not True or row.get('benchmark_score') is not False):
                    raise ValueError('Actual model session must remain development-only')
                if name != 'full_prompt_preflight.json' and (row.get('plan_sha256') != c.PLAN_SHA
                        or row.get('job_id') != job):
                    raise ValueError('Model startup/attempt differs from actual allocation')
                if name == 'phase_attempt.json' and (row.get('operational_config_sha256') != c.OP_CONFIG_SHA
                        or row.get('model_key') != model
                        or row.get('no_automatic_retry') is not True):
                    raise ValueError('Only the actual once-only model phase is permitted')
                if name == 'session_ready.json' and (row.get('model') != contract['models'][model]['name']
                        or row.get('revision') != contract['models'][model]['revision']):
                    raise ValueError('Actual development checkpoint identity differs')
            elif any(row['saved_responses_verified'] or row['request_files_observed'] for row in rows):
                raise ValueError('Raw generation lacks original startup/once-only/full-prompt evidence')
    pair_path = run / 'pair_completion.json'
    complete = pair_path.is_file()
    if complete:
        pair = c.read(pair_path)
        if (set(pair) != {'at_epoch', 'planned', 'models', 'plan_sha256', 'operational_config_sha256',
                'benchmark_score', 'biological_correctness_assessed'} or pair.get('planned') != 184 or pair.get('plan_sha256') != c.PLAN_SHA
                or pair.get('operational_config_sha256') != c.OP_CONFIG_SHA
                or pair.get('benchmark_score') is not False
                or pair.get('biological_correctness_assessed') is not False
                or set(pair.get('models', {})) != set(d.MODELS)):
            raise ValueError('Only an actual exact184 development completion is accepted')
        for model in d.MODELS:
            if set(pair['models'][model]) != {'completion_sha256', 'delivery_passed'}:
                raise ValueError('Unexpected pair completion metadata')
            require_hash(run / model / 'completion.json', pair['models'][model]['completion_sha256'])
            if pair['models'][model]['delivery_passed'] != c.read(run / model / 'completion.json')['delivery_passed']:
                raise ValueError('Pair completion no longer binds both exact model outcomes')
        if closure['unresolved_claims']:
            raise ValueError('Complete184 cannot include unresolved actual claims')
    elif (closure.get('terminal_gate_failure') is not True
          or not isinstance(closure.get('failure_reason'), str) or not closure['failure_reason'].strip()):
        raise ValueError('An incomplete terminal allocation requires explicit failure reconciliation')
    summary = d.pair_summary(models, pair_completion_verified=complete,
                              terminal_failure_verified=not complete)
    prior, old_members = preserved_old_partial()
    members.update(old_members)
    summary.update({'prior_Base24_separate_condition': prior, 'job_id': job,
        'plan_sha256': c.PLAN_SHA, 'grant_sha256': grant_sha,
        'root_scope_adoption_sha256': c.SCOPE_SHA,
        'operational_config_sha256': c.OP_CONFIG_SHA, 'root_authorization_sha256': c.AUTH_SHA,
        'reference_values_inspected_or_scored': False,
        'unknown_unclosed_model_attempts_are_not_zero': True})
    for path in run.rglob('scores.json'):
        raise ValueError('Unexpected correctness score in a delivery-only condition: ' + path.name)
    metadata = ['submission_attempt.json', 'submission.json', 'started.json',
                'pair_completion.json', 'owner_terminal_closure.json']
    for model in d.MODELS:
        metadata.extend(model + '/' + name for name in ('phase_attempt.json', 'session_ready.json',
            'full_prompt_preflight.json', 'completion.json'))
        metadata.extend(model + '/' + task + '/completion.json' for task in d.TASK_COUNTS)
    for name in metadata:
        path = run / name
        if path.is_file():
            members['metadata/development/' + name] = (path, c.sha(path))
    protocol = {'plan.json': c.PLAN, 'root_scope.json': c.SCOPE,
                'execution_grant.json': grant_path, 'priority_release.json': Path(release['path']),
                'shared_contract.json': Path(plan['contract_file']),
                'final_source_review_packet.json': c.FINAL_PACKET,
                'restoration_config.json': c.OP_CONFIG,
                'independent_runtime_admission.json': c.HERE.parent / 'independent_runtime_admission.json'}
    for name, path in protocol.items():
        members['protocol/development/' + name] = (path, c.sha(path))
    for path in (c.EXECUTE, c.TEST_EXECUTE, c.WORKER, c.OP_RESTORE, c.OP_WORKER):
        members['code/development/' + path.name] = (path, c.sha(path))
    # These exact generator dependencies are public source code, not model
    # payloads or operational resource-review bodies. Their code is required
    # to reproduce the saved scalar normalization and input contract.
    for name, path in (('prior_scalar_lane.py', c.OLD / 'scalar_lane.py'),
                       ('shared_runtime.py', Path(plan['shared_runtime_file']))):
        require_hash(path, plan['pins'][str(path)])
        members['code/development/' + name] = (path, c.sha(path))
    for name in PUBLICATION_SOURCES:
        path = c.HERE / name
        members['code/publication/' + name] = (path, c.sha(path))
    for task in plan['tasks']:
        for field in ('input_file', 'review_file', 'native_numeric_parser_file'):
            path = Path(task[field])
            members['inputs/development/' + task['task_id'] + '/' + path.name] = (path, c.sha(path))
    # Exact operational private-resource proofs are verified by runtime.validate
    # and retain path/hash references in the frozen plan. Their bodies, runtime
    # environments, caches, model weights and credentials are never whitelisted.
    return summary, members, {'grant_path': str(grant_path), 'grant_sha256': grant_sha,
        'owner_terminal_closure_sha256': c.sha(run / 'owner_terminal_closure.json'),
        'priority_release': release, 'operational_config_sha256': c.OP_CONFIG_SHA,
        'root_authorization_sha256': c.AUTH_SHA,
        'independent_runtime_admission_sha256': c.OP_ADMISSION_SHA}


def description(summary):
    outcome = ('All 184 development outcomes were preserved.' if summary['development_pair_complete']
               else 'The validation job ended before all 184 development outcomes were preserved.')
    lines = ['# Qwen3.5 protein-property delivery validation', '', outcome,
        'These checks assess numeric output delivery on the existing validation panels. '
        'Biological correctness was not scored.', '',
        '| Model | Validation task | Saved | Finite scalar | Truncated | Output range |',
        '|---|---|---:|---:|---:|---|']
    labels = {'P06': 'FLIP Meltome thermostability', 'P08': 'TAPE stability', 'P07': 'TAPE GFP fluorescence'}
    for model in d.MODELS:
        name = 'Qwen3.5-4B-Base' if model == 'base' else 'Qwen3.5-4B'
        for row in summary['models'][model]:
            dist = row['numeric_delivery_distribution']
            span = '—' if dist['finite_count'] == 0 else f"{dist['minimum']:g} to {dist['maximum']:g}"
            lines.append(f"| {name} | {labels[row['task_id']]} | {row['saved_responses_verified']}/{row['planned_development_cases']} | {row['native_finite_scalars']} | {row['truncations']} | {span} |")
    lines += ['', 'Both models use the same complete source prompts, nonthinking output mode, '
        'a fixed finite-number grammar and 256 output tokens. Numeric ranges describe model '
        'outputs only. Unclosed generation attempts remain unknown in a terminal partial record.', '',
        'The earlier thinking16K Base condition stopped after 24 thermostability outputs: '
        '13 numeric finals, 7 truncations and 4 nonnumeric finals. Its raw outputs are preserved '
        'separately; it produced no benchmark score.', '',
        '[Raw trajectories, approved inputs and code](https://github.com/' + c.REPOSITORY +
        '/blob/main/' + c.PREFIX + 'archive_index.json).', '']
    return '\n'.join(lines).encode()


def partition(members, limit=c.MAX_PART_BYTES):
    groups, group, size = ([], {}, 0)
    for name, row in sorted(members.items()):
        c.safe_name(name)
        path, digest = row
        length = len(c.regular_bytes(path))
        if length > limit:
            raise ValueError('A single whitelisted source exceeds the fixed archive boundary')
        if group and size + length > limit:
            groups.append(group)
            group, size = ({}, 0)
        group[name], size = (row, size + length)
    if group:
        groups.append(group)
    if not groups:
        raise ValueError('Empty bundle')
    return groups

def archive_bytes(members, scanner):
    output, metadata = (io.BytesIO(), {})
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=6) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as archive:
            for name, (path, expected) in sorted(members.items()):
                c.safe_name(name)
                scanner.safe_archive_member(name)
                raw = c.scan_source(path, scanner)
                if c.digest(raw) != expected:
                    raise ValueError('Whitelisted source changed during export')
                item = tarfile.TarInfo(name)
                item.size, item.mtime, item.mode = (len(raw), 0, 420)
                archive.addfile(item, io.BytesIO(raw))
                metadata[name] = {'bytes': len(raw), 'sha256': expected}
    data = output.getvalue()
    if len(data) >= c.MAX_GIT_BYTES or sum((row['bytes'] for row in metadata.values())) > c.MAX_PART_BYTES:
        raise ValueError('Archive exceeds the independently reviewed bounded Git/scan boundary')
    return (data, metadata)

def verify_archive(path, expected, scanner):
    observed, total = ({}, 0)
    raw = c.regular_bytes(path)
    if len(raw) >= c.MAX_GIT_BYTES:
        raise ValueError('Git blob too large')
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        for item in archive:
            c.safe_name(item.name)
            scanner.safe_archive_member(item.name)
            if not item.isfile() or item.name in observed or item.mode != 420:
                raise ValueError('Only unique regular archive members allowed')
            total += item.size
            if total > c.MAX_PART_BYTES:
                raise ValueError('Archive exceeds fixed uncompressed scan boundary')
            data = archive.extractfile(item).read()
            scanner.scan_bytes(data)
            if item.name.endswith('.json'):
                c.check_json_privacy(c.loads(data))
            elif item.name.endswith('.jsonl'):
                for line in data.splitlines():
                    c.check_json_privacy(c.loads(line))
            observed[item.name] = {'bytes': len(data), 'sha256': c.digest(data)}
    if observed != expected:
        raise ValueError('Exact concrete archive member inventory changed')


def validate_members(members):
    """Explicit logical roots; never turn all operational source pins into exports."""
    for name, (path, digest) in members.items():
        c.safe_name(name)
        if not name.startswith(('raw/development/', 'raw/prior_base24/', 'metadata/development/',
                'metadata/prior_base24/', 'protocol/development/', 'protocol/prior_base24/',
                'code/development/', 'code/publication/', 'inputs/development/')):
            raise ValueError('Outside the exact development/raw-preservation member union')
        lower = name.lower()
        if any(word in lower for word in ('scorer_reference', 'safetensor', 'checkpoint',
                'credential', 'private_gpu', 'environment', '/cache', 'runtime_archive',
                'unrelated_job', 'external_teacher', 'external_web_filter')):
            raise ValueError('Private operational metadata or protected references may not be archived')
        require_hash(path, digest)


def assemble(freeze_path, freeze_sha, review_path, review_sha):
    frozen = verify_freeze(freeze_path, freeze_sha)
    source_review(review_path, review_sha, freeze_sha)
    if not readiness()['actual_terminal_closure_present']:
        raise ValueError('Actual development terminal proof absent; counts remain unknown')
    lock_fd = os.open(c.HERE / 'assembly.lock', os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        if not stat.S_ISREG(os.fstat(lock_fd).st_mode):
            raise ValueError('Regular assembly lock required')
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if any(os.path.lexists(c.HERE / name) for name in
               ('assembly_attempt.json', 'stage', 'manifest.json', 'assembly_receipt.json')):
            raise FileExistsError('Preserve any prior assembly attempt; no automatic overwrite or retry')
        summary, members, bindings = snapshot()
        validate_members(members)
        c.write_json(c.HERE / 'assembly_attempt.json', {'at_pacific': c.stamp(),
            'pair_id': c.PAIR_ID, 'plan_sha256': c.PLAN_SHA,
            'source_freeze_sha256': freeze_sha, 'source_review_sha256': review_sha,
            'development_pair_complete': summary['development_pair_complete'],
            'terminal_partial_failure': summary['terminal_partial_failure'],
            'model_calls': 0, 'scoring_attempts': 0, 'automatic_retry': False})
        scanner = c.load('property_dev_archive_scanner', c.SCANNER)
        groups = partition(members)
        stage = c.HERE / 'stage'
        archives = []
        for number, group in enumerate(groups, 1):
            data, index = archive_bytes(group, scanner)
            name = c.ARCHIVE_PREFIX + f'part{number:05d}.tar.gz'
            c.write_bytes(stage / name, data)
            verify_archive(stage / name, index, scanner)
            archives.append({'path': name, 'bytes': len(data), 'sha256': c.digest(data),
                             'members': index})
        archive_index = {'pair_id': c.PAIR_ID, 'plan_sha256': c.PLAN_SHA,
            'root_scope_adoption_sha256': c.SCOPE_SHA, 'archives': archives,
            'development_pair_complete': summary['development_pair_complete'],
            'terminal_partial_failure': summary['terminal_partial_failure'],
            'benchmark_score': False, 'biological_correctness_assessed': False,
            'reference_bodies_weights_environment_private_GPU_metadata_included': False}
        c.write_json(stage / (c.PREFIX + 'archive_index.json'), archive_index)
        c.write_json(stage / (c.PREFIX + 'delivery_diagnostics.json'), summary)
        for name in (c.PREFIX + 'README.md', c.REPORT):
            c.write_bytes(stage / name, description(summary))
        files = {name: c.sha(stage / name) for name in sorted(c.expected_public_paths(len(groups)))}
        for name in files:
            scanner.scan_file(stage / name)
        manifest = {'at_pacific': c.stamp(), 'pair_id': c.PAIR_ID,
            'repository': c.REPOSITORY, 'visibility': 'public', 'plan_sha256': c.PLAN_SHA,
            'root_scope_adoption_sha256': c.SCOPE_SHA,
            'development_scope_only': True, 'benchmark_score': False,
            'biological_correctness_assessed': False,
            'development_pair_complete': summary['development_pair_complete'],
            'terminal_partial_failure': summary['terminal_partial_failure'],
            'source_freeze': {'path': str(freeze_path), 'sha256': freeze_sha},
            'source_review': {'path': str(review_path), 'sha256': review_sha},
            'files_sha256': files, 'archive_count': len(groups), 'bindings': bindings,
            'archive_index_sha256': files[c.PREFIX + 'archive_index.json'],
            'source_files_sha256': {str(path): digest for path, digest in members.values()},
            'support_sha256': {**PINNED_HELPERS, **frozen['files_sha256']},
            'prior_Base24_partial_preserved': True,
            'reference_bodies_weights_environment_private_GPU_metadata_included': False,
            'shared_primary_documents_modified': False, 'website_or_schedule_changes': False,
            'model_calls': 0, 'scoring_attempts': 0}
        c.write_json(c.HERE / 'manifest.json', manifest)
        check(c.HERE / 'manifest.json', c.sha(c.HERE / 'manifest.json'))
        c.write_json(c.HERE / 'assembly_receipt.json', {'at_pacific': c.stamp(),
            'stage': 'assembled_not_published', 'manifest_sha256': c.sha(c.HERE / 'manifest.json'),
            'public_paths': len(files), 'archive_count': len(groups),
            'raw_member_count': len(members), 'development_pair_complete': summary['development_pair_complete'],
            'terminal_partial_failure': summary['terminal_partial_failure'],
            'exact_concrete_independent_publication_review_required': True,
            'model_calls': 0, 'scoring_attempts': 0, 'network_calls': 0})
        return manifest
    finally:
        os.close(lock_fd)


def check(path, digest):
    require_hash(path, digest)
    manifest = c.read(path)
    if (manifest.get('pair_id') != c.PAIR_ID or manifest.get('repository') != c.REPOSITORY
            or manifest.get('visibility') != 'public' or manifest.get('plan_sha256') != c.PLAN_SHA
            or manifest.get('root_scope_adoption_sha256') != c.SCOPE_SHA
            or manifest.get('development_scope_only') is not True
            or manifest.get('benchmark_score') is not False
            or manifest.get('biological_correctness_assessed') is not False
            or manifest.get('prior_Base24_partial_preserved') is not True
            or manifest.get('reference_bodies_weights_environment_private_GPU_metadata_included') is not False
            or manifest.get('shared_primary_documents_modified') is not False
            or manifest.get('website_or_schedule_changes') is not False
            or manifest.get('model_calls') != 0 or manifest.get('scoring_attempts') != 0):
        raise ValueError('Only the exact development delivery and prior partial preservation union is accepted')
    freeze, review = manifest['source_freeze'], manifest['source_review']
    frozen = verify_freeze(freeze['path'], freeze['sha256'])
    source_review(review['path'], review['sha256'], freeze['sha256'])
    if manifest['support_sha256'] != {**PINNED_HELPERS, **frozen['files_sha256']}:
        raise ValueError('Exact source/helper support changed')
    summary, members, bindings = snapshot()
    validate_members(members)
    if (manifest.get('bindings') != bindings
            or manifest.get('source_files_sha256') != {str(p): h for p, h in members.values()}
            or manifest.get('development_pair_complete') != summary['development_pair_complete']
            or manifest.get('terminal_partial_failure') != summary['terminal_partial_failure']):
        raise ValueError('Manifest differs from actual closed raw source/authority evidence')
    count = manifest['archive_count']
    c.validate_paths(manifest['files_sha256'], count)
    stage = c.HERE / 'stage'
    for name, expected in manifest['files_sha256'].items():
        require_hash(stage / name, expected)
        if len(c.regular_bytes(stage / name)) >= c.MAX_GIT_BYTES:
            raise ValueError('Artifact exceeds the fixed Git blob boundary')
    if c.read(stage / (c.PREFIX + 'delivery_diagnostics.json')) != summary:
        raise ValueError('Staged numeric delivery diagnostic differs from actual preserved outcomes')
    for name in (c.PREFIX + 'README.md', c.REPORT):
        if c.regular_bytes(stage / name) != description(summary):
            raise ValueError('Staged public prose differs from verified actual delivery counts')
    index = c.read(stage / (c.PREFIX + 'archive_index.json'))
    index_fields = {'pair_id', 'plan_sha256', 'root_scope_adoption_sha256', 'archives',
        'development_pair_complete', 'terminal_partial_failure', 'benchmark_score',
        'biological_correctness_assessed',
        'reference_bodies_weights_environment_private_GPU_metadata_included'}
    if (set(index) != index_fields
            or index.get('pair_id') != c.PAIR_ID or index.get('plan_sha256') != c.PLAN_SHA
            or index.get('root_scope_adoption_sha256') != c.SCOPE_SHA
            or len(index.get('archives', [])) != count
            or index.get('development_pair_complete') != summary['development_pair_complete']
            or index.get('terminal_partial_failure') != summary['terminal_partial_failure']
            or index.get('benchmark_score') is not False
            or index.get('biological_correctness_assessed') is not False
            or index.get('reference_bodies_weights_environment_private_GPU_metadata_included') is not False):
        raise ValueError('Archive index identity/exclusions differ')
    scanner = c.load('property_dev_check_archive_scanner', c.SCANNER)
    observed = {}
    for number, row in enumerate(index['archives'], 1):
        expected_name = c.ARCHIVE_PREFIX + f'part{number:05d}.tar.gz'
        if (set(row) != {'path', 'sha256', 'bytes', 'members'}
                or row['path'] != expected_name or row['sha256'] != manifest['files_sha256'][expected_name]
                or row['bytes'] != len(c.regular_bytes(stage / expected_name))):
            raise ValueError('Archive index no longer binds exact staged public parts')
        if set(observed).intersection(row['members']):
            raise ValueError('Duplicate raw/source member across archive parts')
        verify_archive(stage / expected_name, row['members'], scanner)
        observed.update(row['members'])
    expected = {name: {'bytes': len(c.regular_bytes(p)), 'sha256': h}
                for name, (p, h) in members.items()}
    if observed != expected:
        raise ValueError('Archive members differ from the actual exact raw/source whitelist')
    if manifest['archive_index_sha256'] != manifest['files_sha256'][c.PREFIX + 'archive_index.json']:
        raise ValueError('Archive index pin differs')
    return manifest


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--assemble', action='store_true')
    ap.add_argument('--source-freeze', type=Path)
    ap.add_argument('--source-freeze-sha256')
    ap.add_argument('--source-review', type=Path)
    ap.add_argument('--source-review-sha256')
    args = ap.parse_args(argv)
    if args.assemble:
        if any(value is None for value in (args.source_freeze, args.source_freeze_sha256,
                                           args.source_review, args.source_review_sha256)):
            ap.error('Exact source freeze and independent source-only review pins are required')
        result = assemble(args.source_freeze, args.source_freeze_sha256,
                          args.source_review, args.source_review_sha256)
        print(json.dumps({'stage': 'assembled_not_published', 'archive_count': result['archive_count'],
                          'development_pair_complete': result['development_pair_complete'],
                          'terminal_partial_failure': result['terminal_partial_failure']}))
    else:
        print(json.dumps(readiness()))


if __name__ == '__main__':
    main()
