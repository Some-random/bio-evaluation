from pathlib import Path, PurePosixPath
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import importlib.util
import json
import math
import os
import re
import stat

"""CPU-only development archive identities and reviewed filesystem primitives."""
HERE = Path(__file__).resolve().parent
DEV = HERE.parents[1]
PROPERTY = DEV.parent
COMPARISON = PROPERTY.parent
OLD = PROPERTY / 'recommended_sampling_v2'
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
EXPORT_AUTHOR = '/root/priority_runtime_review/lpb398_verifier_tests'
REPOSITORY = 'Some-random/bio-evaluation'
URL = 'https://github.com/' + REPOSITORY + '.git'
PAIR_ID = 'qwen35_4b_pair_property_validation_delivery_nonthinking_regex256_20261022_v3'
PREFIX = 'results/runs/' + PAIR_ID + '/'
REPORT = 'reports/QWEN35_4B_PROPERTY_VALIDATION_DELIVERY.md'
ARCHIVE_PREFIX = 'results/trajectory_archives/' + PAIR_ID + '/'
SCOPE = DEV / 'root_development_scope_adoption_20261022.json'
SCOPE_SHA = 'be50fcf7b041aa262ce84ba0f1e7c9d083c0232d0b7f9352edb081fd8d254470'
PLAN = DEV / 'plan_final_resource_v4_guarded.json'
PLAN_SHA = 'c60fe0c5277950bd4c3a94b232880a455da247521b98439b58cb53a0cdf00dd4'
EXECUTE = DEV / 'execute_v4_guarded.py'
EXECUTE_SHA = 'fe6da63cb49eaabac7c36c08a866c229e8c642208b5054315379ace7f574d75f'
TEST_EXECUTE = DEV / 'test_execute_v4_guarded.py'
WORKER = DEV / 'worker_v4_guarded.sbatch'
FINAL_PACKET = DEV / 'FINAL_RESOURCE_V4_GUARDED_REVIEW_PACKET.json'
FINAL_PACKET_SHA = '91f5726df8744163018c6e9a359f7359abed34a0475ad0d1a00f90440d8daa2e'
OP_CONFIG = HERE.parent / 'config.json'
OP_CONFIG_SHA = '34bf3cecbc60b5cf6693d0e5e911fed5c552d98d898c0bfab166ba4cc7708d09'
OP_RESTORE = HERE.parent / 'restore.py'
OP_RESTORE_SHA = 'd8c0fafb3567e48ea2ddccbfb65ccabb717214e60491665375a0d9ddcd37eed7'
OP_WORKER = HERE.parent / 'worker.sbatch'
OP_ADMISSION_SHA = '9219934391e88048029e6d2abda3d406050d3050b452bbb5aa9c5f907f3909fc'
AUTH_SHA = 'bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
GRANT_SHA = 'd9173ef9d95d94b0dabf5b7b07b97a0b08a19292ce25ed7357cb02f694afad75'
TASK_COUNTS = {'P06': 16, 'P08': 12, 'P07': 64}
SCANNER = ROOT / 'scripts/daily_backup.py'
GIT_HELPER = ROOT / '.local/litqa2_replay/incremental_upload.py'
CREDENTIAL_HELPER = ROOT / '.local/litqa2_replay/github_credential_helper.py'
DESTINATION_POLICY = ROOT / 'scripts/publication_destination.py'
MAX_PART_BYTES = 32 * 1024**2
MAX_GIT_BYTES = 90 * 1024**2
FORBIDDEN_JSON_KEYS = frozenset(('safety_identifier', 'encrypted_content', 'user', 'api_key',
    'oauth_token', 'access_token', 'authorization', 'password', 'credential', 'credentials',
    'private_gpu_audit', 'private_audit', 'raw_gpu_audit', 'private_runtime',
    'environment_variables', 'unrelated_job_exact_identity', 'unrelated_project_data'))


def stamp():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def regular_bytes(path):
    """Read through no-follow descriptors, refusing links in every component."""
    path = Path(path).absolute()
    descriptor = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            current = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = current
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=descriptor)
        with os.fdopen(fd, 'rb') as stream:
            if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                raise ValueError('Regular files only')
            return stream.read()
    finally:
        os.close(descriptor)

def regular_descriptor(path):
    """Open a current regular file through anchored, non-following descriptors."""
    path = Path(path).absolute()
    directory = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            current = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
            os.close(directory)
            directory = current
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=directory)
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            os.close(fd)
            raise ValueError('Current regular file required')
        return fd
    finally:
        os.close(directory)


def sha(path):
    return digest(regular_bytes(path))

def loads(data):

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('Duplicate JSON key')
            result[key] = value
        return result

    def invalid(_):
        raise ValueError('Nonfinite JSON number')
    return json.loads(data, object_pairs_hook=pairs, parse_constant=invalid)

def read(path):
    return loads(regular_bytes(path))

def json_bytes(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()

def write_bytes(path, data):
    path = Path(path).absolute()
    if any(part in ('.', '..', '') for part in path.parts):
        raise ValueError('Canonical output path required')
    directory = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            try:
                os.mkdir(part, mode=0o700, dir_fd=directory)
            except FileExistsError:
                pass
            next_directory = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                                     dir_fd=directory)
            os.close(directory)
            directory = next_directory
        fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600, dir_fd=directory)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.fsync(directory)
    finally:
        os.close(directory)

def write_json(path, value):
    write_bytes(path, json_bytes(value))

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def safe_name(name):
    if not isinstance(name, str) or not name or '\\' in name:
        raise ValueError('Unsafe public path')
    path = PurePosixPath(name)
    if path.is_absolute() or path.as_posix() != name or any((part in ('..', '.', '.local', 'docs', '.git', '') for part in path.parts)):
        raise ValueError('Unsafe or website path')
    return path

def check_json_privacy(value):
    """Fail rather than silently rewrite original private-sensitive metadata."""
    if isinstance(value, dict):
        for key, item in value.items():
            if key.lower() in FORBIDDEN_JSON_KEYS and item is not None:
                raise ValueError('Private provider/credential metadata needs a separately reviewed export')
            check_json_privacy(item)
    elif isinstance(value, list):
        for item in value:
            check_json_privacy(item)

def scan_source(path, scanner):
    raw = regular_bytes(path)
    scanner.scan_bytes(raw)
    if Path(path).suffix == '.json':
        check_json_privacy(loads(raw))
    elif Path(path).suffix == '.jsonl':
        for line in raw.splitlines():
            check_json_privacy(loads(line))
    return raw

def write_checkout_file(checkout, name, data):
    parts = safe_name(name).parts
    descriptor = os.open(checkout, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in parts[:-1]:
            try:
                os.mkdir(part, mode=493, dir_fd=descriptor)
            except FileExistsError:
                pass
            current = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = current
        try:
            fd = os.open(parts[-1], os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 420, dir_fd=descriptor)
        except FileExistsError:
            fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW, dir_fd=descriptor)
            with os.fdopen(fd, 'rb') as stream:
                if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode) or stream.read() != data:
                    raise ValueError('Existing immutable public artifact differs')
        else:
            with os.fdopen(fd, 'wb') as stream:
                stream.write(data)
    finally:
        os.close(descriptor)


def expected_public_paths(archive_count):
    if type(archive_count) is not int or not 1 <= archive_count <= 16384:
        raise ValueError('Bounded concrete archive count required')
    result = {PREFIX + name for name in ('delivery_diagnostics.json', 'README.md', 'archive_index.json')}
    result.add(REPORT)
    result.update(ARCHIVE_PREFIX + f'part{part:05d}.tar.gz' for part in range(1, archive_count + 1))
    return frozenset(result)


def validate_paths(paths, archive_count):
    if set(paths) != expected_public_paths(archive_count):
        raise ValueError('Only exact development technical artifacts may be published')
    for name in paths:
        safe_name(name)
