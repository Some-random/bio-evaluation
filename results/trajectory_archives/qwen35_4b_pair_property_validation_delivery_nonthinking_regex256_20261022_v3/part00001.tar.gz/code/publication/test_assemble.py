"""Artificial artifact/transaction tests; no scheduler, inference or network calls."""
from pathlib import Path
import ast
import contextlib
import copy
import io
import re
import tarfile
import tempfile
import types
import unittest
from unittest.mock import patch

import assemble as a
import bundle_common as c
import diagnostics as d


class Scanner:
    def safe_archive_member(self, name):
        c.safe_name(name)
    def scan_bytes(self, data):
        if b'ARTIFICIAL_SECRET' in data:
            raise ValueError('Artificial secret')
    def scan_file(self, path):
        data = c.scan_source(path, self) if Path(path).suffix != '.gz' else c.regular_bytes(path)
        self.scan_bytes(data)


def pure_normalize():
    # Extract just the frozen pure normalizer; do not import any model runtime.
    tree = ast.parse(c.regular_bytes(c.EXECUTE))
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'normalize')
    namespace = {'re': re, 'REGEX': r'[+-]?[0-9]{1,12}(\.[0-9]{1,12})?([eE][+-]?[0-9]{1,2})?'}
    exec(compile(ast.Module(body=[function], type_ignores=[]), 'pure_frozen_normalizer', 'exec'), namespace)
    return namespace['normalize']


class Fixture:
    def __init__(self, root):
        self.root = root
        self.dev = root / 'dev'
        self.pub = self.dev / 'publication'
        self.pub.mkdir(parents=True)
        self.contract_file = self.dev / 'contract.json'
        self.contract = {'models': {key: {'name': 'artificial-' + key, 'revision': 'artificial-revision'} for key in d.MODELS}}
        c.write_json(self.contract_file, self.contract)
        shared = self.dev / 'shared_runtime.py'; shared.write_text('artificial source\n')
        self.plan = {'generation': {'max_tokens': 256}, 'contract_file': str(self.contract_file),
            'shared_runtime_file': str(shared), 'pins': {str(shared): c.sha(shared),
                str(c.OLD / 'scalar_lane.py'): c.sha(c.OLD / 'scalar_lane.py')},
            'tasks': [{'task_id': task, 'planned': count} for task, count in d.TASK_COUNTS.items()]}
        self.cases = {task: [{'task_id': task, 'case_id': task + '-' + str(i),
            'messages': [{'role': 'user', 'content': 'Artificial scalar input ' + str(i)}]}
            for i in range(count)] for task, count in d.TASK_COUNTS.items()}
        self.runtime = types.SimpleNamespace(read_inputs=lambda t: self.cases[t['task_id']],
            load_native_parser=lambda t: float, normalize=pure_normalize())
        self.inventory = {}
        self.closure = {'at_pacific': 'artificial', 'job_id': '123', 'plan_sha256': c.PLAN_SHA,
            'grant_sha256': 'a' * 64, 'root_scope_adoption_sha256': c.SCOPE_SHA,
            'terminal_verified': True, 'active_allocation_absent': True, 'worker_lock_verified_free': True,
            'scheduler_state': 'FAILED', 'scheduler_exit_code': '1:0',
            'terminal_gate_failure': True, 'failure_reason': 'Artificial terminal generation failure',
            'requests': [], 'responses': [], 'unresolved_claims': [],
            'operational_config_sha256': c.OP_CONFIG_SHA, 'root_authorization_sha256': c.AUTH_SHA,
            'independent_runtime_admission_sha256': c.OP_ADMISSION_SHA}

    def write(self, path, row):
        c.write_json(path, row)
        return path

    def task(self, model, task, count, *, complete=False, invalid_index=None, unresolved=0):
        folder = self.dev / 'runtime' / model / task
        responses = []
        for index, case in enumerate(self.cases[task][:count + unresolved]):
            name = c.digest(case['case_id'].encode()) + '.json'
            request = folder / 'requests' / name
            self.write(request, {'case': case, 'prompt': 'Artificial prefix ' + case['messages'][0]['content'],
                'prompt_token_ids': [10, 20], 'prompt_tokens': 2, 'generation': self.plan['generation'],
                'model': self.contract['models'][model]['name'], 'model_revision': 'artificial-revision',
                'plan_sha256': c.PLAN_SHA, 'claimed_at_pacific': 'artificial'})
            self.inventory[request] = c.sha(request)
            if index >= count:
                continue
            length = index == invalid_index
            normalized = self.runtime.normalize('4.5' if not length else 'unfinished',
                [10, 20], 'length' if length else 'stop', 248046 if not length else None, float)
            response = folder / 'responses' / name
            row = {'at_pacific': 'artificial', 'case_id': case['case_id'], 'task_id': task,
                'model_key': model, 'plan_sha256': c.PLAN_SHA, 'request_file_sha256': c.sha(request), **normalized}
            self.write(response, row)
            self.inventory[response] = c.sha(response)
            responses.append(row)
        summary = d.summarize_task(task, responses, request_files=[str(i) for i in range(count + unresolved)],
            terminal_closure=True, task_complete=complete)
        if complete:
            dist = summary['numeric_delivery_distribution']
            self.write(folder / 'completion.json', {'at_pacific': 'artificial', 'task_id': task,
                'model_key': model, 'planned': d.TASK_COUNTS[task], 'saved': count,
                'native_finite_scalar': summary['native_finite_scalars'], 'truncations': summary['truncations'],
                'empty_finals': summary['empty_finals'], 'format_errors': summary['format_error_records'],
                'distinct_predictions': dist['distinct_values'], 'prediction_minimum': dist['minimum'],
                'prediction_maximum': dist['maximum'], 'nonconstant_prediction_diagnostic': dist['distinct_values'] > 1,
                'numerical_diagnostics_are_not_correctness_metrics': True, 'transport_or_server_errors': 0,
                'delivery_passed': summary['native_finite_scalars'] == count,
                'biological_correctness_assessed': False, 'benchmark_score': False, 'plan_sha256': c.PLAN_SHA})
        return summary

    def startup(self, model):
        folder = self.dev / 'runtime' / model
        self.write(folder / 'phase_attempt.json', {'at_epoch': 123.0, 'job_id': '123',
            'operational_config_sha256': c.OP_CONFIG_SHA,
            'plan_sha256': c.PLAN_SHA, 'model_key': model, 'no_automatic_retry': True})
        self.write(folder / 'session_ready.json', {'at_pacific': 'artificial', 'job_id': '123',
            'plan_sha256': c.PLAN_SHA, 'model_key': model, **self.contract['models'][model],
            'development_only': True, 'benchmark_score': False, 'model': self.contract['models'][model]['name']})
        row = c.read(folder / 'session_ready.json'); row.pop('name')
        (folder / 'session_ready.json').write_bytes(c.json_bytes(row))
        self.write(folder / 'full_prompt_preflight.json', {'at_pacific': 'artificial', 'planned': 92,
            'complete_inputs_fit': True, 'input_truncations': 0, 'targets_read': False})

    def full_pair(self):
        records = {}
        for model in d.MODELS:
            self.startup(model)
            rows = [self.task(model, task, count, complete=True, invalid_index=0 if task == 'P06' else None)
                    for task, count in d.TASK_COUNTS.items()]
            self.write(self.dev / 'runtime' / model / 'completion.json', {
                'at_pacific': 'artificial', 'model_key': model, 'planned': 92, 'saved': 92,
                'native_finite_scalar': 91, 'truncations': 1, 'empty_finals': 1, 'format_errors': 1,
                'delivery_passed': False, 'biological_correctness_assessed': False,
                'benchmark_score': False, 'plan_sha256': c.PLAN_SHA})
            records[model] = {'completion_sha256': c.sha(self.dev / 'runtime' / model / 'completion.json'),
                              'delivery_passed': False}
        self.write(self.dev / 'runtime/pair_completion.json', {'at_epoch': 123.0, 'planned': 184,
            'operational_config_sha256': c.OP_CONFIG_SHA,
            'models': records, 'plan_sha256': c.PLAN_SHA, 'benchmark_score': False,
            'biological_correctness_assessed': False})
        self.closure.update(scheduler_state='COMPLETED', scheduler_exit_code='0:0')

    def authority(self):
        return self.plan, {}, self.contract, self.runtime, self.dev / 'grant.json', 'a' * 64, '123', {'path': str(self.dev / 'release.json')}


class AssemblyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.f = Fixture(self.root)
        self.stack = contextlib.ExitStack()
        self.stack.enter_context(patch.object(c, 'DEV', self.f.dev))
        self.stack.enter_context(patch.object(c, 'HERE', self.f.pub))

    def tearDown(self):
        self.stack.close()
        self.temp.cleanup()

    def snapshot(self):
        with patch.object(a, 'actual_authority', side_effect=self.f.authority), \
             patch.object(a, 'terminal_inventory', return_value=(self.f.closure, self.f.inventory)), \
             patch.object(a, 'preserved_old_partial', return_value=({'saved_partial_outcomes': 24}, {})), \
             patch.object(c, 'sha', side_effect=lambda p: c.digest(c.regular_bytes(p)) if Path(p).is_file() else 'a' * 64):
            # Do not read real/future protocol paths: synthetic snapshot member collection only.
            for name in a.PUBLICATION_SOURCES:
                (self.f.pub / name).write_text('artificial source\n')
            for task in self.f.plan['tasks']:
                for field in ('input_file', 'review_file', 'native_numeric_parser_file'):
                    path = self.root / (task['task_id'] + field + '.json')
                    if not path.exists(): path.write_text('{}\n')
                    task[field] = str(path)
            return a.snapshot()

    def test_complete184_with_invalid_deliveries_is_not_a_benchmark_score(self):
        self.f.full_pair()
        result, members, _ = self.snapshot()
        self.assertTrue(result['development_pair_complete'])
        self.assertFalse(result['terminal_partial_failure'])
        self.assertEqual(result['saved_development_outcomes_verified'], 184)
        self.assertEqual(result['models']['base'][0]['native_finite_scalars'], 15)
        self.assertFalse(result['benchmark_score'])
        self.assertTrue(any(name.startswith('raw/development/') for name in members))

    def test_terminal_partial_preserves_unresolved_claim_as_unknown(self):
        self.f.startup('base')
        self.f.task('base', 'P06', 2, invalid_index=0, unresolved=1)
        self.f.closure['unresolved_claims'] = ['artificial-unclosed-claim']
        result, _, _ = self.snapshot()
        self.assertTrue(result['terminal_partial_failure'])
        self.assertEqual(result['saved_development_outcomes_verified'], 2)
        self.assertEqual(result['models']['base'][0]['claimed_files_without_verified_response'], 1)
        self.assertIsNone(result['models']['posttrained'][0]['request_creation_or_dispatch_count'])

    def test_raw_generation_without_startup_is_rejected(self):
        self.f.task('base', 'P06', 1)
        with self.assertRaisesRegex(ValueError, 'startup'):
            self.snapshot()

    def test_false_model_completion_cannot_replace_missing_task(self):
        self.f.full_pair()
        (self.f.dev / 'runtime/base/P06/completion.json').unlink()
        with self.assertRaisesRegex(ValueError, 'missing complete task'):
            self.snapshot()

    def test_completed_allocation_without_pair_requires_explicit_failure(self):
        self.f.closure.update(scheduler_state='COMPLETED', scheduler_exit_code='0:0', terminal_gate_failure=False)
        with self.assertRaisesRegex(ValueError, 'failure reconciliation'):
            self.snapshot()
        self.f.closure.update(terminal_gate_failure=True, failure_reason='artificial validation failure')
        self.assertTrue(self.snapshot()[0]['terminal_partial_failure'])

    def test_complete_pair_with_unresolved_claim_is_rejected(self):
        self.f.full_pair(); self.f.closure['unresolved_claims'] = ['artificial']
        with self.assertRaisesRegex(ValueError, 'unresolved'):
            self.snapshot()

    def test_raw_tampering_rejected_even_with_updated_file_inventory(self):
        self.f.task('base', 'P06', 1)
        path = next(p for p in self.f.inventory if p.parent.name == 'responses')
        row = c.read(path); row['final'] = '999'; path.write_bytes(c.json_bytes(row))
        self.f.inventory[path] = c.sha(path)
        with self.assertRaisesRegex(ValueError, 'normalization'):
            a.task_artifacts('base', self.f.plan['tasks'][0], self.f.plan, self.f.runtime, self.f.inventory)

    def test_completion_range_and_private_field_tampering_rejected(self):
        self.f.task('base', 'P06', 16, complete=True)
        path = self.f.dev / 'runtime/base/P06/completion.json'
        original = c.read(path)
        for change in ({'prediction_maximum': 999}, {'private_note': 'artificial'}, {'benchmark_score': True}):
            path.write_bytes(c.json_bytes({**original, **change}))
            with self.subTest(change=change), self.assertRaises(ValueError):
                a.task_artifacts('base', self.f.plan['tasks'][0], self.f.plan, self.f.runtime, self.f.inventory)

    def test_request_source_or_token_schema_tampering_rejected(self):
        self.f.task('base', 'P06', 1)
        path = next(p for p in self.f.inventory if p.parent.name == 'requests')
        original = c.read(path)
        for change in ({'case': {**original['case'], 'messages': []}}, {'prompt_token_ids': [True]},
                       {'model': 'other-model'}, {'prompt_tokens': 65536}):
            path.write_bytes(c.json_bytes({**original, **change})); self.f.inventory[path] = c.sha(path)
            with self.subTest(change=change), self.assertRaises(ValueError):
                a.task_artifacts('base', self.f.plan['tasks'][0], self.f.plan, self.f.runtime, self.f.inventory)

    def write_closure(self):
        for kind in ('requests', 'responses'):
            self.f.closure[kind] = [{'path': str(path), 'sha256': digest}
                for path, digest in self.f.inventory.items() if path.parent.name == kind]
        self.f.closure['unresolved_claims'] = [str(path) for path in self.f.inventory
            if path.parent.name == 'requests' and path.parent.parent / 'responses' / path.name not in self.f.inventory]
        path = self.f.dev / 'runtime/owner_terminal_closure.json'
        if path.exists(): path.unlink()
        self.f.write(path, self.f.closure)
        lock = self.f.dev / 'runtime/worker.lock'
        if not lock.exists() and not lock.is_symlink(): lock.write_bytes(b'')

    def verify_terminal(self, *, active=False):
        calls = []
        def output(command, **kw):
            calls.append(command)
            return ('123|FAILED|1:0\n' if command[0] == 'sacct'
                    else ('123|RUNNING\n' if active else ''))
        with patch.object(a.subprocess, 'check_output', side_effect=output):
            result = a.terminal_inventory(self.f.plan, 'a' * 64, '123')
        self.assertEqual([row[0] for row in calls], ['sacct', 'squeue'])
        return result

    def test_terminal_proof_reconciles_every_actual_hash_and_unclosed_claim(self):
        self.f.task('base', 'P06', 1, unresolved=1); self.write_closure()
        result, inventory = self.verify_terminal()
        self.assertEqual(len(inventory), 3)
        self.assertEqual(len(result['unresolved_claims']), 1)

    def test_live_allocation_or_changed_raw_file_cannot_archive(self):
        self.f.task('base', 'P06', 1); self.write_closure()
        with self.assertRaisesRegex(ValueError, 'still active'): self.verify_terminal(active=True)
        next(iter(self.f.inventory)).write_text('{}\n')
        with self.assertRaisesRegex(ValueError, 'frozen bytes'): self.verify_terminal()

    def test_missing_original_worker_lock_cannot_skip_fresh_check(self):
        self.write_closure()
        (self.f.dev/'runtime/worker.lock').unlink()
        with self.assertRaises(FileNotFoundError): self.verify_terminal()

    def test_terminal_lock_symlink_is_rejected(self):
        self.write_closure()
        target=self.root/'different_lock';target.write_text('')
        (self.f.dev/'runtime/worker.lock').unlink()
        (self.f.dev/'runtime/worker.lock').symlink_to(target)
        with self.assertRaises(OSError):self.verify_terminal()

    def test_terminal_proof_cannot_hide_claim_or_add_private_body(self):
        self.f.task('base', 'P06', 1, unresolved=1); self.write_closure()
        for change in ({'unresolved_claims': []}, {'private_scheduler_dump': 'artificial'}):
            original = dict(self.f.closure); self.f.closure.update(change); self.write_closure()
            if 'unresolved_claims' in change:
                path = self.f.dev / 'runtime/owner_terminal_closure.json'
                row = c.read(path); row['unresolved_claims'] = []; path.write_bytes(c.json_bytes(row))
            with self.assertRaises(ValueError): self.verify_terminal()
            self.f.closure = original

    def test_missing_terminal_record_reports_unknown_and_does_not_assemble(self):
        self.assertIsNone(a.readiness()['runtime_counts'])
        self.assertFalse(a.readiness()['actual_terminal_closure_present'])
        with patch.object(a, 'verify_freeze', return_value={}), patch.object(a, 'source_review'), \
             patch.object(a, 'snapshot', side_effect=AssertionError('Must not touch runtime')), self.assertRaises(ValueError):
            a.assemble(self.root/'freeze', 'a'*64, self.root/'review', 'b'*64)
        self.assertFalse((self.f.pub / 'assembly_attempt.json').exists())


class ArchiveAndIOTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.root = Path(self.temp.name); self.scanner = Scanner()
    def tearDown(self): self.temp.cleanup()
    def source(self, body=b'{"artificial":true}\n'):
        path = self.root / 'source.json'; path.write_bytes(body); return path

    def test_deterministic_archive_round_trip_and_single_source_mutation(self):
        path = self.source(); members = {'raw/development/base/P06/responses/a.json': (path, c.sha(path))}
        first, index = a.archive_bytes(members, self.scanner)
        second, _ = a.archive_bytes(members, self.scanner); self.assertEqual(first, second)
        target = self.root / 'part.tar.gz'; target.write_bytes(first); a.verify_archive(target, index, self.scanner)
        path.write_text('{}\n')
        with self.assertRaisesRegex(ValueError, 'changed'): a.archive_bytes(members, self.scanner)

    def test_protected_private_or_website_members_are_excluded(self):
        path = self.source()
        for name in ('code/development/scorer_reference.json', 'code/development/private_gpu.json',
                     'docs/index.html', '../escape', '.local/private', 'code/development/model.safetensors'):
            with self.subTest(name=name), self.assertRaises(ValueError):
                a.validate_members({name: (path, c.sha(path))})
        for field in ('safety_identifier', 'private_gpu_audit', 'unrelated_job_exact_identity', 'api_key'):
            path.write_bytes(c.json_bytes({'nested': {field: 'artificial'}}))
            with self.subTest(field=field), self.assertRaises(ValueError):
                a.archive_bytes({'metadata/development/a.json': (path, c.sha(path))}, self.scanner)

    def test_secure_io_rejects_parent_and_leaf_symlinks_overwrite_and_duplicate_json(self):
        real = self.root / 'real'; real.mkdir(); (self.root/'alias').symlink_to(real)
        for path in (self.root/'alias/out', self.root/'alias/new/out'):
            with self.assertRaises(OSError): c.write_bytes(path, b'artificial')
        leaf = real/'file'; c.write_bytes(leaf, b'artificial')
        with self.assertRaises(FileExistsError): c.write_bytes(leaf, b'changed')
        (self.root/'link').symlink_to(leaf)
        with self.assertRaises(OSError): c.regular_bytes(self.root/'link')
        with self.assertRaises(ValueError): c.loads(b'{"x":1,"x":2}')
        with self.assertRaises(ValueError): c.loads(b'{"x":NaN}')

    def test_archive_links_duplicates_traversal_and_size_rejected(self):
        target = self.root / 'bad.tar.gz'
        for names, link in ((['../outside'], False), (['raw/development/a','raw/development/a'], False),
                            (['raw/development/link'], True)):
            with tarfile.open(target, 'w:gz') as archive:
                for name in names:
                    item = tarfile.TarInfo(name); item.mode = 0o644
                    if link: item.type=tarfile.SYMTYPE; item.linkname='artificial'; archive.addfile(item)
                    else: item.size=2; archive.addfile(item,io.BytesIO(b'{}'))
            with self.assertRaises(ValueError): a.verify_archive(target, {}, self.scanner)
        path = self.source(b'x'*128)
        with self.assertRaises(ValueError): a.partition({'raw/development/a':(path,c.sha(path))},limit=64)
        with patch.object(c, 'MAX_PART_BYTES', 64), self.assertRaises(ValueError):
            a.archive_bytes({'raw/development/a':(path,c.sha(path))},self.scanner)

    def test_archive_public_union_cannot_expand_into_main_docs(self):
        paths = c.expected_public_paths(1)
        c.validate_paths(paths,1)
        for bad in ('reports/RESULTS_AND_REMAINING_WORK.md','reports/ENGINEERING_PROGRESS.md','docs/index.html'):
            with self.assertRaises(ValueError): c.validate_paths(set(paths)|{bad},1)

    def test_source_review_rejects_self_or_runtime_publication_authority(self):
        review = {'approved':True, 'reviewer':'/root/independent_review', 'source_freeze_sha256':'a'*64,
            'plan_sha256':c.PLAN_SHA, 'pair_id':c.PAIR_ID, 'publishing_authorized':False, 'operational_config_sha256':c.OP_CONFIG_SHA,
             'root_authorization_sha256':c.AUTH_SHA}
        path = self.root/'review.json'; path.write_bytes(c.json_bytes(review))
        a.source_review(path,c.sha(path),'a'*64)
        for change in ({'reviewer':c.EXPORT_AUTHOR},{'publishing_authorized':True},{'plan_sha256':'b'*64}):
            path.write_bytes(c.json_bytes({**review,**change}))
            with self.assertRaises(ValueError): a.source_review(path,c.sha(path),'a'*64)


class AuthorityAndManifestTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.root = Path(self.temp.name)
        self.dev = self.root / 'dev'; self.pub = self.dev / 'publication'; self.pub.mkdir(parents=True)
        self.stack = contextlib.ExitStack()
        self.stack.enter_context(patch.object(c, 'DEV', self.dev))
        self.stack.enter_context(patch.object(c, 'HERE', self.pub))
    def tearDown(self): self.stack.close(); self.temp.cleanup()

    def test_closed_authority_ignores_generation_stop_but_rechecks_all_bound_bytes(self):
        operational_dir = self.pub.parent
        source = operational_dir/'source.py'; source.write_text('# invented source\n')
        authority = operational_dir/'root.json'; c.write_json(authority, {'invented':'root authority'})
        admission = operational_dir/'independent_runtime_admission.json'
        c.write_json(admission, {'invented':'independent admission'})
        release = operational_dir/'release.json'; c.write_json(release, {'invented':'release'})
        shared = operational_dir/'shared.json'
        fields = {'resource_adapter':{'path':'invented','sha256':'a'*64},
            'additional_root_proofs':[{'path':'invented proof','sha256':'b'*64}],
            'additional_proof_binding':{'path':'invented binding','sha256':'c'*64},
            'root_authorization':{'path':str(authority),'sha256':c.sha(authority)},'project_GPU_ceiling':8}
        c.write_json(shared, fields)
        config_path = operational_dir/'config.json'
        config = {**fields,'source_sha256':{str(source):c.sha(source)},
            'shared_resource_binding':{'path':str(shared),'sha256':c.sha(shared)},
            'priority_release':{'path':str(release),'sha256':c.sha(release)}}
        c.write_json(config_path, config)
        (operational_dir/'STOP').write_text('invented generation STOP')
        calls=[]
        operational = types.SimpleNamespace(check_authority=lambda *unused:calls.append('authority'),
            check_release=lambda *unused:calls.append('release'),
            validate=lambda *unused:(_ for _ in ()).throw(AssertionError('No generation STOP gate')))
        with patch.object(c,'OP_CONFIG',config_path),patch.object(c,'OP_CONFIG_SHA',c.sha(config_path)), \
             patch.object(c,'AUTH_SHA',c.sha(authority)),patch.object(c,'OP_ADMISSION_SHA',c.sha(admission)):
            result=a.closed_operational_authority(operational)
            self.assertEqual(calls,['authority','release'])
            self.assertEqual(result['_admission_sha256'],c.sha(admission))
            for path in (source,authority,admission,release,shared):
                original=path.read_bytes();path.write_bytes(original+b' ')
                with self.subTest(path=path.name),self.assertRaises(ValueError):
                    a.closed_operational_authority(operational)
                path.write_bytes(original)

    def actual_fixture(self):
        run = self.dev / 'runtime'; grant = self.dev / 'grant.json'; c.write_json(grant, {'artificial': True})
        release = {'path':str(self.dev/'priority_release.json'),'sha256':'a'*64}
        shared = {'operational_config_sha256':c.OP_CONFIG_SHA, 'root_authorization_sha256':c.AUTH_SHA,
            'independent_runtime_admission_sha256':c.OP_ADMISSION_SHA, 'automatic_retry':False}
        command = ['sbatch','--parsable','--export=NONE',str(c.OP_WORKER),c.OP_CONFIG_SHA]
        c.write_json(run/'submission_attempt.json', {'at_epoch':123.0,'command':command,
            'old_plan_sha256':c.PLAN_SHA,'old_grant_sha256':c.GRANT_SHA,**shared})
        c.write_json(run/'submission.json', {'at_epoch':123.0,'job_id':'123','plan_sha256':c.PLAN_SHA,
            'grant_sha256':c.GRANT_SHA,'requested_GPUs':1,'returncode':0,'stdout':'123','stderr':'',**shared})
        runtime = types.SimpleNamespace()
        config = {'_admission_sha256':c.OP_ADMISSION_SHA,'old_grant':str(grant),'priority_release':release}
        operational = types.SimpleNamespace(validate=lambda unused:config,
            old_science=lambda unused:(runtime,{},{},None,{}))
        return run, operational

    def test_actual_authority_requires_exact_restored_worker_plan_grant_and_admission(self):
        run, operational = self.actual_fixture()
        with patch.object(a,'require_hash'),patch.object(c,'load',return_value=operational), \
             patch.object(a,'closed_operational_authority',return_value=operational.validate(None)):
            self.assertEqual(a.actual_authority()[6],'123')
            path = run/'submission_attempt.json'; original=c.read(path)
            for index, changed in ((3,str(self.dev/'different_worker')), (4,'b'*64)):
                row=copy.deepcopy(original);row['command'][index]=changed;path.write_bytes(c.json_bytes(row))
                with self.subTest(index=index),self.assertRaises(ValueError):a.actual_authority()
            path.write_bytes(c.json_bytes(original))
            submitted=run/'submission.json'; original=c.read(submitted)
            for change in ({'grant_sha256':'b'*64},{'root_authorization_sha256':'b'*64},
                           {'independent_runtime_admission_sha256':'b'*64},{'stderr':'unreviewed metadata'},
                           {'operational_config_sha256':'b'*64},{'automatic_retry':True}):
                submitted.write_bytes(c.json_bytes({**original,**change}))
                with self.subTest(change=change),self.assertRaises(ValueError):a.actual_authority()

    def test_preparation_without_actual_submission_is_not_dispatch_evidence(self):
        with patch.object(a,'require_hash'),patch.object(c,'load',side_effect=AssertionError('No runtime')):
            with self.assertRaises(FileNotFoundError):a.actual_authority()
        self.assertIsNone(a.readiness()['runtime_counts'])

    def assembled_fixture(self):
        source=self.root/'raw.json';source.write_bytes(b'{"artificial":true}\n')
        members={'raw/development/base/P06/responses/artificial.json':(source,c.sha(source))}
        models={model:[d.summarize_task(task,[],request_files=[],terminal_closure=True,task_complete=False)
                       for task in d.TASK_COUNTS] for model in d.MODELS}
        summary=d.pair_summary(models,pair_completion_verified=False,terminal_failure_verified=True)
        summary['prior_Base24_separate_condition']={'saved_partial_outcomes':24}
        bindings={'grant_sha256':'a'*64,'owner_terminal_closure_sha256':'b'*64}
        self.stack.enter_context(patch.object(a,'verify_freeze',return_value={'files_sha256':{}}))
        self.stack.enter_context(patch.object(a,'source_review',return_value={}))
        self.stack.enter_context(patch.object(a,'readiness',return_value={'actual_terminal_closure_present':True}))
        self.stack.enter_context(patch.object(a,'snapshot',return_value=(summary,members,bindings)))
        self.stack.enter_context(patch.object(c,'load',return_value=Scanner()))
        manifest=a.assemble(self.root/'freeze.json','a'*64,self.root/'review.json','b'*64)
        return manifest

    def test_assembly_creates_only_fixed_artifacts_and_cannot_silently_retry(self):
        manifest=self.assembled_fixture()
        self.assertTrue(manifest['terminal_partial_failure']);self.assertFalse(manifest['benchmark_score'])
        self.assertEqual(set(manifest['files_sha256']),c.expected_public_paths(manifest['archive_count']))
        self.assertFalse((self.pub/'publication_receipt.json').exists())
        with self.assertRaises(FileExistsError):a.assemble(self.root/'freeze','a'*64,self.root/'review','b'*64)

    def test_rehashed_false_diagnostics_still_fail_actual_snapshot_comparison(self):
        manifest=self.assembled_fixture();name=c.PREFIX+'delivery_diagnostics.json';path=self.pub/'stage'/name
        row=c.read(path);row['development_pair_complete']=True;path.write_bytes(c.json_bytes(row))
        manifest['files_sha256'][name]=c.sha(path);target=self.pub/'manifest.json';target.write_bytes(c.json_bytes(manifest))
        with self.assertRaisesRegex(ValueError,'differs from actual'):a.check(target,c.sha(target))

    def test_rehashed_unexpected_archive_member_is_not_accepted_as_actual_raw_evidence(self):
        manifest=self.assembled_fixture();stage=self.pub/'stage';name=c.ARCHIVE_PREFIX+'part00001.tar.gz'
        wrong=self.root/'wrong.json';wrong.write_text('{}\n')
        raw,index=a.archive_bytes({'raw/development/base/P06/responses/unapproved.json':(wrong,c.sha(wrong))},Scanner())
        (stage/name).write_bytes(raw);manifest['files_sha256'][name]=c.digest(raw)
        index_path=stage/(c.PREFIX+'archive_index.json');packet=c.read(index_path)
        packet['archives'][0]={'path':name,'sha256':c.digest(raw),'bytes':len(raw),'members':index}
        index_path.write_bytes(c.json_bytes(packet));manifest['files_sha256'][c.PREFIX+'archive_index.json']=c.sha(index_path)
        manifest['archive_index_sha256']=c.sha(index_path);target=self.pub/'manifest.json';target.write_bytes(c.json_bytes(manifest))
        with self.assertRaisesRegex(ValueError,'actual exact raw/source whitelist'):a.check(target,c.sha(target))


if __name__ == '__main__': unittest.main(verbosity=2)
