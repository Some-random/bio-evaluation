"""Matched property-lane invariants, independent of the model runtime.

No targets are loaded by the generator-facing helpers in this module. Historical
complete input messages and native single-number parsers remain unchanged.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from zoneinfo import ZoneInfo


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def write_once(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(encoded(value))
        handle.flush()
        import os
        os.fsync(handle.fileno())
    directory = os.open(str(path.parent), os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def now():
    return datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()


def require_hash(path, expected):
    if sha(path) != expected:
        raise ValueError("Pinned file changed: " + str(path))


def load_native_parser(task):
    path = Path(task["native_numeric_parser_file"])
    require_hash(path, task["native_numeric_parser_sha256"])
    spec = importlib.util.spec_from_file_location("native_" + task["task_id"], path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.parse_number


def read_inputs(task):
    """Read only the historically reviewed solver packet, never references."""
    require_hash(task["input_file"], task["input_sha256"])
    require_hash(task["review_file"], task["review_sha256"])
    cases = [json.loads(line) for line in Path(task["input_file"]).read_text().splitlines()]
    review = json.loads(Path(task["review_file"]).read_text())
    ids = [case["case_id"] for case in cases]
    if len(cases) != task["planned"] or len(set(ids)) != len(ids):
        raise ValueError("Incomplete or duplicate property cohort")
    if ids != review["approved_case_ids"] or review.get("held_cases"):
        raise ValueError("Cohort differs from the prior reviewed ordinary scope")
    for case in cases:
        if set(case) != {"task_id", "case_id", "messages"} or case["task_id"] != task["task_id"]:
            raise ValueError("Unexpected solver fields")
        if len(case["messages"]) != 1:
            raise ValueError("Historical single user message changed")
        msg = case["messages"][0]
        if set(msg) != {"role", "content"} or msg["role"] != "user" or not isinstance(msg["content"], str):
            raise ValueError("Historical text-only message schema changed")
    return cases


def parse_prediction(result, parse_number):
    """Apply the frozen native scalar parser to the shared final region only."""
    if result.get("finish_reason") != "stop" or result.get("status") != "response_saved":
        return None
    if result.get("format_errors") or result.get("refusal") or result.get("tool_calls"):
        return None
    final = result.get("final")
    if not isinstance(final, str):
        return None
    value = parse_number(final)
    return value if value is not None and math.isfinite(value) else None


def average_ranks(values):
    ordered = sorted(range(len(values)), key=values.__getitem__)
    ranks = [0.0] * len(values)
    index = 0
    while index < len(ordered):
        end = index + 1
        while end < len(ordered) and values[ordered[end]] == values[ordered[index]]:
            end += 1
        rank = (index + 1 + end) / 2.0
        for position in range(index, end):
            ranks[ordered[position]] = rank
        index = end
    return ranks


def spearman(targets, predictions):
    if len(targets) != len(predictions) or len(targets) < 2:
        return None
    if any(not math.isfinite(x) for x in targets + predictions):
        raise ValueError("Spearman requires finite native values")
    a, b = average_ranks(targets), average_ranks(predictions)
    amean, bmean = sum(a) / len(a), sum(b) / len(b)
    ac, bc = [x - amean for x in a], [x - bmean for x in b]
    denominator = math.sqrt(sum(x*x for x in ac) * sum(x*x for x in bc))
    return sum(x*y for x, y in zip(ac, bc)) / denominator if denominator else None


def metrics(targets, predictions):
    if len(targets) != len(predictions) or not targets:
        raise ValueError("Full matching cohort arrays required")
    pairs = [(target, pred) for target, pred in zip(targets, predictions) if pred is not None]
    value = spearman([x for x, _ in pairs], [y for _, y in pairs])
    complete = len(pairs) == len(targets)
    return {
        "planned": len(targets), "valid_predictions": len(pairs),
        "invalid_or_missing": len(targets) - len(pairs),
        "spearman": value if complete else None,
        "spearman_parsed_only": value if not complete else None,
        "undefined_constant_or_insufficient": value is None,
        "aggregation": "one global Spearman with average ranks for ties",
        "target_transform": "none", "prediction_transform": "none",
        "invalid_policy": "No fill values, calibration, sign changes or selective retries. Incomplete parsed-only correlation is separate from the full-cohort primary."
    }


def seal_task(run, task, plan_sha256, model):
    """Seal every actual generation artifact before permitting reference access."""
    run = Path(run)
    cases = read_inputs(task)
    results, files = [], {}
    for case in cases:
        key = hashlib.sha256(case["case_id"].encode()).hexdigest()
        request_path, response_path = run / "requests" / (key + ".json"), run / "responses" / (key + ".json")
        if not request_path.exists() or not response_path.exists():
            raise ValueError("Task is not terminal; absent or ambiguous generation remains unsealed")
        request, response = json.loads(request_path.read_text()), json.loads(response_path.read_text())
        if request["case_id"] != case["case_id"] or request["messages"] != case["messages"]:
            raise ValueError("Dispatched message differs from the complete frozen source")
        if request["task_id"] != task["task_id"] or request["plan_sha256"] != plan_sha256 or request["model"] != model:
            raise ValueError("Request identity differs")
        if response["case_id"] != case["case_id"] or response["task_id"] != task["task_id"] or response["request_sha256"] != sha(request_path):
            raise ValueError("Response request provenance differs")
        if response.get("status") not in {"response_saved", "runtime_error", "transport_error", "http_error", "response_error"}:
            raise ValueError("Nonterminal response cannot be sealed")
        results.append(response)
        files[str(request_path.relative_to(run))] = sha(request_path)
        files[str(response_path.relative_to(run))] = sha(response_path)
    for directory in ("requests", "responses"):
        actual = {str(p.relative_to(run)) for p in (run / directory).glob("*") if p.is_file()}
        recorded = {name for name in files if name.startswith(directory + "/")}
        if actual != recorded:
            raise ValueError("Unrecognized generation artifact in " + directory)
    lock = {"task_id": task["task_id"], "model": model, "plan_sha256": plan_sha256,
            "planned": len(cases), "terminal": len(results), "reference_labels_opened": False,
            "sealed_at_pacific": now(), "files_sha256": files}
    write_once(run / "prediction_lock.json", lock)
    counts = dict(Counter(result["status"] for result in results))
    completion = {"task_id": task["task_id"], "model": model, "plan_sha256": plan_sha256,
                  "planned": len(cases), "attempted": len(cases), "terminal": len(results),
                  "responses_saved": counts.get("response_saved", 0), "statuses": counts,
                  "truncations": sum(x.get("finish_reason") == "length" for x in results),
                  "empty_finals": sum(not isinstance(x.get("final"), str) or not x["final"].strip() for x in results),
                  "transport_or_server_errors": sum(x.get("status") != "response_saved" for x in results),
                  "prediction_lock_sha256": sha(run / "prediction_lock.json"),
                  "completed_at_pacific": now()}
    write_once(run / "completion.json", completion)
    return completion


def score_sealed_task(run, task, plan_sha256, model, response_validator=None):
    run = Path(run)
    if (run / "scores.json").exists():
        raise ValueError("One scoring attempt only; existing score must remain immutable")
    cases = read_inputs(task)
    completion = json.loads((run / "completion.json").read_text())
    require_hash(run / "prediction_lock.json", completion["prediction_lock_sha256"])
    lock = json.loads((run / "prediction_lock.json").read_text())
    if (lock["task_id"] != task["task_id"] or lock["plan_sha256"] != plan_sha256 or lock["model"] != model or lock["reference_labels_opened"] is not False
            or lock["planned"] != len(cases) or lock["terminal"] != len(cases)):
        raise ValueError("Complete matching prediction lock required before target access")
    for key, expected in {"task_id": task["task_id"], "model": model, "plan_sha256": plan_sha256,
                          "planned": len(cases), "attempted": len(cases), "terminal": len(cases)}.items():
        if completion.get(key) != expected:
            raise ValueError("Completion identity/count differs from the exact output lock: " + key)
    for name, digest in lock["files_sha256"].items():
        path = (run / name).resolve()
        if not path.is_relative_to(run.resolve()):
            raise ValueError("Unsafe seal path")
        require_hash(path, digest)
    for directory in ("requests", "responses"):
        actual = {str(p.relative_to(run)) for p in (run / directory).glob("*") if p.is_file()}
        recorded = {name for name in lock["files_sha256"] if name.startswith(directory + "/")}
        if actual != recorded:
            raise ValueError("Generation artifact added after prediction lock")
    parser = load_native_parser(task)
    predictions, responses = [], []
    for case in cases:
        key = hashlib.sha256(case["case_id"].encode()).hexdigest()
        request = json.loads((run / "requests" / (key + ".json")).read_text())
        response = json.loads((run / "responses" / (key + ".json")).read_text())
        if (request["messages"] != case["messages"] or request["case_id"] != case["case_id"]
                or request["model"] != model or request["plan_sha256"] != plan_sha256 or request["task_id"] != task["task_id"]):
            raise ValueError("Frozen prompt identity mismatch")
        if (response["request_sha256"] != sha(run / "requests" / (key + ".json"))
                or response["case_id"] != case["case_id"] or response["task_id"] != task["task_id"]):
            raise ValueError("Response is not linked to its saved request")
        if response.get("status") not in {"response_saved", "runtime_error", "transport_error", "http_error", "response_error"}:
            raise ValueError("Nonterminal response cannot be scored")
        if response_validator is not None:
            response_validator(case, request, response)
        predictions.append(parse_prediction(response, parser))
        responses.append(response)
    statuses = dict(Counter(result["status"] for result in responses))
    recomputed = {"statuses": statuses, "responses_saved": statuses.get("response_saved", 0),
                  "truncations": sum(x.get("finish_reason") == "length" for x in responses),
                  "empty_finals": sum(not isinstance(x.get("final"), str) or not x["final"].strip() for x in responses),
                  "transport_or_server_errors": sum(x.get("status") != "response_saved" for x in responses)}
    if any(completion.get(key) != expected for key, expected in recomputed.items()):
        raise ValueError("Completion delivery counts differ from sealed raw responses")
    write_once(run / "scoring_attempt.json", {"started_at_pacific": now(),
               "plan_sha256": plan_sha256, "prediction_lock_sha256": sha(run / "prediction_lock.json"),
               "policy": "One native scoring attempt after full seal; preserve any failure, no automatic scoring rerun."})
    # Scorer-only references are first opened after the exact full output seal.
    require_hash(task["scorer_reference_file"], task["scorer_reference_sha256"])
    references = [json.loads(line) for line in Path(task["scorer_reference_file"]).read_text().splitlines()]
    if [ref["case_id"] for ref in references] != [case["case_id"] for case in cases]:
        raise ValueError("Reference/source order mismatch")
    if any(ref[task["reference_task_key"]] != task["task_id"] for ref in references):
        raise ValueError("Reference task mismatch")
    targets = [ref[task["reference_target_key"]] for ref in references]
    if task["reference_target_encoding"] == "source_numeric_string":
        if any(not isinstance(value, str) for value in targets):
            raise ValueError("Reference source strings changed schema")
        targets = [float(value) for value in targets]
    elif task["reference_target_encoding"] != "json_number":
        raise ValueError("Unknown reference encoding")
    if any(type(x) not in (int, float) or not math.isfinite(x) for x in targets):
        raise ValueError("Invalid native reference")
    result = {"task_id": task["task_id"], "evaluation": task["evaluation"], "model": model,
              "plan_sha256": plan_sha256, "scored_at_pacific": now(),
              "prediction_lock_sha256": sha(run / "prediction_lock.json"),
              "scorer_reference_sha256": task["scorer_reference_sha256"],
              "native_numeric_parser_sha256": task["native_numeric_parser_sha256"],
              "metrics": metrics(targets, predictions), "completion": completion,
              "historical_runs_changed": False, "new_model_calls_by_scorer": 0,
              "interpretation": "Zero-shot complete-sequence experimental property prediction; native Spearman and target scale preserved. Supervised specialist training, biological explanations and contamination-free inference are not established."}
    write_once(run / "scores.json", result)
    return result
