"""Prospective official-validation delivery probe. No benchmark or target access."""
from pathlib import Path
import argparse
from collections import Counter
import fcntl
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
OLD = HERE.parent / 'recommended_sampling_v2'
sys.path.insert(0, str(OLD))
from scalar_lane import encoded, load_native_parser, now, read_inputs, sha, write_once

ROLE = 'property_official_validation_nonthinking_regex256_delivery_only'
REGEX = r'[+-]?[0-9]{1,12}(\.[0-9]{1,12})?([eE][+-]?[0-9]{1,2})?'
BASE_PLAN_SHA = '047920b73d24c54e9243ec488b10b1df15990fde4bbc8daf945cf5016a30abc6'
POST_REQUEST = 'qwen35-properties-posttrained-author-general-thinking-v2'
SCOPE_SHA = 'be50fcf7b041aa262ce84ba0f1e7c9d083c0232d0b7f9352edb081fd8d254470'
GRANT_ISSUERS = {'/root/independent_review','/root/new2026_bixbench'}
PRIORITY_SHA = '4a7a0af77a9f0031363ef90769505d80a3439c1e6d9a0dab724b153121407229'


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def pinned(path, expected):
    path = Path(path)
    if path.is_symlink() or path.resolve() != path or not path.is_file() or sha(path) != expected:
        raise ValueError('Canonical frozen file changed: ' + str(path))
    return path


def required_pin(grant, name, expected_path):
    row = grant[name]
    if (not isinstance(row,dict) or set(row)!={'path','sha256'}
            or row['path'] != str(expected_path)
            or row not in grant['required_prior_closure_artifacts']):
        raise ValueError('Exact canonical prior proof must be explicitly pinned: '+name)
    return pinned(row['path'],row['sha256'])


def resource_audit(plan,additional=0,own=False):
    source=Path(plan['resource_adapter']['path'])
    pinned(source,plan['resource_adapter']['sha256'])
    helper=load(source,'property_dev_exact_resource_adapter')
    result=helper.capacity_audit(additional=additional,override=False,require_own_job=own,
        additional_root_proofs=plan['additional_root_proofs'],
        additional_proof_binding=plan['additional_proof_binding'])
    if (result.get('project_GPU_ceiling')!=8 or result.get('additional_GPUs')!=additional):
        raise ValueError('Different bounded project GPU accounting')
    count=result.get('project_requested_GPUs_with_addition')
    base=result.get('project_requested_GPUs')
    if type(count)is not int or type(base)is not int or base<0 or count!=base+additional:
        raise ValueError('Malformed explicit integer GPU accounting')
    if count>8 or result.get('capacity_available')is not True:
        raise ValueError('Evaluation project GPU requests exceed eight')
    return result


def priority_release(plan,plan_sha,grant_sha):
    reservation=plan['priority_reservation']
    if reservation!={'path':str(ROOT/'.local/qwen_priority_20261022.json'),'sha256':PRIORITY_SHA}:
        raise ValueError('Different root priority reservation')
    pinned(reservation['path'],reservation['sha256'])
    path=Path(plan['priority_release_path'])
    if path!=HERE/'priority_release.json':raise ValueError('Different canonical priority-release path')
    if not path.exists():raise PermissionError('LPB/LABBench2 priority active; no property submitter or GPU waiter allowed')
    raw=path.read_bytes();release_sha=hashlib.sha256(raw).hexdigest()
    pinned(path,release_sha)
    release=json.loads(raw)
    if (release.get('issuer')!='/root' or release.get('approved')is not True
            or release.get('role')!='exact_bound_lower_priority_lane_release'
            or release.get('lane')!='4B property184 development'
            or release.get('priority_reservation_sha256')!=PRIORITY_SHA
            or release.get('root_scope_adoption_sha256')!=SCOPE_SHA
            or release.get('plan_sha256')!=plan_sha or release.get('runtime_grant_sha256')!=grant_sha
            or release.get('maximum_model_calls')!=184
            or set(release.get('acknowledged_priority_suites',[]))
               !={'LiveProteinBench','LABBench2_BASIC_closed_book_text'}
            or release.get('generation_judge_delivery_repair_prerequisites_acknowledged')is not True):
        raise PermissionError('Exact root release acknowledging both priority-suite prerequisites is required')
    return {'path':str(path),'sha256':release_sha}


def verify_prior_closures(grant):
    for row in grant['required_prior_closure_artifacts']:
        pinned(row['path'],row['sha256'])
    old = OLD/'runtime'/'base'
    path=required_pin(grant,'prior_Base_terminal_closure',OLD/'drain_boundary24_v2'/'terminal_closure.json')
    closure=json.loads(path.read_text())
    if (closure.get('job_id')!='247446' or closure.get('plan_sha256')!=BASE_PLAN_SHA
            or closure.get('terminal_verified')is not True
            or closure.get('all_claims_have_saved_responses')is not True
            or closure.get('active_calls_interrupted')is not False
            or closure.get('native_benchmark_score_created')is not False
            or closure.get('attempt_claims')!=24 or closure.get('responses_saved')!=24
            or closure.get('pending_claims')!=0 or closure.get('all37_frozen_plan_pins_match')is not True):
        raise ValueError('Actual safe prior Base drain closure required')
    for key in ['drain_root_grant','drain_application']:
        row=closure[key]
        if row not in grant['required_prior_closure_artifacts']:
            raise ValueError('Prior Base root/application authority is not pinned')
        pinned(row['path'],row['sha256'])
    for kind in ['requests','responses']:
        rows=closure[kind];directory=old/'P06'/kind
        if len(rows)!=24 or set(directory.glob('*.json'))!={Path(row['path'])for row in rows}:
            raise ValueError('Prior Base claims/outcomes changed')
        for row in rows:pinned(row['path'],row['sha256'])
    with (old/'worker.lock').open('rb')as lock:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    if (old/'P06'/'requests').stat().st_mode&0o222:
        raise ValueError('Prior request-creation guard was restored')
    row=subprocess.check_output(['sacct','-j','247446','-n','-X','--format=JobID,State,ExitCode','--parsable2'],text=True).strip()
    if row!='247446|FAILED|1:0':raise ValueError('Prior Base scheduler terminal proof changed')
    queue=OLD.parents[1]/'queue'
    path=required_pin(grant,'prior_Post_withdrawal_receipt',queue/'property_post_withdrawal_20261022'/'withdrawal_complete.json')
    withdrawal=json.loads(path.read_text())
    if (withdrawal.get('role')!='root_restricted_unsubmitted_property_post_withdrawal'
            or withdrawal.get('request_id')!=POST_REQUEST or withdrawal.get('completed')is not True
            or withdrawal.get('administrative_withdrawn')is not True or withdrawal.get('GPU_submissions')!=0
            or withdrawal.get('automatic_restore')is not False):
        raise ValueError('Actual never-submitted Post withdrawal proof required')
    authority=withdrawal['root_decision']
    if authority not in grant['required_prior_closure_artifacts']:
        raise ValueError('Post restriction root authority is not pinned')
    decision=json.loads(pinned(authority['path'],authority['sha256']).read_text())
    if decision.get('issuer')!='/root' or decision.get('approved')is not True:
        raise ValueError('Post withdrawal root authority differs')
    for key in ['archived_state','archived_accepted']:
        item=withdrawal[key];pinned(item['path'],item['sha256'])
    prior=json.loads(Path(withdrawal['archived_state']['path']).read_text())
    if prior.get('submission_attempts')!=0 or prior.get('job_id')is not None:
        raise ValueError('Old Post was not unsubmitted')
    if (queue/'accepted'/(POST_REQUEST+'.json')).exists():raise ValueError('Old Post ticket is active again')
    state=json.loads((queue/'states'/(POST_REQUEST+'.json')).read_text())
    if (state.get('stage')!='error_requires_review' or state.get('administrative_withdrawn')is not True
            or state.get('withdrawal_provisional')is not False or state.get('submission_attempts')!=0
            or state.get('job_id')is not None or state.get('automatic_retry')is not False
            or state.get('withdrawal_receipt_sha256')!=grant['prior_Post_withdrawal_receipt']['sha256']):
        raise ValueError('Old Post is not durably held')
    native=OLD/'runtime'/'posttrained';guard=withdrawal['submission_guard'];actual=native.stat()
    # st_dev is a host-local mount identifier and is not portable from the
    # login-node withdrawal to an allocated compute node. Canonical path,
    # distributed-file inode, owner and restrictive mode stay exact.
    if (str(native)!=guard['path'] or native.resolve()!=native or native.is_symlink()
            or (actual.st_ino,actual.st_uid,actual.st_mode&0o777)
            !=(guard['inode'],guard['uid'],0o500)):
        raise ValueError('Old Post submission guard changed')
    if any((native/name).exists()for name in ['submission_attempt.json','submission.json','started.json','session_ready.json']):
        raise ValueError('Old Post unexpectedly dispatched')


def validate(plan_path, plan_sha, grant_path, grant_sha):
    plan_path = pinned(plan_path, plan_sha)
    grant_path = pinned(grant_path, grant_sha)
    plan = json.loads(plan_path.read_text())
    grant = json.loads(grant_path.read_text())
    if plan['root_scope_adoption']!={'path':str(HERE/'root_development_scope_adoption_20261022.json'),'sha256':SCOPE_SHA}:
        raise ValueError('Different canonical root scientific adoption')
    scope_path=pinned(plan['root_scope_adoption']['path'],SCOPE_SHA)
    scope=json.loads(scope_path.read_text())
    if (scope.get('issuer')!='/root' or scope.get('approved')is not True
            or scope.get('role')!='bounded_official_development_delivery_scientific_scope_adoption_not_dispatch'
            or scope.get('maximum_total_model_calls')!=184
            or scope.get('no_reference_labels_or_correctness_scoring')is not True
            or scope.get('benchmark_test_dispatch_authorized')is not False):
        raise ValueError('Exact root development-only scientific scope required')
    if (grant.get('issuer') not in GRANT_ISSUERS or grant.get('approved') is not True
            or grant.get('role') != ROLE or grant.get('plan_sha256') != plan_sha
            or grant.get('plan_path') != str(plan_path) or grant.get('maximum_model_calls') != 184
            or grant.get('root_scope_adoption_sha256')!=SCOPE_SHA
            or grant.get('conditional_on_priority_release')is not True
            or grant.get('benchmark_dispatch_authorized') is not False
            or grant.get('correctness_scoring_authorized') is not False):
        raise ValueError('Exact root development-only grant is required')
    review=grant['independent_review']
    reviewed=json.loads(pinned(review['path'],review['sha256']).read_text())
    if (reviewed.get('reviewer')!=grant['issuer'] or reviewed.get('approved')is not True
            or reviewed.get('plan_sha256')!=plan_sha
            or reviewed.get('root_scope_adoption_sha256')!=SCOPE_SHA):
        raise ValueError('Independent exact-plan technical review is required')
    for path, expected in plan['pins'].items():
        pinned(path, expected)
    if (plan['role'] != ROLE or plan['condition']!=scope['condition'] or plan['planned_cases_per_model'] != 92
            or plan['model_order'] != ['base', 'posttrained']
            or [(t['task_id'],t['planned']) for t in plan['tasks']] != [('P06',16),('P08',12),('P07',64)]
            or plan['run_dir'] != str(HERE / 'runtime') or plan['batch_size'] != 8
            or plan['context_limit'] != 65536 or plan['max_tokens'] != 256
            or plan['enable_thinking'] is not False or plan['regex'] != REGEX):
        raise ValueError('Different bounded development condition')
    if any('scorer_reference' in key or key in {'reference_file','target_file'}
           for task in plan['tasks'] for key in task):
        raise ValueError('Development solver must not receive reference locations')
    verify_prior_closures(grant)
    expected_post={key:scope['prior_Post_withdrawal'][key]for key in ['path','sha256']}
    if (grant['prior_Base_terminal_closure']['sha256']!=scope['prior_Base']['terminal_closure_sha256']
            or grant['prior_Post_withdrawal_receipt']!=expected_post):
        raise ValueError('Prior closure differs from the root scientific adoption')
    common = load(plan['shared_runtime_file'], 'property_dev_shared_runtime')
    contract = common.load_contract(plan['contract_file'], plan['contract_sha256'])
    generation = dict(contract['generation'])
    generation.pop('return_token_ids',None);generation.pop('add_special_tokens',None)
    generation.update(max_tokens=256,structured_outputs={'regex':REGEX})
    if plan['generation'] != generation:
        raise ValueError('Different fixed scalar-delivery sampling parameters')
    for task in plan['tasks']:
        read_inputs(task)
        load_native_parser(task)
    return plan, grant, common, contract


def normalize(raw, token_ids, finish_reason, stop_reason, parser):
    errors = []
    final = raw
    for marker in ('<|im_end|>', '<|endoftext|>'):
        if marker in final:
            final, _, tail = final.partition(marker)
            if tail.strip():errors.append('unexpected_after_stop')
    if any(marker in raw for marker in ('<think>','</think>','<|im_start|>','<tool_call>','</tool_call>')):
        errors.append('unexpected_reasoning_role_or_tool')
    final = final.strip()
    if finish_reason != 'stop':errors.append('not_normally_stopped')
    if not re.fullmatch(REGEX, final):errors.append('outside_fixed_scalar_grammar')
    value = parser(final) if not errors else None
    if value is None:errors.append('invalid_native_scalar')
    valid_final = final if not errors else ''
    return {'raw_text':raw,'token_ids':token_ids,'finish_reason':finish_reason,'stop_reason':stop_reason,
            'final':valid_final, 'prediction':value,'format_errors':errors,
            'truncated':finish_reason=='length','empty_final':not bool(valid_final),
            'completion_tokens':len(token_ids),'reasoning_expected':False}


def phase(args, plan, common, contract):
    from transformers import AutoTokenizer
    from vllm import LLM, SamplingParams
    from vllm.sampling_params import StructuredOutputsParams
    model = contract['models'][args.model_key]
    directory = common.validate_checkpoint(args.model_key, contract)
    tokenizer = AutoTokenizer.from_pretrained(directory, local_files_only=True, trust_remote_code=False)
    if hashlib.sha256(tokenizer.chat_template.encode()).hexdigest() != contract['chat_template_sha256']:
        raise ValueError('Publisher chat template changed')
    kwargs = dict(plan['generation'])
    kwargs['structured_outputs'] = StructuredOutputsParams(regex=REGEX)
    params = SamplingParams(**kwargs)
    llm = LLM(model=str(directory),tokenizer=str(directory),trust_remote_code=False,dtype='bfloat16',
              tensor_parallel_size=1,max_model_len=65536,max_num_seqs=8,max_num_batched_tokens=8192,
              gpu_memory_utilization=0.9,enforce_eager=True,enable_prefix_caching=False,
              limit_mm_per_prompt={'image':0,'video':0})
    run = Path(plan['run_dir']) / args.model_key
    write_once(run/'session_ready.json',{'at_pacific':now(),'model_key':args.model_key,
               'model':model['name'],'revision':model['revision'],'job_id':os.environ['SLURM_JOB_ID'],
               'plan_sha256':args.plan_sha256,'development_only':True,'benchmark_score':False})
    cases = [(task, read_inputs(task)) for task in plan['tasks']]
    prepared = {}
    for task, rows in cases:
        for case in rows:
            prompt = tokenizer.apply_chat_template(case['messages'],tokenize=False,
                       add_generation_prompt=True,enable_thinking=False)
            ids = tokenizer.encode(prompt,add_special_tokens=False)
            if len(ids)+256>65536:raise ValueError('Full development input exceeds context')
            prepared[(task['task_id'],case['case_id'])] = {'case':case,'prompt':prompt,
                'prompt_token_ids':ids,'prompt_tokens':len(ids),'generation':plan['generation'],
                'model':model['name'],'model_revision':model['revision'],'plan_sha256':args.plan_sha256}
    write_once(run/'full_prompt_preflight.json',{'at_pacific':now(),'planned':92,
               'complete_inputs_fit':True,'input_truncations':0,'targets_read':False})
    totals = Counter()
    for task, rows in cases:
        folder = run / task['task_id'];parser = load_native_parser(task);counts=Counter();values=[]
        for offset in range(0,len(rows),8):
            batch=rows[offset:offset+8];packets=[]
            for case in batch:
                row=prepared[(task['task_id'],case['case_id'])]
                name=hashlib.sha256(case['case_id'].encode()).hexdigest()+'.json'
                write_once(folder/'requests'/name,{**row,'claimed_at_pacific':now()})
                packets.append(row)
            outputs=llm.generate([{'prompt_token_ids':row['prompt_token_ids']}for row in packets],params,use_tqdm=False)
            if len(outputs)!=len(batch):raise ValueError('Ambiguous partial batch; no retry')
            for case,row,result in zip(batch,packets,outputs):
                if len(result.outputs)!=1:raise ValueError('One output per case required')
                out=result.outputs[0];normalized=normalize(out.text,list(out.token_ids),out.finish_reason,out.stop_reason,parser)
                name=hashlib.sha256(case['case_id'].encode()).hexdigest()+'.json'
                write_once(folder/'responses'/name,{'at_pacific':now(),'case_id':case['case_id'],
                    'task_id':task['task_id'],'model_key':args.model_key,'plan_sha256':args.plan_sha256,
                    'request_file_sha256':sha(folder/'requests'/name),**normalized})
                counts['saved']+=1;counts['native_finite_scalar']+=normalized['prediction']is not None
                counts['truncations']+=normalized['truncated'];counts['empty_finals']+=normalized['empty_final']
                counts['format_errors']+=bool(normalized['format_errors'])
                if normalized['prediction']is not None:values.append(normalized['prediction'])
        write_once(folder/'completion.json',{'at_pacific':now(),'task_id':task['task_id'],
            'model_key':args.model_key,'planned':len(rows),**dict(counts),
            'distinct_predictions':len(set(values)),
            'prediction_minimum':min(values)if values else None,
            'prediction_maximum':max(values)if values else None,
            'nonconstant_prediction_diagnostic':len(set(values))>1,
            'numerical_diagnostics_are_not_correctness_metrics':True,'transport_or_server_errors':0,
            'delivery_passed':counts['native_finite_scalar']==len(rows),
            'biological_correctness_assessed':False,'benchmark_score':False,'plan_sha256':args.plan_sha256})
        totals.update(counts)
    write_once(run/'completion.json',{'at_pacific':now(),'model_key':args.model_key,'planned':92,
        **dict(totals),'delivery_passed':totals['native_finite_scalar']==92,
        'biological_correctness_assessed':False,'benchmark_score':False,'plan_sha256':args.plan_sha256})


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--plan',type=Path,required=True)
    ap.add_argument('--plan-sha256',required=True);ap.add_argument('--grant',type=Path,required=True)
    ap.add_argument('--grant-sha256',required=True)
    mode=ap.add_mutually_exclusive_group(required=True);mode.add_argument('--submit',action='store_true')
    mode.add_argument('--worker',action='store_true');mode.add_argument('--model-key',choices=['base','posttrained'])
    args=ap.parse_args();plan,grant,common,contract=validate(args.plan,args.plan_sha256,args.grant,args.grant_sha256)
    actual_priority_release=priority_release(plan,args.plan_sha256,args.grant_sha256)
    run=Path(plan['run_dir']);run.mkdir(exist_ok=True)
    if args.submit:
        with (ROOT/'.local/evaluation_GPU_submission.lock').open('a')as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            if (run/'submission_attempt.json').exists():raise ValueError('One submission attempt only')
            try:observation=resource_audit(plan,additional=1)
            except ValueError as error:
                if str(error)=='Evaluation project GPU requests exceed eight':
                    print(json.dumps({'stage':'capacity_only_wait','sbatch_invoked':False,'submission_attempt_started':False}));sys.exit(75)
                raise
            write_once(run/'private_gpu_audit_submission.json',observation)
            command=['sbatch','--parsable',str(HERE/'worker_v4_guarded.sbatch'),'--plan',str(args.plan),
                '--plan-sha256',args.plan_sha256,'--grant',str(args.grant),'--grant-sha256',args.grant_sha256]
            write_once(run/'submission_attempt.json',{'at_pacific':now(),'command':command})
            result=subprocess.run(command,capture_output=True,text=True,check=True,timeout=30)
            job=result.stdout.strip().split(';')[0]
            if not job.isdigit():raise ValueError('Ambiguous submission; never retry')
            write_once(run/'submission.json',{'at_pacific':now(),'job_id':job,'plan_sha256':args.plan_sha256,
                       'grant_sha256':args.grant_sha256,'requested_GPUs':1,
                       'priority_release':actual_priority_release,'not_model_dispatch_evidence':True})
            print(job);return
    if not os.environ.get('SLURM_JOB_ID'):raise ValueError('Existing Slurm allocation required')
    submission = json.loads((run/'submission.json').read_text())
    if (submission['job_id'] != os.environ['SLURM_JOB_ID']
            or submission['plan_sha256'] != args.plan_sha256
            or submission['grant_sha256'] != args.grant_sha256
            or submission['priority_release']!=actual_priority_release):
        raise ValueError('Actual once-only submission does not match this allocation')
    if args.model_key:
        started = json.loads((run/'started.json').read_text())
        if (started['job_id'] != os.environ['SLURM_JOB_ID'] or started['plan_sha256'] != args.plan_sha256
                or started['grant_sha256'] != args.grant_sha256):
            raise ValueError('Actual worker-start provenance differs')
        write_once(run/args.model_key/'phase_attempt.json',{'at_pacific':now(),
                   'job_id':os.environ['SLURM_JOB_ID'],'plan_sha256':args.plan_sha256,
                   'model_key':args.model_key,'no_automatic_retry':True})
        phase(args,plan,common,contract);return
    with (run/'worker.lock').open('a')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        observation=resource_audit(plan,additional=0,own=True)
        own=next(row for row in observation['jobs']if row['job_id']==os.environ['SLURM_JOB_ID'])
        if own['command']!=str(HERE/'worker_v4_guarded.sbatch')or own['workdir']!=str(ROOT):raise ValueError('Wrong actual allocation')
        write_once(run/'started.json',{'at_pacific':now(),'job_id':os.environ['SLURM_JOB_ID'],
                   'plan_sha256':args.plan_sha256,'grant_sha256':args.grant_sha256})
        local=Path(tempfile.mkdtemp(prefix='qpdev-'+os.environ['SLURM_JOB_ID']+'-'))
        python,env,receipt=common.restore_runtime(local,contract)
        env.update(PYTHONPATH=str(OLD),PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1')
        write_once(run/'environment.json',{'at_pacific':now(),'private_runtime':str(local),'receipt':receipt})
        for key in ['base','posttrained']:
            command=[str(python),str(HERE/'execute_v4_guarded.py'),'--plan',str(args.plan),'--plan-sha256',args.plan_sha256,
                     '--grant',str(args.grant),'--grant-sha256',args.grant_sha256,'--model-key',key]
            with (run/(key+'.log')).open('x')as log:
                subprocess.run(command,check=True,stdout=log,stderr=subprocess.STDOUT,env=env,cwd=local)
        write_once(run/'pair_completion.json',{'at_pacific':now(),'planned':184,'models':{
            key:{'completion_sha256':sha(run/key/'completion.json'),
                 'delivery_passed':json.loads((run/key/'completion.json').read_text())['delivery_passed']}
            for key in ['base','posttrained']},'plan_sha256':args.plan_sha256,
            'benchmark_score':False,'biological_correctness_assessed':False})


if __name__=='__main__':main()
