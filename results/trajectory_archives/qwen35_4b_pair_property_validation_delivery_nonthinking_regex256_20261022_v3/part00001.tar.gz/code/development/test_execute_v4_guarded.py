"""Invented delivery syntax fixtures only; no real examples, targets or GPU."""
from pathlib import Path
import importlib.util
import math
import re
import tempfile
import unittest
from unittest.mock import patch

SOURCE=Path(__file__).with_name('execute_v4_guarded.py')
spec=importlib.util.spec_from_file_location('property_dev_probe',SOURCE)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def parse(text):
    if not re.fullmatch(m.REGEX,text):return None
    value=float(text)
    return value if math.isfinite(value)else None


class Tests(unittest.TestCase):
    def result(self,text,finish='stop'):
        return m.normalize(text,[12,248046],finish,248046,parse)

    def test_decimal(self):
        row=self.result('17.25');self.assertEqual(row['prediction'],17.25)
        self.assertFalse(row['format_errors']);self.assertFalse(row['reasoning_expected'])

    def test_negative(self):self.assertEqual(self.result('-12')['prediction'],-12)
    def test_exponent(self):self.assertEqual(self.result('1.25e-2')['prediction'],0.0125)
    def test_terminal_marker(self):self.assertEqual(self.result('3<|im_end|>')['prediction'],3)
    def test_eos(self):self.assertEqual(self.result('3<|endoftext|>')['prediction'],3)

    def test_length_stays_invalid_even_with_number(self):
        row=self.result('17.25','length');self.assertIsNone(row['prediction'])
        self.assertEqual(row['final'],'');self.assertTrue(row['empty_final']);self.assertTrue(row['truncated'])

    def test_invalid_syntax(self):
        for text in ['','NaN','Inf','Infinity','Answer: 12','12 degrees','12 13','1e999','1.',' .2']:
            with self.subTest(text=text):self.assertIsNone(self.result(text)['prediction'])

    def test_reasoning_role_tool_invalid(self):
        for text in ['<think>12</think>12','</think>12','12<|im_start|>assistant','12<tool_call>']:
            with self.subTest(text=text):self.assertIsNone(self.result(text)['prediction'])

    def test_after_stop_invalid(self):self.assertIsNone(self.result('12<|im_end|>extra')['prediction'])
    def test_raw_ids_preserved(self):self.assertEqual(self.result('1')['token_ids'],[12,248046])

    def test_source_no_scoring(self):
        source=SOURCE.read_text()
        self.assertNotIn('score_sealed_task',source);self.assertNotIn('scorer_references.jsonl',source)
        self.assertIn('write_once(folder/\'requests\'/name',source)
        self.assertLess(source.index('write_once(folder/\'requests\'/name'),source.index('outputs=llm.generate'))

    def test_grant_rejected_before_runtime(self):
        with self.assertRaises(ValueError):m.pinned(SOURCE,'wrong-sha')

    def test_prior_proof_must_be_an_explicit_grant_pin(self):
        with tempfile.TemporaryDirectory()as directory:
            f=Path(directory).resolve()/'proof.json';f.write_text('{}')
            row={'path':str(f),'sha256':m.sha(f)}
            grant={'proof':row,'required_prior_closure_artifacts':[]}
            with self.assertRaises(ValueError):m.required_pin(grant,'proof',f)
            grant['required_prior_closure_artifacts']=[row]
            self.assertEqual(m.required_pin(grant,'proof',f),f)

    def test_prior_proof_cannot_redirect_to_other_path(self):
        with tempfile.TemporaryDirectory()as directory:
            f=Path(directory).resolve()/'proof.json';f.write_text('{}')
            row={'path':str(f),'sha256':m.sha(f)}
            grant={'proof':row,'required_prior_closure_artifacts':[row]}
            with self.assertRaises(ValueError):m.required_pin(grant,'proof',f.with_name('other.json'))

    def test_changed_prior_proof_refused(self):
        with tempfile.TemporaryDirectory()as directory:
            f=Path(directory).resolve()/'proof.json';f.write_text('{}')
            row={'path':str(f),'sha256':m.sha(f)};f.write_text('{"changed":true}')
            grant={'proof':row,'required_prior_closure_artifacts':[row]}
            with self.assertRaises(ValueError):m.required_pin(grant,'proof',f)

    def test_missing_post_proof_refused(self):
        with self.assertRaises(KeyError):m.required_pin({'required_prior_closure_artifacts':[]},'prior_Post_withdrawal_receipt',Path('/absent'))

    def test_resource_capacity_and_startup_use_same_adapter(self):
        with tempfile.TemporaryDirectory()as directory:
            f=Path(directory).resolve()/'adapter.py';f.write_text('''def capacity_audit(additional=1, override=False, require_own_job=False, additional_root_proofs=(), additional_proof_binding=None):
    assert override is False
    return {"project_GPU_ceiling":8,"additional_GPUs":additional,"capacity_available":7+additional<=8,"project_requested_GPUs":7,"project_requested_GPUs_with_addition":7+additional,"own_seen":require_own_job}
''')
            plan={'resource_adapter':{'path':str(f),'sha256':m.sha(f)},'additional_root_proofs':[],'additional_proof_binding':None}
            self.assertTrue(m.resource_audit(plan,additional=1)['capacity_available'])
            self.assertTrue(m.resource_audit(plan,additional=0,own=True)['own_seen'])
            with self.assertRaises(ValueError):m.resource_audit(plan,additional=2)

    def test_resource_ceiling_cannot_expand(self):
        with tempfile.TemporaryDirectory()as directory:
            f=Path(directory).resolve()/'adapter.py';f.write_text('''def capacity_audit(**kwargs):
    return {"project_GPU_ceiling":16,"additional_GPUs":1,"capacity_available":True}
''')
            plan={'resource_adapter':{'path':str(f),'sha256':m.sha(f)},'additional_root_proofs':[],'additional_proof_binding':None}
            with self.assertRaises(ValueError):m.resource_audit(plan,additional=1)

    def test_true_capacity_with_nine_GPUs_refused(self):
        with tempfile.TemporaryDirectory()as directory:
            f=Path(directory).resolve()/'adapter.py';f.write_text('''def capacity_audit(**kwargs):
    return {"project_GPU_ceiling":8,"additional_GPUs":1,"capacity_available":True,"project_requested_GPUs":8,"project_requested_GPUs_with_addition":9}
''')
            plan={'resource_adapter':{'path':str(f),'sha256':m.sha(f)},'additional_root_proofs':[],'additional_proof_binding':None}
            with self.assertRaises(ValueError):m.resource_audit(plan,additional=1)

    def test_noninteger_GPU_count_refused(self):
        with tempfile.TemporaryDirectory()as directory:
            f=Path(directory).resolve()/'adapter.py';f.write_text('''def capacity_audit(**kwargs):
    return {"project_GPU_ceiling":8,"additional_GPUs":1,"capacity_available":True,"project_requested_GPUs":7,"project_requested_GPUs_with_addition":8.0}
''')
            plan={'resource_adapter':{'path':str(f),'sha256':m.sha(f)},'additional_root_proofs':[],'additional_proof_binding':None}
            with self.assertRaises(ValueError):m.resource_audit(plan,additional=1)

    def test_changed_resource_source_refused(self):
        with tempfile.TemporaryDirectory()as directory:
            f=Path(directory).resolve()/'adapter.py';f.write_text('original')
            plan={'resource_adapter':{'path':str(f),'sha256':m.sha(f)},'additional_root_proofs':[],'additional_proof_binding':None};f.write_text('changed')
            with self.assertRaises(ValueError):m.resource_audit(plan,additional=1)

    def test_priority_hold_and_exact_future_release(self):
        with tempfile.TemporaryDirectory()as directory:
            root=Path(directory).resolve();local=root/'.local';local.mkdir();here=root/'dev';here.mkdir()
            reservation=local/'qwen_priority_20261022.json';reservation.write_text('{"fixture":true}')
            reservation_sha=m.sha(reservation)
            plan={'priority_reservation':{'path':str(reservation),'sha256':reservation_sha},
                  'priority_release_path':str(here/'priority_release.json')}
            release={'issuer':'/root','approved':True,'role':'exact_bound_lower_priority_lane_release',
                'lane':'4B property184 development','priority_reservation_sha256':reservation_sha,
                'root_scope_adoption_sha256':m.SCOPE_SHA,'plan_sha256':'plan','runtime_grant_sha256':'grant',
                'maximum_model_calls':184,'acknowledged_priority_suites':['LiveProteinBench','LABBench2_BASIC_closed_book_text'],
                'generation_judge_delivery_repair_prerequisites_acknowledged':True}
            with patch.object(m,'ROOT',root),patch.object(m,'HERE',here),patch.object(m,'PRIORITY_SHA',reservation_sha):
                with self.assertRaises(PermissionError):m.priority_release(plan,'plan','grant')
                f=here/'priority_release.json';f.write_text(__import__('json').dumps(release))
                self.assertEqual(m.priority_release(plan,'plan','grant')['sha256'],m.sha(f))
                for key,value in [('issuer','/owner'),('approved',False),('plan_sha256','wrong'),
                                  ('runtime_grant_sha256','wrong'),('maximum_model_calls',185),
                                  ('acknowledged_priority_suites',['LiveProteinBench']),
                                  ('generation_judge_delivery_repair_prerequisites_acknowledged',False)]:
                    with self.subTest(key=key):
                        altered=dict(release);altered[key]=value;f.write_text(__import__('json').dumps(altered))
                        with self.assertRaises(PermissionError):m.priority_release(plan,'plan','grant')


if __name__=='__main__':unittest.main(verbosity=2)
