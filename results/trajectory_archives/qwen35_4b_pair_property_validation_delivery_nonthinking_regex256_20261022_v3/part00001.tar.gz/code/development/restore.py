"""Once-only operational restoration of the unchanged reviewed scalar184 lane.

The frozen validate/phase/normalize implementation is reused directly. This
module changes authority, resource accounting and allocation plumbing only.
"""
from pathlib import Path
from types import SimpleNamespace
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
LANE = HERE.parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
AUTH = ROOT / '.local/goal_restore_20261024/root_authorization.json'
AUTH_SHA = 'bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
PLAN_SHA = 'c60fe0c5277950bd4c3a94b232880a455da247521b98439b58cb53a0cdf00dd4'
GRANT_SHA = 'd9173ef9d95d94b0dabf5b7b07b97a0b08a19292ce25ed7357cb02f694afad75'
SCIENCE_SHA = 'fe6da63cb49eaabac7c36c08a866c229e8c642208b5054315379ace7f574d75f'
ADAPTER = ROOT / '.local/resource_accounting_20261022/exact_external_checkpoint_jobs_adapter_v5.py'
ADAPTER_SHA = 'd7464059bdf95ab61fe0a2699cc4fb510252b9502aeb2c869d612f9d5d3d5f42'
OWNER = '/root/priority_runtime_review/lpb398_verifier_tests'
REVIEWER = '/root/priority_runtime_review'


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024**2), b''):
            value.update(block)
    return value.hexdigest()


def pinned(path, expected):
    path = Path(path)
    if path.is_symlink() or path.resolve() != path or not path.is_file() or sha(path) != expected:
        raise ValueError('Exact restoration source/authority changed: ' + str(path))
    return path


def write_once(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def load(path, expected, name):
    path = pinned(path, expected)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_authority(config, authority, admission, config_sha):
    if (authority.get('issuer') != '/root' or authority.get('approved') is not True
            or authority.get('role') != 'explicit_user_authorized_restoration_of_reviewed_local_GPU_evaluations'
            or 'scalar184_development_delivery_only' not in authority.get('restore_already_reviewed_local_lanes', [])
            or authority.get('project_GPU_ceiling') != 8
            or authority.get('owners', {}).get('scalar184') != OWNER
            or authority.get('independent_review_delegation', {}).get('P17_P19_scalar184') != REVIEWER):
        raise PermissionError('Exact root-authorized scalar184 restoration required')
    if (config.get('role') != 'scalar184_existing_science_operational_restoration'
            or config.get('old_plan_sha256') != PLAN_SHA or config.get('old_grant_sha256') != GRANT_SHA
            or config.get('maximum_model_calls') != 184 or config.get('models') != ['base', 'posttrained']
            or config.get('planned_cases_per_model') != 92 or config.get('requested_GPUs') != 1
            or config.get('project_GPU_ceiling') != 8 or config.get('new_correctness_scoring') is not False
            or config.get('automatic_benchmark_followon') is not False
            or config.get('automatic_retry') is not False or config.get('scientific_changes') != []):
        raise PermissionError('Only the unchanged184 delivery checks are authorized')
    expected = {'reviewer': REVIEWER, 'approved': True,
        'role': 'independent_scalar184_operational_restore_admission', 'config_sha256': config_sha,
        'root_authorization_sha256': AUTH_SHA, 'old_plan_sha256': PLAN_SHA, 'old_grant_sha256': GRANT_SHA,
        'maximum_model_calls': 184, 'maximum_new_GPU_allocations': 1,
        'correctness_scoring_authorized': False, 'automatic_benchmark_followon': False}
    if any(admission.get(key) != value for key, value in expected.items()):
        raise PermissionError('Exact independent restoration admission required')


def check_release(release):
    expected = {'issuer': '/root', 'approved': True, 'prepared_by': OWNER,
        'issued_under_root_authorization_sha256': AUTH_SHA,
        'role': 'delegated_exact_scalar184_scheduling_release',
        'lane': 'scalar184_development_delivery_only', 'old_plan_sha256': PLAN_SHA,
        'old_grant_sha256': GRANT_SHA, 'maximum_model_calls': 184,
        'maximum_new_GPU_allocations': 1, 'correctness_scoring_authorized': False,
        'automatic_benchmark_followon': False, 'prior_attempts_preserved': True}
    if any(release.get(key) != value for key, value in expected.items()):
        raise PermissionError('Exact delegated scalar184 scheduling release required')


def stops(config):
    for name in config['stop_paths']:
        path = Path(name)
        if path.exists() or path.is_symlink():
            raise PermissionError('Restoration STOP present: ' + str(path))


def validate(config_sha):
    config = read(pinned(HERE / 'config.json', config_sha))
    if (config.get('root_authorization') != {'path': str(AUTH), 'sha256': AUTH_SHA}
            or config.get('old_plan') != str(LANE / 'plan_final_resource_v4_guarded.json')
            or config.get('old_grant') != str(LANE / 'runtime_grant_v4_guarded.json')
            or config.get('run_dir') != str(LANE / 'runtime')
            or config.get('worker') != str(HERE / 'worker.sbatch')
            or config.get('resource_adapter') != {'path': str(ADAPTER), 'sha256': ADAPTER_SHA}
            or config.get('stop_paths') != [str(HERE / 'STOP'), str(LANE / 'STOP')]):
        raise PermissionError('Canonical scalar184 restoration paths required')
    for path, expected in config['source_sha256'].items():
        pinned(path, expected)
    shared_pin = config['shared_resource_binding']
    if shared_pin['path'] != str(ROOT / '.local/goal_restore_20261024/shared_resource_binding.json'):
        raise PermissionError('Canonical reviewed shared resource binding required')
    shared = read(pinned(shared_pin['path'], shared_pin['sha256']))
    for key in ('resource_adapter', 'additional_root_proofs', 'additional_proof_binding',
                'root_authorization', 'project_GPU_ceiling'):
        if shared.get(key) != config.get(key):
            raise PermissionError('Preallocation/startup must use the identical shared resource binding')
    release_pin = config['priority_release']
    if release_pin['path'] != str(HERE / 'priority_release.json'):
        raise PermissionError('Canonical additive priority release required')
    check_release(read(pinned(release_pin['path'], release_pin['sha256'])))
    authority = read(pinned(AUTH, AUTH_SHA))
    admission_path = HERE / 'independent_runtime_admission.json'
    admission_sha = sha(admission_path)
    admission = read(pinned(admission_path, admission_sha))
    check_authority(config, authority, admission, config_sha)
    stops(config)
    config['_admission_sha256'] = admission_sha
    return config


def old_science(config):
    science = load(LANE / 'execute_v4_guarded.py', SCIENCE_SHA, 'scalar184_frozen_science')
    plan, grant, common, contract = science.validate(Path(config['old_plan']), PLAN_SHA,
                                                    Path(config['old_grant']), GRANT_SHA)
    return science, plan, grant, common, contract


def resource_audit(config, additional=0, own=False, loader=load):
    adapter = loader(ADAPTER, ADAPTER_SHA, 'scalar184_current_resource_v5')
    result = adapter.capacity_audit(additional=additional, override=False, require_own_job=own,
        additional_root_proofs=config['additional_root_proofs'],
        additional_proof_binding=config['additional_proof_binding'])
    count, total = result.get('project_requested_GPUs'), result.get('project_requested_GPUs_with_addition')
    if (result.get('project_GPU_ceiling') != 8 or type(count) is not int or count < 0
            or type(total) is not int or total != count + additional or total > 8
            or result.get('capacity_available') is not True
            or (own and (result.get('own_allocation_verified') is not True
                         or result.get('own_job_id') != os.environ.get('SLURM_JOB_ID')))):
        raise ValueError('Evaluation project GPU requests exceed eight')
    return result


def wait_receipt(path, timeout=60, reader=read, clock=time.monotonic, pause=time.sleep):
    deadline = clock() + timeout
    while True:
        try:
            return reader(path)
        except (FileNotFoundError, json.JSONDecodeError):
            if clock() >= deadline:
                raise PermissionError('Submission receipt handshake expired; never replay')
            pause(min(.1, max(0, deadline - clock())))


def assert_no_attempt(run):
    paths = [run / name for name in ('submission_attempt.json', 'submission.json', 'submission_uncertain.json',
        'private_gpu_audit_submission.json', 'started.json', 'environment.json', 'pair_completion.json')]
    paths += [run / key / 'phase_attempt.json' for key in ('base', 'posttrained')]
    artifacts = list(run.glob('*/P*/requests/*.json')) + list(run.glob('*/P*/responses/*.json'))
    if artifacts or any(path.exists() or path.is_symlink() for path in paths):
        raise FileExistsError('Existing/ambiguous scalar184 attempt; no replay')


def submit(config_sha):
    config = validate(config_sha)
    old_science(config)  # Existing metadata/input allowlists and prior closures; no model call.
    run = Path(config['run_dir'])
    with (ROOT / '.local/evaluation_GPU_submission.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        config = validate(config_sha)
        old_science(config)
        assert_no_attempt(run)
        audit = resource_audit(config, additional=1)
        config = validate(config_sha)  # STOP/current authority after all potentially blocking checks.
        assert_no_attempt(run)
        command = ['sbatch', '--parsable', '--export=NONE', config['worker'], config_sha]
        write_once(run / 'private_gpu_audit_submission.json', audit)
        write_once(run / 'submission_attempt.json', {'at_epoch': time.time(), 'command': command,
            'operational_config_sha256': config_sha, 'old_plan_sha256': PLAN_SHA,
            'old_grant_sha256': GRANT_SHA, 'root_authorization_sha256': AUTH_SHA,
            'independent_runtime_admission_sha256': config['_admission_sha256'], 'automatic_retry': False})
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=60)
        except Exception as error:
            write_once(run / 'submission_uncertain.json', {'error_type': type(error).__name__, 'automatic_retry': False})
            raise
        value = result.stdout.strip()
        valid = result.returncode == 0 and re.fullmatch(r'[0-9]+(?:;[A-Za-z0-9_.-]+)?', value)
        receipt = {'at_epoch': time.time(), 'job_id': value.split(';')[0] if valid else None,
            'plan_sha256': PLAN_SHA, 'grant_sha256': GRANT_SHA, 'operational_config_sha256': config_sha,
            'root_authorization_sha256': AUTH_SHA, 'requested_GPUs': 1, 'automatic_retry': False,
            'independent_runtime_admission_sha256': config['_admission_sha256'],
            'returncode': result.returncode, 'stdout': value, 'stderr': result.stderr}
        write_once(run / 'submission.json', receipt)
        if not valid:
            raise RuntimeError('One submission failed or ambiguous; no replay')
        return receipt


def worker(config_sha, model_key=None):
    config = validate(config_sha)
    science, plan, grant, common, contract = old_science(config)
    job = os.environ.get('SLURM_JOB_ID')
    if not job:
        raise PermissionError('Own Slurm allocation required')
    run = Path(config['run_dir'])
    receipt = wait_receipt(run / 'submission.json')
    if (receipt.get('job_id') != job or receipt.get('operational_config_sha256') != config_sha
            or receipt.get('plan_sha256') != PLAN_SHA or receipt.get('grant_sha256') != GRANT_SHA
            or receipt.get('root_authorization_sha256') != AUTH_SHA or receipt.get('returncode') != 0
            or receipt.get('independent_runtime_admission_sha256') != config['_admission_sha256']):
        raise PermissionError('Exact once-only scalar184 allocation receipt required')
    if model_key:
        started = read(run / 'started.json')
        if started.get('job_id') != job or started.get('operational_config_sha256') != config_sha:
            raise PermissionError('Exact parent worker provenance required')
        validate(config_sha)
        write_once(run / model_key / 'phase_attempt.json', {'at_epoch': time.time(), 'job_id': job,
            'plan_sha256': PLAN_SHA, 'model_key': model_key, 'no_automatic_retry': True,
            'operational_config_sha256': config_sha})
        science.phase(SimpleNamespace(model_key=model_key, plan_sha256=PLAN_SHA), plan, common, contract)
        return
    with (run / 'worker.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        audit = resource_audit(config, own=True)
        own = [row for row in audit['jobs'] if row.get('job_id') == job]
        if (len(own) != 1 or own[0].get('command') != config['worker']
                or own[0].get('workdir') != str(ROOT) or own[0].get('gpus') != 1):
            raise PermissionError('Exact oneGPU scalar184 worker required')
        validate(config_sha)
        write_once(run / 'private_gpu_audit_startup.json', audit)
        write_once(run / 'started.json', {'at_epoch': time.time(), 'job_id': job,
            'plan_sha256': PLAN_SHA, 'grant_sha256': GRANT_SHA, 'operational_config_sha256': config_sha,
            'independent_runtime_admission_sha256': config['_admission_sha256'],
            'root_authorization_sha256': AUTH_SHA})
        local = Path(tempfile.mkdtemp(prefix='qpdev-' + job + '-'))
        python, env, runtime_receipt = common.restore_runtime(local, contract)
        env.update(PYTHONPATH=str(science.OLD), PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1')
        write_once(run / 'environment.json', {'at_epoch': time.time(), 'private_runtime': str(local),
            'receipt': runtime_receipt, 'operational_config_sha256': config_sha})
        for key in config['models']:
            validate(config_sha)
            command = [str(python), str(HERE / 'restore.py'), 'phase', '--config-sha256', config_sha,
                       '--model-key', key]
            with (run / (key + '.log')).open('x') as log:
                subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT, env=env, cwd=local)
        write_once(run / 'pair_completion.json', {'at_epoch': time.time(), 'planned': 184,
            'models': {key: {'completion_sha256': sha(run / key / 'completion.json'),
                'delivery_passed': read(run / key / 'completion.json')['delivery_passed']}
                for key in config['models']}, 'plan_sha256': PLAN_SHA,
            'operational_config_sha256': config_sha, 'benchmark_score': False,
            'biological_correctness_assessed': False})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['submit', 'worker', 'phase'])
    parser.add_argument('--config-sha256', required=True)
    parser.add_argument('--model-key', choices=['base', 'posttrained'])
    args = parser.parse_args()
    if args.action == 'submit':
        try:
            print(json.dumps(submit(args.config_sha256), sort_keys=True))
        except ValueError as error:
            if str(error) != 'Evaluation project GPU requests exceed eight':
                raise
            print(json.dumps({'stage': 'capacity_only_wait', 'sbatch_invoked': False,
                              'submission_attempt_started': False}))
            raise SystemExit(75)
    else:
        if (args.action == 'phase') != bool(args.model_key):
            raise ValueError('Phase mode requires one exact model key')
        worker(args.config_sha256, args.model_key)


if __name__ == '__main__':
    main()
