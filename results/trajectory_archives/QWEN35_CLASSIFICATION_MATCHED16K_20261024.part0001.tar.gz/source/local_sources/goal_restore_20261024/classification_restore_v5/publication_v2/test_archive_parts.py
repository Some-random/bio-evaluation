from pathlib import Path
import copy
import hashlib
import io
import tarfile
import tempfile
import unittest
from unittest.mock import patch
import archive_parts as A


class ArchivePartsTests(unittest.TestCase):
    def test_self_consistently_resealed_unsafe_member_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder).resolve(); source = root / 'invented.txt'; source.write_bytes(b'closed')
            originals = {'safe/source.txt': {'path': str(source), 'bytes': 6, 'sha256': A.sha(source)}}
            records = A.capture_verified(originals, root/'stage', 'results/archive', lambda path: None)
            name, record = next(iter(records.items())); destination = root/'stage'/name
            row = next(iter(record['members'].values()))
            with tarfile.open(destination, 'w:gz') as archive:
                item = tarfile.TarInfo('../outside'); item.size = 6
                archive.addfile(item, io.BytesIO(b'closed'))
            record['members'] = {'../outside': row}; record['sha256'] = A.sha(destination)
            record['bytes'] = destination.stat().st_size
            with self.assertRaisesRegex(ValueError, 'Unsafe logical'):
                A.verify_reconstruction(root/'stage', records, originals)

    def test_full_original_reconstruction_across_parts(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder).resolve(); source = root / 'invented.txt'; source.write_bytes(b'abcdefghijk')
            originals = {'safe/source.txt': {'path': str(source), 'bytes': 11, 'sha256': A.sha(source)}}
            scans = []
            with patch.object(A, 'MEMBER_MAX', 4), patch.object(A, 'PART_MAX', 5):
                records = A.capture_verified(originals, root / 'stage', 'results/archive', lambda path: scans.append(path))
            self.assertEqual(len(records), 3); self.assertEqual(len(scans), 4)
            A.verify_reconstruction(root / 'stage', records, originals)
            shifted = copy.deepcopy(records)
            next(iter(list(shifted.values())[1]['members'].values()))['byte_offset'] += 1
            with self.assertRaises(ValueError): A.verify_reconstruction(root / 'stage', shifted, originals)
            archive = root / 'stage' / next(iter(records)); archive.write_bytes(archive.read_bytes() + b'corruption')
            with self.assertRaises(ValueError): A.verify_reconstruction(root / 'stage', records, originals)

    def test_changed_original_and_unsafe_name_are_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder).resolve(); source = root / 'invented.txt'; source.write_bytes(b'closed')
            row = {'path': str(source), 'bytes': 6, 'sha256': A.sha(source)}
            source.write_bytes(b'change')
            with self.assertRaises((ValueError, OSError)): A.capture_verified({'safe.txt': row}, root / 'stage', 'results/archive', lambda path: None)
            with self.assertRaises(ValueError): A.capture_verified({'../private': row}, root / 'stage', 'results/archive', lambda path: None)
            with self.assertRaises(ValueError): A.capture_verified({'safe.txt': row}, root / 'stage', '../archive', lambda path: None)

    def test_source_symlink_and_missing_scanner_are_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder).resolve(); source = root / 'invented.txt'; source.write_bytes(b'closed')
            link = root / 'link'; link.symlink_to(source)
            row = {'path': str(link), 'bytes': 6, 'sha256': A.sha(source)}
            with self.assertRaises(ValueError): A.capture_verified({'safe.txt': row}, root / 'stage', 'results/archive', None)
            with self.assertRaises((ValueError, OSError)): A.capture_verified({'safe.txt': row}, root / 'stage', 'results/archive', lambda path: None)


if __name__ == '__main__': unittest.main()
