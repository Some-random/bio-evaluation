"""Offline verification by default; publish only the exact reviewed matched16k union."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import contextlib
import fcntl
import hashlib
import importlib.util
import json
import os
import re
import stat
import subprocess
import tempfile

from assemble import check, ROOT, STAGE, MANIFEST, STOP, PRIVATE, PUBLIC_PREFIX, valid_public_paths

OWNER = '/root/priority_runtime_review/lpb398_verifier_tests/joint_restart_review'
REVIEWER = '/root/independent_review'
REPOSITORY = 'Some-random/bio-evaluation'
URL = 'https://github.com/'+REPOSITORY+'.git'
RUN_ID = 'qwen35_4b_classification_matched16k_20261024_v5'
PREFIX = 'results/runs/'+RUN_ID+'/'
RAW_PREFIX = 'results/trajectory_archives/QWEN35_CLASSIFICATION_MATCHED16K_20261024'
REPORT = 'reports/QWEN35_CLASSIFICATION_MATCHED16K_20261024.md'
BASE_PATHS = {PREFIX+model+'/'+task+'/scores.json' for model in ('base','posttrained') for task in ('P03','P01')}
BASE_PATHS |= {PREFIX+name for name in ('result_rows.json','scope.json','execution_provenance.json')}
BASE_PATHS.add(REPORT)
ARCHIVE_MANIFEST = RAW_PREFIX+'.manifest.json'
PART_RE = re.compile(re.escape(RAW_PREFIX)+r'\.part([0-9]{4})\.tar\.gz')
SHA_RE = re.compile('[0-9a-f]{64}')
COMMIT_RE = re.compile('[0-9a-f]{40}')
AUTH_SHA = 'bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
MAX_PUBLIC_BYTES = 90*1024**2
HELPER_PINS = {
    '.local/litqa2_replay/incremental_upload.py': '194f143fa81d2409c3f72403c5664f7f9c64b9ca3cc46af9603de0d044cf0160',
    '.local/litqa2_replay/github_credential_helper.py': '45a94c6e738c987277f252bb5177e0d1b7b35ce8ea17d438b358f802442192cb',
    'scripts/publication_destination.py': '7af9309f3b860b69301abae590a6c9ac4f03c1d81a6b3269b86fc077b6a10f4a',
}


def regular_descriptor(path):
    path=Path(path).absolute()
    directory=os.open(path.anchor,os.O_RDONLY|os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            current=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=directory)
            os.close(directory);directory=current
        fd=os.open(path.name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=directory)
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            os.close(fd);raise ValueError('Regular files required')
        return fd
    finally:os.close(directory)


def regular_bytes(path):
    with os.fdopen(regular_descriptor(path),'rb') as stream:
        if os.fstat(stream.fileno()).st_size>=MAX_PUBLIC_BYTES:raise ValueError('Bounded regular artifact required')
        data=stream.read(MAX_PUBLIC_BYTES)
        if len(data)>=MAX_PUBLIC_BYTES:raise ValueError('Bounded regular artifact required')
        return data


def sha(path):
    value=hashlib.sha256()
    with os.fdopen(regular_descriptor(path),'rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):value.update(chunk)
    return value.hexdigest()


def read(path):return json.loads(regular_bytes(path))


def durable_json(path,value):
    path=Path(path).absolute()
    directory=os.open(path.anchor,os.O_RDONLY|os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            current=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=directory)
            os.close(directory);directory=current
        fd=os.open(path.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=directory)
        with os.fdopen(fd,'w') as stream:
            json.dump(value,stream,sort_keys=True,indent=2,allow_nan=False);stream.write('\n')
            stream.flush();os.fsync(stream.fileno())
        os.fsync(directory)
    finally:os.close(directory)


def publication_stops():
    if os.path.lexists(STOP):raise PermissionError('Publication STOP present')


def no_prior_attempt():
    publication_stops()
    if any(os.path.lexists(PRIVATE/name) for name in ('publication_receipt.json','attempt_started.json','push_intent.json')):
        raise FileExistsError('Preserve prior publication attempt; no automatic ambiguous push retry')


@contextlib.contextmanager
def exclusive_lock(path):
    path=Path(path).absolute()
    directory=os.open(path.anchor,os.O_RDONLY|os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            current=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=directory)
            os.close(directory);directory=current
        fd=os.open(path.name,os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW|os.O_NONBLOCK,0o600,dir_fd=directory)
        try:
            if not stat.S_ISREG(os.fstat(fd).st_mode):raise ValueError('Regular shared lock required')
            fcntl.flock(fd,fcntl.LOCK_EX)
            yield
        finally:os.close(fd)
    finally:os.close(directory)


def write_checkout_file(checkout,name,data,allowed):
    if name not in allowed:raise ValueError('Outside exact reviewed publication whitelist')
    parts=Path(name).parts
    directory=os.open(checkout,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        for part in parts[:-1]:
            try:os.mkdir(part,0o755,dir_fd=directory)
            except FileExistsError:pass
            current=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=directory)
            os.close(directory);directory=current
        try:fd=os.open(parts[-1],os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o644,dir_fd=directory)
        except FileExistsError:
            fd=os.open(parts[-1],os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=directory)
            with os.fdopen(fd,'rb') as stream:
                if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode) or stream.read(len(data)+1)!=data:
                    raise ValueError('Existing immutable scoped public artifact differs')
        else:
            with os.fdopen(fd,'wb') as stream:
                stream.write(data);stream.flush();os.fsync(stream.fileno())
    finally:os.close(directory)


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def validate_paths(files):
    if str(PUBLIC_PREFIX) != PREFIX or not isinstance(files,dict):
        raise ValueError('Different exact matched16k publication prefix')
    if any(type(name) is not str or type(digest) is not str or not SHA_RE.fullmatch(digest)
           for name,digest in files.items()):
        raise ValueError('Exact public path/digest mapping required')
    observed=set(files)
    numbers=sorted(int(match.group(1)) for name in observed if (match:=PART_RE.fullmatch(name)))
    if not 1<=len(numbers)<=256 or numbers!=list(range(1,len(numbers)+1)):
        raise ValueError('Require one to256 contiguous archive parts beginning0001')
    expected=BASE_PATHS|{ARCHIVE_MANIFEST}|{RAW_PREFIX+'.part'+str(n).zfill(4)+'.tar.gz' for n in numbers}
    if observed!=expected:
        raise ValueError('Only exact eight matched16k paths plus archive manifest and contiguous parts are supported')
    for name in observed:
        path=Path(name)
        if path.is_absolute() or '..' in path.parts or '.local' in path.parts or 'docs' in path.parts:
            raise ValueError('Unsafe or website publication path')
    if valid_public_paths(files) is not True:
        raise ValueError('Assembler rejected exact public path union')
    return observed


def validated_manifest(manifest_path,digest):
    raw=regular_bytes(manifest_path)
    if hashlib.sha256(raw).hexdigest()!=digest:
        raise ValueError('Reviewed publication manifest changed')
    manifest=json.loads(raw)
    if manifest.get('kind')!='classification_matched16k_publication_manifest':
        raise ValueError('Exact classification matched16k publication manifest required')
    validate_paths(manifest.get('public_files_sha256'))
    if check(manifest_path=Path(manifest_path))!=manifest:
        raise ValueError('Assembler verified a different concrete manifest')
    if regular_bytes(manifest_path)!=raw:
        raise ValueError('Concrete manifest changed during authority checks')
    for name,expected in manifest['public_files_sha256'].items():
        data=regular_bytes(STAGE/name)
        if hashlib.sha256(data).hexdigest()!=expected:
            raise ValueError('Exact reviewed public bytes changed')
    return manifest


def validate_review(path,digest,manifest,manifest_sha):
    if path is None or digest is None:
        raise PermissionError('Exact independent concrete publication review required')
    raw=regular_bytes(path)
    if hashlib.sha256(raw).hexdigest()!=digest:
        raise PermissionError('Exact independent concrete publication review changed')
    review=json.loads(raw)
    if (review.get('role')!='classification_exact_concrete_publication_review'
            or review.get('reviewer')!=REVIEWER or review.get('reviewer')==OWNER
            or review.get('approved') is not True or review.get('manifest_sha256')!=manifest_sha
            or review.get('public_files_sha256')!=manifest['public_files_sha256']
            or review.get('repository')!=REPOSITORY or review.get('visibility')!='public'
            or review.get('root_authorization_sha256')!=AUTH_SHA
            or any(review.get(key) is not True for key in ('secret_archive_scans_verified','exclusions_verified',
                'private_native_review_authority_verified','matched16k_scope_verified'))):
        raise PermissionError('Different exact independent reviewer must approve the concrete matched16k union')
    return review


def verify_helper_sources():
    for name,digest in HELPER_PINS.items():
        if sha(ROOT/name)!=digest:
            raise ValueError('Frozen publication helper source changed')


def git_environment(environment):
    result = {key: value for key, value in environment.items() if not key.startswith('GIT_')}
    result.update(GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull, GIT_TERMINAL_PROMPT='0')
    return result


def git_blob_sha(checkout, revision_path):
    """Hash one Git blob through a bounded stream; no aggregate raw capture."""
    process = subprocess.Popen(['git', 'show', revision_path], cwd=checkout,
        env=git_environment(os.environ), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    digest = hashlib.sha256()
    for block in iter(lambda: process.stdout.read(1024 * 1024), b''):
        digest.update(block)
    process.stdout.close()
    process.stderr.read()
    process.stderr.close()
    if process.wait():
        raise RuntimeError('Local committed blob verification failed')
    return digest.hexdigest()


def commit_sha(text):
    value = text.strip()
    if not COMMIT_RE.fullmatch(value):
        raise ValueError('Exact SHA-1 commit identity required')
    return value


def verify_index(git, checkout, files):
    observed = set()
    for entry in git('ls-files', '--stage', '-z', '--', *sorted(files)).stdout.split('\0'):
        if not entry:
            continue
        metadata, name = entry.split('\t', 1)
        mode, oid, stage = metadata.split()
        if name in observed or mode != '100644' or stage != '0' or not COMMIT_RE.fullmatch(oid):
            raise ValueError('Only unique regular scoped staged blobs allowed')
        observed.add(name)
    if observed != set(files):
        raise ValueError('Staged paths differ from the exact concrete reviewed union')
    if any(git_blob_sha(checkout, ':' + name) != digest for name, digest in files.items()):
        raise ValueError('Staged Git bytes differ from independently reviewed artifacts')


def verify_tree(git, checkout, revision, files):
    observed = set()
    for entry in git('ls-tree', '-z', revision, '--', *sorted(files)).stdout.split('\0'):
        if not entry:
            continue
        metadata, name = entry.split('\t', 1)
        mode, kind, oid = metadata.split()
        if name in observed or mode != '100644' or kind != 'blob' or not COMMIT_RE.fullmatch(oid):
            raise ValueError('Only unique regular scoped committed blobs allowed')
        observed.add(name)
    if observed != set(files):
        raise ValueError('Committed artifact union differs from exact review')
    if any(git_blob_sha(checkout, revision + ':' + name) != digest for name, digest in files.items()):
        raise ValueError('Committed artifact bytes differ')


def confirm_destination(helper):
    if helper.URL!=URL or helper.REPOSITORY!=REPOSITORY:raise ValueError('Exact GitHub helper destination required')
    destination=helper.confirm_destination()
    if (destination.get('repository')!=REPOSITORY or destination.get('visibility')!='public'
            or destination.get('push_permission') is not True):
        raise ValueError('Actual GitHub identity/public visibility/push permission differs')
    return destination


def publish(manifest,manifest_sha,review_path,review_sha,manifest_path=None):
    manifest_path=MANIFEST if manifest_path is None else Path(manifest_path)
    no_prior_attempt()
    manifest=validated_manifest(manifest_path,manifest_sha)
    validate_review(review_path,review_sha,manifest,manifest_sha)
    receipt=PRIVATE/'publication_receipt.json'
    with exclusive_lock(ROOT/'.local/catalog_report_generation.lock'):
        with exclusive_lock(ROOT/'.local/evaluation_publication.lock'):
            no_prior_attempt()
            manifest=validated_manifest(manifest_path,manifest_sha)
            validate_review(review_path,review_sha,manifest,manifest_sha)
            durable_json(PRIVATE/'attempt_started.json',
                {'at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
                 'manifest_path':str(manifest_path),'manifest_sha256':manifest_sha,
                 'independent_review_sha256':review_sha,'model_calls':0,'automatic_retry':False})
            verify_helper_sources()
            helper=load('classification_matched16k_git_helper',ROOT/'.local/litqa2_replay/incremental_upload.py')
            helper.ENV=git_environment(getattr(helper,'ENV',os.environ))
            confirm_destination(helper)
            files=manifest['public_files_sha256'];paths=sorted(files)
            validate_paths(files)
            with tempfile.TemporaryDirectory(prefix='classification-matched16k-publication-') as directory:
                checkout=Path(directory)
                def git(*args):return helper.git(*args,cwd=checkout)
                git('init','--quiet');git('remote','add','origin',URL)
                git('config','core.hooksPath',os.devnull);git('config','core.autocrlf','false')
                git('config','remote.origin.promisor','true');git('config','remote.origin.partialclonefilter','blob:none')
                git('sparse-checkout','init','--no-cone');git('sparse-checkout','set','--no-cone',*('/'+n for n in paths))
                git('fetch','--filter=blob:none','--depth=1','origin','main')
                before=commit_sha(git('rev-parse','FETCH_HEAD').stdout)
                git('checkout','--detach','FETCH_HEAD');git('config','user.name','Codex');git('config','user.email','codex@localhost')
                for name in paths:
                    data=regular_bytes(STAGE/name)
                    if hashlib.sha256(data).hexdigest()!=files[name]:raise ValueError('Captured local bytes changed')
                    write_checkout_file(checkout,name,data,files)
                git('add','-f','--sparse','--',*paths)
                changed=set(git('diff','--cached','--name-only').stdout.splitlines())
                if not changed or not changed<=set(files):raise ValueError('Unexpected paths or existing identical publication requires review')
                verify_index(git,checkout,files)
                git('diff','--cached','--check','--',*paths)
                git('commit','--no-gpg-sign','--no-verify','-m','Publish separate matched16k classification scores and reviewed source trajectories')
                commit=commit_sha(git('rev-parse','HEAD').stdout)
                verify_tree(git,checkout,commit,files)
                if set(git('diff','--name-only',before,commit).stdout.splitlines())!=changed:
                    raise ValueError('Committed paths differ from reviewed staged changes')
                verify_helper_sources()
                if validated_manifest(manifest_path,manifest_sha)!=manifest:
                    raise ValueError('Reviewed authority or concrete union changed before push')
                confirm_destination(helper)
                validate_review(review_path,review_sha,manifest,manifest_sha)
                publication_stops()
                durable_json(PRIVATE/'push_intent.json',
                    {'at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
                     'previous_main_head':before,'commit_sha':commit,'manifest_path':str(manifest_path),
                     'manifest_sha256':manifest_sha,'public_files_sha256':files,'automatic_retry':False})
                publication_stops()
                git('push','origin','HEAD:refs/heads/main')
                git('fetch','--filter=blob:none','origin','main')
                head=commit_sha(git('rev-parse','FETCH_HEAD').stdout)
                git('merge-base','--is-ancestor',commit,head)
                verify_tree(git,checkout,commit,files);verify_tree(git,checkout,head,files)
                value={'at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),'stage':'published',
                    'repository':REPOSITORY,'visibility':'public','push_permission_verified':True,
                    'previous_main_head':before,'commit_sha':commit,'verified_remote_main_head':head,
                    'remote_bytes_verified':True,'published_path_count':len(paths),'public_files_sha256':files,
                    'kind':'classification_matched16k_publication_receipt','run_id':RUN_ID,
                    'root_authorization_sha256':AUTH_SHA,
                    'manifest_path':str(manifest_path),'manifest_sha256':manifest_sha,'independent_review_sha256':review_sha,
                    'model_weights_environments_credentials_references_or_full_account_metadata_published':False,
                    'shared_aggregate_reports_modified':False,'website_or_schedule_changed':False,
                    'new_model_calls':0,'new_scoring_calls':0,'new_GPU_requests':0,'automatic_retry':False}
                durable_json(receipt,value)
                print(json.dumps({k:value[k] for k in ['stage','commit_sha','published_path_count','remote_bytes_verified']}))
                return value


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--manifest',type=Path,default=MANIFEST)
    parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--publish',action='store_true')
    parser.add_argument('--review',type=Path)
    parser.add_argument('--review-sha256')
    args=parser.parse_args()
    manifest=validated_manifest(args.manifest,args.manifest_sha256)
    if not args.publish:
        print(json.dumps({'stage':'offline_classification_matched16k_publication_checks_passed',
            'public_paths':len(manifest['public_files_sha256']),'published':False,'network_calls':0,'model_calls':0}))
        return
    publish(manifest,args.manifest_sha256,args.review,args.review_sha256,args.manifest)


if __name__=='__main__':
    main()
