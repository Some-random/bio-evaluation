"""Pure byte-preserving archive routines reused from reviewed P13 source.

Parent source SHA bc1094deae30f3d49ce62986dc9f6f54003ed968181045c22154440a675a22b8.
Uncompressed grouping is bounded to64MiB. Descriptor reads also reject links;
no source main() is copied.
"""
from pathlib import Path
import hashlib
import gzip
import io
import json
import os
import stat
import tarfile
PART_MAX = 64 * 1024**2
MEMBER_MAX = 64 * 1024**2

def regular_descriptor(path):
    path = Path(path)
    if not path.is_absolute(): raise ValueError('Absolute regular path required')
    directory = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            current = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
            os.close(directory); directory = current
        descriptor = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            os.close(descriptor); raise ValueError('Regular captured file required')
        return descriptor
    finally: os.close(directory)

def sha(path):
    h=hashlib.sha256()
    with os.fdopen(regular_descriptor(Path(path).absolute()),'rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()

def create(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data);stream.flush();os.fsync(stream.fileno())

def verify_reconstruction(stage, archives, originals):
    """Rehash captured original bytes across every ordered archive piece."""
    observed = {name: {'digest': hashlib.sha256(), 'offset': 0} for name in originals}
    archive_names = set()
    for archive_name, record in archives.items():
        archive_path = Path(stage)/archive_name
        if sha(archive_path) != record['sha256']:
            raise ValueError('Archive changed after capture')
        with tarfile.open(archive_path) as archive:
            members = archive.getmembers()
            if [item.name for item in members] != list(record['members']):
                raise ValueError('Archive member order or membership differs')
            for item in members:
                safe_name(item.name)
                if not item.isfile() or item.name in archive_names:
                    raise ValueError('Duplicate or unsafe captured member')
                archive_names.add(item.name)
                row = record['members'][item.name]
                name = row['original_member_name']
                if name not in originals or row['original_sha256'] != originals[name]['sha256']:
                    raise ValueError('Foreign original reconstruction identity')
                state = observed[name]
                if state['offset'] != row['byte_offset'] or row['original_bytes'] != originals[name]['bytes']:
                    raise ValueError('Gap, overlap or size mismatch in original reconstruction')
                data = archive.extractfile(item).read()
                if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
                    raise ValueError('Captured piece mismatch')
                state['digest'].update(data)
                state['offset'] += len(data)
    for name, state in observed.items():
        if state['offset'] != originals[name]['bytes'] or state['digest'].hexdigest() != originals[name]['sha256']:
            raise ValueError('Captured original full hash differs: ' + name)

def recheck_originals(originals):
    for name, row in originals.items():
        if Path(row['path']).stat().st_size != row['bytes'] or sha(row['path']) != row['sha256']:
            raise ValueError('Source changed during capture: ' + name)

def create_verified(path, source, expected):
    data = Path(source).read_bytes()
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError('Published duplicate differs from verified capture')
    create(path, data)

def split_members(originals):
    members=[]
    for name,row in sorted(originals.items()):
        count=max(1,(row['bytes']+MEMBER_MAX-1)//MEMBER_MAX)
        for i in range(count):
            offset=i*MEMBER_MAX;length=min(MEMBER_MAX,row['bytes']-offset)
            public_name=name if count==1 else name+'.part'+str(i+1).zfill(4)
            members.append(dict(row,archive_name=public_name,original_member_name=name,
                                offset=offset,bytes=length,original_bytes=row['bytes']))
    return members

def group_parts(members):
    parts=[];current=[];size=0
    for row in members:
        if current and size+row['bytes']>PART_MAX:parts.append(current);current=[];size=0
        current.append(row);size+=row['bytes']
    if current:parts.append(current)
    return parts


def safe_name(name):
    path = Path(name)
    if path.is_absolute() or '..' in path.parts or '.local' in path.parts or not path.parts:
        raise ValueError('Unsafe logical publication name')


def read_piece(row):
    path = Path(row['path'])
    if not path.is_absolute() or path != path.resolve(): raise ValueError('Canonical regular source required')
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode): raise ValueError('Regular captured source required')
    fd = regular_descriptor(path)
    with os.fdopen(fd, 'rb') as stream:
        identity = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns, item.st_ctime_ns)
        if identity(before) != identity(os.fstat(stream.fileno())): raise ValueError('Captured source replaced')
        stream.seek(row['offset']); data = stream.read(row['bytes'])
        if len(data) != row['bytes'] or identity(before) != identity(os.fstat(stream.fileno())) \
                or identity(before) != identity(path.lstat()): raise ValueError('Captured source changed while reading')
    return data


def capture_verified(originals, stage, archive_prefix, scan_file):
    """Capture only caller-whitelisted closed bytes; reconstruct and rehash all originals."""
    if not originals or not callable(scan_file): raise ValueError('Verified originals and mandatory scanner required')
    safe_name(archive_prefix)
    stage = Path(stage); records = {}
    for name, row in originals.items():
        safe_name(name)
        if set(row) != {'path', 'bytes', 'sha256'} or type(row['bytes']) is not int or row['bytes'] < 0:
            raise ValueError('Exact original capture record required')
        scan_file(Path(row['path']))
    recheck_originals(originals)
    groups = group_parts(split_members(originals))
    if not 1 <= len(groups) <= 256: raise ValueError('Bounded archive-part inventory required')
    for index, rows in enumerate(groups, 1):
        name = archive_prefix + '.part' + str(index).zfill(4) + '.tar.gz'
        destination = stage / name; destination.parent.mkdir(parents=True, exist_ok=True)
        members = {}
        with destination.open('xb') as output:
            with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
                with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                    for row in rows:
                        safe_name(row['archive_name'])
                        data = read_piece(row)
                        entry = tarfile.TarInfo(row['archive_name']); entry.size = len(data)
                        entry.mode = 0o644; entry.mtime = 0
                        archive.addfile(entry, io.BytesIO(data))
                        members[row['archive_name']] = {'original_member_name': row['original_member_name'],
                            'original_sha256': row['sha256'], 'original_bytes': row['original_bytes'],
                            'byte_offset': row['offset'], 'bytes': len(data),
                            'sha256': hashlib.sha256(data).hexdigest()}
            output.flush(); os.fsync(output.fileno())
        if destination.stat().st_size >= 90 * 1024**2: raise ValueError('Compressed Git artifact exceeds fixed bound')
        scan_file(destination)
        records[name] = {'sha256': sha(destination), 'bytes': destination.stat().st_size, 'members': members}
    recheck_originals(originals)
    verify_reconstruction(stage, records, originals)
    return records
