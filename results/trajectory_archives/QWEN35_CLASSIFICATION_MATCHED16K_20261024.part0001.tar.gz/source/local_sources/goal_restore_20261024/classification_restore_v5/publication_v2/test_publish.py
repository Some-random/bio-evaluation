"""Invented-only publisher tests; Git, network and assembler authority are mocked."""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import stat
import sys
import tempfile
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import Mock, patch

HERE = Path(__file__).resolve().parent


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def reject_live_call(*args, **kwargs):
    raise AssertionError('Synthetic publisher test forbids live process/network calls')


class PublisherTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='classification-invented-publisher-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.private = self.root/'publication'
        self.stage = self.private/'stage'
        self.stage.mkdir(parents=True)
        (self.root/'.local').mkdir()
        fake = ModuleType('assemble')
        fake.ROOT = self.root
        fake.PRIVATE = self.private
        fake.STAGE = self.stage
        fake.MANIFEST = self.private/'manifest.json'
        fake.STOP = self.private/'STOP'
        fake.PUBLIC_PREFIX = 'results/runs/qwen35_4b_classification_matched16k_20261024_v5/'
        fake.check = lambda *, manifest_path: json.loads(Path(manifest_path).read_bytes())
        fake.valid_public_paths = lambda paths: True
        with patch.dict(sys.modules, {'assemble': fake}):
            spec = importlib.util.spec_from_file_location('invented_publisher_'+str(id(self)), HERE/'publish.py')
            self.p = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(self.p)
        self.paths = set(self.p.BASE_PATHS)|{self.p.ARCHIVE_MANIFEST, self.p.RAW_PREFIX+'.part0001.tar.gz'}
        self.blobs = {name: ('Invented reviewed fixture: '+name+'\n').encode() for name in self.paths}
        for name, raw in self.blobs.items():
            path = self.stage/name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
        self.manifest = {'kind': 'classification_matched16k_publication_manifest',
                         'public_files_sha256': {name: digest(raw) for name, raw in self.blobs.items()}}
        self.manifest_path = fake.MANIFEST
        self.manifest_path.write_text(json.dumps(self.manifest, sort_keys=True))
        self.manifest_sha = digest(self.manifest_path.read_bytes())
        self.review_path = self.private/'review.json'
        self.review = {'role': 'classification_exact_concrete_publication_review',
            'reviewer': self.p.REVIEWER, 'approved': True, 'manifest_sha256': self.manifest_sha,
            'public_files_sha256': self.manifest['public_files_sha256'],
            'repository': self.p.REPOSITORY, 'visibility': 'public',
            'root_authorization_sha256': self.p.AUTH_SHA,
            'secret_archive_scans_verified': True, 'exclusions_verified': True,
            'private_native_review_authority_verified': True, 'matched16k_scope_verified': True}
        self.save_review()
        self.helper_pins = {}
        for name in self.p.HELPER_PINS:
            path = self.root/name
            path.parent.mkdir(parents=True, exist_ok=True)
            raw = ('# Invented helper fixture '+name+'\n').encode()
            path.write_bytes(raw)
            self.helper_pins[name] = digest(raw)
        self.p.HELPER_PINS = self.helper_pins
        self.before, self.commit, self.head = '1'*40, '2'*40, '3'*40
        self.calls = []
        self.events = []
        self.fetches = 0
        self.index_mode = '100644'
        self.tree_mode = '100644'
        self.bad_index = self.bad_commit = self.bad_remote = False
        self.commit_action = None
        self.push_error = False
        self.committed = None
        self.helper = SimpleNamespace(URL=self.p.URL, REPOSITORY=self.p.REPOSITORY,
            ENV={'PATH': '/invented', 'GIT_CONFIG_COUNT': '1', 'GIT_SSH_COMMAND': 'invented'},
            git=self.git, confirm_destination=self.destination)
        for target in ('connect', 'connect_ex', 'bind'):
            guard = patch.object(socket.socket, target, side_effect=reject_live_call)
            guard.start();self.addCleanup(guard.stop)
        guard = patch.object(socket, 'create_connection', side_effect=reject_live_call)
        guard.start();self.addCleanup(guard.stop)
        guard = patch.object(self.p.subprocess, 'Popen', side_effect=reject_live_call)
        guard.start();self.addCleanup(guard.stop)

    def save_review(self):
        self.review_path.write_text(json.dumps(self.review, sort_keys=True))
        self.review_sha = digest(self.review_path.read_bytes())

    def destination(self):
        self.events.append('confirm_destination')
        self.assertTrue((self.private/'attempt_started.json').is_file())
        self.assertEqual(self.helper.ENV['GIT_CONFIG_GLOBAL'], os.devnull)
        self.assertEqual(self.helper.ENV['GIT_CONFIG_NOSYSTEM'], '1')
        self.assertNotIn('GIT_CONFIG_COUNT', self.helper.ENV)
        self.assertNotIn('GIT_SSH_COMMAND', self.helper.ENV)
        return {'repository': self.p.REPOSITORY, 'visibility': 'public', 'push_permission': True}

    def git(self, *args, cwd):
        self.calls.append(args)
        text = ''
        if args[0] == 'fetch':
            self.fetches += 1
        elif args[:2] == ('rev-parse', 'FETCH_HEAD'):
            text = self.before if self.fetches == 1 else self.head
        elif args[:2] == ('rev-parse', 'HEAD'):
            text = self.commit
        elif args[:3] == ('diff', '--cached', '--name-only') or args[:2] == ('diff', '--name-only'):
            text = '\n'.join(sorted(self.paths))+'\n'
        elif args[0] == 'ls-files':
            text = ''.join(self.index_mode+' '+'a'*40+' 0\t'+name+'\0' for name in sorted(self.paths))
        elif args[0] == 'ls-tree':
            text = ''.join(self.tree_mode+' blob '+'a'*40+'\t'+name+'\0' for name in sorted(self.paths))
        elif args[0] == 'commit':
            self.committed = {name: (Path(cwd)/name).read_bytes() for name in self.paths}
            if self.commit_action:
                self.commit_action()
        elif args[0] == 'push':
            self.assertTrue((self.private/'attempt_started.json').is_file())
            intent = self.p.read(self.private/'push_intent.json')
            self.assertEqual(intent['public_files_sha256'], self.manifest['public_files_sha256'])
            self.assertEqual(intent['commit_sha'], self.commit)
            self.events.append('push')
            if self.push_error:
                raise RuntimeError('Invented ambiguous push failure')
        return SimpleNamespace(stdout=text, returncode=0)

    def blob(self, checkout, revision_path):
        revision, name = revision_path.split(':', 1)
        if revision == '':
            return '0'*64 if self.bad_index else digest((Path(checkout)/name).read_bytes())
        if revision == self.commit:
            return '0'*64 if self.bad_commit else digest(self.committed[name])
        if revision == self.head:
            return '0'*64 if self.bad_remote else digest(self.committed[name])
        raise AssertionError('Unexpected invented revision')

    def publish(self, manifest_path=None):
        with patch.object(self.p, 'load', return_value=self.helper), \
                patch.object(self.p, 'git_blob_sha', side_effect=self.blob), \
                contextlib.redirect_stdout(io.StringIO()):
            return self.p.publish(self.manifest, self.manifest_sha, self.review_path,
                                  self.review_sha, manifest_path or self.manifest_path)

    def assert_no_push(self):
        self.assertFalse(any(row[0] == 'push' for row in self.calls))
        self.assertFalse((self.private/'publication_receipt.json').exists())

    def test_actual_main_offline_checks_never_load_git_or_claim(self):
        with patch.object(sys, 'argv', ['publish.py', '--manifest', str(self.manifest_path),
                '--manifest-sha256', self.manifest_sha]), patch.object(self.p, 'load') as load, \
                contextlib.redirect_stdout(io.StringIO()) as output:
            self.p.main()
        load.assert_not_called()
        self.assertFalse(json.loads(output.getvalue())['published'])
        self.assertFalse((self.private/'attempt_started.json').exists())

    def test_happy_mocked_publish_verifies_index_commit_remote_and_clean_env(self):
        result = self.publish()
        self.assertEqual(result['public_files_sha256'], self.manifest['public_files_sha256'])
        self.assertEqual(result['published_path_count'], 10)
        self.assertTrue(result['remote_bytes_verified'])
        self.assertEqual(result['verified_remote_main_head'], self.head)
        self.assertEqual(sum(row[0] == 'push' for row in self.calls), 1)
        self.assertEqual(sum(row[0] == 'ls-tree' for row in self.calls), 3)
        self.assertLess(next(i for i,row in enumerate(self.calls) if row[0]=='ls-files'),
                        next(i for i,row in enumerate(self.calls) if row[0]=='commit'))

    def test_exact_contiguous_archive_paths_and_digest_types(self):
        files = self.manifest['public_files_sha256']
        for count in (1, 2, 256):
            good = {name: 'a'*64 for name in self.p.BASE_PATHS|{self.p.ARCHIVE_MANIFEST}}
            good.update({self.p.RAW_PREFIX+'.part'+str(n).zfill(4)+'.tar.gz': 'a'*64 for n in range(1,count+1)})
            self.assertEqual(self.p.validate_paths(good), set(good))
        wrong = [dict(files, **{'docs/private.md': 'a'*64}), {k:v for k,v in files.items() if k != self.p.REPORT},
                 dict(files, **{self.p.RAW_PREFIX+'.part0003.tar.gz': 'a'*64}),
                 dict(files, **{self.p.REPORT: 'not-a-digest'})]
        for files in wrong:
            with self.subTest(paths=list(files)), self.assertRaises(ValueError):
                self.p.validate_paths(files)

    def test_owner_or_foreign_review_rejected_before_any_attempt_or_git(self):
        for reviewer in (self.p.OWNER, '/root/unrelated', '/root/priority_runtime_review'):
            self.review['reviewer'] = reviewer
            self.save_review()
            with self.subTest(reviewer=reviewer), self.assertRaises(PermissionError):
                self.publish()
        self.assertEqual(self.calls, [])
        self.assertFalse((self.private/'attempt_started.json').exists())

    def test_dangling_STOP_and_existing_ambiguous_attempt_block_all_calls(self):
        self.p.STOP.symlink_to(self.private/'absent')
        with self.assertRaises(PermissionError):self.publish()
        self.p.STOP.unlink()
        (self.private/'push_intent.json').symlink_to(self.private/'absent')
        with self.assertRaises(FileExistsError):self.publish()
        self.assertEqual(self.calls, [])

    def test_symlink_stage_or_parent_is_rejected(self):
        path = self.stage/self.p.REPORT
        raw = path.read_bytes();other = self.root/'invented.txt';other.write_bytes(raw)
        path.unlink();path.symlink_to(other)
        with self.assertRaises(OSError):self.publish()
        self.assert_no_push()
        path.unlink();path.write_bytes(raw)
        reports = self.stage/'reports'
        reports.rename(self.stage/'reports-real')
        reports.symlink_to(self.stage/'reports-real', target_is_directory=True)
        with self.assertRaises(OSError):self.publish()
        self.assertEqual(self.calls, [])

    def test_manifest_or_stage_drift_before_attempt_rejected(self):
        self.manifest_path.write_text('{}')
        with self.assertRaises(ValueError):self.publish()
        self.assertFalse((self.private/'attempt_started.json').exists())

    def test_private_authority_check_failure_creates_no_attempt(self):
        with patch.object(self.p, 'check', side_effect=PermissionError('Invented native review missing')):
            with self.assertRaises(PermissionError):self.publish()
        self.assertFalse((self.private/'attempt_started.json').exists())
        self.assertEqual(self.calls, [])

    def test_index_symlink_mode_or_wrong_staged_blob_rejected_before_commit(self):
        self.index_mode = '120000'
        with self.assertRaises(ValueError):self.publish()
        self.assert_no_push()
        self.assertFalse(any(row[0] == 'commit' for row in self.calls))

    def test_wrong_staged_bytes_rejected_before_commit(self):
        self.bad_index = True
        with self.assertRaises(ValueError):self.publish()
        self.assert_no_push()
        self.assertFalse(any(row[0] == 'commit' for row in self.calls))

    def test_wrong_commit_blob_rejected_before_push(self):
        self.bad_commit = True
        with self.assertRaises(ValueError):self.publish()
        self.assert_no_push()
        self.assertFalse((self.private/'push_intent.json').exists())

    def test_stage_drift_during_commit_fails_final_authority_check(self):
        self.commit_action = lambda: (self.stage/self.p.REPORT).write_bytes(b'Invented tampering')
        with self.assertRaises(ValueError):self.publish()
        self.assert_no_push()
        self.assertFalse((self.private/'push_intent.json').exists())

    def test_review_drift_during_commit_fails_before_push_intent(self):
        self.commit_action = lambda: self.review_path.write_text('{}')
        with self.assertRaises(PermissionError):self.publish()
        self.assert_no_push()
        self.assertFalse((self.private/'push_intent.json').exists())

    def test_helper_drift_during_commit_fails_before_push_intent(self):
        name = next(iter(self.helper_pins))
        self.commit_action = lambda: (self.root/name).write_bytes(b'Invented source drift')
        with self.assertRaises(ValueError):self.publish()
        self.assert_no_push()

    def test_STOP_after_durable_push_intent_prevents_push(self):
        original = self.p.durable_json
        def save(path, value):
            original(path, value)
            if Path(path).name == 'push_intent.json':self.p.STOP.write_text('Invented concurrent STOP')
        with patch.object(self.p, 'durable_json', side_effect=save):
            with self.assertRaises(PermissionError):self.publish()
        self.assertTrue((self.private/'push_intent.json').exists())
        self.assert_no_push()

    def test_attempt_parent_fsync_failure_prevents_all_git(self):
        real = os.fsync
        def sync(fd):
            if stat.S_ISDIR(os.fstat(fd).st_mode):raise OSError('Invented parent fsync failure')
            return real(fd)
        with patch.object(self.p.os, 'fsync', side_effect=sync):
            with self.assertRaises(OSError):self.publish()
        self.assertTrue((self.private/'attempt_started.json').exists())
        self.assertEqual(self.calls, [])

    def test_push_intent_parent_fsync_failure_prevents_push_and_replay(self):
        real = os.fsync;count = [0]
        def sync(fd):
            if stat.S_ISDIR(os.fstat(fd).st_mode):
                count[0] += 1
                if count[0] == 2:raise OSError('Invented push-intent parent fsync failure')
            return real(fd)
        with patch.object(self.p.os, 'fsync', side_effect=sync):
            with self.assertRaises(OSError):self.publish()
        self.assertTrue((self.private/'push_intent.json').exists())
        self.assert_no_push()
        with self.assertRaises(FileExistsError):self.publish()

    def test_ambiguous_push_preserved_and_never_retried(self):
        self.push_error = True
        with self.assertRaises(RuntimeError):self.publish()
        self.assertTrue((self.private/'attempt_started.json').exists())
        self.assertTrue((self.private/'push_intent.json').exists())
        self.assertFalse((self.private/'publication_receipt.json').exists())
        with self.assertRaises(FileExistsError):self.publish()
        self.assertEqual(sum(row[0]=='push' for row in self.calls), 1)

    def test_remote_blob_mismatch_preserves_attempt_without_success_receipt(self):
        self.bad_remote = True
        with self.assertRaises(ValueError):self.publish()
        self.assertFalse((self.private/'publication_receipt.json').exists())
        with self.assertRaises(FileExistsError):self.publish()
        self.assertEqual(sum(row[0]=='push' for row in self.calls), 1)

    def test_explicit_manifest_path_is_rechecked_and_recorded(self):
        alternate = self.private/'alternate-reviewed-manifest.json'
        alternate.write_bytes(self.manifest_path.read_bytes())
        self.manifest_path.unlink()
        result = self.publish(alternate)
        self.assertEqual(result['manifest_path'], str(alternate))
        self.assertEqual(self.p.read(self.private/'push_intent.json')['manifest_path'], str(alternate))

    def test_anchored_shared_lock_rejects_symlink_parent(self):
        folder = self.root/'lock-real';folder.mkdir()
        linked = self.root/'lock-linked';linked.symlink_to(folder, target_is_directory=True)
        with self.assertRaises(OSError):
            with self.p.exclusive_lock(linked/'invented.lock'):pass
        self.assertFalse((folder/'invented.lock').exists())


if __name__ == '__main__':
    unittest.main()
