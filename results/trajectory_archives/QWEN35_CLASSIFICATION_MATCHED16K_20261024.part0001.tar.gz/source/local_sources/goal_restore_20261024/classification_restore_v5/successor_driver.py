"""Generate only frozen never-claimed inputs under the unchanged16K condition."""
from pathlib import Path
from collections import Counter
import argparse
import fcntl
import importlib.metadata
import json
import os

import restore_controls as C


def arguments():
    parser = argparse.ArgumentParser()
    for name in ('plan', 'grant', 'boundary', 'closure'):
        parser.add_argument('--' + name, type=Path, required=True)
        parser.add_argument('--' + name + '-sha256', required=True)
    parser.add_argument('--model-key', choices=('base', 'posttrained'), required=True)
    return parser.parse_args()


def validate_args(args):
    return C.validate(args.plan, args.plan_sha256, args.grant, args.grant_sha256, args.model_key,
                      args.boundary, args.boundary_sha256, args.closure, args.closure_sha256)


def eligible_rows(task_boundary, inputs):
    cases = task_boundary['cases']
    C.require(len(cases) == len(inputs) == task_boundary['planned'], 'Full original native denominator changed')
    selected = []
    for index, (record, case) in enumerate(zip(cases, inputs)):
        C.require(record['index'] == index and record['case_id'] == case['case_id'], 'Boundary original ordering changed')
        if record['eligible_for_new_model_call']:
            C.require(record['outcome_state'] == 'unclaimed' and record['request'] is None
                      and record['response'] is None, 'A previous claim or saved outcome must never be regenerated')
            selected.append((index, case))
        else:
            C.require(record['outcome_state'] in {'inherited_saved_response', 'ambiguous_claim_invalid'},
                      'Unknown noneligible boundary outcome state')
    return selected


def original_still_unclaimed(task_boundary, index):
    folder = Path(task_boundary['runtime_path']) / 'cases' / f'{index:06d}'
    C.require(not folder.is_symlink(), 'Original empty case directory changed to symlink')
    if folder.exists():
        C.require(folder.is_dir() and not any(folder.iterdir()),
                  'Original case received a new claim/response after the terminal boundary')


def summary(outputs, planned, expected_new):
    return {'at_pacific': C.stamp(), 'full_native_planned': planned,
            'new_eligible_planned': expected_new, 'new_outcomes_saved': len(outputs),
            'new_attempted_confirmed': sum(row.get('status') in {'completed', 'response_error'} for row in outputs),
            'new_truncations': sum(row.get('finish_reason') == 'length' for row in outputs),
            'new_empty_finals': sum(not (row.get('final') or '').strip() for row in outputs),
            'new_finish_reasons': dict(Counter(row.get('finish_reason') for row in outputs)),
            'counts_role': 'new_successor_outcomes_only_unsealed_lower_bound',
            'transport_errors': 0, 'http_errors': 0, 'biological_correctness_assessed': False,
            'endpoint': 'in_process_vllm_no_HTTP'}


def generate_task(session, plan, science, boundary, args, condition):
    key, task = args.model_key, condition['task_id']
    task_boundary = boundary['tasks'][task]
    source = next(row for row in science['tasks'] if row['task_id'] == task)
    C.require(C.sha(source['input_path']) == source['input_sha256'], 'Frozen complete input file changed')
    inputs = [json.loads(line) for line in C.regular(source['input_path']).decode().splitlines()]
    selected = eligible_rows(task_boundary, inputs)
    run = Path(plan['models'][key]['successor_runtime']) / task
    run.mkdir(parents=True, exist_ok=True)
    with (run / 'run.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        C.require(not (run / 'started.json').exists() and not (run / 'cases').exists(),
                  'Successor task already attempted; never retry an uncertain or completed run')
        (run / 'cases').mkdir()
        identity = {name: condition[name] for name in ('model', 'model_revision', 'model_key', 'task_id', 'run_id')}
        identity.update(plan_sha256=C.SCIENCE_SHA, continuation_plan_sha256=args.plan_sha256,
                        boundary_sha256=args.boundary_sha256, closure_sha256=args.closure_sha256,
                        job_id=os.environ['SLURM_JOB_ID'])
        C.save(run / 'started.json', {**identity, 'at_pacific': C.stamp(), 'new_eligible_planned': len(selected),
                                      'full_native_planned': len(inputs), 'inherits_all_prior_outcomes': True})
        outputs = []
        for start in range(0, len(selected), 16):
            batch = selected[start:start + 16]
            prepared = []
            requests = []
            for index, case in batch:
                original_still_unclaimed(task_boundary, index)
                item = session.prepare({'case_id': case['case_id'], 'task_id': case['task'], 'messages': case['messages']})
                folder = run / 'cases' / f'{index:06d}'
                folder.mkdir()
                C.save(folder / 'claim.json', {**identity, 'case_id': case['case_id'], 'index': index,
                    'prepared_request_sha256': item['request_sha256'], 'at_pacific': C.stamp(),
                    'role': 'exclusive_new_unclaimed_case_intent_not_dispatch_evidence', 'one_attempt_only': True})
                claim_sha = C.sha(folder / 'claim.json')
                request = {**identity, 'case_id': case['case_id'], 'index': index,
                           'messages': case['messages'], 'generation': science['generation'], 'prepared': item,
                           'claim_sha256': claim_sha, 'at_pacific': C.stamp()}
                C.save(folder / 'request.json', request)
                prepared.append(item); requests.append(folder / 'request.json')
            # Check again after all intents are durable, immediately before the
            # only model call. No fresh original claim may be bypassed.
            for index, case in batch:
                original_still_unclaimed(task_boundary, index)
            try:
                C.check_restore()
                results = session.generate_prepared(prepared)
                C.save(run / f'raw_normalized_batch_{start:06d}.json', results)
                C.require(isinstance(results, list) and len(results) == len(batch)
                          and [row.get('case_id') for row in results] == [case['case_id'] for _, case in batch],
                          'Uncertain batch count, association or source identity')
            except Exception as error:
                C.save(run / f'ambiguous_batch_{start:06d}.json', {**identity, 'at_pacific': C.stamp(),
                    'case_ids': [case['case_id'] for _, case in batch], 'exception_type': type(error).__name__,
                    'exception': str(error)[:2000], 'actual_dispatch_unknown': True, 'no_retry': True})
                for (index, case), request in zip(batch, requests):
                    C.save(request.parent / 'ambiguous_attempt.json', {**identity, 'case_id': case['case_id'],
                        'index': index, 'request_sha256': C.sha(request), 'actual_dispatch_unknown': True,
                        'status': 'generation_exception', 'no_raw_response_available': True, 'no_retry': True})
                raise
            classifier = C.module(C.LANE / 'driver.py', 'unchanged_successor_refusal_rule')
            stop = False
            for ((index, case), item, request, result) in zip(batch, prepared, requests, results):
                C.require(result.get('request_sha256') == item['request_sha256'], 'Returned request identity differs')
                result.update(classifier.classify_refusal(result.get('final_text', result.get('final', '')) or '', result.get('refusal', False)))
                output = {**result, **identity, 'case_id': case['case_id'], 'index': index,
                          'request_sha256': C.sha(request), 'prepared_request_sha256': item['request_sha256'],
                          'claim_sha256': C.sha(request.parent / 'claim.json'), 'at_pacific': C.stamp()}
                C.save(request.parent / 'response.json', output)
                outputs.append(output)
                stop |= C.fatal_output(output, science)
            C.update(run / 'progress.json', {**identity, **summary(outputs, len(inputs), len(selected))})
            if stop:
                C.save(run / 'stopped.json', {**identity, 'at_pacific': C.stamp(),
                    'reason': 'Fatal/explicit refusal/tool/turn/ambiguous delivery; preserve all outcomes and stop without retry.'})
                raise ValueError('Successor fatal delivery stop; never resume or extend automatically')
        C.save(run / 'new_generation_completion.json', {**identity, **summary(outputs, len(inputs), len(selected)),
            'all_frozen_unclaimed_cases_have_real_saved_responses': True,
            'already_saved_or_ambiguous_original_cases_regenerated': 0})
    return run


def main():
    args = arguments()
    plan, science, boundary, closure = validate_args(args)
    C.require(bool(os.environ.get('SLURM_JOB_ID')), 'Actual admitted successor Slurm job required')
    runtime = Path(plan['models'][args.model_key]['successor_runtime'])
    IPC_local = Path(C.read(runtime / 'runtime_extraction.json')['local'])
    C.ipc_path_preflight(IPC_local, os.environ, bind=True)
    parent_claim = C.read(runtime / 'driver_process_claim.json')
    C.require(parent_claim.get('parent_pid') == os.getppid() and parent_claim.get('model_key') == args.model_key
              and parent_claim.get('operational_plan_sha256') == args.plan_sha256,
              'Require exact admitted worker parent process')
    invocation = (runtime / 'driver.lock').open('a')
    fcntl.flock(invocation, fcntl.LOCK_EX | fcntl.LOCK_NB)
    C.save(runtime / 'driver_invocation_claim.json', {'at_pacific': C.stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
        'model_key': args.model_key, 'operational_plan_sha256': args.plan_sha256, 'no_retry': True})
    with C.terminal_original_locks(plan, science, boundary, closure, args.model_key) as proof:
        C.save(runtime / 'driver_fresh_predecessor_proof.json', proof)
        common = C.module(science['shared_runtime']['path'], 'unchanged16K_successor_runtime')
        contract = common.load_contract(science['shared_contract']['path'], science['shared_contract']['sha256'])
        C.require(contract['generation'] == science['generation'], 'Original scientific generation changed')
        packages = {name: importlib.metadata.version(name) for name in contract['runtime_expected']}
        C.require(all(packages[name].split('+')[0] == expected for name, expected in contract['runtime_expected'].items()),
                  'Actual pinned runtime package identity differs')
        pending = sum(len(task['eligible_case_ids']) for task in boundary['tasks'].values()
                      if task['task_state'] != 'already_scored_preserve_without_rescoring')
        C.save(runtime / 'private_gpu_audit_driver.json', C.audit(plan, own=True))
        C.save(runtime / 'private_IPC_preflight_driver.json', C.ipc_path_preflight(IPC_local, os.environ, bind=True))
        session = common.create_session(args.model_key, contract, max_num_seqs=16) if pending else None
        tokenizer = session.tokenizer if session is not None else None
        effective, GPU = None, None
        if session is not None:
            import torch
            C.require(torch.cuda.device_count() == 1, 'Exactly one actual visible successorGPU required')
            effective = {key: getattr(session.params, key) for key in contract['generation']
                         if key not in {'return_token_ids', 'add_special_tokens'}}
            C.require(effective == {key: value for key, value in contract['generation'].items()
                                   if key not in {'return_token_ids', 'add_special_tokens'}},
                      'Actual native SamplingParams differs from unchanged16K scientific condition')
            actual = session.llm.llm_engine.vllm_config
            C.require(actual.model_config.max_model_len == 65536 and actual.scheduler_config.max_num_seqs == 16
                      and actual.scheduler_config.max_num_batched_tokens == 8192
                      and str(actual.model_config.dtype) == 'torch.bfloat16',
                      'Actual successor context/concurrency/precision differs')
            GPU = {'visible_count': 1, 'name': torch.cuda.get_device_name(0),
                   'total_memory_bytes': torch.cuda.get_device_properties(0).total_memory,
                   'allocated_bytes': torch.cuda.memory_allocated(0), 'reserved_bytes': torch.cuda.memory_reserved(0),
                   'kv_cache_size_tokens': getattr(actual.cache_config, 'kv_cache_size_tokens', None),
                   'kv_cache_max_concurrency': getattr(actual.cache_config, 'kv_cache_max_concurrency', None)}
        C.save(runtime / 'actual_runtime.json', {'at_pacific': C.stamp(), 'packages': packages,
            'shared_contract_sha256': science['shared_contract']['sha256'], 'max_num_seqs': 16,
            'output_budget': 16384, 'context_limit': 65536, 'dtype': 'bfloat16',
            'new_eligible_calls': pending, 'same_scientific_condition': True, 'old_modes_restored': False,
            'effective_native_sampling': effective, 'GPU': GPU})
        ledger = C.module(HERE_LEDGER, 'successor_native_outcome_ledger')
        results = {}
        for task in ('P03', 'P01'):
            condition = next(row for row in science['conditions'] if row['model_key'] == args.model_key and row['task_id'] == task)
            if boundary['tasks'][task]['task_state'] == 'already_scored_preserve_without_rescoring':
                run = Path(plan['models'][args.model_key]['successor_runtime']) / task
            else:
                run = generate_task(session, plan, science, boundary, args, condition)
            results[task] = ledger.seal_and_score(science, boundary, args.model_key, task, run,
                args.plan_sha256, args.boundary_sha256, args.closure_sha256, tokenizer=tokenizer,
                boundary_path=args.boundary, closure_path=args.closure)
        C.save(runtime / 'model_completed.json', {'at_pacific': C.stamp(), 'model_key': args.model_key,
            'job_id': os.environ['SLURM_JOB_ID'], 'scientific_plan_sha256': C.SCIENCE_SHA,
            'operational_plan_sha256': args.plan_sha256, 'boundary_sha256': args.boundary_sha256,
            'closure_sha256': args.closure_sha256, 'full_native_denominator': 4772,
            'all_original_and_successor_tasks_scored': True, 'task_results': results,
            'no_further_successor_chain_authorized': True})


HERE_LEDGER = C.HERE / 'ledger_score.py'

if __name__ == '__main__':
    C.check_restore(full=True)
    main()
