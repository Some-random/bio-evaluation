"""One72h allocation for exactly one unchanged-condition model successor."""
from pathlib import Path
import argparse
import fcntl
import os
import subprocess
import tempfile

import restore_controls as C
from successor_driver import arguments, validate_args


def main():
    args = arguments()
    plan, science, boundary, closure = validate_args(args)
    C.require(bool(os.environ.get('SLURM_JOB_ID')), 'Actual oneGPU Slurm successor required')
    runtime = Path(plan['models'][args.model_key]['successor_runtime'])
    runtime.mkdir(parents=True, exist_ok=True)
    C.ipc_path_preflight()
    lock = (runtime / 'worker.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    C.require(not (runtime / 'worker_started.json').exists(), 'Successor already attempted; no automatic replay or chain')
    C.save(runtime / 'worker_started.json', {'at_pacific': C.stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
        'model_key': args.model_key, 'operational_plan_sha256': args.plan_sha256,
        'scientific_plan_sha256': C.SCIENCE_SHA, 'binding_sha256': args.grant_sha256,
        'boundary_sha256': args.boundary_sha256, 'closure_sha256': args.closure_sha256})
    try:
        # Release these original locks before spawning the child. The child
        # freshly reacquires and retains them through generation+offline score.
        with C.terminal_original_locks(plan, science, boundary, closure, args.model_key) as proof:
            C.save(runtime / 'worker_fresh_predecessor_proof.json', proof)
            C.save(runtime / 'private_gpu_audit_worker.json', C.audit(plan, own=True))
        common = C.module(science['shared_runtime']['path'], 'unchanged16K_worker_runtime')
        contract = common.load_contract(science['shared_contract']['path'], science['shared_contract']['sha256'])
        C.require(os.environ['SLURM_JOB_ID'].isdigit() and len(os.environ['SLURM_JOB_ID']) <= 20, 'Bounded numeric Slurm job ID required')
        local = Path(tempfile.mkdtemp(prefix='bc-' + os.environ['SLURM_JOB_ID'] + '-', dir='/tmp'))
        C.ipc_path_preflight(local)
        python, env, extraction = common.restore_runtime(local, contract)
        env['PYTHONPATH'] = str(C.HERE)
        IPC = C.ipc_path_preflight(local, env, bind=True)
        C.save(runtime / 'runtime_extraction.json', {'at_pacific': C.stamp(), 'local': str(local),
            'archive_verification': extraction, 'credentials_removed': True,
            'no_original_modes_restored': True, 'no_original_requests_or_responses_written': True,
            'private_IPC_preflight': IPC})
        C.save(runtime / 'driver_process_claim.json', {'at_pacific': C.stamp(), 'parent_pid': os.getpid(),
            'model_key': args.model_key, 'operational_plan_sha256': args.plan_sha256,
            'one_attempt_only': True})
        command = [str(python), str(Path(__file__).resolve().parent / 'successor_driver.py')]
        for name in ('plan', 'grant', 'boundary', 'closure'):
            command.extend(['--' + name, str(getattr(args, name).resolve()),
                            '--' + name + '-sha256', getattr(args, name + '_sha256')])
        command.extend(['--model-key', args.model_key])
        with (runtime / 'generation.log').open('x') as log:
            outcome = subprocess.run(command, env=env, cwd=local, stdout=log, stderr=subprocess.STDOUT)
        C.require(outcome.returncode == 0, 'Successor process failed; preserve actual/uncertain attempts, no retry')
        completion = C.read(runtime / 'model_completed.json')
        C.require(completion.get('all_original_and_successor_tasks_scored') is True,
                  'Full original denominator task scores not sealed')
    except Exception as error:
        C.save(runtime / 'worker_terminal.json', {'at_pacific': C.stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
            'model_key': args.model_key, 'operational_plan_sha256': args.plan_sha256, 'completed': False,
            'exception_type': type(error).__name__, 'exception': str(error)[:2000],
            'no_automatic_retry_or_second_successor': True})
        raise
    C.save(runtime / 'worker_terminal.json', {'at_pacific': C.stamp(), 'job_id': os.environ['SLURM_JOB_ID'],
        'model_key': args.model_key, 'operational_plan_sha256': args.plan_sha256, 'completed': True,
        'model_completion_sha256': C.sha(runtime / 'model_completed.json'),
        'no_automatic_retry_or_second_successor': True})


if __name__ == '__main__':
    C.check_restore(full=True)
    main()
