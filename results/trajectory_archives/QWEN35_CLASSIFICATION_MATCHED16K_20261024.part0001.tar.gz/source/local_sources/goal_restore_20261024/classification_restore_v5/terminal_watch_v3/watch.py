"""Finite zero-GPU observer of exact jobs and native terminal seals.

No generation, reference parsing, rescoring, package, publication or job mutation.
"""
from contextlib import ExitStack, contextmanager
from pathlib import Path
from datetime import datetime, timezone
import argparse
import fcntl
import hashlib
import importlib
import json
import os
import re
import stat
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
RUNTIME = HERE.parent / 'runtime'
ROOT = HERE.parents[3]
OWNER = '/root/priority_runtime_review/lpb398_verifier_tests/joint_restart_review'
JOBS = {'base': '249732', 'posttrained': '249734'}
STARTS = {'base': '2026-10-24T14:09:39', 'posttrained': '2026-10-24T14:10:21'}
PLANNED = {'P03': 2773, 'P01': 1999}
ACTIVE = {'PENDING', 'RUNNING', 'CONFIGURING', 'COMPLETING', 'SUSPENDED', 'RESIZING'}
TERMINAL = {'COMPLETED', 'FAILED', 'CANCELLED', 'TIMEOUT', 'OUT_OF_MEMORY', 'NODE_FAIL',
            'PREEMPTED', 'BOOT_FAIL', 'DEADLINE', 'REVOKED'}
MAX_SECONDS = 73 * 3600


def now(): return datetime.now(timezone.utc).isoformat()
def require(value, message):
    if not value: raise ValueError(message)


def regular(path):
    path = Path(path)
    require(path.is_absolute() and path == path.resolve(), 'Canonical nonsymlink file required')
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'Existing regular file required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    opened = os.fstat(fd)
    if (before.st_dev, before.st_ino) != (opened.st_dev, opened.st_ino):
        os.close(fd); raise ValueError('File changed while opening')
    return fd


def sha(path):
    digest = hashlib.sha256()
    with os.fdopen(regular(path), 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): digest.update(block)
    return digest.hexdigest()


def read(path):
    with os.fdopen(regular(path), 'rb') as stream: return json.load(stream)


def save(path, value):
    path = Path(path)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(descriptor)
    finally: os.close(descriptor)


def status(stage, **extra):
    target = HERE / 'watch_status.json'
    temporary = HERE / ('watch_status.' + str(os.getpid()) + '.' + str(time.time_ns()) + '.tmp')
    save(temporary, {'at_utc': now(), 'stage': stage, 'GPU_requests': 0, 'model_calls': 0,
                     'scoring_calls': 0, 'scheduler_mutations': 0, 'publishes': False, **extra})
    temporary.replace(target)
    descriptor = os.open(HERE, os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(descriptor)
    finally: os.close(descriptor)


def source_check(freeze_sha, review_sha):
    require(not os.path.lexists(HERE / 'STOP'), 'Terminal observer STOP remains authoritative')
    freeze_path, review_path = HERE / 'source_freeze_v3.json', HERE / 'independent_source_review_v3.json'
    require(sha(freeze_path) == freeze_sha and sha(review_path) == review_sha, 'Exact peer source binding changed')
    freeze, review = read(freeze_path), read(review_path)
    require(freeze.get('role') == 'classification_finite_zero_GPU_terminal_observer'
            and freeze.get('GPU_requests') == freeze.get('model_calls') == freeze.get('scoring_calls') == 0
            and freeze.get('scheduler_mutations_by_observer') == 0 and freeze.get('publishes') is False
            and freeze.get('maximum_watch_seconds') == MAX_SECONDS and freeze.get('jobs') == JOBS
            and freeze.get('job_starts') == STARTS and freeze.get('planned_per_model') == PLANNED
            and freeze.get('CPU_QoS') == 'il-cpu-long' and freeze.get('Slurm_TimeLimit') == '3-02:00:00'
            and freeze.get('requested_CPUs') == 1 and freeze.get('maximum_allocated_CPU_threads') == 2,
            'Fixed finite terminal-only observer scope required')
    require(review.get('approved') is True and review.get('reviewer') == '/root/independent_review'
            and review.get('reviewer') != OWNER
            and review.get('role') == 'classification_finite_terminal_watch_source_review'
            and review.get('source_freeze_sha256') == freeze_sha
            and review.get('runtime_manifest_sha256') == freeze['runtime_manifest_sha256'],
            'Exact independent finite observer source review required')
    require({str(HERE / name) for name in ('watch.py', 'watch.sbatch', 'submit_once.py', 'test_watch.py')}
            <= set(freeze['files_sha256']), 'Every observer executable and regression source must be pinned')
    for path, expected in freeze['files_sha256'].items():
        require(sha(path) == expected, 'Observer source changed: ' + path)
    for path, expected in freeze['static_evidence_sha256'].items():
        require(sha(path) == expected, 'Exact runtime/control evidence changed: ' + path)
    if str(HERE.parent) not in sys.path: sys.path.insert(0, str(HERE.parent))
    controls = importlib.import_module('restore_controls')
    controls.check_restore(full=True, allow_stop=True)
    # The pinned original loader excludes scorer-only reference files.
    plan = controls.load_plan(controls.ORIGINAL / 'operational_plan.json',
                              freeze['original_operational_plan_sha256'])
    return freeze, controls, plan


def own_cpu_job(job):
    output = subprocess.check_output(['scontrol', 'show', 'job', job, '-o'], text=True, timeout=30)
    fields = dict(re.findall(r'(?:^|\s)([A-Za-z][A-Za-z0-9]*)=(\S*)', output))
    requested = dict(item.split('=', 1) for item in fields.get('ReqTRES', '').split(',') if '=' in item)
    allocated = dict(item.split('=', 1) for item in fields.get('AllocTRES', '').split(',') if '=' in item)
    require(fields.get('JobId') == job and fields.get('UserId') == 'dongweij(26129)'
            and fields.get('Command') == str(HERE / 'watch.sbatch') and fields.get('WorkDir') == str(ROOT)
            and fields.get('Partition') == 'il-cpu' and fields.get('JobState') == 'RUNNING'
            and fields.get('NumCPUs') in {'1', '2'} and fields.get('NumTasks') == '1'
            and requested.get('cpu') == '1' and allocated.get('cpu') == fields.get('NumCPUs')
            and fields.get('TresPerTask') == 'cpu=1'
            and fields.get('QOS') == 'il-cpu-long' and fields.get('TimeLimit') == '3-02:00:00'
            and fields.get('NumNodes') == '1' and fields.get('Restarts') == '0'
            and 'gres/gpu' not in fields.get('ReqTRES', '') and 'gres/gpu' not in fields.get('AllocTRES', ''),
            'Actual exact one requested CPU and at most two allocated threads with zero GPUs required')
    return {'job_id': job, 'partition': 'il-cpu', 'QoS': 'il-cpu-long', 'TimeLimit': '3-02:00:00',
            'requested_CPUs': 1, 'allocated_CPU_threads': int(fields['NumCPUs']), 'GPU_requests': 0,
            'exact_owner_command_workspace_verified': True}


def account(model):
    job = JOBS[model]
    output = subprocess.check_output(['sacct', '-j', job, '--parsable2', '-n',
        '--format=JobIDRaw,State,ExitCode,User,UID,Start,End,ReqTRES,AllocTRES,WorkDir'],
        text=True, timeout=30)
    rows = [line.split('|') for line in output.splitlines() if line.startswith(job + '|')]
    require(len(rows) == 1 and len(rows[0]) == 10, 'Exact actual native job accounting required')
    row = rows[0]; state = row[1].split()[0].rstrip('+')
    require(row[3] == 'dongweij' and row[4] == '26129' and row[9] == str(ROOT) and row[5] == STARTS[model]
            and 'gres/gpu=1' in row[7].split(',') and 'gres/gpu=1' in row[8].split(','),
            'Exact model job owner/workspace/one-GPU identity changed')
    require(state in ACTIVE | TERMINAL, 'Unknown actual native job state')
    if state in TERMINAL:
        require(state == 'COMPLETED' and row[2] == '0:0', 'Actual native job '+job+' failed: '+state+'/'+row[2]+'; preserve without retry')
    return {'job_id': job, 'state': state, 'exit_code': row[2], 'start': row[5], 'end': row[6],
            'terminal': state == 'COMPLETED', 'raw_accounting': output}


@contextmanager
def free_owned_lock(path):
    descriptor = regular(path)
    try:
        opened = os.fstat(descriptor)
        require(opened.st_uid == os.getuid(), 'Owned terminal lock required')
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        after = Path(path).lstat()
        require((opened.st_dev, opened.st_ino) == (after.st_dev, after.st_ino), 'Terminal lock changed')
        yield {'path': str(path), 'ino': opened.st_ino, 'uid': opened.st_uid,
               'existing_regular_owned_lock_acquired_free': True}
    finally: os.close(descriptor)


def task_metadata(folder, model, task):
    done, score, lock, scored = [read(folder / name) for name in
        ('completion.json', 'scores.json', 'prediction_lock.json', 'scoring_completion.json')]
    planned = PLANNED[task]
    require(done.get('planned') == done.get('terminal') == score.get('planned') == lock.get('planned') == planned
            and score.get('metrics', {}).get('planned') == planned
            and done.get('all_planned_outcome_slots_sealed') is True
            and done.get('all_original_case_denominators_preserved') is True
            and lock.get('all_planned_outcome_slots_sealed') is True and lock.get('labels_loaded') is False
            and score.get('native_parser_and_metric_unchanged') is True
            and score.get('same_scientific_condition_as_original') is True
            and score.get('model_key') == model and score.get('task_id') == task
            and done.get('successor_job_id') == lock.get('successor_job_id') == JOBS[model]
            and score.get('delivery', {}).get('successor_job_id') == JOBS[model]
            and score.get('continuation_plan_sha256') == 'd69ab37a69628972db2bef817d5f4762c3907cb546b8b2d9366d66206f53303a'
            and score.get('plan_sha256') == 'ee450e89141e2390f3a93f5ed2e85bd9e3ef81778ddde0301a9c3478ed909cec',
            'Exact complete original native denominator and score required')
    lock_sha, score_sha = sha(folder / 'prediction_lock.json'), sha(folder / 'scores.json')
    require(done.get('prediction_lock_sha256') == score.get('prediction_lock_sha256') == lock_sha
            and scored.get('scoring_terminal') is True and scored.get('scores_sha256') == score_sha
            and (folder / 'scoring_attempt.json').is_file()
            and re.fullmatch('[0-9a-f]{64}', scored.get('per_case_scores_sha256', '')) is not None,
            'Sole native scoring attempt/completion and exact score/seal required')
    # Per-case target-bearing scores and source reference rows are never opened.
    return {'planned': planned, 'score_sha256': score_sha, 'prediction_lock_sha256': lock_sha,
            'metrics': score['metrics'], 'delivery': score['delivery'],
            'explicit_ambiguous_invalid_slots': score['explicit_ambiguous_invalid_slots'],
            'scoring_completion_sha256': sha(folder / 'scoring_completion.json')}, lock


def sealed_member_allowed(path, original_task, new_task, model_info):
    path = Path(path)
    if path in (Path(model_info['boundary_path']), Path(model_info['closure_path']), new_task / 'outcome_ledger.json'):
        return True
    for folder, names in ((original_task / 'cases', {'request.json', 'response.json'}),
                          (new_task / 'cases', {'claim.json', 'request.json', 'response.json'})):
        if path.is_relative_to(folder):
            relative = path.relative_to(folder)
            return len(relative.parts) == 2 and re.fullmatch('[0-9]{6}', relative.parts[0]) is not None \
                and int(relative.parts[0]) < PLANNED[new_task.name] and relative.parts[1] in names
    return False


def inventory(controls, plan, accounts):
    science = controls.read(plan['scientific_plan']['path'])
    sealed, results, lock_proofs = {}, {}, []
    with ExitStack() as stack:
        for model in JOBS:
            run = RUNTIME / model
            for path in [run / 'worker.lock', run / 'driver.lock'] + [run / task / 'ledger_scoring.lock' for task in PLANNED]:
                lock_proofs.append(stack.enter_context(free_owned_lock(path)))
        for model, job in JOBS.items():
            run = RUNTIME / model
            terminal, completed = read(run / 'worker_terminal.json'), read(run / 'model_completed.json')
            require(accounts[model]['terminal'] is True and terminal.get('completed') is True
                    and terminal.get('job_id') == completed.get('job_id') == job
                    and completed.get('model_key') == model and completed.get('full_native_denominator') == 4772
                    and completed.get('all_original_and_successor_tasks_scored') is True
                    and completed.get('operational_plan_sha256') == 'd69ab37a69628972db2bef817d5f4762c3907cb546b8b2d9366d66206f53303a'
                    and completed.get('scientific_plan_sha256') == 'ee450e89141e2390f3a93f5ed2e85bd9e3ef81778ddde0301a9c3478ed909cec'
                    and terminal.get('model_completion_sha256') == sha(run / 'model_completed.json'),
                    'Exact actual completed worker/native model receipt required')
            results[model] = {'job_id': job, 'worker_terminal_sha256': sha(run / 'worker_terminal.json'), 'tasks': {}}
            for task in PLANNED:
                folder = run / task
                result, lock = task_metadata(folder, model, task)
                condition = next(row for row in science['conditions'] if row['model_key'] == model and row['task_id'] == task)
                for path, expected in lock['files_sha256'].items():
                    require(sealed_member_allowed(path, Path(condition['runtime']), folder, plan['models'][model]),
                            'Foreign or reference file in native seal')
                    require(sha(path) == expected, 'Native sealed raw member changed')
                    sealed[path] = expected
                results[model]['tasks'][task] = result
        return {'at_utc': now(), 'role': 'private_native_terminal_seal_inventory_not_new_scoring_or_admission',
                'jobs': accounts, 'models': results, 'sealed_files_sha256': sealed, 'free_owned_lock_proofs': lock_proofs,
                'full_native_denominator_per_model': 4772, 'reference_or_per_case_target_rows_opened': False,
                'scoring_calls': 0, 'model_calls': 0, 'GPU_requests': 0, 'published': False}


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--freeze-sha256', required=True)
    parser.add_argument('--review-sha256', required=True); args = parser.parse_args()
    os.environ['CUDA_VISIBLE_DEVICES'] = ''
    freeze, controls, plan = source_check(args.freeze_sha256, args.review_sha256)
    require(os.environ.get('SLURM_JOB_ID', '').isdigit(), 'Exact admitted CPU-only Slurm observer required')
    require(not os.path.lexists(HERE / 'watch_started.json'), 'Observer already attempted; no automatic replay')
    with (HERE / 'watch.lock').open('a') as owned:
        fcntl.flock(owned, fcntl.LOCK_EX | fcntl.LOCK_NB)
        source_check(args.freeze_sha256, args.review_sha256)
        own = own_cpu_job(os.environ['SLURM_JOB_ID'])
        save(HERE / 'watch_started.json', {'at_utc': now(), 'job_id': os.environ['SLURM_JOB_ID'],
             'source_freeze_sha256': args.freeze_sha256, 'source_review_sha256': args.review_sha256,
             'maximum_watch_seconds': MAX_SECONDS, 'GPU_requests': 0, 'one_attempt_only': True,
             'actual_CPU_allocation': own})
        deadline = time.monotonic() + MAX_SECONDS
        while time.monotonic() < deadline:
            require(not os.path.lexists(HERE / 'STOP'), 'Terminal observer STOP requires review')
            controls.check_restore(allow_stop=True)
            accounts = {model: account(model) for model in JOBS}
            if all(value['terminal'] for value in accounts.values()):
                source_check(args.freeze_sha256, args.review_sha256)
                value = inventory(controls, plan, accounts)
                source_check(args.freeze_sha256, args.review_sha256)
                save(HERE / 'native_terminal_inventory.json', value)
                status('native_terminal_seals_verified_requires_independent_native_and_concrete_publication_review',
                       inventory_sha256=sha(HERE / 'native_terminal_inventory.json'))
                return
            status('waiting_exact_native_jobs_without_retry', jobs=accounts)
            time.sleep(60)
        status('finite_watch_deadline_reached_owner_review_required_no_chain')


if __name__ == '__main__':
    try: main()
    except Exception as error:
        status('stopped_for_owner_review_without_retry', error_type=type(error).__name__, error=str(error)[:500])
        raise
