"""One exact independently reviewed zero-GPU terminal observer allocation."""
import argparse
import fcntl
import os
import re
import subprocess
import watch as W


def submit(freeze_sha, review_sha):
    W.source_check(freeze_sha, review_sha)
    with (W.HERE / 'watch_submission.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        W.require(not any(os.path.lexists(W.HERE / name) for name in
            ('watch_submission_attempt.json', 'watch_submission.json', 'watch_started.json')),
            'Existing or ambiguous CPU observer allocation must not be replayed')
        command = ['sbatch', '--parsable', str(W.HERE / 'watch.sbatch'),
                   '--freeze-sha256', freeze_sha, '--review-sha256', review_sha]
        W.source_check(freeze_sha, review_sha)
        W.save(W.HERE / 'watch_submission_attempt.json', {'at_utc': W.now(), 'command': command,
            'source_freeze_sha256': freeze_sha, 'review_sha256': review_sha,
            'GPU_requests': 0, 'one_attempt_only': True, 'no_automatic_retry': True})
        result = subprocess.run(command, capture_output=True, text=True, timeout=60)
        receipt = {'at_utc': W.now(), 'returncode': result.returncode, 'stdout': result.stdout,
                   'stderr': result.stderr, 'GPU_requests': 0, 'automatic_retry': False}
        if result.returncode == 0 and re.fullmatch(r'[0-9]+(?:;[A-Za-z0-9_.-]+)?\s*', result.stdout):
            receipt['job_id'] = result.stdout.strip().split(';')[0]
        W.save(W.HERE / 'watch_submission.json', receipt)
        W.require('job_id' in receipt, 'Failed/uncertain CPU observer allocation; preserve without replay')
        print(receipt['job_id'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--freeze-sha256', required=True)
    parser.add_argument('--review-sha256', required=True); args = parser.parse_args()
    submit(args.freeze_sha256, args.review_sha256)
