from pathlib import Path
import copy
import fcntl
import json
import tempfile
import unittest
from unittest.mock import patch
import watch as W
import submit_once as S


class WatchTests(unittest.TestCase):
    def test_own_observer_actual_zero_GPU_binding(self):
        raw = 'JobId=123 UserId=dongweij(26129) Command='+str(W.HERE/'watch.sbatch')+' WorkDir='+str(W.ROOT)+' JobState=RUNNING Partition=il-cpu QOS=il-cpu-long TimeLimit=3-02:00:00 NumCPUs=1 NumTasks=1 TresPerTask=cpu=1 NumNodes=1 Restarts=0 ReqTRES=cpu=1,mem=2G AllocTRES=cpu=1,mem=2G'
        with patch.object(W.subprocess,'check_output',return_value=raw):
            self.assertEqual(W.own_cpu_job('123')['GPU_requests'],0)
        rounded = raw.replace('NumCPUs=1','NumCPUs=2').replace('AllocTRES=cpu=1','AllocTRES=cpu=2')
        with patch.object(W.subprocess,'check_output',return_value=rounded):
            proof=W.own_cpu_job('123');self.assertEqual(proof['requested_CPUs'],1);self.assertEqual(proof['allocated_CPU_threads'],2)
        for changed in (raw.replace('cpu=1,mem=2G','cpu=1,mem=2G,gres/gpu=1'),
                        raw.replace('Partition=il-cpu','Partition=il'),raw.replace('Restarts=0','Restarts=1'),
                        raw.replace('QOS=il-cpu-long','QOS=il-interactive').replace('TimeLimit=3-02:00:00','TimeLimit=12:00:00'),
                        raw.replace('TimeLimit=3-02:00:00','TimeLimit=01:00:00'),
                        rounded.replace('ReqTRES=cpu=1','ReqTRES=cpu=2'),
                        rounded.replace('NumCPUs=2','NumCPUs=8').replace('AllocTRES=cpu=2','AllocTRES=cpu=8'),
                        rounded.replace('AllocTRES=cpu=2','AllocTRES=cpu=1'),
                        rounded.replace('JobState=RUNNING','JobState=FAILED')):
            with patch.object(W.subprocess,'check_output',return_value=changed):
                with self.assertRaises(ValueError):W.own_cpu_job('123')

    def test_exact_account_success_and_actual_failure(self):
        template = '249732|{state}|{exit}|dongweij|26129|'+W.STARTS['base']+'|end|cpu=8,gres/gpu=1|cpu=8,gres/gpu=1|'+str(W.ROOT)+'\n'
        for state, code, terminal in (('RUNNING', '0:0', False), ('COMPLETED', '0:0', True)):
            with patch.object(W.subprocess, 'check_output', return_value=template.format(state=state, exit=code)):
                self.assertEqual(W.account('base')['terminal'], terminal)
        for state, code in (('FAILED', '1:0'), ('COMPLETED', '1:0'), ('TIMEOUT', '0:0')):
            with self.subTest(state=state), patch.object(W.subprocess, 'check_output', return_value=template.format(state=state, exit=code)):
                with self.assertRaises(ValueError): W.account('base')
        with patch.object(W.subprocess, 'check_output', return_value=template.format(state='COMPLETED', exit='0:0').replace('26129', '123')):
            with self.assertRaises(ValueError): W.account('base')

    def test_terminal_lock_mandatory_regular_and_free(self):
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory).resolve() / 'owned.lock'
            with self.assertRaises(FileNotFoundError):
                with W.free_owned_lock(p): pass
            p.write_text('')
            with W.free_owned_lock(p) as proof: self.assertTrue(proof['existing_regular_owned_lock_acquired_free'])
            with p.open('r') as active:
                fcntl.flock(active, fcntl.LOCK_EX | fcntl.LOCK_NB)
                with self.assertRaises(BlockingIOError):
                    with W.free_owned_lock(p): pass
            alias = p.with_name('alias'); alias.symlink_to(p)
            with self.assertRaises(ValueError):
                with W.free_owned_lock(alias): pass

    def test_seal_paths_exclude_labels_foreign_and_previous_claims(self):
        old, new = Path('/old/P03'), Path('/new/P03')
        info = {'boundary_path': '/boundary.json', 'closure_path': '/closure.json'}
        for path in ('/old/P03/cases/000000/request.json', '/old/P03/cases/002772/response.json',
                     '/new/P03/cases/000000/claim.json', '/new/P03/outcome_ledger.json', '/closure.json'):
            self.assertTrue(W.sealed_member_allowed(path, old, new, info), path)
        for path in ('/old/P03/cases/000000/claim.json', '/old/P03/cases/002773/request.json',
                     '/new/P03/cases/999999/response.json', '/new/P03/per_case_scores.json',
                     '/private/references.jsonl', '/foreign/response.json'):
            self.assertFalse(W.sealed_member_allowed(path, old, new, info), path)

    def test_invented_native_denominator_and_single_score_gate(self):
        done = {'planned':2773, 'terminal':2773, 'all_planned_outcome_slots_sealed':True,
                'all_original_case_denominators_preserved':True, 'successor_job_id':'249732', 'prediction_lock_sha256':'lock'}
        lock = {'planned':2773, 'all_planned_outcome_slots_sealed':True, 'labels_loaded':False, 'successor_job_id':'249732'}
        score = {'planned':2773, 'metrics':{'planned':2773}, 'native_parser_and_metric_unchanged':True,
                 'same_scientific_condition_as_original':True, 'model_key':'base', 'task_id':'P03',
                 'delivery':{'successor_job_id':'249732'}, 'continuation_plan_sha256':'d69ab37a69628972db2bef817d5f4762c3907cb546b8b2d9366d66206f53303a',
                 'plan_sha256':'ee450e89141e2390f3a93f5ed2e85bd9e3ef81778ddde0301a9c3478ed909cec',
                 'prediction_lock_sha256':'lock', 'explicit_ambiguous_invalid_slots':0}
        scored = {'scoring_terminal':True, 'scores_sha256':'score', 'per_case_scores_sha256':'a'*64}
        values = {'completion.json':done, 'prediction_lock.json':lock, 'scores.json':score, 'scoring_completion.json':scored}
        with tempfile.TemporaryDirectory() as directory:
            folder = Path(directory).resolve(); (folder/'scoring_attempt.json').write_text('{}')
            def reader(path): return values[Path(path).name]
            def digest(path): return {'prediction_lock.json':'lock','scores.json':'score'}.get(Path(path).name,'other')
            with patch.object(W, 'read', side_effect=reader), patch.object(W, 'sha', side_effect=digest):
                result, observed = W.task_metadata(folder,'base','P03'); self.assertEqual(result['planned'],2773)
                self.assertIs(observed,lock)
                for row,key,value in ((score,'planned',2772),(lock,'labels_loaded',True),(done,'successor_job_id','foreign'),(scored,'scoring_terminal',False)):
                    oldvalue=row[key];row[key]=value
                    with self.subTest(key=key), self.assertRaises(ValueError): W.task_metadata(folder,'base','P03')
                    row[key]=oldvalue
                (folder/'scoring_attempt.json').unlink()
                with self.assertRaises(ValueError): W.task_metadata(folder,'base','P03')

    def test_uncertain_CPU_submission_is_consumed(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory).resolve()
            with patch.object(W,'HERE',root), patch.object(W,'source_check'), \
                    patch.object(S.subprocess,'run',side_effect=TimeoutError('invented uncertain scheduler')) as called:
                with self.assertRaises(TimeoutError): S.submit('f','r')
                self.assertTrue((root/'watch_submission_attempt.json').is_file())
                with self.assertRaises(ValueError): S.submit('f','r')
                self.assertEqual(called.call_count,1)

    def test_late_stop_prevents_CPU_intent(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory).resolve()
            with patch.object(W,'HERE',root), patch.object(W,'source_check',side_effect=[None,ValueError('late STOP')]), \
                    patch.object(S.subprocess,'run') as scheduler:
                with self.assertRaisesRegex(ValueError,'late STOP'): S.submit('f','r')
                self.assertFalse((root/'watch_submission_attempt.json').exists());scheduler.assert_not_called()


if __name__ == '__main__': unittest.main()
