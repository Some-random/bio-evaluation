import copy
import json
import os
from types import SimpleNamespace
from contextlib import contextmanager
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch

import restore_controls as R


class RestoreTests(unittest.TestCase):
    def test_original_controller_dependency_import(self):
        module = R.module(R.ORIGINAL / 'controller.py', 'restoration_test_original_controller')
        self.assertTrue(callable(module.drain_record))
        self.assertTrue(callable(module.predecessor_terminal_allowed))

    def test_exact_root_and_independent_binding(self):
        auth = {'approved': True, 'issuer': '/root',
                'role': 'explicit_user_authorized_restoration_of_reviewed_local_GPU_evaluations',
                'project_GPU_ceiling': 8,
                'restore_already_reviewed_local_lanes': ['classification_Base_Post_same16K_untouched_continuations']}
        admission = {'approved': True, 'issuer': '/root/independent_review',
                     'role': 'classification_short_IPC_zero_case_replacement_operational_admission',
                     'manifest_sha256': 'm', 'original_operational_plan_sha256': 'p'}
        R.validate_authority(auth, 'p', 'm', admission)
        for key, value in [('approved', False), ('issuer', '/other'), ('project_GPU_ceiling', 9),
                           ('restore_already_reviewed_local_lanes', [])]:
            changed = copy.deepcopy(auth); changed[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                R.validate_authority(changed, 'p', 'm', admission)
        for key in ('approved', 'issuer', 'manifest_sha256', 'original_operational_plan_sha256'):
            changed = copy.deepcopy(admission); changed[key] = 'changed'
            with self.subTest(admission=key), self.assertRaises(ValueError):
                R.validate_authority(auth, 'p', 'm', changed)

    def test_capacity_and_own_command(self):
        observed = {'project_requested_GPUs': 7, 'project_requested_GPUs_with_addition': 8,
                    'capacity_available': True}
        R.enforce_capacity(observed, 1)
        for changed in ({**observed, 'project_requested_GPUs': True},
                        {**observed, 'capacity_available': 1},
                        {**observed, 'project_requested_GPUs_with_addition': 7}):
            with self.subTest(changed=changed), self.assertRaises(ValueError):
                R.enforce_capacity(changed, 1)
        own = {'project_requested_GPUs': 8, 'project_requested_GPUs_with_addition': 8,
               'capacity_available': True, 'own_allocation_verified': True,
               'jobs': [{'job_id': 'invented', 'command': str(R.RESTORE / 'successor.sbatch'),
                         'workdir': str(R.ROOT)}]}
        R.enforce_capacity(own, 0, True, 'invented')
        bad = copy.deepcopy(own); bad['jobs'][0]['command'] = '/foreign/successor.sbatch'
        with self.assertRaises(ValueError): R.enforce_capacity(bad, 0, True, 'invented')

    def test_late_hold_prevents_durable_claim(self):
        for name in ('submission_attempt.json', 'worker_started.json', 'driver_process_claim.json',
                     'driver_invocation_claim.json', 'claim.json', 'scoring_attempt.json'):
            with self.subTest(name=name), patch.object(R, 'check_restore', side_effect=ValueError('late STOP')), \
                    patch.object(R, '_original_save') as saved:
                with self.assertRaises(ValueError): R.save(Path('/invented') / name, {})
                saved.assert_not_called()

    def test_portable_sealed_lock_identity(self):
        sealed = [{'path': '/invented/owned.lock', 'dev': 56, 'ino': 7, 'uid': 26129,
                   'mode': 384, 'free_lock_acquired': True},
                  {'path': '/invented/unstarted.lock', 'absent_unstarted_task': True}]
        actual = copy.deepcopy(sealed); actual[0]['dev'] = 81
        self.assertTrue(R.portable_lock_records_match(actual, sealed))
        for key, value in [('path', '/foreign/owned.lock'), ('ino', 8), ('uid', 0),
                           ('mode', 511), ('free_lock_acquired', False)]:
            changed = copy.deepcopy(actual); changed[0][key] = value
            with self.subTest(key=key): self.assertFalse(R.portable_lock_records_match(changed, sealed))
        changed = copy.deepcopy(actual); changed[1]['absent_unstarted_task'] = False
        self.assertFalse(R.portable_lock_records_match(changed, sealed))

    def test_context_normalizes_only_local_device_and_preserves_seal(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder).resolve() / 'owned.lock'; path.touch(mode=0o600)
            st = path.stat()
            record = {'path': str(path), 'dev': st.st_dev + 1, 'ino': st.st_ino,
                      'uid': st.st_uid, 'mode': stat.S_IMODE(st.st_mode), 'free_lock_acquired': True}
            closure = {'original_output_locks': [record]}
            seen = []
            @contextmanager
            def held(plan, science, boundary, adjusted, key):
                seen.append(adjusted)
                self.assertEqual(adjusted['original_output_locks'][0]['dev'], st.st_dev)
                yield {'original_output_locks': adjusted['original_output_locks'], 'terminal_scheduler': {'terminal': True}}
            with patch.object(R, 'check_restore'), patch.object(R, '_original_terminal_locks', held):
                with R.terminal_original_locks({}, {}, {}, closure, 'base') as proof:
                    self.assertTrue(proof['sealed_lock_devices_are_namespace_local'])
            self.assertEqual(closure['original_output_locks'][0]['dev'], st.st_dev + 1)
            self.assertEqual({k:v for k,v in record.items() if k != 'dev'},
                             {k:v for k,v in seen[0]['original_output_locks'][0].items() if k != 'dev'})

    def test_only_administrative_source_delta(self):
        for name in ('successor_submit.py', 'successor_worker.py', 'successor_driver.py'):
            original = (R.ORIGINAL / name).read_text()
            candidate = (R.RESTORE / name).read_text()
            candidate = candidate.replace('    C.ipc_path_preflight()\n', '')
            candidate = candidate.replace("        C.require(os.environ['SLURM_JOB_ID'].isdigit() and len(os.environ['SLURM_JOB_ID']) <= 20, 'Bounded numeric Slurm job ID required')\n", '')
            candidate = candidate.replace("tempfile.mkdtemp(prefix='bc-' + os.environ['SLURM_JOB_ID'] + '-', dir='/tmp')", "tempfile.mkdtemp(prefix='bio-classification-continuation-' + os.environ['SLURM_JOB_ID'] + '-')")
            candidate = candidate.replace('        C.ipc_path_preflight(local)\n', '')
            candidate = candidate.replace('        IPC = C.ipc_path_preflight(local, env, bind=True)\n', '')
            candidate = candidate.replace(",\n            'private_IPC_preflight': IPC})", '})')
            candidate = candidate.replace("    IPC_local = Path(C.read(runtime / 'runtime_extraction.json')['local'])\n", '')
            candidate = candidate.replace('    C.ipc_path_preflight(IPC_local, os.environ, bind=True)\n', '')
            candidate = candidate.replace("        C.save(runtime / 'private_IPC_preflight_driver.json', C.ipc_path_preflight(IPC_local, os.environ, bind=True))\n", '')
            candidate = candidate.replace('import restore_controls as C', 'import continuation_controls as C')
            candidate = candidate.replace('    C.check_restore(full=True)\n', '')
            candidate = candidate.replace("if __name__ == '__main__':\n    raise SystemExit(submit(arguments()))", "if __name__ == '__main__': raise SystemExit(submit(arguments()))")
            candidate = candidate.replace("if __name__ == '__main__':\n    main()", "if __name__ == '__main__': main()")
            if name == 'successor_submit.py':
                candidate = candidate.replace("str(Path(__file__).resolve().parent / 'successor.sbatch')", "str(C.HERE / 'successor.sbatch')")
                candidate = candidate.replace('            C.check_restore()\n', '')
            if name == 'successor_worker.py':
                candidate = candidate.replace("str(Path(__file__).resolve().parent / 'successor_driver.py')", "str(C.HERE / 'successor_driver.py')")
            if name == 'successor_driver.py':
                candidate = candidate.replace('                C.check_restore()\n', '')
                candidate = candidate.replace("        C.save(runtime / 'private_gpu_audit_driver.json', C.audit(plan, own=True))\n", '')
            self.assertEqual(original, candidate, name)

    def test_only_replacement_runtime_changes_after_original_validation(self):
        original = {'models': {key: {'successor_runtime': '/failed/' + key,
                                     'original_runtime': '/original/' + key} for key in ('base', 'posttrained')},
                    'generation': {'seed': 42}, 'task_order': ['P03', 'P01']}
        prior = copy.deepcopy(original)
        with patch.object(R, 'check_restore'), patch.object(R, '_original_validate', return_value=(original, 's', 'b', 'c')):
            plan, science, boundary, closure = R.validate('unchanged-original-arguments')
        self.assertEqual(original, prior)
        self.assertEqual((science, boundary, closure), ('s', 'b', 'c'))
        for key in ('base', 'posttrained'):
            self.assertEqual(plan['models'][key]['successor_runtime'], str(R.RESTORE / 'runtime' / key))
            plan['models'][key]['successor_runtime'] = prior['models'][key]['successor_runtime']
        self.assertEqual(plan, prior)

    def test_portable_drain_preserves_receipt_and_restriction_guards(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve(); folder = root / 'drains/base'; folder.mkdir(parents=True)
            target = root / 'original'; target.mkdir(); target.chmod(0o500)
            observed = target.stat()
            value = {'applied': True, 'model_key': 'base', 'predecessor_job_id': 'invented',
                     'restrictions': [{'path': str(target), 'dev': observed.st_dev + 999,
                                      'ino': observed.st_ino, 'uid': observed.st_uid, 'drain_mode': 0o500}]}
            applied = folder / 'applied.json'; applied.write_text(json.dumps(value))
            controller = SimpleNamespace(S=SimpleNamespace(EXPECTED={'base': {'job_id': 'invented'}}))
            with patch.object(R, 'ORIGINAL', root):
                actual, digest = R.portable_drain_record(controller, 'base')
                self.assertEqual(actual, value); self.assertEqual(digest, R.sha(applied))
                for key, changed in (('ino', observed.st_ino + 1), ('uid', observed.st_uid + 1),
                                     ('drain_mode', 0o400), ('path', str(root / 'other'))):
                    altered = copy.deepcopy(value); altered['restrictions'][0][key] = changed
                    applied.write_text(json.dumps(altered))
                    with self.subTest(key=key), self.assertRaises((ValueError, FileNotFoundError)):
                        R.portable_drain_record(controller, 'base')
                applied.write_text(json.dumps(value)); target.chmod(0o700)
                with self.assertRaises(ValueError): R.portable_drain_record(controller, 'base')
                target.chmod(0o500)
                alias = root / 'alias'; alias.symlink_to(target, target_is_directory=True)
                altered = copy.deepcopy(value); altered['restrictions'][0]['path'] = str(alias)
                applied.write_text(json.dumps(altered))
                with self.assertRaises(ValueError): R.portable_drain_record(controller, 'base')
                applied.unlink(); (folder / 'intent.json').write_text('{}')
                with self.assertRaises(ValueError): R.portable_drain_record(controller, 'base')
                (folder / 'intent.json').unlink()
                self.assertEqual(R.portable_drain_record(controller, 'base'), (None, None))

    def test_drain_fd_replacement_race_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve(); folder = root / 'drains/base'; folder.mkdir(parents=True)
            target = root / 'original'; target.mkdir(); target.chmod(0o500); observed = target.stat()
            value = {'applied': True, 'model_key': 'base', 'predecessor_job_id': 'invented',
                     'restrictions': [{'path': str(target), 'dev': observed.st_dev,
                                      'ino': observed.st_ino, 'uid': observed.st_uid, 'drain_mode': 0o500}]}
            (folder / 'applied.json').write_text(json.dumps(value))
            controller = SimpleNamespace(S=SimpleNamespace(EXPECTED={'base': {'job_id': 'invented'}}))
            real_fstat = os.fstat
            def changed(fd):
                actual = real_fstat(fd)
                if stat.S_ISDIR(actual.st_mode):
                    return SimpleNamespace(st_dev=actual.st_dev, st_ino=actual.st_ino + 1,
                        st_uid=actual.st_uid, st_mode=actual.st_mode, st_ctime_ns=actual.st_ctime_ns)
                return actual
            with patch.object(R, 'ORIGINAL', root), patch.object(R.os, 'fstat', side_effect=changed):
                with self.assertRaises(ValueError): R.portable_drain_record(controller, 'base')

    def test_both_actual_resource_boundaries_share_current_binding(self):
        cfg = {'shared_resource': {'path': 'invented_shared'}}
        binding = {'resource_adapter': {'path': 'invented_adapter', 'sha256': 'a'},
                   'additional_root_proofs': [{'path': 'proof', 'sha256': 'p'}],
                   'additional_proof_binding': {'path': 'binding', 'sha256': 'b'}}
        calls = []
        def capacity(**kwargs):
            calls.append(kwargs)
            return {'project_requested_GPUs': 7, 'project_requested_GPUs_with_addition': 7 + kwargs['additional'],
                    'capacity_available': True, 'own_allocation_verified': True,
                    'jobs': [{'job_id': 'invented', 'command': str(R.RESTORE / 'successor.sbatch'), 'workdir': str(R.ROOT)}]}
        with patch.object(R, 'check_restore', return_value=(cfg, 'm')), \
                patch.object(R._C, 'read', return_value=binding), patch.object(R._C, 'sha', return_value='a'), \
                patch.object(R._C, 'module', return_value=SimpleNamespace(capacity_audit=capacity)), \
                patch.dict(os.environ, {'SLURM_JOB_ID': 'invented'}):
            R.audit({}, additional=1); R.audit({}, own=True)
        self.assertEqual([call['additional'] for call in calls], [1, 0])
        self.assertEqual([call['require_own_job'] for call in calls], [False, True])
        for call in calls:
            self.assertEqual(call['additional_root_proofs'], tuple(binding['additional_root_proofs']))
            self.assertEqual(call['additional_proof_binding'], binding['additional_proof_binding'])

    def test_maximum_private_socket_path_actually_binds(self):
        expected = R.ipc_path_preflight()
        self.assertLessEqual(expected['maximum_socket_path_bytes'], 107)
        with tempfile.TemporaryDirectory(prefix='bc-' + '9' * 20 + '-', dir='/tmp') as folder:
            local = Path(folder); temporary = local / 'cache/tmp'; temporary.mkdir(parents=True)
            result = R.ipc_path_preflight(local, {'TMPDIR': str(temporary)}, bind=True)
            self.assertEqual(result['maximum_socket_path_bytes'], result['actual_socket_path_bytes'])
            self.assertTrue(result['actual_socket_bind_verified'])
            self.assertFalse((temporary / ('f' * 36)).exists())
            with self.assertRaises(ValueError): R.ipc_path_preflight(local, {'TMPDIR': '/foreign/tmp'}, bind=True)
            with self.assertRaises(ValueError): R.ipc_path_preflight(local, {'TMPDIR': str(temporary), 'VLLM_RPC_BASE_PATH': '/foreign'})

    def test_legacy_long_runtime_root_rejected(self):
        with tempfile.TemporaryDirectory(prefix='bio-classification-continuation-249670-', dir='/tmp') as folder:
            with self.assertRaises(ValueError): R.ipc_path_preflight(Path(folder))

    def test_actual_submission_and_worker_reject_bad_IPC_before_claim(self):
        import successor_submit as submission
        import successor_worker as worker
        import successor_driver as driver
        with patch.object(R, 'ipc_path_preflight', side_effect=ValueError('invented unsafe IPC')), \
                patch.object(submission, 'validate_args') as validated, patch.object(R, 'save') as saved, \
                patch.object(submission.subprocess, 'run', side_effect=AssertionError('No scheduler/model subprocess')):
            with self.assertRaisesRegex(ValueError, 'unsafe IPC'): submission.submit(None)
            validated.assert_not_called(); saved.assert_not_called()
        with tempfile.TemporaryDirectory() as folder:
            args = SimpleNamespace(model_key='base')
            plan = {'models': {'base': {'successor_runtime': folder}}}
            with patch.object(worker, 'arguments', return_value=args), \
                    patch.object(worker, 'validate_args', return_value=(plan, {}, {}, {})), \
                    patch.dict(os.environ, {'SLURM_JOB_ID': '123'}), \
                    patch.object(R, 'ipc_path_preflight', side_effect=ValueError('invented unsafe IPC')), \
                    patch.object(R, 'save') as saved:
                with self.assertRaisesRegex(ValueError, 'unsafe IPC'): worker.main()
                saved.assert_not_called()
            with patch.object(driver, 'arguments', return_value=args), \
                    patch.object(driver, 'validate_args', return_value=(plan, {}, {}, {})), \
                    patch.dict(os.environ, {'SLURM_JOB_ID': '123'}), \
                    patch.object(R._C, 'read', return_value={'local': '/invented'}), \
                    patch.object(R, 'ipc_path_preflight', side_effect=ValueError('invented unsafe IPC')), \
                    patch.object(R, 'save') as saved:
                with self.assertRaisesRegex(ValueError, 'unsafe IPC'): driver.main()
                saved.assert_not_called()


if __name__ == '__main__': unittest.main()
