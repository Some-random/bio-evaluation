"""Exact current authorization and resource overlay; frozen science stays original."""
from pathlib import Path
from contextlib import contextmanager
import copy
import hashlib
import importlib
import json
import os
import re
import socket
import stat
import sys

RESTORE = Path(__file__).resolve().parent
ROOT = RESTORE.parents[2]
ORIGINAL = ROOT / '.local/qwen35_4b_comparison_20261022/protein_classification_recommended_sampling_v2/same_condition_continuation_v1'
if str(ORIGINAL) not in sys.path:
    sys.path.append(str(ORIGINAL))
_C = importlib.import_module('continuation_controls')
_original_priority = _C.priority
_original_save = _C.save
_original_terminal_locks = _C.terminal_original_locks
_original_validate = _C.validate
_original_module = _C.module


def validate_authority(auth, expected_plan, manifest, admission):
    _C.require(auth.get('approved') is True and auth.get('issuer') == '/root'
               and auth.get('role') == 'explicit_user_authorized_restoration_of_reviewed_local_GPU_evaluations'
               and auth.get('project_GPU_ceiling') == 8
               and 'classification_Base_Post_same16K_untouched_continuations' in auth.get('restore_already_reviewed_local_lanes', []),
               'Current exact root restoration authority required')
    _C.require(admission.get('approved') is True and admission.get('issuer') == '/root/independent_review'
               and admission.get('role') == 'classification_short_IPC_zero_case_replacement_operational_admission'
               and admission.get('manifest_sha256') == manifest
               and admission.get('original_operational_plan_sha256') == expected_plan,
               'Exact independent current operational restoration admission required')


def check_restore(full=False, allow_stop=False):
    manifest_path = RESTORE / 'manifest.json'
    manifest = _C.read(manifest_path)
    manifest_sha = _C.sha(manifest_path)
    cfg_path = RESTORE / 'config.json'
    _C.require(_C.sha(cfg_path) == manifest['files_sha256'][str(cfg_path)], 'Restoration configuration changed')
    cfg = _C.read(cfg_path)
    for s in (RESTORE / 'STOP', RESTORE.parent / 'STOP'):
        _C.require(allow_stop or (not s.exists() and not s.is_symlink()), 'Current restoration STOP requires waiting')
    auth_ref = cfg['root_authorization']
    _C.require(_C.sha(auth_ref['path']) == auth_ref['sha256'], 'Current root restoration authority changed')
    auth = _C.read(auth_ref['path'])
    admission = _C.read(RESTORE / 'engineering_admission.json')
    validate_authority(auth, cfg['original_operational_plan_sha256'], manifest_sha, admission)
    _C.require(admission.get('root_authorization_sha256') == auth_ref['sha256'], 'Peer admission binds another root authority')
    replacement_ref = cfg['zero_call_replacement_authorization']
    failure_ref = cfg['independent_zero_call_failure_review']
    _C.require(_C.sha(replacement_ref['path']) == replacement_ref['sha256']
               and _C.sha(failure_ref['path']) == failure_ref['sha256'], 'Exact zero-call replacement authority changed')
    replacement, failure = _C.read(replacement_ref['path']), _C.read(failure_ref['path'])
    _C.require(replacement.get('approved') is True and replacement.get('issuer') == '/root'
               and replacement.get('owner') == cfg['owner']
               and replacement.get('role') == 'conditional_zero_case_classification_short_IPC_path_operational_replacement_authorization'
               and replacement.get('max_additional_replacement_allocations_per_model') == 1
               and replacement.get('resource_limit_project_gpus') == 8
               and replacement.get('must_not_reuse_consumed_prior_submission_or_driver_claims') is True
               and replacement.get('new_runtime_and_claim_namespace_required') is True
               and replacement.get('attempted_or_ambiguous_case_retries_authorized') is False
               and replacement.get('scientific_condition_changes_authorized') is False
               and replacement.get('original_operational_plan_sha256') == cfg['original_operational_plan_sha256']
               and failure.get('approved_zero_call_boundary') is True
               and failure.get('reviewer') == '/root/independent_review'
               and failure.get('root_replacement_authorization_sha256') == replacement_ref['sha256'],
               'Bounded independently verified zero-call replacement required')
    _C.require(admission.get('replacement_authorization_sha256') == replacement_ref['sha256']
               and admission.get('zero_call_review_sha256') == failure_ref['sha256']
               and admission.get('replacement_runtime_root') == str(RESTORE / 'runtime')
               and admission.get('maximum_additional_allocations_per_model') == 1,
               'Independent admission binds another replacement scope')
    # Failed allocation claims are historical and stay consumed. Check their
    # exact bytes and the independently proved pre-model absence boundary.
    for path, digest in cfg['failed_v3_pins'].items():
        _C.require(_C.sha(path) == digest, 'Failed v3 claim or zero-call evidence changed: ' + path)
    for path in cfg['failed_v3_absent']:
        p = Path(path)
        _C.require(not p.exists() and not p.is_symlink(), 'Failed v3 runtime crossed its zero-call boundary')
    for path, digest in cfg['failed_v4_pins'].items():
        _C.require(_C.sha(path) == digest, 'Failed v4 claim or zero-case evidence changed: ' + path)
    for path in cfg['failed_v4_absent']:
        p = Path(path)
        _C.require(not p.exists() and not p.is_symlink(), 'Failed v4 runtime crossed its zero-case boundary')
    resource = cfg['shared_resource']
    _C.require(_C.sha(resource['path']) == resource['sha256'], 'Current shared resource configuration changed')
    if full:
        for path, digest in manifest['files_sha256'].items():
            _C.require(_C.sha(path) == digest, 'Pinned restoration source changed: ' + path)
        for path, digest in cfg['original_pins'].items():
            _C.require(_C.sha(path) == digest, 'Original operational source/boundary changed: ' + path)
        for path, digest in cfg['preserved_source_pins'].items():
            _C.require(_C.sha(path) == digest, 'Preserved failed operational source changed: ' + path)
    return cfg, manifest_sha


def ipc_path_preflight(local=None, env=None, bind=False):
    # CPython mkdtemp uses eight random ASCII characters. Reserve a 20-digit
    # Slurm job ID and the actual 36-byte vLLM UUID socket basename.
    _C.require(Path('/tmp') == Path('/tmp').resolve() and Path('/tmp').is_dir(), 'Canonical short /tmp root required')
    longest = Path('/tmp') / ('bc-' + '9' * 20 + '-' + 'x' * 8) / 'cache/tmp' / ('f' * 36)
    maximum = len(os.fsencode(longest))
    _C.require(maximum <= 107, 'Deterministic maximum private IPC socket path exceeds kernel limit')
    result = {'maximum_socket_path_bytes': maximum, 'socket_path_limit_bytes': 107,
              'short_private_root': '/tmp', 'actual_socket_bind_verified': False}
    if local is None:
        _C.require(env is None and not bind, 'Actual IPC environment requires a private runtime root')
        return result
    local = Path(local)
    _C.require(local.is_absolute() and local == local.resolve() and local.parent == Path('/tmp')
               and re.fullmatch(r'bc-[0-9]{1,20}-[a-z0-9_]{8}', local.name) is not None,
               'Exact short private runtime directory required')
    observed = local.lstat()
    _C.require(stat.S_ISDIR(observed.st_mode) and observed.st_uid == os.getuid()
               and stat.S_IMODE(observed.st_mode) == 0o700, 'Private runtime owner/mode changed')
    temporary = local / 'cache/tmp'
    if env is not None:
        _C.require(env.get('TMPDIR') == str(temporary)
                   and env.get('VLLM_RPC_BASE_PATH', str(temporary)) == str(temporary),
                   'Actual IPC environment differs from exact short private cache')
    actual = temporary / ('f' * 36)
    _C.require(len(os.fsencode(actual)) <= maximum, 'Actual private socket path exceeds tested maximum')
    result['actual_socket_path_bytes'] = len(os.fsencode(actual))
    if bind:
        _C.require(temporary == temporary.resolve() and temporary.is_dir(), 'Actual private IPC cache changed')
        bound = False
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as probe:
                probe.bind(str(actual)); bound = True
                _C.require(stat.S_ISSOCK(actual.lstat().st_mode), 'Actual IPC probe is not a socket')
                result['actual_socket_bind_verified'] = True
        finally:
            if bound:
                _C.require(stat.S_ISSOCK(actual.lstat().st_mode) and actual.lstat().st_uid == os.getuid(),
                           'Owned IPC probe changed before cleanup')
                actual.unlink()
    return result


def validate(*args, **kwargs):
    check_restore()
    plan, science, boundary, closure = _original_validate(*args, **kwargs)
    adjusted = copy.deepcopy(plan)
    for model in ('base', 'posttrained'):
        adjusted['models'][model]['successor_runtime'] = str(RESTORE / 'runtime' / model)
    return adjusted, science, boundary, closure


def portable_drain_record(controller, model):
    folder = ORIGINAL / 'drains' / model
    applied = folder / 'applied.json'
    if applied.exists():
        value = _C.read(applied)
        digest = _C.sha(applied)
        _C.require(value.get('applied') is True and value.get('model_key') == model
                   and value.get('predecessor_job_id') == controller.S.EXPECTED[model]['job_id'],
                   'Drain receipt identity mismatch')
        for row in value['restrictions']:
            path = Path(row['path'])
            _C.require(path.is_absolute() and path == path.resolve() and not path.is_symlink(),
                       'Original request restriction path changed')
            before = path.lstat()
            _C.require(stat.S_ISDIR(before.st_mode)
                       and (before.st_ino, before.st_uid) == (row['ino'], row['uid'])
                       and before.st_mode & 0o777 == row['drain_mode'] and not before.st_mode & 0o222,
                       'Original request creation restriction changed')
            descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_NONBLOCK)
            try:
                opened = os.fstat(descriptor)
                identity = lambda s: (s.st_dev, s.st_ino, s.st_uid, s.st_mode, s.st_ctime_ns)
                _C.require(identity(before) == identity(opened) == identity(path.lstat()),
                           'Original restriction changed while opening actual directory')
            finally:
                os.close(descriptor)
        _C.require(_C.sha(applied) == digest and _C.read(applied) == value,
                   'Original drain receipt changed while checking restrictions')
        return value, digest
    if (folder / 'intent.json').exists():
        raise ValueError('Incomplete or ambiguous drain intent; no automatic mutation replay')
    return None, None


def module(path, name):
    loaded = _original_module(path, name)
    if Path(path) == ORIGINAL / 'controller.py':
        loaded.drain_record = lambda model: portable_drain_record(loaded, model)
    return loaded


def enforce_capacity(observed, additional, own=False, own_id=None):
    count = observed.get('project_requested_GPUs')
    _C.require(type(count) is int and count >= 0 and type(additional) is int and additional in (0, 1)
               and type(observed.get('capacity_available')) is bool
               and observed.get('project_requested_GPUs_with_addition') == count + additional
               and observed['capacity_available'] == (count + additional <= 8),
               'Malformed or inconsistent conservative project capacity')
    if own:
        _C.require(observed['capacity_available'] and observed.get('own_allocation_verified') is True,
                   'Own actual allocation exceeds current capacity or is unverified')
        row = next(row for row in observed['jobs'] if row['job_id'] == own_id)
        _C.require(row['command'] == str(RESTORE / 'successor.sbatch') and row['workdir'] == str(ROOT),
                   'Actual successor allocation has another command or workspace')
    return observed


def audit(plan, own=False, additional=0):
    cfg, manifest_sha = check_restore()
    resource = _C.read(cfg['shared_resource']['path'])
    adapter = resource['resource_adapter']
    _C.require(_C.sha(adapter['path']) == adapter['sha256'], 'Current pinned resource adapter changed')
    module = _C.module(adapter['path'], 'classification_restored_current_resource')
    observed = module.capacity_audit(additional=additional, override=False, require_own_job=own,
        additional_root_proofs=tuple(resource['additional_root_proofs']),
        additional_proof_binding=resource['additional_proof_binding'])
    enforce_capacity(observed, additional, own, os.environ.get('SLURM_JOB_ID'))
    check_restore()
    observed['operational_restore_manifest_sha256'] = manifest_sha
    return observed


def priority(plan):
    _, manifest_sha = check_restore()
    observed = _original_priority(plan)
    _C.require(observed.get('passed') is True, 'Original positive predecessor/priority proof failed')
    check_restore()
    observed.update(current_restore_authorized=True, operational_restore_manifest_sha256=manifest_sha)
    return observed


def save(path, value):
    if Path(path).name in {'submission_attempt.json', 'worker_started.json', 'driver_process_claim.json',
                           'driver_invocation_claim.json', 'claim.json', 'scoring_attempt.json'}:
        check_restore()
    return _original_save(path, value)


def portable_lock_records_match(actual, sealed):
    def portable(rows):
        return [{key: value for key, value in row.items() if key != 'dev'} for row in rows]
    return portable(actual) == portable(sealed)


@contextmanager
def terminal_original_locks(plan, science, boundary, closure, model_key):
    check_restore()
    # Device numbers belong to a mount namespace. Preserve the sealed record,
    # and compare its exact path/inode/UID/mode/free-lock/absence against fresh
    # actual locks while retaining the original same-namespace FD race checks.
    adjusted = copy.deepcopy(closure)
    for row in adjusted['original_output_locks']:
        if 'dev' in row:
            path = Path(row['path'])
            _C.require(path == path.resolve() and not path.is_symlink(), 'Original lock path changed')
            row['dev'] = path.lstat().st_dev
    with _original_terminal_locks(plan, science, boundary, adjusted, model_key) as proof:
        _C.require(portable_lock_records_match(proof['original_output_locks'], closure['original_output_locks']),
                   'Original lock path/inode/owner/mode/absence identity changed')
        check_restore()
        yield {**proof, 'sealed_lock_devices_are_namespace_local': True}


_C.audit = audit
_C.priority = priority
_C.save = save
_C.terminal_original_locks = terminal_original_locks
_C.validate = validate
_C.module = module


def __getattr__(name):
    return getattr(_C, name)
