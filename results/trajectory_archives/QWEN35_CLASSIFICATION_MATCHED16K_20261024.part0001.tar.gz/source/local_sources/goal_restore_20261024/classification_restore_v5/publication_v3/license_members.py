"""Exact, small license/attribution extension; no runtime/scoring/data calls."""
from pathlib import Path
import re

MEMBERS = {
    'licenses/BioT5/DATASET_CARD.md': ('BioT5_DATASET_CARD.md', '85c2490b5c3a56935a55ec537d57f1aace6443cb2e0ba6c199975c55afc89819'),
    'licenses/ProtST/LICENSE': ('ProtST_LICENSE', 'febde3d68fe7e1ed882276da2b89915c9ed09e90789f9cd834ed2e74bd25042a'),
    'licenses/ProtST/README.md': ('ProtST_README.md', 'efacbdae2a99f57ea8f88536d2aa0fd0cabfd1f0d0b606c7b40938b0917248f3'),
    'licenses/BioT5/STANDARD_MIT_LICENSE_REFERENCE.txt': ('STANDARD_MIT_LICENSE_REFERENCE.txt', 'b05785f9f18e6716bab63424b11454513b9943a222595b70411009202fc592b5'),
    'licenses/SOURCE_ATTRIBUTION.json': ('SOURCE_ATTRIBUTION.json', None),
}
SCIENCE = 'ee450e89141e2390f3a93f5ed2e85bd9e3ef81778ddde0301a9c3478ed909cec'
NATIVE = '19e7da206bea3305f0ef25d72dabe656debf823f42ebc8a844ac880f94f03d30'

def require(value, message):
    if not value: raise ValueError(message)

def validate(freeze, read, sha, here, *, review=None):
    here = Path(here)
    record = freeze.get('license_contract', {})
    path = here / 'license_contract.json'
    require(record.get('path') == str(path) and sha(path) == record.get('sha256'), 'Exact frozen license contract required')
    contract = read(path)
    require(contract.get('role') == 'classification_exact_license_attribution_contract_v1'
            and contract.get('scientific_plan_sha256') == SCIENCE
            and contract.get('native_terminal_review_sha256') == NATIVE
            and contract.get('scientific_or_output_changes') is False,
            'Exact unchanged classification license scope required')
    members = contract.get('members', {})
    require(set(members) == set(MEMBERS), 'Only the five exact license/attribution members are allowed')
    for name, (filename, official_sha) in MEMBERS.items():
        row = members[name]
        expected_path = here / 'license_sources' / filename
        require(set(row) == {'path', 'sha256'} and row.get('path') == str(expected_path)
                and re.fullmatch('[0-9a-f]{64}', row.get('sha256', '')) is not None,
                'Exact regular license source path/digest required')
        require(official_sha is None or row['sha256'] == official_sha, 'Official pinned license metadata bytes changed')
        require(sha(expected_path) == row['sha256'], 'License/attribution source changed')
    attribution = read(here / 'license_sources/SOURCE_ATTRIBUTION.json')
    require(attribution.get('role') == 'classification_dataset_and_ontology_source_attribution'
            and attribution.get('scientific_plan_sha256') == SCIENCE
            and attribution.get('native_terminal_review_sha256') == NATIVE
            and attribution.get('task_ids') == ['P01', 'P03']
            and attribution.get('code_license_is_not_independent_original_dataset_rights_proof') is True
            and attribution.get('concrete_restriction_identified') is False,
            'Exact scoped source attribution and honest license qualification required')
    if review is not None:
        require(review.get('license_and_attribution_contract_verified') is True
                and review.get('license_contract_sha256') == record['sha256'],
                'Independent exact license/attribution source acceptance required')
    return contract

def add_originals(freeze, originals, read, sha, here, add_original):
    contract = validate(freeze, read, sha, here)
    require(not (set(originals) & set(MEMBERS)), 'License member must not overwrite an original')
    for name, row in contract['members'].items():
        add_original(originals, name, Path(row['path']), row['sha256'])
