"""Invented license bytes only. No project payloads, calls or source acquisition."""
from pathlib import Path
from unittest import mock
import hashlib, importlib.util, json, tempfile, unittest
S=importlib.util.spec_from_file_location('invented_license_assemble',Path(__file__).with_name('assemble.py'))
A=importlib.util.module_from_spec(S);S.loader.exec_module(A)
L=A.license_members

class LicenseTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.here=Path(self.tmp.name);(self.here/'license_sources').mkdir()
  self.members={}
  for name,(filename,_) in L.MEMBERS.items():
   p=self.here/'license_sources'/filename;p.write_bytes(('invented license '+name).encode());self.members[name]=(filename,None if name=='licenses/SOURCE_ATTRIBUTION.json' else A.sha(p))
  self.attribution={'role':'classification_dataset_and_ontology_source_attribution','scientific_plan_sha256':L.SCIENCE,'native_terminal_review_sha256':L.NATIVE,'task_ids':['P01','P03'],'code_license_is_not_independent_original_dataset_rights_proof':True,'concrete_restriction_identified':False}
  self.c={'role':'classification_exact_license_attribution_contract_v1','scientific_plan_sha256':L.SCIENCE,'native_terminal_review_sha256':L.NATIVE,'scientific_or_output_changes':False,'members':{n:{'path':str(self.here/'license_sources'/f),'sha256':h} for n,(f,h) in self.members.items()}}
  self.contract_path=self.here/'license_contract.json';self.freeze={};self.bind()
  self.patch=mock.patch.object(L,'MEMBERS',self.members);self.patch.start();self.addCleanup(self.patch.stop)
 def bind(self):
  p=self.here/'license_sources/SOURCE_ATTRIBUTION.json';p.write_text(json.dumps(self.attribution));self.c['members']['licenses/SOURCE_ATTRIBUTION.json']['sha256']=A.sha(p)
  self.contract_path.write_text(json.dumps(self.c));self.freeze={'license_contract':{'path':str(self.contract_path),'sha256':A.sha(self.contract_path)}}
 def call(self,review=None):return L.validate(self.freeze,A.read,A.sha,self.here,review=review)
 def test_exact_members_preserve_old_originals_and_bound_bytes(self):
  original={'old/member':{'bytes':1,'sha256':'a'*64,'path':'/invented'}}
  L.add_originals(self.freeze,original,A.read,A.sha,self.here,A.add_original)
  self.assertEqual(set(original),{'old/member'}|set(self.members));self.assertEqual(original['old/member']['sha256'],'a'*64)
  for name in self.members:self.assertEqual(original[name]['sha256'],self.c['members'][name]['sha256'])
 def test_missing_or_foreign_member_cannot_be_rebound(self):
  for foreign in (False,True):
   before=dict(self.c['members'])
   if foreign:self.c['members']['licenses/foreign']={'path':'/invented','sha256':'a'*64}
   else:self.c['members'].pop('licenses/ProtST/LICENSE')
   self.bind()
   with self.assertRaisesRegex(ValueError,'five exact'):self.call()
   self.c['members']=before
 def test_changed_official_metadata_rejected_after_contract_rebind(self):
  name='licenses/ProtST/LICENSE';p=Path(self.c['members'][name]['path']);p.write_bytes(b'drift');self.c['members'][name]['sha256']=A.sha(p);self.bind()
  with self.assertRaisesRegex(ValueError,'Official pinned'):self.call()
 def test_symlink_and_path_escape_rejected(self):
  name='licenses/ProtST/LICENSE';p=Path(self.c['members'][name]['path']);target=self.here/'target';target.write_bytes(p.read_bytes());p.unlink();p.symlink_to(target)
  with self.assertRaises(OSError):self.call()
  p.unlink();p.write_bytes(target.read_bytes());self.c['members'][name]['path']=str(target);self.bind()
  with self.assertRaisesRegex(ValueError,'Exact regular license source'):self.call()
 def test_wrong_native_or_false_scope_attribution_rejected_after_rebind(self):
  for key,value in [('native_terminal_review_sha256','0'*64),('code_license_is_not_independent_original_dataset_rights_proof',False),('concrete_restriction_identified',True)]:
   old=self.attribution[key];self.attribution[key]=value;self.bind()
   with self.subTest(key=key),self.assertRaisesRegex(ValueError,'honest license'):self.call()
   self.attribution[key]=old
 def test_independent_exact_license_review_required(self):
  good={'license_and_attribution_contract_verified':True,'license_contract_sha256':self.freeze['license_contract']['sha256']}
  self.call(good)
  for bad in ({},{**good,'license_and_attribution_contract_verified':False},{**good,'license_contract_sha256':'0'*64}):
   with self.assertRaisesRegex(ValueError,'Independent exact license'):self.call(bad)
 def test_contract_and_member_drift_detected_before_capture(self):
  self.contract_path.write_bytes(b'{}')
  with self.assertRaisesRegex(ValueError,'Exact frozen license'):self.call()
 def test_cannot_overwrite_existing_archive_member(self):
  originals={next(iter(self.members)):{}}
  with self.assertRaisesRegex(ValueError,'overwrite'):L.add_originals(self.freeze,originals,A.read,A.sha,self.here,A.add_original)
 def test_new_executable_pin_is_mandatory_before_other_authority(self):
  freeze={'role':'classification_terminal_only_publication_source_freeze','runtime_manifest_sha256':A.RUNTIME_SHA,'jobs':A.JOBS,'planned_per_task':A.PLANNED,'model_calls':0,'scoring_calls':0,'GPU_requests':0,'files_sha256':{str(self.here/n):'a'*64 for n in ('assemble.py','archive_parts.py','publish.py')}|{str(A.WATCH/'watch.py'):'a'*64}}
  review={'approved':True,'reviewer':A.REVIEWER,'role':'classification_terminal_publication_source_review','source_freeze_sha256':'a'*64,'runtime_manifest_sha256':A.RUNTIME_SHA}
  with mock.patch.object(A,'HERE',self.here),mock.patch.object(A,'STOP',self.here/'STOP'),mock.patch.object(A,'sha',return_value='a'*64),mock.patch.object(A,'read',side_effect=[freeze,review]):
   with self.assertRaisesRegex(ValueError,'Every publication executable'):A.source_authority(self.here/'source_freeze.json','a'*64,self.here/'independent_source_review.json','a'*64)

 def test_exact_license_members_are_byte_reconstructable_with_originals(self):
  source=self.here/'neutral.txt';source.write_bytes(b'invented neutral output')
  originals={};A.add_original(originals,'trajectories/invented.txt',source,A.sha(source))
  L.add_originals(self.freeze,originals,A.read,A.sha,self.here,A.add_original)
  stage=self.here/'stage';stage.mkdir()
  archives=A.archive_parts.capture_verified(originals,stage,A.ARCHIVE_PREFIX,lambda p:None)
  public={n:{k:r[k] for k in ('bytes','sha256')} for n,r in originals.items()}
  A.archive_parts.verify_reconstruction(stage,archives,public)
  self.assertEqual(set(public),set(self.members)|{'trajectories/invented.txt'})
 def test_standard_MIT_reference_cannot_be_omitted(self):
  self.c['members'].pop('licenses/BioT5/STANDARD_MIT_LICENSE_REFERENCE.txt');self.bind()
  with self.assertRaisesRegex(ValueError,'five exact'):self.call()

if __name__=='__main__':unittest.main()
