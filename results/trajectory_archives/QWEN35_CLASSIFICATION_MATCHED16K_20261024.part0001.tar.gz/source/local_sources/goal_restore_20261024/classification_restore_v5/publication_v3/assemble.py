"""Terminal-only, byte-preserving publication for the unchanged P03/P01 condition.

No generation, scoring, reference parsing, scheduler or Git commands are present.
"""
from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
from pathlib import Path
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
import re
import stat

_parts_spec = importlib.util.spec_from_file_location('classification_publication_archive_parts', Path(__file__).resolve().with_name('archive_parts.py'))
archive_parts = importlib.util.module_from_spec(_parts_spec)
_parts_spec.loader.exec_module(archive_parts)

_license_spec = importlib.util.spec_from_file_location('classification_exact_license_members', Path(__file__).resolve().with_name('license_members.py'))
license_members = importlib.util.module_from_spec(_license_spec)
_license_spec.loader.exec_module(license_members)

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
PRIVATE = HERE
STAGE = HERE / 'stage'
MANIFEST = HERE / 'manifest.json'
STOP = HERE / 'STOP'
RESTORE = HERE.parent
RUNTIME = RESTORE / 'runtime'
LANE = ROOT / '.local/qwen35_4b_comparison_20261022/protein_classification_recommended_sampling_v2'
OPERATIONAL = LANE / 'same_condition_continuation_v1/operational_plan.json'
WATCH = RESTORE / 'terminal_watch_v3'
NATIVE_REVIEW = RESTORE / 'publication_v2/independent_native_terminal_review.json'
OWNER = '/root/main_docs_refresh'
REVIEWER = '/root/independent_review'
RUN_ID = 'qwen35_4b_classification_matched16k_20261024_v5'
PUBLIC_PREFIX = 'results/runs/' + RUN_ID + '/'
ARCHIVE_PREFIX = 'results/trajectory_archives/QWEN35_CLASSIFICATION_MATCHED16K_20261024'
REPORT = 'reports/QWEN35_CLASSIFICATION_MATCHED16K_20261024.md'
JOBS = {'base': '249732', 'posttrained': '249734'}
STARTS = {'base': '2026-10-24T14:09:39', 'posttrained': '2026-10-24T14:10:21'}
PLANNED = {'P03': 2773, 'P01': 1999}
NEW_PLANNED = {'base': {'P03': 437, 'P01': 1999}, 'posttrained': {'P03': 421, 'P01': 1999}}
RUNTIME_SHA = '80337a9cac833a6764637b9262498fe531a06b7cb3130aa98fcf2832013147e6'
ADMISSION_SHA = 'fbc56ceceab317bd13a977141042466a359a0facb38fa7f2b305431100a69218'
SCIENCE_SHA = 'ee450e89141e2390f3a93f5ed2e85bd9e3ef81778ddde0301a9c3478ed909cec'
OPERATIONAL_SHA = 'd69ab37a69628972db2bef817d5f4762c3907cb546b8b2d9366d66206f53303a'
ROOT_SHA = 'bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
REPLACEMENT_SHA = 'f6f22d2bb886752fb229c92d5f19ae91315af126bc7b1b8f25fb2d84aac6f54e'
SHARED_SHA = 'cb881370f7dac295d7d153f72baddcbf604c0fce0cc651ee82c557e5efcad6f9'
FIXED_PUBLIC = {PUBLIC_PREFIX + model + '/' + task + '/scores.json'
                for model in JOBS for task in PLANNED} | {
                    PUBLIC_PREFIX + name for name in ('result_rows.json', 'scope.json', 'execution_provenance.json')
                } | {REPORT}


def require(value, message):
    if not value: raise ValueError(message)


def now(): return datetime.now(timezone.utc).isoformat()


def regular_descriptor(path):
    path = Path(path)
    require(path.is_absolute(), 'Absolute regular path required')
    directory = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            current = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory)
            os.close(directory); directory = current
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            os.close(fd); raise ValueError('Existing regular file required')
        return fd
    finally: os.close(directory)


def raw(path):
    with os.fdopen(regular_descriptor(path), 'rb') as stream: return stream.read()


def sha(path):
    digest = hashlib.sha256()
    with os.fdopen(regular_descriptor(path), 'rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''): digest.update(block)
    return digest.hexdigest()


def read(path): return json.loads(raw(path))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()
    archive_parts.create(path, data)
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try: os.fsync(fd)
    finally: os.close(fd)


def load(path, name):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def valid_public_paths(paths):
    names = set(paths)
    parts = sorted(name for name in names if re.fullmatch(re.escape(ARCHIVE_PREFIX) + r'\.part[0-9]{4}\.tar\.gz', name))
    require(1 <= len(parts) <= 256 and parts == [ARCHIVE_PREFIX + '.part' + str(i).zfill(4) + '.tar.gz'
            for i in range(1, len(parts) + 1)], 'Contiguous bounded archive parts required')
    require(names == FIXED_PUBLIC | {ARCHIVE_PREFIX + '.manifest.json'} | set(parts),
            'Exact matched P03/P01 public path set required')
    for name in names: archive_parts.safe_name(name)
    return True


def stops():
    require(not os.path.lexists(STOP), 'Publication STOP remains authoritative')


def source_authority(freeze_path, freeze_sha, review_path, review_sha):
    stops()
    require(Path(freeze_path) == HERE / 'source_freeze.json'
            and Path(review_path) == HERE / 'independent_source_review.json', 'Exact publication source records required')
    require(sha(freeze_path) == freeze_sha and sha(review_path) == review_sha, 'Publication source authority changed')
    freeze, review = read(freeze_path), read(review_path)
    require(freeze.get('role') == 'classification_terminal_only_publication_source_freeze'
            and freeze.get('runtime_manifest_sha256') == RUNTIME_SHA
            and freeze.get('jobs') == JOBS and freeze.get('planned_per_task') == PLANNED
            and freeze.get('model_calls') == freeze.get('scoring_calls') == freeze.get('GPU_requests') == 0,
            'Fixed terminal-only publication scope required')
    require(review.get('approved') is True and review.get('reviewer') == REVIEWER != OWNER
            and review.get('role') == 'classification_terminal_publication_source_review'
            and review.get('source_freeze_sha256') == freeze_sha
            and review.get('runtime_manifest_sha256') == RUNTIME_SHA, 'Exact independent publication source review required')
    required = {str(HERE / name) for name in ('assemble.py', 'archive_parts.py', 'publish.py', 'license_members.py')} | {str(WATCH / 'watch.py')}
    require(required <= set(freeze['files_sha256']), 'Every publication executable must be frozen')
    for mapping in ('files_sha256', 'static_evidence_sha256', 'public_source_files_sha256'):
        for path, expected in freeze[mapping].items():
            require(sha(path) == expected, 'Pinned source or lineage changed')
    mandatory = {
        str(RESTORE / 'manifest.json'): RUNTIME_SHA,
        str(RESTORE / 'engineering_admission.json'): ADMISSION_SHA,
        str(LANE / 'plan.json'): SCIENCE_SHA,
        str(OPERATIONAL): OPERATIONAL_SHA,
        str(RESTORE.parent / 'root_authorization.json'): ROOT_SHA,
        str(RESTORE.parent / 'classification_short_IPC_zero_call_replacement_authorization.json'): REPLACEMENT_SHA,
        str(RESTORE.parent / 'shared_resource_binding.json'): SHARED_SHA,
    }
    require(all(freeze['static_evidence_sha256'].get(path) == expected for path, expected in mandatory.items()),
            'Exact original science, restored runtime, root and resource lineage required')
    predecessor = RESTORE / 'publication'
    require(freeze.get('preserved_predecessor_publication') == str(predecessor)
            and sha(predecessor / 'STOP') == freeze.get('preserved_predecessor_STOP_sha256')
            and not any(os.path.lexists(predecessor / name) for name in ('stage', 'manifest.json', 'assembly_attempt.json',
                'attempt_started.json', 'push_intent.json', 'publication_receipt.json')),
            'Preserve disabled unattempted predecessor publication; never bypass an earlier attempt')
    predecessor_v2 = RESTORE / 'publication_v2'
    require(freeze.get('preserved_predecessor_v2') == str(predecessor_v2)
            and sha(predecessor_v2 / 'STOP') == freeze.get('preserved_predecessor_v2_STOP_sha256')
            and sha(predecessor_v2 / 'source_freeze.json') == freeze.get('preserved_predecessor_v2_freeze_sha256')
            and sha(predecessor_v2 / 'independent_source_review.json') == freeze.get('preserved_predecessor_v2_review_sha256')
            and not any(os.path.lexists(predecessor_v2 / name) for name in ('stage', 'manifest.json',
                'assembly_attempt.json', 'attempt_started.json', 'push_intent.json', 'publication_receipt.json')),
            'Preserve exact disabled unattempted V2 publication predecessor')
    license_members.validate(freeze, read, sha, HERE, review=review)
    return freeze


def native_authority(review_path, review_sha):
    require(Path(review_path) == NATIVE_REVIEW, 'Exact terminal review path required')
    require(sha(review_path) == review_sha, 'Native terminal review changed')
    review = read(review_path)
    require(review.get('approved') is True and review.get('reviewer') == REVIEWER
            and review.get('role') == 'classification_full_native_terminal_review'
            and review.get('runtime_manifest_sha256') == RUNTIME_SHA and review.get('jobs') == JOBS
            and review.get('full_native_denominator_per_model') == 4772
            and review.get('planned_per_task') == PLANNED
            and review.get('all_invalid_and_ambiguous_slots_retained') is True
            and review.get('no_rescoring') is True, 'Exact full native independent terminal review required')
    record = review['inventory']
    require(record['path'] == str(WATCH / 'native_terminal_inventory.json') and sha(record['path']) == record['sha256'],
            'Exact admitted observer inventory required')
    inventory = read(record['path'])
    require(inventory.get('role') == 'private_native_terminal_seal_inventory_not_new_scoring_or_admission'
            and inventory.get('full_native_denominator_per_model') == 4772
            and inventory.get('reference_or_per_case_target_rows_opened') is False
            and inventory.get('scoring_calls') == inventory.get('model_calls') == inventory.get('GPU_requests') == 0,
            'Terminal-only exhaustive inventory required')
    for model, job in JOBS.items():
        account = inventory['jobs'][model]
        require(account.get('job_id') == job and account.get('state') == 'COMPLETED'
                and account.get('exit_code') == '0:0' and account.get('start') == STARTS[model]
                and account.get('terminal') is True, 'Exact native jobs must have completed successfully')
    raw_batch_mapping(review)
    return review, inventory


def raw_batch_mapping(review):
    mapping = review.get('raw_batch_files_sha256')
    expected = {str(RUNTIME / model / task / ('raw_normalized_batch_' + str(start).zfill(6) + '.json'))
                for model in JOBS for task in PLANNED for start in range(0, NEW_PLANNED[model][task], 16)}
    require(isinstance(mapping, dict) and set(mapping) == expected
            and all(type(value) is str and re.fullmatch('[0-9a-f]{64}', value) for value in mapping.values()),
            'Independent terminal review must bind every exact original16-case raw batch path and hash')
    return mapping


@contextmanager
def free_owned_lock(path):
    fd = regular_descriptor(path)
    try:
        before = os.fstat(fd)
        require(before.st_uid == os.getuid(), 'Owned existing terminal lock required')
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        after = Path(path).lstat()
        require((before.st_dev, before.st_ino) == (after.st_dev, after.st_ino), 'Terminal lock was replaced')
        yield
    finally: os.close(fd)


def terminal_locks(stack):
    for model in JOBS:
        run = RUNTIME / model
        for path in [run / 'worker.lock', run / 'driver.lock'] + [run / task / 'ledger_scoring.lock' for task in PLANNED]:
            stack.enter_context(free_owned_lock(path))


def checked_tasks(inventory):
    watch = load(WATCH / 'watch.py', 'classification_publication_pinned_native_metadata')
    output = {}
    for model in JOBS:
        run = RUNTIME / model
        terminal, complete = read(run / 'worker_terminal.json'), read(run / 'model_completed.json')
        require(terminal.get('completed') is True and terminal.get('job_id') == complete.get('job_id') == JOBS[model]
                and complete.get('full_native_denominator') == 4772 and complete.get('model_key') == model
                and complete.get('all_original_and_successor_tasks_scored') is True
                and terminal.get('model_completion_sha256') == sha(run / 'model_completed.json')
                and inventory['models'][model]['worker_terminal_sha256'] == sha(run / 'worker_terminal.json'),
                'Exact complete native model seal required')
        for task in PLANNED:
            value, lock = watch.task_metadata(run / task, model, task)
            require(value == inventory['models'][model]['tasks'][task], 'Native score metadata differs from reviewed inventory')
            require(all(inventory['sealed_files_sha256'].get(path) == expected for path, expected in lock['files_sha256'].items()),
                    'Exhaustive prediction lock differs from reviewed inventory')
            output[model, task] = (read(run / task / 'scores.json'), lock)
    return output


def add_original(originals, name, path, expected=None):
    archive_parts.safe_name(name)
    path = Path(path)
    require(path == path.resolve() and path.is_absolute(), 'Canonical capture path required')
    digest = sha(path)
    require(expected is None or expected == digest, 'Captured source differs from exact seal')
    row = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}
    require(name not in originals or originals[name] == row, 'Logical archive member collision')
    originals[name] = row


def collect_originals(freeze, inventory, tasks, raw_batch_files_sha256):
    """Whitelist only approved inputs, scientific source and sealed raw outcomes."""
    originals = {}
    science, operational = read(LANE / 'plan.json'), read(OPERATIONAL)
    watch = load(WATCH / 'watch.py', 'classification_publication_pinned_member_whitelist')
    expected_sealed = {}
    private_records = {Path(operational['models'][model][kind]) for model in JOBS for kind in ('boundary_path', 'closure_path')}
    for (model, task), (_, lock) in tasks.items():
        old = Path(next(row['runtime'] for row in science['conditions'] if row['model_key'] == model and row['task_id'] == task))
        new = RUNTIME / model / task
        for path, expected in lock['files_sha256'].items():
            require(watch.sealed_member_allowed(path, old, new, operational['models'][model]),
                    'Only sealed raw requests/responses/claims and outcome ledgers may be captured')
            require(sha(path) == expected, 'Closed raw prediction member changed')
            expected_sealed[path] = expected
            source = Path(path)
            if source in private_records: continue
            if source.is_relative_to(old): name = 'trajectories/original/' + model + '/' + task + '/' + str(source.relative_to(old))
            else: name = 'trajectories/restored_v5/' + model + '/' + task + '/' + str(source.relative_to(new))
            add_original(originals, name, source, expected)
        raw_batches = {str(path) for path in new.glob('raw_normalized_batch_*.json')}
        reviewed_batches = {path: expected for path, expected in raw_batch_files_sha256.items() if Path(path).parent == new}
        require(raw_batches == set(reviewed_batches), 'Missing or unlisted raw batch; filename discovery is not capture authority')
        for name, expected in sorted(reviewed_batches.items()):
            path = Path(name)
            add_original(originals, 'trajectories/restored_v5/' + model + '/' + task + '/' + path.name, path, expected)
        for name in ('prediction_lock.json', 'completion.json', 'scoring_attempt.json', 'scores.json', 'scoring_completion.json'):
            add_original(originals, 'seals/' + model + '/' + task + '/' + name, new / name)
    require(expected_sealed == inventory['sealed_files_sha256'], 'Native inventory must match all four exhaustive seals exactly')
    for row in science['tasks']:
        task = row['task_id']; require(task in PLANNED and row['planned_per_model'] == PLANNED[task], 'Native input scope changed')
        require(Path(row['input_path']) == LANE / (task + '.inputs.jsonl'), 'Only original reviewed inputs may be captured')
        add_original(originals, 'approved_inputs/' + task + '.inputs.jsonl', row['input_path'], row['input_sha256'])
    for path, expected in freeze['public_source_files_sha256'].items():
        source = Path(path)
        require(source.is_relative_to(ROOT) and source.suffix in {'.py', '.sbatch', '.json'}
                and (source.suffix != '.json' or source.name in {'plan.json', 'operational_plan.json', 'shared_contract.json', 'config.json', 'manifest.json', 'engineering_admission.json', 'license_contract.json'}),
                'Only explicitly frozen code and named configuration metadata may be published as source')
        name = 'source/' + str(source.relative_to(ROOT)).replace('.local/', 'local_sources/', 1)
        add_original(originals, name, source, expected)
    return originals


def scanner(freeze):
    source = ROOT / 'scripts/daily_backup.py'
    require(freeze['files_sha256'].get(str(source)) == sha(source), 'Pinned credential scanner required')
    return load(source, 'classification_pinned_publication_secret_scanner').scan_file


def authority_bundle(freeze_path, freeze_sha, source_review_path, source_review_sha, native_review_path, native_review_sha):
    freeze = source_authority(freeze_path, freeze_sha, source_review_path, source_review_sha)
    native, inventory = native_authority(native_review_path, native_review_sha)
    return freeze, native, inventory


def package(args):
    freeze, native, inventory = authority_bundle(args.freeze, args.freeze_sha256, args.source_review,
        args.source_review_sha256, args.native_review, args.native_review_sha256)
    require(not any(os.path.lexists(path) for path in (STAGE, MANIFEST, HERE / 'assembly_attempt.json')),
            'Preserve prior assembly attempt; no automatic ambiguous packaging replay')
    with free_owned_lock(HERE / 'assembly.lock'), ExitStack() as stack:
        terminal_locks(stack)
        tasks = checked_tasks(inventory)
        originals = collect_originals(freeze, inventory, tasks, raw_batch_mapping(native))
        license_members.add_originals(freeze, originals, read, sha, HERE, add_original)
        scan = scanner(freeze)
        authority_bundle(args.freeze, args.freeze_sha256, args.source_review, args.source_review_sha256,
                         args.native_review, args.native_review_sha256)
        stops()
        save(HERE / 'assembly_attempt.json', {'at_utc': now(), 'model_calls': 0, 'scoring_calls': 0,
             'source_freeze_sha256': args.freeze_sha256, 'native_terminal_review_sha256': args.native_review_sha256})
        STAGE.mkdir(mode=0o700)
        archives = archive_parts.capture_verified(originals, STAGE, ARCHIVE_PREFIX, scan)
        public_originals = {name: {k: row[k] for k in ('bytes', 'sha256')} for name, row in originals.items()}
        save(STAGE / (ARCHIVE_PREFIX + '.manifest.json'), {'kind': 'byte_preserving_classification_raw_archive_manifest',
            'originals': public_originals, 'archives': archives, 'reference_rows_included': False,
            'model_weights_environments_private_GPU_audits_included': False})
        rows = []
        for (model, task), (score, _) in tasks.items():
            path = RUNTIME / model / task / 'scores.json'
            archive_parts.create_verified(STAGE / (PUBLIC_PREFIX + model + '/' + task + '/scores.json'), path, sha(path))
            rows.append({key: score[key] for key in ('model_key', 'model', 'model_revision', 'task_id', 'planned',
                'metrics', 'delivery', 'explicit_ambiguous_invalid_slots', 'prediction_lock_sha256')})
        scope = {'condition': 'unchanged matched thinking16K original plus untouched-case continuation',
            'planned_per_task_per_model': PLANNED, 'full_native_denominator_per_model': 4772,
            'all_original_case_slots_retained': True, 'attempted_or_ambiguous_cases_retried': False,
            'truncated_empty_and_ambiguous_slots_retained_invalid': True, 'output_budget': 16384,
            'new_training_or_model_selection': False, 'explanation_support_assessed': False,
            'public_pretraining_exposure': 'unknown', 'reference_rows_published': False}
        save(STAGE / (PUBLIC_PREFIX + 'result_rows.json'), rows)
        save(STAGE / (PUBLIC_PREFIX + 'scope.json'), scope)
        save(STAGE / (PUBLIC_PREFIX + 'execution_provenance.json'), {'jobs': JOBS, 'job_starts': STARTS,
             'runtime_manifest_sha256': RUNTIME_SHA, 'runtime_admission_sha256': ADMISSION_SHA,
             'scientific_plan_sha256': SCIENCE_SHA, 'original_operational_plan_sha256': OPERATIONAL_SHA,
             'root_authorization_sha256': ROOT_SHA, 'zero_case_replacement_authorization_sha256': REPLACEMENT_SHA,
             'shared_resource_binding_sha256': SHARED_SHA, 'native_terminal_review_sha256': args.native_review_sha256,
             'failed_v3_v4_records_preserved': True, 'source_freeze_sha256': args.freeze_sha256})
        lines = ['# Qwen3.5-4B matched thinking16K classification', '',
            'These are the unchanged Base and released Post conditions. Each retains the full P03 (2,773) and P01 (1,999) denominators.',
            'Immutable old responses and only previously untouched-case continuation responses form each native score. Truncated, empty and ambiguous outcomes remain invalid; none were regenerated.', '',
            '| Model | Task | Planned | Native metrics |', '| --- | --- | ---: | --- |']
        for row in rows: lines.append('| ' + row['model_key'] + ' | ' + row['task_id'] + ' | ' + str(row['planned']) + ' | `' + json.dumps(row['metrics'], sort_keys=True) + '` |')
        lines += ['', 'The individual score files retain native delivery and invalid-output counts. Outcome accuracy does not establish explanation support. Public pretraining exposure is unknown.', '',
            'Raw reviewed inputs, visible generated text/token IDs, requests/responses, frozen source and exact upstream license/attribution metadata are preserved in byte-reconstructable archive parts. Reference rows, weights, environments and private resource inventories are excluded.',
            'General-thinking sampling is matched across checkpoints at 16,384 output tokens (temperature 1.0, top-p 0.95, top-k 20, presence penalty 1.5, seed 42). Guidance comes from the released Post model; no separate Base recommendation or specialist-head reproduction is claimed.',
            'Dataset, ontology and upstream publication attribution with the exact applicable publisher declarations are included under licenses/SOURCE_ATTRIBUTION.json; no functional or experimental validation follows.', '']
        archive_parts.create(STAGE / REPORT, '\n'.join(lines).encode())
        files = {str(path.relative_to(STAGE)): sha(path) for path in STAGE.rglob('*') if path.is_file()}
        valid_public_paths(files)
        for name in files: scan(STAGE / name)
        archive_parts.recheck_originals(originals)
        authority_bundle(args.freeze, args.freeze_sha256, args.source_review, args.source_review_sha256,
                         args.native_review, args.native_review_sha256)
        evidence = {str(path): sha(path) for path in (args.freeze, args.source_review, args.native_review,
                    WATCH / 'native_terminal_inventory.json')}
        save(MANIFEST, {'kind': 'classification_matched16k_publication_manifest', 'repository': 'Some-random/bio-evaluation',
            'visibility': 'public', 'public_files_sha256': files, 'support_sha256': freeze['files_sha256'],
            'private_evidence_sha256': evidence, 'root_authorization_sha256': ROOT_SHA,
            'runtime_manifest_sha256': RUNTIME_SHA, 'jobs': JOBS, 'planned_per_task': PLANNED,
            'full_native_denominator_per_model': 4772, 'model_calls': 0, 'scoring_calls': 0,
            'website_or_schedule_changes': False, 'shared_aggregate_paths_modified': False,
            'authority': {'source_freeze': {'path': str(args.freeze), 'sha256': args.freeze_sha256},
                'source_review': {'path': str(args.source_review), 'sha256': args.source_review_sha256},
                'native_review': {'path': str(args.native_review), 'sha256': args.native_review_sha256}}})
    check()


def check(*, manifest_path=MANIFEST):
    stops()
    require(Path(manifest_path).parent == HERE and Path(manifest_path).name == 'manifest.json', 'Exact publication manifest required')
    manifest = read(manifest_path)
    require(manifest.get('kind') == 'classification_matched16k_publication_manifest'
            and manifest.get('repository') == 'Some-random/bio-evaluation' and manifest.get('visibility') == 'public'
            and manifest.get('root_authorization_sha256') == ROOT_SHA and manifest.get('runtime_manifest_sha256') == RUNTIME_SHA
            and manifest.get('jobs') == JOBS and manifest.get('planned_per_task') == PLANNED
            and manifest.get('full_native_denominator_per_model') == 4772
            and manifest.get('model_calls') == manifest.get('scoring_calls') == 0
            and manifest.get('website_or_schedule_changes') is False
            and manifest.get('shared_aggregate_paths_modified') is False, 'Fixed complete classification publication scope required')
    authority = manifest['authority']
    freeze, native, inventory = authority_bundle(authority['source_freeze']['path'], authority['source_freeze']['sha256'],
        authority['source_review']['path'], authority['source_review']['sha256'],
        authority['native_review']['path'], authority['native_review']['sha256'])
    for mapping in ('support_sha256', 'private_evidence_sha256'):
        for path, expected in manifest[mapping].items(): require(sha(path) == expected, 'Publication support/evidence changed')
    valid_public_paths(manifest['public_files_sha256'])
    actual = {str(path.relative_to(STAGE)) for path in STAGE.rglob('*') if path.is_file() or path.is_symlink()}
    require(actual == set(manifest['public_files_sha256']), 'Foreign/missing staged files')
    scan = scanner(freeze)
    for name, expected in manifest['public_files_sha256'].items():
        path = STAGE / name
        require(path.stat().st_size < 90 * 1024**2 and sha(path) == expected, 'Exact bounded staged public bytes required')
        scan(path)
    archive = read(STAGE / (ARCHIVE_PREFIX + '.manifest.json'))
    require(archive.get('kind') == 'byte_preserving_classification_raw_archive_manifest'
            and archive.get('reference_rows_included') is False
            and archive.get('model_weights_environments_private_GPU_audits_included') is False,
            'Raw archive exclusions changed')
    parts = set(manifest['public_files_sha256']) - FIXED_PUBLIC - {ARCHIVE_PREFIX + '.manifest.json'}
    require(set(archive['archives']) == parts, 'Exact archive part membership required')
    with ExitStack() as stack:
        terminal_locks(stack)
        tasks = checked_tasks(inventory)
        originals = collect_originals(freeze, inventory, tasks, raw_batch_mapping(native))
        license_members.add_originals(freeze, originals, read, sha, HERE, add_original)
        require(archive['originals'] == {name: {k: row[k] for k in ('bytes', 'sha256')} for name, row in originals.items()},
                'Raw archive original inventory differs from exhaustive native seals/source')
        archive_parts.verify_reconstruction(STAGE, archive['archives'], archive['originals'])
        for model in JOBS:
            for task in PLANNED:
                require(sha(STAGE / (PUBLIC_PREFIX + model + '/' + task + '/scores.json')) == sha(RUNTIME / model / task / 'scores.json'),
                        'Public native score differs from sole original score')
        rows = [{key: score[key] for key in ('model_key', 'model', 'model_revision', 'task_id', 'planned',
                    'metrics', 'delivery', 'explicit_ambiguous_invalid_slots', 'prediction_lock_sha256')}
                for score, _ in tasks.values()]
        require(read(STAGE / (PUBLIC_PREFIX + 'result_rows.json')) == rows, 'Public result rows differ from native metrics/delivery')
        scope = read(STAGE / (PUBLIC_PREFIX + 'scope.json'))
        require(scope.get('planned_per_task_per_model') == PLANNED and scope.get('full_native_denominator_per_model') == 4772
                and scope.get('all_original_case_slots_retained') is True
                and scope.get('attempted_or_ambiguous_cases_retried') is False
                and scope.get('truncated_empty_and_ambiguous_slots_retained_invalid') is True
                and scope.get('output_budget') == 16384 and scope.get('reference_rows_published') is False,
                'Public full native denominator and invalid-output qualifications changed')
        provenance = read(STAGE / (PUBLIC_PREFIX + 'execution_provenance.json'))
        require(provenance.get('jobs') == JOBS and provenance.get('job_starts') == STARTS
                and provenance.get('runtime_manifest_sha256') == RUNTIME_SHA
                and provenance.get('runtime_admission_sha256') == ADMISSION_SHA
                and provenance.get('scientific_plan_sha256') == SCIENCE_SHA
                and provenance.get('original_operational_plan_sha256') == OPERATIONAL_SHA
                and provenance.get('root_authorization_sha256') == ROOT_SHA
                and provenance.get('zero_case_replacement_authorization_sha256') == REPLACEMENT_SHA
                and provenance.get('shared_resource_binding_sha256') == SHARED_SHA
                and provenance.get('native_terminal_review_sha256') == authority['native_review']['sha256']
                and provenance.get('source_freeze_sha256') == authority['source_freeze']['sha256']
                and provenance.get('failed_v3_v4_records_preserved') is True,
                'Public original/restoration/job/native-review lineage changed')
    return manifest


def main():
    parser = argparse.ArgumentParser()
    for name in ('freeze', 'source-review', 'native-review'): parser.add_argument('--' + name, type=Path, required=True)
    for name in ('freeze', 'source-review', 'native-review'): parser.add_argument('--' + name + '-sha256', required=True)
    package(parser.parse_args())


if __name__ == '__main__': main()
