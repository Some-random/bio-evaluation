"""Invented metadata and bytes only; never touch a live evaluation output."""
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
import importlib.util
import json
import os
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location('classification_test_assemble', Path(__file__).with_name('assemble.py'))
A = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)


class AssemblyTests(unittest.TestCase):
    def test_public_paths_exact_contiguous_and_bounded(self):
        good = A.FIXED_PUBLIC | {A.ARCHIVE_PREFIX + '.manifest.json', A.ARCHIVE_PREFIX + '.part0001.tar.gz'}
        self.assertTrue(A.valid_public_paths(good))
        for bad in (good | {'README.md'}, good - {A.REPORT}, good | {A.ARCHIVE_PREFIX + '.part0003.tar.gz'},
                    good | {'../foreign'}, A.FIXED_PUBLIC | {A.ARCHIVE_PREFIX + '.manifest.json'}):
            with self.subTest(paths=bad), self.assertRaises(ValueError): A.valid_public_paths(bad)

    def test_missing_link_or_contended_terminal_lock_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with self.assertRaises(FileNotFoundError), A.free_owned_lock(root / 'missing'): pass
            lock = root / 'owned'; lock.touch()
            link = root / 'link'; link.symlink_to(lock)
            with self.assertRaises(OSError), A.free_owned_lock(link): pass
            with A.free_owned_lock(lock):
                with self.assertRaises(BlockingIOError), A.free_owned_lock(lock): pass
            with A.free_owned_lock(lock): pass

    def test_stop_prevents_any_authority_read(self):
        with tempfile.TemporaryDirectory() as directory:
            stop = Path(directory) / 'STOP'; stop.touch()
            with mock.patch.object(A, 'STOP', stop), mock.patch.object(A, 'sha', side_effect=AssertionError('read')):
                with self.assertRaisesRegex(ValueError, 'STOP'):
                    A.source_authority('unused', 'a', 'unused', 'b')

    def test_native_review_requires_exact_terminal_jobs_and_full_denominator(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); review_path = root / 'independent_native_terminal_review.json'
            watch = root / 'watch'; watch.mkdir()
            inventory = {'role': 'private_native_terminal_seal_inventory_not_new_scoring_or_admission',
                'full_native_denominator_per_model': 4772, 'reference_or_per_case_target_rows_opened': False,
                'scoring_calls': 0, 'model_calls': 0, 'GPU_requests': 0,
                'jobs': {model: {'job_id': job, 'state': 'COMPLETED', 'exit_code': '0:0',
                    'start': A.STARTS[model], 'terminal': True} for model, job in A.JOBS.items()}}
            inventory_path = watch / 'native_terminal_inventory.json'
            review = {'approved': True, 'reviewer': A.REVIEWER, 'role': 'classification_full_native_terminal_review',
                'runtime_manifest_sha256': A.RUNTIME_SHA, 'jobs': A.JOBS, 'full_native_denominator_per_model': 4772,
                'all_invalid_and_ambiguous_slots_retained': True, 'no_rescoring': True,
                'raw_batch_files_sha256': {str(A.RUNTIME/model/task/('raw_normalized_batch_'+str(start).zfill(6)+'.json')):'a'*64
                    for model in A.JOBS for task in A.PLANNED for start in range(0,A.NEW_PLANNED[model][task],16)},
                'planned_per_task': A.PLANNED, 'inventory': {'path': str(inventory_path), 'sha256': ''}}
            def write():
                inventory_path.write_text(json.dumps(inventory))
                review['inventory']['sha256'] = A.sha(inventory_path)
                review_path.write_text(json.dumps(review))
                return A.sha(review_path)
            with mock.patch.object(A, 'HERE', root), mock.patch.object(A, 'WATCH', watch), mock.patch.object(A, 'NATIVE_REVIEW', review_path):
                A.native_authority(review_path, write())
                for field, bad in [('state', 'RUNNING'), ('job_id', '9'), ('exit_code', '1:0'), ('terminal', False)]:
                    prior = inventory['jobs']['base'][field]; inventory['jobs']['base'][field] = bad
                    with self.subTest(field=field), self.assertRaises(ValueError): A.native_authority(review_path, write())
                    inventory['jobs']['base'][field] = prior
                review['full_native_denominator_per_model'] = 1
                with self.assertRaises(ValueError): A.native_authority(review_path, write())

    def test_capture_whitelist_rejects_reference_path_before_read(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); lane = root / 'lane'; lane.mkdir()
            runtime = root / 'runtime'; runtime.mkdir()
            operational = root / 'operational_plan.json'
            models = {m: {'boundary_path': str(root / (m + '.boundary.json')),
                          'closure_path': str(root / (m + '.closure.json'))} for m in A.JOBS}
            operational.write_text(json.dumps({'models': models}))
            science = {'conditions': [{'model_key': m, 'task_id': t, 'runtime': str(root / 'old' / m / t)}
                                     for m in A.JOBS for t in A.PLANNED], 'tasks': []}
            (lane / 'plan.json').write_text(json.dumps(science))
            reference = lane / 'P03.references.jsonl'
            tasks = {('base', 'P03'): ({}, {'files_sha256': {str(reference): 'a' * 64}})}
            validator = SimpleNamespace(sealed_member_allowed=lambda *args: False)
            with mock.patch.object(A, 'LANE', lane), mock.patch.object(A, 'OPERATIONAL', operational), \
                    mock.patch.object(A, 'RUNTIME', runtime), mock.patch.object(A, 'load', return_value=validator):
                with self.assertRaisesRegex(ValueError, 'Only sealed'):
                    A.collect_originals({'public_source_files_sha256': {}}, {'sealed_files_sha256': {}}, tasks, {})
            self.assertFalse(reference.exists())

    def test_terminal_raw_batch_mapping_is_exact_complete_and_digest_bound(self):
        mapping = {str(A.RUNTIME/model/task/('raw_normalized_batch_'+str(start).zfill(6)+'.json')):'a'*64
                   for model in A.JOBS for task in A.PLANNED for start in range(0,A.NEW_PLANNED[model][task],16)}
        self.assertEqual(len(mapping),305)
        self.assertEqual(A.raw_batch_mapping({'raw_batch_files_sha256':mapping}),mapping)
        missing = dict(mapping);missing.pop(next(iter(missing)))
        foreign = dict(mapping);foreign['/tmp/unlisted.json']='a'*64
        bad_hash = dict(mapping);bad_hash[next(iter(bad_hash))]='bad'
        for value in [missing,foreign,bad_hash,None]:
            with self.subTest(mapping=value), self.assertRaises(ValueError):
                A.raw_batch_mapping({'raw_batch_files_sha256':value})

    def test_unlisted_missing_or_changed_raw_batch_is_rejected_before_capture(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);lane=root/'lane';lane.mkdir();runtime=root/'runtime'
            new=runtime/'base/P03';new.mkdir(parents=True)
            batch=new/'raw_normalized_batch_000000.json';batch.write_bytes(b'[{"raw_text":"invented"}]')
            op=root/'operational_plan.json';op.write_text(json.dumps({'models':{model:{
                'boundary_path':str(root/(model+'.boundary')), 'closure_path':str(root/(model+'.closure'))} for model in A.JOBS}}))
            (lane/'plan.json').write_text(json.dumps({'conditions':[{'model_key':'base','task_id':'P03','runtime':str(root/'old')}],'tasks':[]}))
            tasks={('base','P03'):({}, {'files_sha256':{}})}
            with mock.patch.object(A,'LANE',lane),mock.patch.object(A,'OPERATIONAL',op),mock.patch.object(A,'RUNTIME',runtime), \
                    mock.patch.object(A,'load',return_value=SimpleNamespace()):
                with self.assertRaisesRegex(ValueError,'unlisted raw batch'):
                    A.collect_originals({'public_source_files_sha256':{}},{'sealed_files_sha256':{}},tasks,{})
                with self.assertRaisesRegex(ValueError,'differs from exact seal'):
                    A.collect_originals({'public_source_files_sha256':{}},{'sealed_files_sha256':{}},tasks,{str(batch):'a'*64})
                batch.unlink()
                with self.assertRaisesRegex(ValueError,'Missing or unlisted'):
                    A.collect_originals({'public_source_files_sha256':{}},{'sealed_files_sha256':{}},tasks,{str(batch):'a'*64})

    def test_stop_arriving_after_terminal_reads_prevents_attempt_and_capture(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); lock = root / 'assembly.lock'; lock.touch()
            stop = root / 'STOP'
            def authority(*args):
                authority.calls += 1
                if authority.calls == 2: stop.touch()
                return {}, {}, {}
            authority.calls = 0
            args = SimpleNamespace(freeze=root/'freeze', freeze_sha256='a', source_review=root/'review',
                source_review_sha256='b', native_review=root/'native', native_review_sha256='c')
            with ExitStack() as stack:
                for name, value in {'HERE': root, 'STOP': stop, 'STAGE': root/'stage', 'MANIFEST': root/'manifest.json'}.items():
                    stack.enter_context(mock.patch.object(A, name, value))
                stack.enter_context(mock.patch.object(A, 'authority_bundle', side_effect=authority))
                stack.enter_context(mock.patch.object(A, 'terminal_locks'))
                stack.enter_context(mock.patch.object(A, 'checked_tasks', return_value={}))
                stack.enter_context(mock.patch.object(A, 'collect_originals', return_value={}))
                stack.enter_context(mock.patch.object(A.license_members, 'add_originals'))
                stack.enter_context(mock.patch.object(A, 'raw_batch_mapping', return_value={}))
                stack.enter_context(mock.patch.object(A, 'scanner', return_value=lambda path: None))
                capture = stack.enter_context(mock.patch.object(A.archive_parts, 'capture_verified', side_effect=AssertionError('capture')))
                with self.assertRaisesRegex(ValueError, 'STOP'): A.package(args)
                capture.assert_not_called()
                self.assertFalse((root/'assembly_attempt.json').exists())
                self.assertFalse((root/'stage').exists())

    def test_prior_or_dangling_assembly_attempt_has_no_replay(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); (root/'assembly_attempt.json').symlink_to(root/'missing')
            args = SimpleNamespace(freeze='a', freeze_sha256='a', source_review='a', source_review_sha256='a',
                                   native_review='a', native_review_sha256='a')
            with mock.patch.object(A, 'HERE', root), mock.patch.object(A, 'STAGE', root/'stage'), \
                    mock.patch.object(A, 'MANIFEST', root/'manifest.json'), mock.patch.object(A, 'authority_bundle', return_value=({}, {}, {})):
                with self.assertRaisesRegex(ValueError, 'prior assembly'): A.package(args)
            self.assertFalse((root/'stage').exists())

    def test_invented_capture_emits_only_expected_public_paths_and_exact_native_bytes(self):
        actual_check = A.check
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); (root/'assembly.lock').touch()
            runtime = root/'runtime'; runtime.mkdir()
            source = root/'invented-response.json'; source.write_bytes(b'{"raw_text":"invented neutral words","token_ids":[1,2]}\n')
            originals = {'trajectories/invented/response.json': {'path': str(source), 'bytes': source.stat().st_size,
                         'sha256': A.sha(source)}}
            tasks = {}
            for model in A.JOBS:
                for task in A.PLANNED:
                    folder = runtime/model/task; folder.mkdir(parents=True)
                    score = {'model_key': model, 'model': 'invented/' + model, 'model_revision': 'a'*40,
                        'task_id': task, 'planned': A.PLANNED[task], 'metrics': {'planned': A.PLANNED[task], 'accuracy': 0.0},
                        'delivery': {'truncations': 1, 'empty_or_missing_finals': 1},
                        'explicit_ambiguous_invalid_slots': 0, 'prediction_lock_sha256': 'b'*64}
                    (folder/'scores.json').write_text(json.dumps(score))
                    tasks[model, task] = (score, {})
            args = SimpleNamespace(freeze=root/'freeze', freeze_sha256='a', source_review=root/'review',
                source_review_sha256='b', native_review=root/'native', native_review_sha256='c')
            for path in (args.freeze, args.source_review, args.native_review): path.write_text('{}')
            watch = root/'watch'; watch.mkdir(); (watch/'native_terminal_inventory.json').write_text('{}')
            with ExitStack() as stack:
                for name, value in {'HERE': root, 'STOP': root/'STOP', 'STAGE': root/'stage',
                                    'MANIFEST': root/'manifest.json', 'RUNTIME': runtime, 'WATCH': watch}.items():
                    stack.enter_context(mock.patch.object(A, name, value))
                stack.enter_context(mock.patch.object(A, 'authority_bundle', return_value=({'files_sha256': {}}, {}, {})))
                stack.enter_context(mock.patch.object(A, 'terminal_locks'))
                stack.enter_context(mock.patch.object(A, 'checked_tasks', return_value=tasks))
                stack.enter_context(mock.patch.object(A, 'collect_originals', return_value=originals))
                stack.enter_context(mock.patch.object(A.license_members, 'add_originals'))
                stack.enter_context(mock.patch.object(A, 'raw_batch_mapping', return_value={}))
                stack.enter_context(mock.patch.object(A, 'scanner', return_value=lambda path: None))
                stack.enter_context(mock.patch.object(A, 'check'))
                A.package(args)
                manifest = json.loads((root/'manifest.json').read_text())
                self.assertTrue(A.valid_public_paths(manifest['public_files_sha256']))
                for model in A.JOBS:
                    for task in A.PLANNED:
                        self.assertEqual((root/'stage'/(A.PUBLIC_PREFIX+model+'/'+task+'/scores.json')).read_bytes(),
                                         (runtime/model/task/'scores.json').read_bytes())
                archive = json.loads((root/'stage'/(A.ARCHIVE_PREFIX+'.manifest.json')).read_text())
                self.assertNotIn('path', archive['originals']['trajectories/invented/response.json'])
                A.archive_parts.verify_reconstruction(root/'stage', archive['archives'], archive['originals'])
                actual_check(manifest_path=root/'manifest.json')
                for name, change in [
                    ('scope.json', lambda value: value.update(full_native_denominator_per_model=1)),
                    ('result_rows.json', lambda value: value[0]['metrics'].update(accuracy=999)),
                    ('execution_provenance.json', lambda value: value['jobs'].update(base='9')),
                ]:
                    destination = root/'stage'/(A.PUBLIC_PREFIX+name)
                    old = destination.read_bytes(); value = json.loads(old); change(value)
                    destination.write_text(json.dumps(value))
                    manifest['public_files_sha256'][A.PUBLIC_PREFIX+name] = A.sha(destination)
                    (root/'manifest.json').write_text(json.dumps(manifest))
                    with self.subTest(mutated=name), self.assertRaises(ValueError):
                        actual_check(manifest_path=root/'manifest.json')
                    destination.write_bytes(old)
                    manifest['public_files_sha256'][A.PUBLIC_PREFIX+name] = A.sha(destination)
                    (root/'manifest.json').write_text(json.dumps(manifest))
                with self.assertRaisesRegex(ValueError, 'prior assembly'): A.package(args)


if __name__ == '__main__': unittest.main()
