"""Owned request-creation drain at live allocation EndTime minus sixty minutes.

No signals, cancellations, existing-case writes, scientific edits or retries.
Existing fully prepared batches may finish. Draft requests remain immutable
ambiguous outcomes and cannot become eligible for a successor call.
"""
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import hashlib
import json
import os
import stat
import time

from scheduler import LANE, EXPECTED, observe

HERE=Path(__file__).resolve().parent
PACIFIC=ZoneInfo('America/Los_Angeles')


def stamp():return datetime.now(PACIFIC).isoformat()


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x')as handle:
        json.dump(value,handle,indent=2);handle.write('\n');handle.flush();os.fsync(handle.fileno())
    fd=os.open(path.parent,os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)


def deadline_due(row,now=None):
    if row.get('JobState')!='RUNNING':return False
    now=now or datetime.now(PACIFIC)
    end=datetime.fromisoformat(row['EndTime'])
    if end.tzinfo is None:end=end.replace(tzinfo=PACIFIC)
    return (end-now).total_seconds()<=3600


def directory_identity(path):
    path=Path(path)
    if path!=path.resolve()or path.is_symlink():raise ValueError('Exact nonsymlink directory required')
    before=path.lstat()
    if not stat.S_ISDIR(before.st_mode)or before.st_uid!=26129:raise ValueError('Owned original request parent required')
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    opened=os.fstat(fd)
    if (opened.st_dev,opened.st_ino)!=(before.st_dev,before.st_ino):
        os.close(fd);raise ValueError('Original request parent replaced during open')
    return fd,{'path':str(path),'dev':opened.st_dev,'ino':opened.st_ino,'uid':opened.st_uid,
        'original_mode':stat.S_IMODE(opened.st_mode),'drain_mode':stat.S_IMODE(opened.st_mode)&~0o222}


def observed_progress(runtime):
    """Only a direct metadata observation; filenames never establish attempts."""
    rows={}
    for task in ('P03','P01'):
        folder=Path(runtime)/task;progress=folder/'progress.json'
        row={'task_directory_exists':folder.exists(),'case_parent_exists':(folder/'cases').exists(),
             'filename_counts_are_observations_not_dispatch_counts':True}
        if progress.exists():
            try:
                raw=progress.read_bytes();value=json.loads(raw)
                row['progress_sha256']=hashlib.sha256(raw).hexdigest()
                row['progress']={key:value.get(key)for key in ('at_pacific','plan_sha256','model_key','task_id','job_id',
                    'planned','attempted_confirmed','attempted_or_ambiguous','responses_saved','terminal','not_dispatched',
                    'truncations','empty_finals','generation_exceptions','transport_errors','http_errors','refusals')}
            except (OSError,ValueError)as error:row['progress_read_unknown']=type(error).__name__
        else:row['progress']='unknown; no direct progress record'
        rows[task]=row
    return rows


def remove_writes(fd,identity):
    current=os.fstat(fd)
    if(current.st_dev,current.st_ino,current.st_uid,stat.S_IMODE(current.st_mode))!=(identity['dev'],identity['ino'],identity['uid'],identity['original_mode']):
        raise ValueError('Owned original directory identity or mode changed before restriction')
    os.fchmod(fd,identity['drain_mode']);os.fsync(fd)
    after=os.fstat(fd);named=Path(identity['path']).lstat()
    if ((named.st_dev,named.st_ino)!=(identity['dev'],identity['ino'])
        or stat.S_IMODE(after.st_mode)!=identity['drain_mode']or after.st_mode&0o222):
        raise ValueError('Request creation drain did not verify')
    return {**identity,'verified_mode':stat.S_IMODE(after.st_mode),'write_bits_removed':True,
            'existing_case_children_untouched':True}


def apply_model_drain(plan,model):
    info=plan['models'][model];runtime=Path(info['original_runtime'])
    if runtime!=LANE/'runtime'/model or info['predecessor_job_id']!=EXPECTED[model]['job_id']:
        raise ValueError('Different original condition or model path')
    before=observe(model)
    if not deadline_due(before['fields']):raise ValueError('Drain is only permitted in the adopted final60minute window')
    if any((runtime/task/'stopped.json').exists()for task in ('P03','P01')):
        raise ValueError('Original fatal stop remains held; no operational drain mutation')
    target=HERE/'drains'/model;target.mkdir(parents=True,exist_ok=True)
    if(target/'intent.json').exists():raise ValueError('Drain already attempted or ambiguous; no automatic repeat')
    if all((runtime/task/'scoring_completion.json').exists()for task in ('P03','P01')):
        return {'not_needed':True,'reason':'Both original task scoring-completion artifacts exist; terminal reconciliation will verify them.'}
    parent_fd,parent_identity=directory_identity(runtime)
    try:
        save(target/'intent.json',{'at_pacific':stamp(),'model_key':model,'predecessor_job_id':info['predecessor_job_id'],
            'operational_plan_sha256':sha(HERE/'operational_plan.json'),'before_scheduler':before,
            'model_parent':parent_identity,'before_progress':observed_progress(runtime),
            'role':'restriction_only_owned_request_creation_drain_intent_not_dispatch_counts',
            'model_calls_by_operation':0,'signals_sent':0,'jobs_cancelled':0})
        restricted=[remove_writes(parent_fd,parent_identity)]
        # Restrict the model parent first. A not-yet-created P01 namespace can
        # no longer appear. If its mkdir won the race, let the frozen startup
        # create its cases parent, then restrict it; existing batches may finish.
        for task in ('P03','P01'):
            folder=runtime/task;cases=folder/'cases'
            if not folder.exists():continue
            wait_until=time.monotonic()+15
            while not cases.exists()and time.monotonic()<wait_until:
                if not folder.exists():raise ValueError('Original task namespace changed during drain')
                time.sleep(0.05)
            if not cases.exists():
                # Do not claim a completed drain if an already-created task
                # could still make new requests. The parent restriction remains
                # preserved; this rare race is held for exact manual review.
                raise ValueError('Existing original task has no cases parent; safe drain closure remains unknown')
            fd,identity=directory_identity(cases)
            try:restricted.append(remove_writes(fd,identity))
            finally:os.close(fd)
        result={'at_pacific':stamp(),'role':'verified_restriction_only_request_creation_drain',
            'applied':True,'model_key':model,'predecessor_job_id':info['predecessor_job_id'],
            'intent_sha256':sha(target/'intent.json'),'restrictions':restricted,
            'after_progress_observation':observed_progress(runtime),
            'active_calls_interrupted':False,'existing_case_children_untouched':True,
            'fully_prepared_batches_may_finish':True,'partial_drafts_preserved_and_never_retried':True,
            'permissions_will_not_be_restored_by_this_controller':True,
            'model_calls_by_operation':0,'signals_sent':0,'jobs_cancelled':0}
        save(target/'applied.json',result);return result
    finally:os.close(parent_fd)
