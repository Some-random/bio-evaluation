"""Once-only native scoring of unchanged16K inherited and successor outcomes.

An absent original response remains an explicit None scoring slot. This module
never generates text, restores permissions, changes original files or submits.
"""
from collections import Counter
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import fcntl
import hashlib
import importlib.util
import json
import os
import stat

HERE = Path(__file__).resolve().parent
LANE = HERE.parent
SCIENCE_SHA = 'ee450e89141e2390f3a93f5ed2e85bd9e3ef81778ddde0301a9c3478ed909cec'


def require(value, message):
    if not value:
        raise ValueError(message)


def stamp():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def raw(path):
    path = Path(path)
    require(path.is_absolute() and path == path.resolve(), 'Exact nonsymlink absolute artifact required')
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'Regular artifact required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as handle:
        opened = os.fstat(handle.fileno())
        require((opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino), 'Artifact replaced before read')
        value = handle.read()
        after = os.fstat(handle.fileno())
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(identity(before) == identity(after) == identity(path.lstat()), 'Artifact changed during read')
    return value


def sha(path):
    return hashlib.sha256(raw(path)).hexdigest()


def read(path):
    return json.loads(raw(path))


def module(path, name):
    raw(path)
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def save(path, value):
    path = Path(path)
    with path.open('x') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
    fd = os.open(path.parent, os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def validate_science(plan):
    """Do not even hash reference files before exhaustive outcome sealing."""
    original = LANE / 'plan.json'
    require(sha(original) == SCIENCE_SHA and read(original) == plan, 'Exact original16K scientific plan required')
    references = {row['reference_path'] for row in plan['tasks']}
    for path, expected in plan['pins'].items():
        if path not in references:
            require(sha(path) == expected, 'Original scientific source changed: ' + path)
    require(plan['generation']['max_tokens'] == 16384 and plan['batch_size'] == 16,
            'Original scientific generation or concurrency changed')


def bind_boundary(boundary, model_key, boundary_path, boundary_sha, closure_path, closure_sha):
    require(boundary_path is not None and closure_path is not None, 'Actual immutable boundary and closure paths required')
    require(sha(boundary_path) == boundary_sha and read(boundary_path) == boundary,
            'Exact immutable boundary hash or content changed')
    require(sha(closure_path) == closure_sha, 'Exact predecessor closure changed')
    closure = read(closure_path)
    require(boundary.get('model_key') == model_key and boundary.get('scientific_plan_sha256') == SCIENCE_SHA,
            'Boundary scientific/model identity mismatch')
    for name, expected in [('model_key', model_key), ('scientific_plan_sha256', SCIENCE_SHA),
                           ('predecessor_job_id', boundary['predecessor_job_id']), ('boundary_sha256', boundary_sha)]:
        require(closure.get(name) == expected, 'Closure does not bind exact boundary/model/predecessor: ' + name)
    scheduler, locks = closure.get('terminal_scheduler'), closure.get('original_output_locks')
    require(isinstance(scheduler, dict) and scheduler.get('terminal') is True
            and isinstance(locks, list) and bool(locks), 'Closure lacks terminal scheduler or original lock evidence')
    require(all(isinstance(row, dict) and isinstance(row.get('path'), str)
                and ((row.get('free_lock_acquired') is True
                      and all(type(row.get(k)) is int for k in ('dev', 'ino', 'uid', 'mode')))
                     or row.get('absent_unstarted_task') is True) for row in locks),
            'Closure original-output lock record is malformed')
    return closure


def replay_context(plan, condition, tokenizer=None):
    common = module(plan['shared_runtime']['path'], 'continuation16k_shared_replay')
    contract = common.load_contract(plan['shared_contract']['path'], plan['shared_contract']['sha256'])
    require(contract['generation'] == plan['generation'] and contract['context_limit'] == 65536,
            'Original scientific shared recipe changed')
    native = module(LANE / 'score.py', 'continuation16k_native_score')
    runtime = module(LANE / 'driver.py', 'continuation16k_native_refusal')
    if tokenizer is None:
        checked, checked_contract, tokenizer = native.replay_context(plan, condition)
        require(checked_contract == contract, 'Native scorer shared contract differs')
    return common, contract, tokenizer, native, runtime


def fatal(output, runtime, normalized):
    """Apply exactly the original driver's stop rule, never a new condition.

    Structural provenance and raw-schema validation remain separate. Ordinary
    parser/format failures, including nested thinking tags and truncated text,
    stay invalid outcomes in the original native denominator.
    """
    text = output.get('raw_text')
    require(isinstance(text, str), 'Saved raw output is malformed')
    require(output.get('status') != 'generation_exception', 'Original or successor fatal generation outcome remains held')
    require(output.get('finish_reason') in {'stop', 'length'}, 'Ambiguous generation finish remains held')
    final = normalized.get('final_text', normalized.get('final', '')) or ''
    refused = runtime.classify_refusal(final, output.get('refusal', False))['refusal']
    require(not refused and not output.get('extra_assistant_tail')
            and '<tool_call>' not in text and '<|im_start|>' not in text,
            'Original or successor fatal refusal/tool/role outcome remains held')


def verify_request(request_path, row, identity, plan, common, contract, tokenizer, extra=None):
    request = read(request_path)
    require(all(request.get(k) == v for k, v in identity.items())
            and request.get('case_id') == row['case_id'] and request.get('messages') == row['messages']
            and request.get('generation') == plan['generation'], 'Saved request native source/model/generation mismatch')
    if extra:
        require(all(request.get(k) == v for k, v in extra.items()), 'Successor request operational provenance mismatch')
        require(str(request.get('job_id', '')).isdigit() and request['job_id'] == os.environ.get('SLURM_JOB_ID'),
                'Actual successor request job identity mismatch')
    expected = common.prepare_case({'task_id': row['task'], 'case_id': row['case_id'], 'messages': row['messages']},
                                   tokenizer, identity['model_key'], contract)
    require(request.get('prepared') == expected, 'Saved prepared request differs from complete native rendering')
    return request


def verify_response(response_path, request_path, request, row, identity, common, contract, runtime, extra=None):
    response = read(response_path)
    require(all(response.get(k) == v for k, v in identity.items())
            and response.get('case_id') == row['case_id'] and response.get('request_sha256') == sha(request_path)
            and response.get('prepared_request_sha256') == request['prepared']['request_sha256'],
            'Saved response source/request/model provenance mismatch')
    if extra:
        require(all(response.get(k) == v for k, v in extra.items())
                and response.get('job_id') == request.get('job_id'), 'Successor response operational provenance mismatch')
    replay = common.normalize_output(request['prepared'], response['raw_text'], response['token_ids'],
                                     response['finish_reason'], contract, usage=response.get('usage', {}))
    replay.update(runtime.classify_refusal(replay['final_text']))
    fatal(response, runtime, replay)
    names = ['final', 'final_text', 'reasoning', 'response_error', 'extra_assistant_tail', 'missing_think_close',
             'status', 'truncated', 'terminal', 'transport_error', 'http_error', 'not_dispatched',
             'prompt_tokens', 'completion_tokens', 'usage', 'refusal', 'possible_inability_text']
    require(all(response.get(name) == replay[name] for name in names), 'Saved response derived fields differ from native raw replay')
    require(len(response['token_ids']) <= 16384, 'Saved generation exceeds unchanged16K ceiling')
    return response


def preserved_score(original, task_boundary, identity, records):
    """Return independently hash-verified existing terminal score, never rescore."""
    require(task_boundary['task_state'] == 'already_scored_preserve_without_rescoring'
            and all(row['outcome_state'] == 'inherited_saved_response' for row in records),
            'Original score conflicts with exhaustive inherited boundary')
    done = read(original / 'scoring_completion.json')
    result = read(original / 'scores.json')
    require(done.get('scoring_terminal') is True and done.get('scores_sha256') == sha(original / 'scores.json')
            and done.get('per_case_scores_sha256') == sha(original / 'per_case_scores.json'), 'Original terminal score hashes changed')
    completion = read(original / 'completion.json')
    lock_path = original / 'prediction_lock.json'
    lock = read(lock_path)
    expected = {f'cases/{r["index"]:06d}/{name}.json': r[name]['sha256']
                for r in records for name in ('request', 'response')}
    require(lock.get('files_sha256') == expected and lock.get('all_planned_terminal') is True
            and completion.get('all_planned_terminal') is True
            and completion.get('terminal') == len(records)
            and completion.get('prediction_lock_sha256') == sha(lock_path)
            and result.get('prediction_lock_sha256') == sha(lock_path)
            and result.get('planned') == len(records)
            and result.get('metrics', {}).get('planned') == len(records)
            and all(result.get(k) == identity[k] for k in ('model', 'model_revision', 'task_id', 'run_id'))
            and all(lock.get(k) == v and completion.get(k) == v for k, v in identity.items()),
            'Original terminal score lacks exact exhaustive scientific seal')
    return result


def seal_and_score(scientific_plan_dict, boundary_manifest, model_key, task_id, successor_task_runtime,
                   operational_plan_sha256, boundary_sha256, closure_sha256, tokenizer=None, *,
                   boundary_path=None, closure_path=None):
    """Seal all original case slots, then calculate the unchanged native metric.

    Predecessor terminality/live locks and engineering admission are checked by
    the caller; immutable exact closure evidence is independently bound here.
    """
    plan = scientific_plan_dict
    validate_science(plan)
    bind_boundary(boundary_manifest, model_key, boundary_path, boundary_sha256, closure_path, closure_sha256)
    condition = next(c for c in plan['conditions'] if c['model_key'] == model_key and c['task_id'] == task_id)
    source = next(t for t in plan['tasks'] if t['task_id'] == task_id)
    identity = {name: condition[name] for name in ('model', 'model_revision', 'model_key', 'task_id', 'run_id')}
    identity['plan_sha256'] = SCIENCE_SHA
    extra = {'continuation_plan_sha256': operational_plan_sha256, 'boundary_sha256': boundary_sha256,
             'closure_sha256': closure_sha256}
    original = Path(condition['runtime'])
    run = Path(successor_task_runtime)
    require(run.is_absolute() and run == run.resolve() and not run.is_relative_to(original)
            and not original.is_relative_to(run), 'Separate exact successor task namespace required')
    require(not (original / 'stopped.json').exists() and not (run / 'stopped.json').exists(),
            'Fatal predecessor or successor stop remains held')
    require(sha(source['input_path']) == source['input_sha256'], 'Original input bytes changed')
    inputs = [json.loads(line) for line in raw(source['input_path']).splitlines()]
    task = boundary_manifest['tasks'][task_id]
    require(task['planned'] == condition['planned'] == source['planned_per_model'] == len(inputs)
            and task['input_path'] == source['input_path'] and task['input_sha256'] == source['input_sha256']
            and task['runtime_path'] == str(original) and task['run_id'] == condition['run_id'], 'Exact full native boundary denominator/source differs')
    records = task['cases']
    require(len(records) == len(inputs) and [r['index'] for r in records] == list(range(len(inputs)))
            and [r['case_id'] for r in records] == [r['case_id'] for r in inputs]
            and all(r['task_id'] == task_id for r in records), 'Boundary cases must cover exact original order once')
    require(task['counts'] == dict(Counter(r['outcome_state'] for r in records)), 'Boundary outcome counts differ')
    require(task['eligible_case_ids'] == [r['case_id'] for r in records if r['outcome_state'] == 'unclaimed']
            and task['ambiguous_case_ids'] == [r['case_id'] for r in records if r['outcome_state'] == 'ambiguous_claim_invalid'],
            'Boundary eligible/ambiguous roster differs')
    for name, record in task.get('source_records', {}).items():
        require(record['path'] == str(original / name) and sha(record['path']) == record['sha256'],
                'Frozen predecessor task metadata changed: ' + name)
    common, contract, tokenizer, native, runtime = replay_context(plan, condition, tokenizer)
    outputs, ledger, files = [], [], {}
    for index, (record, row) in enumerate(zip(records, inputs)):
        state = record['outcome_state']
        original_case = original / 'cases' / f'{index:06d}'
        request_path, response_path = original_case / 'request.json', original_case / 'response.json'
        operational = None
        claim_path = None
        if state in {'inherited_saved_response', 'ambiguous_claim_invalid'}:
            require(record.get('eligible_for_new_model_call') is False and record.get('request') is not None,
                    'Inherited/ambiguous case cannot be dispatched')
            require(record['request']['path'] == str(request_path) and sha(request_path) == record['request']['sha256'],
                    'Original inherited request bytes changed')
            if state == 'inherited_saved_response':
                require(record.get('response') is not None and record['response']['path'] == str(response_path)
                        and sha(response_path) == record['response']['sha256'], 'Original inherited response bytes changed')
            else:
                require(record.get('response') is None and not response_path.exists(), 'Original ambiguous response unexpectedly appeared')
            require(not (run / 'cases' / f'{index:06d}').exists(), 'Previously claimed case must never have successor artifacts')
        elif state == 'unclaimed':
            require(record.get('eligible_for_new_model_call') is True and record.get('request') is None
                    and record.get('response') is None and not request_path.exists() and not response_path.exists(),
                    'Boundary-unclaimed original case acquired a prior claim/output')
            request_path, response_path = run / 'cases' / f'{index:06d}' / 'request.json', run / 'cases' / f'{index:06d}' / 'response.json'
            claim_path = request_path.parent / 'claim.json'
            operational = extra
        else:
            raise ValueError('Unknown boundary outcome state')
        request = verify_request(request_path, row, identity, plan, common, contract, tokenizer, operational)
        if claim_path is not None:
            claim = read(claim_path)
            require(all(claim.get(k) == v for k, v in {**identity, **extra}.items())
                    and claim.get('job_id') == request.get('job_id') and claim.get('case_id') == row['case_id']
                    and claim.get('index') == index and request.get('index') == index
                    and claim.get('prepared_request_sha256') == request['prepared']['request_sha256']
                    and claim.get('role') == 'exclusive_new_unclaimed_case_intent_not_dispatch_evidence'
                    and claim.get('one_attempt_only') is True and request.get('claim_sha256') == sha(claim_path),
                    'Successor exclusive once-only claim/request association mismatch')
            files[str(claim_path)] = sha(claim_path)
        if operational is None:
            require(request.get('job_id') == boundary_manifest['predecessor_job_id']
                    and record['request'].get('job_id') == request.get('job_id'),
                    'Inherited request does not belong to exact original predecessor job')
        files[str(request_path)] = sha(request_path)
        output = None
        if state != 'ambiguous_claim_invalid':
            output = verify_response(response_path, request_path, request, row, identity, common, contract, runtime, operational)
            if operational is None:
                require(output.get('job_id') == request.get('job_id')
                        and record['response'].get('job_id') == output.get('job_id'),
                        'Inherited response does not belong to exact original predecessor job')
            else:
                require(output.get('index') == index and output.get('claim_sha256') == sha(claim_path),
                        'Successor response differs from original-index exclusive claim')
            files[str(response_path)] = sha(response_path)
        outputs.append(output)
        ledger.append({'index': index, 'case_id': row['case_id'], 'task_id': task_id,
                       'outcome_state': state if state != 'unclaimed' else 'successor_saved_response',
                       'claim': {'path': str(claim_path), 'sha256': sha(claim_path)} if claim_path is not None else None,
                       'request': {'path': str(request_path), 'sha256': sha(request_path)},
                       'response': {'path': str(response_path), 'sha256': sha(response_path)} if output is not None else None,
                       'missing_raw_response': output is None, 'native_scoring_slot': 'None_invalid' if output is None else 'saved_raw_response',
                       'response_status': output.get('status') if output is not None else 'ambiguous_claim_invalid',
                       'raw_response_fabricated': False})
    if (original / 'scores.json').exists():
        return preserved_score(original, task, identity, records)
    require(task['task_state'] == 'continue_unclaimed_then_seal_once'
            and not (original / 'scoring_attempt.json').exists()
            and not (original / 'scoring_completion.json').exists(), 'Original incomplete scoring attempt must be held offline')
    expected_new = {f'{r["index"]:06d}' for r in records if r['outcome_state'] == 'unclaimed'}
    cases = run / 'cases'
    if cases.exists():
        require(not cases.is_symlink() and cases.is_dir() and {p.name for p in cases.iterdir()} == expected_new
                and all(p.is_dir() and not p.is_symlink() for p in cases.iterdir()), 'Foreign or missing successor case directories')
    else:
        require(not expected_new, 'Missing successor case output namespace')
    run.mkdir(parents=True, exist_ok=True)
    with (run / 'ledger_scoring.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        once = ('outcome_ledger.json', 'prediction_lock.json', 'completion.json', 'scoring_attempt.json',
                'per_case_scores.json', 'scores.json', 'scoring_completion.json')
        require(not any((run / name).exists() for name in once), 'Successor seal or scoring already attempted; preserve once-only artifacts')
        require(all(sha(path) == expected for path, expected in files.items()), 'Raw outcome changed before exhaustive seal')
        provenance = {**identity, **extra, 'successor_job_id': os.environ.get('SLURM_JOB_ID'), 'at_pacific': stamp()}
        save(run / 'outcome_ledger.json', {**provenance, 'planned': len(inputs), 'cases': ledger,
             'all_original_case_slots_resolved': True, 'missing_raw_responses_are_explicit_invalid': True,
             'labels_loaded': False, 'role': 'complete_outcome_ledger_not_a_fabricated_model_response_set'})
        files[str(Path(boundary_path))], files[str(Path(closure_path))] = boundary_sha256, closure_sha256
        files[str(run / 'outcome_ledger.json')] = sha(run / 'outcome_ledger.json')
        save(run / 'prediction_lock.json', {**provenance, 'planned': len(inputs), 'files_sha256': files,
             'all_planned_outcome_slots_sealed': True, 'all_planned_terminal': True, 'labels_loaded': False,
             'outcome_ledger_sha256': sha(run / 'outcome_ledger.json')})
        complete = {**provenance, 'planned': len(inputs), 'terminal_outcome_slots': len(inputs),
                    'terminal': len(inputs), 'all_planned_terminal': True,
                    'all_planned_outcome_slots_sealed': True, 'responses_saved': sum(o is not None for o in outputs),
                    'ambiguous_prior_claims': sum(o is None for o in outputs),
                    'truncations': sum(o is not None and o.get('finish_reason') == 'length' for o in outputs),
                    'empty_or_missing_finals': sum(o is None or not (o.get('final') or '').strip() for o in outputs),
                    'all_original_case_denominators_preserved': True, 'biological_correctness_assessed': False,
                    'prediction_lock_sha256': sha(run / 'prediction_lock.json'),
                    'outcome_ledger_sha256': sha(run / 'outcome_ledger.json'),
                    'role': 'sealed_full_native_outcome_ledger_with_explicit_ambiguous_invalid_slots'}
        save(run / 'completion.json', complete)
        require(all(sha(path) == expected for path, expected in files.items()), 'Sealed raw outcome changed before scoring')
        save(run / 'scoring_attempt.json', {**provenance, 'prediction_lock_sha256': sha(run / 'prediction_lock.json'),
             'completion_sha256': sha(run / 'completion.json'), 'references_not_opened_before_attempt': True,
             'policy': 'One native all-case accuracy calculation; original raw responses unchanged and None for ambiguous prior claims.'})
        # This is the first and only read of reference bytes. Hash and parse the
        # same bytes, after the exhaustive ledger, prediction seal and claim.
        reference_bytes = raw(source['reference_path'])
        require(hashlib.sha256(reference_bytes).hexdigest() == source['reference_sha256'], 'Native reference bytes changed')
        references = [json.loads(line) for line in reference_bytes.splitlines()]
        require([r['case_id'] for r in references] == [r['case_id'] for r in inputs], 'Native reference/input order differs')
        targets = [r['target_binary' if task_id == 'P01' else 'target'] for r in references]
        metrics, predictions, correct = native.calculate(task_id, targets, outputs)
        scored = [{'case_id': row['case_id'], 'prediction': pred, 'target': target, 'correct': good,
                   'status': output['status'] if output is not None else 'ambiguous_claim_invalid'}
                  for row, pred, target, good, output in zip(inputs, predictions, targets, correct, outputs)]
        save(run / 'per_case_scores.json', scored)
        result = {**identity, **extra, 'protocol_variant': condition['protocol_variant'], 'planned': len(inputs),
                  'metrics': metrics, 'delivery': complete, 'native_parser_and_metric_unchanged': True,
                  'prediction_lock_sha256': sha(run / 'prediction_lock.json'), 'outcome_ledger_sha256': sha(run / 'outcome_ledger.json'),
                  'same_scientific_condition_as_original': True, 'explicit_ambiguous_invalid_slots': sum(o is None for o in outputs),
                  'original_raw_artifacts_unchanged': True, 'biological_correctness_assessed': True,
                  'explanation_support_assessed': False, 'public_pretraining_exposure': 'unknown',
                  'comparison': 'Unchanged matched16K scientific condition; only original unclaimed cases continued. All native case slots retained.'}
        save(run / 'scores.json', result)
        save(run / 'scoring_completion.json', {'at_pacific': stamp(), 'scoring_terminal': True,
             'scores_sha256': sha(run / 'scores.json'), 'per_case_scores_sha256': sha(run / 'per_case_scores.json'),
             'prediction_lock_sha256': sha(run / 'prediction_lock.json'), 'outcome_ledger_sha256': sha(run / 'outcome_ledger.json')})
        return result
