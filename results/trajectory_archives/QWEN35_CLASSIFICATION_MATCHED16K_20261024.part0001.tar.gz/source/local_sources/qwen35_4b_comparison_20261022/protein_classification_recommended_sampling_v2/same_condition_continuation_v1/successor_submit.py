"""One claim/model only after exact original termination and fresh<=8GPU audit."""
from pathlib import Path
import fcntl
import re
import subprocess

import continuation_controls as C
from successor_driver import arguments, validate_args


def submit(args):
    plan, science, boundary, closure = validate_args(args)
    runtime = Path(plan['models'][args.model_key]['successor_runtime'])
    runtime.mkdir(parents=True, exist_ok=True)
    with (C.ROOT / '.local/evaluation_GPU_submission.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        C.require(not (runtime / 'submission_attempt.json').exists()
                  and not (runtime / 'worker_started.json').exists(),
                  'One successor already submitted/uncertain; never replay sbatch or create a further chain')
        with C.terminal_original_locks(plan, science, boundary, closure, args.model_key) as proof:
            if all(task['task_state'] == 'already_scored_preserve_without_rescoring' for task in boundary['tasks'].values()):
                C.save(runtime / 'original_model_already_complete.json', {'at_pacific': C.stamp(),
                    'model_key': args.model_key, 'boundary_sha256': args.boundary_sha256,
                    'no_successor_allocation_needed': True, 'model_calls': 0})
                print('already_complete_no_allocation'); return 0
            priority = C.priority(plan)
            if not priority['passed'] or args.model_key not in priority.get('released_model_keys', []):
                print('priority_only_wait'); return 75
            try:
                inventory = C.audit(plan, additional=1)
            except ValueError as error:
                if str(error) == 'Evaluation project GPU requests exceed eight':
                    print('capacity_only_wait'); return 75
                raise
            if inventory.get('capacity_available') is not True:
                print('capacity_only_wait'); return 75
            C.require(type(inventory.get('project_requested_GPUs')) is int
                      and inventory['project_requested_GPUs'] + 1 <= 8,
                      'Strict conservative resource ceiling must hold before scheduler claim')
            C.save(runtime / 'private_gpu_audit_submission.json', inventory)
            C.save(runtime / 'priority_observation.json', priority)
            C.save(runtime / 'submission_fresh_predecessor_proof.json', proof)
            command = ['sbatch', '--parsable', str(C.HERE / 'successor.sbatch')]
            for name in ('plan', 'grant', 'boundary', 'closure'):
                command.extend(['--' + name, str(getattr(args, name).resolve()),
                                '--' + name + '-sha256', getattr(args, name + '_sha256')])
            command.extend(['--model-key', args.model_key])
            C.save(runtime / 'submission_attempt.json', {'at_pacific': C.stamp(), 'command': command,
                'operational_plan_sha256': args.plan_sha256, 'scientific_plan_sha256': C.SCIENCE_SHA,
                'model_key': args.model_key, 'binding_sha256': args.grant_sha256,
                'boundary_sha256': args.boundary_sha256, 'closure_sha256': args.closure_sha256,
                'one_successor_only': True, 'no_retry_on_uncertain_sbatch': True})
        # The immutable once-only claim is now durable under original locks.
        # Release them BEFORE sbatch: an immediately started worker must be
        # able to take its own fresh predecessor locks. The global GPU lock
        # remains held through scheduler submission and receipt persistence.
        result = subprocess.run(command, capture_output=True, text=True, timeout=30)
        C.save(runtime / 'scheduler_outcome.json', {'at_pacific': C.stamp(), 'returncode': result.returncode,
            'stdout': result.stdout, 'stderr': result.stderr})
        C.require(result.returncode == 0 and re.fullmatch(r'[0-9]+(?:;[A-Za-z0-9_.-]+)?\s*', result.stdout),
                  'Failed or uncertain scheduler submission; preserve claim and never retry')
        job = result.stdout.strip().split(';')[0]
        C.save(runtime / 'submission.json', {'at_pacific': C.stamp(), 'job_id': job,
            'model_key': args.model_key, 'operational_plan_sha256': args.plan_sha256,
            'scientific_plan_sha256': C.SCIENCE_SHA, 'binding_sha256': args.grant_sha256,
            'boundary_sha256': args.boundary_sha256, 'closure_sha256': args.closure_sha256,
            'requested_gpus': 1, 'walltime_hours': 72, 'model_calls_by_submitter': 0})
        print(job); return 0


if __name__ == '__main__': raise SystemExit(submit(arguments()))
