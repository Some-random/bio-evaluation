"""Exact original scheduler identity and exclusive output-lock boundary proofs."""
from contextlib import contextmanager, ExitStack
from pathlib import Path
import fcntl
import json
import os
import re
import stat
import subprocess

HERE=Path(__file__).resolve().parent
LANE=HERE.parent
ROOT=LANE.parents[2]
SCIENCE_SHA='ee450e89141e2390f3a93f5ed2e85bd9e3ef81778ddde0301a9c3478ed909cec'
GRANT_SHA='98208a9809872190fc3494c8361ed20880989ee45b5d883f3e7f0c65c52e3bf7'
EXPECTED={
    'base':{'job_id':'247043','start_time':'2026-10-22T12:44:30','node':'ampere2'},
    'posttrained':{'job_id':'247044','start_time':'2026-10-22T12:45:30','node':'ampere8'}}
ACTIVE={'PENDING','RUNNING','CONFIGURING','COMPLETING','SUSPENDED','RESIZING'}
TERMINAL={'COMPLETED','FAILED','TIMEOUT','CANCELLED','NODE_FAIL','OUT_OF_MEMORY','BOOT_FAIL','DEADLINE','PREEMPTED'}


def fields(raw):return dict(re.findall(r'(?:^|\s)([A-Za-z][A-Za-z0-9]*)=(\S*)',raw))


def verify_identity(raw,model,require_terminal=False):
    if model not in EXPECTED:raise ValueError('Unknown original matched model')
    expected=EXPECTED[model];row=fields(raw)
    if(row.get('JobId')!=expected['job_id'] or row.get('UserId')!='dongweij(26129)'
       or row.get('StartTime')!=expected['start_time'] or row.get('Command')!=str(LANE/'worker.sbatch')
       or row.get('WorkDir')!=str(ROOT) or row.get('Restarts')!='0' or row.get('NumNodes')!='1'
       or row.get('NodeList')!=expected['node'] or 'gres/gpu=1' not in row.get('AllocTRES','').split(',')
       or '--plan-sha256 '+SCIENCE_SHA not in raw or '--grant-sha256 '+GRANT_SHA not in raw
       or '--model-key '+model not in raw):
        raise ValueError('Original job owner/start/command/resources/scientific identity changed')
    state=row.get('JobState')
    if state not in ACTIVE|TERMINAL:raise ValueError('Unknown original scheduler state')
    if require_terminal and state not in TERMINAL:raise ValueError('Original predecessor is not terminal')
    return row


def observe(model):
    result=subprocess.run(['scontrol','show','job',EXPECTED[model]['job_id'],'-o'],capture_output=True,text=True,check=True,timeout=30)
    return {'fields':verify_identity(result.stdout,model),'raw_scontrol':result.stdout}


def verify_terminal(job,model,operational_plan=None,sealed_closure=None):
    if job!=EXPECTED.get(model,{}).get('job_id'):raise ValueError('Wrong exact predecessor job')
    try:
        observed=observe(model)
    except subprocess.CalledProcessError as error:
        # Missing live scheduler state alone proves nothing. A caller may use
        # its already hash-verified immutable exact terminal closure, but fresh
        # accounting below must independently match it on every call.
        if('Invalid job id specified' not in (error.stderr or '') or not isinstance(sealed_closure,dict)):
            raise
        prior=sealed_closure.get('terminal_scheduler',{})
        if(prior.get('terminal')is not True or not isinstance(prior.get('raw_scontrol'),str)):
            raise ValueError('Missing exact sealed terminal identity for purged original')
        observed={'fields':verify_identity(prior['raw_scontrol'],model,True),
            'raw_scontrol':prior['raw_scontrol'],'live_scontrol_purged':True,
            'identity_source':'hash_verified_predecessor_terminal_closure_plus_fresh_sacct'}
    row=verify_identity(observed['raw_scontrol'],model,True)
    result=subprocess.run(['sacct','-j',job,'--parsable2','-n','--format=JobIDRaw,State,ExitCode,Start,End,AllocTRES'],capture_output=True,text=True,check=True,timeout=30)
    matches=[line.split('|')for line in result.stdout.splitlines()if line.startswith(job+'|')]
    if len(matches)!=1:raise ValueError('Exact original terminal accounting row missing or ambiguous')
    account=matches[0];state=account[1].split()[0].split('+')[0]
    if(state!=row['JobState'] or state not in TERMINAL or account[3]!=EXPECTED[model]['start_time']
       or account[4]!=row.get('EndTime') or 'gres/gpu=1' not in account[5].split(',')):
        raise ValueError('Independent terminal accounting does not match exact original job')
    return {**observed,'raw_sacct':result.stdout,'accounting_row':account,
            'terminal':True,'terminal_state':state,'no_new_requests_by_operation':True}


def lock_identity(path):
    path=Path(path)
    if path.is_symlink():raise ValueError('Symlink original output lock forbidden')
    before=path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_uid!=26129:
        raise ValueError('Original output lock identity/owner changed')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    opened=os.fstat(fd)
    if (opened.st_dev,opened.st_ino)!=(before.st_dev,before.st_ino):
        os.close(fd);raise ValueError('Original lock replaced while opening')
    try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BaseException:os.close(fd);raise
    return fd,{'path':str(path),'dev':opened.st_dev,'ino':opened.st_ino,'uid':opened.st_uid,
               'mode':stat.S_IMODE(opened.st_mode),'free_lock_acquired':True}


@contextmanager
def locked_original_outputs(plan,model):
    """Caller must prove terminal first; retain all original locks through seal."""
    source=plan
    if 'conditions' not in source:source=json.loads((LANE/'plan.json').read_text())
    conditions=[c for c in source['conditions']if c['model_key']==model]
    if [c['task_id']for c in conditions]!=['P03','P01']:raise ValueError('Original full sequential tasks changed')
    runtime=Path(source['models'][model]['runtime'])
    if runtime!=LANE/'runtime'/model:raise ValueError('Original model runtime changed')
    paths=[runtime/'worker.lock']+[Path(c['runtime'])/'run.lock' for c in conditions]
    receipts=[]
    with ExitStack()as stack:
        for index,path in enumerate(paths):
            if not path.exists():
                folder=path.parent
                if index==0 or (folder/'cases').exists()or(folder/'started.json').exists():
                    raise ValueError('Missing original lock for an attempted task')
                receipts.append({'path':str(path),'absent_unstarted_task':True});continue
            fd,proof=lock_identity(path);stack.callback(os.close,fd);receipts.append(proof)
        yield receipts
