"""Pinned unchanged-condition successor controls. No labels or inference here."""
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import fcntl
import hashlib
import importlib.util
import json
import os
import stat

HERE = Path(__file__).resolve().parent
LANE = HERE.parent
ROOT = HERE.parents[3]
SCIENCE_SHA = 'ee450e89141e2390f3a93f5ed2e85bd9e3ef81778ddde0301a9c3478ed909cec'
ORIGINAL_GRANT_SHA = '98208a9809872190fc3494c8361ed20880989ee45b5d883f3e7f0c65c52e3bf7'
ADOPTION_SHA = 'bbfe8f7ee60b6a2d8db078b5fe6ab9fe865a3d97ce405671673d25157d681ef2'
CONDITION = 'QWEN35_CLASSIFICATION_AUTHOR_GENERAL_THINKING_RAW16K_V2_SAME_CONDITION_CONTINUATION1'


def stamp():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def require(value, message):
    if not value: raise ValueError(message)


def regular(path):
    path = Path(path)
    require(path.is_absolute() and path == path.resolve(), 'Exact nonsymlink absolute artifact required')
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'Regular pinned artifact required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as handle:
        opened = os.fstat(handle.fileno())
        require((opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino), 'Artifact replaced while opening')
        raw = handle.read()
        after = os.fstat(handle.fileno())
    identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(identity(before) == identity(after) == identity(path.lstat()), 'Artifact changed while reading')
    return raw


def sha(path): return hashlib.sha256(regular(path)).hexdigest()
def read(path): return json.loads(regular(path))
def digest(value): return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def module(path, name):
    regular(path)
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def sync_parent(path):
    fd = os.open(str(Path(path).parent), os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)


def save(path, value):
    path = Path(path)
    with path.open('x') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write('\n'); handle.flush(); os.fsync(handle.fileno())
    sync_parent(path)


def update(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.' + str(os.getpid()) + '.tmp')
    save(tmp, value)
    tmp.replace(path); sync_parent(path)


def load_plan(path, expected):
    require(Path(path).resolve() == HERE / 'operational_plan.json' and sha(path) == expected,
            'Exact independently reviewed successor plan required')
    plan = read(path)
    require(plan.get('condition_id') == CONDITION and plan.get('batch_size') == 16
            and plan.get('walltime_hours') == 72 and plan.get('max_successors_per_model') == 1
            and plan.get('max_GPUs') == 1 and plan.get('task_order') == ['P03', 'P01']
            and plan.get('no_original_mode_restoration') is True,
            'Bounded unchanged successor scope differs')
    require(plan['root_adoption']['sha256'] == ADOPTION_SHA and sha(plan['root_adoption']['path']) == ADOPTION_SHA,
            'Exact root operational continuation adoption required')
    adoption = read(plan['root_adoption']['path'])
    require(adoption.get('issuer') == '/root' and adoption.get('scope_adopted') is True
            and adoption.get('condition_id') == CONDITION, 'Root adoption does not admit this successor')
    require(plan['scientific_plan']['sha256'] == SCIENCE_SHA and sha(plan['scientific_plan']['path']) == SCIENCE_SHA
            and plan['scientific_grant']['sha256'] == ORIGINAL_GRANT_SHA
            and sha(plan['scientific_grant']['path']) == ORIGINAL_GRANT_SHA,
            'Original exact scientific plan/grant changed')
    science = read(plan['scientific_plan']['path'])
    references = {task['reference_path'] for task in science['tasks']}
    require(not (references & set(plan['pins'])), 'Scorer-only reference files must not be opened by generation controls')
    for path, expected_sha in plan['pins'].items():
        require(sha(path) == expected_sha, 'Pinned successor source changed: ' + path)
    for path, expected_sha in science['pins'].items():
        if path not in references:
            require(sha(path) == expected_sha, 'Frozen original scientific source changed: ' + path)
    require(plan['generation'] == science['generation'] and plan['shared_contract'] == science['shared_contract']
            and plan['shared_runtime'] == science['shared_runtime'] and science['batch_size'] == 16,
            'Successor must preserve original generation, rendering, runtime and concurrency')
    for key in ('base', 'posttrained'):
        row, original = plan['models'][key], science['models'][key]
        require(row['predecessor_job_id'] == adoption['exact_predecessors'][key]['job_id']
                and row['predecessor_start_time'] == adoption['exact_predecessors'][key]['original_start_time']
                and row['original_runtime'] == original['runtime']
                and row['successor_runtime'] == str(HERE / 'runtime' / key)
                and row['boundary_path'] == str(HERE / 'boundaries' / key / 'boundary.json')
                and row['closure_path'] == str(HERE / 'boundaries' / key / 'closure.json'),
                'Exact predecessor/model/boundary/output namespace differs')
    return plan


def validate(plan_path, expected, grant_path, grant_sha, model_key,
             boundary_path, boundary_sha, closure_path, closure_sha):
    plan = load_plan(plan_path, expected)
    require(model_key in ('base', 'posttrained'), 'Unknown matched model')
    model = plan['models'][model_key]
    require(str(Path(boundary_path).resolve()) == model['boundary_path'] and sha(boundary_path) == boundary_sha
            and str(Path(closure_path).resolve()) == model['closure_path'] and sha(closure_path) == closure_sha,
            'Exact model terminal boundary and closure artifacts required')
    boundary, closure = read(boundary_path), read(closure_path)
    require(boundary.get('model_key') == model_key and boundary.get('scientific_plan_sha256') == SCIENCE_SHA
            and boundary.get('predecessor_job_id') == model['predecessor_job_id']
            and boundary.get('full_denominator') == 4772 and set(boundary.get('tasks', {})) == {'P03', 'P01'}
            and boundary['tasks']['P03']['planned'] == 2773 and boundary['tasks']['P01']['planned'] == 1999,
            'Original complete native denominator or boundary identity changed')
    require(closure.get('model_key') == model_key and closure.get('predecessor_job_id') == model['predecessor_job_id']
            and closure.get('operational_plan_sha256') == expected
            and closure.get('scientific_plan_sha256') == SCIENCE_SHA
            and closure.get('boundary_sha256') == boundary_sha
            and closure.get('terminal_scheduler', {}).get('terminal') is True
            and isinstance(closure.get('original_output_locks'), list) and bool(closure['original_output_locks']),
            'Exact predecessor terminal and retained-lock closure missing')
    require(sha(grant_path) == grant_sha, 'Independent dynamic admission changed')
    binding = read(grant_path)
    require(binding.get('role') == 'mechanical_binding_under_independent_conditional_grant'
            and 'approved' not in binding and 'issuer' not in binding
            and binding.get('operational_plan_sha256') == expected
            and binding.get('model_key') == model_key
            and binding.get('predecessor_job_id') == model['predecessor_job_id']
            and binding.get('boundary') == {'path': model['boundary_path'], 'sha256': boundary_sha}
            and binding.get('closure') == {'path': model['closure_path'], 'sha256': closure_sha}
            and binding.get('drain_receipt_sha256') == closure.get('drain_receipt_sha256'),
            'Exact mechanical model/boundary/closure binding required; owner cannot issue peer approval')
    conditional = binding['conditional_grant']
    require(sha(conditional['path']) == conditional['sha256'], 'Original independent conditional grant changed')
    validate_conditional_grant(plan, expected, conditional['path'], conditional['sha256'])
    return plan, read(plan['scientific_plan']['path']), boundary, closure


def validate_conditional_grant(plan, expected, grant_path, grant_sha):
    """Independent static source admission, valid before a future boundary exists."""
    require(sha(grant_path) == grant_sha, 'Original independent conditional grant changed')
    grant = read(grant_path)
    require(grant.get('approved') is True and grant.get('issuer') in plan['independent_issuers']
            and grant.get('issuer') != plan['owner'] and grant.get('plan_sha256') == expected
            and grant.get('condition_id') == CONDITION
            and grant.get('same_scientific_condition') is True and grant.get('one_successor_only') is True
            and grant.get('permit_mechanical_boundary_binding') is True
            and grant.get('model_predecessors') == {key: plan['models'][key]['predecessor_job_id']
                                                  for key in ('base', 'posttrained')},
            'Independent exact source-bound conditional successor grant required')
    require(sha(grant['independent_review_path']) == grant['independent_review_sha256'],
            'Independent successor review changed')
    review = read(grant['independent_review_path'])
    require(review.get('passed') is True and review.get('plan_sha256') == expected
            and review.get('reviewer') == grant['issuer'] and review.get('reviewer') != plan['owner'],
            'Exact runnable source review required')
    return grant


def fatal_output(output, scientific_plan):
    if output.get('status') not in {'completed', 'response_error'}:
        return True
    classifier = module(Path(scientific_plan['models']['base']['runtime']).parents[1] / 'driver.py', 'continuation_original_refusal')
    final = output.get('final_text', output.get('final', '')) or ''
    raw = output.get('raw_text', '') or ''
    return (output.get('finish_reason') not in {'stop', 'length'}
            or bool(output.get('refusal')) or classifier.classify_refusal(final)['refusal']
            or bool(output.get('extra_assistant_tail'))
            or any(marker in raw for marker in ('<tool_call>', '<|im_start|>')))


def verify_boundary_unchanged(plan, science, boundary, closure, model_key):
    """Caller holds actual original locks and has fresh independent terminal proof."""
    boundary_module = module(plan['boundary_source']['path'], 'continuation_exact_boundary_recheck')
    fresh = boundary_module.freeze_model(science, SCIENCE_SHA, model_key, plan['models'][model_key]['predecessor_job_id'])
    expected = {key: value for key, value in boundary.items() if key != 'at_pacific'}
    require({key: value for key, value in fresh.items() if key != 'at_pacific'} == expected,
            'Original terminal case boundary changed; never reinterpret a new claim as eligible')
    for task in boundary['tasks'].values():
        for case in task['cases']:
            if case['outcome_state'] == 'inherited_saved_response':
                output = read(case['response']['path'])
                require(not fatal_output(output, science), 'Fatal inherited delivery remains held even without a stopped.json')


@contextmanager
def terminal_original_locks(plan, science, boundary, closure, model_key):
    scheduler = module(plan['scheduler_source']['path'], 'continuation_exact_predecessor_scheduler')
    terminal = scheduler.verify_terminal(plan['models'][model_key]['predecessor_job_id'], model_key, plan,
                                         sealed_closure=closure)
    with scheduler.locked_original_outputs(science, model_key) as locks:
        require(locks == closure['original_output_locks'], 'Original lock identities changed since exact terminal boundary')
        # Scheduler state may evolve its EndTime accounting but cannot change
        # terminal identity. The exact pinned source independently checks both.
        require(terminal['terminal'] is True, 'Fresh actual predecessor is not terminal')
        controller = module(plan['controller_source']['path'], 'continuation_reviewed_terminal_failure_policy')
        drain, drain_sha = controller.drain_record(model_key)
        require(drain_sha == closure.get('drain_receipt_sha256'), 'Recorded operational drain changed since closure')
        if drain is not None:
            drain_path = HERE / 'drains' / model_key / 'applied.json'
            require(closure.get('drain_receipt_path') == str(drain_path), 'Different owned drain receipt scope')
            intent_path = drain_path.parent / 'intent.json'
            require(sha(intent_path) == drain.get('intent_sha256'), 'Original owned drain intent changed')
            intent = read(intent_path)
            require(intent.get('model_key') == model_key
                    and intent.get('predecessor_job_id') == plan['models'][model_key]['predecessor_job_id']
                    and intent.get('operational_plan_sha256') == sha(HERE / 'operational_plan.json'),
                    'Drain intent belongs to a different model, predecessor or operational plan')
            original = Path(plan['models'][model_key]['original_runtime'])
            allowed = {str(original), str(original / 'P03/cases'), str(original / 'P01/cases')}
            require(all(row.get('path') in allowed and row.get('drain_mode') == row.get('original_mode', 0) & ~0o222
                        for row in drain['restrictions']), 'Drain contains foreign paths or changed restrictions')
        else:
            require(closure.get('drain_receipt_path') is None, 'Unverified drain path without actual applied record')
        controller.predecessor_terminal_allowed(terminal, drain, plan['models'][model_key]['original_runtime'])
        verify_boundary_unchanged(plan, science, boundary, closure, model_key)
        yield {'terminal_scheduler': terminal, 'original_output_locks': locks}


def audit(plan, own=False, additional=0):
    helper = module(plan['gpu_audit']['path'], 'continuation_conservative_GPU_audit')
    observed = helper.capacity_audit(additional=additional, override=False, require_own_job=own,
        additional_root_proofs=tuple(plan.get('additional_root_proofs', [])),
        additional_proof_binding=plan.get('additional_proof_binding'))
    count = observed.get('project_requested_GPUs')
    require(type(count) is int and count >= 0 and type(observed.get('capacity_available')) is bool
            and observed.get('project_requested_GPUs_with_addition') == count + additional
            and observed['capacity_available'] == (count + additional <= 8),
            'Resource adapter returned malformed or inconsistent conservative project capacity')
    if own:
        require(observed['capacity_available'] and count + additional <= 8
                and observed.get('own_allocation_verified') is True,
                'Actual own startup capacity/identity not verified within eightGPUs')
        row = next(value for value in observed['jobs'] if value['job_id'] == os.environ['SLURM_JOB_ID'])
        require(row['command'] == str(HERE / 'successor.sbatch') and row['workdir'] == str(ROOT),
                'Own successor allocation identity differs')
    return observed


def priority(plan):
    record = plan['priority_record']
    require(sha(record['path']) == record['sha256'], 'Root LiveProteinBench/LABBench2 priority record changed')
    release_path = Path(plan['priority_release_path'])
    if not release_path.exists():
        return {'passed': False, 'reason': 'LiveProteinBench_LABBench2_capacity_reserved_no_exact_release', 'model_calls': 0}
    release = read(release_path)
    require(release.get('issuer') == '/root' and release.get('approved') is True
            and release.get('role') == 'exact_priority_release_for_same_condition_classification_successor'
            and release.get('priority_record_sha256') == record['sha256']
            and release.get('operational_plan_sha256') == sha(HERE / 'operational_plan.json')
            and release.get('condition_id') == CONDITION
            and isinstance(release.get('model_keys'), list) and bool(release['model_keys'])
            and len(set(release['model_keys'])) == len(release['model_keys'])
            and set(release['model_keys']) <= {'base', 'posttrained'}
            and release.get('acknowledges_LPB_LABBench2_generation_judge_delivery_prerequisites') is True,
            'Only exact root priority release may admit a lower-priority successor allocation')
    evidence = release.get('prerequisite_evidence')
    require(isinstance(evidence, list) and bool(evidence)
            and {row.get('suite') for row in evidence} == {'LiveProteinBench', 'LABBench2_BASIC_closed_book_text'},
            'Priority release must bind both suites generation/judge/delivery prerequisite evidence')
    for row in evidence:
        require(Path(row['path']).is_relative_to(ROOT) and sha(row['path']) == row['sha256'],
                'Root priority prerequisite evidence changed')
    helper = module(plan['queue_priority_helper']['path'], 'continuation_positive_predecessor_priority')
    observed = helper.verify_priority(plan)
    observed.update(priority_release_path=str(release_path), priority_release_sha256=sha(release_path),
                    released_model_keys=release['model_keys'])
    return observed
