"""Bounded CPU checkpoint, exact terminal boundary and once-only successor service.

This service records facts under an independent conditional admission. It never
issues peer approval, changes science, replays attempted cases or chains jobs.
"""
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import argparse
import fcntl
import json
import os
import subprocess
import sys
import time

import continuation_controls as C
import boundary as B
import drain as D
import scheduler as S

HERE=Path(__file__).resolve().parent


def state(value):
    C.update(HERE/'controller_status.json',{'at_pacific':C.stamp(),'pid':os.getpid(),
        'role':'bounded_original_drain_terminal_boundary_and_one_successor_controller_not_model_counts',
        'model_calls_by_controller':0,**value})


def predecessor_terminal_allowed(terminal,drain_receipt,runtime):
    state=terminal['terminal_state']
    if state=='COMPLETED':return True
    if not drain_receipt or drain_receipt.get('applied')is not True:
        raise ValueError('Unexpected original failure without adopted request-creation drain remains held')
    if state=='FAILED':
        path=Path(runtime)/'generation.log'
        # Frozen worker/driver source proves a next-case/task mkdir is the
        # permission boundary. No model output is printed or inspected here.
        with path.open('rb')as handle:
            handle.seek(max(0,path.stat().st_size-65536));tail=handle.read().decode(errors='replace')
        if 'PermissionError'not in tail or str(Path(runtime))not in tail:
            raise ValueError('Original failure does not reconcile with the owned permission drain')
        return True
    if state=='TIMEOUT':
        # A scheduler deadline may leave a prior claim ambiguous. Root scope
        # permits retaining such a slot as invalid, never replaying it. Fatal
        # response/provenance checks still run exhaustively before admission.
        return True
    raise ValueError('Unexpected original terminal failure remains held: '+state)


def drain_record(model):
    folder=HERE/'drains'/model;applied=folder/'applied.json'
    if applied.exists():
        value=C.read(applied)
        C.require(value.get('applied')is True and value.get('model_key')==model
            and value.get('predecessor_job_id')==S.EXPECTED[model]['job_id'],
            'Drain receipt identity mismatch')
        for row in value['restrictions']:
            p=Path(row['path']);observed=p.stat()
            C.require(not p.is_symlink()and (observed.st_dev,observed.st_ino,observed.st_uid)==(row['dev'],row['ino'],row['uid'])
                and observed.st_mode&0o777==row['drain_mode']and not observed.st_mode&0o222,
                'Original request creation restriction changed')
        return value,C.sha(applied)
    if(folder/'intent.json').exists():raise ValueError('Incomplete or ambiguous drain intent; no automatic mutation replay')
    return None,None


def seal_boundary(plan,plan_sha,conditional_path,conditional_sha,model):
    info=plan['models'][model];folder=Path(info['boundary_path']).parent
    folder.mkdir(parents=True,exist_ok=True)
    paths=[Path(info['boundary_path']),Path(info['closure_path']),folder/'binding.json']
    if any(path.exists()for path in paths):
        C.require(all(path.exists()for path in paths),'Partial terminal boundary/binding exists; no automatic overwrite')
        C.validate(HERE/'operational_plan.json',plan_sha,paths[2],C.sha(paths[2]),model,
            paths[0],C.sha(paths[0]),paths[1],C.sha(paths[1]))
        return paths
    terminal=S.verify_terminal(info['predecessor_job_id'],model,plan)
    applied,applied_sha=drain_record(model)
    predecessor_terminal_allowed(terminal,applied,info['original_runtime'])
    science=C.read(plan['scientific_plan']['path'])
    with S.locked_original_outputs(science,model)as locks:
        # Re-observe terminal inside locks and immediately freeze every original
        # planned slot. B rejects hidden fatal outcomes even without stopfiles.
        terminal=S.verify_terminal(info['predecessor_job_id'],model,plan)
        value=B.freeze_model(science,C.SCIENCE_SHA,model,info['predecessor_job_id'])
        C.save(paths[0],value)
        closure={'at_pacific':C.stamp(),'role':'exact_predecessor_terminal_and_output_lock_closure',
            'model_key':model,'predecessor_job_id':info['predecessor_job_id'],
            'operational_plan_sha256':plan_sha,'scientific_plan_sha256':C.SCIENCE_SHA,
            'boundary_sha256':C.sha(paths[0]),'terminal_scheduler':terminal,
            'original_output_locks':locks,'drain_receipt_sha256':applied_sha,
            'drain_receipt_path':str(HERE/'drains'/model/'applied.json')if applied else None,
            'prior_claims_never_replayed':True,'reference_values_parsed':False,
            'new_model_calls':0,'new_GPU_allocations':0}
        C.save(paths[1],closure)
        binding={'at_pacific':C.stamp(),'role':'mechanical_binding_under_independent_conditional_grant',
            'operational_plan_sha256':plan_sha,'model_key':model,
            'predecessor_job_id':info['predecessor_job_id'],
            'boundary':{'path':str(paths[0]),'sha256':C.sha(paths[0])},
            'closure':{'path':str(paths[1]),'sha256':C.sha(paths[1])},
            'conditional_grant':{'path':str(conditional_path.resolve()),'sha256':conditional_sha},
            'drain_receipt_sha256':applied_sha,'new_model_calls':0,'new_GPU_allocations':0}
        C.save(paths[2],binding)
    return paths


def actual_submission(runtime,plan_sha,binding_sha):
    path=runtime/'submission.json'
    if path.exists():
        value=C.read(path)
        C.require(value.get('operational_plan_sha256')==plan_sha and value.get('binding_sha256')==binding_sha
            and value.get('requested_gpus')==1 and value.get('walltime_hours')==72
            and isinstance(value.get('job_id'),str)and value['job_id'].isdigit(),
            'Actual successor submission identity mismatch')
        return value
    C.require(not(runtime/'submission_attempt.json').exists()and not(runtime/'worker_started.json').exists(),
        'Actual or uncertain successor attempt exists without receipt; never repeat')
    return None


def step_model(plan,plan_sha,conditional_path,conditional_sha,model):
    info=plan['models'][model];runtime=Path(info['successor_runtime'])
    # The original remains authoritative until it is actually terminal.
    try:observed=S.observe(model)
    except subprocess.CalledProcessError as error:
        closure_path=Path(info['closure_path'])
        if 'Invalid job id specified' not in (error.stderr or '')or not closure_path.exists():raise
        observed=S.verify_terminal(info['predecessor_job_id'],model,plan,sealed_closure=C.read(closure_path))
    if observed['fields']['JobState']in S.ACTIVE:
        applied,_=drain_record(model)
        if observed['fields']['JobState']=='RUNNING'and D.deadline_due(observed['fields'])and not applied:
            applied=D.apply_model_drain(plan,model)
        stage=('original_tasks_scored_awaiting_terminal'if applied and applied.get('not_needed') else
            'original_running_request_creation_drained'if applied and applied.get('applied') else 'original_running_unchanged')
        return {'stage':stage,
            'predecessor_job_id':info['predecessor_job_id'],'live_end_time':observed['fields'].get('EndTime'),
            'successor_submitted':False,'direct_original_progress':D.observed_progress(info['original_runtime'])}
    paths=seal_boundary(plan,plan_sha,conditional_path,conditional_sha,model)
    boundary_path,closure_path,binding_path=paths
    binding_sha=C.sha(binding_path);runtime.mkdir(parents=True,exist_ok=True)
    submission=actual_submission(runtime,plan_sha,binding_sha)
    if submission is None and (runtime/'original_model_already_complete.json').exists():
        value=C.read(runtime/'original_model_already_complete.json')
        C.require(value.get('model_key')==model and value.get('boundary_sha256')==C.sha(boundary_path)
            and value.get('no_successor_allocation_needed')is True,'Prior no-allocation completion identity mismatch')
        return {'stage':'original_completed_scored_no_successor_needed','complete':True,
            'boundary_sha256':C.sha(boundary_path),'successor_submitted':False}
    if submission is None:
        command=[sys.executable,str(HERE/'successor_submit.py')]
        values={'plan':HERE/'operational_plan.json','grant':binding_path,'boundary':boundary_path,'closure':closure_path}
        hashes={'plan':plan_sha,'grant':binding_sha,'boundary':C.sha(boundary_path),'closure':C.sha(closure_path)}
        for name,path in values.items():command+=['--'+name,str(path),'--'+name+'-sha256',hashes[name]]
        command+=['--model-key',model]
        result=subprocess.run(command,capture_output=True,text=True,timeout=180)
        submission=actual_submission(runtime,plan_sha,binding_sha)
        if result.returncode==75 and submission is None and result.stdout.strip()in{'priority_only_wait','capacity_only_wait'}:
            return {'stage':result.stdout.strip(),'predecessor_job_id':info['predecessor_job_id'],
                'boundary_sha256':C.sha(boundary_path),'successor_submitted':False}
        C.require(result.returncode==0,'Exact once-only successor submitter stopped: '+result.stderr[-2000:])
        if(runtime/'original_model_already_complete.json').exists():
            return {'stage':'original_completed_scored_no_successor_needed','complete':True,
                'boundary_sha256':C.sha(boundary_path),'successor_submitted':False}
        C.require(submission is not None,'No actual scheduler receipt; preserve uncertainty without retry')
    job=submission['job_id']
    queue=subprocess.run(['squeue','-h','-j',job,'-o','%i|%T|%N|%R'],capture_output=True,text=True,check=True,timeout=30)
    row={'stage':'observing_actual_once_only_successor','job_id':job,'predecessor_job_id':info['predecessor_job_id'],
        'successor_submitted':True,'scheduler_observation':queue.stdout.strip(),'tasks':{}}
    for task in ('P03','P01'):
        folder=runtime/task;entry={}
        for name in ('progress.json','completion.json','scores.json','scoring_completion.json'):
            path=folder/name
            if path.exists():entry[name]={'path':str(path),'sha256':C.sha(path)}
        row['tasks'][task]=entry or {'progress':'unknown; missing evidence does not mean zero attempts'}
    if not queue.stdout.strip():
        account=subprocess.run(['sacct','-j',job,'--parsable2','-n','--format=JobIDRaw,State,ExitCode'],capture_output=True,text=True,check=True,timeout=30)
        terminal=next((line.split('|')for line in account.stdout.splitlines()if line.startswith(job+'|')),None)
        if terminal and terminal[1].split()[0].split('+')[0]not in S.ACTIVE:
            worker_terminal=runtime/'worker_terminal.json'
            C.require(worker_terminal.exists(),'Successor terminal without complete worker receipt; no further chain')
            done=C.read(worker_terminal)
            C.require(done.get('completed')is True and done.get('model_key')==model
                and done.get('job_id')==job and done.get('operational_plan_sha256')==plan_sha,
                'Successor failed/incomplete or wrong identity; no retry or automatic further successor')
            model_completion=runtime/'model_completed.json';complete=C.read(model_completion)
            C.require(done.get('model_completion_sha256')==C.sha(model_completion)
                and complete.get('job_id')==job and complete.get('model_key')==model
                and complete.get('operational_plan_sha256')==plan_sha
                and complete.get('scientific_plan_sha256')==C.SCIENCE_SHA
                and complete.get('boundary_sha256')==C.sha(boundary_path)
                and complete.get('closure_sha256')==C.sha(closure_path)
                and complete.get('full_native_denominator')==4772
                and complete.get('all_original_and_successor_tasks_scored')is True
                and set(complete.get('task_results',{}))=={'P03','P01'},
                'Successor terminal lacks exact whole-denominator score completion seal')
            row.update(stage='successor_completed_scored_publication_pending',complete=True,
                worker_terminal_sha256=C.sha(worker_terminal),scheduler_terminal=terminal,
                next_action='Verify exact whole-model task scores and source/outcome archives, then independent narrow publication review.')
    return row


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--plan-sha256',required=True)
    parser.add_argument('--conditional-grant',type=Path,required=True);parser.add_argument('--conditional-grant-sha256',required=True)
    args=parser.parse_args();plan=C.load_plan(args.plan,args.plan_sha256)
    C.validate_conditional_grant(plan,args.plan_sha256,args.conditional_grant,args.conditional_grant_sha256)
    with(HERE/'controller.lock').open('a')as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        deadline=time.monotonic()+7*24*3600
        held={};finished={}
        while time.monotonic()<deadline:
            plan=C.load_plan(args.plan,args.plan_sha256)
            C.validate_conditional_grant(plan,args.plan_sha256,args.conditional_grant,args.conditional_grant_sha256)
            models={}
            for model in ('base','posttrained'):
                if model in held:models[model]=held[model];continue
                if model in finished:models[model]=finished[model];continue
                try:
                    models[model]=step_model(plan,args.plan_sha256,args.conditional_grant,args.conditional_grant_sha256,model)
                    if models[model].get('complete'):finished[model]=models[model]
                except Exception as error:
                    held[model]={'stage':'held_for_exact_review_no_retry_or_new_condition','error_type':type(error).__name__,'error':str(error)[:3000]}
                    models[model]=held[model]
            state({'stage':'all_models_terminal_or_held'if len(held)+len(finished)==2 else 'watching_originals_or_single_successors',
                'operational_plan_sha256':args.plan_sha256,'models':models,'no_automatic_further_chain':True})
            if len(held)+len(finished)==2:return
            time.sleep(60)
        state({'stage':'bounded_controller_expired_no_new_mutations_or_submissions','models_held':held,'models_finished':finished})


if __name__=='__main__':
    try:main()
    except Exception as error:
        state({'stage':'controller_stopped_for_review','error_type':type(error).__name__,'error':str(error)[:3000]});raise
