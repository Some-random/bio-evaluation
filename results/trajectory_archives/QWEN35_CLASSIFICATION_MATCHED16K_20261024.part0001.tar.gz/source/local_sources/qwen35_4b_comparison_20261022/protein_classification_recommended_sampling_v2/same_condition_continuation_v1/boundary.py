"""Freeze exact inherited/ambiguous/unclaimed case states, without inference."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
from collections import Counter
import hashlib
import json
import importlib.util
from functools import lru_cache

HERE=Path(__file__).resolve().parent
LANE=HERE.parent
SCIENCE_SHA='ee450e89141e2390f3a93f5ed2e85bd9e3ef81778ddde0301a9c3478ed909cec'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_hashed(path):
    path=Path(path)
    if path.is_symlink() or not path.is_file():raise ValueError('Regular existing artifact required: '+str(path))
    raw=path.read_bytes();return json.loads(raw),hashlib.sha256(raw).hexdigest()


def stamp():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


@lru_cache(maxsize=1)
def scientific_helpers():
    common_path=LANE.parent/'recommended_sampling_v2/shared_runtime.py'
    contract_path=LANE.parent/'recommended_sampling_v2/shared_contract.json'
    if sha(common_path)!='997fb4c910620ca1db9589b6243ecebf0b030003ee346a2177829a65a19c8981':
        raise ValueError('Frozen common normalization source changed')
    if sha(LANE/'plan.json')!=SCIENCE_SHA:raise ValueError('Frozen original scientific plan changed')
    science=json.loads((LANE/'plan.json').read_text())
    if sha(LANE/'driver.py')!=science['pins'][str(LANE/'driver.py')]:raise ValueError('Frozen original refusal classifier changed')
    def load(path,name):
        spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
    common=load(common_path,'continuation_boundary_original_common')
    contract=common.load_contract(contract_path,'00f42f82e48d9dbb4cebcf8c2a5c8631c45092e80a94a12af9b0b58cf451a83d')
    driver=load(LANE/'driver.py','continuation_boundary_original_driver')
    return common,contract,driver.classify_refusal


def validate_request(request,condition,predecessor_job_id):
    common,contract,_=scientific_helpers();prepared=request.get('prepared')
    if(request.get('job_id')!=predecessor_job_id or request.get('generation')!=contract['generation']
       or not isinstance(prepared,dict)):
        raise ValueError('Original job or prepared generation identity mismatch')
    required=('case_id','task_id','model_key','messages','prompt','prompt_token_ids','prompt_tokens',
              'body','request_sha256','prompt_token_ids_sha256','messages_sha256')
    if any(k not in prepared for k in required):raise ValueError('Missing inherited prepared request fields')
    ids=prepared['prompt_token_ids']
    if(prepared['case_id']!=request['case_id']or prepared['task_id']!=condition['task_id']
       or prepared['model_key']!=condition['model_key']or prepared['messages']!=request['messages']
       or not isinstance(prepared['prompt'],str)or not isinstance(ids,list)or not ids
       or any(type(t)is not int for t in ids)or prepared['prompt_tokens']!=len(ids)
       or len(ids)+16384>65536
       or prepared['body']!={'model':condition['model'],'prompt':prepared['prompt'],**contract['generation']}
       or common.digest(prepared['body'])!=prepared['request_sha256']
       or common.digest(ids)!=prepared['prompt_token_ids_sha256']
       or common.digest(prepared['messages'])!=prepared['messages_sha256']):
        raise ValueError('Inherited prepared request input/context or canonical digest mismatch')
    return prepared


def validate_saved_response(request,response,condition,predecessor_job_id):
    common,contract,classify_refusal=scientific_helpers()
    prepared=validate_request(request,condition,predecessor_job_id)
    raw=response.get('raw_text');tokens=response.get('token_ids')
    if response.get('job_id')!=predecessor_job_id:raise ValueError('Original response job identity mismatch')
    if(response.get('status')=='generation_exception' or bool(response.get('refusal'))
       or isinstance(raw,str)and ('<tool_call>' in raw or '<|im_start|>' in raw)
       or bool(response.get('extra_assistant_tail'))):
        raise ValueError('Inherited fatal delivery/refusal/turn/tool remains held')
    if(not isinstance(raw,str) or not isinstance(tokens,list) or not 1<=len(tokens)<=16384
       or any(type(t)is not int for t in tokens)or response.get('finish_reason') not in {'stop','length'}
       or not isinstance(response.get('usage'),dict)
       or response.get('prepared_request_sha256')!=prepared['request_sha256']):
        raise ValueError('Missing or malformed inherited raw response/budget fields')
    replay=common.normalize_output(prepared,raw,tokens,response['finish_reason'],contract,response['usage'])
    if any(response.get(k)!=v for k,v in replay.items()if k!='request_sha256'):
        raise ValueError('Inherited raw normalization replay mismatch')
    refusal=classify_refusal(replay.get('final_text')or'',False)
    if refusal['refusal']:raise ValueError('Inherited raw final refusal remains held despite stored flag')
    if response.get('status')not in {'completed','response_error'}:raise ValueError('Unknown inherited outcome status remains held')


def condition_boundary(condition,source,science_sha,predecessor_job_id):
    raw=Path(source['input_path']).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=source['input_sha256']:raise ValueError('Frozen input bytes changed')
    inputs=[json.loads(line)for line in raw.splitlines()]
    if len(inputs)!=condition['planned']:raise ValueError('Frozen full case denominator changed')
    run=Path(condition['runtime']);cases=run/'cases'
    if(run/'stopped.json').exists():raise ValueError('Original fatal delivery/refusal/turn stop remains held')
    observed=set()
    if cases.exists():
        if cases.is_symlink()or not cases.is_dir():raise ValueError('Invalid original cases directory')
        for folder in cases.iterdir():
            if(folder.is_symlink()or not folder.is_dir()or len(folder.name)!=6 or not folder.name.isdigit()
               or int(folder.name)>=len(inputs)):
                raise ValueError('Foreign or malformed original case artifact')
            if any(p.name not in{'request.json','response.json'}for p in folder.iterdir()):
                raise ValueError('Unexpected artifact inside original case directory')
            observed.add(int(folder.name))
    expected_identity={k:condition[k]for k in ['model','model_revision','model_key','task_id','run_id']}
    expected_identity['plan_sha256']=science_sha
    records=[]
    for index,case in enumerate(inputs):
        folder=cases/f'{index:06d}';request_path=folder/'request.json';response_path=folder/'response.json'
        record={'index':index,'case_id':case['case_id'],'task_id':condition['task_id'],
                'request':None,'response':None,'eligible_for_new_model_call':False}
        if request_path.exists():
            request,request_sha=read_hashed(request_path)
            if(request.get('case_id')!=case['case_id'] or request.get('messages')!=case['messages']
               or request.get('job_id')!=predecessor_job_id or any(request.get(k)!=v for k,v in expected_identity.items())):
                raise ValueError('Original request source/model/run identity mismatch')
            validate_request(request,condition,predecessor_job_id)
            record['request']={'path':str(request_path),'sha256':request_sha,'job_id':request.get('job_id')}
            if response_path.exists():
                response,response_sha=read_hashed(response_path)
                if(response.get('case_id')!=case['case_id']or response.get('request_sha256')!=request_sha
                   or any(response.get(k)!=v for k,v in expected_identity.items())):
                    raise ValueError('Original saved response provenance mismatch')
                validate_saved_response(request,response,condition,predecessor_job_id)
                record.update(outcome_state='inherited_saved_response',
                    response={'path':str(response_path),'sha256':response_sha,'job_id':response.get('job_id')},
                    inherited_status=response.get('status'),inherited_finish_reason=response.get('finish_reason'))
            else:
                record.update(outcome_state='ambiguous_claim_invalid',
                    explanation='A prior request exists without a saved model response; preserve it as ambiguous invalid and never regenerate this case.')
        else:
            if response_path.exists():raise ValueError('Response without its original request')
            record.update(outcome_state='unclaimed',eligible_for_new_model_call=True,
                          empty_original_directory_observed=index in observed)
        records.append(record)
    counts=dict(Counter(row['outcome_state']for row in records))
    source_records={}
    for name in ['started.json','progress.json','prediction_lock.json','completion.json','scoring_attempt.json','scores.json','scoring_completion.json']:
        p=run/name
        if p.exists():source_records[name]={'path':str(p),'sha256':sha(p)}
    if (run/'scores.json').exists():
        done,done_sha=read_hashed(run/'scoring_completion.json')
        if(done.get('scoring_terminal')is not True or done.get('scores_sha256')!=sha(run/'scores.json')
           or done.get('per_case_scores_sha256')!=sha(run/'per_case_scores.json')):
            raise ValueError('Existing completed score hash does not verify')
        if counts!={'inherited_saved_response':len(inputs)}:raise ValueError('Score exists without full inherited outcome set')
        completion,_=read_hashed(run/'completion.json');prediction_lock,lock_sha=read_hashed(run/'prediction_lock.json')
        scored,_=read_hashed(run/'scores.json')
        exhaustive={f"cases/{row['index']:06d}/{name}.json":row[name]['sha256']
                    for row in records for name in ['request','response']}
        if(completion.get('terminal')!=len(inputs)or completion.get('all_planned_terminal')is not True
           or completion.get('prediction_lock_sha256')!=lock_sha or scored.get('prediction_lock_sha256')!=lock_sha
           or prediction_lock.get('files_sha256')!=exhaustive
           or any(completion.get(k)!=v or prediction_lock.get(k)!=v for k,v in expected_identity.items())):
            raise ValueError('Already-scored task lacks exact exhaustive source/model/outcome seal')
        task_state='already_scored_preserve_without_rescoring'
    elif(run/'scoring_attempt.json').exists():
        raise ValueError('Original incomplete scoring attempt needs separate offline review; never silently repeat it')
    else:task_state='continue_unclaimed_then_seal_once'
    return {'task_id':condition['task_id'],'run_id':condition['run_id'],'planned':len(inputs),
        'runtime_path':str(run),'input_path':source['input_path'],'input_sha256':source['input_sha256'],
        'task_state':task_state,'counts':counts,'cases':records,'source_records':source_records,
        'eligible_case_ids':[row['case_id']for row in records if row['eligible_for_new_model_call']],
        'ambiguous_case_ids':[row['case_id']for row in records if row['outcome_state']=='ambiguous_claim_invalid'],
        'reference_values_parsed':False,'filename_counts_are_not_dispatch_counts':True}


def freeze_model(plan,science_sha,model_key,predecessor_job_id):
    if model_key not in {'base','posttrained'}:raise ValueError('Unknown matched model')
    conditions=[c for c in plan['conditions']if c['model_key']==model_key]
    if [c['task_id']for c in conditions]!=['P03','P01']:raise ValueError('Original sequential task scope changed')
    tasks={}
    for condition in conditions:
        source=next(t for t in plan['tasks']if t['task_id']==condition['task_id'])
        tasks[condition['task_id']]=condition_boundary(condition,source,science_sha,predecessor_job_id)
    return {'at_pacific':stamp(),'role':'exhaustive_terminal_case_boundary_not_new_model_delivery',
        'scientific_plan_sha256':science_sha,'model_key':model_key,'predecessor_job_id':predecessor_job_id,
        'full_denominator':sum(t['planned']for t in tasks.values()),'tasks':tasks,
        'new_model_calls':0,'new_GPU_allocations':0,'reference_values_parsed':False,
        'requires_predecessor_terminal_and_all_output_locks_free':True,
        'prior_claims_never_replayed':True,'unknown_missing_responses_are_invalid_not_fabricated':True}


# Only the independently admitted controller persists this pure boundary after
# verifying scheduler terminal identity and retaining every original output lock.
