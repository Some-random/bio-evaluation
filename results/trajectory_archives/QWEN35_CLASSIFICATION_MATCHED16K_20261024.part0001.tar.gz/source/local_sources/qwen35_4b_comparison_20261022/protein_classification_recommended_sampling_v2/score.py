"""Once-only, offline native accuracy for sealed matched P01/P03 conditions."""
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def write_once(path, value):
    with Path(path).open("x") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def parsers():
    binary = module(ROOT / "scripts/catalog_metric_helpers.py", "native_binary")
    categorical = module(ROOT / "scripts/score_local_catalog_extended.py", "native_localization")
    return {"P01": binary.parse_binary_answer, "P03": categorical.parse_class_id}


def replay_context(plan, condition):
    common = module(plan["shared_runtime"]["path"], "classification_recommended_replay")
    contract = common.load_contract(plan["shared_contract"]["path"], plan["shared_contract"]["sha256"])
    if contract["generation"] != plan["generation"]:
        raise ValueError("Plan generation differs from exact shared recipe")
    profile = contract["models"][condition["model_key"]]
    for name in ["tokenizer_config.json", "tokenizer.json", "vocab.json", "merges.txt", "chat_template.jinja"]:
        if name in profile["files"] and sha(Path(profile["directory"]) / name) != profile["files"][name]["sha256"]:
            raise ValueError("Native tokenizer source changed")
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(profile["directory"], local_files_only=True, trust_remote_code=False)
    return common, contract, tokenizer


def reconstruct_prepared(case, model_key, common, contract, tokenizer):
    return common.prepare_case({"task_id": case["task"], "case_id": case["case_id"], "messages": case["messages"]}, tokenizer, model_key, contract)


def calculate(task, targets, outputs):
    if task not in {"P01", "P03"} or not targets or len(targets) != len(outputs):
        raise ValueError("Require one output slot per planned label")
    valid = {0, 1} if task == "P01" else set(range(10))
    if any(type(t) is not int or t not in valid for t in targets):
        raise ValueError("Reference outside frozen native label ontology")
    parse = parsers()[task]
    predictions = [parse(row.get("final")) if row and row.get("status") == "completed" and not row.get("refusal") else None for row in outputs]
    correct = [p is not None and p == target for p, target in zip(predictions, targets)]
    counts = Counter(row.get("status") if row else "missing_terminal_record" for row in outputs)
    return {"accuracy": sum(correct) / len(targets), "correct": sum(correct), "planned": len(targets), "parsed": sum(p is not None for p in predictions), "invalid_or_missing": sum(p is None for p in predictions), "statuses": dict(counts), "all_case_rule": "Every frozen planned case remains in denominator; missing, transport, exception and invalid final outputs count incorrect."}, predictions, correct


def score(plan_path, model_slug, task):
    plan = read(plan_path)
    for path, expected_digest in plan["pins"].items():
        if sha(path) != expected_digest:
            raise ValueError("Pinned source changed: " + path)
    condition = next(x for x in plan["conditions"] if x["model_slug"] == model_slug and x["task_id"] == task)
    folder = Path(condition["runtime"])
    if (folder / "scores.json").exists() or (folder / "scoring_attempt.json").exists():
        raise ValueError("Scoring already attempted; do not duplicate or overwrite")
    completion = read(folder / "completion.json")
    lock_path = folder / "prediction_lock.json"
    if completion.get("prediction_lock_sha256") != sha(lock_path) or completion.get("terminal") != condition["planned"] or completion.get("all_planned_terminal") is not True:
        raise ValueError("Require exact complete cohort seal before scoring")
    lock = read(lock_path)
    if lock["plan_sha256"] != sha(plan_path) or lock["planned"] != condition["planned"] or lock.get("all_planned_terminal") is not True:
        raise ValueError("Prediction lock differs from frozen plan")
    expected_paths = {f"cases/{i:06d}/{name}" for i in range(condition["planned"]) for name in ["request.json", "response.json"]}
    if set(lock["files_sha256"]) != expected_paths:
        raise ValueError("Require exhaustive exact request and response lock path set")
    identity = {"model": condition["model"], "model_revision": condition["model_revision"], "model_key": condition["model_key"], "task_id": task, "run_id": condition["run_id"], "plan_sha256": sha(plan_path)}
    for name, value in identity.items():
        if completion.get(name) != value or lock.get(name) != value:
            raise ValueError("Seal model/run provenance mismatch: " + name)
    for path, expected_digest in lock["files_sha256"].items():
        if sha(folder / path) != expected_digest:
            raise ValueError("Locked output changed: " + path)
    source = next(x for x in plan["tasks"] if x["task_id"] == task)
    inputs = [json.loads(line) for line in Path(source["input_path"]).read_text().splitlines()]
    if sha(source["reference_path"]) != source["reference_sha256"]:
        raise ValueError("References changed")
    common, contract, tokenizer = replay_context(plan, condition)
    runtime_parser = module(HERE / "driver.py", "classification_recommended_refusal_rule")
    outputs = []
    for index, row in enumerate(inputs):
        output = read(folder / "cases" / f"{index:06d}" / "response.json")
        if output["case_id"] != row["case_id"] or any(output.get(name) != value for name, value in identity.items()):
            raise ValueError("Response provenance mismatch")
        request = read(folder / "cases" / f"{index:06d}" / "request.json")
        if output["request_sha256"] != sha(folder / "cases" / f"{index:06d}" / "request.json") or request["messages"] != row["messages"] or request["case_id"] != row["case_id"] or any(request.get(name) != value for name, value in identity.items()) or request["generation"] != plan["generation"]:
            raise ValueError("Request provenance mismatch")
        prepared = request["prepared"]
        expected_body = {"model": condition["model"], "prompt": prepared["prompt"], **plan["generation"]}
        if prepared["body"] != expected_body or prepared["request_sha256"] != digest(expected_body) or prepared["messages_sha256"] != digest(row["messages"]) or prepared["prompt_token_ids_sha256"] != digest(prepared["prompt_token_ids"]) or output.get("prepared_request_sha256") != prepared["request_sha256"]:
            raise ValueError("Prepared native request/generation identity mismatch")
        if prepared != reconstruct_prepared(row, condition["model_key"], common, contract, tokenizer):
            raise ValueError("Saved prepared request differs from original complete native messages")
        replayed = common.normalize_output(prepared, output["raw_text"], output["token_ids"], output["finish_reason"], contract, usage=output.get("usage", {}))
        replayed.update(runtime_parser.classify_refusal(replayed["final_text"]))
        for name in ["final", "final_text", "reasoning", "response_error", "extra_assistant_tail", "missing_think_close", "status", "truncated", "terminal", "transport_error", "http_error", "not_dispatched", "prompt_tokens", "completion_tokens", "usage", "refusal", "possible_inability_text"]:
            if output.get(name) != replayed[name]:
                raise ValueError("Saved derived response differs from raw replay: " + name)
        outputs.append(output)
    write_once(folder / "scoring_attempt.json", {"plan_sha256": sha(plan_path), "prediction_lock_sha256": sha(lock_path), "policy": "One native offline scoring attempt. Complete seal, every native request/provenance and raw-derived normalization verified before references opened."})
    references = [json.loads(line) for line in Path(source["reference_path"]).read_text().splitlines()]
    if [r["case_id"] for r in references] != [r["case_id"] for r in inputs]:
        raise ValueError("Reference/input order mismatch")
    targets = [r["target_binary" if task == "P01" else "target"] for r in references]
    metrics, predictions, correct = calculate(task, targets, outputs)
    scored = [{"case_id": row["case_id"], "prediction": pred, "target": target, "correct": good, "status": out["status"]} for row, pred, target, good, out in zip(inputs, predictions, targets, correct, outputs)]
    write_once(folder / "per_case_scores.json", scored)
    result = {"task_id": task, "model": condition["model"], "model_revision": condition["model_revision"], "run_id": condition["run_id"], "protocol_variant": condition["protocol_variant"], "prediction_lock_sha256": sha(lock_path), "planned": condition["planned"], "metrics": metrics, "delivery": completion, "native_parser_and_metric_unchanged": True, "explanation_support_assessed": False, "public_pretraining_exposure": "unknown", "comparison": "Identical complete reviewed inputs and native accuracy; matched Qwen3.5-4B/Base generation. Distinct from trained specialist paper systems and historical Qwen3.8 generation settings."}
    write_once(folder / "scores.json", result)
    write_once(folder / "scoring_completion.json", {"scores_sha256": sha(folder / "scores.json"), "per_case_scores_sha256": sha(folder / "per_case_scores.json"), "scoring_terminal": True})
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--model-slug", required=True)
    parser.add_argument("--task", choices=["P01", "P03"], required=True)
    args = parser.parse_args()
    result = score(args.plan, args.model_slug, args.task)
    print(json.dumps({"task_id": args.task, "model": result["model"], "metrics": result["metrics"]}))
