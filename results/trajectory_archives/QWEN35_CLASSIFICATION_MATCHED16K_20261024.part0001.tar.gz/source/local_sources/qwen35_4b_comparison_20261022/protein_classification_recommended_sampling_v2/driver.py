"""One-attempt P03/P01 generation; reference files are never loaded here."""
from collections import Counter
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
import re

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stamp():
    return datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()


def write(path, value, once=False):
    path = Path(path)
    if once:
        with path.open("x") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    else:
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
        tmp.replace(path)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def classify_refusal(final, explicit=False):
    """Reviewed narrow refusal rule; generic lack of information stays invalid."""
    inability = bool(re.search(r"\b(?:I cannot|I can't|I'm unable to) (?:assist|help|provide|answer)\b", final, re.I))
    direct_decline = bool(re.search(r"\b(?:I cannot|I can't|I'm unable to) (?:assist|help)(?: you)? with (?:this|that|your) request\b", final, re.I))
    safety_reason = bool(re.search(r"\b(?:unsafe|harmful|prohibited|biosafety|biosecurity|biological risk|safety policy)\b", final, re.I))
    return {"refusal": bool(explicit) or direct_decline or (inability and safety_reason), "possible_inability_text": inability}


def summarize(outputs, planned):
    return {"at_pacific": stamp(), "role": "direct_unsealed_progress_lower_bound", "planned": planned, "attempted_confirmed": sum(o.get("status") != "generation_exception" for o in outputs), "attempted_or_ambiguous": len(outputs), "ambiguous_generation_exceptions": sum(o.get("status") == "generation_exception" for o in outputs), "responses_saved": sum(o.get("status") in {"completed", "response_error"} for o in outputs), "terminal": len(outputs), "not_dispatched": planned - len(outputs), "empty_finals": sum(not (o.get("final") or "").strip() for o in outputs), "truncations": sum(o.get("finish_reason") == "length" for o in outputs), "transport_errors": 0, "http_errors": 0, "generation_exceptions": sum(o.get("status") == "generation_exception" for o in outputs), "output_contract_errors": sum(o.get("status") == "response_error" for o in outputs), "refusals": sum(bool(o.get("refusal")) for o in outputs), "finish_reasons": dict(Counter(o.get("finish_reason") for o in outputs)), "biological_correctness_assessed": False, "native_scoring_status": "not_started", "endpoint": "in_process_vllm_no_http_endpoint"}


def run_task(session, plan, plan_path, condition):
    run = Path(condition["runtime"])
    run.mkdir(parents=True, exist_ok=True)
    with (run / "run.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return _run_task_locked(session, plan, plan_path, condition)


def _run_task_locked(session, plan, plan_path, condition):
    source = next(t for t in plan["tasks"] if t["task_id"] == condition["task_id"])
    inputs = [json.loads(line) for line in Path(source["input_path"]).read_text().splitlines()]
    if len(inputs) != condition["planned"]:
        raise ValueError("Input count changed")
    run = Path(condition["runtime"])
    run.mkdir(parents=True, exist_ok=True)
    if (run / "started.json").exists() or (run / "cases").exists():
        raise ValueError("Namespace already attempted; no automatic re-execution")
    (run / "cases").mkdir()
    identity = {"model": condition["model"], "model_revision": condition["model_revision"], "model_key": condition["model_key"], "task_id": condition["task_id"], "run_id": condition["run_id"], "plan_sha256": sha(plan_path), "job_id": os.environ["SLURM_JOB_ID"]}
    write(run / "started.json", {**identity, "at_pacific": stamp(), "planned": len(inputs)}, once=True)
    outputs = []
    write(run / "progress.json", {**identity, **summarize(outputs, len(inputs))})
    for start in range(0, len(inputs), plan["batch_size"]):
        batch = inputs[start:start + plan["batch_size"]]
        prepared = [session.prepare({"case_id": case["case_id"], "task_id": case["task"], "messages": case["messages"]}) for case in batch]
        request_paths = []
        for offset, (case, item) in enumerate(zip(batch, prepared)):
            folder = run / "cases" / f"{start + offset:06d}"
            folder.mkdir()
            request_path = folder / "request.json"
            request = {**identity, "case_id": case["case_id"], "messages": case["messages"], "generation": plan["generation"], "prepared": item, "at_pacific": stamp()}
            write(request_path, request, once=True)
            request_paths.append(request_path)
        try:
            results = session.generate_prepared(prepared)
            if len(results) != len(batch):
                raise ValueError("Common session returned wrong output count")
        except Exception as error:
            results = [{"case_id": c["case_id"], "task_id": c["task"], "status": "generation_exception", "final": None, "raw_text": "", "token_ids": [], "finish_reason": None, "error_type": type(error).__name__, "error": str(error)[:2000]} for c in batch]
        stop = False
        for case, result, request_path in zip(batch, results, request_paths):
            if result.get("case_id") != case["case_id"]:
                raise ValueError("Common session returned wrong case identity")
            result.update(classify_refusal(result.get("final_text", result.get("final", "")) or "", result.get("refusal", False)))
            output = {**result, **identity, "case_id": case["case_id"], "prepared_request_sha256": result.get("request_sha256"), "request_sha256": sha(request_path), "at_pacific": stamp()}
            write(request_path.parent / "response.json", output, once=True)
            outputs.append(output)
            raw = output.get("raw_text", "")
            stop |= output["status"] == "generation_exception" or bool(output.get("refusal")) or "<tool_call>" in raw or bool(output.get("extra_assistant_tail")) or "<|im_start|>" in raw
        write(run / "progress.json", {**identity, **summarize(outputs, len(inputs))})
        if stop:
            write(run / "stopped.json", {**identity, "at_pacific": stamp(), "reason": "Model delivery exception, refusal or undeclared tool call; no new requests, retries or scoring.", "observed_terminal": len(outputs)}, once=True)
            raise RuntimeError("Delivery stop; preserve all attempted cases")
    files = {}
    for index in range(len(inputs)):
        for name in ["request.json", "response.json"]:
            path = run / "cases" / f"{index:06d}" / name
            files[str(path.relative_to(run))] = sha(path)
    write(run / "prediction_lock.json", {**identity, "at_pacific": stamp(), "planned": len(inputs), "files_sha256": files, "all_planned_terminal": True, "references_not_opened": True}, once=True)
    completion = {**identity, **summarize(outputs, len(inputs)), "role": "sealed_complete_reviewed_cohort_delivery", "all_planned_terminal": True, "prediction_lock_sha256": sha(run / "prediction_lock.json")}
    write(run / "completion.json", completion, once=True)
    return completion


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha256", required=True)
    parser.add_argument("--model-key", required=True)
    args = parser.parse_args()
    if sha(args.plan) != args.plan_sha256:
        raise ValueError("Plan changed")
    plan = json.loads(args.plan.read_text())
    for path, expected in plan["pins"].items():
        if sha(path) != expected:
            raise ValueError("Pinned source changed before inference: " + path)
    for source in plan["tasks"]:
        rows = [json.loads(line) for line in Path(source["input_path"]).read_text().splitlines()]
        review = json.loads(Path(source["review_path"]).read_text())
        if [r["case_id"] for r in rows] != review["approved_case_ids"] or len(rows) != source["planned_per_model"] or review["held_cases"]:
            raise ValueError("Historical complete approved cohort changed")
    common = load(plan["shared_runtime"]["path"], "shared_qwen35_runtime")
    contract = common.load_contract(plan["shared_contract"]["path"], plan["shared_contract"]["sha256"])
    session = common.create_session(args.model_key, contract, max_num_seqs=plan["batch_size"])
    runtime = Path(plan["models"][args.model_key]["runtime"])
    # One fixed shared 34-call task-shaped actual gate is required by worker.
    # No second artificial panel, parameter search or silent gate retry occurs here.
    preflights = []
    for source in plan["tasks"]:
        rows = [json.loads(line) for line in Path(source["input_path"]).read_text().splitlines()]
        lengths = [session.prepare({"task_id": row["task"], "case_id": row["case_id"], "messages": row["messages"]})["prompt_tokens"] for row in rows]
        preflights.append({"task_id": source["task_id"], "count": len(lengths), "max_prompt_tokens": max(lengths), "max_total_with_output_budget": max(lengths) + contract["generation"]["max_tokens"], "all_fit": max(lengths) + contract["generation"]["max_tokens"] <= contract["context_limit"], "inputs_truncated": False})
    write(runtime / "input_token_preflight.json", {"model_key": args.model_key, "plan_sha256": args.plan_sha256, "tasks": preflights, "all_fit": all(r["all_fit"] for r in preflights), "biological_model_calls": 0}, once=True)
    for condition in plan["conditions"]:
        if condition["model_key"] != args.model_key:
            continue
        run_task(session, plan, args.plan, condition)
        scorer = load(HERE / "score.py", "classification_offline_scorer")
        scorer.score(args.plan, condition["model_slug"], condition["task_id"])
    write(runtime / "model_completed.json", {"at_pacific": stamp(), "model_key": args.model_key, "plan_sha256": args.plan_sha256, "all_task_conditions_scored": True}, once=True)


if __name__ == "__main__":
    main()
