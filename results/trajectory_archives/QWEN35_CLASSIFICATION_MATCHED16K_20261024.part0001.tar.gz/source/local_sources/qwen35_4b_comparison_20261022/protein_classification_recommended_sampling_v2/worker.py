"""Plan-bound one-GPU worker for one paired classifier model."""
from pathlib import Path
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write(path, value):
    with Path(path).open("x") as handle:
        json.dump(value, handle, indent=2)
        handle.write("\n")


def validate(plan_path, expected_plan, grant_path, expected_grant, model_key, require_neutral=True):
    if sha(plan_path) != expected_plan or sha(grant_path) != expected_grant:
        raise ValueError("Plan or root grant changed")
    plan = json.loads(Path(plan_path).read_text())
    grant = json.loads(Path(grant_path).read_text())
    decision = json.loads(Path(plan["repair_decision"]["path"]).read_text())
    if sha(plan["repair_decision"]["path"]) != plan["repair_decision"]["sha256"] or decision.get("issuer") != "/root" or decision.get("role") != "prospective_scientific_recipe_adoption_and_bounded_engineering_delegation":
        raise ValueError("Exact root recipe adoption required")
    if grant.get("issuer") not in decision["engineering_delegation"]["review_grant_issuers"] or grant.get("issuer") == plan["owner"] or grant.get("approved") is not True or grant.get("plan_sha256") != expected_plan or model_key not in grant["model_keys"]:
        raise ValueError("Require independent exact model/plan admission")
    for path, expected in plan["pins"].items():
        if sha(path) != expected:
            raise ValueError("Pinned file changed: " + path)
    review_path = Path(grant["independent_review_path"])
    if sha(review_path) != grant["independent_review_sha256"]:
        raise ValueError("Independent final review changed")
    review = json.loads(review_path.read_text())
    if not review.get("passed") or review.get("plan_sha256") != expected_plan or review.get("reviewer") == plan["owner"]:
        raise ValueError("Independent review does not admit exact candidate")
    if require_neutral is not True:
        raise ValueError("New recipe submissions require actual prior neutral success")
    neutral_path = Path(plan["required_shared_neutral_receipt"])
    proof_module = load(plan["neutral_proof"]["path"], "classification_recommended_neutral_proof")
    proof_module.verify_neutral_proof(plan["shared_contract"]["sha256"], receipt_path=neutral_path)
    neutral = json.loads(neutral_path.read_text())
    if neutral.get("passed") is not True or neutral.get("shared_contract_sha256") != plan["shared_contract"]["sha256"] or set(neutral.get("models", {})) != {"base", "posttrained"} or not all(row.get("passed") is True for row in neutral["models"].values()):
        raise ValueError("Actual new shared neutral gate must pass for both exact models before submission or calls")
    if sha(neutral_path) != grant.get("shared_neutral_receipt_sha256"):
        raise ValueError("Exact actual neutral proof must be bound by independent grant")
    # Serialize the two new validators, while actual predecessor locks remain
    # nonblocking checks. A validator must not mistake its peer for old work.
    with (HERE / "predecessor_validation.lock").open("a") as boundary_lock:
        fcntl.flock(boundary_lock, fcntl.LOCK_EX)
        if sha(plan["old_drain_closure"]["path"]) != plan["old_drain_closure"]["sha256"]:
            raise ValueError("Original drain preservation proof changed")
        for path in plan["old_worker_locks"]:
            with Path(path).open("r") as old_worker:
                fcntl.flock(old_worker, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for path in plan["old_p01_namespaces"]:
            old_p01 = Path(path)
            if (old_p01 / "started.json").exists() or (old_p01 / "cases").exists():
                raise ValueError("Unexpected original P01 attempt namespace")
        for old in plan["old_conditions"]:
            folder = Path(old["runtime"])
            if folder == Path(plan["models"][model_key]["runtime"]):
                raise ValueError("New output namespace overlaps original")
            if not (folder / "cases").exists() or (folder / "cases").stat().st_mode & 0o222:
                raise ValueError("Original request creation is not drained")
            with (folder / "run.lock").open("r") as old_lock:
                fcntl.flock(old_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    return plan


def audit(plan, own=False, additional=0):
    audit_module = load(plan["gpu_audit"]["path"], "classification_project_gpu_audit")
    for row in plan["unrelated_job_reviews"]:
        if sha(row["path"]) != row["sha256"] or sha(row["command"]) != row["command_sha256"]:
            raise ValueError("Unrelated-job identity review changed")
        audit_module.REVIEWED_UNRELATED[row["job_id"]] = (row["workdir"], row["command"])
    result = audit_module.conservative_project_gpu_audit(require_own_job=own, additional_gpus=additional)
    if own:
        job = next(row for row in result["jobs"] if row["job_id"] == os.environ["SLURM_JOB_ID"])
        if job["command"] != str(HERE / "worker.sbatch") or job["workdir"] != str(ROOT):
            raise ValueError("Wrong exact worker identity")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha256", required=True)
    parser.add_argument("--grant", type=Path, required=True)
    parser.add_argument("--grant-sha256", required=True)
    parser.add_argument("--model-key", choices=["base", "posttrained"], required=True)
    args = parser.parse_args()
    plan = validate(args.plan, args.plan_sha256, args.grant, args.grant_sha256, args.model_key)
    if not os.environ.get("SLURM_JOB_ID"):
        raise ValueError("Real one-GPU Slurm allocation required")
    model_runtime = Path(plan["models"][args.model_key]["runtime"])
    model_runtime.mkdir(parents=True, exist_ok=True)
    lock = (model_runtime / "worker.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    write(model_runtime / "worker_started.json", {"job_id": os.environ["SLURM_JOB_ID"], "plan_sha256": args.plan_sha256, "grant_sha256": args.grant_sha256, "model_key": args.model_key})
    write(model_runtime / "gpu_audit.json", audit(plan, own=True))
    common = load(plan["shared_runtime"]["path"], "classification_shared_runtime")
    contract = common.load_contract(plan["shared_contract"]["path"], plan["shared_contract"]["sha256"])
    neutral_path = Path(contract["neutral_gate_receipt"])
    neutral = json.loads(neutral_path.read_text())
    if neutral.get("passed") is not True or neutral.get("shared_contract_sha256") != plan["shared_contract"]["sha256"]:
        raise ValueError("Exact shared two-model neutral runtime gate must pass first")
    write(model_runtime / "shared_neutral_gate_observation.json", {"receipt_path": str(neutral_path), "receipt_sha256": sha(neutral_path), "shared_contract_sha256": plan["shared_contract"]["sha256"], "passed": True})
    local = Path(tempfile.mkdtemp(prefix="qwen35-classification-" + os.environ["SLURM_JOB_ID"] + "-"))
    python, env, receipt = common.restore_runtime(local, contract)
    env["PYTHONPATH"] = str(HERE)
    write(model_runtime / "runtime_environment.json", {"private_runtime": str(local), "archive_verification": receipt, "credentials_removed": True, "no_model_tools_or_external_endpoint": True})
    with (model_runtime / "generation.log").open("x") as log:
        result = subprocess.run([str(python), str(HERE / "driver.py"), "--plan", str(args.plan), "--plan-sha256", args.plan_sha256, "--model-key", args.model_key], env=env, cwd=local, stdout=log, stderr=subprocess.STDOUT)
    write(model_runtime / "worker_terminal.json", {"job_id": os.environ["SLURM_JOB_ID"], "returncode": result.returncode, "model_key": args.model_key, "plan_sha256": args.plan_sha256})
    if result.returncode:
        raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
