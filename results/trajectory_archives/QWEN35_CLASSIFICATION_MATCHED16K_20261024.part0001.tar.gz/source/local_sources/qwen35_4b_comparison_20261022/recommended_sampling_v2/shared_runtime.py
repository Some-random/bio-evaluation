"""Matched raw inference helpers. No benchmark targets, tool execution or admission."""
from pathlib import Path
import hashlib, importlib.util, json, os, re, tarfile

HERE=Path(__file__).resolve().parent

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def canonical_bytes(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()

def digest(value):return hashlib.sha256(canonical_bytes(value)).hexdigest()

def load_contract(path,expected_sha256):
    if sha(path)!=expected_sha256:raise ValueError('Contract changed')
    contract=json.loads(Path(path).read_text())
    for fp,expected in contract['source_pins'].items():
        if sha(fp)!=expected:raise ValueError('Shared source changed: '+fp)
    if contract['condition']!='qwen35_4b_matched_author_general_thinking_raw16k_v2' or contract['generation']['max_tokens']!=16384 or contract['context_limit']!=65536:
        raise ValueError('Different prospective common condition or budget')
    for key,value in {'temperature':1.0,'top_p':0.95,'top_k':20,'presence_penalty':1.5}.items():
        if contract['generation'].get(key)!=value:raise ValueError('Different author-recommended sampling')
    return contract

def model_profile(model_key,contract):
    if model_key not in ('base','posttrained'):raise ValueError('Unknown paired model')
    return contract['models'][model_key]

def validate_checkpoint(model_key,contract):
    model=model_profile(model_key,contract);directory=Path(model['directory'])
    receipt_path=Path(model['acquisition_receipt'])
    if sha(receipt_path)!=model['acquisition_receipt_sha256']:raise ValueError('Acquisition receipt changed')
    receipt=json.loads(receipt_path.read_text())
    if receipt['model']!=model['name'] or receipt['revision']!=model['revision'] or not receipt['all_publisher_digests_verified']:
        raise ValueError('Publisher receipt identity mismatch')
    for name,row in model['files'].items():
        path=directory/name
        if path.stat().st_size!=row['bytes'] or sha(path)!=row['sha256']:raise ValueError('Checkpoint changed: '+name)
    return directory

def restore_runtime(local_dir,contract):
    local=Path(local_dir)
    if local.exists() and any(local.iterdir()):raise ValueError('Use a private empty runtime directory')
    local.mkdir(parents=True,exist_ok=True)
    for key in ('base_runtime','cuda_overlay'):
        row=contract[key]
        if sha(row['path'])!=row['sha256']:raise ValueError('Runtime archive changed')
    spec=importlib.util.spec_from_file_location('paired_runtime_archive_common',contract['runtime_common'])
    common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
    with tarfile.open(contract['base_runtime']['path']) as ar:ar.extractall(local,filter='data')
    receipt=common.apply_overlay(local)
    if receipt!={'base':contract['base_runtime']['sha256'],'overlay':contract['cuda_overlay']['sha256']}:
        raise ValueError('Extracted runtime differs')
    env=common.environment(local)
    for key in list(env):
        if re.search(r'API_KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL',key,re.I) or key in {'SSH_AUTH_SOCK','NETRC','KUBECONFIG','PYTHONHOME','VIRTUAL_ENV'}:env.pop(key,None)
    env.update(PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1',VLLM_USE_V2_MODEL_RUNNER='0')
    return local/'python/bin/python3.12',env,receipt

def render_prompt(tokenizer,messages,contract):
    if hashlib.sha256(tokenizer.chat_template.encode()).hexdigest()!=contract['chat_template_sha256']:
        raise ValueError('Native chat template differs')
    if not isinstance(messages,list) or not messages:raise ValueError('Complete messages required')
    for message in messages:
        content=message.get('content')
        text_only=isinstance(content,str) or (isinstance(content,list) and len(content)>0 and all(
          isinstance(part,dict) and set(part)=={'type','text'} and part['type']=='text' and isinstance(part['text'],str) for part in content))
        if message.get('role') not in ('system','user','assistant') or not text_only:
            raise ValueError('Initial lanes require complete text-only messages')
        if any(k in message for k in ('tools','tool_calls','images')):raise ValueError('No tools or images in initial lanes')
    return tokenizer.apply_chat_template(messages,tokenize=False,add_generation_prompt=True,enable_thinking=True)

def prepare_case(case,tokenizer,model_key,contract):
    prompt=render_prompt(tokenizer,case['messages'],contract)
    ids=tokenizer.encode(prompt,add_special_tokens=False)
    if len(ids)+contract['generation']['max_tokens']>contract['context_limit']:
        raise ValueError('Complete input plus output budget exceeds context; do not truncate')
    body={'model':model_profile(model_key,contract)['name'],'prompt':prompt,**contract['generation']}
    return {'task_id':case['task_id'],'case_id':case['case_id'],'model_key':model_key,
            'messages':case['messages'],
            'prompt':prompt,'prompt_token_ids':ids,'prompt_tokens':len(ids),'body':body,
            'request_sha256':digest(body),'prompt_token_ids_sha256':digest(ids),
            'messages_sha256':digest(case['messages'])}

def split_final(raw_text,contract):
    if not isinstance(raw_text,str):raise ValueError('Raw generated text required')
    text=raw_text;extra=False
    undeclared_control=any(marker in raw_text for marker in ('<|im_start|>','<tool_call>','</tool_call>'))
    for marker in ('<|im_end|>','<|endoftext|>'):
        if marker in text:
            text,_,tail=text.partition(marker)
            if tail.strip():extra=True
    if '</think>' not in text:
        return {'final':'','final_text':'','reasoning':text,'response_error':True,
                'extra_assistant_tail':extra,'missing_think_close':True}
    reasoning,final=text.split('</think>',1);final=final.strip()
    bad=extra or undeclared_control or any(tag in final for tag in ('<think>','</think>'))
    if bad:final=''
    return {'final':final,'final_text':final,'reasoning':reasoning,
            'response_error':bad,'extra_assistant_tail':extra,'missing_think_close':False}

def normalize_output(prepared,raw_text,token_ids,finish_reason,contract,usage=None):
    if not isinstance(token_ids,list) or any(type(t)is not int for t in token_ids):raise ValueError('Actual generated token IDs required')
    parts=split_final(raw_text,contract);usage=usage or {}
    if finish_reason!='stop':parts.update(final='',final_text='',response_error=True)
    return {'case_id':prepared['case_id'],'task_id':prepared['task_id'],'model_key':prepared['model_key'],
      **parts,'raw_text':raw_text,'token_ids':token_ids,'finish_reason':finish_reason,
      'status':'response_error' if parts['response_error'] else 'completed',
      'request_sha256':prepared['request_sha256'],'prompt_tokens':prepared['prompt_tokens'],
      'completion_tokens':usage.get('completion_tokens',len(token_ids)),'usage':usage,
      'truncated':finish_reason=='length','terminal':True,'transport_error':False,'http_error':False,'not_dispatched':False}

class Session:
    def __init__(self,model_key,contract,max_num_seqs=16):
        from transformers import AutoTokenizer
        from vllm import LLM,SamplingParams
        self.contract=contract;self.model_key=model_key
        if type(max_num_seqs)is not int or not 1<=max_num_seqs<=contract['maximum_concurrency']:
            raise ValueError('Concurrency outside neutral-validated ceiling')
        directory=validate_checkpoint(model_key,contract)
        self.tokenizer=AutoTokenizer.from_pretrained(directory,local_files_only=True,trust_remote_code=False)
        if self.tokenizer.convert_tokens_to_ids('<|im_end|>')!=248046 or self.tokenizer.convert_tokens_to_ids('<|endoftext|>')!=248044:
            raise ValueError('Stop-token identity mismatch')
        kwargs=dict(contract['generation']);kwargs.pop('return_token_ids',None);kwargs.pop('add_special_tokens',None)
        self.params=SamplingParams(**kwargs)
        self.llm=LLM(model=str(directory),tokenizer=str(directory),trust_remote_code=False,dtype='bfloat16',
          tensor_parallel_size=1,max_model_len=contract['context_limit'],max_num_seqs=max_num_seqs,
          max_num_batched_tokens=8192,gpu_memory_utilization=0.90,enforce_eager=True,
          enable_prefix_caching=False,limit_mm_per_prompt={'image':0,'video':0})
    def prepare(self,case):return prepare_case(case,self.tokenizer,self.model_key,self.contract)
    def generate_prepared(self,prepared):
        for row in prepared:
            if row['model_key']!=self.model_key or digest(row['body'])!=row['request_sha256']:
                raise ValueError('Prepared request changed')
            if row['body']!={'model':model_profile(self.model_key,self.contract)['name'],'prompt':row['prompt'],**self.contract['generation']}:
                raise ValueError('Prepared request settings differ')
            if self.tokenizer.encode(row['prompt'],add_special_tokens=False)!=row['prompt_token_ids']:
                raise ValueError('Prepared tokenization changed')
            if row['prompt_tokens']!=len(row['prompt_token_ids']) or digest(row['prompt_token_ids'])!=row['prompt_token_ids_sha256']:
                raise ValueError('Prepared token count/hash changed')
            if len(row['prompt_token_ids'])+self.contract['generation']['max_tokens']>self.contract['context_limit']:
                raise ValueError('Prepared complete input exceeds context')
            if digest(row['messages'])!=row['messages_sha256'] or render_prompt(self.tokenizer,row['messages'],self.contract)!=row['prompt']:
                raise ValueError('Prepared source messages/rendering changed')
        outputs=self.llm.generate([{'prompt_token_ids':r['prompt_token_ids']} for r in prepared],self.params,use_tqdm=False)
        if len(outputs)!=len(prepared):raise ValueError('Incomplete model batch')
        normalized=[]
        for row,result in zip(prepared,outputs):
            if len(result.outputs)!=1:raise ValueError('One response per request required')
            output=result.outputs[0]
            normalized.append(normalize_output(row,output.text,list(output.token_ids),output.finish_reason,self.contract))
            normalized[-1]['stop_reason']=output.stop_reason
        return normalized

def create_session(model_key,contract,max_num_seqs=16):return Session(model_key,contract,max_num_seqs)

def validate_neutral_outputs(outputs,expected):
    """expected maps synthetic case IDs to exact final strings. No real QA labels."""
    keyed={x['case_id']:x for x in outputs}
    if len(keyed)!=len(outputs) or set(keyed)!=set(expected):raise ValueError('Neutral case identity mismatch')
    diagnostics={k:{'final':keyed[k]['final'],'expected':str(v),'correct':keyed[k]['final']==str(v),
      'truncated':keyed[k]['truncated'],'response_error':keyed[k]['response_error']} for k,v in expected.items()}
    return {'passed':all(x['correct'] and not x['truncated'] and not x['response_error'] for x in diagnostics.values()),
            'cases':diagnostics,'synthetic_only':True,'biological_admission':False}
