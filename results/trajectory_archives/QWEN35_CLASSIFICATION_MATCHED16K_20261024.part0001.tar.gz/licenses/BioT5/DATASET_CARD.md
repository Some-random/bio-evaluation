---
license: mit
language:
- en
---

## References
For more information, please refer to our paper and GitHub repository.

Paper: 

[BioT5: Enriching Cross-modal Integration in Biology with Chemical Knowledge and Natural Language Associations](https://arxiv.org/abs/2310.07276)

[BioT5+: Towards Generalized Biological Understanding with IUPAC Integration and Multi-task Tuning](https://arxiv.org/abs/2402.17810)

GitHub: https://github.com/QizhiPei/BioT5