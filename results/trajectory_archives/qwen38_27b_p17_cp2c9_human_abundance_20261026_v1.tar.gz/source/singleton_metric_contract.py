"""Pure native formula/seal contract, synthetic-only until separate scoring grant.

No source/reference loader or scoring command is implemented in this module.
"""
import math

NATIVE_COUNT = 6370


def native_singleton_after_complete_seal(case_ids, predictions, seal, reference_loader):
    ids = list(case_ids)
    if len(ids) != NATIVE_COUNT or len(set(ids)) != NATIVE_COUNT:
        raise ValueError("exact_native_singleton_denominator_required")
    if set(predictions) - set(ids):
        raise ValueError("foreign_prediction_identity")
    invalid = [case for case, value in predictions.items() if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value)]
    if set(predictions) != set(ids) or invalid:
        return {"native_scoring_status": "undefined_incomplete_full_cohort_delivery", "primary_native_Spearman": None, "protected_references_opened": False, "native_denominator": NATIVE_COUNT}
    if seal.get("exact_plan_bound_raw_request_outcome_validation_complete") is not True or seal.get("all_original_attempts_sealed") is not True or seal.get("planned_native_variants") != NATIVE_COUNT or seal.get("sole_scoring_claim_admitted") is not True:
        raise PermissionError("exact_full_prediction_seal_and_once_scoring_claim_required")
    references = reference_loader()
    if set(references) != set(ids):
        raise ValueError("exact_native_reference_identity_required")
    if any(isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) for value in references.values()):
        raise ValueError("finite_native_references_required")
    from scipy.stats import spearmanr
    import numpy as np
    correlation = float(spearmanr([references[case] for case in ids], [predictions[case] for case in ids])[0])
    defined = math.isfinite(correlation)
    return {"native_scoring_status": "completed_native_scored_exact_singleton" if defined else "undefined_constant_or_insufficient_native_assay", "native_per_assay_Spearman_unrounded": correlation if defined else None, "primary_native_Spearman": float(np.round(correlation, 3)) if defined else None, "protected_references_opened": True, "native_denominator": NATIVE_COUNT, "native_coarse_selection_type": "Expression", "native_aggregation": "Native per-assay Spearman rounded3; one assay/one UniProt/one Expression group, no pooling with old30, separate9, TPMT, PRKN or PTEN.", "full217_complete": False}
