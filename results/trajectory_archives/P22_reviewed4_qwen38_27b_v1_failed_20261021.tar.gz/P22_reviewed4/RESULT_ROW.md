| Evaluation | Qwen3.8-27B | GPT models |
| --- | --- | --- |
| PFArena — single-mutant-informed ranking,reviewed vertebrate stability subset(4/29 assays) | Undefined under native strict coverage | Not evaluated |

This subset result does not complete the native29-assay panel or the retained catalog.
