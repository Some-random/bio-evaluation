# Protein function description: human-curation snapshot adaptation

Qwen3.8-27B generated descriptions from nine complete human protein sequences. These are all independently labeled records from the declared UniProt reviewed-human curation2026 query after excluding three missing function comments; exact sequence overlap with the four completed Mol-Instructions description cohorts is zero.

This small source adaptation does not reproduce NatureLM’s unreleased temporal NCBI test and its ROUGE result cannot be compared directly with the paper. UniProt creation dates do not establish first sequence publication, first functional annotation or absence from model pretraining. ROUGE measures lexical agreement, not factual correctness.

Complete questions, saved model responses, failure records and the declared lexical score are included. Checkpoints, environments, credentials and the full account GPU inventory remain local. This archive has not itself been uploaded.
