| Evaluation | Qwen3.8-27B | GPT models |
| --- | --- | --- |
| PFArena — single-mutant-informed ranking,reviewed vertebrate stability subset(4/29 assays) | NDCG=0.8796074581537591; NMS@5=0.8731816761082669; Recall@5=0.15000000000000002; spearman=0.16351589335243225 | Not evaluated |

This subset result does not complete the native29-assay panel or the retained catalog.
