"""Exact one-GPU submission, disabled until peer grant and delegated operational release exist."""
from pathlib import Path
import argparse
import fcntl
import json
import os
import re
import subprocess

import admission
import resource_contract as resource
import scheduler_contract as scheduler
import scorer

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]


def submit(plan_sha, grant_sha):
    plan = admission.validate_plan_and_grant(HERE/"plan.json", plan_sha, HERE/"engineering_admission.json", grant_sha)
    with (HERE/"submission.lock").open("a") as owned:
        fcntl.flock(owned, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if any(path.exists() or path.is_symlink() for path in [HERE/"submission_claim.json",HERE/"submission_receipt.json",HERE/"runtime/allocation_started.json"]):
            raise PermissionError("preserve_existing_or_ambiguous_submission_no_retry")
        with resource.shared_lock():
            # Hold shared lock through fresh audit, durable claim and sole sbatch.
            audit = resource.audit(plan, startup=False)
            scorer._exclusive_json(HERE/"preallocation_resource_audit.json", audit)
            release = admission.validate_operational_release(plan_sha, grant_sha)
            command = scheduler.submission_command(HERE, plan_sha, grant_sha)
            environment = scheduler.submission_environment(os.environ)
            stop = HERE/"STOP"
            if stop.is_symlink() or not stop.is_file() or admission.protocol.sha(stop) != plan["new_scheduling_STOP_sha256"]:
                raise PermissionError("exact_new_STOP_required_before_authorized_clearance")
            scorer._exclusive_json(HERE/"STOP_clearance_receipt.json", {"role":"exact_P19_FULL2_new_STOP_clearance_only", "plan_sha256":plan_sha,"engineering_admission_sha256":grant_sha,"operational_release_sha256":admission.protocol.sha(HERE/"engineering_admission.json"),"removed_STOP_sha256":plan["new_scheduling_STOP_sha256"],"legacy_STOPs_unchanged":True})
            stop.unlink()
            scorer._exclusive_json(HERE/"submission_claim.json", {"role":"durable_exact_once_P19_FULL2_submission_claim","plan_sha256":plan_sha,"engineering_admission_sha256":grant_sha,"command":command,"submitted_GPUs":1,"automatic_retry_authorized":False})
            try:
                result = subprocess.run(command, capture_output=True, text=True, timeout=60, check=True, cwd=ROOT, env=environment)
                match = re.fullmatch(r"([0-9]+)(?:;[^\s]+)?\s*", result.stdout)
                if match is None:
                    raise ValueError("ambiguous_submission_response")
                receipt = {"role":"actual_exact_once_P19_FULL2_GPU_submission_not_model_completion", "job_id":match.group(1),"plan_sha256":plan_sha,"engineering_admission_sha256":grant_sha,"submitted_GPUs":1,"command":command,"automatic_retry_authorized":False}
                scorer._exclusive_json(HERE/"submission_receipt.json", receipt)
                return {"submitted_job_id": match.group(1), "requested_GPUs":1,"model_dispatch_observed":False}
            except BaseException:
                scorer._exclusive_json(HERE/"submission_ambiguous_or_failed.json", {"role":"preserved_submission_terminal_or_ambiguous_no_retry","plan_sha256":plan_sha,"claim_present":True,"automatic_retry_authorized":False})
                raise


if __name__ == "__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--plan-sha",required=True);parser.add_argument("--grant-sha",required=True);args=parser.parse_args()
    try:
        print(json.dumps(submit(args.plan_sha,args.grant_sha),sort_keys=True))
    except Exception:
        print(json.dumps({"error_code":"P19_FULL2_submission_stopped_or_ambiguous_preserve_claim_no_retry"}))
        raise SystemExit(2)
