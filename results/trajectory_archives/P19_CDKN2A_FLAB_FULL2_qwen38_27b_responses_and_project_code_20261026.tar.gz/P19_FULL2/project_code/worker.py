"""One exact adopted P19 FULL2 allocation: artificial3, native2 once, native score once."""
from pathlib import Path
import argparse
import fcntl
import importlib.metadata as metadata
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

import admission
import resource_contract as resource
import scorer
import durable_runner
import server_identity

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
protocol, runner = admission.protocol, scorer.runner


def bind_address(endpoint):
    parsed = urllib.parse.urlsplit(endpoint)
    if parsed.scheme != "http" or parsed.hostname != "127.0.0.1" or parsed.port != 8421 or parsed.path != "/v1" or parsed.username is not None or parsed.password is not None or parsed.query or parsed.fragment:
        raise PermissionError("exact_dedicated_loopback_endpoint_required")
    return parsed.hostname, parsed.port


def owned_local(path, job):
    path = Path(path)
    if path.is_symlink() or path != path.resolve() or path.parent != Path("/tmp") or not path.name.startswith("bio-p19-full2-" + job + "-") or not path.is_dir() or path.stat().st_uid != os.getuid() or path.stat().st_mode & 0o077:
        raise PermissionError("exact_owned_private_local_runtime_required")
    return path


def create_local_runtime(job):
    # Slurm may set TMPDIR and tempfile cache to /tmp/<user>. The reviewed
    # isolation contract requires a direct /tmp child on both exec stages.
    return owned_local(Path(tempfile.mkdtemp(prefix="bio-p19-full2-" + job + "-", dir="/tmp")), job)


def clean_runtime_overrides(environment):
    return {key:value for key,value in environment.items()
            if not key.startswith(("VLLM_", "RAY_"))}


def require_runtime_overrides(environment, ipc):
    expected={"VLLM_NO_USAGE_STATS":"1", "VLLM_USE_V2_MODEL_RUNNER":"0", "VLLM_RPC_BASE_PATH":str(ipc)}
    if ({key:value for key,value in environment.items() if key.startswith("VLLM_")} != expected
            or any(key.startswith("RAY_") for key in environment)):
        raise PermissionError("exact_owned_runtime_overrides_required")


def server_command(local, model, plan):
    host, port = bind_address(plan["endpoint"])
    return [str(local/"python/bin/python3.12"), "-m", "vllm.entrypoints.cli.main", "serve", str(model), "--served-model-name", plan["model"], "--host", host, "--port", str(port), "--dtype", "bfloat16", "--tensor-parallel-size", "1", "--gpu-memory-utilization", "0.95", "--max-model-len", "65536", "--max-num-seqs", "1", "--max-num-batched-tokens", "8192", "--reasoning-parser", "qwen3", "--limit-mm-per-prompt", '{"image":0,"video":0}', "--logits-processors", "p19_literal_logits:P19LiteralLogitsProcessor"]


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--plan",type=Path,required=True);parser.add_argument("--plan-sha",required=True);parser.add_argument("--grant",type=Path);parser.add_argument("--grant-sha");parser.add_argument("--runtime-dir",type=Path);parser.add_argument("--check-only",action="store_true");args=parser.parse_args()
    plan = admission.validate_plan_and_grant(args.plan,args.plan_sha,args.grant,args.grant_sha,require_job=not args.check_only)
    bind_address(plan["endpoint"])
    if args.check_only:
        print(json.dumps({"reviewed_assays":2,"model_calls":0,"runtime_release_required":True}));return
    os.umask(0o077)
    job=os.environ["SLURM_JOB_ID"]
    runtime=Path(plan["runtime_root"]);runtime.mkdir(mode=0o700,exist_ok=True)
    if runtime.is_symlink() or runtime.stat().st_mode & 0o077:
        raise PermissionError("private_runtime_output_required")
    durable_runner.sync_directory(runtime.parent)
    durable_runner.sync_directory(runtime)
    shared=admission.load("p19_full2_vetted_private_runtime",plan["vetted_V06_worker"],extra=Path(plan["vetted_V06_worker"]).parent)
    common=shared.common_module(plan)
    if args.runtime_dir is None:
        lock=(runtime/"allocation.lock").open("a");fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        scorer._exclusive_json(runtime/"allocation_started.json",{"job_id":job,"plan_sha256":args.plan_sha,"engineering_admission_sha256":args.grant_sha,"no_retry":True})
        scorer._exclusive_json(runtime/"resource_at_start.json",resource.fresh_startup_audit(plan))
        if shutil.disk_usage("/tmp").free < 32*1024**3:
            raise PermissionError("private_local_scratch_capacity_required")
        for key in ["base_runtime","cuda_overlay"]:
            admission.regular(plan[key]["path"],plan[key]["sha256"])
        local=create_local_runtime(job)
        with tarfile.open(plan["base_runtime"]["path"]) as archive:archive.extractall(local,filter="data")
        scorer._exclusive_json(runtime/"archive_receipt.json",common.apply_overlay(local))
        env=clean_runtime_overrides(shared.clean_environment(common,local))
        site=admission.load("p19_full2_runtime_site_tools",plan["site_tools_helper"]);env,tools=site.bind_site_tools(env)
        ipc=local/"ipc";ipc.mkdir(mode=0o700)
        env.update(PYTHONPATH=str(HERE),VLLM_NO_USAGE_STATS="1",VLLM_USE_V2_MODEL_RUNNER="0",VLLM_RPC_BASE_PATH=str(ipc),TMPDIR=str(local))
        require_runtime_overrides(env,ipc)
        scorer._exclusive_json(runtime/"site_tool_binding.json",tools)
        scorer._exclusive_json(runtime/"private_runtime_identity.json",{"path":str(local),"job_id":job,"plan_sha256":args.plan_sha,"IPC_path":str(ipc),"short_local_IPC":len(str(ipc))<80})
        shared.install_private_runtime(local/"python/bin/python3.12",env,runtime)
        cpu=dict(env);cpu["CUDA_VISIBLE_DEVICES"]=""
        with (runtime/"installed_API_check.log").open("x") as log:
            subprocess.run([str(local/"python/bin/python3.12"),str(HERE/"check_installed_API.py"),"--plan",str(args.plan),"--output",str(runtime/"installed_API_check.json")],env=cpu,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
        command=[str(local/"python/bin/python3.12"),str(Path(__file__).resolve()),*sys.argv[1:],"--runtime-dir",str(local)]
        os.execve(command[0],command,env)
    local=owned_local(args.runtime_dir,job)
    require_runtime_overrides(os.environ,local/"ipc")
    identity=admission.read(runtime/"private_runtime_identity.json")
    claim=admission.read(runtime/"allocation_started.json")
    if identity.get("path") != str(local) or identity.get("job_id") != job or identity.get("plan_sha256") != args.plan_sha or claim.get("job_id") != job or claim.get("plan_sha256") != args.plan_sha or claim.get("engineering_admission_sha256") != args.grant_sha:
        raise PermissionError("exact_first_stage_allocation_identity_required")
    lock=(runtime/"execution.lock").open("a");fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    scorer._exclusive_json(runtime/"execution_started.json",{"job_id":job,"plan_sha256":args.plan_sha,"no_retry":True})
    if any(os.path.lexists(runtime/key) for key in ["development","benchmark","scoring_attempt_started.json","terminal_receipt.json"]):
        raise PermissionError("prior_or_ambiguous_scientific_phase_no_retry")
    scorer._exclusive_json(runtime/"resource_at_model_start.json",resource.fresh_startup_audit(plan))
    shared.verify_package_identity({"packages":{key:metadata.version(key) for key in shared.PINNED_PACKAGES}})
    import torch
    if torch.cuda.device_count() != 1 or not torch.cuda.is_bf16_supported():
        raise PermissionError("exact_one_native_BF16_GPU_required")
    prop=torch.cuda.get_device_properties(0)
    kind=resource.compatible_GPU(torch.cuda.get_device_name(0),torch.cuda.get_device_capability(0),prop.total_memory)
    scorer._exclusive_json(runtime/"model_environment.json",{"packages":{key:metadata.version(key) for key in shared.PINNED_PACKAGES},"dtype":"bfloat16","tensor_parallel_size":1,"visible_device_count":1,"compatible_GPU_kind":kind,"device_name":torch.cuda.get_device_name(0)})
    model=common.validate_checkpoint(plan["model"],plan["model_revision"])
    if str(model) != plan["model_directory"]:
        raise PermissionError("exact_original_checkpoint_required")
    host,port=bind_address(plan["endpoint"])
    with socket.socket() as probe:probe.bind((host,port))
    server=None
    try:
        command=server_command(local,model,plan)
        with (runtime/"server.log").open("x") as log:
            server=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,cwd=local)
        ticks=common.start_ticks(server.pid)
        def owned():
            if server.poll() is not None or os.environ["SLURM_JOB_ID"]!=job:
                raise PermissionError("exact_owned_server_identity_changed")
            server_identity.process_identity(server.pid,ticks,command,command[0])
            return server_identity.owned_listener(server.pid,ticks,plan["endpoint"])
        opener=durable_runner.OwnedOpener(plan["endpoint"],owned);deadline=time.monotonic()+1800
        while time.monotonic()<deadline:
            if server.poll() is not None:raise RuntimeError("own_server_startup_failed")
            server_identity.process_identity(server.pid,ticks,command,command[0])
            if not server_identity.listener_inodes(plan["endpoint"],server_pid=server.pid):
                time.sleep(3);continue
            owned()
            try:
                with opener.open("http://"+host+":"+str(port)+"/health",timeout=3) as response:
                    if response.status==200:break
            except (OSError,urllib.error.URLError):time.sleep(3)
        else:raise TimeoutError("own_server_readiness_timeout")
        with opener.open(plan["endpoint"]+"/models",timeout=5) as response:models=json.load(response)
        model_identity=server_identity.verify_models_reply(models,plan)
        identity={"pid":server.pid,"proc_start_ticks":ticks,"job_id":job,"hostname":socket.gethostname(),"plan_sha256":args.plan_sha,"endpoint":plan["endpoint"],"model":plan["model"],"revision":plan["model_revision"],"actual_model_identity":model_identity,"launch_process_identity":server_identity.process_identity(server.pid,ticks,command,command[0]),"owned_listener_identity":owned(),"redirects_allowed":False,"durable_scientific_runner_IO":True,"condition":plan["condition"],"dtype":"bfloat16","model_runner":"legacy_V1_explicit","custom_logits_processor":plan["custom_logits_processor"],"plugin_sha256":protocol.sha(HERE/"p19_literal_logits.py")}
        scorer._exclusive_json(runtime/"server_identity.json",identity)
        dev=runner.run_phase(plan=plan,plan_sha=args.plan_sha,endpoint=plan["endpoint"],folder=runtime/"development",phase="development",cases=runner.phase_cases(plan,"development"),assert_owned_server=owned,opener_factory=lambda:durable_runner.OwnedOpener(plan["endpoint"],owned))
        from phase_guard import require_development, require_solver_seal
        require_development(dev,plan["configuration_sha256"],plan["generation"])
        runner.verify_phase(plan,args.plan_sha,runtime/"development","development")
        admission.validate_plan_and_grant(args.plan,args.plan_sha,args.grant,args.grant_sha,require_job=True)
        done=runner.run_phase(plan=plan,plan_sha=args.plan_sha,endpoint=plan["endpoint"],folder=runtime/"benchmark",phase="benchmark",cases=runner.phase_cases(plan,"benchmark"),assert_owned_server=owned,opener_factory=lambda:durable_runner.OwnedOpener(plan["endpoint"],owned))
        require_solver_seal(done,plan["configuration_sha256"],plan["generation"])
        runner.verify_phase(plan,args.plan_sha,runtime/"benchmark","benchmark")
        os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=60)
        scorer._exclusive_json(runtime/"server_terminal.json",{"own_server_stopped":True})
        admission.validate_plan_and_grant(args.plan,args.plan_sha,args.grant,args.grant_sha,require_job=True,allow_scoring=True)
        scorer._exclusive_json(runtime/"scoring_attempt_started.json",{"prediction_lock_sha256":done["prediction_lock_sha256"],"protected_targets_not_yet_read":True,"sole_attempt":True})
        with (runtime/"native_scoring.log").open("x") as log:
            subprocess.run([sys.executable,str(HERE/"scorer.py"),"--plan",str(args.plan),"--plan-sha",args.plan_sha,"--grant",str(args.grant),"--grant-sha",args.grant_sha,"--run",str(runtime/"benchmark")],env=dict(os.environ,CUDA_VISIBLE_DEVICES=""),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=7200)
        result=admission.read(runtime/"benchmark/scores.json")
        scorer._exclusive_json(runtime/"terminal_receipt.json",{"task_id":"P19","job_id":job,"plan_sha256":args.plan_sha,"condition":protocol.CONDITION,"planned_assays":2,"case_ids":plan["case_ids"],"prediction_lock_sha256":done["prediction_lock_sha256"],"native_score_sha256":protocol.sha(runtime/"benchmark/scores.json"),"native_scoring_status":result["native_scoring_status"],"native_metrics":result["native_metrics"],"full_native123_complete":False,"prior34_9_2_1_separate":True})
    finally:
        if server is not None and server.poll() is None:
            os.killpg(server.pid,signal.SIGTERM)
            try:server.wait(timeout=60)
            except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait(timeout=10)
        if not (runtime/"server_terminal.json").exists():scorer._exclusive_json(runtime/"server_terminal.json",{"own_server_stopped":True,"server_never_started":server is None})


if __name__ == "__main__":
    try:main()
    except BaseException as error:
        # Never interpolate exception bodies: inputs/targets may occur in library errors.
        runtime=HERE/"runtime"
        if runtime.is_dir() and not (runtime/"failed_or_interrupted.json").exists():
            scorer._exclusive_json(runtime/"failed_or_interrupted.json",{"error_type":type(error).__name__,"no_retry":True,"missing_progress_is_not_zero_attempts":True})
        print(json.dumps({"error_code":"P19_FULL2_execution_stopped_preserve_all_attempts_no_retry","error_type":type(error).__name__}))
        raise SystemExit(2)
