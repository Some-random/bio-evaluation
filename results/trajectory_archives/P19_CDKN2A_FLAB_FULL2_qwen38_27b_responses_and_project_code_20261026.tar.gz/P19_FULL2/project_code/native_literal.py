"""Prospective literal native T1 constraints; no source, target or model IO.

The original text and declared length are independent immutable inputs. Positions
are literal Python string indices, bounded by the native declared Length. No
character is removed/replaced and no biological meaning is assigned to symbols.
The accepted Parkin JSON/prefix/EOS machine is reused without alteration.
"""
import copy
import hashlib
import json

from unique40_core import Unique40Language, RequestConstraint, ConstraintError, COUNT
from generation_contract import AMINO_ACIDS, GenerationAudit, MUTATION, unique_object, GENERATION

CONDITION = 'PFARENA_T1_LITERAL_NATIVE_DECLARED_INDEX_UNIQUE40_V1'


class LiteralNativeLanguage(Unique40Language):
    def __init__(self, sequence, declared_length):
        if not isinstance(sequence, str) or type(declared_length) is not int or declared_length <= 0:
            raise ConstraintError('literal_native_string_and_positive_declared_integer_required')
        # Exactly the three native prompt predicates: standard WT/MUT letters,
        # position<=Length and WT==wildtype_sequence[position-1]. No cleanup.
        self.allowed = frozenset(
            f'{before}{position}{after}'
            for position, before in enumerate(sequence, 1)
            if position <= declared_length and before in AMINO_ACIDS
            for after in AMINO_ACIDS if after != before
        )
        if len(self.allowed) < COUNT:
            raise ConstraintError('fewer_than40_literal_native_valid_substitutions_no_fallback')
        prefixes = {}
        for mutation in self.allowed:
            for length in range(1, len(mutation) + 1):
                prefixes.setdefault(mutation[:length], set()).add(mutation)
        self.by_prefix = {key: frozenset(values) for key, values in prefixes.items()}


class LiteralRequestConstraint(RequestConstraint):
    def __init__(self, sequence, declared_length, vocabulary):
        self.language = LiteralNativeLanguage(sequence, declared_length)
        self.vocabulary = vocabulary
        from unique40_core import State
        self.state = State()
        self.output_ids = []
        self.eos_seen = False


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def audit_delivery(sequence, declared_length, final):
    language = LiteralNativeLanguage(sequence, declared_length)
    if not isinstance(final, str):
        return GenerationAudit(False, None, ('final_not_text',), None)
    try:
        value = json.loads(final, object_pairs_hook=unique_object)
    except (ValueError, TypeError):
        return GenerationAudit(False, None, ('invalid_or_duplicate_key_json',), None)
    if not isinstance(value, dict) or set(value) != {'ranking'}:
        return GenerationAudit(False, None, ('unexpected_object_schema',), None)
    ranking = value['ranking']
    if not isinstance(ranking, list):
        return GenerationAudit(False, None, ('ranking_not_list',), None)
    errors = []
    if len(ranking) != 40:
        errors.append('ranking_size_not_40')
    seen = set()
    for index, mutation in enumerate(ranking):
        match = MUTATION.fullmatch(mutation) if isinstance(mutation, str) else None
        if not match:
            errors.append(f'malformed_mutation:{index}')
            continue
        before, position, after = match.groups()
        position = int(position)
        if not 1 <= position <= declared_length or position > len(sequence):
            errors.append(f'position_out_of_range:{index}')
        elif before != sequence[position - 1]:
            errors.append(f'wildtype_mismatch:{index}')
        if before == after:
            errors.append(f'no_op:{index}')
        if mutation in seen:
            errors.append(f'duplicate_mutation:{index}')
        seen.add(mutation)
    return GenerationAudit(not errors, len(ranking), tuple(errors),
                           tuple(ranking) if all(isinstance(x, str) for x in ranking) else None)


def bound_request(case, context, *, case_sha256, context_sha256, base_generation_sha256):
    for value, expected in ((case, case_sha256), (context, context_sha256), (GENERATION, base_generation_sha256)):
        if canonical_hash(value) != expected:
            raise ValueError('changed_frozen_case_context_or_generation')
    if set(case) != {'task_id', 'case_id', 'messages'} or case['task_id'] != 'P19':
        raise ValueError('exact_P19_case_fields_required')
    if set(context) != {'case_id', 'wildtype_sequence', 'sequence_length'} or context['case_id'] != case['case_id']:
        raise ValueError('exact_native_context_identity_required')
    messages = case['messages']
    if len(messages) != 1 or set(messages[0]) != {'role', 'content'} or messages[0]['role'] != 'user':
        raise ValueError('single_fresh_native_user_message_required')
    sequence, length = context['wildtype_sequence'], context['sequence_length']
    language = LiteralNativeLanguage(sequence, length)
    if '`' + sequence + '`' not in messages[0]['content'] or f'(Length: {length})' not in messages[0]['content']:
        raise ValueError('whole_native_reference_and_declared_length_not_in_message')
    request = {'model': 'Qwen/Qwen3.8-27B', 'messages': copy.deepcopy(messages), **copy.deepcopy(GENERATION)}
    request['structured_outputs'] = {'json': {'type': 'object', 'properties': {'ranking': {
        'type': 'array', 'minItems': 40, 'maxItems': 40,
        'items': {'type': 'string', 'enum': sorted(language.allowed)}}},
        'required': ['ranking'], 'additionalProperties': False}}
    request['vllm_xargs'] = {'p19_unique40_condition': CONDITION,
                             'p19_unique40_sequence': sequence,
                             'p19_unique40_sequence_sha256': hashlib.sha256(sequence.encode()).hexdigest(),
                             'p19_unique40_declared_length': str(length)}
    return request
