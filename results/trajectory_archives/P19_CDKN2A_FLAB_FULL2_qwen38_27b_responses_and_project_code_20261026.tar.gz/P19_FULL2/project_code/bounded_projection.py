"""Non-owning seekable binary window over one verified retained descriptor.

Every returned byte belongs to [0, expected_bytes). No detection byte is needed:
the caller's descriptor/path identity check runs before and after physical reads,
and reads are clipped to the admitted remaining window even during a race.
BufferedReader/TextIOWrapper may wrap this view; neither can prefetch beyond it.
No path or source descriptor is opened, replaced or closed by this primitive.
"""
import io
import os


class SourceIntegrityError(ValueError):
    pass


class ProjectionReadLimitError(SourceIntegrityError):
    pass


class BoundedSourceWindow(io.RawIOBase):
    def __init__(self, source, expected_bytes, check_identity):
        super().__init__()
        if (type(expected_bytes) is not int or expected_bytes < 0 or not callable(check_identity)
                or not isinstance(source, io.RawIOBase) or isinstance(source, (io.BufferedIOBase, io.TextIOBase))):
            raise ProjectionReadLimitError('projection_window_contract_invalid')
        self._source = source
        self._expected = expected_bytes
        self._position = 0
        self._check_identity = check_identity
        self._failure = None
        self.bytes_returned = 0
        self.detection_bytes = 0

    def _check(self):
        if self.closed:
            raise ValueError('projection_window_closed')
        if self._failure is not None:
            raise ProjectionReadLimitError(self._failure)
        self._check_identity()

    def _fail(self, code):
        self._failure = code
        raise ProjectionReadLimitError(code)

    def readable(self):return True
    def seekable(self):return True
    def writable(self):return False

    def fileno(self):
        # Owner identity inspection only; no unbounded FileIO object is exposed.
        self._check();return self._source.fileno()

    def tell(self):
        self._check();return self._position

    def seek(self, offset, whence=os.SEEK_SET):
        self._check()
        if type(offset) is not int or whence not in (os.SEEK_SET, os.SEEK_CUR, os.SEEK_END):
            self._fail('projection_seek_contract_invalid')
        position = offset + (0 if whence == os.SEEK_SET else self._position if whence == os.SEEK_CUR else self._expected)
        if not 0 <= position <= self._expected:
            self._fail('projection_seek_outside_admitted_window')
        self._position = position
        self._check_identity()
        return position

    def readinto(self, buffer):
        self._check()
        if len(buffer) == 0:
            return 0
        remaining = self._expected - self._position
        if remaining == 0:
            self._check_identity()
            return 0
        wanted = min(len(buffer), remaining, 65536)
        self._source.seek(self._position, os.SEEK_SET)
        chunk = self._source.read(wanted)
        if not isinstance(chunk, bytes) or len(chunk) > wanted:
            self._fail('projection_binary_stream_contract')
        if not chunk:
            self._fail('projection_early_EOF')
        # Detect truncation/growth before even the clipped prefix is returned.
        self._check_identity()
        buffer[:len(chunk)] = chunk
        self._position += len(chunk)
        self.bytes_returned += len(chunk)
        return len(chunk)

    # IOBase.close marks only this non-owning view closed. It never closes the
    # private retained descriptor; the owner keeps it for later hash/stat checks.
