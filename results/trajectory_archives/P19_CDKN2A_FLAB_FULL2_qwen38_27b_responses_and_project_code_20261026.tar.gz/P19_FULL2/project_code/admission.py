"""Exact FULL2 engineering gate; root science delegates only after peer admission.

Imports never read inputs, protected targets, checkpoint weights or scheduler
state. The prospective packet and both original CPU preparations stay immutable.
"""
from pathlib import Path
import importlib.util
import os
import re
import sys
from types import SimpleNamespace

from io_contract import read, sha, regular
from phase_guard import CASE_IDS

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
SCIENCE = HERE.parent/'first2_prospective_native_protocol_20261026_v1'
SCIENCE_SHA = 'b6486ff787eb051353b634a8cf64d5f6dd511cba23a37fe6b8691db5b7d6d9cc'
CONFIG_SHA = '0936775f3534e6ef0811700548f1b962931113bacee698278f4521ed2d9fe699'
OWNER = '/root/main_docs_refresh/p13_downstream_source_map'
REVIEWERS = ('/root/remaining_scope_audit','/root/independent_review','/root/classification_docs_review')
CONDITION = 'PFARENA_T1_FULL2_CDKN2A_FLAB_NATIVE_LITERAL_INDEX_UNIQUE40_V1'
protocol = SimpleNamespace(sha=sha, CONDITION=CONDITION, MODEL='Qwen/Qwen3.8-27B')


def load(name, path, dependencies=None, extra=None):
    if extra is not None:
        sys.path.append(str(extra))
    previous = {key:sys.modules.get(key) for key in (dependencies or {})}
    sys.modules.update(dependencies or {})
    try:
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec);sys.modules[name]=module
        spec.loader.exec_module(module)
        return module
    finally:
        for key, value in previous.items():
            if value is None:sys.modules.pop(key,None)
            else:sys.modules[key]=value


def require_completion_delegation(science):
    value = science.get('conditional_existing_scope_completion', {})
    expected = {'owner':OWNER, 'after_exact_independent_runtime_admission_only':True,
                'allowed_named_peers':list(REVIEWERS), 'independent_peer_must_not_author_implementation':True,
                'no_additional_routine_user_or_root_permission_turn':True,
                'fresh_three_artificial_controls_all_pass_before_native':True,
                'full_two_original_attempts_maximum':2,
                'fresh_shared_lock_project_requested_running_pending_unknown_GPU_ceiling':8,
                'correct_plugin_class':'p19_literal_logits:P19LiteralLogitsProcessor',
                'native_scoring_once_after_full2_seal_and_valid_original_durable_claim_only':True}
    if any(value.get(k)!=v for k,v in expected.items()):
        raise PermissionError('exact_root_conditional_completion_delegation_required')
    return value


def grant_values(plan_sha):
    return {'role':'independent_exact_P19_FULL2_engineering_runtime_admission',
            'approved':True, 'admitted':True, 'owner':OWNER, 'task_id':'P19', 'condition':CONDITION,
            'plan_sha256':plan_sha, 'configuration_sha256':CONFIG_SHA,
            'root_scientific_adoption_sha256':SCIENCE_SHA, 'case_ids':list(CASE_IDS),
            'gpu_count':1, 'project_gpu_ceiling':8, 'development_planned':3,
            'one_submission_only':True, 'one_attempt_per_case':True, 'automatic_retry':False,
            'automatic_resume':False, 'allow_once_scoring_after_full_seal':True,
            'protected_target_source_access_after_full_solver_lock_and_sole_native_claim':True,
            'strict_delivery_failure_metrics_undefined_no_target_access':True,
            'delegated_operational_release_under_root_adoption':True,
            'may_clear_this_new_STOP_only_after_operational_release':True,
            'new_training':False, 'paid_model_calls':False}


def validate_operational_release(plan_sha, grant_sha):
    regular(SCIENCE/'root_scientific_adoption.json',SCIENCE_SHA)
    science=read(SCIENCE/'root_scientific_adoption.json');require_completion_delegation(science)
    regular(HERE/'engineering_admission.json',grant_sha)
    release=read(HERE/'engineering_admission.json')
    if release.get('reviewer') not in REVIEWERS or any(release.get(k)!=v for k,v in grant_values(plan_sha).items()):
        raise PermissionError('exact_independent_FULL2_runtime_release_required')
    return release


def validate_plan_and_grant(plan_path, plan_sha, grant_path=None, grant_sha=None, *, require_job=False, allow_scoring=False):
    if Path(plan_path)!=HERE/'plan.json' or not re.fullmatch('[0-9a-f]{64}',plan_sha):
        raise PermissionError('exact_frozen_execution_plan_path_and_digest_required')
    regular(plan_path,plan_sha);plan=read(plan_path)
    expected={'task_id':'P19','owner':OWNER,'condition':CONDITION,'case_ids':list(CASE_IDS),
              'planned':2,'development_planned':3,'concurrency':1,'gpus_requested':1,
              'project_gpu_ceiling':8,'precision':'BF16','tensor_parallel_size':1,
              'context_limit':65536,'model':protocol.MODEL,
              'model_revision':'1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0',
              'configuration':str(SCIENCE/'configuration_candidate.json'),
              'configuration_sha256':CONFIG_SHA,'root_scientific_adoption':str(SCIENCE/'root_scientific_adoption.json'),
              'root_scientific_adoption_sha256':SCIENCE_SHA,'endpoint':'http://127.0.0.1:8421/v1',
              'runtime_root':str(HERE/'runtime'),'custom_logits_processor':'p19_literal_logits:P19LiteralLogitsProcessor',
              'automatic_retries':False,'automatic_resume':False,'full_native123_complete':False,
              'new_training':False,'paid_model_calls':False,'scores_pooled':False}
    if any(plan.get(k)!=v for k,v in expected.items()):
        raise PermissionError('exact_adopted_FULL2_runtime_condition_required')
    for path,digest in plan['frozen_files_sha256'].items():regular(path,digest)
    regular(plan['configuration'],CONFIG_SHA);configuration=read(plan['configuration'])
    regular(plan['root_scientific_adoption'],SCIENCE_SHA);science=read(plan['root_scientific_adoption'])
    if (science.get('adopted') is not True or science.get('issuer')!='/root' or science.get('configuration_sha256')!=CONFIG_SHA
            or science.get('case_ids')!=list(CASE_IDS) or science.get('condition')!=CONDITION):
        raise PermissionError('exact_root_scientific_adoption_required')
    require_completion_delegation(science)
    if plan['generation']!=configuration['generation'] or plan['protected_targets']!=configuration['protected_targets']:
        raise PermissionError('unchanged_native_generation_and_target_descriptors_required')
    if plan['source_objective_qualifications']!=science['source_objective_qualifications']:
        raise PermissionError('both_native_context_qualifications_required')
    if not grant_path:
        if require_job or allow_scoring:raise PermissionError('independent_runtime_admission_missing')
        return plan
    if Path(grant_path)!=HERE/'engineering_admission.json':raise PermissionError('exact_runtime_admission_path_required')
    validate_operational_release(plan_sha,grant_sha)
    if require_job:
        job=os.environ.get('SLURM_JOB_ID','')
        if not job.isdigit():raise PermissionError('actual_own_allocation_required')
        regular(HERE/'submission_receipt.json');receipt=read(HERE/'submission_receipt.json')
        if any(receipt.get(k)!=v for k,v in {'job_id':job,'plan_sha256':plan_sha,'engineering_admission_sha256':grant_sha,'submitted_GPUs':1}.items()):
            raise PermissionError('exact_once_submission_binding_required')
        if os.path.lexists(HERE/'STOP'):raise PermissionError('new_execution_STOP_present')
        regular(HERE/'STOP_clearance_receipt.json');clearance=read(HERE/'STOP_clearance_receipt.json')
        expected={'role':'exact_P19_FULL2_new_STOP_clearance_only','plan_sha256':plan_sha,
                  'engineering_admission_sha256':grant_sha,'operational_release_sha256':grant_sha,
                  'removed_STOP_sha256':plan['new_scheduling_STOP_sha256'],'legacy_STOPs_unchanged':True}
        if any(clearance.get(k)!=v for k,v in expected.items()):raise PermissionError('exact_STOP_clearance_binding_required')
    return plan
