"""Pin one canonical regular-file descriptor for hashing and permitted reads.

This module defines no biological parser, model, target or network interface.
Only an already admitted caller supplies an exact path and expected SHA256.
"""
from contextlib import contextmanager
import hashlib
import io
import os
from pathlib import Path
import stat

from bounded_projection import BoundedSourceWindow, ProjectionReadLimitError, SourceIntegrityError


def file_signature(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_uid, value.st_gid,
            value.st_nlink, value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def descriptor_hash(stream, maximum_bytes):
    if isinstance(stream, io.TextIOBase) or (isinstance(stream, io.BufferedIOBase) and not isinstance(stream, io.BytesIO)):
        raise SourceIntegrityError("source_unbuffered_hash_stream_required")
    if type(maximum_bytes) is not int or maximum_bytes < 0:
        raise SourceIntegrityError("source_declared_byte_limit_invalid")
    stream.seek(0)
    digest = hashlib.sha256()
    seen = 0
    while seen < maximum_bytes:
        wanted = min(65536, maximum_bytes - seen)
        chunk = stream.read(wanted)
        if not isinstance(chunk, bytes) or len(chunk) > wanted:
            raise SourceIntegrityError("source_descriptor_read_contract_invalid")
        if not chunk:
            raise SourceIntegrityError("source_descriptor_early_EOF")
        seen += len(chunk)
        digest.update(chunk)
    stream.seek(0)
    return digest.hexdigest()


class StableSource:
    def __init__(self, path, expected_sha256, expected_bytes, expected_owner_uid):
        self.path = Path(path)
        self.expected = expected_sha256
        if type(expected_bytes) is not int or expected_bytes <= 0:
            raise SourceIntegrityError("source_declared_byte_limit_invalid")
        self.expected_bytes = expected_bytes
        self.expected_owner_uid = expected_owner_uid
        self.stream = None
        self._raw_stream = None
        self.parent_fd = None
        self.initial = None

    def _path_identity(self):
        if self.path.resolve(strict=True) != self.path:
            raise SourceIntegrityError("source_path_not_canonical")
        source = os.stat(self.path, follow_symlinks=False)
        parent = os.stat(self.path.parent, follow_symlinks=False)
        held_parent = os.fstat(self.parent_fd)
        if (parent.st_dev, parent.st_ino) != (held_parent.st_dev, held_parent.st_ino):
            raise SourceIntegrityError("source_parent_identity_changed")
        if not stat.S_ISREG(source.st_mode) or file_signature(source) != self.initial:
            raise SourceIntegrityError("source_path_identity_or_stat_changed")

    def _check_identity_only(self):
        if self._raw_stream is None or file_signature(os.fstat(self._raw_stream.fileno())) != self.initial:
            raise SourceIntegrityError("source_descriptor_identity_or_stat_changed")
        self._path_identity()

    def _bounded_window(self):
        return BoundedSourceWindow(self._raw_stream, self.expected_bytes, self._check_identity_only)

    def __enter__(self):
        if not self.path.is_absolute() or self.path.resolve(strict=True) != self.path:
            raise SourceIntegrityError("source_path_not_canonical")
        parent_fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
        raw_fd = None
        try:
            # No ancestor or final component may be a symbolic link. Retain the
            # parent descriptor too, so replacing an ancestor cannot redirect us.
            for part in self.path.parts[1:-1]:
                following = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                                    dir_fd=parent_fd)
                os.close(parent_fd)
                parent_fd = following
            self.parent_fd = parent_fd
            raw_fd = os.open(self.path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK,
                             dir_fd=parent_fd)
            status = os.fstat(raw_fd)
            if not stat.S_ISREG(status.st_mode):
                raise SourceIntegrityError("source_descriptor_not_regular_file")
            mode = stat.S_IMODE(status.st_mode)
            if (status.st_size != self.expected_bytes or status.st_uid != self.expected_owner_uid
                    or status.st_nlink != 1 or not mode & 0o400 or mode & 0o133):
                raise SourceIntegrityError("source_descriptor_owner_mode_link_or_size_policy")
            self.initial = file_signature(status)
            self._raw_stream = os.fdopen(raw_fd, "rb", buffering=0)
            raw_fd = None
            if not isinstance(self._raw_stream, io.RawIOBase) or isinstance(self._raw_stream, (io.BufferedIOBase, io.TextIOBase)):
                raise SourceIntegrityError("source_unbuffered_descriptor_required")
            self._path_identity()
            if descriptor_hash(self._raw_stream, self.expected_bytes) != self.expected:
                raise SourceIntegrityError("source_descriptor_hash_mismatch")
            if file_signature(os.fstat(self._raw_stream.fileno())) != self.initial:
                raise SourceIntegrityError("source_descriptor_changed_while_hashing")
            self._path_identity()
            # Every consumer, including seekable archive readers, receives a
            # bounded facade rather than the private unbuffered descriptor.
            self.stream = io.BufferedReader(self._bounded_window(), buffer_size=65536)
            return self
        except BaseException:
            if raw_fd is not None:
                os.close(raw_fd)
            if self.stream is not None:
                self.stream.close()
                self.stream = None
            if self._raw_stream is not None:
                self._raw_stream.close()
                self._raw_stream = None
            os.close(parent_fd)
            self.parent_fd = None
            raise

    def verify(self):
        self._check_identity_only()
        if descriptor_hash(self._raw_stream, self.expected_bytes) != self.expected:
            raise SourceIntegrityError("source_descriptor_hash_changed")
        if file_signature(os.fstat(self._raw_stream.fileno())) != self.initial:
            raise SourceIntegrityError("source_descriptor_changed_while_hashing")
        self._path_identity()

    @contextmanager
    def text_reader(self):
        # Reject changes since initial hashing before granting a text view.
        self.verify()
        bounded = self._bounded_window()
        buffered = io.BufferedReader(bounded, buffer_size=8192)
        text = io.TextIOWrapper(buffered, encoding="utf-8", newline="")
        try:
            try:
                yield text
            except ProjectionReadLimitError:
                raise SourceIntegrityError("source_projection_byte_bound_or_EOF_violation") from None
            # This also detects changes if a consumer ends a projection early.
            self.verify()
        finally:
            if not text.closed:
                text.detach()
            buffered.close()

    def binding(self):
        return {"path": str(self.path), "sha256": self.expected,
                "verified_same_regular_descriptor": True,
                "verified_identity_stat": dict(zip(
                    ["device", "inode", "mode", "uid", "gid", "links", "bytes", "mtime_ns", "ctime_ns"],
                    self.initial))}

    def __exit__(self, kind, value, traceback):
        # Callers verify after the last permitted read and immediately before
        # committing success. Closing must not invent a success after failure.
        try:
            if self.stream is not None:
                self.stream.close()
        finally:
            try:
                if self._raw_stream is not None:
                    self._raw_stream.close()
            finally:
                if self.parent_fd is not None:
                    os.close(self.parent_fd)
                self.stream = None
                self._raw_stream = None
                self.parent_fd = None

