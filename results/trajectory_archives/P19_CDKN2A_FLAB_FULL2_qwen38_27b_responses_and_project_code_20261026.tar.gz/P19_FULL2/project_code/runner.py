"""Exact adopted FULL2 and artificial3, sequential once-only loopback delivery.

No targets, labels or source CSVs are available to this runner. Native messages
and independent declared lengths are passed unchanged to the reviewed adapter.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import urllib.error
import urllib.request

from io_contract import read, sha, save, write_bytes, private_directory, exact_members
from native_literal import bound_request, audit_delivery, canonical_hash
from phase_guard import CASE_IDS

MAX_CAPTURE_BYTES = 8 * 1024 * 1024


def now():
    return datetime.now(timezone.utc).isoformat()


def phase_cases(plan, phase):
    if phase not in ('development', 'benchmark'):
        raise ValueError('exact_phase_required')
    configuration = read(plan['configuration'])
    info = configuration['phases'][phase]
    if sha(info['input_file']) != info['input_sha256'] or sha(info['context_file']) != info['context_sha256']:
        raise PermissionError('exact_accepted_private_input_bindings_required')
    cases = [json.loads(line) for line in Path(info['input_file']).read_bytes().splitlines()]
    contexts = read(info['context_file'])['cases']
    expected = 3 if phase == 'development' else 2
    if len(cases) != expected or [c['case_id'] for c in cases] != [c['case_id'] for c in contexts]:
        raise PermissionError('complete_ordered_phase_required')
    if phase == 'benchmark' and [c['case_id'] for c in cases] != list(CASE_IDS):
        raise PermissionError('exact_FULL2_only')
    ledger = {x['case_id']:x for x in read(plan['CPU_context_evidence'])['counts'] if x['phase'] == phase}
    result = []
    for case, context in zip(cases, contexts):
        payload = bound_request(case, context, **info['case_bindings'][case['case_id']])
        if canonical_hash(payload) != ledger[case['case_id']]['request_sha256']:
            raise PermissionError('reviewed_CPU_payload_hash_required')
        result.append({'case_id':case['case_id'], 'payload':payload, 'context':context})
    return result


def outcome_from_raw(raw, context):
    result = {'status':'response_error', 'delivery_passed':False, 'response_errors':1,
              'truncated':False, 'empty_final':False, 'refusal':False, 'reasoning_present':False,
              'tool_calls_present':False, 'final_observed':False, 'ranking':None}
    try:
        body = json.loads(raw)
        if not isinstance(body, dict) or len(body.get('choices', [])) != 1:
            return result
        choice = body['choices'][0];message = choice['message'];final = message.get('content')
        audit = audit_delivery(context['wildtype_sequence'], context['sequence_length'], final)
        result.update(finish_reason=choice.get('finish_reason'), truncated=choice.get('finish_reason') == 'length',
                      empty_final=not isinstance(final, str) or not final.strip(),
                      refusal=bool(message.get('refusal')),
                      reasoning_present=bool(message.get('reasoning') or message.get('reasoning_content')),
                      tool_calls_present=bool(message.get('tool_calls')), final_observed='content' in message,
                      generation_contract=audit.to_dict(), ranking=list(audit.ranking) if audit.ranking is not None else None)
        passed = (choice.get('finish_reason') == 'stop' and audit.delivery_passed and
                  not any(result[k] for k in ('refusal', 'reasoning_present', 'tool_calls_present')))
        result.update(delivery_passed=bool(passed), response_errors=0,
                      status='delivered' if passed else 'invalid_delivery')
        return result
    except (ValueError, TypeError, KeyError, AttributeError, IndexError):
        return result


def summarize(outcomes):
    return {'planned':len(outcomes), 'terminal':len(outcomes),
            'attempted_confirmed':sum(x.get('attempted') is True for x in outcomes),
            'not_dispatched':sum(x.get('not_dispatched') is True for x in outcomes),
            'responses_saved':sum(x.get('response_saved') is True for x in outcomes),
            'delivery_passed':sum(x.get('delivery_passed') is True for x in outcomes),
            **{key:sum(bool(x.get(key)) for x in outcomes) for key in
               ('transport_errors','http_errors','response_errors','ambiguous_attempts','truncations','empty_finals','refusals','reasoning_present')}}


def run_phase(*, plan, plan_sha, endpoint, folder, phase, cases, assert_owned_server, opener_factory):
    folder = private_directory(folder)
    for name in ('requests', 'responses', 'outcomes'):
        private_directory(folder / name)
    if len(cases) != (3 if phase == 'development' else 2) or len({x['case_id'] for x in cases}) != len(cases):
        raise PermissionError('complete_exact_phase_required')
    outcomes = [];halted = False
    for case in cases:
        key = hashlib.sha256(case['case_id'].encode()).hexdigest()
        base = {'case_id':case['case_id'], 'attempted':False, 'not_dispatched':True,
                'delivery_passed':False, 'response_saved':False}
        if halted:
            result = {**base, 'status':'not_dispatched_after_fatal_failure'}
        else:
            assert_owned_server()
            payload = case['payload'];wire = json.dumps(payload, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
            # This exclusive request claim and its exact wire body are fsynced
            # before constructing the only POST. Any interruption blocks replay.
            save(folder/'requests'/(key+'.json'), {'case_id':case['case_id'], 'payload':payload,
                 'wire_sha256':hashlib.sha256(wire).hexdigest(), 'plan_sha256':plan_sha})
            request = urllib.request.Request(endpoint+'/chat/completions', data=wire, headers={'Content-Type':'application/json'})
            try:
                with opener_factory().open(request, timeout=1200) as response:
                    raw = response.read(MAX_CAPTURE_BYTES + 1)
                write_bytes(folder/'responses'/(key+'.raw.json'), raw)
                result = outcome_from_raw(raw, case['context']) if len(raw) <= MAX_CAPTURE_BYTES else {'status':'response_size_exceeded','response_errors':1,'delivery_passed':False,'raw_capture_complete':False}
                result.update(response_saved=True, raw_sha256=hashlib.sha256(raw).hexdigest())
            except urllib.error.HTTPError as error:
                raw = error.read(MAX_CAPTURE_BYTES + 1)
                write_bytes(folder/'responses'/(key+'.http_error.raw'), raw)
                result = {'status':'http_error', 'http_errors':1, 'http_status':error.code,
                          'delivery_passed':False, 'response_saved':False, 'ambiguous_attempts':1}
            except (urllib.error.URLError, TimeoutError, OSError) as error:
                result = {'status':'transport_error', 'transport_errors':1, 'error_type':type(error).__name__,
                          'delivery_passed':False, 'response_saved':False, 'ambiguous_attempts':1}
            result.update(case_id=case['case_id'], attempted=True, not_dispatched=False)
            # Invalid biological output/truncation remains terminal; only the
            # adopted fatal transport/response/refusal policy stops new native
            # requests. Every failed artificial delivery blocks native phase.
            halted = (phase == 'development' and not result.get('delivery_passed') or
                      result['status'] in ('transport_error','http_error','response_error','response_size_exceeded') or
                      bool(result.get('refusal')))
        result['truncations'] = bool(result.get('truncated'))
        result['refusals'] = bool(result.get('refusal'))
        result['empty_finals'] = bool(result.get('empty_final'))
        save(folder/'outcomes'/(key+'.json'), result);outcomes.append(result)
    members = {str(p.relative_to(folder)):sha(p) for base in ('requests','responses','outcomes') for p in sorted((folder/base).iterdir())}
    lock = {'task_id':'P19', 'phase':phase, 'plan_sha256':plan_sha,
            'configuration_sha256':plan['configuration_sha256'], 'case_ids':[x['case_id'] for x in cases],
            'reference_labels_opened':False, 'files_sha256':members}
    save(folder/'prediction_lock.json', lock)
    done = {'task_id':'P19', 'phase':phase, 'at_utc':now(), 'plan_sha256':plan_sha,
            'configuration_sha256':plan['configuration_sha256'], 'generation':plan['generation'],
            'case_ids':lock['case_ids'], **summarize(outcomes),
            'prediction_lock_sha256':sha(folder/'prediction_lock.json'), 'protected_targets_opened':False,
            'biological_correctness_assessed':False, 'no_retries':True,
            'artificial_exact_copy_gate_passed':all(x.get('delivery_passed') for x in outcomes) if phase == 'development' else None}
    save(folder/'completion.json', done)
    return done


def verify_phase(plan, plan_sha, folder, phase):
    """Recompute original wire/raw/outcome evidence, with no target access."""
    folder = Path(folder);done = read(folder/'completion.json');lock = read(folder/'prediction_lock.json')
    cases = phase_cases(plan, phase)
    if (done.get('plan_sha256') != plan_sha or lock.get('plan_sha256') != plan_sha or
            done.get('phase') != phase or lock.get('phase') != phase or
            done.get('configuration_sha256') != plan['configuration_sha256'] or
            lock.get('configuration_sha256') != plan['configuration_sha256'] or
            done.get('generation') != plan['generation'] or lock.get('reference_labels_opened') is not False or
            done.get('prediction_lock_sha256') != sha(folder/'prediction_lock.json') or
            done.get('case_ids') != [x['case_id'] for x in cases] or lock.get('case_ids') != done['case_ids']):
        raise PermissionError('exact_original_phase_seal_required')
    exact_members(folder, lock['files_sha256']);outcomes=[];halted=False
    expected_members=set()
    for case in cases:
        key=hashlib.sha256(case['case_id'].encode()).hexdigest();name='outcomes/'+key+'.json';expected_members.add(name)
        outcome=read(folder/name)
        if outcome.get('case_id') != case['case_id']:
            raise PermissionError('outcome_identity_mismatch')
        if halted:
            if outcome != {'case_id':case['case_id'],'attempted':False,'not_dispatched':True,
                           'delivery_passed':False,'response_saved':False,
                           'status':'not_dispatched_after_fatal_failure','truncations':False,'refusals':False,'empty_finals':False}:
                raise PermissionError('no_postfatal_or_unclaimed_request_permitted')
        else:
            request_name='requests/'+key+'.json';expected_members.add(request_name);request=read(folder/request_name)
            wire=json.dumps(case['payload'],ensure_ascii=False,separators=(',', ':'),allow_nan=False).encode()
            if request != {'case_id':case['case_id'],'payload':case['payload'],'wire_sha256':hashlib.sha256(wire).hexdigest(),'plan_sha256':plan_sha} or outcome.get('attempted') is not True or outcome.get('not_dispatched') is not False:
                raise PermissionError('original_exact_request_claim_required')
            if outcome.get('response_saved'):
                raw_name='responses/'+key+'.raw.json';expected_members.add(raw_name);raw=(folder/raw_name).read_bytes()
                if len(raw)>MAX_CAPTURE_BYTES:
                    if outcome.get('status')!='response_size_exceeded':raise PermissionError('raw_size_binding')
                else:
                    parsed=outcome_from_raw(raw,case['context'])
                    # The audit dataclass has tuple fields; persisted JSON has
                    # arrays. Compare their canonical JSON representations.
                    if canonical_hash({k:outcome.get(k) for k in parsed})!=canonical_hash(parsed):
                        raise PermissionError('original_raw_outcome_mismatch')
                if outcome.get('raw_sha256')!=hashlib.sha256(raw).hexdigest():raise PermissionError('original_raw_hash_mismatch')
            elif outcome.get('status')=='http_error':
                expected_members.add('responses/'+key+'.http_error.raw')
                if (outcome.get('delivery_passed') is not False or outcome.get('http_errors')!=1 or
                        outcome.get('ambiguous_attempts')!=1 or type(outcome.get('http_status')) is not int or
                        outcome.get('ranking') is not None):raise PermissionError('explicit_HTTP_failure_required')
            elif outcome.get('status')=='transport_error':
                if (outcome.get('delivery_passed') is not False or outcome.get('transport_errors')!=1 or
                        outcome.get('ambiguous_attempts')!=1 or outcome.get('ranking') is not None):
                    raise PermissionError('explicit_ambiguous_transport_failure_required')
            else:raise PermissionError('saved_response_or_explicit_transport_required')
            halted=(phase=='development' and not outcome.get('delivery_passed') or outcome['status'] in ('transport_error','http_error','response_error','response_size_exceeded') or bool(outcome.get('refusal')))
        if (outcome.get('truncations')!=bool(outcome.get('truncated')) or
                outcome.get('refusals')!=bool(outcome.get('refusal')) or
                outcome.get('empty_finals')!=bool(outcome.get('empty_final'))):
            raise PermissionError('exact_outcome_counters_required')
        outcomes.append(outcome)
    if expected_members!=set(lock['files_sha256']) or any(done.get(k)!=v for k,v in summarize(outcomes).items()):
        raise PermissionError('complete_original_phase_accounting_required')
    if done.get('protected_targets_opened') is not False or done.get('biological_correctness_assessed') is not False:
        raise PermissionError('solver_target_isolation_required')
    return done,lock,outcomes
