"""Prospective FULL2 terminal/denominator guards; no files or model calls."""
CASE_IDS = ('P19::CDKN2A_elife_95347_supp4_supp6', 'P19::FLAB_binding_koenig2017mutational_kd_g6')


def require_development(done, configuration_sha256, generation):
    if done.get('configuration_sha256') != configuration_sha256 or done.get('generation') != generation:
        raise ValueError('exact_fresh_configuration_and_generation_required')
    if any(done.get(k) != 3 for k in ('planned', 'terminal', 'responses_saved', 'delivery_passed')):
        raise ValueError('all_three_fresh_artificial_deliveries_must_pass')
    if any(done.get(k) != 0 for k in ('transport_errors', 'http_errors', 'response_errors', 'ambiguous_attempts', 'truncations', 'empty_finals', 'refusals', 'reasoning_present')):
        raise ValueError('any_development_failure_blocks_both_native_cases')
    if done.get('biological_correctness_assessed') is not False or not done.get('prediction_lock_sha256'):
        raise ValueError('actual_reference_free_development_seal_required')


def require_solver_seal(done, configuration_sha256, generation):
    if (done.get('configuration_sha256') != configuration_sha256 or done.get('generation') != generation
            or done.get('case_ids') != list(CASE_IDS) or done.get('planned') != 2 or done.get('terminal') != 2
            or not done.get('prediction_lock_sha256') or done.get('protected_targets_opened') is not False):
        raise ValueError('exact_complete_FULL2_prediction_seal_required')
    # Invalid/failed/undispatched terminal outcomes remain in this denominator.
    return {'planned_assays': 2, 'native_panel_assays': 123, 'full_native123_complete': False}


def scoring_disposition(audits):
    if [a.get('case_id') for a in audits] != list(CASE_IDS):
        raise ValueError('exact_FULL2_audits_no_subset_or_reordering')
    invalid = [a['case_id'] for a in audits if a.get('delivery_passed') is not True]
    return {'planned_assays': 2, 'native_panel_assays': 123,
            'reference_rows_may_be_opened': not invalid,
            'strict_native_coverage_primary_undefined': bool(invalid),
            'undefined_case_ids': invalid, 'replacement_partial_primary_permitted': False,
            'missing_query_random_fallback_enabled': False, 'prior_scores_pooled': False}
