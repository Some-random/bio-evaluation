"""Read-only complete account inventory before preserved exact external proofs.

No squeue GPU-summary prefilter is permitted. Every row is queried through
scontrol first. Unknown, unavailable or conflicting resource evidence blocks.
Only explicit ReqTRES without any GPU resource permits a zero-GPU omission.
The unchanged shared adapter receives the same captured scheduler snapshot.
"""
from datetime import datetime
import copy
import re
import subprocess
from types import SimpleNamespace
from zoneinfo import ZoneInfo


QUEUE_COMMAND = ["squeue", "-h", "--array", "-u", "dongweij", "-o", "%i|%j|%T|%b"]
ADAPTER_QUEUE_COMMAND = ["squeue", "-h", "-u", "dongweij", "-o", "%i|%j|%T|%b"]
JOB_PREFIX = ["scontrol", "show", "job", "-o"]


def field(raw, key, *, required=False):
    values = re.findall(r"(?:^|\s)" + re.escape(key) + r"=([^\s]+)", raw)
    if len(values) > 1 or (required and len(values) != 1):
        raise ValueError("missing_or_ambiguous_scheduler_field:" + key)
    return values[0] if values else None


def tres(value, *, required=False):
    if value in (None, "", "N/A", "(null)", "None"):
        if required:
            raise ValueError("authoritative_ReqTRES_required_for_every_queue_row")
        return None
    result = {}
    for item in value.split(","):
        if item.count("=") != 1:
            raise ValueError("malformed_scheduler_TRES")
        key, count = item.split("=", 1)
        if not key or not count or key in result:
            raise ValueError("missing_or_duplicate_scheduler_TRES")
        result[key] = count
    return result


def gpu_count(values):
    """Require the authoritative aggregate; unsupported typed-only data blocks."""
    if values is None:
        return None
    gpu = {key: count for key, count in values.items() if "gpu" in key.lower()}
    if not gpu:
        return 0
    if "gres/gpu" not in gpu:
        raise ValueError("authoritative_aggregate_GPU_TRES_required")
    if any(not (key == "gres/gpu" or key.startswith("gres/gpu:")) or not value.isdigit()
           for key, value in gpu.items()):
        raise ValueError("unsupported_or_noninteger_GPU_TRES")
    count = int(gpu["gres/gpu"])
    typed = [int(value) for key, value in gpu.items() if key != "gres/gpu"]
    if typed and sum(typed) != count:
        raise ValueError("conflicting_aggregate_and_typed_GPU_TRES")
    return count


def _gpu_hint(value):
    return value is not None and "gpu" in value.lower()


def capture(runner):
    """Query every exact account row once; retain only private scheduler metadata."""
    def command(argv):
        result = runner(argv, capture_output=True, text=True, check=True, timeout=30)
        if not isinstance(result.stdout, str):
            raise ValueError("text_scheduler_inventory_required")
        return result.stdout
    queue = command(QUEUE_COMMAND)
    records, raws, gpu_lines, seen, scheduler_ids = [], {}, [], set(), set()
    for line in queue.splitlines():
        parts = line.split("|")
        if len(parts) != 4:
            raise ValueError("malformed_complete_account_queue_row")
        ident, name, state, summary = parts
        if (re.fullmatch(r"[0-9]+(?:_[0-9]+)?", ident) is None
                or ident in seen or not name or not state):
            raise ValueError("unique_expanded_exact_scheduler_ID_required")
        seen.add(ident)
        raw = command(JOB_PREFIX + [ident])
        internal_id = field(raw, "JobId", required=True)
        array = re.fullmatch(r"([0-9]+)_([0-9]+)", ident)
        if array:
            if (not internal_id.isdigit()
                    or field(raw, "ArrayJobId", required=True) != array.group(1)
                    or field(raw, "ArrayTaskId", required=True) != array.group(2)):
                raise ValueError("exact_scheduler_array_coordinates_required")
        elif internal_id != ident:
            raise ValueError("exact_scheduler_job_identity_required")
        if internal_id in scheduler_ids:
            raise ValueError("duplicate_internal_scheduler_job_identity")
        scheduler_ids.add(internal_id)
        if field(raw, "JobName", required=True) != name:
            raise ValueError("changing_scheduler_job_name_blocks_snapshot")
        field(raw, "JobState", required=True)
        requested = tres(field(raw, "ReqTRES", required=True), required=True)
        count = gpu_count(requested)
        allocated = gpu_count(tres(field(raw, "AllocTRES")))
        if allocated is not None and allocated > count:
            raise ValueError("allocated_GPU_count_exceeds_authoritative_request")
        hints = [summary, field(raw, "Gres"), field(raw, "TresPerNode"),
                 field(raw, "TresPerTask"), field(raw, "TresPerSocket"),
                 field(raw, "TresPerJob")]
        if count == 0 and any(_gpu_hint(value) for value in hints):
            raise ValueError("GPU_hint_conflicts_with_zero_ReqTRES")
        if count == 0:
            allowed_zero = {"cpu", "mem", "node", "billing", "energy"}
            if (any(key not in allowed_zero and key != "gres/gpu"
                    and not key.startswith("gres/gpu:") for key in requested)
                    or any(not requested.get(key, "").isdigit()
                           or int(requested[key]) < 1 for key in ("cpu", "node"))):
                raise ValueError("explicit_recognized_CPU_node_request_required_for_zero_GPU_omission")
        record = {"job_id": ident, "name": name, "state": state,
                  "internal_scheduler_JobId": internal_id,
                  "exact_array_coordinates": {"ArrayJobId": array.group(1), "ArrayTaskId": array.group(2)} if array else None,
                  "queue_GPU_summary": summary, "ReqTRES": field(raw, "ReqTRES"),
                  "AllocTRES": field(raw, "AllocTRES"), "requested_GPUs": count,
                  "classification": "positive_authoritative_GPU_request" if count else
                  "explicit_non_GPU_ReqTRES_no_conflicting_GPU_hint"}
        records.append(record)
        raws[ident] = raw
        if count:
            # The legacy adapter's prefilter now sees every positively measured
            # GPU row, including original N/A summaries. ReqTRES remains exact.
            gpu_lines.append("|".join([ident, name, state, "gpu:" + str(count)]))
    return {"at_pacific": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
            "queue_command": list(QUEUE_COMMAND), "all_account_rows": records,
            "all_rows_scontrol_queried": True, "GPU_summary_prefilter_used": False,
            "unknown_resource_evidence_blocks": True,
            "positive_GPU_rows": len(gpu_lines), "scheduler_mutations": 0,
            "model_calls": 0, "_raw": raws, "_GPU_queue": "\n".join(gpu_lines)}


def capacity_audit(adapter, *, additional=1, require_own_job=False, runner=None,
                   additional_root_proofs=(), additional_proof_binding=None):
    if type(additional) is not int or additional not in (0, 1):
        raise ValueError("exact_zero_or_one_additional_GPU_required")
    snapshot = capture(runner or subprocess.run)
    raws = snapshot.pop("_raw")
    queue = snapshot.pop("_GPU_queue")
    calls = []

    def captured(argv, **kwargs):
        calls.append(list(argv))
        if argv == ADAPTER_QUEUE_COMMAND:
            return SimpleNamespace(stdout=queue, returncode=0)
        if len(argv) == 5 and argv[:4] == JOB_PREFIX and argv[4] in raws:
            return SimpleNamespace(stdout=raws[argv[4]], returncode=0)
        raise ValueError("uncaptured_or_mutating_scheduler_command_forbidden")

    result = adapter.capacity_audit(additional=additional, override=False,
        require_own_job=require_own_job, runner=captured,
        additional_root_proofs=additional_root_proofs,
        additional_proof_binding=additional_proof_binding)
    if (not isinstance(result, dict) or type(result.get("project_requested_GPUs")) is not int
            or type(result.get("project_requested_GPUs_with_addition")) is not int
            or result["project_requested_GPUs_with_addition"] != result["project_requested_GPUs"] + additional
            or result.get("additional_GPUs") != additional):
        raise ValueError("exact_preserved_adapter_capacity_result_required")
    measured = {row["job_id"]: row["requested_GPUs"] for row in snapshot["all_account_rows"]
                if row["requested_GPUs"] > 0}
    rows = result.get("jobs", [])
    if (len(rows) != len(measured) or {row.get("job_id") for row in rows} != set(measured)
            or any(type(row.get("gpus")) is not int or row["gpus"] != measured[row["job_id"]]
                   for row in rows)):
        raise ValueError("preserved_adapter_omitted_or_changed_measured_GPU_row")
    result = copy.deepcopy(result)
    result["strict_complete_account_ReqTRES_snapshot"] = snapshot
    result["preserved_adapter_uses_exact_same_captured_snapshot"] = True
    result["cached_scheduler_queries"] = calls
    result["strict_snapshot_project_GPUs_after_exact_existing_root_exclusions"] = result["project_requested_GPUs"]
    return result
