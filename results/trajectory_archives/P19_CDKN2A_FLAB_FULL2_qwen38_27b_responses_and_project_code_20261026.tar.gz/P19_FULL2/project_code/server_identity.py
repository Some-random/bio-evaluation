"""Read-only Linux process/listener identity checks; no model imports."""
from pathlib import Path
import hashlib
import json
import os
import re
import urllib.parse
import urllib.request


def start_ticks(pid, proc=Path('/proc')):
    return (proc / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()[19]


def argv(pid, proc=Path('/proc')):
    return [v.decode() for v in (proc / str(pid) / 'cmdline').read_bytes().split(b'\0') if v]


def listener_inodes(endpoint, *, proc=Path('/proc'), server_pid=None):
    parsed = urllib.parse.urlsplit(endpoint)
    if (parsed.scheme != 'http' or parsed.hostname != '127.0.0.1' or parsed.path != '/v1'
            or parsed.username is not None or parsed.password is not None or parsed.query or parsed.fragment
            or not isinstance(parsed.port, int)):
        raise ValueError('Exact IPv4 loopback model endpoint required')
    base = proc / (str(server_pid) if server_pid is not None else 'self') / 'net'
    wanted = '0100007F:' + format(parsed.port, '04X')
    result = set()
    for family in ['tcp', 'tcp6']:
        for line in (base / family).read_text().splitlines()[1:]:
            parts = line.split()
            if len(parts) <= 9 or parts[3] != '0A' or parts[1].split(':')[-1].upper() != format(parsed.port, '04X'):
                continue
            if family != 'tcp' or parts[1].upper() != wanted:
                raise PermissionError('Conflicting wildcard, IPv6 or non-loopback listener on frozen port')
            if not parts[9].isdigit() or int(parts[9]) == 0:
                raise ValueError('Owned TCP listener inode unavailable')
            result.add(parts[9])
    return result


def owned_listener(pid, ticks, endpoint, *, proc=Path('/proc')):
    if start_ticks(pid, proc) != ticks:
        raise PermissionError('Original server PID/start identity changed')
    if os.readlink(proc / str(pid) / 'ns/net') != os.readlink(proc / 'self/ns/net'):
        raise PermissionError('Server and caller must share the observed loopback network namespace')
    state = (proc / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()[0]
    if state in ['Z', 'X', 'x']:
        raise PermissionError('Original server is not live')
    sockets = listener_inodes(endpoint, proc=proc, server_pid=pid)
    if len(sockets) != 1:
        raise PermissionError('Exactly one owned IPv4 loopback listener required')
    owners = []
    # The pinned DP1 Python launcher serves HTTP in the root process. Requiring
    # its own FD avoids stale descendant/PID ancestry observations entirely.
    for descriptor in (proc / str(pid) / 'fd').iterdir():
        try:
            target = os.readlink(descriptor)
        except FileNotFoundError:
            continue
        match = re.fullmatch(r'socket:\[([0-9]+)\]', target)
        if match and match.group(1) in sockets:
            owners.append({'pid': pid, 'proc_start_ticks': ticks,
                           'fd': descriptor.name, 'socket_inode': match.group(1)})
    if (not owners or start_ticks(pid, proc) != ticks
            or listener_inodes(endpoint, proc=proc, server_pid=pid) != sockets):
        raise PermissionError('Listener is not held by the original live root server')
    return {'server_pid': pid, 'server_start_ticks': ticks,
            'listener_inodes': sorted(sockets), 'listener_owners': owners,
            'namespace_device_numbers_are_not_cross_host_pins': True}


def verify_models_reply(value, plan):
    if not isinstance(value, dict) or not isinstance(value.get('data'), list) or len(value['data']) != 1:
        raise ValueError('Exactly one actual served model required')
    model = value['data'][0]
    if (model.get('id') != plan['model'] or model.get('root') != plan['model_directory']
            or type(model.get('max_model_len')) is not int
            or model['max_model_len'] != plan['context_limit']):
        raise ValueError('Actual engine model root or max context differs from frozen condition')
    return {key: model[key] for key in ['id', 'root', 'max_model_len']}


def process_identity(pid, ticks, command, python, *, proc=Path('/proc')):
    if start_ticks(pid, proc) != ticks:
        raise PermissionError('Original live server process identity changed')
    executable = (proc / str(pid) / 'exe').resolve()
    if executable != Path(python).resolve():
        raise PermissionError('Original server Python executable changed')
    observed = argv(pid, proc)
    if observed != command:
        raise PermissionError('Server command/title differs from exact pinned launcher behavior')
    return {'pid': pid, 'proc_start_ticks': ticks, 'python_executable': str(executable),
            'observed_argv': observed,
            'launch_command_sha256': hashlib.sha256(json.dumps(command, separators=(',', ':')).encode()).hexdigest()}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def loopback_opener():
    return urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
