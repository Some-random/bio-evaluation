"""Unadopted dedicated-server vLLM0.32 V1 adapter for Unique40Language.

Load only in a future separately admitted server with
VLLM_USE_V2_MODEL_RUNNER=0 and --logits-processors
p19_literal_logits:P19LiteralLogitsProcessor. No model is loaded by this module.
"""
from __future__ import annotations

import hashlib
import importlib.metadata
import os
from pathlib import Path

from vllm.v1.sample.logits_processor import AdapterLogitsProcessor

from unique40_core import TokenVocabulary
from native_literal import CONDITION, LiteralNativeLanguage, LiteralRequestConstraint

TOKENIZER_PATH = Path("/dfs/scratch0/tchen/models/Qwen3.8-27B/tokenizer.json")
TOKENIZER_SHA256 = "0997f410c57a1f4e53b09e4be8f4a172d90edd9564368fb0847030937229b9f3"
EOS_IDS = {248044, 248046}
ARG_KEYS = {"p19_unique40_condition", "p19_unique40_sequence", "p19_unique40_sequence_sha256", "p19_unique40_declared_length"}


def validate_request_params(params):
    args = params.extra_args
    if not isinstance(args, dict) or set(args) != ARG_KEYS:
        raise ValueError("dedicated_P19_server_requires_exact_constraint_arguments")
    if args["p19_unique40_condition"] != CONDITION:
        raise ValueError("wrong_prospective_condition_identity")
    sequence = args["p19_unique40_sequence"]
    declared_text = args["p19_unique40_declared_length"]
    if not isinstance(declared_text, str) or not declared_text.isascii() or not declared_text.isdecimal() or str(int(declared_text)) != declared_text:
        raise ValueError("canonical_native_declared_integer_required")
    declared_length = int(declared_text)
    LiteralNativeLanguage(sequence, declared_length)
    if hashlib.sha256(sequence.encode()).hexdigest() != args["p19_unique40_sequence_sha256"]:
        raise ValueError("input_sequence_hash_mismatch")
    if getattr(params, "n", 1) != 1:
        raise ValueError("single_output_only_no_best_of_or_retry")
    return sequence, declared_length


class P19LiteralLogitsProcessor(AdapterLogitsProcessor):
    @classmethod
    def validate_params(cls, params):
        validate_request_params(params)

    def __init__(self, vllm_config, device, is_pin_memory):
        if importlib.metadata.version("vllm") != "0.32.0":
            raise ValueError("exact_vllm0.32_required")
        if os.environ.get("VLLM_USE_V2_MODEL_RUNNER") != "0":
            raise ValueError("prospective_legacy_V1_adapter_requires_explicit_runner0")
        if vllm_config.speculative_config is not None:
            raise ValueError("speculative_decoding_not_supported")
        if Path(vllm_config.model_config.model).resolve() != TOKENIZER_PATH.parent.resolve():
            raise ValueError("wrong_pinned_model_directory")
        super().__init__(vllm_config, device, is_pin_memory)
        self.vocabulary = TokenVocabulary.from_checkpoint_tokenizer(
            TOKENIZER_PATH, TOKENIZER_SHA256, EOS_IDS
        )

    def is_argmax_invariant(self):
        # Hard constraints must never be skipped for greedy sampling.
        return False

    def apply(self, logits):
        # This is a dedicated prospective P19 server, never a generic opt-in
        # plugin: missing lifecycle state must fail instead of leaving a row
        # unconstrained, including ambiguous same-step slot reuse.
        if set(self.req_info) != set(range(logits.shape[0])):
            raise ValueError("every_active_logit_row_requires_constraint_state")
        return super().apply(logits)

    def new_req_logits_processor(self, params):
        sequence, declared_length = validate_request_params(params)
        return LiteralRequestConstraint(sequence, declared_length, self.vocabulary)
