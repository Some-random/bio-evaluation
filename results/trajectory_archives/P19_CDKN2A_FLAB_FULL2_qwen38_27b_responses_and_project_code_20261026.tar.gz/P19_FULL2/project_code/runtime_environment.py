"""Pure exact CP2v3 runtime override functions; no admission or environment IO.

Only function source is copied. P19 must bind its own runtime and permissions.
"""

def clean_runtime_overrides(environment):
    return {key:value for key,value in environment.items()
            if not key.startswith(("VLLM_", "RAY_"))}

def require_runtime_overrides(environment, ipc):
    expected={"VLLM_NO_USAGE_STATS":"1", "VLLM_USE_V2_MODEL_RUNNER":"0", "VLLM_RPC_BASE_PATH":str(ipc)}
    if ({key:value for key,value in environment.items() if key.startswith("VLLM_")} != expected
            or any(key.startswith("RAY_") for key in environment)):
        raise PermissionError("exact_owned_runtime_overrides_required")
