"""Once-only original native NMS@40/Recall@40 after exact FULL2 original seal.

Targets remain closed for any invalid delivery. Otherwise a durable sole claim
precedes the same-descriptor private target projection and unchanged native
metric functions. No missing-query fallback, polarity inversion or pooling.
"""
from pathlib import Path
import argparse
import ast
import json
import sys
import types

from io_contract import save as _exclusive_json, read as _read_json, sha, regular
import runner
import phase_guard as protocol
from phase_guard import require_development, require_solver_seal, scoring_disposition, CASE_IDS
from protected_target_loader import copy_exact_postseal_targets

HERE=Path(__file__).resolve().parent


def _module(name,path,dependencies=None):
    import admission
    return admission.load(name,path,dependencies)


def load_native(plan):
    source=regular(plan['native_scorer'],plan['frozen_files_sha256'][plan['native_scorer']])
    router=regular(plan['native_router'],plan['frozen_files_sha256'][plan['native_router']])
    registry=[ast.literal_eval(n.value) for n in ast.parse(router.read_bytes()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DATASET_INPUTS' for t in n.targets)]
    if len(registry)!=1:raise PermissionError('single_exact_literal_native_registry_required')
    tree=ast.parse(source.read_bytes())
    tree.body=[n for n in tree.body if not (isinstance(n,ast.ImportFrom) and n.module=='router')]
    module=types.ModuleType('_P19_FULL2_unchanged_native_metrics');module.__file__=str(source);module.DATASET_INPUTS=registry[0]
    sys.modules[module.__name__]=module;exec(compile(tree,str(source),'exec'),module.__dict__)
    return module


def score(plan_path,plan_sha,grant_path,grant_sha,run=None):
    import admission
    plan=admission.validate_plan_and_grant(plan_path,plan_sha,grant_path,grant_sha,require_job=True,allow_scoring=True)
    folder=Path(plan['runtime_root'])/'benchmark'
    if run is not None and Path(run)!=folder:raise PermissionError('exact_original_benchmark_folder_required')
    dev,_,_=runner.verify_phase(plan,plan_sha,folder.parent/'development','development')
    require_development(dev,plan['configuration_sha256'],plan['generation'])
    done,lock,outcomes=runner.verify_phase(plan,plan_sha,folder,'benchmark')
    require_solver_seal(done,plan['configuration_sha256'],plan['generation'])
    audits=[{'case_id':row['case_id'],'delivery_passed':row.get('delivery_passed') is True} for row in outcomes]
    disposition=scoring_disposition(audits)
    claim={'role':'durable_sole_FULL2_native_scoring_and_protected_reader_claim','plan_sha256':plan_sha,
           'engineering_admission_sha256':grant_sha,'configuration_sha256':plan['configuration_sha256'],
           'solver_prediction_lock_sha256':done['prediction_lock_sha256'],'case_ids':list(CASE_IDS),
           'file_and_parent_fsynced':True,'protected_target_rows_not_yet_opened':True,'no_retry':True}
    # The only native scoring claim precedes every target stat/hash/open. Any
    # interrupted or completed claim blocks another score invocation.
    _exclusive_json(folder/'sole_native_score_attempt.json',claim)
    result={'task_id':'P19','condition':plan['condition'],'plan_sha256':plan_sha,
            'configuration_sha256':plan['configuration_sha256'],'engineering_admission_sha256':grant_sha,
            'prediction_lock_sha256':done['prediction_lock_sha256'],'planned_assays':2,'native_panel_assays':123,
            'case_ids':list(CASE_IDS),'full_native_benchmark_complete':False,'scores_pooled':False,
            'delivery_audits':audits,'strict_delivery_passed':sum(a['delivery_passed'] for a in audits),
            'native_metrics':None,'reference_rows_opened':False,
            'source_objective_qualifications':plan['source_objective_qualifications'],
            'native123_partition_snapshot_at_adoption':plan['native123_partition_snapshot'],
            'missing_query_random_fallback_enabled':False,'no_score_polarity_inversion':True,
            'biological_measurement_inference':'Comparison with existing released measurements, not experimental validation of generated variants.',
            **{key:done[key] for key in ('attempted_confirmed','not_dispatched','responses_saved','empty_finals','truncations','refusals','http_errors','transport_errors','response_errors','ambiguous_attempts')}}
    if not disposition['reference_rows_may_be_opened']:
        result.update(native_scoring_status='undefined_native_strict_coverage_failure',undefined_case_ids=disposition['undefined_case_ids'])
    else:
        admission_data=admission.read(grant_path);adoption=admission.read(plan['root_scientific_adoption'])
        # Re-read the durable claim from disk, binding exactly what was fsynced.
        persisted_claim=_read_json(folder/'sole_native_score_attempt.json')
        if persisted_claim!=claim:raise PermissionError('original_durable_claim_changed')
        view=folder/'private_native_target_view'
        receipt=copy_exact_postseal_targets(plan,admission_data,adoption,done,lock,persisted_claim,audits,view)
        native=load_native(plan);setting='T1_single_mutant_generation'
        truth=native.load_full_ground_truth(view,nested_groups=False,item_column='mutant',setting=setting)
        names=[c.split('::',1)[1] for c in CASE_IDS]
        if set(truth)!=set(names):raise PermissionError('exact_FULL2_native_truth_membership_required')
        predictions={name:[native.PredictionRow(name,m,float(i),i-1,'original_sealed_literal_native_JSON40') for i,m in enumerate(row['ranking'],1)] for name,row in zip(names,outcomes)}
        native._validate_predictions(truth,predictions,top_k=40,strict=True,setting=setting)
        per_assay=[native.evaluate_one_assay(truth=truth[name],pred_rows=predictions[name],top_k=40,setting=setting) for name in names]
        summary=native.summarize_full_results(per_assay,truth=truth,predictions=predictions,setting=setting,
                    ground_truth_dir=Path('exact_private_FULL2_native_target_view'),predictions_path=folder,top_k=40,strict=True)
        result.update(native_scoring_status='completed_native_scored_reviewed_FULL2',native_metrics=summary['metrics'],
                      native_summary=summary,per_assay=per_assay,reference_rows_opened=True,
                      protected_view_receipt_sha256=sha(view/'protected_view_receipt.json'))
    _exclusive_json(folder/'scores.json',result)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--plan-sha',required=True)
    parser.add_argument('--grant',type=Path,required=True);parser.add_argument('--grant-sha',required=True);parser.add_argument('--run',type=Path)
    args=parser.parse_args()
    try:
        result=score(args.plan,args.plan_sha,args.grant,args.grant_sha,args.run)
        print(json.dumps({'task_id':'P19','native_scoring_status':result['native_scoring_status'],'native_metrics':result['native_metrics']}))
    except BaseException as error:
        print(json.dumps({'error_code':'P19_FULL2_native_scoring_stopped_preserve_claim_no_retry','error_type':type(error).__name__}))
        raise SystemExit(2)
