"""Complete installed CPU request/plugin/worker/native-scorer readiness.

No weights, model forwards, target files or native metric functions are used.
This checks all five unchanged payloads and the actual installed plugin ABI.
"""
from pathlib import Path
import argparse
import importlib.metadata as metadata
import os
import sys
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))


def check(plan):
    if os.environ.get('CUDA_VISIBLE_DEVICES')!='' or os.environ.get('HF_HUB_OFFLINE')!='1':
        raise PermissionError('offline_CPU_only_readiness_required')
    from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest
    from vllm.v1.sample.logits_processor import AdapterLogitsProcessor
    import p19_literal_logits
    import runner
    import scorer
    import worker
    import admission
    expected={'vllm':'0.32.0','torch':'2.13.0','transformers':'5.17.0','tokenizers':'0.23.3','triton':'3.7.1','xgrammar':'0.2.8','flashinfer-python':'0.7.0.post1'}
    packages={name:metadata.version(name) for name in expected}
    if packages!=expected:raise PermissionError('exact_runtime_packages_required')
    if not issubclass(p19_literal_logits.P19LiteralLogitsProcessor,AdapterLogitsProcessor):
        raise PermissionError('exact_actual_plugin_ABI_required')
    rows=[]
    for phase in ('development','benchmark'):
        for row in runner.phase_cases(plan,phase):
            parsed=ChatCompletionRequest.model_validate(row['payload'])
            result=p19_literal_logits.validate_request_params(SimpleNamespace(extra_args=row['payload']['vllm_xargs'],n=1))
            if parsed.structured_outputs is None or result!=(row['context']['wildtype_sequence'],row['context']['sequence_length']):
                raise PermissionError('actual_HTTP_schema_and_literal_plugin_binding_required')
            rows.append({'phase':phase,'case_id':row['case_id'],'request_sha256':runner.canonical_hash(row['payload']),'passed':True})
    command=worker.server_command(Path('/tmp/bio-p19-full2-CPU-fixture'),Path(plan['model_directory']),plan)
    flag=command.index('--logits-processors')
    if command[flag+1]!='p19_literal_logits:P19LiteralLogitsProcessor' or command[command.index('--max-model-len')+1]!='65536' or command[command.index('--tensor-parallel-size')+1]!='1':
        raise PermissionError('mandatory_actual_worker_plugin_and_frozen_runtime_required')
    # The unchanged upstream scorer contains stdlib imports only. Loading it
    # does not enumerate/stat/open protected targets or invoke native metrics.
    native=scorer.load_native(plan)
    names=('load_full_ground_truth','_validate_predictions','evaluate_one_assay','summarize_full_results')
    if not all(callable(getattr(native,n,None)) for n in names):raise PermissionError('complete_native_metric_API_required')
    return {'role':'actual_complete_P19_FULL2_CPU_worker_API_plugin_and_stdlib_native_scorer_readiness',
            'passed':True,'packages':packages,'counts':rows,'native_cases':2,'artificial_cases':3,
            'correct_plugin':'p19_literal_logits:P19LiteralLogitsProcessor',
            'source_files_sha256':{str(p):runner.sha(p) for p in sorted(HERE.glob('*.py'))},
            'native_scorer_functions':list(names),'native_metric_calls':0,
            'no_model_weights_forwards_or_GPU_allocation':True,'no_source_or_target_reopen':True,
            'qualification':'Actual installed request-schema/plugin ABI and worker wiring; no live logits, grammar or model execution.'}


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    try:
        from io_contract import read,save,sha
        result=check(read(args.plan));save(args.output,result)
        print(__import__('json').dumps({'passed':True,'evidence_sha256':sha(args.output),'model_calls':0,'native_metric_calls':0}))
    except BaseException as error:
        print(__import__('json').dumps({'passed':False,'error_type':type(error).__name__,'input_or_target_values_echoed':False}))
        raise SystemExit(2)
