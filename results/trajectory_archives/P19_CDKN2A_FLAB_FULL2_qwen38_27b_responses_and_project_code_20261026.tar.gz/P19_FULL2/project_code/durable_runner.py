"""Runtime IO/transport guards around byte-identical adopted scientific runner.

The payload builder, parser, concurrency, counters and no-retry control flow
remain in the adopted runner. Only its file/transport dependencies are bound.
"""
from pathlib import Path
import json
import os
import urllib.request

import server_identity


def sync_directory(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


class _DurableFile:
    def __init__(self, stream, parent):
        self.stream, self.parent = stream, parent

    def __enter__(self):
        return self.stream

    def __exit__(self, kind, value, traceback):
        try:
            self.stream.flush()
            os.fsync(self.stream.fileno())
        finally:
            self.stream.close()
        sync_directory(self.parent)
        return False


class DurablePath(type(Path())):
    def mkdir(self, mode=0o777, parents=False, exist_ok=False):
        super().mkdir(mode=mode, parents=parents, exist_ok=exist_ok)
        sync_directory(self.parent)

    def open(self, mode='r', *args, **kwargs):
        stream = super().open(mode, *args, **kwargs)
        return _DurableFile(stream, self.parent) if any(key in mode for key in 'wax+') else stream


def durable_save(path, value, exclusive=True):
    path = Path(path)
    if not path.parent.is_dir():
        DurablePath(path.parent).mkdir(parents=True, exist_ok=True)
    target = path if exclusive else path.with_suffix(path.suffix + '.tmp')
    flags = os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW
    flags |= os.O_EXCL if exclusive else os.O_TRUNC
    descriptor = os.open(target, flags, 0o600)
    with os.fdopen(descriptor, 'w') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    if not exclusive:
        os.replace(target, path)
    sync_directory(path.parent)


class OwnedOpener:
    """No proxies or redirects; exact loopback destination and live socket owner."""
    def __init__(self, endpoint, assert_owned):
        self.endpoint, self.assert_owned = endpoint, assert_owned
        self.opener = server_identity.loopback_opener()

    def open(self, request, timeout):
        url = request.full_url if isinstance(request, urllib.request.Request) else request
        method = request.get_method() if isinstance(request, urllib.request.Request) else 'GET'
        allowed = {(self.endpoint + '/chat/completions', 'POST'),
                   (self.endpoint + '/models', 'GET'),
                   (self.endpoint.removesuffix('/v1') + '/health', 'GET')}
        if (url, method) not in allowed:
            raise PermissionError('exact_owned_loopback_transport_destination_required')
        self.assert_owned()
        response = self.opener.open(request, timeout=timeout)
        try:
            if response.geturl() != url:
                raise PermissionError('redirected_transport_forbidden')
            self.assert_owned()
        except BaseException:
            response.close()
            raise
        return response


def run_phase(runner, *, endpoint, assert_owned_server, **kwargs):
    # The isolated module instance is owned by this worker; source bytes and
    # original scientific behavior stay immutable. Every raw context close and
    # every JSON save now flushes/fsyncs the file and its containing directory.
    runner.Path, runner.save = DurablePath, durable_save
    return runner.run_phase(endpoint=endpoint, assert_owned_server=assert_owned_server,
        opener_factory=lambda: OwnedOpener(endpoint, assert_owned_server), **kwargs)
