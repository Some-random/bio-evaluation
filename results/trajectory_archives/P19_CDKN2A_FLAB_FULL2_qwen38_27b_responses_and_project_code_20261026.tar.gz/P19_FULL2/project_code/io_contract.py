"""Private durable evidence IO; exclusive claims survive every failure."""
from pathlib import Path
import hashlib
import json
import os
import stat


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def sync(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def private_directory(path):
    path = Path(path)
    if os.path.lexists(path):
        raise PermissionError('existing_namespace_preserved_no_replay')
    path.mkdir(mode=0o700)
    sync(path.parent)
    return path


def write_bytes(path, body):
    path = Path(path)
    info = path.parent.lstat()
    if path.parent != path.parent.resolve() or not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o700:
        raise PermissionError('canonical_private_parent_required')
    directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    identity = lambda x: (x.st_dev, x.st_ino, x.st_mode, x.st_uid)
    try:
        if identity(info) != identity(os.fstat(directory)):
            raise PermissionError('private_parent_changed')
        fd = os.open(path.name, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600, dir_fd=directory)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(body);stream.flush();os.fsync(stream.fileno())
        os.fsync(directory)
        if identity(info) != identity(path.parent.lstat()):
            raise PermissionError('private_parent_changed')
    finally:
        os.close(directory)


def save(path, value):
    write_bytes(path, canonical(value))


def regular(path, digest=None):
    path = Path(path)
    if path != path.resolve() or not stat.S_ISREG(path.lstat().st_mode):
        raise PermissionError('canonical_regular_evidence_required')
    if digest is not None and sha(path) != digest:
        raise PermissionError('changed_pinned_evidence')
    return path


def exact_members(folder, expected):
    folder = Path(folder)
    if folder != folder.resolve() or not folder.is_dir():
        raise PermissionError('canonical_phase_directory_required')
    actual = set()
    for base in ('requests', 'responses', 'outcomes'):
        directory = folder / base
        if directory.is_symlink() or not directory.is_dir():
            raise PermissionError('regular_phase_subdirectories_required')
        for path in directory.iterdir():
            regular(path)
            actual.add(str(path.relative_to(folder)))
    if actual != set(expected):
        raise PermissionError('exact_sealed_phase_members_required')
    for name, digest in expected.items():
        if name not in actual:
            raise PermissionError('unsafe_lock_member')
        regular(folder / name, digest)
