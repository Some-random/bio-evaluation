"""Fixed one-allocation submission arguments and isolated scheduler environment."""
from pathlib import Path
import hashlib
import json
import os
import re
import stat


# These are client-side controls or inherited allocation identities. A new
# submission must obtain its own scheduler-assigned allocation and device map.
SCHEDULER_PREFIXES = ("SBATCH_", "SLURM_", "SALLOC_", "SRUN_", "VLLM_", "RAY_", "LD_", "BASH_FUNC_")
DEVICE_SELECTION = frozenset({
    "CUDA_VISIBLE_DEVICES", "CUDA_DEVICE_ORDER", "NVIDIA_VISIBLE_DEVICES",
    "HIP_VISIBLE_DEVICES", "ROCR_VISIBLE_DEVICES", "GPU_DEVICE_ORDINAL",
    "ZE_AFFINITY_MASK", "ONEAPI_DEVICE_SELECTOR", "SYCL_DEVICE_FILTER",
    "SYCL_DEVICE_ALLOWLIST",
})
LOADER_OVERRIDES = frozenset({"PYTHONPATH", "PYTHONHOME", "BASH_ENV", "ENV"})
SBATCH = Path("/usr/local/bin/sbatch")
BINDING = Path(__file__).resolve().parent / "CPU_scheduler_executable_binding.json"


def _component(path, info, *, directory):
    correct_type = stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)
    if not correct_type or info.st_uid != 0 or info.st_mode & 0o022:
        raise PermissionError("canonical_root_owned_nonwritable_scheduler_component_required")
    return {"path": str(path), "uid": info.st_uid, "gid": info.st_gid,
            "mode": stat.S_IMODE(info.st_mode), "kind": "directory" if directory else "regular"}


def executable_metadata(path):
    """Inspect only canonical component metadata and the four-byte ELF marker."""
    path = Path(path)
    if not path.is_absolute() or path != path.resolve(strict=True):
        raise PermissionError("exact_canonical_scheduler_executable_required")
    ancestors = [_component(part, part.lstat(), directory=True)
                 for part in reversed(path.parents)]
    info = path.lstat()
    executable = _component(path, info, directory=False)
    if not info.st_mode & 0o111 or not os.access(path, os.X_OK):
        raise PermissionError("executable_scheduler_binary_required")
    with path.open("rb") as stream:
        if stream.read(4) != b"\x7fELF":
            raise PermissionError("exact_native_scheduler_binary_required")
    executable.update({"bytes": info.st_size, "mtime_ns": info.st_mtime_ns, "format": "ELF"})
    return {"ancestors": ancestors, "executable": executable}


def verified_executable():
    """Revalidate the plan-pinned CPU metadata proof before any submission."""
    if BINDING != BINDING.resolve(strict=True) or not stat.S_ISREG(BINDING.lstat().st_mode):
        raise PermissionError("regular_canonical_scheduler_binding_required")
    binding = json.loads(BINDING.read_text())
    if (binding.get("role") != "CPU_metadata_only_scheduler_binding_no_submission"
            or binding.get("scheduler_contract_sha256") != hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
            or binding.get("metadata") != executable_metadata(SBATCH)):
        raise PermissionError("exact_reviewed_root_owned_scheduler_binding_required")
    return str(SBATCH)


def submission_environment(source):
    """Return a child-only copy; do not persist or disclose environment values."""
    clean = {}
    for name, value in source.items():
        if not isinstance(name, str) or not isinstance(value, str):
            raise ValueError("string_submission_environment_required")
        upper = name.upper()
        if upper.startswith(SCHEDULER_PREFIXES) or upper in DEVICE_SELECTION or upper in LOADER_OVERRIDES:
            continue
        clean[name] = value
    return clean


def submission_command(here, plan_sha, grant_sha):
    """No caller-supplied scheduler options or extra allocations are accepted."""
    here = Path(here)
    if not here.is_absolute() or here != here.resolve():
        raise ValueError("canonical_submission_namespace_required")
    if any(not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None
           for value in (plan_sha, grant_sha)):
        raise ValueError("exact_submission_digests_required")
    # Account, partition, hardware constraint, CPU/memory/time and output paths
    # remain the exact separately pinned worker.sbatch directives.
    return [verified_executable(), "--parsable", "--nodes=1", "--ntasks=1", "--gres=gpu:1",
            "--no-requeue", str(here / "worker.sbatch"),
            "--plan", str(here / "plan.json"), "--plan-sha", plan_sha,
            "--grant", str(here / "engineering_admission.json"),
            "--grant-sha", grant_sha]
