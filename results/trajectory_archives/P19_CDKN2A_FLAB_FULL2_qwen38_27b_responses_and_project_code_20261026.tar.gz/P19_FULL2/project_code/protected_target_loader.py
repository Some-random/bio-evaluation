"""Disabled post-seal FULL2 protected reader, prepared from code/metadata only.

No target stat/hash/open occurs at import or before verified phase metadata,
complete FULL2 solver seal and durable sole native-reader claim. Callers in the
eventual reviewed scorer must verify metadata bytes against their frozen pins;
this module does not issue scientific, runtime or target-source authority.
"""
from pathlib import Path
import hashlib
import json
import os
import stat

from stable_source import StableSource
from phase_guard import CASE_IDS, require_solver_seal, scoring_disposition


def require_gate(plan, admission, adoption, solver_done, lock, claim, audits):
    if admission.get('admitted') is not True or adoption.get('adopted') is not True:
        raise PermissionError('actual_exact_scientific_and_runtime_admission_required')
    if (admission.get('configuration_sha256') != plan['configuration_sha256']
            or adoption.get('configuration_sha256') != plan['configuration_sha256']
            or admission.get('protected_target_source_access_after_full_solver_lock_and_sole_native_claim') is not True
            or admission.get('case_ids') != list(CASE_IDS) or adoption.get('case_ids') != list(CASE_IDS)):
        raise PermissionError('exact_FULL2_postseal_target_scope_required')
    require_solver_seal(solver_done, plan['configuration_sha256'], plan['generation'])
    if (lock.get('case_ids') != list(CASE_IDS)
            or lock.get('configuration_sha256') != plan['configuration_sha256']
            or lock.get('reference_labels_opened') is not False):
        raise PermissionError('exact_FULL2_label_free_lock_required')
    if (claim.get('role') != 'durable_sole_FULL2_native_scoring_and_protected_reader_claim'
            or claim.get('configuration_sha256') != plan['configuration_sha256']
            or claim.get('solver_prediction_lock_sha256') != solver_done['prediction_lock_sha256']
            or claim.get('case_ids') != list(CASE_IDS)
            or claim.get('file_and_parent_fsynced') is not True
            or claim.get('protected_target_rows_not_yet_opened') is not True):
        raise PermissionError('durable_exact_sole_native_claim_required_before_target_access')
    disposition = scoring_disposition(audits)
    if not disposition['reference_rows_may_be_opened']:
        raise PermissionError('strict_FULL2_delivery_failure_primary_undefined_no_target_read')
    if [x.get('case_id') for x in plan['protected_targets']] != list(CASE_IDS):
        raise PermissionError('exact_two_metadata_pinned_targets_required')
    if any(x.get('native_truth_id') != case_id.split('::', 1)[1]
           for x, case_id in zip(plan['protected_targets'], CASE_IDS)):
        raise PermissionError('exact_native_target_basenames_required')
    return disposition


def private_write(path, body):
    path = Path(path)
    parent = path.parent.lstat()
    if path.parent.absolute() != path.parent.resolve() or not stat.S_ISDIR(parent.st_mode) or parent.st_uid != os.getuid() or stat.S_IMODE(parent.st_mode) != 0o700:
        raise PermissionError('private_output_directory_required')
    directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    key = lambda v: (v.st_dev, v.st_ino, v.st_uid, v.st_mode)
    try:
        if key(parent) != key(os.fstat(directory)):
            raise PermissionError('output_parent_changed')
        with os.fdopen(os.open(path.name, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600, dir_fd=directory), 'wb') as stream:
            stream.write(body);stream.flush();os.fsync(stream.fileno())
        os.fsync(directory)
        if key(parent) != key(path.parent.lstat()):
            raise PermissionError('output_parent_changed')
    finally:
        os.close(directory)

def copy_exact_postseal_targets(plan, admission, adoption, solver_done, lock, claim, audits, destination):
    """Only future admitted scorer calls this with hash-verified gate metadata.

    This is a private exact-byte view for the unchanged native scorer; it never
    rewrites source rows or changes score direction. No partial result is a
    complete score, and failure preserves the exclusive view and native claim.
    """
    require_gate(plan, admission, adoption, solver_done, lock, claim, audits)
    destination = Path(destination)
    if os.path.lexists(destination):
        raise PermissionError('existing_target_view_blocks_replay')
    destination.mkdir(mode=0o700)
    parent = os.open(destination.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(parent)
    finally:
        os.close(parent)
    receipt = []
    for descriptor in plan['protected_targets']:
        with StableSource(descriptor['path'], descriptor['sha256'], descriptor['bytes'], descriptor['owner_uid']) as source:
            source.stream.seek(0)
            body = source.stream.read(descriptor['bytes'])
            if len(body) != descriptor['bytes'] or hashlib.sha256(body).hexdigest() != descriptor['sha256']:
                raise PermissionError('complete_exact_target_bytes_required')
            source.verify()
            target = destination / (descriptor['native_truth_id'] + '.csv')
            private_write(target, body)
            source.verify()
            receipt.append({'case_id': descriptor['case_id'], 'sha256': hashlib.sha256(body).hexdigest(),
                            'bytes': len(body), 'source_binding': source.binding()})
    private_write(destination / 'protected_view_receipt.json', (json.dumps(receipt, sort_keys=True) + '\n').encode())
    return receipt
