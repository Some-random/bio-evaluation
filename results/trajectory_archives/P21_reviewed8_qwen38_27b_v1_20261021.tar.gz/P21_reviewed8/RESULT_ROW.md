| Evaluation | Qwen3.8-27B | GPT models |
| --- | --- | --- |
| PFArena — anchor-informed ranking,reviewed mammalian stability subset(8/67 assays) | NDCG=0.8748976812284484; NMS@5=0.8716931854694374; Recall@5=0.375; spearman=0.23323719161603965 | Not evaluated |

This subset result does not complete the native67-assay panel or the retained catalog.
