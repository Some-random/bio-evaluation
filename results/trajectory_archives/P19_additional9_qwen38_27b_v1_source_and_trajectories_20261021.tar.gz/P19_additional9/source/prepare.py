"""Nine-only preparation; no targets parsed, inference, adoption or submission."""
import ast
import copy
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
TASK = HERE.parent
ROOT = HERE.parents[4]
REVIEW = TASK/'remaining_scope_review_v2'
OLD = TASK/'standalone_execution_v4'
sys.path.insert(0, str(HERE))
import protocol
import runner
from bound_request import canonical_sha256


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text())
def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
def rel(path): return str(Path(path).resolve().relative_to(ROOT))


def main():
    proposal = read(REVIEW/'proposed_stability9_scope_review.json')
    peer = read(REVIEW/'independent_stability9_preparation_review.json')
    assert sha(REVIEW/'proposed_stability9_scope_review.json') == peer['proposal_sha256']
    assert peer['preparation_review_passed'] and not peer['blocking_findings']
    for name, digest in proposal['artifact_sha256'].items(): assert sha(ROOT/name) == digest
    ids = [row['case_id'] for row in proposal['cases']]
    assert len(ids) == len(set(ids)) == 9
    original_review = read(TASK/'input_review.json')
    assert not set(ids) & set(original_review['approved_case_ids'])
    assert not set(ids) & {'P19::'+x for x in original_review['held_cases']}
    assert 'P19::HUMAN_DOMAINOME_P03034_PF01381_4' not in ids
    shutil.copyfile(REVIEW/'candidate_inputs.jsonl', HERE/'benchmark_inputs.jsonl')
    contexts = [json.loads(x) for x in (REVIEW/'candidate_delivery_contexts.jsonl').read_text().splitlines() if x]
    assert [row['case_id'] for row in contexts] == ids
    save(HERE/'benchmark_delivery_contexts.json', {'task_id':'P19','reference_labels_included':False,'cases':contexts})
    save(HERE/'input_review.json', {
        'task_id':'P19','approved_case_ids':ids,'held_cases':original_review['held_cases'],
        'prior_scored_case_ids':original_review['approved_case_ids'],
        'positive_review_proposal':rel(REVIEW/'proposed_stability9_scope_review.json'),
        'positive_review_proposal_sha256':sha(REVIEW/'proposed_stability9_scope_review.json'),
        'independent_review':rel(REVIEW/'independent_stability9_preparation_review.json'),
        'independent_review_sha256':sha(REVIEW/'independent_stability9_preparation_review.json'),
        'cases':proposal['cases'],'biological_input_review_passed':True,
        'scientific_scope_adoption_required_before_runtime':True,'dispatch_admitted':False})
    source_scope = {
        'task_id':'P19','condition':protocol.CONDITION,'approved_case_ids':ids,'approved':9,
        'native_panel':123,'prior_scored':34,'held':12,'outside_current_scope':1,'unadmitted':67,
        'approved_organism_counts':{'Homo sapiens (Human)':9},
        'scope':'nine additional human isolated-domain stability inputs; native objective fields preserved',
        'proposal_sha256':sha(REVIEW/'proposed_stability9_scope_review.json'),
        'peer_preparation_sha256':sha(REVIEW/'independent_stability9_preparation_review.json'),
        'held_case_ids':['P19::'+x for x in original_review['held_cases']],
        'prior_scored_case_ids':original_review['approved_case_ids'],
        'outside_case_ids':['P19::HUMAN_DOMAINOME_P03034_PF01381_4'],
        'P20_or_interrupted_material_reopened':False,'new_measurement_row_review':False,
        'original34_unchanged':True,'full_native123_complete':False,'dispatch_admitted':False}
    save(HERE/'source_scope.json', source_scope)
    # New artificial delivery IDs and reference-free artificial sequences;
    # none is an additional benchmark observation or biological development set.
    source = ROOT/'.local/source_acquisition_2026-10-19/protocols/AMix-Bio__PFArena/files/code/prompts/single_mutant_generation.py'
    functions = [x for x in ast.parse(source.read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='single_mutant_generation_template']
    namespace = {};exec(compile(ast.Module(body=functions,type_ignores=[]),str(source),'exec'),namespace)
    template = namespace['single_mutant_generation_template']()
    alphabet = 'ACDEFGHIKLMNPQRSTVWY'
    development = [];dev_contexts=[]
    for index,length in enumerate([40,71,100],1):
        sequence = ((alphabet[index:]+alphabet[:index])*6)[:length]
        case_id = 'P19::additional9_synthetic_delivery_'+str(index).zfill(2)
        fields={'uniprot_id':'SYNTHETIC_NO_BIOLOGICAL_IDENTITY','primary_task_class':'synthetic_delivery',
                'fitness_type':'synthetic_delivery_no_measured_target','readout_subclass':'synthetic_delivery_no_measurements',
                'sequence_length':length,'wildtype_sequence':sequence}
        development.append({'task_id':'P19','case_id':case_id,'messages':[{'role':'user','content':template.format(**fields)}]})
        dev_contexts.append({'case_id':case_id,'wildtype_sequence':sequence,'sequence_length':length})
    (HERE/'development_inputs.jsonl').write_text(''.join(json.dumps(x,sort_keys=True)+'\n' for x in development))
    save(HERE/'development_delivery_contexts.json',{'task_id':'P19','reference_labels_included':False,'cases':dev_contexts})
    save(HERE/'development_review.json',{'task_id':'P19','approved_case_ids':[x['case_id'] for x in development],
        'held_cases':[],'synthetic_only':True,'biological_correctness_assessed':False})
    acquisition = read(ROOT/'.local/source_recovery_round2_2026-10-19/pfarena/authenticated/completion.json')
    previous_manifest = read(TASK/'scorer_only_manifest.json')
    manifest = {key:value for key,value in previous_manifest.items() if key not in {'condition','cases'}}
    manifest.update(condition=protocol.CONDITION,cases=[])
    header_checks=[]
    for case_id in ids:
        assay=case_id.removeprefix('P19::');path='T1_single_mutant_generation/norm_data/'+assay+'.csv'
        item=acquisition['files'][path];target=ROOT/'.local/source_recovery_round2_2026-10-19/pfarena/authenticated/raw'/path
        assert item['publisher_digest_verified'] and sha(target)==item['sha256']
        with target.open() as stream: header=stream.readline().strip().split(',')
        assert 'mutant' in header and 'DMS_score' in header
        header_checks.append({'case_id':case_id,'column_names':header,'measurement_rows_opened':False})
        manifest['cases'].append({'case_id':case_id,'assay_id':assay,'native_truth_id':assay,'target_path':rel(target),
            'sha256':item['sha256'],'publisher_digest_kind':item['publisher_digest_kind'],
            'publisher_digest_verified_at_acquisition':True,'score_table_rows_opened_during_preparation':False})
    save(HERE/'scorer_only_manifest.json',manifest)
    code_names=['worker.py','runner.py','protocol.py','scorer.py','unique40_core.py','p19_unique40_logits.py','request_contract.py','bound_request.py','prepare.py']
    code_pins={str(HERE/name):sha(HERE/name) for name in code_names}
    code_pins[str(ROOT/'scripts/p19_generation_contract_20261020.py')]=sha(ROOT/'scripts/p19_generation_contract_20261020.py')
    for phase,cases,context_rows in [('development',development,dev_contexts),('benchmark',[json.loads(x) for x in (HERE/'benchmark_inputs.jsonl').read_text().splitlines() if x],contexts)]:
        config=copy.deepcopy(read(OLD/(phase+'_config.json')))
        config.update(condition=protocol.CONDITION,run_id='qwen38_27b_p19_additional9_'+phase+'_unique40_eos16k_20261021_v1',
            planned=len(cases),generation=runner.GENERATION,
            input_file=rel(HERE/(phase+'_inputs.jsonl')),input_sha256=sha(HERE/(phase+'_inputs.jsonl')),
            delivery_context_file=rel(HERE/(phase+'_delivery_contexts.json')),delivery_context_sha256=sha(HERE/(phase+'_delivery_contexts.json')),
            review_file=rel(HERE/('development_review.json' if phase=='development' else 'input_review.json')),
            review_sha256=sha(HERE/('development_review.json' if phase=='development' else 'input_review.json')),
            files_sha256=code_pins,base_generation_sha256=canonical_sha256(runner.BASE_GENERATION),
            case_bindings={case['case_id']:{'case_sha256':canonical_sha256(case),'context_sha256':canonical_sha256(context),
                'base_generation_sha256':canonical_sha256(runner.BASE_GENERATION)} for case,context in zip(cases,context_rows)},
            material_differences=['Separate additional9 human stability cohort; original34 fixed condition unchanged.',
                'Exact native six-field prompts and complete sequences; no publisher auxiliary context added.',
                'Same pinned local BF16 Qwen model, nonthinking16K sampling and unchanged input-valid unique40 V4 decoder.',
                'Three new artificial reference-free delivery cases; PFArena supplies no development split.',
                'Eight MaveDB primary class=binding fields retained with native fitness_type=stability; publisher metadata confirms stability.',
                'Recovered human accession uses exact historical UniSave26 identity/fragment; current entry is inactive.'])
        if phase=='benchmark':
            config.update(development_config_sha256=sha(HERE/'development_config.json'),
                scorer_only_manifest_path=rel(HERE/'scorer_only_manifest.json'),scorer_only_manifest_sha256=sha(HERE/'scorer_only_manifest.json'))
        save(HERE/(phase+'_config.json'),config)
        runner.load_contract(HERE/(phase+'_config.json'))
    save(HERE/'preparation_receipt.json',{'at_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'planned':9,'synthetic_development':3,'header_only_target_checks':header_checks,
        'all_native_sequences_prompts_preserved':True,'protected_measurement_rows_opened':False,
        'model_calls':0,'GPU_allocations':0,'scientific_adoption':False,'runtime_admission':False,
        'source_proposal_sha256':sha(REVIEW/'proposed_stability9_scope_review.json')})
    print(json.dumps({'planned':9,'synthetic':3,'input_contracts_checked':True,'model_calls':0,'admitted':False}))


if __name__=='__main__': main()
