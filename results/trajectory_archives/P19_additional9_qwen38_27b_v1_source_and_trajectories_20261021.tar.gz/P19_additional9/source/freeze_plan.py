"""Freeze the exact nine-only plan after independent/CPU review; never submit."""
import copy
import datetime
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
TASK=HERE.parent
ROOT=HERE.parents[4]
sys.path.insert(0,str(HERE))
import protocol
import runner
import worker


def read(path):return json.loads(Path(path).read_text())


def main():
    if (HERE/'plan.json').exists():raise FileExistsError('The exact additional9 plan is already frozen')
    cpu=read(HERE/'CPU_validation.json');terminal=read(HERE/'CPU_terminal.json')
    assert cpu['passed'] and terminal['passed'] and terminal['CPU_validation_sha256']==worker.sha(HERE/'CPU_validation.json')
    assert cpu['CPU_plan_sha256']==worker.sha(HERE/'CPU_plan.json')
    for name,want in read(HERE/'CPU_plan.json')['file_sha256'].items():assert worker.sha(name)==want,name
    peer=read(HERE/'independent_engineering_preflight_review.json')
    assert peer.get('checks_passed') is True and peer.get('blocking_findings') == [], 'Independent engineering preflight is required'
    old=read(TASK/'standalone_execution_v4/plan.json')
    scope=read(HERE/'source_scope.json')
    assert [scope[k] for k in ['approved','native_panel','prior_scored','held','outside_current_scope','unadmitted']]==[9,123,34,12,1,67]
    pins={}
    def pin(path,expected=None):
        path=Path(path);path=path if path.is_absolute() else ROOT/path
        actual=worker.sha(path)
        if expected is not None:assert actual==expected,str(path)
        pins[str(path)]=actual
    for path,want in read(HERE/'CPU_plan.json')['file_sha256'].items():pin(path,want)
    for name in ['CPU_plan.json','CPU_validation.json','CPU_terminal.json','independent_engineering_preflight_review.json']:
        pin(HERE/name)
    pin(HERE/'CPU.sbatch')
    for name in ['vetted_V06_worker','runtime_common','checkpoint_audit','project_gpu_audit_helper']:
        path=old[name];pin(path,old['frozen_files_sha256'].get(path))
    for manifest_key in ['native_scorer','native_router','native_parser']:
        manifest=read(HERE/'scorer_only_manifest.json');pin(manifest[manifest_key+'_file'],manifest[manifest_key+'_sha256'])
    script=f'''#!/bin/bash
#SBATCH --job-name=bio-p19-additional9
#SBATCH --partition=il
#SBATCH --account=infolab
#SBATCH --gres=gpu:a100:1
#SBATCH --cpus-per-task=10
#SBATCH --mem=96G
#SBATCH --time=06:00:00
#SBATCH --chdir={ROOT}
#SBATCH --output={HERE}/slurm-%j.log
set -euo pipefail
umask 077
unset OPENAI_API_KEY ANTHROPIC_API_KEY GEMINI_API_KEY GOOGLE_API_KEY AZURE_OPENAI_API_KEY HF_TOKEN HUGGING_FACE_HUB_TOKEN
unset OPENAI_BASE_URL OPENAI_ORG_ID OPENAI_ORGANIZATION OPENAI_PROJECT_ID PYTHONPATH PYTHONHOME VIRTUAL_ENV SSH_AUTH_SOCK
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONNOUSERSITE=1
exec /usr/bin/python3 {HERE}/worker.py --plan {HERE}/plan.json --plan-sha256 "$1" --admission "$2" --admission-sha256 "$3"
'''
    (HERE/'worker.sbatch').write_text(script);pin(HERE/'worker.sbatch')
    keep=['model','model_revision','model_directory','endpoint','context_limit','tensor_parallel_size','dtype','base_runtime','cuda_overlay',
          'runtime_common','checkpoint_audit','runtime_package_installation','vetted_V06_worker','vetted_V06_infrastructure_version',
          'vetted_V06_plan_sha256','base_archive_contains_vllm','pinned_install_before_private_exec_and_GPU_guard_required','runtime_version',
          'mandatory_model_runner','custom_logits_processor','project_gpu_audit_helper','project_gpu_audit_helper_sha256','GPU_accounting_scope']
    plan={key:copy.deepcopy(old[key]) for key in keep}
    plan.update(created_at_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),task_id='P19',scope=protocol.SCOPE,condition=protocol.CONDITION,
        planned=9,synthetic_development_planned=3,native_panel_assays=123,held_assays=12,prior_scored_assays=34,outside_current_scope_assays=1,not_reviewed_assays=67,
        source_scope_sha256=worker.sha(HERE/'source_scope.json'),scope_proposal_sha256=scope['proposal_sha256'],
        source_scope_file=str(HERE/'source_scope.json'),generation=runner.GENERATION,
        development_config=str(HERE/'development_config.json'),development_config_sha256=worker.sha(HERE/'development_config.json'),
        benchmark_config=str(HERE/'benchmark_config.json'),benchmark_config_sha256=worker.sha(HERE/'benchmark_config.json'),
        runner=str(HERE/'runner.py'),scorer=str(HERE/'scorer.py'),scorer_only_manifest=str(HERE/'scorer_only_manifest.json'),
        runtime_root=str(HERE/'runtime'),gpus_requested=1,total_project_gpu_ceiling=8,
        plugin_sha256=worker.sha(HERE/'p19_unique40_logits.py'),frozen_files_sha256=pins,
        preserved_original34_plan_sha256=worker.sha(TASK/'standalone_execution_v4/plan.json'),
        phase_policy={'development_attempts':3,'benchmark_attempts_maximum':9,'concurrency':1,'uniform_output_tokens':16384,
            'development_must_pass_all':True,'benchmark_grant_after_passing_actual_development_lock':True,
            'native_scoring_after_complete9_prediction_lock_only':True,'sole_scoring_attempt':True,
            'automatic_or_selective_retries':False,'automatic_resume':False,
            'stop_new_requests_on':['transport_error','http_error','response_error','refusal'],
            'truncated_or_empty_finals_retained_in_full_denominator':True,'native_strict_coverage_failure_metric_undefined':True},
        scientific_scope_adoption_required=True,scientific_scope_adoption_granted=False,runtime_admission_granted=False,
        new_model_calls=0,new_GPU_allocations=0,full_native123_complete=False,full_catalog_complete=False,
        reference_access='Only the once-only scorer may parse the nine protected target tables after all nine predictions are sealed. Preparation only verified acquired digests and column headers.',
        source_caveats=read(HERE/'benchmark_config.json')['material_differences'])
    worker.save(HERE/'plan.json',plan);digest=worker.sha(HERE/'plan.json');(HERE/'plan.sha256').write_text(digest+'\n')
    worker.save(HERE/'scientific_adoption_NOT_GRANTED_template.json',{'adopted':False,'issuer':'/root','task_id':'P19','condition':protocol.CONDITION,
        'proposal_sha256':scope['proposal_sha256'],'approved_case_ids':scope['approved_case_ids'],'native_input_objectives_unchanged':True})
    worker.save(HERE/'peer_admission_NOT_GRANTED_template.json',{'admitted':False,'task_id':'P19','scope':protocol.SCOPE,'condition':protocol.CONDITION,
        'plan_sha256':digest,'source_scope_sha256':plan['source_scope_sha256'],'gpu_count':1,'project_gpu_ceiling':8,
        'allow_benchmark_only_after_development_gate':True,'scientific_scope_adoption_receipt':None,'scientific_scope_adoption_sha256':None,
        'gpu_audit_receipt':None,'gpu_audit_receipt_sha256':None})
    worker.validate_plan(HERE/'plan.json',digest)
    worker.save(HERE/'freeze_receipt.json',{'created_at_UTC':plan['created_at_UTC'],'plan_sha256':digest,'dependency_pins':len(pins),
        'scope_counts':{'native':123,'additional_reviewed':9,'previously_scored':34,'held':12,'outside':1,'unadmitted':67},
        'native_inputs_objectives_and_metric_functions_preserved':True,'original34_unchanged':True,
        'protected_measurement_rows_opened':False,'scientific_adoption':False,'runtime_admission':False,'model_calls':0,'GPU_allocations':0})
    print(json.dumps({'plan_sha256':digest,'pins':len(pins),'scientific_adoption_required':True,'runtime_admission':False,'model_calls':0}))


if __name__=='__main__':main()
