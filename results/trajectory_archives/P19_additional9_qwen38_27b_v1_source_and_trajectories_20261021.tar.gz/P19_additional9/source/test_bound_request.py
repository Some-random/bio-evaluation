import copy
import unittest

from bound_request import build_bound_request, canonical_sha256


class BoundRequestTests(unittest.TestCase):
    def setUp(self):
        sequence = "ACDEFGHIKLMNPQRSTVWY" * 2
        self.case = {"task_id":"P19","case_id":"P19::invented","messages":[{"role":"user","content":"Invented exact native-format sequence: `"+sequence+"`"}]}
        self.context = {"case_id":"P19::invented","wildtype_sequence":sequence,"sequence_length":len(sequence)}
        self.generation = {"max_tokens":16384,"temperature":1.0,"top_p":0.95,"top_k":20,"seed":42,"n":1,"chat_template_kwargs":{"enable_thinking":False},"structured_outputs":{"json":{"type":"object"}}}
        self.pins = {"case_sha256":canonical_sha256(self.case),"context_sha256":canonical_sha256(self.context),"base_generation_sha256":canonical_sha256(self.generation)}

    def build(self): return build_bound_request(self.case,self.context,self.generation,**self.pins)

    def repin(self):
        self.pins = {"case_sha256":canonical_sha256(self.case),"context_sha256":canonical_sha256(self.context),"base_generation_sha256":canonical_sha256(self.generation)}

    def test_exact_binding_preserves_native_prompt_and_base_sampling(self):
        request=self.build()
        self.assertEqual(request["messages"],self.case["messages"])
        for key,value in self.generation.items():
            if key!="structured_outputs":self.assertEqual(request[key],value)

    def test_changed_case_context_or_generation_blocked_by_pins(self):
        for target in ["case","context","generation"]:
            instance=BoundRequestTests();instance.setUp()
            if target=="case":instance.case["case_id"]="P19::changed"
            if target=="context":instance.context["sequence_length"]+=1
            if target=="generation":instance.generation["max_tokens"]=1
            with self.assertRaises(ValueError):instance.build()

    def test_valid_but_different_sequence_cannot_bind_to_native_prompt(self):
        self.context["wildtype_sequence"]="Y"*40;self.repin()
        with self.assertRaises(ValueError):self.build()

    def test_different_case_identity_or_incomplete_sequence_rejected(self):
        self.context["case_id"]="P19::other";self.repin()
        with self.assertRaises(ValueError):self.build()

    def test_reference_or_measurement_field_rejected_before_overlay(self):
        self.context["artificial_private_measurements"]="SENTINEL_NOT_AN_INPUT";self.repin()
        with self.assertRaises(ValueError):self.build()

    def test_tools_system_messages_or_hidden_input_fields_rejected(self):
        self.case["messages"].append({"role":"system","content":"extra"});self.repin()
        with self.assertRaises(ValueError):self.build()


if __name__=="__main__":unittest.main(verbosity=2)
