import hashlib
import json
import random
import sys
import types
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from unique40_core import ConstraintError, CONDITION, RequestConstraint, State, TokenVocabulary, Unique40Language
from request_contract import prospective_request

SEQUENCE = "ACDEFGHIKLMNPQRSTVWY" * 2  # Invented, not a biological source record.


def character_vocabulary(extra=()):
    alphabet = b'{}[]":,ranking0123456789 \n\t\rACDEFGHIKLMNPQRSTVWY'
    pieces = {byte: bytes([byte]) for byte in set(alphabet)}
    for index, piece in enumerate(extra, 256): pieces[index] = piece
    return TokenVocabulary(pieces, {999}, 1000)


class LanguageTests(unittest.TestCase):
    def setUp(self):
        self.language = Unique40Language(SEQUENCE)
        self.ranking = sorted(self.language.allowed)[:40]

    def document(self, ranking): return json.dumps({"ranking": ranking}, separators=(",", ":")).encode()

    def test_all19_substitutions_at_all_input_positions(self):
        self.assertEqual(len(self.language.allowed), 19 * len(SEQUENCE))

    def test_valid40_finishes(self):
        self.assertEqual(self.language.feed(State(), self.document(self.ranking)).phase, "done")

    def test_two_hundred_arbitrary_valid_orderings(self):
        rng = random.Random(87102)
        for _ in range(200):
            ranking = rng.sample(sorted(self.language.allowed), 40)
            self.assertEqual(self.language.feed(State(), self.document(ranking)).phase, "done")

    def test_every_selected_ID_can_occupy_every_rank(self):
        for shift in range(40):
            ranking = self.ranking[shift:] + self.ranking[:shift]
            self.assertEqual(self.language.feed(State(), self.document(ranking)).phase, "done")

    def test_duplicate_blocked_before_completion(self):
        ranking = self.ranking.copy(); ranking[-1] = ranking[0]
        with self.assertRaises(ConstraintError): self.language.feed(State(), self.document(ranking))

    def test_wrong_wildtype_out_of_range_no_op_and_malformed_blocked(self):
        for wrong in ["C1D", "A999C", "A1A", "A0C", "A01C", "A1C_extra"]:
            ranking = self.ranking.copy(); ranking[-1] = wrong
            with self.assertRaises(ConstraintError): self.language.feed(State(), self.document(ranking))

    def test_short_or_long_rankings_cannot_close(self):
        for ranking in [self.ranking[:-1], self.ranking + [sorted(self.language.allowed)[40]]]:
            with self.assertRaises(ConstraintError): self.language.feed(State(), self.document(ranking))

    def test_whitespace_outside_strings_and_final_whitespace(self):
        text = b' \n{ \t"ranking" : [ ' + b', \n'.join(json.dumps(x).encode() for x in self.ranking) + b' ] \r} \n'
        self.assertEqual(self.language.feed(State(), text).phase, "done")

    def test_extra_fields_duplicate_keys_escaped_spelling_or_trailing_JSON_blocked(self):
        for text in [self.document(self.ranking)[:-1] + b',"other":1}', b'{"ranking":[],"ranking":[]}', b'{"rank\\u0069ng":[', self.document(self.ranking) + b'{}']:
            with self.assertRaises(ConstraintError): self.language.feed(State(), text)

    def test_nonstandard_or_too_short_sequences_fail(self):
        for sequence in [None, "", "AC", "ACX", "acde", "AC DE"]:
            with self.assertRaises(ConstraintError): Unique40Language(sequence)

    def test_multichar_token_cannot_bypass_duplicate_constraint(self):
        prefix = b'{"ranking":["A1C",'
        vocabulary = character_vocabulary([b'"A1C",', b'"A1D",'])
        state = self.language.feed(State(), prefix)
        allowed = vocabulary.allowed_next_ids(self.language, state)
        self.assertNotIn(256, allowed); self.assertIn(257, allowed)

    def test_whole_document_token_accepted_only_if_valid(self):
        wrong = self.ranking.copy(); wrong[-1] = wrong[0]
        vocab = character_vocabulary([self.document(self.ranking), self.document(wrong)])
        allowed = vocab.allowed_next_ids(self.language, State())
        self.assertIn(256, allowed); self.assertNotIn(257, allowed)

    def test_EOS_not_available_until_complete40(self):
        vocab = character_vocabulary()
        self.assertNotIn(999, vocab.allowed_next_ids(self.language, State()))
        done = self.language.feed(State(), self.document(self.ranking))
        self.assertIn(999, vocab.allowed_next_ids(self.language, done))

    def test_incremental_history_rewrite_and_early_EOS_fail(self):
        constraint = RequestConstraint(SEQUENCE, character_vocabulary())
        constraint.update([ord('{')])
        with self.assertRaises(ConstraintError): constraint.update([])
        with self.assertRaises(ConstraintError): constraint.update([ord('{'), 999])

    def test_per_request_state_is_isolated(self):
        vocab = character_vocabulary()
        a = RequestConstraint(SEQUENCE, vocab); b = RequestConstraint(SEQUENCE, vocab)
        a.update(list(b'{"ranking":["A1C",'))
        self.assertEqual(len(a.state.used), 1); self.assertEqual(len(b.state.used), 0)

    def test_native_messages_and_sampling_preserved_by_overlay(self):
        original = {"model":"synthetic", "messages":[{"role":"user","content":"Invented native prompt"}], "temperature":1.0,"top_p":0.95,"max_tokens":16384,"seed":42,"n":1,"chat_template_kwargs":{"enable_thinking":False},"structured_outputs":{"json":{"type":"object"}}}
        before = json.dumps(original, sort_keys=True)
        updated = prospective_request(original, SEQUENCE)
        self.assertEqual(before, json.dumps(original, sort_keys=True))
        for key in original:
            if key != "structured_outputs": self.assertEqual(original[key], updated[key])
        self.assertNotIn("uniqueItems", json.dumps(updated["structured_outputs"]))
        self.assertTrue(all(isinstance(x,str) for x in updated["vllm_xargs"].values()))

    def test_overlay_refuses_ambiguous_custom_args_and_multiple_outputs(self):
        for original in [{"n":2,"structured_outputs":{"json":{}}},{"vllm_xargs":{},"structured_outputs":{"json":{}}},{"structured_outputs":{"regex":".*"}}]:
            with self.assertRaises(ValueError): prospective_request(original, SEQUENCE)


if __name__ == "__main__": unittest.main(verbosity=2)
