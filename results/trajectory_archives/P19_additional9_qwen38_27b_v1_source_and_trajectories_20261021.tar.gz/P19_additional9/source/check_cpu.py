"""Actual tokenizer and nine-only request preflight; no weights or inference."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import runner
import worker


def main():
    assert os.environ.get('SLURM_JOB_ID') and os.environ.get('CUDA_VISIBLE_DEVICES')==''
    assert not os.environ.get('SLURM_GPUS')
    plan=json.loads((HERE/'CPU_plan.json').read_text())
    for name,want in plan['file_sha256'].items():assert worker.sha(name)==want,name
    started=time.monotonic();phases={};request_checks=[]
    for phase,count in [('development',3),('benchmark',9)]:
        cfg,cases,contexts=runner.load_contract(HERE/(phase+'_config.json'))
        assert len(cases)==cfg['planned']==count
        phases[phase]=runner.count_tokens(cfg,cases,plan['model_directory'],65536)
        for case in cases:
            request=runner.payload(case,contexts,cfg)
            assert request['messages']==case['messages'] and request['n']==1
            assert request['vllm_xargs']['p19_unique40_condition']==runner.DECODER_CONDITION
            assert request['structured_outputs']['json']['properties']['ranking']['minItems']==40
            assert request['structured_outputs']['json']['properties']['ranking']['maxItems']==40
            assert request['vllm_xargs']['p19_unique40_sequence']==contexts[case['case_id']]
            request_checks.append({'case_id':case['case_id'],'request_sha256':hashlib.sha256(json.dumps(request,sort_keys=True).encode()).hexdigest(),
                'native_messages_unchanged':True,'input_only_constraint_bound':True,'body_bytes':len(json.dumps(request).encode())})
    old=HERE.parent/'standalone_execution_v4'
    unchanged={name:worker.sha(HERE/name)==worker.sha(old/name) for name in ['unique40_core.py','p19_unique40_logits.py','request_contract.py','bound_request.py']}
    assert all(unchanged.values())
    prior=worker.require_no_prior_case_requests(plan)
    result={'at_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'job_id':os.environ['SLURM_JOB_ID'],
        'stage':'actual_tokenizer_and_exact_nine_only_request_preflight_passed','passed':True,
        'CPU_plan_sha256':worker.sha(HERE/'CPU_plan.json'),'phases':phases,'request_checks':request_checks,
        'decoder_files_byte_identical_to_validated_V4':unchanged,'historical_request_filename_preflight':prior,
        'elapsed_seconds':time.monotonic()-started,'weights_loaded':False,'model_forwards':0,'model_calls':0,
        'protected_measurement_rows_opened':False,'GPU_allocations':0,'scientific_adoption_or_runtime_admission':False}
    worker.save(HERE/'CPU_validation.json',result)
    worker.save(HERE/'CPU_terminal.json',{'job_id':os.environ['SLURM_JOB_ID'],'passed':True,'CPU_validation_sha256':worker.sha(HERE/'CPU_validation.json'),
        'model_calls':0,'GPU_allocations':0,'protected_measurement_rows_opened':False})
    print(json.dumps({'passed':True,'job_id':os.environ['SLURM_JOB_ID'],'benchmark9_max_prompt_tokens':phases['benchmark']['max_prompt_tokens'],
        'model_calls':0,'GPU_allocations':0}),flush=True)


if __name__=='__main__':main()
