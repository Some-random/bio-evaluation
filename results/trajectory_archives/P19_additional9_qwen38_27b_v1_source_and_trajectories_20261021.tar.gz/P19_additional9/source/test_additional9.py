"""Invented fixtures for nine-only scope, once-only checks and native scoring."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import protocol
import runner
import scorer
import worker


def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value))


class HistoricalAttemptChecks(unittest.TestCase):
    def test_filename_only_prior_or_ambiguous_request_blocks_cohort(self):
        with tempfile.TemporaryDirectory() as directory:
            task=Path(directory);here=task/'additional';here.mkdir()
            ids=['P19::invented_'+str(i) for i in range(9)]
            save(here/'source_scope.json',{'approved_case_ids':ids})
            requests=task/'old/runtime/benchmark/requests';requests.mkdir(parents=True)
            # This is deliberately unreadable JSON. Filename existence suffices.
            target=requests/(hashlib.sha256(ids[0].encode()).hexdigest()+'.json')
            target.write_text('invented ambiguous request marker, not parsed')
            with patch.object(worker,'HERE',here):
                with self.assertRaises(ValueError):worker.require_no_prior_case_requests({})
                target.unlink()
                result=worker.require_no_prior_case_requests({})
            self.assertEqual(result['case_count'],9)
            self.assertFalse(result['request_response_or_label_bodies_opened'])

    def test_root_adoption_must_bind_the_exact_positive_nine(self):
        with tempfile.TemporaryDirectory() as directory:
            here=Path(directory);ids=['P19::invented_'+str(i) for i in range(9)]
            save(here/'source_scope.json',{'approved_case_ids':ids})
            audit=here/'audit.json';save(audit,{})
            adoption=here/'adoption.json'
            value={'adopted':True,'issuer':'/root','task_id':'P19','condition':protocol.CONDITION,
                   'proposal_sha256':'invented-proposal','approved_case_ids':ids,'native_input_objectives_unchanged':True}
            plan={'source_scope_sha256':'invented-scope','scope_proposal_sha256':'invented-proposal'}
            admission=here/'admission.json'
            def grant():
                save(adoption,value)
                save(admission,{'admitted':True,'task_id':'P19','scope':protocol.SCOPE,'condition':protocol.CONDITION,
                    'plan_sha256':'invented-plan','source_scope_sha256':'invented-scope','gpu_count':1,'project_gpu_ceiling':8,
                    'allow_benchmark_only_after_development_gate':True,'gpu_audit_receipt':str(audit),'gpu_audit_receipt_sha256':worker.sha(audit),
                    'scientific_scope_adoption_receipt':str(adoption),'scientific_scope_adoption_sha256':worker.sha(adoption)})
            with patch.object(worker,'HERE',here),patch.dict(worker.os.environ,{'SLURM_JOB_ID':'invented-job'}):
                grant();worker.check_root_admission(admission,worker.sha(admission),'invented-plan',plan)
                for key,bad in [('issuer','/invented-owner'),('proposal_sha256','foreign'),('native_input_objectives_unchanged',False),('approved_case_ids',ids[:-1])]:
                    old=value[key];value[key]=bad;grant()
                    with self.assertRaises(PermissionError):worker.check_root_admission(admission,worker.sha(admission),'invented-plan',plan)
                    value[key]=old


class NativeSyntheticNineScoring(unittest.TestCase):
    def fixture(self,root,short=False):
        ids=['P19::synthetic_score_'+str(i) for i in range(9)]
        sequence='ACDEFGHIKLMNPQRSTVWY'*3
        values=[before+str(pos)+after for pos,before in enumerate(sequence,1) for after in 'ACDEFGHIKLMNPQRSTVWY' if before!=after][:40]
        cases=[{'case_id':x} for x in ids]
        inputs=root/'inputs.jsonl';inputs.write_text(''.join(json.dumps(x)+'\n' for x in cases))
        contexts=root/'contexts.json';save(contexts,{'cases':[{'case_id':x,'wildtype_sequence':sequence} for x in ids]})
        review=root/'review.json';save(review,{})
        manifest={'task_id':'P19','missing_query_random_fallback_enabled':False,'cases':[]}
        source=worker.ROOT/'.local/source_acquisition_2026-10-19/protocols/AMix-Bio__PFArena/files'
        for field,relative in [('native_scorer','code/evaluation/full.py'),('native_router','code/router.py'),('native_parser','code/llm/infer_api_mutation.py')]:
            path=source/relative;manifest[field+'_file']=str(path);manifest[field+'_sha256']=scorer.sha(path)
        targets=[]
        for index,case_id in enumerate(ids):
            target=root/('synthetic_'+str(index)+'.csv');target.write_text('mutant,DMS_score\n'+''.join(value+','+str(i)+'\n' for i,value in enumerate(values)));targets.append(target)
            manifest['cases'].append({'case_id':case_id,'native_truth_id':target.stem,'target_path':str(target),'sha256':scorer.sha(target)})
        references=root/'references.json';save(references,manifest)
        config=root/'config.json';save(config,{'task_id':'P19','split':'reviewed_benchmark_subset','planned':9,'condition':protocol.CONDITION,
            'files_sha256':{},'input_file':str(inputs),'input_sha256':scorer.sha(inputs),'delivery_context_file':str(contexts),'delivery_context_sha256':scorer.sha(contexts),
            'review_file':str(review),'review_sha256':scorer.sha(review),'scorer_only_manifest_sha256':scorer.sha(references)})
        run=root/'run';files=[]
        for index,case_id in enumerate(ids):
            key=hashlib.sha256(case_id.encode()).hexdigest();outcome=run/'outcomes'/(key+'.json');save(outcome,{'case_id':case_id});files.append(outcome)
            response=run/'responses'/(key+'.json');save(response,{'choices':[{'message':{'content':json.dumps({'ranking':values[:-1] if short and index==0 else values})}}]});files.append(response)
        lock=run/'prediction_lock.json';save(lock,{'config_sha256':scorer.sha(config),'reference_labels_opened':False,'files_sha256':{str(x.relative_to(run)):scorer.sha(x) for x in files}})
        save(run/'completion.json',{'task_id':'P19','config_sha256':scorer.sha(config),'planned':9,'terminal':9,'prediction_lock_sha256':scorer.sha(lock),
            'transport_or_response_errors':0,'empty_finals':0,'truncations':0})
        return run,config,references,targets

    def test_complete_invented_nine_use_native_metrics_and_score_once(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);run,config,references,_=self.fixture(root)
            output=root/'scores.json';scorer.score(run,config,references,output);result=json.loads(output.read_text())
            self.assertEqual(result['planned_assays'],9);self.assertEqual(result['native_panel_assays'],123)
            self.assertEqual(result['native_metrics'],{'NMS@40':1.0,'Recall@40':1.0})
            self.assertEqual(result['strict_delivery_passed'],9);self.assertFalse(result['full_native_benchmark_complete'])
            with self.assertRaises(FileExistsError):scorer.score(run,config,references,root/'second_scores.json')

    def test_short_one_keeps_all_nine_undefined_and_opens_no_targets(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);run,config,references,targets=self.fixture(root,short=True)
            for target in targets:target.unlink()
            output=root/'scores.json';scorer.score(run,config,references,output);result=json.loads(output.read_text())
            self.assertEqual(result['planned_assays'],9);self.assertIsNone(result['native_metrics'])
            self.assertFalse(result['reference_rows_opened']);self.assertEqual(result['strict_delivery_passed'],8)

    def test_partial_prediction_lock_stops_before_score_claim_or_targets(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);run,config,references,targets=self.fixture(root)
            completion=json.loads((run/'completion.json').read_text());completion['terminal']=8;save(run/'completion.json',completion)
            for target in targets:target.unlink()
            with self.assertRaises(ValueError):scorer.score(run,config,references,root/'scores.json')
            self.assertFalse((run/'sole_native_score_attempt.json').exists())


if __name__=='__main__':unittest.main(verbosity=2)
