"""One admitted native Protenix execution phase; complete five-sample artifacts."""
from pathlib import Path
import argparse,ast,hashlib,json,math,os,socket,subprocess,sys,types
import admission
import protocol
HERE=Path(__file__).resolve().parent

def check_case(phase,runtime,plan_sha):
 if phase=='resource':return ('P39_ARTIFICIAL_512',('ACDEFGHIKLMNPQRSTVWY'*26)[:512])
 if phase!='benchmark':raise ValueError('Fixed artificial resource or exact sealed generation only')
 gate=json.loads((runtime/'predictor_resource/completion.json').read_bytes())
 if gate.get('all_five_structures_valid')is not True or gate.get('sequence_length')!=512:raise PermissionError('Actual full-length five-sample predictor gate required')
 folder=runtime/'generation/benchmark';complete=json.loads((folder/'completion.json').read_bytes());lock=json.loads((folder/'prediction_lock.json').read_bytes())
 if complete['plan_sha256']!=plan_sha or complete.get('phase')!='benchmark'or lock.get('phase')!='benchmark'or lock.get('plan_sha256')!=plan_sha or lock.get('planned')!=1 or complete['prediction_lock_sha256']!=protocol.sha(folder/'prediction_lock.json')or complete['delivered']!=1:raise PermissionError('Actual sealed single whole-sequence generation required')
 if not {'request.json','response.raw.json','outcome.json'}<=set(lock['files_sha256']):raise PermissionError('Actual request/raw/outcome must be sealed before predictor')
 for rel,digest in lock['files_sha256'].items():
  path=folder/rel
  if Path(rel).is_absolute()or'..'in Path(rel).parts or path.is_symlink()or protocol.sha(path)!=digest:raise ValueError('Unsafe or changed sealed generation bytes')
 raw=(folder/'response.raw.json').read_bytes();parsed=protocol.parse_reply(raw)
 if parsed['status']!='delivered':raise ValueError('No crop/repair/substitution of invalid generation')
 if json.loads((runtime/'qwen_server_terminal.json').read_bytes())['own_server_stopped']is not True:raise PermissionError('Qwen must stop before predictor benchmark allocation use')
 return 'P39_GENERATED_SINGLE',parsed['sequence']

def validate_geometry(files,*,case_name,sequence,load_structure,diagnostics):
 expected={case_name+'_sample_'+str(i)+'.cif'for i in range(5)}
 if {p.name for p in files}!=expected or len(files)!=5:raise ValueError('All five original stochastic structures required, without selection')
 observations=[]
 for path in sorted(files):
  loaded=load_structure(path);atoms=loaded['atoms']
  if loaded['protein_sequence']!=sequence:raise ValueError('Predicted structure must retain the complete unmodified generated sequence')
  if not atoms or any(len(a['xyz'])!=3 or not all(math.isfinite(float(v))for v in a['xyz'])for a in atoms):raise ValueError('Finite complete atomic coordinates required')
  ligand_chains={a['chain']for a in atoms if a['resname']=='HEM'};protein_chains={a['chain']for a in atoms if a['resname']!='HEM'}
  if len(ligand_chains)!=1 or len(protein_chains)!=1 or ligand_chains&protein_chains:raise ValueError('One protein chain and separate CCD_HEM ligand required')
  if sum(a['resname']=='HEM'and a['element'].upper()not in['H','D']for a in atoms)!=43:raise ValueError('Complete43-heavy-atom CCD_HEM ligand required')
  value=diagnostics(atoms,protein_chain=next(iter(protein_chains)),ligand_chain=next(iter(ligand_chains)))
  if value['binding_success']is not None or value['measured_affinity']is not None:raise ValueError('Predicted geometry must not manufacture binding success')
  observations.append({'sample_file':path.name,'structure_sha256':protocol.sha(path),'sequence_length':len(sequence),'geometry':value})
 return observations

def finite_json(value):
 if isinstance(value,float)and not math.isfinite(value):raise ValueError('Nonfinite confidence output')
 if isinstance(value,dict):
  for v in value.values():finite_json(v)
 elif isinstance(value,list):
  for v in value:finite_json(v)
 return value

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--plan-sha256',required=True);parser.add_argument('--admission',type=Path,required=True);parser.add_argument('--admission-sha256',required=True);parser.add_argument('--phase',choices=['resource','benchmark'],required=True);args=parser.parse_args()
 plan=admission.validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256,require_job=True);runtime=Path(plan['runtime_root'])
 audit=admission.current_project_audit(plan)
 name,sequence=check_case(args.phase,runtime,args.plan_sha256)
 directory=runtime/('predictor_'+args.phase);directory.mkdir(exist_ok=False)
 protocol.write(directory/'private_GPU_audit.json',audit)
 for item in plan['predictor_assets'].values():
  if protocol.sha(item['path'])!=item['sha256']:raise ValueError('Original predictor/cache/encoder asset bytes changed')
 sys.path.insert(0,plan['predictor_source_directory'])
 class NoNetwork:
  def __call__(self,*a,**k):raise RuntimeError('Python networking disabled for standalone predictor')
 socket.create_connection=NoNetwork();socket.socket.connect=NoNetwork();socket.socket.connect_ex=NoNetwork();socket.getaddrinfo=NoNetwork()
 import torch
 if torch.__version__!='2.7.1+cu126'or torch.cuda.device_count()!=1:raise ValueError('Exact CUDA126 runtime and own single device required')
 source=Path(plan['vetted_neutral_hardware_source']);tree=ast.parse(source.read_text());functions=[x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='check_hardware'];assert len(functions)==1
 namespace={'contract':types.SimpleNamespace(now=protocol.now,write_json=lambda path,value:protocol.write(path,value,exclusive=False)),'subprocess':subprocess};exec(compile(ast.Module(body=functions,type_ignores=[]),str(source),'exec'),namespace)
 namespace['check_hardware'](torch,directory,plan)
 torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.set_float32_matmul_precision('highest')
 protocol.write(directory/'precision_binding.json',{'torch':torch.__version__,'dtype':'fp32','matmul_allow_tf32':torch.backends.cuda.matmul.allow_tf32,'cudnn_allow_tf32':torch.backends.cudnn.allow_tf32,'float32_matmul_precision':torch.get_float32_matmul_precision()})
 from ml_collections import ConfigDict
 from protenix.data import ccd
 ccd.COMPONENTS_FILE=plan['predictor_assets']['CCD_CIF']['path'];ccd.RKDIT_MOL_PKL=Path(plan['predictor_assets']['CCD_RDKIT']['path']);ccd.biotite_load_ccd_cif.cache_clear()
 from runner.inference import InferenceRunner,infer_predict
 checkpoint_dir=directory/'checkpoints';checkpoint_dir.mkdir()
 for key in ['STRUCTURE_MODEL','ESM_ENCODER','ESM_CONTACT']:
  src=Path(plan['predictor_assets'][key]['path']);os.link(src,checkpoint_dir/src.name)
 input_path=directory/'input.json';protocol.write(input_path,protocol.complex_input(sequence,name))
 cfg=protocol.predictor_configuration(json.loads(Path(plan['predictor_model_config']).read_bytes()),input_json=input_path,dump_dir=directory/'outputs',checkpoints=checkpoint_dir)
 cfg['data']['ccd_components_file']=ccd.COMPONENTS_FILE;cfg['data']['ccd_components_rdkit_mol_file']=str(ccd.RKDIT_MOL_PKL)
 protocol.write(directory/'predictor_config.json',cfg)
 # Unique cwd prevents stale embedding/case reuse across artificial and benchmark.
 os.chdir(directory)
 protocol.write(directory/'status.json',{'at_pacific':protocol.now(),'stage':'loading_native_predictor_after_exact_grant_and_hardware','sequence_length':len(sequence),'model_forwards_not_yet_observed':True})
 runner=InferenceRunner(ConfigDict(cfg));infer_predict(runner,runner.configs)
 # The upstream featurizer catches embedding errors and can substitute zeros.
 # Refuse that fallback explicitly; this is delivery validation, not selection.
 errors=[p for root in [directory/'outputs/ERR',directory/'esm_embeddings/esm_error']for p in root.rglob('*')if p.is_file()and p.stat().st_size]
 if errors:raise RuntimeError('Native predictor recorded a data/embedding/forward error; preserve without retry')
 embeddings=list((directory/'esm_embeddings'/cfg['esm']['model_name']).rglob('*.pt'))
 if len(embeddings)!=1:raise ValueError('Exactly one complete native ESM embedding required')
 embedding=torch.load(embeddings[0],map_location='cpu',weights_only=True)
 if tuple(embedding.shape)!=(len(sequence),2560)or not torch.isfinite(embedding).all()or not torch.count_nonzero(embedding):raise ValueError('Whole finite nonzero native ESM embedding required')
 protocol.write(directory/'encoder_delivery.json',{'at_pacific':protocol.now(),'sequence_length':len(sequence),'embedding_shape':list(embedding.shape),'embedding_sha256':protocol.sha(embeddings[0]),'native_error_files':0,'all_finite':True,'nonzero':True})
 del embedding
 from biotite.structure.io import pdbx
 import biotite.structure as struc
 from Bio.SeqUtils import seq1
 def structure(path):
  array=pdbx.get_structure(pdbx.CIFFile.read(path),model=1)
  protein=array[array.res_name!='HEM'];starts=struc.get_residue_starts(protein)
  output_sequence=seq1(''.join(str(x)for x in protein.res_name[starts]))
  return {'protein_sequence':output_sequence,'atoms':[{'chain':str(atom.chain_id),'resname':str(atom.res_name),'element':str(atom.element),'xyz':[float(x)for x in atom.coord]}for atom in array]}
 geom=admission.load('p39_declared_geometry_diagnostics',plan['geometry_diagnostics_source'])
 structures=list((directory/'outputs').rglob('*.cif'))
 observations=validate_geometry(structures,case_name=name,sequence=sequence,load_structure=structure,diagnostics=geom.structural_diagnostics)
 confidence=list((directory/'outputs').rglob('*summary_confidence_sample_*.json'))
 if {p.name for p in confidence}!={name+'_summary_confidence_sample_'+str(i)+'.json'for i in range(5)}or len(confidence)!=5:raise ValueError('All five associated confidence outputs required')
 for path in confidence:finite_json(json.loads(path.read_bytes()))
 # No correctness/affinity label or success threshold is inferred from these files.
 complete={'at_pacific':protocol.now(),'phase':args.phase,'condition':protocol.CONDITION,'plan_sha256':args.plan_sha256,'case_name':name,'sequence_length':len(sequence),'sequence_sha256':hashlib.sha256(sequence.encode()).hexdigest(),'all_five_structures_valid':True,'predicted_structures':5,'observations':observations,'confidence_files':[str(p.relative_to(directory))for p in sorted(confidence)],'measured_binding_assessed':False,'binding_accuracy':None,'biological_function_validated':False,'native_NatureLM_replication':False}
 files=[input_path,directory/'predictor_config.json',directory/'hardware_gate.json',directory/'precision_binding.json',directory/'encoder_delivery.json',*structures,*confidence]
 lock={'plan_sha256':args.plan_sha256,'phase':args.phase,'files_sha256':{str(p.relative_to(directory)):protocol.sha(p)for p in sorted(files)}}
 protocol.write(directory/'prediction_lock.json',lock);complete['prediction_lock_sha256']=protocol.sha(directory/'prediction_lock.json');protocol.write(directory/'completion.json',complete)
if __name__=='__main__':main()
