"""Declared qualitative single-prompt heme-complex demonstration, never accuracy."""
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,math,re
from pathlib import Path
CONDITION='P39_AVAILABLE_QWEN_SINGLE_HEME_CCD_PROTENIX_MINI_ISM_V1'
MODEL='Qwen/Qwen3.8-27B'
MIN_RESIDUES=20
MAX_RESIDUES=512
QUESTION=('Design a heme-binding protein sequence.\n\n'
          'Return one JSON object with the single key "sequence", containing a complete '
          'protein sequence of 20 to 512 residues using only the 20 standard amino-acid '
          'letters. Do not return an explanation or claim experimental validation.')
SCHEMA={'type':'object','properties':{'sequence':{'type':'string','pattern':'^[ACDEFGHIKLMNPQRSTVWY]{20,512}$'}},'required':['sequence'],'additionalProperties':False}
SERIALIZATION_REGEX=r'\{"sequence":"[ACDEFGHIKLMNPQRSTVWY]{20,512}"\}'
GENERATION={'temperature':0,'top_p':1,'seed':42,'max_tokens':16384,'chat_template_kwargs':{'enable_thinking':False}}

def now():return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as stream:
  for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
def write(path,value,*,exclusive=True):
 path=Path(path)
 if exclusive:
  with path.open('x')as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
 else:
  tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)

def development_expected(index):
 if index not in [0,1]:raise ValueError('Exactly two fixed artificial delivery inputs')
 return ('ACDEFGHIKLMNPQRSTVWY'if index==0 else'YWVTSRQPNMLKIHGFEDCA')*2

def payload(*,development=False,index=0):
 if development:
  sequence=development_expected(index)
  message='Return this artificial alphabet sequence verbatim in the required JSON object: '+sequence
 else:message=QUESTION
 return {'model':MODEL,'messages':[{'role':'user','content':message}],**GENERATION,
         'structured_outputs':{'regex':SERIALIZATION_REGEX},'n':1,'stream':False}

def parse_reply(raw):
 result={'observed_final':False,'empty_final':False,'sequence':None,'http_errors':0,'transport_errors':0,'response_errors':0,'truncation':False,'refusal':False,'reasoning_present':False,'tool_calls_present':False}
 try:
  body=json.loads(raw)
  if not isinstance(body,dict)or not isinstance(body.get('choices'),list)or len(body['choices'])!=1 or not isinstance(body['choices'][0],dict):raise ValueError('Exactly one choice mapping required')
  choice=body['choices'][0];message=choice['message']
  if not isinstance(message,dict):raise ValueError('Message mapping required')
  text=message['content'];result.update(observed_final=text is None or isinstance(text,str),finish_reason=choice.get('finish_reason'),truncation=choice.get('finish_reason')=='length',refusal=bool(message.get('refusal')),reasoning_present=bool(message.get('reasoning_content')or message.get('reasoning')),tool_calls_present=bool(message.get('tool_calls')))
  if text is None or isinstance(text,str)and not text.strip():
   return {**result,'status':'invalid_observed_empty','empty_final':True}
  if not isinstance(text,str):raise ValueError('Final is not a string')
  if choice.get('finish_reason')!='stop'or result['reasoning_present']or result['refusal']or result['tool_calls_present']:
   return {**result,'status':'invalid_delivery'}
  if not re.fullmatch(SERIALIZATION_REGEX,text):raise ValueError('One compact whole JSON object required without unbounded whitespace')
  decoded=json.loads(text)
  if not isinstance(decoded,dict)or set(decoded)!={'sequence'}or not isinstance(decoded['sequence'],str):raise ValueError('Exact output object required')
  sequence=decoded['sequence']
  if not re.fullmatch('[ACDEFGHIKLMNPQRSTVWY]{20,512}',sequence):raise ValueError('Whole sequence outside frozen delivery contract')
  return {**result,'status':'delivered','sequence':sequence,'sequence_length':len(sequence),'sequence_sha256':hashlib.sha256(sequence.encode()).hexdigest()}
 except (ValueError,TypeError,KeyError,IndexError,AssertionError):
  return {**result,'status':'invalid_schema'if result['observed_final']else'invalid_envelope','response_errors':1}

def development_outcome(raw,index):
 result=parse_reply(raw)
 result['artificial_exact_copy_passed']=result['status']=='delivered'and result['sequence']==development_expected(index)
 if result['status']=='delivered'and result['artificial_exact_copy_passed']is not True:result.update(status='invalid_artificial_exact_copy',schema_delivered=True)
 return result

def complex_input(sequence,name):
 if not re.fullmatch('[ACDEFGHIKLMNPQRSTVWY]{20,512}',sequence):raise ValueError('No crop or repair of complete generated sequences')
 if not re.fullmatch('[A-Za-z0-9_.-]+',name):raise ValueError('Safe unique case name required')
 return [{'name':name,'sequences':[{'proteinChain':{'sequence':sequence,'count':1}},{'ligand':{'ligand':'CCD_HEM','count':1}}]}]

def predictor_configuration(source_config,*,input_json,dump_dir,checkpoints):
 # Exact checkpoint dimensions/sampling come from released mini-ISM config.
 c=json.loads(json.dumps(source_config));c.update(model_name='protenix_mini_ism_v0.5.0',load_checkpoint_dir=str(checkpoints),load_strict=True,input_json_path=str(input_json),dump_dir=str(dump_dir),use_msa=False,num_workers=0,dtype='fp32',triangle_attention='torch',triangle_multiplicative='torch',enable_tf32=False,sorted_by_ranking_score=False)
 c['data']['msa']['enable']=False;c['data']['num_dl_workers']=0;c['data']['template']['enable']=False
 if c['sample_diffusion']['N_sample']!=5 or c['sample_diffusion']['N_step']!=5 or c['seeds']!=[101]:raise ValueError('Exact released mini-ISM five-sample/five-step/seed101 contract changed')
 return c
