"""Freeze explicit qualitative available condition after CPU checks, no dispatch."""
from pathlib import Path
import json,subprocess,sys,unittest
import protocol
HERE=Path(__file__).resolve().parent;TASK=HERE.parent;ROOT=HERE.parents[4]
def read(path):return json.loads(Path(path).read_bytes())
def build():
 if(HERE/'plan.json').exists():raise FileExistsError('Do not mutate a frozen proposal')
 suite=unittest.defaultTestLoader.discover(str(HERE),pattern='test_*.py');result=unittest.TextTestRunner(verbosity=1).run(suite)
 if not result.wasSuccessful():raise ValueError('Artificial checks failed')
 native=read(HERE/'native_input_validation.json')
 if native['all_full_inputs_fit']is not True or native['packages']['vllm']not in['0.31.0','0.32.0']or any(row['prompt_tokens']<10 for row in native['per_case']):raise ValueError('Actual full-tokenizer and installed JSON API checks required')
 validation={'at_pacific':protocol.now(),'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'model_forwards':0,'GPU_allocations':0,'actual_native_tokenizer_and_JSON_API_receipt_sha256':protocol.sha(HERE/'native_input_validation.json'),'mini_strict_checkpoint_CPU_job':'245699','ESM_encoder_strict_checkpoint_CPU_job':'245706','Cu126_library_CPU_job':'245707','portable_restore_and_import_CPU_job':'245711','qualification':'These are CPU preparation checks, not actual GPU delivery or benchmark results.'}
 protocol.write(HERE/'CPU_validation_receipt.json',validation)
 p27=read(ROOT/'.local/catalog_execution_2026-10-20/tasks/P27/independent_available_v1/execution_v1/plan.json')
 structural=ROOT/'.local/source_recovery_round2_2026-10-19/structural';vendor=structural/'vendor';source=Path(read(TASK/'runtime_preparation_v1/source_manifest.json')['source_directory'])
 artifacts={
  'STRUCTURE_MODEL':(vendor/'protenix_mini_ism_v0.5.0.pt','a90d3040cdb2c84430878ea724ad817698ee68cc8b12f802a91dac3b081521a2'),
  'ESM_ENCODER':(vendor/'esm2_t36_3B_UR50D_ism.pt','6dfa8d55fff3d25662b7bf4cbe536aa9cb6c9dd09c4d6ea8a4e8a11c8fb8779a'),
  'ESM_CONTACT':(TASK/'runtime_preparation_v4/esm_assets/esm2_t36_3B_UR50D_ism-contact-regression.pt','daf204499768643ef58a701b85d5290a62ef6e5e5fcacd97dce467b867b24d5b'),
  'CCD_CIF':(vendor/'components.v20240608.cif','7240b17369ccfbbcc86e2d02dc8c9db59f46c32e0420f58889c6c121c60bfef0'),
  'CCD_RDKIT':(vendor/'components.v20240608.cif.rdkit_mol.pkl','2d6caced2d26c62015115a1d0a50f4106755a300e0c2a2d2b5c101c9038dcbcd')}
 portable=read(TASK/'portable_predictor_runtime_v1/status.json');library_manifest=TASK/'portable_predictor_runtime_v1/library_manifest.json'
 if portable['archive_sha256']!='49b0a59066bc112b241cc33ae30a4a08f159478ade08f626502e538f2c0e7eaf'or portable['library_manifest_sha256']!=protocol.sha(library_manifest):raise ValueError('Exact restored CUDA library pins changed')
 plan={
  'at_pacific':protocol.now(),'role':'frozen_qualitative_available_condition_not_runtime_or_dispatch','owner':'/root/new_2026_benchmarks','task_id':'P39','condition':protocol.CONDITION,
  'model':protocol.MODEL,'model_revision':p27['model_revision'],'model_directory':p27['model_directory'],'generation':protocol.GENERATION,'JSON_output_schema':protocol.SCHEMA,'structured_output_regex':protocol.SERIALIZATION_REGEX,'exact_question':protocol.QUESTION,
  'planned_generated_cases':1,'development_planned':2,'minimum_sequence_length':20,'maximum_sequence_length':512,'context_limit':65536,
  'predictor_model':'Protenix-mini-ISM v0.5.0','predictor_encoder':'released ESM2-3B-ISM','predictor_source_revision':'d60af043d0604757e1f4613181462ba683c80c1e','predictor_source_directory':str(source),'predictor_source_manifest':str(TASK/'runtime_preparation_v1/source_manifest.json'),
  'predictor_model_config':str(structural/'source/smiles724__Proteo-R1/pretrained/protenix_mini_ism_v0.5.0/config.json'),'predictor_samples_per_case':5,'predictor_diffusion_steps':5,'predictor_seeds':[101],'predictor_precision':'fp32','predictor_attention':'torch','predictor_TF32':False,'predictor_MSA':False,'predictor_templates':False,'rank_or_HemeList_selection':False,
  'predictor_assets':{key:{'path':str(path),'sha256':digest,'bytes':path.stat().st_size}for key,(path,digest)in artifacts.items()},
  'predictor_libraries':{'path':portable['archive'],'bytes':portable['archive_bytes'],'sha256':portable['archive_sha256']},'predictor_library_manifest':str(library_manifest),'predictor_runtime_packages':{'torch':'2.7.1+cu126','numpy':'1.26.4','fair-esm':'2.0.0','biotite':'1.4.0','rdkit':'2023.9.6'},
  'base_runtime':p27['base_runtime'],'cuda_overlay':p27['cuda_overlay'],'private_runtime_packages':p27['private_runtime_packages'],'runtime_common':p27['runtime_common'],'checkpoint_audit':p27['checkpoint_audit'],'vetted_V06_worker':p27['vetted_V06_worker'],'site_tools_helper':p27['site_tools_helper'],'vetted_neutral_hardware_source':p27['vetted_neutral_hardware_source'],'project_gpu_audit_helper':p27['project_gpu_audit_helper'],
  'root_scientific_direction_adoption':str(TASK/'scope_direction_root_20261021.json'),'independent_draft_scope_review':str(TASK/'independent_source_review_v1/protocol_scope_review.json'),
  'geometry_diagnostics_source':str(TASK/'engineering_20261020/case_interface.py'),'packager':str(HERE/'package.py'),'runtime_root':str(HERE/'runtime'),'endpoint':'http://127.0.0.1:8439/v1',
  'gpus_requested':1,'GPU_type':'A100_80GB','project_GPU_ceiling':8,'new_training':False,'paid_model_calls':False,'automatic_retries':False,'native_NatureLM_replication':False,'measured_binding_assessed':False,'biological_function_validated':False,'primary_metric':None,
  'sequence_crop_repair_or_substitution':False,'all_five_structures_retained':True,
  'CPU_API_version_preparation_qualification':{'observed':native['packages']['vllm'],'exact0_32_recheck':'Before any model phase, the allocated worker runs the same CPU check in its verified exact0.32 runtime and requires exact0.32 API identity.'},
  'scientific_differences':[
   'One newly declared generic heme-binding prompt and one generated outcome; original NatureLM prompt, selected cohort and denominator are unavailable.',
   'Uses the acquired Proteo-R1 Protenix fork d60af043 and released mini-ISM v0.5.0, five samples/five diffusion steps/seed101, fp32 Torch kernels without MSA/templates; exact NatureLM predictor configuration is unavailable.',
   'The whole canonical sequence must contain20–512residues; no crop, repair, redesign, selection or retry is permitted. This declared interface is not the original paper sampling condition.',
   'All five complexes are retained without HemeList, keyword, model-confidence or geometric selection.',
   'Generation uses a compact JSON regex that preserves every20–512residue canonical sequence while excluding formatting whitespace; this is a prospective delivery adaptation.',
   'Confidence and heavy-atom proximity are computational observations only. No measured binding, functional validation, accuracy score or native-paper comparison is claimed.'
  ]}
 local_code=sorted(HERE.glob('*.py'))+[HERE/'worker.sbatch']
 upstream_public=[source/x for x in ['runner/inference.py','runner/dumper.py','protenix/data/infer_data_pipeline.py','protenix/data/compute_esm.py','protenix/data/esm_featurizer.py']]
 plan['public_code_paths']=[str(p)for p in [*local_code,*upstream_public]]
 files=[*local_code,*source.rglob('*.py'),*source.glob('requirements*.txt'),Path(plan['predictor_model_config']),library_manifest,
   TASK/'runtime_preparation_v1/source_manifest.json',TASK/'runtime_preparation_v4/cpu_validation.json',TASK/'runtime_preparation_v4/strict_checkpoint_binding.json',TASK/'encoder_cpu_v1/status.json',TASK/'cuda_preparation_v1/installed_package_lock.txt',TASK/'portable_predictor_runtime_v1/status.json',HERE/'native_input_validation.json',HERE/'CPU_validation_receipt.json',
   TASK/'scope_direction_root_20261021.json',TASK/'independent_source_review_v1/protocol_scope_review.json',Path(plan['geometry_diagnostics_source']),
   *[Path(plan[key])for key in ['runtime_common','checkpoint_audit','vetted_V06_worker','site_tools_helper','vetted_neutral_hardware_source','project_gpu_audit_helper']],
   ROOT/'.local/catalog_execution_2026-10-20/tasks/V06/local_execution_v2/v06_runner.py',
   *[ROOT/'.local/litqa2_replay'/name for name in ['runtime_archive.json','cuda_overlay_archive.json','cuda_overlay_deletions.json','publisher_verification.json']],
   ROOT/'.local/catalog_execution_2026-10-20/dedicated_execution_20261021/delegated_engineering_review.json']
 for path in files:
  if path.is_symlink()or not path.is_file():raise ValueError('Exact regular frozen path missing: '+str(path))
 plan['frozen_files_sha256']={str(path):protocol.sha(path)for path in sorted(set(files))}
 protocol.write(HERE/'plan.json',plan)
 print(json.dumps({'plan':str(HERE/'plan.json'),'sha256':protocol.sha(HERE/'plan.json'),'pins':len(plan['frozen_files_sha256']),'model_calls':0,'GPU_allocations':0}))
if __name__=='__main__':build()
