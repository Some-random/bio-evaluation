"""One independently admitted allocation: predictor gate -> Qwen2+1 -> five CIFs."""
from pathlib import Path
import argparse,fcntl,importlib.util,json,os,shutil,signal,socket,subprocess,sys,tarfile,tempfile,time,urllib.error,urllib.request
import admission
import protocol
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]

def read(path):return json.loads(Path(path).read_bytes())
def load(name,path,extra=None):
 if extra:sys.path.insert(0,str(extra))
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module

def predictor_environment(common,local,predictor_site,source):
 env=common.environment(local)
 for key in list(env):
  if any(word in key.upper()for word in ['API_KEY','TOKEN','SECRET','PASSWORD','CREDENTIAL'])or key in ['SSH_AUTH_SOCK','NETRC','KUBECONFIG','PYTHONHOME','VIRTUAL_ENV','CUDA_HOME','CUDA_PATH','CUDACXX','CUDAHOSTCXX','NVCC','CC','CXX','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LIBRARY_PATH','CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','NVCC_PREPEND_FLAGS','NVCC_APPEND_FLAGS','TORCH_CUDA_ARCH_LIST']:env.pop(key,None)
 env['PATH']=':'.join([str(local/'python/bin'),'/usr/local/bin','/usr/bin','/bin'])
 env['PYTHONPATH']=':'.join([str(predictor_site),str(source),str(HERE)])
 env['LD_LIBRARY_PATH']=':'.join(str(p)for p in [local/'python/lib',predictor_site/'torch/lib',*sorted((predictor_site/'nvidia').glob('*/lib'))])
 env.update(PYTHONNOUSERSITE='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
 return env

def invoke_predictor(plan,args,common,local,site,phase):
 env=predictor_environment(common,local,site,plan['predictor_source_directory'])
 native_site=admission.load('p39_predictor_site_binding',plan['site_tools_helper']);env,_=native_site.bind_site_tools(env)
 command=[str(local/'python/bin/python3.12'),str(HERE/'predictor.py'),'--plan',str(args.plan),'--plan-sha256',args.plan_sha256,'--admission',str(args.admission),'--admission-sha256',args.admission_sha256,'--phase',phase]
 runtime=Path(plan['runtime_root'])
 with(runtime/('predictor_'+phase+'.log')).open('x')as log:subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=7200)
 result=read(runtime/('predictor_'+phase)/'completion.json')
 if result['plan_sha256']!=args.plan_sha256 or result['predicted_structures']!=5 or result['all_five_structures_valid']is not True:raise ValueError('Complete original five-sample predictor closure required')
 return result

def generate_phase(plan,args,common,identity,phase):
 runtime=Path(plan['runtime_root']);folder=runtime/'generation'/phase;folder.mkdir(parents=True,exist_ok=False)
 planned=2 if phase=='development'else 1
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));identity_sha=protocol.sha(runtime/'qwen_server_identity.json')
 outcomes=[];halted=False
 def counts():
  attempted=[o for o in outcomes if o['attempted']]
  return {'planned':planned,'attempted_confirmed':len(attempted),'terminal':len(attempted),'recorded_outcomes':len(outcomes),'not_dispatched':sum(o['not_dispatched']for o in outcomes),'responses_saved':sum(o.get('response_saved',False)for o in attempted),'delivered':sum(o['status']=='delivered'for o in attempted),'observed_empty_finals':sum(o['empty_final']for o in attempted),'unknown_finals':sum(not o['observed_final']for o in attempted),'http_errors':sum(o.get('http_errors',0)for o in attempted),'server_errors':sum(o.get('server_error',False)for o in attempted),'transport_errors':sum(o.get('transport_errors',0)for o in attempted),'response_errors':sum(o.get('response_errors',0)for o in attempted),'truncations':sum(o.get('truncation',False)for o in attempted),'refusals':sum(o.get('refusal',False)for o in attempted),'reasoning_present':sum(o.get('reasoning_present',False)for o in attempted),'tool_calls_present':sum(o.get('tool_calls_present',False)for o in attempted)}
 for index in range(planned):
  case=folder if phase=='benchmark'else folder/('case_'+str(index));case.mkdir(exist_ok=True)
  if halted:
   outcome={'status':'prior_development_gate_failure_not_dispatched','attempted':False,'not_dispatched':True,'observed_final':False,'empty_final':False,'sequence':None}
  else:
   if protocol.sha(runtime/'qwen_server_identity.json')!=identity_sha or common.start_ticks(identity['pid'])!=identity['proc_start_ticks']or identity['job_id']!=os.environ['SLURM_JOB_ID']or identity['hostname']!=socket.gethostname():raise PermissionError('Exact owned Qwen server identity changed')
   body=protocol.payload(development=phase=='development',index=index);protocol.write(case/'request.json',body)
   request=urllib.request.Request(plan['endpoint']+'/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
   try:
    with opener.open(request,timeout=1800)as response:raw=response.read(16*1024*1024+1)
    with(case/'response.raw.json').open('xb')as stream:stream.write(raw)
    if len(raw)>16*1024*1024:
     outcome={'status':'response_size_limit_exceeded','observed_final':False,'empty_final':False,'sequence':None,'response_errors':1,'raw_capture_complete':False}
    else:outcome=protocol.development_outcome(raw,index)if phase=='development'else protocol.parse_reply(raw)
    outcome['response_saved']=True
   except urllib.error.HTTPError as error:
    raw=error.read(16*1024*1024+1)
    with(case/'http_error.raw').open('xb')as stream:stream.write(raw)
    outcome={'status':'HTTP_failure','observed_final':False,'empty_final':False,'sequence':None,'http_errors':1,'http_status':error.code,'server_error':500<=error.code<=599,'error_body_capture_complete':len(raw)<=16*1024*1024}
    protocol.write(case/'transport_error.json',{'error_type':'HTTPError','http_status':error.code,'server_acceptance_unknown':True,'one_attempt_only':True})
   except(urllib.error.URLError,TimeoutError,OSError)as error:
    outcome={'status':'transport_failure','observed_final':False,'empty_final':False,'sequence':None,'transport_errors':1}
    protocol.write(case/'transport_error.json',{'error_type':type(error).__name__,'server_acceptance_unknown':True,'one_attempt_only':True})
   outcome.update(attempted=True,not_dispatched=False)
   if phase=='development'and outcome.get('artificial_exact_copy_passed')is not True:halted=True
  protocol.write(case/'outcome.json',outcome);outcomes.append(outcome)
  protocol.write(folder/'progress.json',{'at_pacific':protocol.now(),'role':'direct_unsealed_lower_bound','phase':phase,**counts()},exclusive=False)
 lock={'plan_sha256':args.plan_sha256,'phase':phase,'planned':planned,'files_sha256':{str(p.relative_to(folder)):protocol.sha(p)for p in sorted(folder.rglob('*'))if p.is_file()and p.name!='progress.json'}}
 protocol.write(folder/'prediction_lock.json',lock)
 complete={'at_pacific':protocol.now(),'plan_sha256':args.plan_sha256,'phase':phase,**counts(),'all_delivered':all(o['status']=='delivered'for o in outcomes),'exact_copy_gate_passed':all(o.get('artificial_exact_copy_passed')is True for o in outcomes)if phase=='development'else None,'prediction_lock_sha256':protocol.sha(folder/'prediction_lock.json')}
 protocol.write(folder/'completion.json',complete)
 return complete

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--plan-sha256',required=True);parser.add_argument('--admission',type=Path);parser.add_argument('--admission-sha256');parser.add_argument('--runtime-dir',type=Path);parser.add_argument('--check-only',action='store_true');args=parser.parse_args()
 plan=admission.validate(args.plan,args.plan_sha256)
 if args.check_only:print(json.dumps({'planned_qualitative_cases':1,'actual_admission_required':True,'model_calls':0,'GPU_allocations':0}));return
 if args.admission is None or args.admission_sha256 is None:raise PermissionError('Exact independent detached grant required')
 admission.validate(args.plan,args.plan_sha256,args.admission,args.admission_sha256,require_job=True)
 runtime=Path(plan['runtime_root']);runtime.mkdir(exist_ok=True)
 shared=load('p39_vetted_v06_helpers',plan['vetted_V06_worker'],Path(plan['vetted_V06_worker']).parent);common=shared.common_module(plan)
 if args.runtime_dir is None:
  own=(runtime/'allocation.lock').open('a');fcntl.flock(own,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if(runtime/'allocation_started.json').exists():raise FileExistsError('Never blindly repeat an allocation or partial case')
  protocol.write(runtime/'private_GPU_audit_at_start.json',admission.current_project_audit(plan))
  protocol.write(runtime/'allocation_started.json',{'at_pacific':protocol.now(),'job_id':os.environ['SLURM_JOB_ID'],'plan_sha256':args.plan_sha256})
  protocol.write(runtime/'status.json',{'at_pacific':protocol.now(),'stage':'verifying_and_restoring_private_CPU_runtime','job_id':os.environ['SLURM_JOB_ID'],'model_phases_not_started_by_this_worker':True})
  if shutil.disk_usage('/tmp').free<48*1024**3:raise ValueError('At least48GiB private local scratch required')
  for field in ['base_runtime','cuda_overlay','predictor_libraries']:
   if protocol.sha(plan[field]['path'])!=plan[field]['sha256']:raise ValueError('Frozen runtime archive changed')
  local=Path(tempfile.mkdtemp(prefix='bio-p39-'+os.environ['SLURM_JOB_ID']+'-'))
  with tarfile.open(plan['base_runtime']['path'])as tar:tar.extractall(local,filter='data')
  protocol.write(runtime/'archive_receipt.json',{'local_prefix':str(local),**common.apply_overlay(local)})
  env=shared.clean_environment(common,local);site=admission.load('p39_site_tools',plan['site_tools_helper']);env,tools=site.bind_site_tools(env)
  env.update(PYTHONPATH=str(HERE),VLLM_USE_V2_MODEL_RUNNER='0')
  protocol.write(runtime/'site_tool_binding.json',{'tools':tools});shared.install_private_runtime(local/'python/bin/python3.12',env,runtime)
  cpu_env=dict(env);cpu_env['CUDA_VISIBLE_DEVICES']=''
  command=[str(local/'python/bin/python3.12'),str(HERE/'check_inputs_cpu.py'),'--output',str(runtime/'native_input_validation.json')]
  with(runtime/'native_input_validation.log').open('x')as log:subprocess.run(command,env=cpu_env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
  checked=read(runtime/'native_input_validation.json')
  if checked['packages']['vllm']!='0.32.0'or checked['exact_vllm032_API_recheck_required_before_model_phases']is not False:raise ValueError('Actual exact0.32 JSON API/full-tokenizer gate required before any model phase')
  command=[str(local/'python/bin/python3.12'),str(Path(__file__).resolve()),*sys.argv[1:],'--runtime-dir',str(local)];os.execve(command[0],command,env)
 local=args.runtime_dir.resolve()
 if not local.name.startswith('bio-p39-'+os.environ['SLURM_JOB_ID']+'-'):raise PermissionError('Private runtime prefix ownership mismatch')
 own=(runtime/'execution.lock').open('a');fcntl.flock(own,fcntl.LOCK_EX|fcntl.LOCK_NB)
 if any((runtime/name).exists()for name in ['predictor_resource','generation','terminal_receipt.json']):raise FileExistsError('No partial or completed scientific phase may be repeated')
 # Native library restoration happens on CPU; only the native child touches its
 # checkpoint/device after its own exact grant + fresh real-job resource guard.
 overlay=local/'predictor_libraries';overlay.mkdir()
 with tarfile.open(plan['predictor_libraries']['path'])as tar:tar.extractall(overlay,filter='data')
 native_site=overlay/'site-packages';manifest=read(plan['predictor_library_manifest'])
 for row in manifest['files']:
  if protocol.sha(native_site/row['path'])!=row['sha256']:raise ValueError('Restored exact predictor library changed')
 server=None
 try:
  protocol.write(runtime/'status.json',{'at_pacific':protocol.now(),'stage':'actual_artificial_predictor_resource_gate'},exclusive=False)
  resource=invoke_predictor(plan,args,common,local,native_site,'resource')
  protocol.write(runtime/'private_GPU_audit_at_Qwen_start.json',admission.current_project_audit(plan))
  import importlib.metadata as metadata
  shared.verify_package_identity({'packages':{name:metadata.version(name)for name in shared.PINNED_PACKAGES}})
  import torch
  if torch.cuda.device_count()!=1:raise PermissionError('Owned Qwen process requires exactly one visible CUDA device')
  qwen_uuid=str(torch.cuda.get_device_properties(0).uuid);qwen_uuid=qwen_uuid if qwen_uuid.startswith('GPU-')else'GPU-'+qwen_uuid
  if qwen_uuid!=read(runtime/'predictor_resource/hardware_gate.json')['GPU_uuid']:raise PermissionError('Qwen and predictor must use the same actual allocated GPU')
  model=common.validate_checkpoint(plan['model'],plan['model_revision'])
  if str(model)!=plan['model_directory']:raise ValueError('Original pinned Qwen checkpoint required')
  with socket.socket()as probe:probe.bind(('127.0.0.1',8439))
  command=[str(local/'python/bin/python3.12'),'-m','vllm.entrypoints.cli.main','serve',str(model),'--served-model-name',plan['model'],'--host','127.0.0.1','--port','8439','--dtype','bfloat16','--tensor-parallel-size','1','--gpu-memory-utilization','0.95','--max-model-len','65536','--max-num-seqs','2','--max-num-batched-tokens','8192','--reasoning-parser','qwen3','--limit-mm-per-prompt','{"image":0,"video":0}']
  protocol.write(runtime/'status.json',{'at_pacific':protocol.now(),'stage':'starting_dedicated_Qwen_server'},exclusive=False)
  with(runtime/'qwen_server.log').open('x')as log:server=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,cwd=local)
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));deadline=time.monotonic()+1800
  while time.monotonic()<deadline:
   if server.poll()is not None:raise RuntimeError('Owned Qwen server exited during readiness')
   try:
    with opener.open('http://127.0.0.1:8439/health',timeout=3)as response:
     if response.status==200:break
   except(OSError,urllib.error.URLError):time.sleep(3)
  else:raise TimeoutError('Owned server startup timed out')
  with opener.open(plan['endpoint']+'/models',timeout=5)as response:models=json.load(response)
  if [r['id']for r in models['data']]!=[plan['model']]:raise ValueError('Actual served model differs')
  identity={'at_pacific':protocol.now(),'job_id':os.environ['SLURM_JOB_ID'],'hostname':socket.gethostname(),'pid':server.pid,'proc_start_ticks':common.start_ticks(server.pid),'model':plan['model'],'revision':plan['model_revision'],'plan_sha256':args.plan_sha256,'endpoint':plan['endpoint']}
  protocol.write(runtime/'qwen_server_identity.json',identity)
  dev=generate_phase(plan,args,common,identity,'development')
  if dev['exact_copy_gate_passed']is not True:raise RuntimeError('Actual exact-copy artificial delivery gate failed; no benchmark')
  generated=generate_phase(plan,args,common,identity,'benchmark')
  if generated['all_delivered']is not True:raise RuntimeError('Single generated outcome invalid; retain without retry or predictor substitution')
  os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=60)
  protocol.write(runtime/'qwen_server_terminal.json',{'at_pacific':protocol.now(),'own_server_stopped':True})
  result=invoke_predictor(plan,args,common,local,native_site,'benchmark')
  protocol.write(runtime/'scoring_status.json',{'at_pacific':protocol.now(),'primary_metric':None,'reason':'No released measured-binding gold/accuracy definition; preserve all five predicted-geometry/confidence observations.','biological_function_validated':False,'native_NatureLM_replication':False})
  packager=load('p39_exact_public_packager',plan['packager']);bundle=packager.package(plan,runtime,args.plan_sha256)
  protocol.write(runtime/'terminal_receipt.json',{'at_pacific':protocol.now(),'stage':'qualified_single_demonstration_five_structures_complete','generated_cases':1,'predicted_structures':5,'native_NatureLM_replication':False,'measured_binding_assessed':False,'primary_metric':None,'bundle_sha256':bundle['sha256'],'public_upload_performed':False})
  protocol.write(runtime/'status.json',{'at_pacific':protocol.now(),'stage':'qualified_single_demonstration_five_structures_complete','generated_cases':1,'predicted_structures':5,'primary_metric':None,'bundle_sha256':bundle['sha256'],'public_upload_performed':False},exclusive=False)
 except Exception as error:
  protocol.write(runtime/'status.json',{'at_pacific':protocol.now(),'stage':'stopped_for_review_no_automatic_retry','error_type':type(error).__name__,'error':str(error),'missing_progress_is_not_zero_attempts':True},exclusive=False);raise
 finally:
  if server is not None and server.poll()is None:
   os.killpg(server.pid,signal.SIGTERM)
   try:server.wait(timeout=60)
   except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait(timeout=10)
  if not(runtime/'qwen_server_terminal.json').exists():protocol.write(runtime/'qwen_server_terminal.json',{'at_pacific':protocol.now(),'own_server_stopped':True,'server_never_started':server is None})
if __name__=='__main__':main()
