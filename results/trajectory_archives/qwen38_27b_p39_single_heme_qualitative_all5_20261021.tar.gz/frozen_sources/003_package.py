"""Seal one generated outcome and all five structures; no binding score exists."""
from pathlib import Path
import io,json,tarfile
import protocol
HERE=Path(__file__).resolve().parent

def read(path):return json.loads(Path(path).read_bytes())
def verify_lock(folder,plan_sha,phase):
 completion=read(folder/'completion.json');lockfile=folder/'prediction_lock.json';lock=read(lockfile)
 if completion.get('phase')!=phase or lock.get('phase')!=phase or completion.get('plan_sha256')!=plan_sha or completion.get('prediction_lock_sha256')!=protocol.sha(lockfile)or lock.get('plan_sha256')!=plan_sha:raise ValueError('Complete exact phase/plan prediction seal required')
 for rel,digest in lock['files_sha256'].items():
  path=folder/rel
  if Path(rel).is_absolute()or'..'in Path(rel).parts or path.is_symlink()or protocol.sha(path)!=digest:raise ValueError('Changed or unsafe sealed outcome')
 return completion,lock

def materialize(plan,runtime,plan_sha):
 for path in plan['public_code_paths']:
  if Path(path).is_symlink()or plan['frozen_files_sha256'].get(str(path))!=protocol.sha(path):raise ValueError('Exact frozen public source changed before packaging')
 dev,dev_lock=verify_lock(runtime/'generation/development',plan_sha,'development')
 generated,generation_lock=verify_lock(runtime/'generation/benchmark',plan_sha,'benchmark')
 resource,resource_lock=verify_lock(runtime/'predictor_resource',plan_sha,'resource')
 predicted,prediction_lock=verify_lock(runtime/'predictor_benchmark',plan_sha,'benchmark')
 if dev.get('exact_copy_gate_passed')is not True or dev['planned']!=2 or dev['delivered']!=2:raise ValueError('Two exact artificial copies must precede demonstration')
 if generated['planned']!=1 or generated['delivered']!=1 or generated['responses_saved']!=1:raise ValueError('Exactly one whole generated outcome required')
 if resource.get('sequence_length')!=512 or resource.get('all_five_structures_valid')is not True:raise ValueError('Full-length actual resource gate required')
 for record in [resource,predicted]:
  if record.get('predicted_structures')!=5 or record.get('all_five_structures_valid')is not True or record.get('measured_binding_assessed')is not False or record.get('binding_accuracy')is not None or record.get('native_NatureLM_replication')is not False:raise ValueError('All five qualitative structures required without invented correctness')
 raw=(runtime/'generation/benchmark/response.raw.json').read_bytes();outcome=protocol.parse_reply(raw)
 if outcome['status']!='delivered'or outcome['sequence_sha256']!=predicted['sequence_sha256']:raise ValueError('Whole native predictor input must match exact saved generation')
 scoring=read(runtime/'scoring_status.json')
 if scoring['primary_metric']is not None or scoring['biological_function_validated']is not False:raise ValueError('No gold binding/function accuracy exists')
 own=read(runtime/'qwen_server_terminal.json')
 if own.get('own_server_stopped')is not True:raise ValueError('Owned Qwen server must be terminal')
 result={'task_id':'P39','title':'Heme-complex generation: one qualitative demonstration','condition':protocol.CONDITION,'model':protocol.MODEL,'model_revision':plan['model_revision'],'planned_generated_cases':1,'responses_saved':1,'generated_cases':1,'sequence_length':outcome['sequence_length'],'sequence_sha256':outcome['sequence_sha256'],'structures_saved':5,'predictor':'Protenix-mini-ISM v0.5.0','predictor_source_revision':plan['predictor_source_revision'],'sampling':{'seeds':[101],'samples':5,'diffusion_steps':5,'all_samples_retained':True,'ranking_or_HemeList_selection':False},'primary_metric':None,'native_NatureLM_replication':False,'measured_binding_assessed':False,'biological_function_validated':False,'claims':'Predicted structure, confidence and geometric proximity only; no experimental binding or functional validation.','qualifications':plan['scientific_differences'],'plan_sha256':plan_sha,'generation_lock_sha256':protocol.sha(runtime/'generation/benchmark/prediction_lock.json'),'predictor_lock_sha256':protocol.sha(runtime/'predictor_benchmark/prediction_lock.json'),'observations':predicted['observations']}
 members={}
 def add(name,path):
  p=Path(path)
  if p.is_symlink()or not p.is_file():raise ValueError('Only exact regular whitelisted artifacts')
  if any(part in ['.local','checkpoints','site-packages','__pycache__']for part in Path(name).parts)or Path(name).is_absolute()or'..'in Path(name).parts:raise ValueError('Unsafe public archive path')
  data=p.read_bytes()
  if len(data)>32*1024*1024:raise ValueError('Unexpected public artifact size')
  members[name]=data
 # Keep actual requests, raw responses and every outcome, including all five
 # artificial resource structures. Exclude model weights, ESM tensor caches,
 # environments, unrestricted logs and private account-wide resource records.
 for phase,lock in [('development',dev_lock),('benchmark',generation_lock)]:
  folder=runtime/'generation'/phase
  expected={prefix+name for prefix in(['case_0/','case_1/']if phase=='development'else[''])for name in['request.json','response.raw.json','outcome.json']}
  if set(lock['files_sha256'])!=expected:raise ValueError('Only mandatory locked actual request/raw/outcome records may be exported')
  closed={'progress.json','prediction_lock.json','completion.json'}
  actual={str(p.relative_to(folder))for p in folder.rglob('*')if p.is_file()or p.is_symlink()}
  if actual!=expected|closed:raise ValueError('Unsealed generation extras are forbidden')
  for rel in sorted(expected|closed):add('generation/'+phase+'/'+rel,folder/rel)
 for phase,lock in [('resource',resource_lock),('benchmark',prediction_lock)]:
  folder=runtime/('predictor_'+phase)
  for rel in lock['files_sha256']:
   if rel=='predictor_config.json':
    original=read(folder/rel);public=json.loads(json.dumps(original));public.update(input_json_path='input.json',dump_dir='outputs',load_checkpoint_dir='MODEL_REFERENCES_ONLY')
    public['data']['ccd_components_file']='CCD_CIF_REFERENCE';public['data']['ccd_components_rdkit_mol_file']='CCD_RDKIT_REFERENCE'
    members['predictor/'+phase+'/'+rel]=(json.dumps({'public_configuration':public,'original_sha256':protocol.sha(folder/rel),'only_local_asset_paths_redacted':True},indent=2,allow_nan=False)+'\n').encode()
   else:add('predictor/'+phase+'/'+rel,folder/rel)
  for name in ['completion.json','prediction_lock.json']:add('predictor/'+phase+'/'+name,folder/name)
 for name in ['qwen_server_identity.json','qwen_server_terminal.json','scoring_status.json']:add('runtime/'+name,runtime/name)
 members['result.json']=(json.dumps(result,indent=2,allow_nan=False)+'\n').encode()
 model_refs={key:{'sha256':value['sha256'],'bytes':Path(value['path']).stat().st_size,'basename':Path(value['path']).name}for key,value in plan['predictor_assets'].items()}
 members['model_references.json']=(json.dumps({'Qwen':{'model':plan['model'],'revision':plan['model_revision']},'predictor_source_revision':plan['predictor_source_revision'],'assets':model_refs,'weights_included':False},indent=2)+'\n').encode()
 for index,path in enumerate(plan['public_code_paths']):add('frozen_sources/'+str(index).zfill(3)+'_'+Path(path).name,path)
 source_manifest={str(index).zfill(3)+'_'+Path(path).name:{'sha256':protocol.sha(path),'original_basename':Path(path).name}for index,path in enumerate(plan['public_code_paths'])}
 members['source_manifest.json']=(json.dumps(source_manifest,indent=2)+'\n').encode()
 lines=['# Heme-complex generation: one qualitative demonstration','','Qwen3.8-27B generated one complete sequence. Protenix-mini-ISM v0.5.0 produced all five predicted complexes; every sample is retained.','','These are computational structure and confidence observations. There is no measured binding, validated function, accuracy score or native NatureLM replication.','','| Sample | Minimum heavy-atom distance (Å) | Contact pairs within 4 Å |','|---|---:|---:|']
 for row in predicted['observations']:
  value=row['geometry'];lines.append('| '+row['sample_file']+' | '+format(value['minimum_heavy_atom_distance_angstrom'],'.3f')+' | '+str(value['heavy_atom_contact_pairs'])+' |')
 lines+=['','The artificial 512-residue resource gate and two exact-copy delivery checks passed before the single demonstration.','',*['- '+x for x in plan['scientific_differences']],'']
 members['README.md']='\n'.join(lines).encode()
 return result,members

def package(plan,runtime,plan_sha):
 result,members=materialize(plan,runtime,plan_sha)
 output=runtime/'publication';output.mkdir(exist_ok=False)
 for name in ['result.json','README.md']:(output/name).write_bytes(members[name])
 path=output/'P39_single_heme_qualitative_all5.tar.gz'
 with path.open('xb')as raw:
  import gzip
  with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0)as compressed:
   with tarfile.open(fileobj=compressed,mode='w')as tar:
    for name,data in sorted(members.items()):
     info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0;tar.addfile(info,io.BytesIO(data))
 manifest={'at_pacific':protocol.now(),'archive':str(path),'sha256':protocol.sha(path),'bytes':path.stat().st_size,'members':len(members),'members_sha256':{name:__import__('hashlib').sha256(data).hexdigest()for name,data in sorted(members.items())},'no_weights_or_environments_or_private_account_inventory':True,'native_accuracy_available':False,'public_upload_performed':False}
 protocol.write(output/'manifest.json',manifest)
 return manifest
