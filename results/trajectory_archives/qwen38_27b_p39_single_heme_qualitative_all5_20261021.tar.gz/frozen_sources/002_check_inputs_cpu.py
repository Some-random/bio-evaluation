"""Exact full rendered prompts and installed vLLM JSON API, no model forwards."""
from pathlib import Path
import importlib.metadata as metadata,json,os,sys
import protocol
HERE=Path(__file__).resolve().parent

def check(output):
 if os.environ.get('CUDA_VISIBLE_DEVICES')!='':raise ValueError('CPU-only validation requires CUDA hidden')
 from transformers import AutoTokenizer
 from vllm.entrypoints.openai.chat_completion.protocol import ChatCompletionRequest
 from vllm.sampling_params import StructuredOutputsParams
 tokenizer=AutoTokenizer.from_pretrained('/dfs/scratch0/tchen/models/Qwen3.8-27B',local_files_only=True)
 rows=[]
 for phase,index in [('development',0),('development',1),('benchmark',0)]:
  payload=protocol.payload(development=phase=='development',index=index)
  parsed=ChatCompletionRequest.model_validate(payload)
  if parsed.structured_outputs is None or parsed.structured_outputs.regex!=protocol.SERIALIZATION_REGEX:raise ValueError('Exact compact JSON regex not preserved by native vLLM API')
  params=StructuredOutputsParams(regex=protocol.SERIALIZATION_REGEX)
  rendered=tokenizer.apply_chat_template(payload['messages'],tokenize=False,add_generation_prompt=True,**payload['chat_template_kwargs'])
  if not isinstance(rendered,str)or payload['messages'][0]['content']not in rendered:raise ValueError('Full unchanged question must survive actual chat template')
  encoded=tokenizer.apply_chat_template(payload['messages'],tokenize=True,return_dict=True,truncation=False,add_generation_prompt=True,**payload['chat_template_kwargs'])
  ids=encoded['input_ids']
  if ids and isinstance(ids[0],list):ids=ids[0]
  if len(ids)<10 or len(ids)+16384>65536:raise ValueError('Full input must fit without truncation')
  rows.append({'phase':phase,'index':index,'prompt_tokens':len(ids),'max_tokens':16384,'all_fields_accepted':True,'compact_regex_preserved':params.regex==protocol.SERIALIZATION_REGEX,'maximum_complete_output_ASCII_bytes':527,'all20_to512canonical_sequences_permitted':True,'full_rendered_prompt_sha256':__import__('hashlib').sha256(rendered.encode()).hexdigest()})
 receipt={'at_pacific':protocol.now(),'stage':'actual_native_tokenizer_and_installed_structured_JSON_API_passed','model':'Qwen/Qwen3.8-27B','model_revision':'1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0','packages':{name:metadata.version(name)for name in ['vllm','transformers','torch']},'per_case':rows,'all_full_inputs_fit':True,'model_forwards':0,'GPU_allocations_by_this_check':0,'native_API_source_sha256':protocol.sha(__import__('inspect').getfile(ChatCompletionRequest)),'exact_vllm032_API_recheck_required_before_model_phases':metadata.version('vllm')!='0.32.0'}
 protocol.write(output,receipt);return receipt
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();print(json.dumps(check(a.output)))
