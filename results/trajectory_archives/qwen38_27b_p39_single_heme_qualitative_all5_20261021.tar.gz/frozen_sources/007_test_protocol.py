"""Artificial sequence/contract checks only; no source biological cases or models."""
import json,re,tempfile,unittest
from pathlib import Path
import protocol

def response(content,reason='stop',**extra):return json.dumps({'choices':[{'message':{'content':content,**extra},'finish_reason':reason}]}).encode()
class Tests(unittest.TestCase):
 def test_single_fixed_question_and_sampling(self):
  p=protocol.payload();self.assertEqual(len(p['messages']),1);self.assertEqual(p['messages'][0]['content'],protocol.QUESTION);self.assertEqual(p['max_tokens'],16384);self.assertEqual(p['temperature'],0);self.assertEqual(p['seed'],42);self.assertEqual(p['structured_outputs']['regex'],protocol.SERIALIZATION_REGEX)
  for index in [0,1]:
   expected=protocol.development_expected(index)
   self.assertTrue(protocol.development_outcome(response(json.dumps({'sequence':expected},separators=(',',':'))),index)['artificial_exact_copy_passed'])
   self.assertFalse(protocol.development_outcome(response(json.dumps({'sequence':'A'*40})),index)['artificial_exact_copy_passed'])
 def test_full_artificial_sequence_preserved(self):
  seq='ACDEFGHIKLMNPQRSTVWY'*25
  parsed=protocol.parse_reply(response(json.dumps({'sequence':seq},separators=(',',':'))));self.assertEqual(parsed['sequence'],seq);self.assertEqual(parsed['sequence_length'],500)
  value=protocol.complex_input(seq,'ARTIFICIAL');self.assertEqual(value[0]['sequences'][0]['proteinChain']['sequence'],seq);self.assertEqual(value[0]['sequences'][1]['ligand']['ligand'],'CCD_HEM')
 def test_invalid_outputs_never_cropped_or_repaired(self):
  for seq in ['A'*19,'A'*513,'A'*20+'X','A'*20+'\n']:
   r=protocol.parse_reply(response(json.dumps({'sequence':seq},separators=(',',':'))))
   self.assertNotEqual(r['status'],'delivered');self.assertTrue(r['observed_final']);self.assertFalse(r['empty_final'])
   with self.assertRaises(ValueError):protocol.complex_input(seq,'CASE')
 def test_observed_empty_distinct_from_unknown_final(self):
  for content in [None,'','   ']:self.assertTrue(protocol.parse_reply(response(content))['empty_final'])
  for raw in [b'not JSON',b'{}',response(['wrong type'])]:
   r=protocol.parse_reply(raw);self.assertFalse(r['observed_final']);self.assertFalse(r['empty_final'])
 def test_truncated_reasoning_refusal_not_delivery(self):
  text=json.dumps({'sequence':'A'*20})
  for raw in [response(text,'length'),response(text,reasoning_content='x'),response(text,refusal='x')]:self.assertNotEqual(protocol.parse_reply(raw)['status'],'delivered')
 def test_unknown_result_fields_not_accepted(self):
  self.assertNotEqual(protocol.parse_reply(response(json.dumps({'sequence':'A'*20,'binding_success':True})))['status'],'delivered')
 def test_alternate_reasoning_tools_and_distinct_truncation_flags(self):
  text=json.dumps({'sequence':'A'*20},separators=(',',':'))
  for extra,flag in [({'reasoning':'hidden'},'reasoning_present'),({'tool_calls':[{'function':{}}]},'tool_calls_present'),({'refusal':'declined'},'refusal')]:
   value=protocol.parse_reply(response(text,**extra));self.assertNotEqual(value['status'],'delivered');self.assertTrue(value[flag]);self.assertTrue(value['observed_final']);self.assertFalse(value['empty_final'])
  value=protocol.parse_reply(response(None,'length'));self.assertTrue(value['empty_final']);self.assertTrue(value['truncation'])
  for raw in [b'[]',b'{"choices":[null]}',b'{"choices":[{"message":null}]}']:
   value=protocol.parse_reply(raw);self.assertEqual(value['response_errors'],1);self.assertFalse(value['observed_final'])
 def test_compact_regex_preserves_sequence_space_and_excludes_whitespace(self):
  for char in 'ACDEFGHIKLMNPQRSTVWY':
   for length in [20,512]:
    text=json.dumps({'sequence':char*length},separators=(',',':'));self.assertIsNotNone(re.fullmatch(protocol.SERIALIZATION_REGEX,text));self.assertEqual(protocol.parse_reply(response(text))['status'],'delivered')
  text=json.dumps({'sequence':'A'*20})
  self.assertEqual(protocol.parse_reply(response(text))['status'],'invalid_schema')
 def test_all_five_predictor_samples_preserved_without_selection(self):
  cfg={'sample_diffusion':{'N_sample':5,'N_step':5},'seeds':[101],'data':{'msa':{'enable':True},'template':{'enable':False}}}
  c=protocol.predictor_configuration(cfg,input_json='artificial.json',dump_dir='out',checkpoints='weights')
  self.assertFalse(c['sorted_by_ranking_score']);self.assertEqual(c['sample_diffusion']['N_sample'],5);self.assertFalse(c['use_msa']);self.assertEqual(c['num_workers'],0);self.assertTrue(c['load_strict']);self.assertEqual(c['triangle_attention'],'torch')
  cfg['sample_diffusion']['N_sample']=1
  with self.assertRaises(ValueError):protocol.predictor_configuration(cfg,input_json='x',dump_dir='o',checkpoints='w')
if __name__=='__main__':unittest.main()
