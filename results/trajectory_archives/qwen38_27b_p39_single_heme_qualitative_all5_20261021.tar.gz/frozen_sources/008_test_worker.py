"""Artificial admission, transport, seal and public-packaging tests; zero model work."""
from pathlib import Path
from types import SimpleNamespace
import copy,hashlib,io,json,os,socket,tempfile,unittest,urllib.error
from unittest.mock import patch
import admission,package,predictor,protocol,worker

def response(sequence):return json.dumps({'choices':[{'message':{'content':json.dumps({'sequence':sequence},separators=(',',':'))},'finish_reason':'stop'}]}).encode()
class Tests(unittest.TestCase):
 def test_predictor_child_cannot_inherit_Qwen_CUDA13_compiler(self):
  common=SimpleNamespace(environment=lambda p:{'CUDA_HOME':'/sentinel/cu13','CUDACXX':'/sentinel/cu13/bin/nvcc','NVCC':'/sentinel/cu13/bin/nvcc','PATH':'/sentinel/cu13/bin:/bin','LD_LIBRARY_PATH':'/sentinel/cu13/lib','API_KEY':'private','CXXFLAGS':'--cuda13','CUDA_VISIBLE_DEVICES':'0'})
  env=worker.predictor_environment(common,Path('/runtime'),Path('/native/site-packages'),Path('/source'))
  self.assertEqual(env['CUDA_VISIBLE_DEVICES'],'0');self.assertFalse(any('/sentinel/'in value for value in env.values()));self.assertNotIn('CUDA_HOME',env);self.assertNotIn('CUDACXX',env);self.assertNotIn('API_KEY',env)
 def plan(self,root):
  p={'task_id':'P39','condition':protocol.CONDITION,'model':protocol.MODEL,'planned_generated_cases':1,'development_planned':2,'gpus_requested':1,'maximum_sequence_length':512,'predictor_samples_per_case':5,'native_NatureLM_replication':False,'measured_binding_assessed':False,'biological_function_validated':False,'new_training':False,'paid_model_calls':False,'automatic_retries':False,'frozen_files_sha256':{}}
  path=root/'plan.json';protocol.write(path,p);return path,protocol.sha(path),p
 def test_owner_may_not_admit(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);path,digest,p=self.plan(root);grant={k:p[k]for k in ['task_id','condition','planned_generated_cases','native_NatureLM_replication','measured_binding_assessed','biological_function_validated','new_training','paid_model_calls']};grant.update(admitted=True,reviewer=admission.OWNER,plan_sha256=digest,gpu_count=1,project_gpu_ceiling=8,one_attempt_per_case=True);g=root/'grant.json';protocol.write(g,grant)
   with self.assertRaises(PermissionError):admission.validate(path,digest,g,protocol.sha(g))
 def test_changed_frozen_input_and_invented_metric_scope_rejected(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);path,digest,p=self.plan(root);item=root/'input';item.write_text('original');p['frozen_files_sha256'][str(item)]=protocol.sha(item);path.write_text(json.dumps(p));digest=protocol.sha(path);item.write_text('changed')
   with self.assertRaises(ValueError):admission.validate(path,digest)
   p['frozen_files_sha256']={};p['measured_binding_assessed']=True;path.write_text(json.dumps(p))
   with self.assertRaises(ValueError):admission.validate(path,protocol.sha(path))
 def test_exact_own_worker_required(self):
  plan={'site_tools_helper':'unused','project_gpu_audit_helper':'unused'}
  site=SimpleNamespace(bind_site_tools=lambda env:(env,[]))
  own={'job_id':'123','gpus':1,'command':str(admission.HERE/'worker.sbatch'),'workdir':str(admission.ROOT)}
  audit=SimpleNamespace(conservative_project_gpu_audit=lambda **k:{'jobs':[own]})
  with patch.dict(os.environ,{'SLURM_JOB_ID':'123'}),patch.object(admission,'load',side_effect=[site,audit]):self.assertEqual(len(admission.current_project_audit(plan)['jobs']),1)
  own['command']='/someone/else.sbatch'
  with patch.dict(os.environ,{'SLURM_JOB_ID':'123'}),patch.object(admission,'load',side_effect=[site,audit]):
   with self.assertRaises(PermissionError):admission.current_project_audit(plan)
 def test_transport_unknown_is_not_observed_empty(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);identity={'job_id':'123','pid':42,'proc_start_ticks':'ticks','hostname':socket.gethostname()};protocol.write(root/'qwen_server_identity.json',identity)
   opener=SimpleNamespace(open=lambda *a,**k:(_ for _ in ()).throw(TimeoutError('artificial timeout')))
   with patch.dict(os.environ,{'SLURM_JOB_ID':'123'}),patch.object(worker.urllib.request,'build_opener',return_value=opener):
    result=worker.generate_phase({'runtime_root':str(root),'endpoint':'http://127.0.0.1:1/v1'},SimpleNamespace(plan_sha256='fixture'),SimpleNamespace(start_ticks=lambda pid:'ticks'),identity,'benchmark')
   self.assertEqual(result['unknown_finals'],1);self.assertEqual(result['observed_empty_finals'],0);self.assertEqual(result['responses_saved'],0)
   with self.assertRaises(FileExistsError):worker.generate_phase({'runtime_root':str(root)},None,None,None,'benchmark')
 def run_fake_phase(self,root,opener,phase='development'):
  identity={'job_id':'123','pid':42,'proc_start_ticks':'ticks','hostname':socket.gethostname()};protocol.write(root/'qwen_server_identity.json',identity)
  with patch.dict(os.environ,{'SLURM_JOB_ID':'123'}),patch.object(worker.urllib.request,'build_opener',return_value=opener):return worker.generate_phase({'runtime_root':str(root),'endpoint':'http://127.0.0.1:1/v1'},SimpleNamespace(plan_sha256='fixture'),SimpleNamespace(start_ticks=lambda pid:'ticks'),identity,phase)
 def test_first_failed_copy_stops_new_sends_and_seals_unattempted_slot(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);calls=[]
   def send(*a,**k):calls.append('attempt');return io.BytesIO(response('A'*40))
   result=self.run_fake_phase(root,SimpleNamespace(open=send));self.assertEqual(len(calls),1);self.assertEqual(result['attempted_confirmed'],1);self.assertEqual(result['not_dispatched'],1);self.assertEqual(result['recorded_outcomes'],2);self.assertFalse(result['exact_copy_gate_passed']);self.assertFalse((root/'generation/development/case_1/request.json').exists());self.assertFalse(json.loads((root/'generation/development/case_1/outcome.json').read_bytes())['attempted'])
 def test_oversize_and_HTTP_attempts_are_closed_without_observed_empty(self):
  for kind in ['oversize','HTTP']:
   with tempfile.TemporaryDirectory()as d:
    root=Path(d)
    def send(*a,**k):
     if kind=='HTTP':raise urllib.error.HTTPError('http://127.0.0.1',503,'unavailable',{},io.BytesIO(b'artificial failure'))
     return io.BytesIO(b'x'*(16*1024*1024+1))
    result=self.run_fake_phase(root,SimpleNamespace(open=send),'benchmark');self.assertEqual(result['attempted_confirmed'],1);self.assertEqual(result['unknown_finals'],1);self.assertEqual(result['observed_empty_finals'],0);self.assertTrue((root/'generation/benchmark/prediction_lock.json').exists());self.assertEqual(result['response_errors']if kind=='oversize'else result['http_errors'],1)
 def test_single_sealed_generation_requires_actual_resource_and_stopped_Qwen(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d)
   with self.assertRaises(FileNotFoundError):predictor.check_case('benchmark',root,'p')
   (root/'predictor_resource').mkdir();protocol.write(root/'predictor_resource/completion.json',{'all_five_structures_valid':True,'sequence_length':512})
   folder=root/'generation/benchmark';folder.mkdir(parents=True);(folder/'response.raw.json').write_bytes(response('ACDEFGHIKLMNPQRSTVWY'));protocol.write(folder/'request.json',{});protocol.write(folder/'outcome.json',{});protocol.write(folder/'prediction_lock.json',{'phase':'benchmark','planned':1,'plan_sha256':'p','files_sha256':{name:protocol.sha(folder/name)for name in ['request.json','response.raw.json','outcome.json']}});protocol.write(folder/'completion.json',{'phase':'benchmark','plan_sha256':'p','prediction_lock_sha256':protocol.sha(folder/'prediction_lock.json'),'delivered':1})
   protocol.write(root/'qwen_server_terminal.json',{'own_server_stopped':False})
   with self.assertRaises(PermissionError):predictor.check_case('benchmark',root,'p')
   (root/'qwen_server_terminal.json').write_text(json.dumps({'own_server_stopped':True}));name,seq=predictor.check_case('benchmark',root,'p');self.assertEqual(seq,'ACDEFGHIKLMNPQRSTVWY')
   (folder/'response.raw.json').write_bytes(response('YWVTSRQPNMLKIHGFEDCA'))
   with self.assertRaises(ValueError):predictor.check_case('benchmark',root,'p')
 def test_nonfinite_confidence_rejected(self):
  with self.assertRaises(ValueError):predictor.finite_json({'score':[float('nan')]})
  self.assertEqual(predictor.finite_json({'score':[.1,None]}),{'score':[.1,None]})
 def fixture(self,root):
  p='fixture';sequence='ACDEFGHIKLMNPQRSTVWY';plan={'model':protocol.MODEL,'model_revision':'test','predictor_source_revision':'test','scientific_differences':['Artificial fixture, not a measured binding benchmark.'],'predictor_assets':{},'public_code_paths':[],'frozen_files_sha256':{}}
  for phase,planned in [('development',2),('benchmark',1)]:
   folder=root/'generation'/phase;folder.mkdir(parents=True);files={}
   for index in range(planned):
    case=folder/('case_'+str(index))if phase=='development'else folder;case.mkdir(exist_ok=True);(case/'response.raw.json').write_bytes(response(sequence));protocol.write(case/'request.json',{});protocol.write(case/'outcome.json',{})
    for name in ['request.json','response.raw.json','outcome.json']:files[str((case/name).relative_to(folder))]=protocol.sha(case/name)
   protocol.write(folder/'progress.json',{});protocol.write(folder/'prediction_lock.json',{'phase':phase,'plan_sha256':p,'files_sha256':files});protocol.write(folder/'completion.json',{'phase':phase,'plan_sha256':p,'prediction_lock_sha256':protocol.sha(folder/'prediction_lock.json'),'planned':planned,'delivered':planned,'responses_saved':planned,'exact_copy_gate_passed':phase=='development'})
  for phase,length in [('resource',512),('benchmark',20)]:
   folder=root/('predictor_'+phase);folder.mkdir();files={};observations=[]
   for i in range(5):
    item=folder/('CASE_sample_'+str(i)+'.cif');item.write_text('Artificial structure');files[item.name]=protocol.sha(item);observations.append({'sample_file':item.name,'geometry':{'minimum_heavy_atom_distance_angstrom':2.5,'heavy_atom_contact_pairs':3}})
   protocol.write(folder/'prediction_lock.json',{'phase':phase,'plan_sha256':p,'files_sha256':files});protocol.write(folder/'completion.json',{'phase':phase,'plan_sha256':p,'prediction_lock_sha256':protocol.sha(folder/'prediction_lock.json'),'predicted_structures':5,'all_five_structures_valid':True,'sequence_length':length,'sequence_sha256':hashlib.sha256(sequence.encode()).hexdigest(),'measured_binding_assessed':False,'binding_accuracy':None,'native_NatureLM_replication':False,'observations':observations})
  protocol.write(root/'scoring_status.json',{'primary_metric':None,'biological_function_validated':False});protocol.write(root/'qwen_server_terminal.json',{'own_server_stopped':True});protocol.write(root/'qwen_server_identity.json',{'test':True})
  (root/'private_GPU_audit_at_start.json').write_text('PRIVATE ACCOUNT INVENTORY');(root/'weights.pt').write_bytes(b'PRIVATE WEIGHTS')
  return plan,p
 def test_actual_public_package_allowlist_and_changed_seal(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);plan,p=self.fixture(root);result,members=package.materialize(plan,root,p)
   self.assertIsNone(result['primary_metric']);self.assertEqual(result['structures_saved'],5);self.assertTrue(all('.local'not in name for name in members));self.assertTrue(all(b'PRIVATE'not in value for value in members.values()))
   manifest=package.package(plan,root,p)
   import tarfile
   with tarfile.open(manifest['archive'])as tar:self.assertEqual(len(tar.getnames()),manifest['members'])
   (root/'predictor_benchmark/CASE_sample_0.cif').write_text('Changed')
   with self.assertRaises(ValueError):package.materialize(plan,root,p)
 def test_partial_five_or_fabricated_success_never_packaged(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);plan,p=self.fixture(root);file=root/'predictor_benchmark/completion.json';value=json.loads(file.read_bytes());value['predicted_structures']=4;file.write_text(json.dumps(value))
   with self.assertRaises(ValueError):package.materialize(plan,root,p)
 def test_unsealed_extra_and_mutated_public_code_never_exported(self):
  for kind in ['extra','source']:
   with tempfile.TemporaryDirectory()as d:
    root=Path(d);plan,p=self.fixture(root)
    if kind=='extra':(root/'generation/benchmark/protected_reference.csv').write_text('Artificial forbidden extra')
    else:
     source=root/'source.py';source.write_text('original');plan['public_code_paths']=[str(source)];plan['frozen_files_sha256']={str(source):protocol.sha(source)};source.write_text('changed')
    with self.assertRaises(ValueError):package.materialize(plan,root,p)
 def test_predictor_rejects_unlocked_raw_and_unsafe_or_wrong_phase_seals(self):
  for kind in ['raw_unlocked','unsafe','phase']:
   with tempfile.TemporaryDirectory()as d:
    root=Path(d);(root/'predictor_resource').mkdir();protocol.write(root/'predictor_resource/completion.json',{'all_five_structures_valid':True,'sequence_length':512});folder=root/'generation/benchmark';folder.mkdir(parents=True)
    files={}
    for name in ['request.json','response.raw.json','outcome.json']:
     (folder/name).write_bytes(response('ACDEFGHIKLMNPQRSTVWY')if name=='response.raw.json'else b'{}');files[name]=protocol.sha(folder/name)
    if kind=='raw_unlocked':files.pop('response.raw.json')
    if kind=='unsafe':files['../outside']='unused'
    protocol.write(folder/'prediction_lock.json',{'plan_sha256':'p','phase':'development'if kind=='phase'else'benchmark','planned':1,'files_sha256':files});protocol.write(folder/'completion.json',{'phase':'benchmark','plan_sha256':'p','delivered':1,'prediction_lock_sha256':protocol.sha(folder/'prediction_lock.json')});protocol.write(root/'qwen_server_terminal.json',{'own_server_stopped':True})
    with self.assertRaises((ValueError,PermissionError)):predictor.check_case('benchmark',root,'p')
if __name__=='__main__':unittest.main()
