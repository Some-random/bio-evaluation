"""Artificial complete-five-structure gates and generation seals; no neural work."""
from pathlib import Path
import copy,json,tempfile,unittest
from unittest.mock import patch
import predictor,protocol
SEQ='ACDEFGHIKLMNPQRSTVWY'
def atoms():return [{'chain':'A','resname':'ALA','element':'C','xyz':[0.,0.,0.]}]+[{'chain':'B','resname':'HEM','element':'C','xyz':[float(i),0.,1.]}for i in range(43)]
def diagnostic(a,**k):return {'binding_success':None,'measured_affinity':None,'minimum_heavy_atom_distance_angstrom':1.0}
class Tests(unittest.TestCase):
 def files(self,d):
  files=[]
  for i in range(5):p=Path(d)/('CASE_sample_'+str(i)+'.cif');p.write_text('Artificial fixture');files.append(p)
  return files
 def check(self,files,value):return predictor.validate_geometry(files,case_name='CASE',sequence=SEQ,load_structure=lambda p:value,diagnostics=diagnostic)
 def test_all_five_whole_structures_required(self):
  with tempfile.TemporaryDirectory()as d:
   files=self.files(d);value={'atoms':atoms(),'protein_sequence':SEQ};result=self.check(files,value);self.assertEqual(len(result),5);self.assertTrue(all(r['sequence_length']==20 for r in result))
   with self.assertRaises(ValueError):self.check(files[:-1],value)
 def test_truncated_sequence_and_incomplete_ligand_rejected(self):
  with tempfile.TemporaryDirectory()as d:
   files=self.files(d)
   for value in [{'atoms':atoms(),'protein_sequence':SEQ[:-1]},{'atoms':atoms()[:-1],'protein_sequence':SEQ}]:
    with self.assertRaises(ValueError):self.check(files,value)
 def test_nonfinite_or_same_chain_rejected(self):
  with tempfile.TemporaryDirectory()as d:
   files=self.files(d);bad=atoms();bad[0]['xyz'][0]=float('nan')
   with self.assertRaises(ValueError):self.check(files,{'atoms':bad,'protein_sequence':SEQ})
   bad=atoms()
   for a in bad:a['chain']='A'
   with self.assertRaises(ValueError):self.check(files,{'atoms':bad,'protein_sequence':SEQ})
 def test_no_binding_success_can_be_invented(self):
  with tempfile.TemporaryDirectory()as d:
   files=self.files(d)
   with self.assertRaises(ValueError):predictor.validate_geometry(files,case_name='CASE',sequence=SEQ,load_structure=lambda p:{'atoms':atoms(),'protein_sequence':SEQ},diagnostics=lambda *a,**k:{'binding_success':True,'measured_affinity':None})
 def test_artificial_resource_exact_full_length(self):
  name,seq=predictor.check_case('resource',Path('/not-used'),'unused');self.assertEqual(name,'P39_ARTIFICIAL_512');self.assertEqual(len(seq),512)
  with self.assertRaises(ValueError):predictor.check_case('other',Path('/not-used'),'unused')
if __name__=='__main__':unittest.main()
