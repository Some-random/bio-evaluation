"""Task P13 source/denominator/interface checks; no inference or target reads."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
sys.path.insert(0,str(ROOT/'scripts'))
import run_deepfri_catalog_20261020 as runner
spec=importlib.util.spec_from_file_location('prepare_p13',HERE/'prepare_p13.py')
preparer=importlib.util.module_from_spec(spec);spec.loader.exec_module(preparer)

class P13Preparation(unittest.TestCase):
 def test_complete_reviewed_source_cohort_and_full_sequences(self):
  expected=preparer.fasta(HERE/'source/nrPDB-GO_test_sequences.fasta')
  ids=(HERE/'source/nrPDB-GO_test.txt').read_text().split()
  review=json.loads((ROOT/'configs/local_deepfri_p13_review.json').read_text())
  observed=[]
  for row in preparer.rows(HERE/'test_inputs.jsonl'):
   self.assertEqual(set(row),{'task_id','case_id','messages'})
   self.assertEqual(row['task_id'],'P13');observed.append(row['case_id'])
   messages=row['messages'];self.assertEqual(len(messages),1)
   self.assertEqual(set(messages[0]),{'role','content'});self.assertEqual(messages[0]['role'],'user')
   text=messages[0]['content']
   seq=text.split('\n\nComplete amino acid sequence:\n',1)[1].split('\n\nFixed global class order',1)[0]
   self.assertEqual(seq,expected[row['case_id']])
   self.assertNotIn(row['case_id'],text)
  self.assertEqual(len(observed),3416)
  self.assertEqual(observed,ids);self.assertEqual(observed,review['approved_case_ids'])
 def test_exact_source_global_vocabulary(self):
  path=HERE/'class_vocabulary.json'
  self.assertEqual(preparer.sha(path),preparer.SOURCE_HASHES['class_vocabulary.json'])
  vocab=json.loads(path.read_text());classes=vocab['classes']
  self.assertEqual(vocab['branch'],'BP');self.assertEqual(len(classes),1943)
  self.assertEqual([x['index'] for x in classes],list(range(1943)))
  self.assertEqual(len({x['class_id'] for x in classes}),1943)
 def test_label_blind_disjoint_validation_quantiles(self):
  seqs=preparer.fasta(HERE/'source/nrPDB-GO_sequences.fasta')
  official=(HERE/'source/nrPDB-GO_valid.txt').read_text().split()
  panel=preparer.select_panel(official,seqs)
  observed=list(preparer.rows(HERE/'development_inputs.jsonl'))
  self.assertEqual(len(panel),12);self.assertEqual([r['case_id'] for r in observed],panel)
  self.assertFalse(set(panel)&set((HERE/'source/nrPDB-GO_test.txt').read_text().split()))
  lengths=[len(seqs[x]) for x in panel]
  self.assertEqual(min(lengths),min(len(seqs[x]) for x in official))
  self.assertEqual(max(lengths),max(len(seqs[x]) for x in official))
  classes=json.loads((HERE/'class_vocabulary.json').read_text())['classes']
  for r in observed:self.assertEqual(r['messages'][0]['content'],runner.dense_prompt('P13',seqs[r['case_id']],classes))
 def test_fixed_length_dense_scores_are_model_supplied(self):
  text='{"scores":['+','.join(['0.999']*1943)+']}'
  self.assertEqual(len(runner.parse_vector(text,1943)),1943)
  for bad in [text.replace('0.999','true',1),text.replace('0.999','1.001',1),text.replace('0.999','"0.9"',1),'{"scores":['+','.join(['0']*1942)+']}',text[:-1],text+'\n']:
   with self.assertRaises(ValueError):runner.parse_vector(bad,1943)
  with self.assertRaises(ValueError):runner.parse_vector(text,1943,'length')
 def test_maximum_compact_ascii_size_below_output_budget(self):
  worst='{"scores":['+','.join(['1.000']*1943)+']}'
  self.assertEqual(len(worst.encode('ascii')),11670)
  self.assertLess(len(worst)+1,16384)
  self.assertFalse(runner.generation_for(1943)['chat_template_kwargs']['enable_thinking'])
 def test_labels_live_only_in_separate_scorer_file(self):
  config=json.loads((HERE/'test_config.json').read_text())
  self.assertEqual(config['planned'],3416)
  self.assertNotEqual(config['input_file'],config['scorer_reference_file'])
  self.assertEqual(config['scorer_reference_sha256'],preparer.SOURCE_HASHES['scorer_references.jsonl'])
  self.assertFalse(config['reference_labels_read_during_preparation'])
  dev=json.loads((HERE/'development_config.json').read_text())
  self.assertNotIn('scorer_reference_file',dev)
  self.assertEqual(dev['generation'],config['generation'])
if __name__=='__main__':unittest.main(verbosity=2)
