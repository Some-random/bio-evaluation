"""Artificial proof of stopping untouched request creation while active calls finish."""
import io
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import run_deepfri_catalog_20261020 as runner


class DirectoryDrainTest(unittest.TestCase):
    def test_active_response_finishes_then_untouched_calls_resume_without_replay(self):
        self.assertNotEqual(os.getuid(), 0, 'Permission drain proof requires an unprivileged owner')
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            output = base / 'run'
            output.mkdir()
            config = {'task_id': 'P12', 'run_id': 'invented-drain', 'split': 'official_test',
                      'class_count': 2, 'generation': {'max_tokens': 16384}}
            config_path = base / 'config.json'
            config_path.write_text(json.dumps(config))
            grant = base / 'grant.json'
            grant.write_text('{}')
            cases = [{'case_id': name, 'messages': [{'role': 'user', 'content': name}]} for name in ['active', 'untouched']]
            sent = []
            class SyntheticOpener:
                def open(self, request, timeout):
                    if isinstance(request, str):
                        return io.BytesIO(json.dumps({'data': [{'id': runner.MODEL}]}).encode())
                    name = json.loads(request.data)['messages'][0]['content']
                    sent.append(name)
                    if name == 'active':
                        (output / 'requests').chmod(0o500)
                    return io.BytesIO(json.dumps({'model': runner.MODEL, 'choices': [{
                        'finish_reason': 'stop', 'message': {'content': '{"scores":[0,1]}'}}]}).encode())
            args = SimpleNamespace(resume_unattempted=False, grant=grant, model_path='unused',
                                   context_limit=65536, concurrency=1, timeout=1)
            with patch.object(runner, 'count_tokens', return_value={'synthetic': True}), \
                 patch.object(runner.urllib.request, 'build_opener', return_value=SyntheticOpener()):
                with self.assertRaises(PermissionError):
                    runner.run_locked(args, config_path, config, cases, runner.parse_vector,
                                      {'endpoint': 'http://127.0.0.1:1/v1'}, {'synthetic': True}, output)
                self.assertEqual(sent, ['active'])
                self.assertEqual(len(list((output / 'outcomes').glob('*.json'))), 1)
                self.assertFalse((output / 'completion.json').exists())
                preserved = {str(p.relative_to(output)): runner.sha(p) for folder in ['requests', 'responses', 'outcomes']
                             for p in (output / folder).glob('*.json')}
                (output / 'requests').chmod(0o700)
                args.resume_unattempted = True
                runner.run_locked(args, config_path, config, cases, runner.parse_vector,
                                  {'endpoint': 'http://127.0.0.1:1/v1'}, {'synthetic': True}, output)
            self.assertEqual(sent, ['active', 'untouched'])
            for name, expected in preserved.items():
                self.assertEqual(runner.sha(output / name), expected)
            done = json.loads((output / 'completion.json').read_text())
            self.assertTrue(done['all_passed'])
            self.assertEqual(done['ambiguous_attempts'], 0)
            self.assertEqual((done['terminal'], done['planned']), (2, 2))


if __name__ == '__main__':
    unittest.main()
