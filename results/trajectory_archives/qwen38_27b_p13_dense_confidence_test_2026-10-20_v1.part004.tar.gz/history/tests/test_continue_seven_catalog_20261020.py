"""Artificial-only proof that a boundary continuation never replays an attempt."""
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import socket
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import run_deepfri_catalog_20261020 as runner
import continue_seven_catalog_20261020 as continuation


class ContinuationTests(unittest.TestCase):
    def test_existing_response_and_ambiguous_request_are_never_replayed(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            output = base / 'run'
            output.mkdir()
            for name in ['requests', 'responses', 'outcomes', 'errors']:
                (output / name).mkdir()
            config = {'task_id': 'P12', 'run_id': 'invented-continuation',
                      'split': 'official_test', 'class_count': 2,
                      'generation': {'max_tokens': 16384, 'chat_template_kwargs': {'enable_thinking': False}}}
            config_path = base / 'config.json'
            config_path.write_text(json.dumps(config))
            cases = [{'case_id': name, 'messages': [{'role': 'user', 'content': name}]} for name in ['saved', 'ambiguous', 'untouched']]
            grant_path = base / 'grant.json'
            grant_path.write_text('{}')
            (output / 'run_manifest.json').write_text(json.dumps({'config_sha256': runner.sha(config_path)}))
            for case in cases[:2]:
                key = hashlib.sha256(case['case_id'].encode()).hexdigest()
                (output / 'requests' / (key + '.json')).write_text(json.dumps(runner.payload(case, config)))
            key = hashlib.sha256(b'saved').hexdigest()
            response = output / 'responses' / (key + '.json')
            response.write_text('{"synthetic_saved":true}')
            (output / 'outcomes' / (key + '.json')).write_text(json.dumps({
                'case_id': 'saved', 'status': 'response_saved', 'response_saved': True,
                'delivery_passed': True, 'prediction': [0, 1]}))
            prior = {str(p.relative_to(output)): runner.sha(p) for p in output.rglob('*') if p.is_file()}
            dispatched = []
            class RecordingOpener:
                def open(self, request, timeout):
                    if isinstance(request, str):
                        return io.BytesIO(json.dumps({'data': [{'id': runner.MODEL}]}).encode())
                    payload = json.loads(request.data)
                    dispatched.append(payload['messages'][0]['content'])
                    return io.BytesIO(json.dumps({'model': runner.MODEL, 'choices': [{
                        'finish_reason': 'stop', 'message': {'content': '{"scores":[0,1]}'}}]}).encode())
            args = SimpleNamespace(resume_unattempted=True, grant=grant_path,
                                   model_path='unused', context_limit=65536, concurrency=1, timeout=1)
            with patch.object(runner, 'count_tokens', return_value={'synthetic': True}), \
                 patch.object(runner.urllib.request, 'build_opener', return_value=RecordingOpener()):
                runner.run_locked(args, config_path, config, cases, runner.parse_vector,
                                  {'endpoint': 'http://127.0.0.1:1/v1'}, {'synthetic': True}, output)
            self.assertEqual(dispatched, ['untouched'])
            for name, digest in prior.items():
                self.assertEqual(runner.sha(output / name), digest)
            complete = json.loads((output / 'completion.json').read_text())
            self.assertEqual((complete['planned'], complete['terminal'], complete['responses_saved']), (3, 3, 2))
            self.assertEqual(complete['ambiguous_attempts'], 1)
            self.assertFalse(complete['all_passed'])
            with self.assertRaisesRegex(ValueError, 'sealed'):
                runner.run_locked(args, config_path, config, cases, runner.parse_vector,
                                  {'endpoint': 'http://127.0.0.1:1/v1'}, {}, output)

    def test_boundary_rejects_changed_history(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            (output / 'requests').mkdir()
            request = output / 'requests' / 'invented.json'
            request.write_text('{}')
            boundary = continuation.snapshot_boundary(output, 'invented-config')
            continuation.verify_boundary(output, boundary)
            request.write_text('{"changed":true}')
            with self.assertRaisesRegex(ValueError, 'Historical output changed'):
                continuation.verify_boundary(output, boundary)

    def test_boundary_refuses_sealed_or_error_conditions(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            (output / 'completion.json').write_text('{}')
            self.assertIsNone(continuation.snapshot_boundary(output, 'invented'))
            (output / 'completion.json').unlink()
            (output / 'progress.json').write_text(json.dumps({'refusals': 1}))
            with self.assertRaisesRegex(ValueError, 'needs review'):
                continuation.snapshot_boundary(output, 'invented')

    def test_successor_requires_exact_model_precision_and_runtime(self):
        versions = {'packages': {'torch': 'synthetic-fixed'}, 'python': 'synthetic-fixed', 'torch_cuda': 'synthetic-fixed'}
        manifest = {'pool_plan': 'unused-plan', 'runtime_root': 'unused-runtime',
                    'original_job_id': '243179', 'runtime_versions': versions}
        identity = {'model': 'fixed-model', 'revision': 'fixed-revision', 'dtype': 'bfloat16',
                    'dedicated_gpu_count': 1, 'max_model_len': 65536, 'job_id': 'invented-successor',
                    'hostname': socket.gethostname(), 'pid': os.getpid(),
                    'proc_start_ticks': Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19]}
        def fake_read(path):
            return {'model': 'fixed-model', 'revision': 'fixed-revision'} if str(path) == 'unused-plan' else versions
        with patch.dict(os.environ, {'SLURM_JOB_ID': 'invented-successor'}), patch.object(continuation, 'read', side_effect=fake_read):
            continuation.identity_valid(manifest, identity)
            for key, value in [('dtype', 'float16'), ('revision', 'changed'), ('dedicated_gpu_count', 2), ('job_id', '243179')]:
                with self.subTest(key=key), self.assertRaises(ValueError):
                    continuation.identity_valid(manifest, dict(identity, **{key: value}))

    def test_active_predecessor_cannot_be_overlapped(self):
        with patch.object(continuation.subprocess, 'run', return_value=SimpleNamespace(returncode=0, stdout='JobState=RUNNING')):
            with self.assertRaisesRegex(ValueError, 'has not finished'):
                continuation.predecessor_terminal('243179')
        with patch.object(continuation.subprocess, 'run', return_value=SimpleNamespace(returncode=0, stdout='JobState=TIMEOUT')):
            self.assertEqual(continuation.predecessor_terminal('243179'), 'TIMEOUT')

    def test_only_recorded_owned_exact_task_request_permissions_are_restored(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            output = base / 'tasks/P12/runtime/benchmark'
            request_dir = output / 'requests'
            request_dir.mkdir(parents=True)
            request_dir.chmod(0o500)
            receipt = base / 'continuation_v1/request_permission_drain.json'
            receipt.parent.mkdir()
            row = {'output_folder': str(output.resolve()), 'config_sha256': 'fixed',
                   'original_mode': 0o700, 'blocked_mode': 0o500}
            receipt.write_text(json.dumps({'tasks': [row]}))
            with patch.object(continuation, 'BASE', base):
                with self.assertRaises(ValueError):
                    continuation.restore_drained_request_permission(output, 'changed-config')
                restored = continuation.restore_drained_request_permission(output, 'fixed')
            self.assertEqual(request_dir.stat().st_mode & 0o777, 0o700)
            self.assertFalse(restored['historical_files_changed'])


if __name__ == '__main__':
    unittest.main()
