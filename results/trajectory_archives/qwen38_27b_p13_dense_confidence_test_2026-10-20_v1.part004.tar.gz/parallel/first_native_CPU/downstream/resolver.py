"""Explicit read-only current P13 CPU lineage; never remap historical paths.

Importing this module reads no task artifacts. Final source admission and actual
completed CPU provenance are mandatory before any downstream consumer succeeds.
"""
import hashlib
import importlib.util
import json
import os
import re
from pathlib import Path
import stat
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
BASE = ROOT / '.local/catalog_execution_2026-10-20'
PARALLEL = BASE / 'P13_parallel_20261024_v2'
OUT = BASE / 'tasks/P13/runtime/benchmark'
OLD_STATE = BASE / 'control/P13_scoring_status.json'
OLD_LOG = BASE / 'control/P13_scoring.log'
PLAN_SHA = '187ccab658a8d2bc2e15d327a56168c06dc7ae11e9a8e242d7c4349a03d903d5'
AUTH_SHA = 'bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
SCORER = ROOT / 'scripts/score_deepfri_catalog_20261020.py'
RUNNER = ROOT / 'scripts/run_deepfri_catalog_20261020.py'
SCORER_SHA = 'b297106d0ec993bbf1ab56515f7579b0d8c49743cd2b8eab521579f6b2f973d8'
RUNNER_SHA = 'e3ebc62f8ad3c4ce8dbb1d8f45323d719e7c932db4a3cb6315e74ce2994cac00'
OLD_CHECKER = PARALLEL / 'publication_delivery_v2/package_contract.py'
OLD_CHECKER_SHA = 'bc3ad5a7c19881fed6bcc943c3607dbdd8f12d9cbf5387cfd12aba17ec36df4b'
ORIGINAL_ASSEMBLER = PARALLEL / 'publication.py'
ORIGINAL_ASSEMBLER_SHA = '9e267e49052b5dcc3db1dafe269db3366434ea676b4107d3bb1bebd56ba9e9d3'
REVIEWERS = frozenset(('/root', '/root/priority_runtime_review', '/root/independent_review'))
NULL_METRICS = {'auprc@micro': None, 'f1_max': None}


def regular(path):
    path = Path(path)
    if not path.is_absolute() or any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('Absolute non-symlink metadata/source required')
    observed = path.lstat()
    if not stat.S_ISREG(observed.st_mode) or observed.st_uid != os.getuid():
        raise ValueError('Owned regular metadata/source required')
    return observed


def sha(path):
    regular(path)
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024**2), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    regular(path)
    return json.loads(Path(path).read_bytes())


def exact(path, expected):
    if not isinstance(expected, str) or len(expected) != 64 or sha(path) != expected:
        raise ValueError('Exact source/provenance hash differs: ' + str(path))


def ref(value, expected_path=None):
    if not isinstance(value, dict) or set(value) != {'path', 'sha256'}:
        raise ValueError('Exact path/hash reference required')
    path = Path(value['path'])
    if expected_path is not None and path != expected_path:
        raise ValueError('Unexpected provenance path')
    exact(path, value['sha256'])
    return path


def load_exact(path, digest, name, install=False):
    path = Path(path)
    exact(path, digest)
    if name in sys.modules:
        raise ValueError('Foreign/preloaded helper module forbidden')
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    if install:
        sys.modules[name] = result
    try:
        spec.loader.exec_module(result)
        exact(path, digest)
    except BaseException:
        if install:
            sys.modules.pop(name, None)
        raise
    return result


def current_cpu(cfg):
    namespace = Path(cfg['current_CPU_namespace'])
    if (namespace.parent != PARALLEL
            or re.fullmatch(r'first_native_CPU_score_v[1-9][0-9]*', namespace.name) is None):
        raise ValueError('Exact task-local first-native CPU namespace required')
    ref(cfg['cpu_config'], namespace / 'config.json')
    return namespace


def source_check():
    cfg = read(HERE / 'config.json')
    if (cfg.get('role') != 'P13_first_native_CPU_downstream_source_configuration'
            or cfg.get('task_id') != 'P13' or cfg.get('owner') != '/root/deepfri_p13_completion'
            or cfg.get('parallel_manifest_sha256') != PLAN_SHA
            or cfg.get('root_authorization_sha256') != AUTH_SHA
            or cfg.get('old_failure_is_preserved_not_remapped') is not True
            or cfg.get('new_model_or_scoring_calls') != 0):
        raise PermissionError('Exact downstream source scope required')
    ref(cfg['old_checker'], OLD_CHECKER)
    if cfg['old_checker']['sha256'] != OLD_CHECKER_SHA:
        raise ValueError('Original checker identity changed')
    ref(cfg['original_assembler'], ORIGINAL_ASSEMBLER)
    if cfg['original_assembler']['sha256'] != ORIGINAL_ASSEMBLER_SHA:
        raise ValueError('Original assembler identity changed')
    current_cpu(cfg)
    fixed_sources = {str(OLD_CHECKER): OLD_CHECKER_SHA, str(ORIGINAL_ASSEMBLER): ORIGINAL_ASSEMBLER_SHA,
        str(RUNNER): RUNNER_SHA, str(SCORER): SCORER_SHA}
    if any(cfg['files_sha256'].get(path) != digest for path, digest in fixed_sources.items()):
        raise ValueError('Exact original checker/assembler/native source pins required')
    if not {str(HERE / name) for name in ('resolver.py', 'base_checker_adapter.py',
            'assemble_publication.py', 'test_downstream.py')} <= set(cfg['files_sha256']):
        raise ValueError('Every additive downstream source must be explicitly pinned')
    for path, digest in cfg['files_sha256'].items():
        exact(path, digest)
    review = read(HERE / 'independent_source_review.json')
    if (review.get('approved') is not True or review.get('reviewer') not in REVIEWERS
            or review.get('role') != 'independent_P13_CPU_downstream_source_review'
            or review.get('config_sha256') != sha(HERE / 'config.json')
            or review.get('files_sha256') != cfg['files_sha256']):
        raise PermissionError('Exact downstream independent source admission required')
    return cfg


def current_state():
    cfg = source_check()
    config_sha = sha(HERE / 'config.json')
    CPU = current_cpu(cfg)
    cpu_cfg = read(ref(cfg['cpu_config'], CPU / 'config.json'))
    cpu_cfg_sha = cfg['cpu_config']['sha256']
    if (cpu_cfg.get('role') != 'P13_first_native_CPU_import_repair_source'
            or cpu_cfg.get('planned') != 3416 or cpu_cfg.get('historical_invalids') != 4
            or cpu_cfg.get('old_failed_state_and_STOP_preserved') is not True
            or cpu_cfg.get('new_model_or_generation_calls') != 0):
        raise ValueError('Exact first-entry CPU source contract required')
    for path, digest in cpu_cfg['files_sha256'].items():
        exact(path, digest)
    for path in cpu_cfg['preserved_preparation_execution_paths_must_remain_absent']:
        if os.path.lexists(path):
            raise ValueError('Prior unexecuted CPU preparation gained an attempt')
    preserved = cpu_cfg['preserved_evidence_sha256']
    if preserved != cfg['preserved_evidence_sha256']:
        raise ValueError('Downstream preserved evidence must equal CPU contract')
    required_old = {str(OLD_STATE), str(OLD_LOG), cfg['old_failure_stop']['path']}
    if not required_old <= set(preserved):
        raise ValueError('Old failed state/log/STOP must all remain explicitly bound')
    ref(cfg['old_failure_stop'])
    if preserved[cfg['old_failure_stop']['path']] != cfg['old_failure_stop']['sha256']:
        raise ValueError('Exact old failure STOP binding differs')
    for path, digest in preserved.items():
        exact(path, digest)
    old = read(OLD_STATE)
    if old.get('stage') != 'failed_no_retry' or old.get('exit_code') != 1 or old.get('score_sha256') is not None:
        raise ValueError('Preserved original failure must remain a failure')
    if any(os.path.lexists(CPU / name) for name in ('failure.json', 'CPU_launch_failure.json')):
        raise ValueError('A failed/ambiguous recovery cannot be presented as completed')
    proof_path = ref(cfg['zero_native_entry_proof'])
    release_path = ref(cfg['delegated_release'])
    if (str(proof_path) != cpu_cfg['zero_native_entry_proof']
            or cfg['zero_native_entry_proof']['sha256'] != cpu_cfg['zero_native_entry_proof_sha256']
            or str(release_path) != cpu_cfg['delegated_release']
            or cfg['delegated_release']['sha256'] != cpu_cfg['files_sha256'][str(release_path)]):
        raise ValueError('CPU and downstream proof/release lineage differs')
    proof = read(proof_path)
    if (proof.get('supporting_pass') is not True
            or proof.get('role') != 'supporting_independent_P13_CPU_v2_command_lookup_failure_zero_native_entry_source_proof'
            or proof.get('reviewer') != '/root/priority_runtime_review/lpb398_verifier_tests'
            or proof.get('CPU_job_id') != '250370'
            or proof.get('failed_child_conclusions') != {
                'helper_main_execute_authority_entered': True, 'native_entry_claim_created': False,
                'native_metric_calculation': False, 'original_native_functions_entered': False,
                'original_pre_reference_verifier_entered': False, 'original_runner_imported': False,
                'original_score_entered': False, 'original_scorer_imported': False,
                'original_scorer_main_entered': False, 'protected_reference_read': False}):
        raise ValueError('Exact V2 scheduler-lookup zero-native-entry proof required')
    original_proof_path = ref(cfg['original_import_zero_entry_proof'])
    if (str(original_proof_path) != cpu_cfg['original_import_zero_entry_proof']
            or cfg['original_import_zero_entry_proof']['sha256'] != cpu_cfg['original_import_zero_entry_proof_sha256']):
        raise ValueError('Original failed scorer proof must remain explicit')
    original_proof = read(original_proof_path)
    if (original_proof.get('supporting_pass') is not True
            or original_proof.get('role') != 'supporting_independent_P13_failed_scorer_subprocess_zero_entry_source_proof'
            or original_proof.get('reviewer') != '/root/priority_runtime_review/lpb398_verifier_tests'
            or original_proof.get('failed_subprocess_conclusions') != {
                'main_entered': False, 'matrix_metrics_entered': False, 'native_functions_entered': False,
                'native_score_calculation': False, 'protected_reference_read': False, 'score_entered': False}):
        raise ValueError('Exact original failed-subprocess zero-entry proof required')
    release = read(release_path)
    if (release.get('approved') is not True or release.get('issuer') != '/root/independent_review'
            or release.get('role') != 'delegated_P13_CPU_v2_zero_native_entry_one_replacement_release'
            or release.get('maximum_original_native_scoring_function_entries') != 1
            or release.get('maximum_new_CPU_execution_attempts') != 1
            or release.get('old_418_deef_grants_reusable_for_new_execution') is not False
            or release.get('root_authorization_sha256') != AUTH_SHA
            or release.get('failed_subprocess_zero_entry_proof', {}).get('sha256')
                != cfg['zero_native_entry_proof']['sha256']):
        raise ValueError('Exact honest delegated V2-zero-entry CPU replacement release required')
    prior_release = ref(cfg['original_delegated_release'])
    previous = release['previous_CPU_attempt_authorization_consumed_and_preserved']
    if (previous.get('release_path') != str(prior_release)
            or previous.get('release_sha256') != cfg['original_delegated_release']['sha256']
            or previous.get('CPU_job_id') != '250370' or previous.get('state') != 'FAILED'
            or previous.get('exit_code') != '1:0'
            or previous.get('all_old_claims_logs_probes_failures_STOPs_and_source_bytes_preserved') is not True):
        raise ValueError('Consumed original CPU authority must remain historical')
    for path, digest in release['failed_V2_source_probe_log_and_admission_sha256'].items():
        exact(path, digest)
    ref(release['actual_CPU_terminal_observation'])
    attempt = read(CPU / 'native_entry_attempt.json')
    admission_path = CPU / 'independent_admission.json'
    admission_sha = sha(admission_path)
    admission = read(admission_path)
    if (admission.get('approved') is not True or admission.get('reviewer') not in REVIEWERS
            or admission.get('role') != 'independent_P13_first_native_CPU_score_entry_admission'
            or admission.get('config_sha256') != cpu_cfg_sha
            or admission.get('zero_native_entry_proof_sha256') != cfg['zero_native_entry_proof']['sha256']
            or admission.get('first_native_entry_once_only') is not True
            or admission.get('old_failed_state_and_STOP_preserved') is not True
            or admission.get('model_or_GPU_calls_authorized') is not False):
        raise ValueError('Actual first-native admission required')
    expected_attempt = {'role': 'P13_first_native_CPU_entry_once_only', 'config_sha256': cpu_cfg_sha,
        'independent_admission_sha256': admission_sha,
        'zero_native_entry_proof_sha256': cfg['zero_native_entry_proof']['sha256'],
        'prediction_lock_sha256': sha(OUT / 'prediction_lock.json'),
        'original_scoring_status_and_STOP_preserved': True, 'new_model_calls': 0}
    if (any(attempt.get(key) != value for key, value in expected_attempt.items())
            or not isinstance(attempt.get('CPU_job_id'), str) or not attempt['CPU_job_id'].isdigit()
            or attempt.get('hostname') != 'ampere8.stanford.edu'):
        raise ValueError('Exact durable native-entry claim required')
    done = read(CPU / 'completion.json')
    for key, value in attempt.items():
        if key != 'role' and done.get(key) != value:
            raise ValueError('Completed native entry must preserve every claim field')
    if (done.get('role') != 'P13_first_native_CPU_score_completed' or done.get('native_entries') != 1
            or done.get('planned') != 3416 or done.get('parsed') != 3412
            or done.get('invalid_or_missing') != 4 or done.get('full_primary_metrics_null') is not True
            or done.get('original_failed_no_retry_preserved') is not True or done.get('new_GPU_allocations') != 0
            or done.get('score_sha256') != sha(OUT / 'scores.json')
            or done.get('per_case_sha256') != sha(OUT / 'scores.per_case.json')):
        raise ValueError('Exact one-entry completed native CPU score required')
    state_path = CPU / 'score_status.json'
    state = read(state_path)
    if (any(state.get(key) != value for key, value in done.items())
            or state.get('stage') != 'completed' or state.get('exit_code') != 0
            or not isinstance(state.get('finished_at_pacific'), str) or not state['finished_at_pacific']
            or state.get('scoring_status_path') != str(state_path)
            or state.get('completion_sha256') != sha(CPU / 'completion.json')):
        raise ValueError('New actual completed state must bind native completion')
    launch = read(CPU / 'CPU_launch_attempt.json')
    launch_done = read(CPU / 'CPU_launch_completion.json')
    probe = read(CPU / 'runtime_version_probe.json')
    scheduler_probe = read(CPU / 'scheduler_version_probe.json')
    if (launch.get('role') != 'P13_once_only_CPU_runtime_launch'
            or launch.get('CPU_job_id') != attempt['CPU_job_id']
            or launch.get('hostname') != attempt['hostname']
            or launch.get('config_sha256') != cpu_cfg_sha
            or launch.get('independent_admission_sha256') != admission_sha
            or launch_done.get('returncode') != 0 or launch_done.get('config_sha256') != cpu_cfg_sha
            or launch_done.get('native_completion_sha256') != sha(CPU / 'completion.json')
            or probe.get('config_sha256') != cpu_cfg_sha or probe.get('CPU_only') is not True
            or probe.get('reference_reads') != 0 or probe.get('native_score_entries') != 0
            or probe.get('runtime') != cpu_cfg['expected_scoring_runtime']
            or probe.get('independent_admission_sha256') != admission_sha
            or probe.get('CPU_job_id') != attempt['CPU_job_id']
            or launch.get('runtime_version_probe_sha256') != sha(CPU / 'runtime_version_probe.json')
            or launch.get('scheduler_version_probe_sha256') != sha(CPU / 'scheduler_version_probe.json')
            or scheduler_probe.get('config_sha256') != cpu_cfg_sha
            or scheduler_probe.get('independent_admission_sha256') != admission_sha
            or scheduler_probe.get('CPU_job_id') != attempt['CPU_job_id']
            or scheduler_probe.get('actual_python') != '3.12.15'
            or scheduler_probe.get('actual_executable') != str(Path(cpu_cfg['retained_runtime']) / 'python/bin/python3.12')
            or scheduler_probe.get('exact_original_terminal_identities_verified') is not True
            or scheduler_probe.get('native_or_model_or_reference_calls') != 0):
        raise ValueError('Actual CPU launch/version/return-zero lineage required')
    expected_allocation = {'JobId': attempt['CPU_job_id'], 'UserId': 'dongweij(26129)',
        'JobState': 'RUNNING', 'JobName': 'bio-P13-first-native-CPU', 'Partition': 'il-data',
        'QOS': 'il-data', 'WorkDir': str(ROOT), 'Command': str(CPU / 'score_CPU.sbatch'),
        'Requeue': '0', 'Restarts': '0', 'TimeLimit': '02:00:00', 'NumCPUs': '2',
        'NodeList': 'ampere8', 'NumNodes': '1'}
    for allocation in (launch.get('CPU_allocation', {}), scheduler_probe.get('CPU_allocation', {})):
        if any(allocation.get(key) != value for key, value in expected_allocation.items()):
            raise ValueError('Captured exact owned CPU-only allocation differs')
        for name in ('AllocTRES', 'ReqTRES'):
            values = dict(piece.split('=', 1) for piece in allocation.get(name, '').split(',') if '=' in piece)
            if values.get('cpu') != '2' or values.get('mem') != '8G' or any(
                    'gpu' in key.lower() and value != '0' for key, value in values.items()):
                raise ValueError('Captured CPU/memory/zero-GPU resources differ')
        if 'gpu' in allocation.get('TresPerNode', '').lower():
            raise ValueError('Captured per-node GPU request forbidden')
    versions = scheduler_probe.get('scheduler_versions', {})
    if set(versions) != set(cpu_cfg['scheduler_commands']):
        raise ValueError('Both exact scheduler version records required')
    for name, identity in cpu_cfg['scheduler_commands'].items():
        row = versions[name]
        if (any(row.get(key) != value for key, value in identity.items())
                or not isinstance(row.get('version'), str) or not row['version'].startswith('slurm ')
                or '\n' in row['version']):
            raise ValueError('Pinned scheduler version provenance differs')
    close_path = PARALLEL / 'FINAL_NATIVE_CLOSED.json'
    close = read(close_path)
    required_close = {'role': 'P13_native_closed_after_proven_import_failure_first_CPU_entry',
        'task_id': 'P13', 'planned': 3416, 'terminal': 3416, 'score_path': str(OUT / 'scores.json'),
        'score_sha256': done['score_sha256'], 'prediction_lock_sha256': expected_attempt['prediction_lock_sha256'],
        'scoring_status_path': str(state_path), 'scoring_status_sha256': sha(state_path),
        'old_failed_scoring_status_path': str(OLD_STATE), 'old_failed_scoring_status_sha256': preserved[str(OLD_STATE)],
        'zero_native_entry_proof_sha256': cfg['zero_native_entry_proof']['sha256'],
        'delegated_release_sha256': cfg['delegated_release']['sha256'],
        'first_native_CPU_completion_sha256': sha(CPU / 'completion.json'),
        'further_allocation_or_scoring_authorized': False}
    if any(close.get(key) != value for key, value in required_close.items()):
        raise ValueError('New closure must explicitly bind new status and old failure')
    completion = read(OUT / 'completion.json')
    score = read(OUT / 'scores.json')
    if (completion.get('planned') != 3416 or completion.get('terminal') != 3416
            or completion.get('responses_saved') != 3412 or completion.get('ambiguous_attempts') != 4
            or completion.get('prediction_lock_sha256') != expected_attempt['prediction_lock_sha256']
            or score.get('planned') != 3416 or score.get('parsed') != 3412 or score.get('invalid_or_missing') != 4
            or score.get('metrics') != NULL_METRICS or score.get('full_planned_primary_metrics_valid') is not False
            or score.get('predictions_locked_before_reference_read') is not True
            or score.get('prediction_lock_sha256') != expected_attempt['prediction_lock_sha256']
            or score.get('scorer_sha256') != SCORER_SHA):
        raise ValueError('Full3416/four-invalid native-null policy must remain exact')
    # Recheck immutable authority and historical failure after the completed chain.
    exact(HERE / 'config.json', config_sha)
    exact(CPU / 'config.json', cpu_cfg_sha)
    for path, digest in preserved.items():
        exact(path, digest)
    source_check()
    return {'CPU_namespace': str(CPU), 'score_sha256': done['score_sha256'], 'prediction_lock_sha256': expected_attempt['prediction_lock_sha256'],
        'state_path': str(state_path), 'state_sha256': sha(state_path),
        'closure_path': str(close_path), 'closure_sha256': sha(close_path), 'score': score,
        'cpu_config_sha256': cpu_cfg_sha, 'cpu_admission_sha256': admission_sha}


def archive_provenance():
    current_state()
    cfg = source_check()
    CPU = current_cpu(cfg)
    cpu_cfg = read(ref(cfg['cpu_config'], CPU / 'config.json'))
    members = {}
    def add(name, path, digest):
        if name in members:
            raise ValueError('Duplicate explicit CPU provenance member')
        exact(path, digest)
        members[name] = {'path': str(path), 'sha256': digest}
    for name in ('native_entry_attempt.json', 'completion.json', 'score_status.json',
                 'CPU_launch_attempt.json', 'CPU_launch_completion.json', 'runtime_version_probe.json',
                 'independent_admission.json', 'native_score.log', 'scheduler_version_probe.json'):
        add('parallel/first_native_CPU/runtime/' + name, CPU / name, sha(CPU / name))
    add('parallel/first_native_CPU/source/config.json', CPU / 'config.json', cfg['cpu_config']['sha256'])
    for name, row in (('delegated_release.json', cfg['delegated_release']),
                      ('zero_native_entry_proof.json', cfg['zero_native_entry_proof']),
                      ('original_import_zero_entry_proof.json', cfg['original_import_zero_entry_proof']),
                      ('original_consumed_delegated_release.json', cfg['original_delegated_release'])):
        add('parallel/first_native_CPU/authority/' + name, row['path'], row['sha256'])
    for name in ('README.md', 'launch.py', 'score_CPU.sbatch', 'score_once.py', 'test_startup.py',
                 'scheduler_probe.py', 'scheduler_preflight.py', 'test_scheduler.py',
                 'test_private_scheduler.py', 'private_scheduler_regression.json'):
        path = CPU / name
        add('parallel/first_native_CPU/source/' + name, path, cpu_cfg['files_sha256'][str(path)])
    final_regression = CPU / 'private_scheduler_regression_v2.json'
    if (cpu_cfg.get('actual_private_environment_regression') != str(final_regression)
            or cpu_cfg.get('actual_private_environment_regression_sha256')
                != cpu_cfg['files_sha256'].get(str(final_regression))):
        raise ValueError('Exact final admitted private scheduler regression required')
    add('parallel/first_native_CPU/source/private_scheduler_regression_v2.json', final_regression,
        cpu_cfg['actual_private_environment_regression_sha256'])
    prior_path = Path(cpu_cfg['preserved_source_preparation_config'])
    add('parallel/first_native_CPU/preserved_source_preparation/config.json', prior_path,
        cpu_cfg['preserved_source_preparation_config_sha256'])
    for path, digest in cpu_cfg['preserved_evidence_sha256'].items():
        path = Path(path)
        if path not in (OLD_STATE, OLD_LOG) and path.name.startswith('STOP'):
            add('parallel/first_native_CPU/preserved_failure/' + str(path.relative_to(PARALLEL)), path, digest)
        elif path.parent.parent == PARALLEL and re.fullmatch(r'first_native_CPU_score_v[1-9][0-9]*', path.parent.name):
            add('parallel/first_native_CPU/preserved_prior_CPU/' + str(path.relative_to(PARALLEL)), path, digest)
    release = read(ref(cfg['delegated_release']))
    for path, digest in release['failed_V2_source_probe_log_and_admission_sha256'].items():
        path = Path(path)
        if path.parent == PARALLEL / 'first_native_CPU_score_v2':
            name = 'parallel/first_native_CPU/preserved_prior_CPU/' + str(path.relative_to(PARALLEL))
            if name not in members:
                add(name, path, digest)
    row = release['actual_CPU_terminal_observation']
    add('parallel/first_native_CPU/authority/failed_CPU250370_terminal.json', row['path'], row['sha256'])
    add('control/P13_scoring.log', OLD_LOG, cpu_cfg['preserved_evidence_sha256'][str(OLD_LOG)])
    for name in ('resolver.py', 'base_checker_adapter.py', 'assemble_publication.py', 'config.json', 'independent_source_review.json'):
        add('parallel/first_native_CPU/downstream/' + name, HERE / name, sha(HERE / name))
    return members


def load_native():
    source_check()
    load_exact(RUNNER, RUNNER_SHA, 'run_deepfri_catalog_20261020', install=True)
    return load_exact(SCORER, SCORER_SHA, 'P13_CPU_downstream_native_pre_reference_verifier')
