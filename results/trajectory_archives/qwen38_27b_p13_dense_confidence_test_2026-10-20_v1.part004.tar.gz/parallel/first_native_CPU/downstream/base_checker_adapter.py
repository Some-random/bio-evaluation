"""Source-only additive adapter for the independently admitted P13 checker.

Authoring this source grants no execution, scoring, publication, or admission
authority. At import, only the sibling resolver source is loaded; current
closure and original checker sources are resolved only when a function runs.
"""
import importlib.util
import hashlib
from pathlib import Path


HERE = Path(__file__).resolve().parent
_RESOLVER_SHA = '2a8e338f3bb144a6dfe2804a6d30e3d5d5ac0d873888fcbe4522d2c2fee41871'
if (HERE / 'resolver.py').is_symlink() or hashlib.sha256((HERE / 'resolver.py').read_bytes()).hexdigest() != _RESOLVER_SHA:
    raise ValueError('Exact downstream resolver source changed')
_resolver_spec = importlib.util.spec_from_file_location(
    'P13_first_native_CPU_score_downstream_resolver', HERE / 'resolver.py')
if _resolver_spec is None or _resolver_spec.loader is None:
    raise ImportError('Sibling P13 downstream resolver source is unavailable')
resolver = importlib.util.module_from_spec(_resolver_spec)
_resolver_spec.loader.exec_module(resolver)


def source_check():
    return resolver.source_check()


def _load_original(config):
    row = config['old_checker']
    return resolver.load_exact(
        row['path'], row['sha256'],
        'P13_first_native_CPU_score_downstream_original_checker')


def terminal_identity(original=None):
    current = resolver.current_state()
    if original is None:
        original = _load_original(resolver.source_check())
    read = original.read
    sha = original.sha
    PARALLEL = original.PARALLEL
    PLAN_SHA = original.PLAN_SHA
    for rank, planned in enumerate((250, 249, 249)):
        folder = PARALLEL / 'replicas' / str(rank)
        registration = read(PARALLEL / ('submission_rank' + str(rank) + '.json'))
        terminal = read(folder / 'runtime/partition_terminal.json')
        cleanup = read(folder / 'runtime/cleanup.json')
        grant_sha = sha(folder / 'runtime/queue/P13_partition.grant.json')
        finished_path = folder / 'runtime/queue/P13_partition.finished.json'
        finished = read(finished_path)
        if (registration.get('rank') != rank or registration.get('manifest_sha256') != PLAN_SHA
                or terminal.get('rank') != rank or terminal.get('task_id') != 'P13'
                or terminal.get('job_id') != registration.get('job_id')
                or terminal.get('manifest_sha256') != PLAN_SHA
                or terminal.get('boundary_sha256') != sha(PARALLEL / 'boundary.json')
                or terminal.get('grant_sha256') != grant_sha
                or terminal.get('finished_sha256') != sha(finished_path)
                or finished.get('grant_sha256') != grant_sha or finished.get('exit_code') != 0
                or terminal.get('planned') != planned or terminal.get('terminal') != planned
                or terminal.get('completion_sha256') != sha(folder / 'output/completion.json')
                or terminal.get('prediction_lock_sha256') != sha(folder / 'output/prediction_lock.json')
                or cleanup.get('owned_processes_only') is not True):
            raise ValueError('All three exact original partition terminal/cleanup lineages required')
    return current['score_sha256'], current['prediction_lock_sha256']


def check(path, digest_value):
    config = resolver.source_check()
    original = _load_original(config)
    saved_terminal_identity = original.terminal_identity

    def current_terminal_identity():
        return terminal_identity(original)

    original.terminal_identity = current_terminal_identity
    try:
        return original.check(path, digest_value)
    finally:
        original.terminal_identity = saved_terminal_identity
