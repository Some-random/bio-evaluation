"""Invented-only source/bootstrap/durability regressions. No native imports."""
from contextlib import contextmanager
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, HERE / file)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


s = load('P13_startup_test_source', 'score_once.py')
l = load('P13_launch_test_source', 'launch.py')


class Startup(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='p13-invented-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.old = sys.modules.pop(s.RUNNER_NAME, None)
        self.addCleanup(self.restore)

    def restore(self):
        sys.modules.pop(s.RUNNER_NAME, None)
        if self.old is not None:
            sys.modules[s.RUNNER_NAME] = self.old

    def source(self, name, body):
        path = self.root / name
        path.write_text(body)
        return path, hashlib.sha256(path.read_bytes()).hexdigest()

    def test_preload_allows_original_sibling_import_without_sys_path_change(self):
        runner, digest = self.source('runner.py', 'VALUE = 41\n')
        scorer, score_digest = self.source('scorer.py',
            'from run_deepfri_catalog_20261020 import VALUE\nRESULT = VALUE + 1\n')
        before = list(sys.path)
        s.preload_runner(runner, digest)
        module = s.load_exact(scorer, score_digest, 'invented_preflight')
        self.assertEqual(module.RESULT, 42)
        self.assertEqual(sys.path, before)

    def test_wrong_runner_pin_rejected_before_execution(self):
        path, _ = self.source('runner.py', 'raise RuntimeError("must not execute")\n')
        with self.assertRaises(ValueError):
            s.preload_runner(path, '0' * 64)
        self.assertNotIn(s.RUNNER_NAME, sys.modules)

    def test_preexisting_module_rejected(self):
        path, digest = self.source('runner.py', 'VALUE = 1\n')
        sys.modules[s.RUNNER_NAME] = object()
        with self.assertRaises(ValueError):
            s.preload_runner(path, digest)

    def test_original_cli_main_runs_once_with_exact_arguments(self):
        target = self.root / 'entry.json'
        path, _ = self.source('scorer.py',
            'import json,sys\nfrom pathlib import Path\n'
            'if __name__ == "__main__":\n'
            ' with Path(sys.argv[1]).open("x") as f: json.dump(sys.argv[2:],f)\n')
        before = sys.argv
        s.original_main(path, [str(target), '--config', 'frozen', '--output', 'exact'])
        self.assertEqual(json.loads(target.read_text()), ['--config', 'frozen', '--output', 'exact'])
        self.assertIs(sys.argv, before)

    def test_fsync_failure_prevents_native_callback(self):
        called = []
        with mock.patch.object(s.os, 'fsync', side_effect=OSError('invented fsync failure')):
            with self.assertRaises(OSError):
                s.persist_then_call(self.root / 'claim.json', {}, lambda: called.append(True))
        self.assertFalse(called)
        self.assertTrue((self.root / 'claim.json').exists())

    def test_parent_fsync_failure_prevents_native_callback(self):
        called = []
        real = os.fsync
        count = []
        def injected(fd):
            count.append(fd)
            if len(count) == 2:
                raise OSError('invented parent fsync failure')
            return real(fd)
        with mock.patch.object(s.os, 'fsync', side_effect=injected):
            with self.assertRaises(OSError):
                s.persist_then_call(self.root / 'claim.json', {}, lambda: called.append(True))
        self.assertFalse(called)

    def test_exclusive_claim_disallows_replay(self):
        path = self.root / 'claim.json'
        called = []
        s.persist_then_call(path, {}, lambda: called.append(True))
        with self.assertRaises(FileExistsError):
            s.persist_then_call(path, {}, lambda: called.append(True))
        self.assertEqual(called, [True])

    def test_dangling_attempt_and_final_closure_prevent_entry(self):
        with mock.patch.object(s, 'HERE', self.root), mock.patch.object(s, 'RUN', self.root / 'run'), \
                mock.patch.object(s, 'PARALLEL', self.root / 'parallel'):
            (self.root / 'native_entry_attempt.json').symlink_to(self.root / 'missing')
            with self.assertRaises(FileExistsError):
                s.outputs_absent()

    def test_runtime_environment_clears_injection_and_secrets(self):
        source = {'PYTHONPATH': '/invented', 'PYTHONHOME': '/invented', 'VIRTUAL_ENV': 'x',
            'LD_PRELOAD': 'invented.so', 'LD_AUDIT': 'invented.so', 'LD_LIBRARY_PATH': '/invented',
            'OPENAI_API_KEY': 'invented-secret', 'HF_TOKEN': 'invented-token', 'OPENAI_BASE_URL': 'invented',
            'SLURM_JOB_ID': 'invented-job'}
        env = l.cpu_environment(self.root / 'runtime', self.root / 'scratch', source)
        for name in ('PYTHONPATH', 'PYTHONHOME', 'VIRTUAL_ENV', 'LD_PRELOAD', 'LD_AUDIT',
                     'OPENAI_API_KEY', 'HF_TOKEN', 'OPENAI_BASE_URL'):
            self.assertNotIn(name, env)
        self.assertEqual(env['CUDA_VISIBLE_DEVICES'], '')
        self.assertEqual(env['PYTHONSAFEPATH'], '1')
        self.assertEqual(env['LD_LIBRARY_PATH'], str(self.root / 'runtime/python/lib'))
        self.assertEqual(env['SLURM_JOB_ID'], 'invented-job')

    def test_stop_after_intent_prevents_original_entry(self):
        called = []
        with mock.patch.object(s, 'authority', side_effect=PermissionError('invented late STOP')), \
                mock.patch.object(s, 'original_main', side_effect=lambda *_: called.append(True)):
            with self.assertRaises(PermissionError):
                s.persist_then_call(self.root / 'claim.json', {},
                    lambda: s.guarded_original_entry('config', 'review', 'scorer', []))
        self.assertFalse(called)

    def CPU_fields(self):
        return {'JobId': '123', 'UserId': 'dongweij(26129)', 'JobState': 'RUNNING',
            'JobName': 'bio-P13-first-native-CPU', 'Partition': 'il-data', 'QOS': 'il-data',
            'WorkDir': str(s.ROOT), 'Command': str(s.HERE / 'score_CPU.sbatch'),
            'Requeue': '0', 'Restarts': '0', 'TimeLimit': '02:00:00', 'NumCPUs': '2',
            'NodeList': 'ampere8', 'NumNodes': '1', 'AllocTRES': 'cpu=2,mem=8G,node=1',
            'ReqTRES': 'cpu=2,mem=8G,node=1', 'TresPerNode': 'N/A'}

    def test_exact_CPU_allocation_identity(self):
        s.verify_CPU_fields(self.CPU_fields(), '123')

    def test_requesting_GPU_rejected(self):
        fields = self.CPU_fields()
        fields['ReqTRES'] += ',gres/gpu:a100=1'
        with self.assertRaises(ValueError):
            s.verify_CPU_fields(fields, '123')

    def test_allocated_GPU_rejected(self):
        fields = self.CPU_fields()
        fields['AllocTRES'] += ',gres/gpu=1'
        with self.assertRaises(ValueError):
            s.verify_CPU_fields(fields, '123')

    def test_wrong_CPU_node_rejected(self):
        fields = self.CPU_fields()
        fields['NodeList'] = 'ampere7'
        with self.assertRaises(ValueError):
            s.verify_CPU_fields(fields, '123')

    def terminal_fixture(self):
        identity = {'state': 'COMPLETED', 'exit_code': '0:0', 'job_name': 'invented-P13',
            'submit_command': ['sbatch', '--parsable', '/invented/exact.sbatch']}
        cfg = {'terminal_GPU_jobs': {'123': identity}, 'terminal_CPU_jobs': {}}
        row = '|'.join(['123', 'COMPLETED', '0:0', '26129', 'invented-P13',
            str(s.ROOT), 'sbatch --parsable /invented/exact.sbatch']) + '\n'
        return cfg, row

    def test_exact_terminal_source_identity(self):
        cfg, row = self.terminal_fixture()
        with mock.patch.object(s.subprocess, 'run', return_value=SimpleNamespace(stdout=row)), \
                mock.patch.object(s, 'scheduler_command', return_value='/invented/sacct'):
            s.terminal_jobs(cfg)

    def test_foreign_terminal_owner_rejected(self):
        cfg, row = self.terminal_fixture()
        with mock.patch.object(s.subprocess, 'run', return_value=SimpleNamespace(stdout=row.replace('26129', '999'))), \
                mock.patch.object(s, 'scheduler_command', return_value='/invented/sacct'):
            with self.assertRaises(ValueError):
                s.terminal_jobs(cfg)

    def test_changed_terminal_command_rejected(self):
        cfg, row = self.terminal_fixture()
        with mock.patch.object(s.subprocess, 'run', return_value=SimpleNamespace(stdout=row.replace('exact.sbatch', 'wrong.sbatch'))), \
                mock.patch.object(s, 'scheduler_command', return_value='/invented/sacct'):
            with self.assertRaises(ValueError):
                s.terminal_jobs(cfg)

    def test_runtime_missing_does_not_offer_download_or_install(self):
        body = (HERE / 'launch.py').read_text()
        self.assertNotIn('pip', body)
        self.assertNotIn('urlopen', body)
        self.assertNotIn('obtain_runtime', body)
        self.assertIn('no fallback acquisition', body)


if __name__ == '__main__':
    with mock.patch('subprocess.run', side_effect=AssertionError('No actual subprocess in synthetic tests')), \
            mock.patch('socket.socket', side_effect=AssertionError('No network in synthetic tests')):
        unittest.main()
