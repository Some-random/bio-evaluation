"""First native P13 score after independently proved import-only failure.

No model/network/GPU action. Original runner, scorer, sealed predictions and old
failed controls are immutable. A new durable intent permits only one native entry.
"""
from contextlib import ExitStack
from datetime import datetime
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import runpy
import shlex
import socket
import stat
import subprocess
import sys
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
PARALLEL = HERE.parent
BASE = ROOT / '.local/catalog_execution_2026-10-20'
RUN = BASE / 'tasks/P13/runtime/benchmark'
CONFIG = BASE / 'tasks/P13/test_config.json'
RUNNER = ROOT / 'scripts/run_deepfri_catalog_20261020.py'
SCORER = ROOT / 'scripts/score_deepfri_catalog_20261020.py'
RUNNER_NAME = 'run_deepfri_catalog_20261020'
RUNTIME = Path('/tmp/bio-gfp-development-242190-xzl_r06k')


def stamp():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def regular(path):
    path = Path(path)
    if not path.is_absolute() or any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('Absolute non-symlink source required')
    value = path.lstat()
    if not stat.S_ISREG(value.st_mode) or value.st_uid != os.getuid():
        raise ValueError('Owned regular source required')
    return value


def sha(path):
    regular(path)
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for piece in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(piece)
    return digest.hexdigest()


def read(path):
    regular(path)
    return json.loads(Path(path).read_bytes())


def exact(path, digest):
    if sha(path) != digest:
        raise ValueError('Pinned metadata or source changed: ' + str(path))


def durable(path, value):
    path = Path(path)
    body = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, 'wb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def persist_then_call(path, value, callback):
    durable(path, value)
    return callback()


def load_exact(path, digest, name, install=False):
    exact(path, digest)
    if name in sys.modules:
        # A fresh admitted interpreter is mandatory; do not accept a foreign or
        # previously imported module even when it advertises the same __file__.
        raise ValueError('Scorer dependency module was already installed')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    if install:
        sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        if install:
            sys.modules.pop(name, None)
        raise
    exact(path, digest)
    return module


def preload_runner(path, digest):
    return load_exact(path, digest, RUNNER_NAME, install=True)


def scheduler_command(name):
    cfg = read(HERE / 'config.json')
    source = HERE / 'scheduler_probe.py'
    module = load_exact(source, cfg['files_sha256'][str(source)], 'P13_absolute_scheduler_source')
    return str(module.validate_command(name, cfg['scheduler_commands'][name]))


def original_main(scorer, argv):
    previous = sys.argv
    try:
        sys.argv = [str(scorer), *argv]
        return runpy.run_path(str(scorer), run_name='__main__')
    finally:
        sys.argv = previous


def authority(config_sha, admission_sha, private_runtime=True):
    if sys.flags.optimize or not sys.flags.safe_path or os.environ.get('PYTHONSAFEPATH') != '1':
        raise PermissionError('Safe-path, nonoptimized interpreter required')
    if os.environ.get('CUDA_VISIBLE_DEVICES') != '':
        raise PermissionError('CPU-only empty GPU visibility required')
    exact(HERE / 'config.json', config_sha)
    cfg = read(HERE / 'config.json')
    if (cfg.get('role') != 'P13_first_native_CPU_import_repair_source'
            or cfg.get('planned') != 3416 or cfg.get('historical_invalids') != 4
            or cfg.get('new_model_or_generation_calls') != 0
            or cfg.get('old_failed_state_and_STOP_preserved') is not True):
        raise PermissionError('Exact full retained condition required')
    for path, digest in cfg['files_sha256'].items():
        exact(path, digest)
    for path, digest in cfg['preserved_evidence_sha256'].items():
        exact(path, digest)
    for name in ('scontrol', 'sacct'):
        scheduler_command(name)
    for path in cfg['preserved_preparation_execution_paths_must_remain_absent']:
        if os.path.lexists(path):
            raise FileExistsError('Preserved route preparation has an actual or ambiguous execution')
    exact(cfg['zero_native_entry_proof'], cfg['zero_native_entry_proof_sha256'])
    proof = read(cfg['zero_native_entry_proof'])
    if (proof.get('reviewer') != '/root/priority_runtime_review/lpb398_verifier_tests'
            or proof.get('role') != 'supporting_independent_P13_CPU_v2_command_lookup_failure_zero_native_entry_source_proof'
            or proof.get('supporting_pass') is not True
            or proof.get('CPU_job_id') != '250370'
            or proof.get('failed_child_conclusions') != {
                'helper_main_execute_authority_entered': True, 'native_entry_claim_created': False,
                'native_metric_calculation': False, 'original_native_functions_entered': False,
                'original_pre_reference_verifier_entered': False, 'original_runner_imported': False,
                'original_score_entered': False, 'original_scorer_imported': False,
                'original_scorer_main_entered': False, 'protected_reference_read': False}):
        raise PermissionError('Independent V2 zero-native-entry proof required')
    exact(cfg['original_import_zero_entry_proof'], cfg['original_import_zero_entry_proof_sha256'])
    original_proof = read(cfg['original_import_zero_entry_proof'])
    if (original_proof.get('supporting_pass') is not True
            or original_proof.get('reviewer') != '/root/priority_runtime_review/lpb398_verifier_tests'
            or original_proof.get('role') != 'supporting_independent_P13_failed_scorer_subprocess_zero_entry_source_proof'
            or original_proof.get('failed_subprocess_conclusions') != {
                'main_entered': False, 'matrix_metrics_entered': False,
                'native_functions_entered': False, 'native_score_calculation': False,
                'protected_reference_read': False, 'score_entered': False}):
        raise PermissionError('Cumulative original import failure zero-entry proof required')
    release = read(cfg['delegated_release'])
    if (release.get('issuer') != '/root/independent_review' or release.get('approved') is not True
            or release.get('maximum_original_native_scoring_function_entries') != 1
            or release.get('failed_subprocess_zero_entry_proof', {}).get('sha256')
                != cfg['zero_native_entry_proof_sha256']):
        raise PermissionError('Exact delegated first-native CPU scope required')
    exact(HERE / 'independent_admission.json', admission_sha)
    grant = read(HERE / 'independent_admission.json')
    if (grant.get('reviewer') not in {'/root/priority_runtime_review', '/root/independent_review', '/root'}
            or grant.get('approved') is not True
            or grant.get('role') != 'independent_P13_first_native_CPU_score_entry_admission'
            or grant.get('config_sha256') != config_sha
            or grant.get('zero_native_entry_proof_sha256') != cfg['zero_native_entry_proof_sha256']
            or grant.get('first_native_entry_once_only') is not True
            or grant.get('old_failed_state_and_STOP_preserved') is not True
            or grant.get('model_or_GPU_calls_authorized') is not False):
        raise PermissionError('Exact independent first-native CPU admission required')
    if any(os.path.lexists(p) for p in (HERE / 'STOP', PARALLEL / 'STOP_OPERATION')):
        raise PermissionError('CPU recovery or owner operation STOP is active')
    if private_runtime:
        if (Path(sys.executable) != RUNTIME / 'python/bin/python3.12'
                or platform.python_version() != '3.12.15'
                or socket.gethostname() != 'ampere8.stanford.edu'
                or not os.environ.get('SLURM_JOB_ID')):
            raise ValueError('Exact retained private CPU runtime/allocation required')
        launch = read(HERE / 'CPU_launch_attempt.json')
        probe = read(HERE / 'runtime_version_probe.json')
        scheduler_probe = read(HERE / 'scheduler_version_probe.json')
        if (launch.get('config_sha256') != config_sha
                or launch.get('independent_admission_sha256') != admission_sha
                or launch.get('CPU_job_id') != os.environ['SLURM_JOB_ID']
                or launch.get('runtime') != str(RUNTIME)
                or launch.get('runtime_python_sha256') != sha(RUNTIME / 'python/bin/python3.12')
                or probe.get('runtime') != cfg['expected_scoring_runtime']
                or launch.get('runtime_version_probe_sha256') != sha(HERE / 'runtime_version_probe.json')
                or probe.get('config_sha256') != config_sha
                or probe.get('independent_admission_sha256') != admission_sha
                or probe.get('CPU_job_id') != os.environ['SLURM_JOB_ID']
                or launch.get('scheduler_version_probe_sha256') != sha(HERE / 'scheduler_version_probe.json')
                or scheduler_probe.get('config_sha256') != config_sha
                or scheduler_probe.get('independent_admission_sha256') != admission_sha
                or scheduler_probe.get('CPU_job_id') != os.environ['SLURM_JOB_ID']
                or scheduler_probe.get('actual_executable') != str(RUNTIME / 'python/bin/python3.12')
                or scheduler_probe.get('actual_python') != '3.12.15'
                or scheduler_probe.get('exact_original_terminal_identities_verified') is not True
                or scheduler_probe.get('native_or_model_or_reference_calls') != 0):
            raise ValueError('Exact same-launch runtime probe required before native entry')
        own_CPU_identity()
    return cfg


def terminal_jobs(cfg):
    expected = {**cfg['terminal_GPU_jobs'], **cfg['terminal_CPU_jobs']}
    ids = list(expected)
    result = subprocess.run([scheduler_command('sacct'), '--jobs', ','.join(ids), '--noheader', '--parsable2',
        '--format=JobIDRaw,State,ExitCode,UID,JobName%128,WorkDir%512,SubmitLine%8192'],
        capture_output=True, text=True, check=True, timeout=45)
    rows = {row.split('|')[0]: row.split('|')[1:] for row in result.stdout.splitlines()
            if row.split('|')[0] in ids}
    if set(rows) != set(expected):
        raise ValueError('Original allocation terminal identities are incomplete')
    for job_id, identity in expected.items():
        fields = rows[job_id]
        if (len(fields) < 6 or fields[:5] != [identity['state'], identity['exit_code'],
                '26129', identity['job_name'], str(ROOT)]
                or shlex.split(fields[5]) != identity['submit_command']):
            raise ValueError('Original allocation terminal owned source identity differs')


def verify_CPU_fields(fields, job_id):
    expected = {'JobId': job_id, 'UserId': 'dongweij(26129)', 'JobState': 'RUNNING',
        'JobName': 'bio-P13-first-native-CPU', 'Partition': 'il-data', 'QOS': 'il-data',
        'WorkDir': str(ROOT), 'Command': str(HERE / 'score_CPU.sbatch'),
        'Requeue': '0', 'Restarts': '0', 'TimeLimit': '02:00:00', 'NumCPUs': '2',
        'NodeList': 'ampere8', 'NumNodes': '1'}
    if any(fields.get(key) != value for key, value in expected.items()):
        raise ValueError('Exact finite owned CPU-only allocation differs')
    for name in ('AllocTRES', 'ReqTRES'):
        rows = dict(piece.split('=', 1) for piece in fields.get(name, '').split(',') if '=' in piece)
        if rows.get('cpu') != '2' or rows.get('mem') != '8G':
            raise ValueError('Exact CPU/memory request and allocation required')
        for key, value in rows.items():
            if 'gpu' in key.lower() and value != '0':
                raise ValueError('CPU scorer must request and allocate zero GPUs')
    if 'gpu' in fields.get('TresPerNode', '').lower():
        raise ValueError('No per-node GPU request is permitted')


def own_CPU_identity():
    job_id = os.environ.get('SLURM_JOB_ID', '')
    if not job_id.isdecimal():
        raise ValueError('Actual finite CPU allocation identity required')
    result = subprocess.run([scheduler_command('scontrol'), 'show', 'job', job_id, '-o'],
        check=True, capture_output=True, text=True, timeout=45)
    fields = dict(piece.split('=', 1) for piece in result.stdout.split() if '=' in piece)
    verify_CPU_fields(fields, job_id)
    return fields


def lock_existing(stack, path):
    before = regular(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    stack.callback(os.close, fd)
    current = os.fstat(fd)
    if (before.st_dev, before.st_ino) != (current.st_dev, current.st_ino):
        raise ValueError('Original lock identity changed')
    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)


def outputs_absent():
    for path in (RUN / 'scores.json', RUN / 'scores.per_case.json', HERE / 'native_entry_attempt.json',
                 HERE / 'completion.json', HERE / 'score_status.json', HERE / 'failure.json',
                 PARALLEL / 'FINAL_NATIVE_CLOSED.json'):
        if os.path.lexists(path):
            raise FileExistsError('Preserve every actual or ambiguous native entry; never retry')


def guarded_original_entry(config_sha, admission_sha, scorer, argv):
    authority(config_sha, admission_sha)
    return original_main(scorer, argv)


def execute(config_sha, admission_sha):
    cfg = authority(config_sha, admission_sha)
    with ExitStack() as stack:
        for path in (PARALLEL / 'operator.lock', RUN / '.runner.lock',
                     *[PARALLEL / ('replicas/' + str(rank) + '/runtime/pool.lock') for rank in range(3)]):
            lock_existing(stack, path)
        authority(config_sha, admission_sha)
        terminal_jobs(cfg)
        outputs_absent()
        # This explicit original-source preload keeps safe-path enabled and
        # never adds the project scripts directory to the module search path.
        preload_runner(RUNNER, cfg['files_sha256'][str(RUNNER)])
        native = load_exact(SCORER, cfg['files_sha256'][str(SCORER)], 'P13_original_pre_reference_only')
        native.verify_locked_generation(CONFIG, RUN)
        # Torch/version import is CPU-only and precedes any reference access.
        import torch
        if str(torch.__version__) != '2.13.0+cu130':
            raise ValueError('Frozen native Torch runtime differs')
        outputs_absent()
        argv = ['--config', str(CONFIG), '--run-folder', str(RUN), '--output', str(RUN / 'scores.json')]
        intent = {'role': 'P13_first_native_CPU_entry_once_only', 'at_pacific': stamp(),
            'config_sha256': config_sha, 'independent_admission_sha256': admission_sha,
            'zero_native_entry_proof_sha256': cfg['zero_native_entry_proof_sha256'],
            'prediction_lock_sha256': cfg['preserved_evidence_sha256'][str(RUN / 'prediction_lock.json')],
            'pid': os.getpid(), 'hostname': socket.gethostname(), 'CPU_job_id': os.environ['SLURM_JOB_ID'],
            'original_scoring_status_and_STOP_preserved': True, 'new_model_calls': 0}
        def first_entry():
            # All pinned authorities/STOPs are freshly checked after preflight,
            # accounting waits and durable intent, immediately before original main.
            return guarded_original_entry(config_sha, admission_sha, SCORER, argv)
        try:
            persist_then_call(HERE / 'native_entry_attempt.json', intent, first_entry)
            authority(config_sha, admission_sha)
            score = read(RUN / 'scores.json')
            if (score.get('planned') != 3416 or score.get('invalid_or_missing') != 4
                    or score.get('parsed') != 3412
                    or score.get('metrics') != {'auprc@micro': None, 'f1_max': None}
                    or score.get('full_planned_primary_metrics_valid') is not False
                    or score.get('prediction_lock_sha256') != intent['prediction_lock_sha256']
                    or score.get('scorer_sha256') != cfg['files_sha256'][str(SCORER)]):
                raise ValueError('Full native score/invalid denominator differs')
            for path in (RUN / 'scores.json', RUN / 'scores.per_case.json'):
                descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
                try:
                    os.fsync(descriptor)
                finally:
                    os.close(descriptor)
            descriptor = os.open(RUN, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
            result = dict(intent, role='P13_first_native_CPU_score_completed', native_entries=1,
                score_sha256=sha(RUN / 'scores.json'), per_case_sha256=sha(RUN / 'scores.per_case.json'),
                original_failed_no_retry_preserved=True, new_GPU_allocations=0,
                planned=3416, parsed=3412, invalid_or_missing=4, full_primary_metrics_null=True)
            durable(HERE / 'completion.json', result)
            status = dict(result, stage='completed', exit_code=0, finished_at_pacific=stamp(),
                scoring_status_path=str(HERE / 'score_status.json'),
                completion_sha256=sha(HERE / 'completion.json'))
            durable(HERE / 'score_status.json', status)
            durable(PARALLEL / 'FINAL_NATIVE_CLOSED.json', {
                'role': 'P13_native_closed_after_proven_import_failure_first_CPU_entry',
                'at_pacific': stamp(), 'task_id': 'P13', 'planned': 3416, 'terminal': 3416,
                'score_path': str(RUN / 'scores.json'), 'score_sha256': result['score_sha256'],
                'prediction_lock_sha256': intent['prediction_lock_sha256'],
                'scoring_status_path': str(HERE / 'score_status.json'),
                'scoring_status_sha256': sha(HERE / 'score_status.json'),
                'old_failed_scoring_status_path': str(BASE / 'control/P13_scoring_status.json'),
                'old_failed_scoring_status_sha256': cfg['preserved_evidence_sha256'][str(BASE / 'control/P13_scoring_status.json')],
                'zero_native_entry_proof_sha256': cfg['zero_native_entry_proof_sha256'],
                'delegated_release_sha256': cfg['files_sha256'][cfg['delegated_release']],
                'first_native_CPU_completion_sha256': sha(HERE / 'completion.json'),
                'further_allocation_or_scoring_authorized': False})
            return result
        except BaseException as error:
            if not os.path.lexists(HERE / 'failure.json'):
                durable(HERE / 'failure.json', {'at_pacific': stamp(),
                    'error_type': type(error).__name__, 'no_retry': True,
                    'old_outputs_controls_and_any_native_intent_preserved': True})
            raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config-sha256', required=True)
    parser.add_argument('--admission-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(execute(args.config_sha256, args.admission_sha256)))
