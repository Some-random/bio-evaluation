"""Invented binary/path/hash regressions; no real scheduler calls."""
import hashlib
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('invented_scheduler_source', HERE / 'scheduler_probe.py')
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)


class Scheduler(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='p13-invented-cli-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.file = self.root / 'scontrol'
        self.file.write_bytes(b'#!/bin/sh\nexit 0\n')
        self.file.chmod(0o700)
        self.record = {'path': str(self.file), 'uid': os.getuid(), 'bytes': self.file.stat().st_size,
            'sha256': hashlib.sha256(self.file.read_bytes()).hexdigest()}
        self.patch = mock.patch.object(p, 'SCHEDULER_COMMANDS', {'scontrol': self.record})
        self.patch.start()
        self.addCleanup(self.patch.stop)

    def test_exact_absolute_regular_executable(self):
        self.assertEqual(p.validate_command('scontrol', self.record), self.file)

    def test_wrong_path_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_command('scontrol', dict(self.record, path='/invented/wrong'))

    def test_absent_path_rejected(self):
        self.file.unlink()
        with self.assertRaises(FileNotFoundError):
            p.validate_command('scontrol', self.record)

    def test_changed_binary_digest_rejected(self):
        self.file.write_bytes(b'#!/bin/sh\nexit 1\n')
        with self.assertRaises(ValueError):
            p.validate_command('scontrol', self.record)

    def test_symlink_rejected(self):
        self.file.unlink()
        self.file.symlink_to('/invented/target')
        with self.assertRaises(ValueError):
            p.validate_command('scontrol', self.record)

    def test_world_writable_binary_rejected(self):
        self.file.chmod(0o722)
        with self.assertRaises(ValueError):
            p.validate_command('scontrol', self.record)

    def test_missing_executable_bit_rejected(self):
        self.file.chmod(0o600)
        with self.assertRaises(ValueError):
            p.validate_command('scontrol', self.record)

    def test_unlisted_command_rejected(self):
        with self.assertRaises(ValueError):
            p.validate_command('sbatch', self.record)


if __name__ == '__main__':
    with mock.patch('subprocess.run', side_effect=AssertionError('No real scheduler in invented tests')), \
            mock.patch('socket.socket', side_effect=AssertionError('No network')):
        unittest.main()
