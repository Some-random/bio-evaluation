"""Actual fresh private-Python sanitized-env regression; only --version calls.

The first child runs the two fixed scheduler version commands. The second child
runs an invented executable by absolute path while /usr/local/bin is absent from
PATH. No model, Torch, scorer, references or real scheduler queries are invoked.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
PYTHON = Path('/tmp/dongweij/p13-private-python-core-review-2zku3j63/python/bin/python3.12')
PYTHON_SHA = 'eaaa308032c4aa063df5880c4c293cd458b4629d503fbc2c03ec163d71f7f790'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    if PYTHON.is_symlink() or hashlib.sha256(PYTHON.read_bytes()).hexdigest() != PYTHON_SHA:
        raise ValueError('Exact existing private test interpreter required')
    launch = load('P13_actual_cpu_environment_test', HERE / 'launch.py')
    probe = load('P13_actual_scheduler_source_test', HERE / 'scheduler_probe.py')
    with tempfile.TemporaryDirectory(prefix='p13-private-scheduler-') as folder:
        scratch = Path(folder)
        scratch.chmod(0o700)
        env = launch.cpu_environment(PYTHON.parents[2], scratch, os.environ)
        if '/usr/local/bin' in env['PATH'].split(os.pathsep):
            raise ValueError('Regression must reproduce scheduler directory PATH exclusion')
        result = subprocess.run([str(PYTHON), '-P', '-B', str(HERE / 'scheduler_probe.py'),
            '--commands-json', json.dumps(probe.SCHEDULER_COMMANDS, sort_keys=True)],
            env=env, cwd=scratch, text=True, capture_output=True, check=True, timeout=90)
        observed = json.loads(result.stdout)
        if observed['actual_python'] != '3.12.15' or observed['actual_executable'] != str(PYTHON):
            raise ValueError('Actual fresh private interpreter mismatch')
        fake = scratch / 'absolute-invented-scheduler'
        fake.write_text('#!/bin/sh\n[ "$1" = "--version" ] || exit 9\nprintf "invented-scheduler-version\\n"\n')
        fake.chmod(0o700)
        code = ('import subprocess,sys; p=subprocess.run([sys.argv[1],"--version"],'
            'check=True,text=True,capture_output=True);print(p.stdout.strip())')
        toy = subprocess.run([str(PYTHON), '-P', '-B', '-c', code, str(fake)],
            env=env, cwd=scratch, text=True, capture_output=True, check=True, timeout=30)
        if toy.stdout.strip() != 'invented-scheduler-version':
            raise ValueError('Actual private absolute-executable regression failed')
        print(json.dumps({'role': 'actual_private_Python_CPU_environment_scheduler_regression',
            'passed': True, 'private_python': str(PYTHON), 'private_python_sha256': PYTHON_SHA,
            'private_python_version': observed['actual_python'],
            'scheduler_versions': observed['scheduler_versions'],
            'sanitized_PATH_excludes_usr_local_bin': True,
            'absolute_invented_executable_test_passed': True,
            'real_scheduler_version_commands': 2, 'real_scheduler_queries_or_mutations': 0,
            'native_Torch_model_reference_or_biological_calls': 0}))


if __name__ == '__main__':
    main()
