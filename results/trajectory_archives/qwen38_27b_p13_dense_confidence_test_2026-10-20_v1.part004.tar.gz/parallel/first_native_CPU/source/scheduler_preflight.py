"""Admitted startup's fresh private-interpreter read-only scheduler boundary."""
import argparse
import importlib.util
import json
from pathlib import Path
import platform
import sys

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config-sha256', required=True)
    parser.add_argument('--admission-sha256', required=True)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('P13_scheduler_preflight_source', HERE / 'score_once.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    cfg = module.authority(args.config_sha256, args.admission_sha256, private_runtime=False)
    probe_path = HERE / 'scheduler_probe.py'
    probe = module.load_exact(probe_path, cfg['files_sha256'][str(probe_path)], 'P13_scheduler_version_preflight')
    versions = probe.probe_all(cfg['scheduler_commands'])
    allocation = module.own_CPU_identity()
    module.terminal_jobs(cfg)
    module.authority(args.config_sha256, args.admission_sha256, private_runtime=False)
    print(json.dumps({'scheduler_versions': versions, 'actual_python': platform.python_version(),
        'actual_executable': sys.executable, 'CPU_allocation': allocation,
        'exact_original_terminal_identities_verified': True,
        'scheduler_queries_or_mutations': {'read_only_queries': 2, 'mutations': 0},
        'native_or_model_or_reference_calls': 0}))


if __name__ == '__main__':
    main()
