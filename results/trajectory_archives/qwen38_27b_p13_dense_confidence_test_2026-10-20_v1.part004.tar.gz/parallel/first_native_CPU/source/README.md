# P13 first native CPU scoring entry

This additive operational repair is source preparation until exact independent
admission and the runtime owner's once-only CPU submission. The previous scorer
subprocess failed at its sibling import before main, score, reference access or
native metric entry. Its failed status, trace, intents and inference STOP remain
immutable. Generation is fully sealed: 3,416 terminal, 3,412 delivered vectors
and four historical ambiguous invalids; original full primary metrics stay null.

The finite zero-GPU allocation uses the retained runtime only on ampere8 and
fails if that cache is absent or its actual Python/Torch build differs. It does
not download/install software, acquire weights, initialize a model or restore
inference permissions. Runtime probing checks Python 3.12.15 and Torch
2.13.0+cu130 on CPU with float32 and both thread counts one in a separate child;
the original scorer retains its own unchanged thread setters. Safe-path remains
enabled, injected search/loader paths and credentials are removed, and the exact
runner is explicitly preloaded under its canonical module name before importing
the unchanged scorer. The scripts directory never enters sys.path.

The wrapper verifies exact old terminal ownership/source metadata, exclusively
owns the existing coordinator/canonical-output/three-pool locks, reuses the
original canonical pre-reference verifier, then consumes a new durable native
intent. A final fresh authority/STOP/source/seal check immediately precedes the
unchanged original CLI entry. Every uncertain/failed new CPU or native attempt
is preserved with no automatic replay. New completion, score_status and native
closure explicitly identify first CPU scoring and retain the original failure.

Independent admission goes in independent_admission.json and binds config.json
and the preserved zero-entry proof. Expected role:
independent_P13_first_native_CPU_score_entry_admission; reviewer must be
/root/priority_runtime_review, /root/independent_review or /root, never this
source author. Required fields: approved=true, config_sha256,
zero_native_entry_proof_sha256, first_native_entry_once_only=true,
old_failed_state_and_STOP_preserved=true, model_or_GPU_calls_authorized=false.

The runtime owner supplies --config-sha256 and --admission-sha256 to the exact
score_CPU.sbatch. This source lane performs no actual submission, scorer import,
reference/prediction parsing, package or publication. Downstream provenance and
publication adapters are separately owned and do not enter this config's pins.

Tests use invented source/files and mocked accounting only. They do not load
Torch or original scientific modules, invoke subprocesses, or access a network.

V3 preserves the actual V2 CPU250370 failure before native entry. A separate
honestly attributed delegated release is required because the previous CPU
launch authorization was consumed; neither old claim is reset. Both cumulative
zero-entry proofs remain bound. Only fixed root-owned, non-symlink executable
/usr/local/bin/scontrol and /usr/local/bin/sacct with exact SHA-256 pins are
accepted; PATH is not widened. The production private child must pass --version,
own-job and original-terminal identity queries in the exact sanitized environment
before either CPU/native intent. Its two preflight receipts are durable first;
the CPU claim pins their hashes, avoiding a circular receipt relationship.

The separate test_private_scheduler.py regression uses the existing byte-pinned
private Python 3.12.15 test interpreter, the same cpu_environment builder and
only two real scheduler --version invocations plus one invented executable.
It performs no actual scheduler query/mutation, Torch/scorer/native execution
or biological/reference access. Its result is preserved as metadata; actual
ampere8 accounting preflight remains a future admitted-startup operation.
