"""Pinned absolute scheduler paths; executable action is --version only."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys

SCHEDULER_COMMANDS = {
    'scontrol': {'path': '/usr/local/bin/scontrol', 'uid': 0, 'bytes': 162592,
        'sha256': '9f1af747a3ee7c4ee82876200d336da9363ce894ea3a818d59de9fcdf3f847c1'},
    'sacct': {'path': '/usr/local/bin/sacct', 'uid': 0, 'bytes': 81712,
        'sha256': 'eb1d38a281267c65dd12c51967f4cb81627bccd6d123ba97a8f156cef3be5628'},
}


def validate_command(name, supplied):
    expected = SCHEDULER_COMMANDS.get(name)
    if expected is None or supplied != expected:
        raise ValueError('Only the exact frozen absolute scheduler binary is allowed')
    path = Path(expected['path'])
    if not path.is_absolute() or any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('Absolute nonsymlink scheduler binary required')
    value = path.lstat()
    if (not stat.S_ISREG(value.st_mode) or value.st_uid != expected['uid']
            or value.st_size != expected['bytes'] or value.st_mode & 0o022
            or not os.access(path, os.X_OK)):
        raise ValueError('Pinned executable scheduler ownership or mode changed')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        current = os.fstat(stream.fileno())
        if (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns) != (
                current.st_dev, current.st_ino, current.st_size, current.st_mtime_ns, current.st_ctime_ns):
            raise ValueError('Scheduler binary changed while opening')
        if hashlib.sha256(stream.read()).hexdigest() != expected['sha256']:
            raise ValueError('Pinned scheduler binary digest changed')
    return path


def probe_all(commands):
    if set(commands) != set(SCHEDULER_COMMANDS):
        raise ValueError('Both exact scheduler commands are required')
    if not sys.flags.safe_path or os.environ.get('PYTHONSAFEPATH') != '1':
        raise PermissionError('Fresh safe-path interpreter required for scheduler probe')
    rows = {}
    for name in ('scontrol', 'sacct'):
        path = validate_command(name, commands[name])
        result = subprocess.run([str(path), '--version'], check=True, capture_output=True,
            text=True, timeout=30)
        if not result.stdout.strip().startswith('slurm ') or '\n' in result.stdout.strip():
            raise ValueError('Expected one-line scheduler version response')
        validate_command(name, commands[name])
        rows[name] = dict(commands[name], version=result.stdout.strip())
    return rows


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commands-json', required=True)
    args = parser.parse_args()
    print(json.dumps({'scheduler_versions': probe_all(json.loads(args.commands_json)),
        'actual_python': platform.python_version(), 'actual_executable': sys.executable,
        'scheduler_queries_or_mutations': 0, 'native_or_model_or_reference_calls': 0}))
