"""Exact retained-node CPU runtime launcher; never obtains models or software."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import stat
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
RUNTIME = Path('/tmp/bio-gfp-development-242190-xzl_r06k')


def cpu_environment(runtime, scratch, original):
    env = dict(original)
    for name in list(env):
        upper = name.upper()
        if (upper.endswith(('API_KEY', 'API_TOKEN')) or upper in {
                'HF_TOKEN', 'HUGGING_FACE_HUB_TOKEN', 'OPENAI_BASE_URL',
                'OPENAI_ORG_ID', 'OPENAI_ORGANIZATION', 'OPENAI_PROJECT_ID',
                'ANTHROPIC_BASE_URL', 'AZURE_OPENAI_ENDPOINT', 'PYTHONPATH',
                'PYTHONHOME', 'VIRTUAL_ENV', 'LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'}):
            env.pop(name, None)
    env.update(PYTHONSAFEPATH='1', PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1',
        CUDA_VISIBLE_DEVICES='', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
        OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
        HF_HOME=str(scratch / 'hf'), XDG_CACHE_HOME=str(scratch), TMPDIR=str(scratch),
        PATH=str(runtime / 'python/bin') + ':/usr/bin:/bin',
        LD_LIBRARY_PATH=str(runtime / 'python/lib'), DO_NOT_TRACK='1')
    return env


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config-sha256', required=True)
    parser.add_argument('--admission-sha256', required=True)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location('P13_CPU_startup_source', HERE / 'score_once.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    cfg = module.authority(args.config_sha256, args.admission_sha256, private_runtime=False)
    if socket.gethostname() != 'ampere8.stanford.edu' or not os.environ.get('SLURM_JOB_ID'):
        raise ValueError('Retained runtime is node-local; exact CPU allocation required')
    allocation = module.own_CPU_identity()
    for path in (RUNTIME, RUNTIME / 'python', RUNTIME / 'python/bin'):
        value = path.lstat()
        if (path.is_symlink() or not stat.S_ISDIR(value.st_mode) or value.st_uid != os.getuid()):
            raise ValueError('Owned retained runtime directory required; no fallback acquisition')
    python = RUNTIME / 'python/bin/python3.12'
    module.regular(python)
    for name in ('CPU_launch_attempt.json', 'CPU_launch_completion.json', 'CPU_launch_failure.json'):
        if os.path.lexists(HERE / name):
            raise FileExistsError('No replay of an actual or ambiguous CPU launch')
    scratch = Path(tempfile.mkdtemp(prefix='p13cpu-', dir='/tmp'))
    scratch.chmod(0o700)
    env = cpu_environment(RUNTIME, scratch, os.environ)
    command = [str(python), '-P', '-B', str(HERE / 'score_once.py'),
        '--config-sha256', args.config_sha256, '--admission-sha256', args.admission_sha256]
    module.authority(args.config_sha256, args.admission_sha256, private_runtime=False)
    module.durable(HERE / 'CPU_launch_attempt.json', {
        'at_pacific': module.stamp(), 'role': 'P13_once_only_CPU_runtime_launch',
        'config_sha256': args.config_sha256, 'independent_admission_sha256': args.admission_sha256,
        'CPU_job_id': os.environ['SLURM_JOB_ID'], 'hostname': socket.gethostname(),
        'runtime': str(RUNTIME), 'runtime_python_sha256': module.sha(python),
        'scratch': str(scratch), 'CPU_allocation': allocation, 'new_GPU_or_model_calls': 0})
    probe = ("import json,platform,torch;torch.set_num_threads(1);torch.set_num_interop_threads(1);"
        "print(json.dumps({'python':platform.python_version(),'torch':str(torch.__version__),"
        "'device':'cpu','dtype':'float32','num_threads':torch.get_num_threads(),"
        "'num_interop_threads':torch.get_num_interop_threads()}))")
    try:
        observed = subprocess.run([str(python), '-P', '-B', '-c', probe], env=env,
            cwd=scratch, check=True, capture_output=True, text=True, timeout=180)
        version = json.loads(observed.stdout)
        if version != cfg['expected_scoring_runtime']:
            raise ValueError('Actual retained Python/Torch/thread runtime differs')
        module.durable(HERE / 'runtime_version_probe.json', {
            'at_pacific': module.stamp(), 'runtime': version, 'CPU_only': True,
            'reference_reads': 0, 'native_score_entries': 0,
            'CPU_launch_attempt_sha256': module.sha(HERE / 'CPU_launch_attempt.json'),
            'config_sha256': args.config_sha256})
        module.authority(args.config_sha256, args.admission_sha256, private_runtime=False)
        with (HERE / 'native_score.log').open('x') as log:
            result = subprocess.run(command, env=env, cwd=scratch,
                stdout=log, stderr=subprocess.STDOUT, check=True, timeout=3600)
        module.durable(HERE / 'CPU_launch_completion.json', {
            'at_pacific': module.stamp(), 'returncode': result.returncode,
            'config_sha256': args.config_sha256,
            'native_completion_sha256': module.sha(HERE / 'completion.json')})
    except BaseException as error:
        if not os.path.lexists(HERE / 'CPU_launch_failure.json'):
            module.durable(HERE / 'CPU_launch_failure.json', {'at_pacific': module.stamp(),
                'error_type': type(error).__name__, 'no_retry': True})
        raise


if __name__ == '__main__':
    main()
