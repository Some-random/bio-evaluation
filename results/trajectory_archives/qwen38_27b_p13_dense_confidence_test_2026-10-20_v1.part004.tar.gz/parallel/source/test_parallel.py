"""Invented-only operational tests; no real questions, targets, model or scheduler calls."""
import concurrent.futures
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from contextlib import redirect_stdout
from unittest.mock import Mock,patch
import urllib.error

HERE = Path(__file__).resolve().parent
def load(name,path):
    spec = importlib.util.spec_from_file_location(name,path)
    result = importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
c = load('p13_test_common',HERE/'common.py')
op = load('p13_test_operator',HERE/'coordinator.py')


def invented_cases(number):
    return [{'task_id':'P13','case_id':'invented-'+str(i),
        'messages':[{'role':'user','content':'Invented arithmetic fixture '+str(i)}]} for i in range(number)]


class Response:
    def __init__(self,body):self.raw=json.dumps(body).encode()
    def read(self):return self.raw
    def __enter__(self):return self
    def __exit__(self,*args):return False


class FakeBackend:
    def __init__(self,native,cases,canonical_output,local_by_id,fail_first=False):
        self.native=native;self.cases=cases;self.output=canonical_output;self.local=local_by_id
        self.by_content={row['messages'][0]['content']:row['case_id'] for row in cases}
        self.calls=[];self.fail_first=fail_first
    def open(self,request,timeout):
        if isinstance(request,str):
            return Response({'data':[{'id':self.native.MODEL}]})
        payload=json.loads(request.data)
        case_id=self.by_content[payload['messages'][0]['content']]
        key=hashlib.sha256(case_id.encode()).hexdigest()
        if (self.output/'requests'/(key+'.json')).read_bytes()!=request.data:
            raise AssertionError('Global durable request was not present before client call')
        if (self.local[case_id]/'requests'/(key+'.json')).read_bytes()!=request.data:
            raise AssertionError('Original native local request differs from global payload')
        if payload['seed']!=42 or payload['max_tokens']!=16384 or payload['top_p']!=.95 or payload['top_k']!=20:
            raise AssertionError('Frozen decoding changed')
        self.calls.append(request.data)
        if self.fail_first and len(self.calls)==1:
            raise urllib.error.HTTPError(request.full_url,503,'Invented failure',{},None)
        return Response({'model':self.native.MODEL,'choices':[{'finish_reason':'stop',
            'message':{'content':'{"scores":[0.1,0.2]}'}}],
            'usage':{'prompt_tokens':10,'completion_tokens':10}})


class NativeClaimTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name);self.shared=self.root/'canonical';self.control=self.root/'control'
        (self.shared/'requests').mkdir(parents=True);self.control.mkdir()
        self.native=load('native_invented_'+str(id(self)),c.NATIVE)
        self.config={'task_id':'P13','run_id':'invented','split':'official_test','class_count':2,
            'generation':self.native.generation_for(2)}
        self.config_path=self.root/'config.json';self.config_path.write_bytes(self.native.canonical(self.config))
        self.grant=self.root/'grant.json';self.grant.write_text('{}')

    def run_native(self,cases,backend=None,bound=None,rank=0,output=None,concurrency=1):
        output=output or self.root/'shard';output.mkdir(exist_ok=True)
        bound=bound or {'partitions':[[row['case_id'] for row in cases],[],[]],
            'payload_sha256_by_case_key':{hashlib.sha256(row['case_id'].encode()).hexdigest():
                hashlib.sha256(self.native.canonical(self.native.payload(row,self.config))).hexdigest() for row in cases}}
        backend=backend or FakeBackend(self.native,cases,self.shared,{r['case_id']:output for r in cases})
        self.native.count_tokens=lambda *args,**kwargs:{'planned':len(cases),'counts':[]}
        self.native.ThreadPoolExecutor=c.native_executor(self.native,bound,rank,'invented-grant',
            out=self.shared,here=self.control,job_id='invented-job')
        args=SimpleNamespace(resume_unattempted=False,grant=self.grant,model_path='unused',
            context_limit=65536,timeout=900,concurrency=concurrency)
        with patch.object(self.native.urllib.request,'build_opener',return_value=backend):
            self.native.run_locked(args,self.config_path,self.config,cases,self.native.parse_vector,
                {'endpoint':'http://127.0.0.1:1/v1'},{},output)
        return backend,output,bound

    def test_real_native_inner_call_preserves_payload_seed_parser(self):
        cases=invented_cases(2);backend,output,bound=self.run_native(cases)
        self.assertEqual(len(backend.calls),2)
        for row,raw in zip(cases,backend.calls):
            self.assertEqual(raw,self.native.canonical(self.native.payload(row,self.config)))
            key=hashlib.sha256(row['case_id'].encode()).hexdigest()
            claim=c.read(self.control/'claims'/(key+'.json'))
            self.assertTrue(claim['original_native_callable']);self.assertFalse(claim['attempt_replay_authorized'])
            self.assertEqual(c.read(output/'outcomes'/(key+'.json'))['prediction'],[.1,.2])

    def test_dangling_shared_STOP_prevents_all_claims_and_calls(self):
        (self.control/'STOP_INFERENCE').symlink_to(self.control/'missing')
        backend,output,_=self.run_native(invented_cases(2))
        self.assertEqual(backend.calls,[])
        self.assertEqual(list((self.shared/'requests').iterdir()),[])
        self.assertEqual(list((output/'requests').iterdir()),[])

    def test_HTTP_error_propagates_condition_STOP_and_skips_queued_cases(self):
        cases=invented_cases(3);output=self.root/'shard'
        backend=FakeBackend(self.native,cases,self.shared,{row['case_id']:output for row in cases},True)
        self.run_native(cases,backend,output=output)
        self.assertEqual(len(backend.calls),1)
        self.assertTrue(c.present(self.control/'STOP_INFERENCE'))
        self.assertEqual(len(list((self.shared/'requests').iterdir())),1)
        self.assertEqual(c.read(output/'completion.json')['terminal'],1)
        self.assertEqual(c.read(output/'completion.json')['planned'],3)

    def test_existing_original_request_is_never_replayed_or_overwritten(self):
        cases=invented_cases(1);key=hashlib.sha256(cases[0]['case_id'].encode()).hexdigest()
        path=self.shared/'requests'/(key+'.json');path.write_bytes(b'Immutable earlier attempt')
        output=self.root/'shard';backend=FakeBackend(self.native,cases,self.shared,{cases[0]['case_id']:output})
        with self.assertRaises(FileExistsError):self.run_native(cases,backend,output=output)
        self.assertEqual(path.read_bytes(),b'Immutable earlier attempt')
        self.assertEqual(backend.calls,[])

    def test_claim_directory_fsync_failure_prevents_client_call_and_preserves_claim(self):
        cases=invented_cases(1);output=self.root/'shard';backend=FakeBackend(self.native,cases,self.shared,{cases[0]['case_id']:output})
        original=c.sync_directory
        def fail(path):
            if Path(path)==self.shared/'requests':raise OSError('Invented fsync failure')
            return original(path)
        with patch.object(c,'sync_directory',side_effect=fail):
            with self.assertRaises(OSError):self.run_native(cases,backend,output=output)
        self.assertEqual(backend.calls,[])
        self.assertEqual(len(list((self.shared/'requests').iterdir())),1)
        self.assertTrue(c.present(self.control/'STOP_INFERENCE'))

    def test_three_disjoint_native_shards_share_exact_original_claim_namespace(self):
        cases=invented_cases(6);parts=[cases[rank::3] for rank in range(3)]
        bound={'partitions':[[row['case_id'] for row in part] for part in parts],
            'payload_sha256_by_case_key':{hashlib.sha256(row['case_id'].encode()).hexdigest():
                hashlib.sha256(self.native.canonical(self.native.payload(row,self.config))).hexdigest() for row in cases}}
        natives=[load('native_three_'+str(rank),c.NATIVE) for rank in range(3)]
        outputs=[self.root/('shard'+str(rank)) for rank in range(3)]
        local={row['case_id']:outputs[rank] for rank,part in enumerate(parts) for row in part}
        backend=FakeBackend(self.native,cases,self.shared,local)
        def task(rank):
            native=natives[rank];output=outputs[rank];output.mkdir()
            native.count_tokens=lambda *args,**kwargs:{'planned':len(parts[rank]),'counts':[]}
            native.ThreadPoolExecutor=c.native_executor(native,bound,rank,'grant'+str(rank),
                out=self.shared,here=self.control,job_id='invented'+str(rank))
            args=SimpleNamespace(resume_unattempted=False,grant=self.grant,model_path='unused',context_limit=65536,timeout=900,concurrency=2)
            native.run_locked(args,self.config_path,self.config,parts[rank],native.parse_vector,
                {'endpoint':'http://127.0.0.1:1/v1'},{},output)
        with patch.object(self.native.urllib.request,'build_opener',return_value=backend):
            with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
                list(executor.map(task,range(3)))
        self.assertEqual(len(backend.calls),6)
        self.assertEqual(len(list((self.shared/'requests').iterdir())),6)
        self.assertEqual(len(list((self.control/'claims').iterdir())),6)
        for output in outputs:self.assertEqual(c.read(output/'completion.json')['terminal'],2)

    def test_late_allocation_cutoff_creates_no_claim_or_model_call(self):
        cases=invented_cases(1);original=c.native_executor
        def expired(*args,**kwargs):return original(*args,**kwargs,deadline_epoch=1)
        with patch.object(c,'native_executor',side_effect=expired):backend,output,_=self.run_native(cases)
        self.assertEqual(backend.calls,[])
        self.assertEqual(list((self.shared/'requests').iterdir()),[])
        self.assertTrue(c.present(self.control/'STOP_INFERENCE'))


class BoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.out=Path(self.temporary.name)
        for category in ['requests','responses','outcomes','errors']:(self.out/category).mkdir()
        self.native=load('native_boundary_'+str(id(self)),c.NATIVE)
        self.cases=invented_cases(3416)
        self.config={'class_count':2,'generation':self.native.generation_for(2)}
        self.keys=[hashlib.sha256(row['case_id'].encode()).hexdigest() for row in self.cases]
        patcher=patch.object(c,'HISTORICAL_INVALID_KEYS',frozenset(self.keys[:4]));patcher.start();self.addCleanup(patcher.stop)
        for index in range(5):
            key=self.keys[index];case=self.cases[index]
            request=self.out/'requests'/(key+'.json');request.write_bytes(self.native.canonical(self.native.payload(case,self.config)))
            if index<4:
                row={'case_id':case['case_id'],'status':'ambiguous_attempt_not_retried','delivery_passed':False}
            else:
                body={'model':self.native.MODEL,'choices':[{'finish_reason':'stop','message':{'content':'{"scores":[0.1,0.2]}'}}]}
                response=self.out/'responses'/(key+'.json');response.write_bytes(self.native.canonical(body))
                row={'case_id':case['case_id'],'status':'response_saved','response_saved':True,
                    'request_sha256':c.sha(request),'response_sha256':c.sha(response),**self.native.parse_delivery(body,2)}
            (self.out/'outcomes'/(key+'.json')).write_bytes(self.native.canonical(row))
        for name in ['run_manifest.json','tokenizer_preflight.json']:(self.out/name).write_text('{}')
        (self.out/'progress.json').write_bytes(c.canonical({'planned':3416,'responses_saved':1,'terminal':5,
            'attempted_confirmed':5,'not_dispatched':3411,'ambiguous_attempts':4,'config_sha256':c.CONFIG_SHA}))

    def test_original_order_partitions_are_disjoint_exhaustive_and_invalids_preserved(self):
        bound=c.boundary(self.native,self.config,self.cases,self.out)
        self.assertEqual(bound['untouched_case_ids'],[row['case_id'] for row in self.cases[5:]])
        self.assertEqual(bound['partitions'],[bound['untouched_case_ids'][rank::3] for rank in range(3)])
        self.assertEqual(len(set(x for part in bound['partitions'] for x in part)),3411)
        self.assertEqual(bound['historical_invalid_keys'],sorted(self.keys[:4]))

    def test_outstanding_original_request_blocks_terminal_boundary(self):
        row=self.cases[5];key=self.keys[5]
        (self.out/'requests'/(key+'.json')).write_bytes(self.native.canonical(self.native.payload(row,self.config)))
        with self.assertRaisesRegex(ValueError,'In-flight'):c.boundary(self.native,self.config,self.cases,self.out)

    def test_saved_parser_flag_tamper_is_rejected_by_original_parser(self):
        path=self.out/'outcomes'/(self.keys[4]+'.json');row=c.read(path);row['prediction']=[.9,.9];path.write_bytes(c.canonical(row))
        with self.assertRaisesRegex(ValueError,'interpretation'):c.boundary(self.native,self.config,self.cases,self.out)

    def test_foreign_case_artifact_rejected(self):
        (self.out/'requests'/('f'*64+'.json')).write_text('{}')
        with self.assertRaisesRegex(ValueError,'outside'):c.boundary(self.native,self.config,self.cases,self.out)

    def test_orphan_response_rejected(self):
        (self.out/'responses'/(self.keys[5]+'.json')).write_text('{}')
        with self.assertRaisesRegex(ValueError,'without'):c.boundary(self.native,self.config,self.cases,self.out)

    def test_changed_historical_source_cannot_be_merged(self):
        bound=c.boundary(self.native,self.config,self.cases,self.out)
        (self.out/'requests'/(self.keys[0]+'.json')).write_text('Changed')
        with self.assertRaisesRegex(ValueError,'Historical'):c.verify_historical(bound,self.out)


class PermissionAndGateTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name);self.out=self.root/'out';(self.out/'requests').mkdir(parents=True)
        (self.out/'requests').chmod(0o700)
        self.patcher=patch.object(op.c,'OUT',self.out);self.patcher.start();self.addCleanup(self.patcher.stop)
        self.m={'requests_inode':(self.out/'requests').stat().st_ino}
        self.receipt=self.root/'drain_receipt.json'

    def test_owned_directory_drain_and_restore_preserve_bytes(self):
        path=self.out/'requests'/'invented.txt';path.write_bytes(b'Original bytes')
        op.directory_change(self.m,0o700,0o500,self.receipt,lambda:None)
        self.assertEqual((self.out/'requests').stat().st_mode&0o777,0o500)
        # Persisted device identity from another namespace does not gate current descriptor identity.
        self.m['predecessor_namespace_device']=(self.out/'requests').stat().st_dev+100
        op.directory_change(self.m,0o500,0o700,self.root/'restore.json',lambda:None)
        self.assertEqual(path.read_bytes(),b'Original bytes')
        self.assertFalse(c.read(self.receipt)['active_model_calls_interrupted'])

    def test_claim_fsync_failure_does_not_change_live_directory_mode(self):
        with patch.object(op.c,'sync_directory',side_effect=OSError('Invented fsync failure')):
            with self.assertRaises(OSError):op.directory_change(self.m,0o700,0o500,self.receipt,lambda:None)
        self.assertEqual((self.out/'requests').stat().st_mode&0o777,0o700)

    def test_final_prerequisite_failure_prevents_mode_change(self):
        prerequisite=Mock(side_effect=[None,ValueError('New STOP')])
        with self.assertRaises(ValueError):op.directory_change(self.m,0o700,0o500,self.receipt,prerequisite)
        self.assertEqual((self.out/'requests').stat().st_mode&0o777,0o700)

    def test_changed_frozen_pin_blocks_drain_before_fchmod(self):
        args=SimpleNamespace(manifest='invented',manifest_sha256='invented',
            source_admission_sha256='invented',runtime_admission_sha256='invented')
        with patch.object(op.c,'bind',side_effect=ValueError('Changed pinned source')), \
                patch.object(op.os,'fchmod') as chmod,patch.object(op.subprocess,'run') as scheduler:
            with self.assertRaises(ValueError):
                op.directory_change(self.m,0o700,0o500,self.receipt,lambda:op.drain_prerequisite(self.m,args))
            chmod.assert_not_called();scheduler.assert_not_called()
        self.assertFalse(self.receipt.exists())

    def test_changed_frozen_pin_blocks_restoration_before_scheduler_or_mode_change(self):
        args=SimpleNamespace(manifest='invented',manifest_sha256='invented',
            source_admission_sha256='invented',runtime_admission_sha256='invented')
        (self.out/'requests').chmod(0o500)
        with patch.object(op.c,'bind',side_effect=ValueError('Changed pinned source')), \
                patch.object(op.os,'fchmod') as chmod,patch.object(op.subprocess,'run') as scheduler:
            with self.assertRaises(ValueError):
                op.directory_change(self.m,0o500,0o700,self.receipt,
                    lambda:op.restore_prerequisite(self.m,args,'invented','invented'))
            chmod.assert_not_called();scheduler.assert_not_called()
        self.assertEqual((self.out/'requests').stat().st_mode&0o777,0o500)

    def test_wrong_inode_rejected_before_drain(self):
        with self.assertRaises(ValueError):op.directory_change({'requests_inode':-1},0o700,0o500,self.receipt,lambda:None)
        self.assertFalse(self.receipt.exists())

    def test_regular_file_cannot_be_used_as_requests_directory(self):
        path=self.root/'file';path.write_text('ordinary')
        with self.assertRaises(ValueError):op.owned_directory(path,path.stat().st_ino,0o600)

    def test_intermediate_symlink_directory_is_rejected(self):
        (self.root/'linked').symlink_to(self.out,target_is_directory=True)
        with self.assertRaises(ValueError):op.owned_directory(self.root/'linked/requests',self.m['requests_inode'],0o700)

    def test_existing_original_score_attempt_never_calls_native_or_scheduler(self):
        base=self.root/'base';(base/'control').mkdir(parents=True)
        (base/'control/P13_scoring_status.json').write_text('{"stage":"one_attempt_started"}')
        with patch.object(op.c,'BASE',base),patch.object(op.c,'module') as native,patch.object(op.subprocess,'run') as run:
            with self.assertRaises(ValueError):op.score({},None,'unused','unused')
            native.assert_not_called();run.assert_not_called()

    def test_STOP_arriving_at_final_score_bind_creates_no_irreversible_score_claim(self):
        control=self.root/'score-control';control.mkdir()
        (control/'submission_rank0.json').write_text('{"job_id":"invented-job"}')
        runtime=control/'replicas/0/runtime';runtime.mkdir(parents=True)
        (runtime/'job_identity.json').write_bytes(c.canonical({'end_time':'invented-end','deadline_epoch':time.time()+7200}))
        base=self.root/'score-base';(base/'control').mkdir(parents=True)
        args=SimpleNamespace(manifest='invented',manifest_sha256='invented',
            source_admission_sha256='invented',runtime_admission_sha256='invented')
        fields='JobId=invented-job JobState=RUNNING UserId=dongweij(26129) WorkDir='+str(op.c.ROOT)+' Command='+str(control/'replica.sbatch')+' EndTime=invented-end'
        def stop_at_bind(*args):
            (control/'STOP_INFERENCE').write_text('Invented concurrent stop')
            return {}
        with patch.object(op,'HERE',control),patch.object(op.c,'BASE',base), \
                patch.object(op.c,'module',return_value=SimpleNamespace(verify_locked_generation=Mock())), \
                patch.object(op.c,'bind',side_effect=stop_at_bind), \
                patch.object(op.subprocess,'run',return_value=SimpleNamespace(stdout=fields)) as run:
            with self.assertRaisesRegex(ValueError,'irreversible'):op.score({'scorer':'invented'},args,'boundary','admission')
            self.assertEqual(run.call_count,1)  # Only mocked read-only scontrol, never srun/scorer.
        self.assertFalse((base/'control/P13_scoring_status.json').exists())

    def test_dangling_completion_path_is_already_claimed(self):
        (self.out/'completion.json').symlink_to(self.root/'missing')
        with self.assertRaises(ValueError):c.check_no_score_or_seal(self.out)


class StaticScienceTests(unittest.TestCase):
    def test_three_pool_plans_change_only_operational_paths_and_client_count(self):
        old=c.read(c.BASE/'continuation_v3/pool_plan.json')
        allowed={'port','endpoint','queue_root','max_simultaneous_clients','allowed_runner_paths','purpose'}
        for rank in range(3):
            new=c.read(HERE/('pool_plan_rank'+str(rank)+'.json'))
            self.assertEqual({k:v for k,v in old.items() if k not in allowed},{k:v for k,v in new.items() if k not in allowed})
            self.assertEqual(new['gpus_requested'],1)
            self.assertEqual(new['vllm']['tensor_parallel_size'],1)
            self.assertNotEqual(new['port'],old['port'])

    def test_frozen_native_sampling_dict_and_source_bytes_are_preserved(self):
        native=load('native_static_science',c.NATIVE)
        self.assertEqual(c.sha(c.NATIVE),c.NATIVE_SHA)
        self.assertEqual(c.sha(c.CONFIG),c.CONFIG_SHA)
        self.assertEqual(c.read(c.CONFIG)['generation'],native.generation_for(1943))
        self.assertEqual(native.generation_for(1943)['seed'],42)

    def test_copy_exact_rejects_existing_or_changed_destination(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);source=root/'source';dest=root/'dest';source.write_bytes(b'Invented bytes')
            c.copy_exact(source,dest,c.sha(source));self.assertEqual(dest.read_bytes(),source.read_bytes())
            with self.assertRaises(ValueError):c.copy_exact(source,dest,c.sha(source))


class FullCanonicalMergeTests(unittest.TestCase):
    """Realistic3416 invented artifacts, four immutable ambiguities and three new calls."""
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.control=self.root/'control';self.control.mkdir()
        self.out=self.root/'canonical'
        for category in ('requests','responses','outcomes','errors'):(self.out/category).mkdir(parents=True)
        self.native=load('native_fullmerge_'+str(id(self)),c.NATIVE)
        self.cases=invented_cases(3416)
        self.config={'task_id':'P13','run_id':'invented','generation':self.native.generation_for(2),'class_count':2}
        self.config_path=self.root/'config.json';self.config_path.write_bytes(c.canonical(self.config))
        self.base=self.root/'base';(self.base/'control').mkdir(parents=True)
        for obj,key,value in [(op,'HERE',self.control),(op.c,'OUT',self.out),(op.c,'BASE',self.base),(op.c,'CONFIG',self.config_path)]:
            patcher=patch.object(obj,key,value);patcher.start();self.addCleanup(patcher.stop)
        response={'model':self.native.MODEL,'choices':[{'finish_reason':'stop','message':{'content':'{"scores":[0.1,0.2]}'}}]}
        self.payloads={}
        def write_case(folder,case,invalid=False):
            key=hashlib.sha256(case['case_id'].encode()).hexdigest()
            raw=self.native.canonical(self.native.payload(case,self.config))
            (folder/'requests'/(key+'.json')).write_bytes(raw);self.payloads[key]=hashlib.sha256(raw).hexdigest()
            if invalid:row={'case_id':case['case_id'],'status':'ambiguous_attempt_not_retried','delivery_passed':False}
            else:
                path=folder/'responses'/(key+'.json');path.write_bytes(c.canonical(response))
                row={'case_id':case['case_id'],'status':'response_saved','response_saved':True,
                    'request_sha256':hashlib.sha256(raw).hexdigest(),'response_sha256':c.sha(path),
                    **self.native.parse_delivery(response,2)}
            (folder/'outcomes'/(key+'.json')).write_bytes(c.canonical(row))
            return key
        for index,case in enumerate(self.cases[:3413]):write_case(self.out,case,index<4)
        for name in ('run_manifest.json','tokenizer_preflight.json'):(self.out/name).write_text('{}')
        self.historical={str(path.relative_to(self.out)):c.sha(path) for path in self.out.rglob('*') if path.is_file()}
        self.parts=[[row['case_id']] for row in self.cases[3413:]]
        (self.control/'boundary.json').write_text('{"invented_boundary":true}')
        bsha=c.sha(self.control/'boundary.json')
        for rank,case in enumerate(self.cases[3413:]):
            folder=self.control/'replicas'/str(rank)/'output';runtime=folder.parent/'runtime';runtime.mkdir(parents=True)
            for category in ('requests','responses','outcomes','errors'):(folder/category).mkdir(parents=True)
            (folder/'.runner.lock').write_bytes(b'')
            key=write_case(folder,case)
            # This is the pre-call shared canonical request, not a merge-created attempt.
            (self.out/'requests'/(key+'.json')).write_bytes((folder/'requests'/(key+'.json')).read_bytes())
            claim=self.control/'claims'/(key+'.json');claim.parent.mkdir(exist_ok=True)
            claim.write_bytes(c.canonical({'rank':rank,'grant_sha256':'invented-grant'+str(rank),'request_sha256':self.payloads[key]}))
            for name in ('run_manifest.json','tokenizer_preflight.json'):(folder/name).write_text('{}')
            files={str(path.relative_to(folder)):c.sha(path) for path in folder.rglob('*') if path.is_file() and path.name!='.runner.lock'}
            (folder/'prediction_lock.json').write_bytes(c.canonical({'files_sha256':files,'reference_labels_opened':False,'config_sha256':c.CONFIG_SHA}))
            (folder/'completion.json').write_bytes(c.canonical({'config_sha256':c.CONFIG_SHA,'planned':1,'terminal':1}))
            (runtime/'partition_terminal.json').write_bytes(c.canonical({'manifest_sha256':'invented-manifest','boundary_sha256':bsha,
                'planned':1,'terminal':1,'grant_sha256':'invented-grant'+str(rank),
                'prediction_lock_sha256':c.sha(folder/'prediction_lock.json'),'completion_sha256':c.sha(folder/'completion.json')}))
        self.bound={'historical_files_sha256':self.historical,'partitions':self.parts,'payload_sha256_by_case_key':self.payloads}
        self.args=SimpleNamespace(manifest_sha256='invented-manifest')

    def test_full3416_merge_preserves_four_old_invalids_and_every_original_byte(self):
        op.merge(self.bound,self.args)
        done=c.read(self.out/'completion.json');lock=c.read(self.out/'prediction_lock.json')
        self.assertEqual(done['planned'],3416);self.assertEqual(done['terminal'],3416)
        self.assertEqual(done['responses_saved'],3412);self.assertEqual(done['ambiguous_attempts'],4)
        self.assertFalse(done['all_passed']);self.assertFalse(done['biological_correctness_assessed'])
        self.assertFalse(lock['reference_labels_opened']);self.assertEqual(len(lock['files_sha256']),10246)
        for name,digest in self.historical.items():self.assertEqual(c.sha(self.out/name),digest)
        self.assertFalse((self.out/'scores.json').exists())

    def test_changed_shared_request_blocks_full_seal_before_native_scoring(self):
        case=self.cases[-1];key=hashlib.sha256(case['case_id'].encode()).hexdigest()
        (self.out/'requests'/(key+'.json')).write_bytes(b'Changed payload')
        with self.assertRaisesRegex(ValueError,'payload'):op.merge(self.bound,self.args)
        self.assertFalse((self.out/'completion.json').exists());self.assertFalse((self.out/'scores.json').exists())

    def test_foreign_partition_lock_member_is_rejected(self):
        folder=self.control/'replicas/0/output';path=folder/'prediction_lock.json';value=c.read(path)
        value['files_sha256']['../foreign.json']='invented';path.write_bytes(c.canonical(value))
        with self.assertRaisesRegex(ValueError,'traversal'):op.merge(self.bound,self.args)
        self.assertFalse((self.out/'completion.json').exists())


class ResourceTests(unittest.TestCase):
    def test_false_or_contradictory_capacity_never_passes(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);blob=root/'blob.json';blob.write_text('{}')
            ref={'path':str(blob),'sha256':c.sha(blob)}
            binding={'resource_adapter':ref,'root_authorization':ref,'additional_root_proofs':[ref], 'additional_proof_binding':ref}
            p=root/'binding.json';p.write_bytes(c.canonical(binding))
            manifest={'resource_binding':str(p),'resource_binding_sha256':c.sha(p)}
            healthy={'project_requested_GPUs':5,'project_requested_GPUs_with_addition':6,
                'additional_GPUs':1,'project_GPU_ceiling':8,'capacity_available':True}
            adapter=SimpleNamespace(capacity_audit=Mock(return_value=healthy))
            with patch.object(c,'module',return_value=adapter):
                self.assertEqual(c.require_capacity(manifest,1,False),healthy)
                adapter.capacity_audit.assert_called_with(additional=1,override=False,require_own_job=False,
                    additional_root_proofs=[ref],additional_proof_binding=ref)
                for changes in [{'capacity_available':False},{'project_requested_GPUs_with_addition':9},
                                {'additional_GPUs':0},{'project_GPU_ceiling':9},{'project_requested_GPUs':None}]:
                    adapter.capacity_audit.return_value=dict(healthy,**changes)
                    with self.subTest(changes=changes),self.assertRaises(BlockingIOError):c.require_capacity(manifest,1,False)


if __name__=='__main__':
    unittest.main()
