"""Finite CPU assembly of the exact full3416 score and complete parallel provenance.

No model calls, target values, scoring, automatic upload, or shared-report edits.
"""
import argparse
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tarfile
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('P13_parallel_publication_common',HERE/'common.py')
c = importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
STAGE = HERE/'publication_stage'


def main():
    parser = argparse.ArgumentParser()
    for name in ['manifest','manifest-sha256','source-admission-sha256','runtime-admission-sha256',
                 'boundary-sha256','boundary-admission-sha256']:
        parser.add_argument('--'+name,required=True)
    args = parser.parse_args()
    m = c.bind(args.manifest,args.manifest_sha256,args.source_admission_sha256,args.runtime_admission_sha256)
    bound = c.bind_boundary(args.manifest_sha256,args.boundary_sha256,args.boundary_admission_sha256)
    c.verify_historical(bound)
    closed = c.read(HERE/'FINAL_NATIVE_CLOSED.json')
    state = c.read(c.BASE/'control/P13_scoring_status.json')
    score = c.read(c.OUT/'scores.json');score_sha = c.sha(c.OUT/'scores.json')
    lock_sha = c.sha(c.OUT/'prediction_lock.json')
    if (state.get('stage') != 'completed' or state.get('score_sha256') != score_sha
            or closed.get('score_path') != str(c.OUT/'scores.json') or closed.get('score_sha256') != score_sha
            or closed.get('prediction_lock_sha256') != lock_sha
            or closed.get('planned') != 3416 or closed.get('terminal') != 3416
            or score.get('config_sha256') != c.CONFIG_SHA or score.get('planned') != 3416
            or score.get('prediction_lock_sha256') != lock_sha
            or score.get('predictions_locked_before_reference_read') is not True
            or score.get('full_planned_primary_metrics_valid') is not False
            or score.get('metrics') != {'auprc@micro':None,'f1_max':None}):
        raise ValueError('Require exact full original once-native closure/undefined-primary policy')
    c.create(HERE/'publication_assembly_claim.json',{'at_pacific':c.stamp(),
        'manifest_sha256':args.manifest_sha256,'boundary_sha256':args.boundary_sha256,
        'score_sha256':score_sha,'prediction_lock_sha256':lock_sha,
        'closed_receipt_sha256':c.sha(HERE/'FINAL_NATIVE_CLOSED.json'),'new_model_or_score_calls':0})
    if STAGE.exists():
        raise ValueError('Prior publication stage preserved; no silent assembly replay')
    deadline = time.monotonic()+1800
    while not all((HERE/'replicas'/str(rank)/'runtime/cleanup.json').exists() for rank in range(3)):
        if time.monotonic()>deadline:
            raise TimeoutError('Owned model cleanup metadata not observed')
        time.sleep(5)
    native = c.module(m['scorer'],'P13_parallel_publication_native_pre_reference_verifier')
    verified = native.verify_locked_generation(c.CONFIG,c.OUT)
    if c.read(c.OUT/'scores.per_case.json') != verified[3]:
        raise ValueError('Per-case score differs from original strict native interpretation')
    helpers = c.module(m['publication_archive_helper'],'P13_reviewed_publication_archive_helpers')
    scanner = c.module(m['secret_scanner'],'P13_frozen_secret_scanner')
    config = c.read(c.CONFIG);target = c.ROOT/config['scorer_reference_file']
    originals = {}
    def add(name,path,digest):
        path = Path(path)
        helpers.permitted_source(name,path,target,c.ROOT)
        if name in originals or c.sha(path) != digest:
            raise ValueError('Duplicate/changed explicit archive source')
        scanner.scan_file(path)
        originals[name] = {'path':str(path),'sha256':digest,'bytes':path.stat().st_size}
    inherited_path = Path(m['historical_publication_contract'])
    if c.sha(inherited_path) != m['historical_publication_contract_sha256']:
        raise ValueError('Historical explicit108-source contract changed')
    inherited = c.read(inherited_path)
    for name,row in inherited['sources'].items():
        add('history/'+name,c.ROOT/row['path'],row['sha256'])
    add('history/publication/source_contract.json',inherited_path,m['historical_publication_contract_sha256'])
    for name in ['common.py','runtime.py','coordinator.py','publication.py','prepare_manifest.py','test_parallel.py','test_recovery.py','replica.sbatch','supervisor.sbatch',
                 'pool_plan_rank0.json','pool_plan_rank1.json','pool_plan_rank2.json',
                 'private_python_bootstrap_reproduction.json','source_delta_summary.json',
                 'root_replacement_scope_proposed.json','independent_zero_delivery_support.json']:
        add('parallel/source/'+name,HERE/name,m['files_sha256'][str(HERE/name)])
    add('parallel/source/manifest.json',args.manifest,args.manifest_sha256)
    add('parallel/source/root_operational_scope.json',m['root_scope'],m['root_scope_sha256'])
    add('parallel/source/standing_root_authorization.json',m['standing_root_authorization'],m['standing_root_authorization_sha256'])
    add('parallel/recovery/zero_delivery_evidence.json',m['zero_delivery_evidence'],m['zero_delivery_evidence_sha256'])
    add('parallel/recovery/original_parallel_boundary.json',m['parent_boundary'],m['parent_boundary_sha256'])
    for path,digest in c.read(m['zero_delivery_evidence'])['files_sha256'].items():
        if path == str(c.OUT/'progress.json'):
            continue  # dated live progress is captured by immutable preserved_old_progress below
        add('parallel/recovery/previous_attempt/'+str(Path(path).relative_to(c.BASE/'P13_parallel_20261024_v1')),path,digest)
    resource = c.read(m['resource_binding'])
    add('parallel/source/resource_configuration.json',m['resource_binding'],m['resource_binding_sha256'])
    add('parallel/source/resource_adapter_v5.py',resource['resource_adapter']['path'],resource['resource_adapter']['sha256'])
    for name,digest in [('engineering_admission.json',args.source_admission_sha256),
                        ('runtime_admission.json',args.runtime_admission_sha256),
                        ('boundary.json',args.boundary_sha256),('boundary_admission.json',args.boundary_admission_sha256)]:
        add('parallel/closure/'+name,HERE/name,digest)
    for name in ['operator_claim.json','cpu_submission_claim.json','cpu_submission_receipt.json','zero_delivery_recovery_start.json','old_terminal_receipt.json',
                 'quiescent_lock_handoff_receipt.json','preserved_old_progress.json',
                 'merge_claim.json','merge_receipt.json',
                 'FINAL_NATIVE_CLOSED.json']:
        add('parallel/closure/'+name,HERE/name,c.sha(HERE/name))
    for path in sorted((HERE/'claims').glob('*.json')):
        add('parallel/shared_original_request_claims/'+path.name,path,c.sha(path))
    for rank in range(3):
        replica = HERE/'replicas'/str(rank);runtime = replica/'runtime';output = replica/'output'
        for name in ['submission_claim_rank'+str(rank)+'.json','submission_rank'+str(rank)+'.json']:
            add('parallel/dispatch/'+name,HERE/name,c.sha(HERE/name))
        for name in ['runtime_version_manifest.json','execution_started.json','server_identity.json','job_identity.json',
                     'synthetic_delivery.json','partition_terminal.json','cleanup.json',
                     'queue/P13_partition.grant.json','queue/P13_partition.started.json','queue/P13_partition.finished.json']:
            add('parallel/replica'+str(rank)+'/runtime/'+name,runtime/name,c.sha(runtime/name))
        if c.read(runtime/'cleanup.json').get('owned_processes_only') is not True:
            raise ValueError('Unverified replica process cleanup')
        seal = c.read(output/'prediction_lock.json')
        for name,digest in seal['files_sha256'].items():
            if not helpers.permitted_runtime_member(name):
                raise ValueError('Unapproved partition trajectory member')
            add('parallel/replica'+str(rank)+'/output/'+name,output/name,digest)
        for name in ['completion.json','prediction_lock.json']:
            add('parallel/replica'+str(rank)+'/output/'+name,output/name,c.sha(output/name))
    full_lock = c.read(c.OUT/'prediction_lock.json')
    for name,digest in full_lock['files_sha256'].items():
        if not helpers.permitted_runtime_member(name):
            raise ValueError('Unapproved canonical trajectory member')
        add('runtime/benchmark/'+name,c.OUT/name,digest)
    for name in ['completion.json','prediction_lock.json','scores.json','scores.per_case.json']:
        add('runtime/benchmark/'+name,c.OUT/name,c.sha(c.OUT/name))
    development = c.BASE/'tasks/P13/runtime/development'
    development_lock = c.read(development/'prediction_lock.json')
    development_completion = c.read(development/'completion.json')
    initial_grant = c.read(c.BASE/'runtime/queue/10_P13_benchmark.grant.json')
    if (development_completion['prediction_lock_sha256'] != c.sha(development/'prediction_lock.json')
            or development_completion['planned'] != development_completion['terminal']
            or development_completion.get('biological_correctness_assessed') is not False
            or initial_grant['development_completion_sha256'] != c.sha(development/'completion.json')):
        raise ValueError('Original unscored development gate differs')
    for name,digest in development_lock['files_sha256'].items():
        if not helpers.permitted_runtime_member(name):
            raise ValueError('Unapproved development trajectory member')
        add('runtime/development/'+name,development/name,digest)
    for name in ['completion.json','prediction_lock.json']:
        add('runtime/development/'+name,development/name,c.sha(development/name))
    add('control/P13_scoring_status.json',c.BASE/'control/P13_scoring_status.json',c.sha(c.BASE/'control/P13_scoring_status.json'))
    run = m['run_id'];prefix = 'results/runs/'+run+'/'
    archive_prefix = 'results/trajectory_archives/'+run
    inventory = {}
    groups = helpers.group_parts(helpers.split_members(originals))
    for number,rows in enumerate(groups,1):
        filename = archive_prefix+'.part'+str(number).zfill(3)+'.tar.gz'
        path = STAGE/filename;path.parent.mkdir(parents=True,exist_ok=True)
        members = {}
        with tarfile.open(path,'w:gz') as archive:
            for row in rows:
                with Path(row['path']).open('rb') as stream:
                    stream.seek(row['offset']);raw = stream.read(row['bytes'])
                if len(raw) != row['bytes']:
                    raise ValueError('Truncated captured source')
                scanner.scan_bytes(raw)
                info = tarfile.TarInfo(row['archive_name']);info.size=len(raw);info.mode=0o600
                archive.addfile(info,io.BytesIO(raw))
                members[info.name] = {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
                    'original_member_name':row['original_member_name'],'original_sha256':row['sha256'],
                    'original_bytes':row['original_bytes'],'byte_offset':row['offset']}
        if path.stat().st_size >= 90*1024**2:
            raise ValueError('Compressed Git archive exceeds90MiB')
        scanner.scan_file(path)
        inventory[filename] = {'sha256':c.sha(path),'uncompressed_bytes':sum(row['bytes'] for row in members.values()),'members':members}
    helpers.verify_reconstruction(STAGE,inventory,originals);helpers.recheck_originals(originals)
    archive_manifest = {'task_id':'P13','run_id':run,'parts':inventory,'original_sources':originals,
        'score_sha256':score_sha,'prediction_lock_sha256':lock_sha,'manifest_sha256':args.manifest_sha256,
        'full_original_hashes_reconstructed_and_verified':True,'originals_rechecked_after_capture':True,
        'scorer_target_values_included':False,'weights_credentials_and_full_account_audits_included':False}
    c.create(STAGE/(archive_prefix+'.manifest.json'),archive_manifest)
    for name in ['completion.json','prediction_lock.json','scores.json']:
        c.copy_exact(c.OUT/name,STAGE/(prefix+name),c.sha(c.OUT/name))
    result = {'task_id':'P13','run_id':run,'planned':3416,'parsed':score['parsed'],
        'invalid_or_missing':score['invalid_or_missing'],'metrics':score['metrics'],
        'full_planned_primary_metrics_valid':False,'historical_ambiguous_attempts_preserved_invalid':4,
        'same_scientific_payloads_seeds_and_recipe':True,'partition_replica_count':3,
        'score_sha256':score_sha,'prediction_lock_sha256':lock_sha,'new_assembly_model_or_score_calls':0}
    c.create(STAGE/(prefix+'result.json'),result)
    case = verified[1][0];key = hashlib.sha256(case['case_id'].encode()).hexdigest()
    request = c.read(c.OUT/'requests'/(key+'.json'))
    if request != native.payload(case,config) or c.sha(c.OUT/'requests'/(key+'.json')) != full_lock['files_sha256']['requests/'+key+'.json']:
        raise ValueError('Original evaluated request changed')
    question = ('# DeepFRI / ProtST: biological process — complete evaluated input\n\n'
        'Verbatim saved user message, including the complete protein sequence and 1,943 fixed GO descriptions. '
        'Reference targets and model answer are excluded.\n\n```text\n'+request['messages'][0]['content']+'\n```\n').encode()
    c.create(STAGE/'reports/questions/P13_dense_confidence_v1.md',question,raw=True)
    report = ('# DeepFRI / ProtST: biological-process annotation\n\n'
        'Qwen3.8-27B BF16 reached terminal closure for all 3,416 released test95 cases. '
        +str(score['parsed'])+' valid confidence vectors; '+str(score['invalid_or_missing'])+' invalid or missing.\n\n'
        'Micro AUPRC and Fmax: **undefined under the native all-case policy**. Four historical ambiguous attempts remain invalid; '
        'they were preserved without retries or omission. No valid-only replacement score is reported.\n\n'
        '[Complete evaluated input](questions/P13_dense_confidence_v1.md). One generation per case with seed 42, nonthinking mode, '
        '16,384 maximum output tokens and the fixed ordered three-decimal confidence vector. Operational continuations and three '
        'disjoint whole-model replicas preserved the original payload bytes, model/revision/BF16, sampling and all 3,416 cases.\n\n'
        'Native TorchDrug micro AUPRC/Fmax formulas and float32 tie ordering are preserved. This zero-shot full-FASTA text adaptation '
        'differs from trained DeepFRI/ProtST representations and the paper’s PDB-modeled/cropped inputs. '
        '[DeepFRI (2021)](https://doi.org/10.1038/s41467-021-23303-9); '
        '[ProtST (2023)](https://proceedings.mlr.press/v202/xu23t.html). Explanation support is unassessed; pretraining exposure is unknown.\n').encode()
    c.create(STAGE/'reports/P13_BP_DENSE_CONFIDENCE_RESULT.md',report,raw=True)
    files = {str(path.relative_to(STAGE)):c.sha(path) for path in STAGE.rglob('*') if path.is_file()}
    for name in files:
        scanner.scan_file(STAGE/name)
    c.create(HERE/'publication_manifest.json',{'at_pacific':c.stamp(),'task_id':'P13','run_id':run,
        'owner':'/root/deepfri_p13_completion','repository':'Some-random/bio-evaluation','visibility':'public',
        'stage_path':str(STAGE),'files_sha256':files,'score_sha256':score_sha,'prediction_lock_sha256':lock_sha,
        'parallel_manifest_sha256':args.manifest_sha256,'planned':3416,'parsed':score['parsed'],'metrics':score['metrics'],
        'new_model_calls':0,'new_scoring_calls':0,'aggregate_documents_modified':False,
        'automatic_publication':False,'independent_exact_publication_review_required':True,
        'captured_original_full_hashes_verified':True,'original_sources_rechecked_after_capture':True,'scans_passed':True})
    print(json.dumps({'stage':'assembled_for_exact_independent_review','path_count':len(files),'archive_parts':len(groups),
        'publication_manifest_sha256':c.sha(HERE/'publication_manifest.json')}))


if __name__=='__main__':
    main()
