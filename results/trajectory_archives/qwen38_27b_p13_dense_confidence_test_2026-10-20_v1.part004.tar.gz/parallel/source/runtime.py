"""One admitted TP1 replica, unchanged native calls, or original once-only CPU scorer."""
import argparse
from datetime import datetime
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import sys
import threading
import time
import subprocess
from types import SimpleNamespace
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('P13_parallel_common',HERE/'common.py')
c = importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def parser():
    result = argparse.ArgumentParser()
    result.add_argument('--mode',choices=('pool','worker','score'),required=True)
    result.add_argument('--manifest',type=Path,required=True)
    result.add_argument('--manifest-sha256',required=True)
    result.add_argument('--source-admission-sha256',required=True)
    result.add_argument('--runtime-admission-sha256',required=True)
    result.add_argument('--boundary-sha256',required=True)
    result.add_argument('--boundary-admission-sha256',required=True)
    result.add_argument('--rank',type=int,choices=range(3),required=True)
    result.add_argument('--config',type=Path,default=c.CONFIG)
    result.add_argument('--grant',type=Path)
    return result


def bind(args):
    if not sys.flags.safe_path or os.environ.get('PYTHONSAFEPATH') != '1':
        raise ValueError('Safe fresh interpreter entry is required before runtime/source access')
    m = c.bind(args.manifest,args.manifest_sha256,args.source_admission_sha256,args.runtime_admission_sha256)
    bound = c.bind_boundary(args.manifest_sha256,args.boundary_sha256,args.boundary_admission_sha256)
    if args.config != c.CONFIG or c.sha(args.config) != c.CONFIG_SHA:
        raise ValueError('Original scientific configuration required')
    registration_path = HERE/('submission_rank'+str(args.rank)+'.json')
    limit = time.monotonic()+60
    while not registration_path.exists() and time.monotonic()<limit:
        time.sleep(1)
    registration = c.read(registration_path)
    if (registration['job_id'] != os.environ.get('SLURM_JOB_ID')
            or registration['manifest_sha256'] != args.manifest_sha256
            or registration['boundary_sha256'] != args.boundary_sha256):
        raise ValueError('Actual replica allocation differs')
    c.original_terminal()
    c.recovery_predecessors(m)
    c.verify_historical(bound)
    return m,bound


def grant(args,m,bound,identity,runtime):
    entry = c.read(m['dispatch_plan'])['tasks']
    entry = next(value for value in entry if value['task_id']=='P13')
    development = c.BASE/'tasks/P13/runtime/development/completion.json'
    path = runtime/'queue/P13_partition.grant.json'
    value = {'authorized':True,'task_id':'P13','run_id':m['run_id'],'phase':'benchmark',
        'runner':str(HERE/'runtime.py'),'runner_sha256':c.sha(HERE/'runtime.py'),
        'config':str(c.CONFIG),'config_sha256':c.CONFIG_SHA,'endpoint':identity['endpoint'],
        'server_identity_file':str(runtime/'server_identity.json'),
        'server_identity_sha256':c.sha(runtime/'server_identity.json'),
        'development_completion':str(development),'development_completion_sha256':c.sha(development),
        'rank':args.rank,'partition_case_count':len(bound['partitions'][args.rank]),
        'boundary_sha256':args.boundary_sha256,'historical_attempts_never_retried':True,
        'argv':['--mode','worker','--manifest',str(args.manifest),'--manifest-sha256',args.manifest_sha256,
            '--source-admission-sha256',args.source_admission_sha256,
            '--runtime-admission-sha256',args.runtime_admission_sha256,
            '--boundary-sha256',args.boundary_sha256,
            '--boundary-admission-sha256',args.boundary_admission_sha256,
            '--rank',str(args.rank),'--config',str(c.CONFIG),'--grant',str(path)]}
    c.create(path,value)


def worker(args,m,bound):
    if c.present(HERE/'STOP_INFERENCE'):
        raise ValueError('Condition-wide inference stop')
    native = c.module(c.NATIVE,'P13_unchanged_native_runner')
    config,cases,native_parser = native.load_contract(c.CONFIG)
    grant_value,identity = native.validate_grant(args.grant,c.CONFIG,config)
    native.validate_development(config,c.BASE/'tasks/P13/runtime/development/completion.json')
    if (grant_value.get('rank') != args.rank or grant_value.get('boundary_sha256') != args.boundary_sha256
            or identity.get('job_id') != os.environ.get('SLURM_JOB_ID')
            or identity.get('hostname') != socket.gethostname()):
        raise ValueError('Exact owned rank/endpoint/grant differs')
    assigned_ids = bound['partitions'][args.rank]
    assigned = [case for case in cases if case['case_id'] in set(assigned_ids)]
    if [case['case_id'] for case in assigned] != assigned_ids:
        raise ValueError('Partition is not exact original source order')
    output = HERE/'replicas'/str(args.rank)/'output'
    output.mkdir(parents=True,exist_ok=True)
    job_metadata = c.read(HERE/'replicas'/str(args.rank)/'runtime/job_identity.json')
    if job_metadata['job_id'] != os.environ['SLURM_JOB_ID']:
        raise ValueError('Allocation deadline belongs to another job')
    native.ThreadPoolExecutor = c.native_executor(native,bound,args.rank,c.sha(args.grant),
        job_id=os.environ['SLURM_JOB_ID'],deadline_epoch=job_metadata['deadline_epoch'],
        deadline_reserve_seconds=3240 if args.rank == 0 else 1020)
    frozen_args = SimpleNamespace(resume_unattempted=False,grant=args.grant,
        model_path=m['model_path'],context_limit=65536,concurrency=4,timeout=900)
    with c.owned_lock(output/'.runner.lock',create_missing=True,nonblocking=True):
        native.run_locked(frozen_args,c.CONFIG,config,assigned,native_parser,grant_value,identity,output)


def monitor(args,m,bound,runtime,done):
    output = runtime.parent/'output'
    grant_path = runtime/'queue/P13_partition.grant.json'
    try:
        while not done.wait(5):
            state_path = runtime/'status.json'
            if not state_path.exists() or c.read(state_path).get('stage')!='serving_task_queue':
                continue
            if not grant_path.exists():
                if c.present(HERE/'STOP_INFERENCE'):
                    (runtime/'STOP').touch();return
                identity = c.read(runtime/'server_identity.json')
                grant(args,m,bound,identity,runtime)
                continue
            finished_path = runtime/'queue/P13_partition.finished.json'
            rejected_path = runtime/'queue/P13_partition.rejected.json'
            if rejected_path.exists():
                raise ValueError('Partition launch rejected; no retry')
            if not finished_path.exists():
                continue
            finished = c.read(finished_path)
            if finished.get('grant_sha256') != c.sha(grant_path):
                raise ValueError('Partition finished receipt belongs to another grant')
            completion = c.read(output/'completion.json') if (output/'completion.json').exists() else None
            if (finished.get('exit_code') != 0 or completion is None
                    or completion.get('config_sha256') != c.CONFIG_SHA
                    or completion.get('planned') != len(bound['partitions'][args.rank])
                    or completion.get('terminal') != len(bound['partitions'][args.rank])
                    or completion.get('prediction_lock_sha256') != c.sha(output/'prediction_lock.json')
                    or any(completion.get(key) for key in ('transport_errors','http_errors','response_errors','refusals','ambiguous_attempts'))):
                raise ValueError('Partial/failed partition preserved; no model retry or full score')
            terminal_path = runtime/'partition_terminal.json'
            if not terminal_path.exists():
                c.create(terminal_path,{'at_pacific':c.stamp(),'role':'partition_terminal_not_full_benchmark_score',
                    'rank':args.rank,'job_id':os.environ['SLURM_JOB_ID'],'task_id':'P13',
                    'planned':len(bound['partitions'][args.rank]),'terminal':completion['terminal'],
                    'manifest_sha256':args.manifest_sha256,'boundary_sha256':args.boundary_sha256,
                    'grant_sha256':c.sha(grant_path),'finished_sha256':c.sha(finished_path),
                    'completion_sha256':c.sha(output/'completion.json'),
                    'prediction_lock_sha256':c.sha(output/'prediction_lock.json')})
            if args.rank != 0 or (HERE/'FINAL_NATIVE_CLOSED.json').exists() or c.present(HERE/'STOP_INFERENCE'):
                (runtime/'STOP').touch();return
    except Exception as error:
        c.stop_condition('Partition controller: '+type(error).__name__+': '+str(error))
        c.update(runtime/'controller_error.json',{'at_pacific':c.stamp(),'error':str(error),'new_model_retries':0})
        # Do not interrupt outstanding calls on administrative failure. The shared
        # STOP prevents new global claims; native in-flight calls retain their full timeout.
        while not done.wait(5):
            if not grant_path.exists():
                (runtime/'STOP').touch();return
            finished_path = runtime/'queue/P13_partition.finished.json'
            if finished_path.exists():
                value = c.read(finished_path)
                if value.get('grant_sha256') == c.sha(grant_path) and type(value.get('exit_code')) is int:
                    (runtime/'STOP').touch();return


def main():
    args = parser().parse_args()
    m,bound = bind(args)
    if c.present(HERE/'STOP_OPERATION') or c.present(HERE/'STOP_INFERENCE'):
        raise ValueError('Condition/owner stop before runtime preparation or scoring')
    runtime = HERE/'replicas'/str(args.rank)/'runtime'
    if args.mode == 'worker':
        worker(args,m,bound);return
    if args.mode == 'score':
        if args.rank != 0:
            raise ValueError('One original score in coordinator replica0 only')
        helper = c.module(m['scoring_helper'],'P13_original_native_CPU_helper')
        helper.BASE = runtime.parent
        sys.argv = [m['scoring_helper'],'--plan',m['dispatch_plan'],
            '--plan-sha256',m['dispatch_plan_sha256'],'--task','P13']
        helper.main();return
    with c.owned_lock(m['submission_lock']):
        audit = c.require_capacity(m,0,True)
        observation = subprocess.run(['scontrol','show','job',os.environ['SLURM_JOB_ID'],'-o'],
            capture_output=True,text=True,timeout=30,check=True)
        fields = dict(token.split('=',1) for token in observation.stdout.split() if '=' in token)
        expected = {'JobId':os.environ['SLURM_JOB_ID'],'UserId':'dongweij(26129)',
            'JobState':'RUNNING','JobName':'bio-P13-parallel-'+str(args.rank),
            'WorkDir':str(c.ROOT),'Command':str(HERE/'replica.sbatch'),'TimeLimit':'3-00:00:00',
            'Requeue':'0','Restarts':'0','TresPerNode':'gres/gpu:a100:1'}
        if any(fields.get(key) != value for key,value in expected.items()):
            raise ValueError('Exact owned oneGPU72h/no-requeue allocation differs')
        end = datetime.fromisoformat(fields['EndTime'])
        end = end.replace(tzinfo=ZoneInfo('America/Los_Angeles')) if end.tzinfo is None else end
    runtime.mkdir(parents=True,exist_ok=True);(runtime/'queue').mkdir(exist_ok=True)
    c.create(runtime/'startup_gpu_audit.json',audit)
    c.create(runtime/'job_identity.json',{'at_pacific':c.stamp(),'job_id':os.environ['SLURM_JOB_ID'],
        'rank':args.rank,'hostname':socket.gethostname(),'start_time':fields['StartTime'],
        'end_time':fields['EndTime'],'deadline_epoch':end.timestamp(),'resources_verified':expected})
    pool = c.module(m['pool_worker'],'P13_unchanged_native_pool')
    pool.BASE = runtime
    done = threading.Event()
    thread = threading.Thread(target=monitor,args=(args,m,bound,runtime,done),daemon=True)
    thread.start()
    def stop(_signal,_frame):
        raise SystemExit('Slurm/operator stop; preserve all original claims')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        path = HERE/('pool_plan_rank'+str(args.rank)+'.json')
        pool.execute(SimpleNamespace(plan=path,plan_sha256=m['files_sha256'][str(path)]))
    finally:
        done.set();thread.join(timeout=30)


if __name__=='__main__':
    main()
