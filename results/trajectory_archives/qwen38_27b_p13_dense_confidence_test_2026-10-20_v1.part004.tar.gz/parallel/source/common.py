"""Operational metadata/claims/merge only; scientific calls remain in frozen native code."""
from contextlib import contextmanager
from datetime import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
from types import CodeType
from zoneinfo import ZoneInfo

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
BASE = ROOT/'.local/catalog_execution_2026-10-20'
HERE = Path(__file__).resolve().parent
OLD = BASE/'continuation_v3/runtime'
OUT = BASE/'tasks/P13/runtime/benchmark'
CONFIG = BASE/'tasks/P13/test_config.json'
CONFIG_SHA = 'd3915c12cb72599cd5c2a0737bfa3fd72c0705fe4819e688ebd5493adede80dc'
NATIVE = ROOT/'scripts/run_deepfri_catalog_20261020.py'
NATIVE_SHA = 'e3ebc62f8ad3c4ce8dbb1d8f45323d719e7c932db4a3cb6315e74ce2994cac00'
ROOT_SCOPE_SHA = '6e523069d78219115423650d62026b1d6e19a0ae133b533ee9446b557db70678'
STANDING_ROOT_AUTH_SHA = 'bbd274fe26c087b408f4e6e7e799d142341baeed06dd75cc713ba4a923840c46'
HISTORICAL_INVALID_KEYS = frozenset([
    '2dd64557b8a5b23cdeac3334cc96760c3d4aae55f989f4c396c505cef4e479e8',
    '6830b404b0db598e471e43844feccd452e96c5520c4ec9eb588d208fb3445f8b',
    '780d9fbd3fb37f82fb108edbedc849727b761eae63a736f755b2b3d898385cee',
    '85dd9a8a79f4bb218fdcf8beb731304abb4750e0b12c13e526a8e6a0941cb2aa'])


def stamp():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def present(path):
    """A dangling symlink is still a STOP/claimed path, never an absent guard."""
    return os.path.lexists(path)


def generation_member(name):
    return (name in ('run_manifest.json','tokenizer_preflight.json')
            or re.fullmatch(r'(requests|responses|outcomes)/[0-9a-f]{64}\.json',name) is not None
            or re.fullmatch(r'errors/[0-9a-f]{64}\.http',name) is not None)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for piece in iter(lambda: stream.read(8*1024*1024), b''):
            digest.update(piece)
    return digest.hexdigest()


def canonical(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)+'\n').encode()


def regular(path, uid=None):
    path = Path(path)
    for parent in [path, *path.parents]:
        if parent.is_symlink():
            raise ValueError('Symlink path forbidden: '+str(path))
    observed = path.lstat()
    if not stat.S_ISREG(observed.st_mode) or observed.st_uid != (os.getuid() if uid is None else uid):
        raise ValueError('Owned regular file required: '+str(path))
    return observed


def read(path):
    regular(path)
    return json.loads(Path(path).read_bytes())


def sync_directory(path):
    descriptor = os.open(path, os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def create(path, value, raw=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor = os.open(path, os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, 'wb') as stream:
        stream.write(value if raw else canonical(value))
        stream.flush()
        os.fsync(stream.fileno())
    sync_directory(path.parent)


def update(path, value):
    path = Path(path)
    temporary = path.with_name(path.name+'.tmp-'+str(os.getpid()))
    create(temporary, value)
    os.replace(temporary, path)
    sync_directory(path.parent)


def module(path, name):
    if Path(path).parent == ROOT/'scripts' and str(ROOT/'scripts') not in sys.path:
        sys.path.insert(0,str(ROOT/'scripts'))
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


@contextmanager
def owned_lock(path, create_missing=False, nonblocking=False):
    path = Path(path)
    if create_missing and not path.exists():
        try:
            create(path, b'', raw=True)
        except FileExistsError:
            pass
    before = regular(path)
    descriptor = os.open(path, os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(descriptor, 'rb') as stream:
        observed = os.fstat(stream.fileno())
        if (before.st_dev, before.st_ino) != (observed.st_dev, observed.st_ino):
            raise ValueError('Lock identity changed')
        fcntl.flock(stream, fcntl.LOCK_EX|(fcntl.LOCK_NB if nonblocking else 0))
        yield stream


def bind(manifest_path, manifest_sha, source_sha, runtime_sha):
    if sha(manifest_path) != manifest_sha:
        raise ValueError('Parallel manifest changed')
    manifest = read(manifest_path)
    for path, expected in manifest['files_sha256'].items():
        regular(path)
        if sha(path) != expected:
            raise ValueError('Changed pinned support: '+path)
    if (manifest['task_id'] != 'P13' or manifest['planned'] != 3416
            or manifest['replicas'] != 3 or manifest['gpus_per_replica'] != 1
            or manifest['automatic_further_allocations'] is not False
            or manifest['root_scope_sha256'] != ROOT_SCOPE_SHA
            or sha(manifest['root_scope']) != ROOT_SCOPE_SHA
            or sha(CONFIG) != CONFIG_SHA or sha(NATIVE) != NATIVE_SHA):
        raise ValueError('Different root/scientific/replica scope')
    if (manifest['standing_root_authorization_sha256'] != STANDING_ROOT_AUTH_SHA
            or sha(manifest['standing_root_authorization']) != STANDING_ROOT_AUTH_SHA):
        raise ValueError('Immutable standing root delegation changed')
    validate_release_authority(read(manifest['root_scope']),read(manifest['standing_root_authorization']))
    if (sha(manifest['zero_delivery_evidence']) != manifest['zero_delivery_evidence_sha256']
            or sha(manifest['parent_boundary']) != manifest['parent_boundary_sha256']):
        raise ValueError('Changed immutable zero-delivery/parent-boundary evidence')
    original_plan = read(BASE/'continuation_v3/pool_plan.json')
    for rank in range(3):
        expected = dict(original_plan,port=8271+rank,
            endpoint='http://127.0.0.1:'+str(8271+rank)+'/v1',
            queue_root=str(HERE/'replicas'/str(rank)/'runtime/queue'),max_simultaneous_clients=1,
            allowed_runner_paths=[str((HERE/'runtime.py').relative_to(ROOT))],
            purpose='One exact P13 disjoint untouched partition; original model/serving science unchanged')
        if read(HERE/('pool_plan_rank'+str(rank)+'.json')) != expected:
            raise ValueError('Replica changes original checkpoint/precision/serving science')
    if manifest['model_path'] != original_plan['model_path'] or manifest['run_id'] != read(CONFIG)['run_id']:
        raise ValueError('Original checkpoint path/run identity differs')
    for name, digest, issuer in [('engineering_admission.json', source_sha,
                               '/root/priority_runtime_review/lpb398_verifier_tests'),
                               ('runtime_admission.json', runtime_sha, '/root/priority_runtime_review')]:
        path = HERE/name
        if sha(path) != digest:
            raise ValueError('Changed exact independent admission')
        admission = read(path)
        if (admission.get('approved') is not True or admission.get('manifest_sha256') != manifest_sha
                or admission.get('reviewer') != issuer or admission.get('root_scope_sha256') != ROOT_SCOPE_SHA):
            raise ValueError('Missing exact independent '+name)
    return manifest


def validate_release_authority(scope, standing):
    """Accept an honestly attributed release only under the exact root delegation."""
    issuer = scope.get('issuer')
    if (standing.get('approved') is not True or standing.get('issuer') != '/root'
            or standing.get('owners',{}).get('P13') != '/root/deepfri_p13_completion'
            or 'without another user/root permission turn' not in standing.get('bounded_completion_authority','')
            or issuer not in ('/root','/root/independent_review')
            or (issuer == '/root/independent_review'
                and standing.get('independent_review_delegation',{}).get('P13_P37_P44_classification') != issuer)
            or scope.get('root_restoration_authorization_sha256') != STANDING_ROOT_AUTH_SHA
            or scope.get('role') != 'delegated_P13_zero_benchmark_delivery_operational_replacement_release'
            or scope.get('parent_scope_sha256') != '8a769217d95c0a3e51c2bc2c87185f5ad6f2b2c8fa3b15a903b69b2a3a067cc6'
            or scope.get('parent_boundary_sha256') != 'abe40c869fe8acb4d431c5c87b28edb71c9f0c40ac1ac4fd96af84d7332b7001'
            or scope.get('zero_delivery_evidence_sha256') != 'fca1c98658d20f693fdde77b1424ef748039d81797a6e279ce28b7b4c8808feb'
            or scope.get('untouched_cases') != 748 or scope.get('preserved_historical_invalids') != 4
            or scope.get('partition_counts') != [250,249,249]
            or scope.get('automatic_further_allocations') is not False
            or scope.get('approved') is not True or scope.get('current_job_id') != '249544'
            or scope.get('proposed_replacement_replica_count') != 3
            or scope.get('failed_replica_job_ids') != ['249822','249823','249824']
            or scope.get('maximum_new_GPU_allocations') != 3
            or scope.get('zero_benchmark_delivery_required') is not True):
        raise ValueError('Exact independently bound zero-delivery replacement authority absent')


def recovery_predecessors(manifest):
    """Read-only exact terminal accounting for the consumed, zero-delivery jobs."""
    evidence = read(manifest['zero_delivery_evidence'])
    for job,expected in evidence['terminal_jobs'].items():
        result = subprocess.run(['scontrol','show','job',job,'-o'],
            capture_output=True,text=True,timeout=30)
        if result.returncode == 0 and result.stdout.strip():
            fields = dict(token.split('=',1) for token in result.stdout.split() if '=' in token)
            keys = ['JobId','JobName','UserId','WorkDir','Command','JobState','ExitCode',
                    'StartTime','TimeLimit','Requeue','Restarts']
            if (any(fields.get(key) != expected.get(key) for key in keys)
                    or fields.get('JobState') not in ('COMPLETED','FAILED')):
                raise ValueError('Zero-delivery predecessor identity/terminal state differs')
            continue
        result = subprocess.run(['sacct','-X','-n','-P','-j',job,
            '--format=JobIDRaw,State,ExitCode,UID,User,Start,JobName%100,TimelimitRaw,WorkDir%300'],
            capture_output=True,text=True,timeout=30)
        rows = [line.split('|') for line in result.stdout.splitlines() if line.strip()]
        time_limit = '10080' if job == '249802' else '4320'
        wanted = [job,expected['JobState'],expected['ExitCode'],'26129','dongweij',
                  expected['StartTime'],expected['JobName'],time_limit,str(ROOT)]
        if result.returncode or len(rows) != 1 or rows[0][:9] != wanted:
            raise ValueError('Exact terminal zero-delivery accounting absent/ambiguous')
    return evidence


def zero_delivery_boundary(manifest, manifest_sha):
    """Reuse the admitted payload/native-parser boundary only after exact zero-call proof.

    This metadata recovery never reads source biological rows or reference values.
    The original native parsing was completed before the failed allocations; every
    historical generation byte and exact inventory must still match it here.
    """
    if (sha(manifest['zero_delivery_evidence']) != manifest['zero_delivery_evidence_sha256']
            or sha(manifest['parent_boundary']) != manifest['parent_boundary_sha256']):
        raise ValueError('Changed exact immutable recovery evidence/parent boundary')
    evidence = recovery_predecessors(manifest)
    parent = read(manifest['parent_boundary'])
    if (evidence.get('benchmark_attempts_after_parent_boundary') != 0
            or evidence.get('benchmark_responses_after_parent_boundary') != 0
            or evidence.get('canonical_inventory_and_all_hashes_equal_parent_boundary') is not True
            or evidence.get('parent_boundary_sha256') != manifest['parent_boundary_sha256']
            or parent.get('old_saved') != 2664 or parent.get('old_requests') != 2668
            or parent.get('untouched_count') != 748
            or list(map(len,parent.get('partitions',[]))) != [250,249,249]
            or parent.get('historical_invalid_keys') != sorted(HISTORICAL_INVALID_KEYS)):
        raise ValueError('Exact original zero-delivery boundary is not established')
    for path,digest in evidence['files_sha256'].items():
        regular(path)
        if sha(path) != digest:
            raise ValueError('Changed zero-delivery closure evidence: '+path)
    previous = Path(manifest['parent_boundary']).parent
    if present(previous/'claims') or any(present(previous/'replicas'/str(rank)/'output') for rank in range(3)):
        raise ValueError('A failed predecessor has a global/local benchmark claim')
    actual = set()
    for category in ('requests','responses','outcomes','errors'):
        for path in (OUT/category).iterdir():
            regular(path);actual.add(category+'/'+path.name)
    actual.update(('run_manifest.json','tokenizer_preflight.json'))
    if actual != set(parent['historical_files_sha256']):
        raise ValueError('New/missing canonical claim/output invalidates zero-delivery replacement')
    if ({category:sum(name.startswith(category+'/') for name in actual)
            for category in ('requests','responses','outcomes','errors')}
            != {'requests':2668,'responses':2664,'outcomes':2668,'errors':0}):
        raise ValueError('The admitted full historical generation inventory differs')
    verify_historical(parent)
    check_no_score_or_seal()
    request = (OUT/'requests').lstat()
    if (not stat.S_ISDIR(request.st_mode) or request.st_uid != os.getuid()
            or request.st_ino != manifest['requests_inode']
            or stat.S_IMODE(request.st_mode) != 0o700):
        raise ValueError('Exact preserved writable request-directory identity differs')
    parts = parent['partitions'];flat = [value for part in parts for value in part]
    if (len(flat) != len(set(flat)) or set(flat) != set(parent['untouched_case_ids'])
            or parts != [parent['untouched_case_ids'][rank::3] for rank in range(3)]):
        raise ValueError('Inherited untouched complement is not exact/disjoint/source ordered')
    return dict(parent, at_pacific=stamp(), manifest_sha256=manifest_sha,
        parent_boundary_sha256=manifest['parent_boundary_sha256'],
        zero_delivery_evidence_sha256=manifest['zero_delivery_evidence_sha256'],
        previous_allocation_failure_was_before_benchmark_entry=True,
        new_request_permission_mutations=0, reference_labels_opened=False)


def original_terminal(require_terminal=True):
    """Exact old allocation; missing scheduler data never proves terminal."""
    expected = {'JobId':'249544', 'UserId':'dongweij(26129)', 'JobName':'bio-P13-continue3',
                'StartTime':'2026-10-24T12:29:15', 'WorkDir':str(ROOT), 'TimeLimit':'3-00:00:00',
                'Command':str(BASE/'continuation_v3/early_drain_operational_rebind_v2/pool.sbatch')}
    result = subprocess.run(['scontrol','show','job','249544','-o'],capture_output=True,text=True,timeout=30)
    if result.returncode == 0 and result.stdout.strip():
        fields = dict(token.split('=',1) for token in result.stdout.split() if '=' in token)
        if any(fields.get(key) != value for key,value in expected.items()):
            raise ValueError('Old allocation identity changed')
        state = fields.get('JobState')
        if require_terminal and (state != 'COMPLETED' or fields.get('ExitCode') != '0:0'):
            raise BlockingIOError('Old allocation not cleanly terminal: '+str(state))
        if not require_terminal and state != 'RUNNING':
            raise ValueError('Original productive job is not running')
        return {'source':'scontrol','job_id':'249544','state':state,'exit_code':fields.get('ExitCode')}
    if not require_terminal:
        raise ValueError('Current running allocation cannot be verified')
    result = subprocess.run(['sacct','-X','-n','-P','-j','249544',
        '--format=JobIDRaw,State,ExitCode,UID,User,Start,JobName%100,TimelimitRaw,WorkDir%300'],
        capture_output=True,text=True,timeout=30)
    rows = [line.split('|') for line in result.stdout.splitlines() if line.strip()]
    if result.returncode or len(rows) != 1 or rows[0][:9] != [
        '249544','COMPLETED','0:0','26129','dongweij','2026-10-24T12:29:15',
        'bio-P13-continue3','4320',str(ROOT)]:
        raise BlockingIOError('Exact clean terminal accounting absent')
    return {'source':'sacct','job_id':'249544','state':'COMPLETED','exit_code':'0:0'}


def check_no_score_or_seal(out=None):
    out = OUT if out is None else Path(out)
    for path in [Path(out)/name for name in ('completion.json','prediction_lock.json','scores.json')]:
        if present(path):
            raise ValueError('Existing terminal generation/score cannot be cut over')
    if present(BASE/'control/P13_scoring_status.json'):
        raise ValueError('Original scoring attempt already exists')


def boundary(native, config, cases, out=None):
    """Derive the exact request/outcome complement only after terminal handoff."""
    out = OUT if out is None else Path(out)
    files = {}
    for category in ('requests','responses','outcomes','errors'):
        for path in sorted((out/category).iterdir()):
            regular(path)
            if not generation_member(category+'/'+path.name):
                raise ValueError('Foreign generation artifact')
            files[category+'/'+path.name] = sha(path)
    approved_keys = {hashlib.sha256(case['case_id'].encode()).hexdigest() for case in cases}
    if any(Path(name).stem not in approved_keys for name in files):
        raise ValueError('Generation member outside original reviewed cohort')
    untouched, invalids, requests, saved = [], set(), 0, 0
    payloads = {}
    for case in cases:
        key = hashlib.sha256(case['case_id'].encode()).hexdigest()
        payload = native.canonical(native.payload(case,config))
        payloads[key] = hashlib.sha256(payload).hexdigest()
        request, response, outcome = ('requests/'+key+'.json','responses/'+key+'.json','outcomes/'+key+'.json')
        if request not in files:
            if response in files or outcome in files:
                raise ValueError('Outcome/response without original request')
            untouched.append(case['case_id'])
            continue
        requests += 1
        if files[request] != payloads[key] or outcome not in files:
            raise ValueError('In-flight/changed request remains at terminal boundary')
        row = read(out/outcome)
        if row.get('case_id') != case['case_id']:
            raise ValueError('Outcome case identity differs')
        if row.get('status') == 'ambiguous_attempt_not_retried':
            if response in files or row.get('delivery_passed') is not False:
                raise ValueError('Ambiguity interpretation changed')
            invalids.add(key)
        elif (row.get('status') == 'response_saved' and row.get('delivery_passed') is True
              and response in files and row.get('response_sha256') == files[response]
              and row.get('request_sha256') == files[request]
              and not any(row.get(k) for k in ('refusal','truncated','empty_final','reasoning_present'))):
            parsed = native.parse_delivery(read(out/response),config['class_count'])
            if any(row.get(key) != parsed[key] for key in (
                    'prediction','delivery_passed','finish_reason','empty_final','truncated','refusal')):
                raise ValueError('Original frozen response interpretation differs')
            saved += 1
        else:
            raise ValueError('New error/refusal/invalid output requires review; no replica dispatch')
    if invalids != HISTORICAL_INVALID_KEYS or any(name.startswith('errors/') for name in files):
        raise ValueError('Historical invalid set or transport/server errors changed')
    for name in ('run_manifest.json','tokenizer_preflight.json'):
        regular(out/name);files[name] = sha(out/name)
    progress = read(out/'progress.json')
    if any(progress.get(k) != value for k,value in {
        'planned':3416,'responses_saved':saved,'terminal':requests,'attempted_confirmed':requests,
        'not_dispatched':len(untouched),'ambiguous_attempts':4,'config_sha256':CONFIG_SHA}.items()):
        raise ValueError('Terminal direct progress does not match exact original artifact boundary')
    partitions = [untouched[rank::3] for rank in range(3)]
    if not untouched or any(not part for part in partitions):
        raise ValueError('No meaningful three-way untouched complement remains')
    return {'at_pacific':stamp(),'role':'terminal_untouched_partition_boundary_not_score',
            'task_id':'P13','planned':3416,'config_sha256':CONFIG_SHA,'original_job_id':'249544',
            'historical_files_sha256':files,'payload_sha256_by_case_key':payloads,
            'old_requests':requests,'old_saved':saved,'historical_invalid_keys':sorted(invalids),
            'untouched_case_ids':untouched,'partitions':partitions,'untouched_count':len(untouched),
            'partition_rule':'original source order, index modulo3; exact disjoint exhaustive complement',
            'reference_labels_opened':False}


def verify_historical(bound, out=None):
    out = OUT if out is None else Path(out)
    for name,digest in bound['historical_files_sha256'].items():
        path = Path(out)/name;regular(path)
        if sha(path) != digest:
            raise ValueError('Historical bytes changed: '+name)


def stop_condition(reason, here=None):
    here = HERE if here is None else Path(here)
    path = Path(here)/'STOP_INFERENCE'
    try:
        create(path,{'at_pacific':stamp(),'reason':reason,'new_attempts_held':True})
    except FileExistsError:
        pass


def native_executor(native, bound, rank, grant_sha, out=None, here=None, job_id=None, deadline_epoch=None,
                    deadline_reserve_seconds=1020):
    """Add durable global claims around the actual unchanged native inner one()."""
    from concurrent.futures import ThreadPoolExecutor
    here = HERE if here is None else Path(here)
    out = OUT if out is None else Path(out)
    expected_code = next(code for code in native.run_locked.__code__.co_consts
                         if isinstance(code,CodeType) and code.co_name == 'one')
    assigned = set(bound['partitions'][rank])
    class Executor:
        def __init__(self,*args,**kwargs):
            self.real = ThreadPoolExecutor(*args,**kwargs)
            self.wrapped_events = set()
        def __enter__(self):
            self.real.__enter__();return self
        def __exit__(self,*args):
            return self.real.__exit__(*args)
        def submit(self, fn, case):
            if fn.__code__ is not expected_code or not fn.__qualname__.endswith('run_locked.<locals>.one'):
                raise ValueError('Original native call function identity differs')
            cells = dict(zip(fn.__code__.co_freevars,fn.__closure__))
            event = cells['stop'].cell_contents
            if id(event) not in self.wrapped_events:
                original_set = event.set
                def signal_stop():
                    try:
                        with owned_lock(here/'dispatch_claim.lock',create_missing=True):
                            stop_condition('Native refusal/HTTP/transport/response stop',here)
                    finally:
                        original_set()
                event.set = signal_stop
                self.wrapped_events.add(id(event))
            def claimed():
                case_id = case['case_id']
                key = hashlib.sha256(case_id.encode()).hexdigest()
                config = cells['config'].cell_contents
                payload = native.canonical(native.payload(case,config))
                if case_id not in assigned or hashlib.sha256(payload).hexdigest() != bound['payload_sha256_by_case_key'][key]:
                    raise ValueError('Unassigned or changed scientific payload')
                with owned_lock(here/'dispatch_claim.lock',create_missing=True):
                    if event.is_set() or present(here/'STOP_INFERENCE'):
                        return None
                    if deadline_epoch is not None and time.time()+deadline_reserve_seconds >= deadline_epoch:
                        stop_condition('Allocation cutoff: preserve native call/terminal/scoring reserve',here)
                        return None
                    try:
                        create(out/'requests'/(key+'.json'),payload,raw=True)
                        create(here/'claims'/(key+'.json'),{'case_key':key,'at_pacific':stamp(),
                            'rank':rank,'job_id':job_id,'grant_sha256':grant_sha,
                            'request_sha256':hashlib.sha256(payload).hexdigest(),
                            'original_native_callable':True,'attempt_replay_authorized':False})
                    except Exception:
                        stop_condition('Global durable pre-call claim failed; preserve attempt',here)
                        raise
                try:
                    row = fn(case)
                    local = cells['output'].cell_contents/'requests'/(key+'.json')
                    if row is None or local.read_bytes() != payload:
                        raise ValueError('Claimed call has no identical native local request; preserve ambiguity')
                    return row
                except Exception:
                    event.set()
                    raise
            return self.real.submit(claimed)
    return Executor


def copy_exact(source,dest,digest):
    source,dest = Path(source),Path(dest)
    regular(source)
    if sha(source) != digest or dest.exists():
        raise ValueError('Changed source or existing canonical destination')
    create(dest,source.read_bytes(),raw=True)
    if sha(dest) != digest or sha(source) != digest:
        raise ValueError('Changed copy/reconstruction bytes')


def require_capacity(manifest, additional, own):
    binding_path = manifest['resource_binding']
    if sha(binding_path) != manifest['resource_binding_sha256']:
        raise ValueError('Shared resource binding changed')
    binding = read(binding_path)
    for row in [binding['resource_adapter'], binding['root_authorization'],
                *binding['additional_root_proofs'],binding['additional_proof_binding']]:
        if sha(row['path']) != row['sha256']:
            raise ValueError('Shared resource dependency changed')
    adapter = module(binding['resource_adapter']['path'],'P13_parallel_exact_resource_audit')
    result = adapter.capacity_audit(additional=additional, override=False, require_own_job=own,
        additional_root_proofs=binding['additional_root_proofs'],
        additional_proof_binding=binding['additional_proof_binding'])
    count, after = result.get('project_requested_GPUs'),result.get('project_requested_GPUs_with_addition')
    if (type(count) is not int or type(after) is not int or count < 0 or after != count+additional
            or type(result.get('additional_GPUs')) is not int or result['additional_GPUs'] != additional
            or result.get('project_GPU_ceiling') != 8 or after > 8
            or result.get('capacity_available') is not True):
        raise BlockingIOError('No currently verified capacity within eight project GPUs')
    return result


def bind_boundary(manifest_sha, boundary_sha, admission_sha):
    path = HERE/'boundary.json'
    admission_path = HERE/'boundary_admission.json'
    if sha(path) != boundary_sha or sha(admission_path) != admission_sha:
        raise ValueError('Actual terminal boundary/admission changed')
    bound, admission = read(path),read(admission_path)
    if (admission.get('approved') is not True or admission.get('reviewer') != '/root/priority_runtime_review'
            or admission.get('manifest_sha256') != manifest_sha
            or admission.get('boundary_sha256') != boundary_sha
            or admission.get('root_scope_sha256') != ROOT_SCOPE_SHA
            or bound.get('config_sha256') != CONFIG_SHA or bound.get('planned') != 3416
            or bound.get('historical_invalid_keys') != sorted(HISTORICAL_INVALID_KEYS)
            or len(bound.get('partitions',[])) != 3):
        raise ValueError('Missing exact actual terminal/partition admission')
    parts = bound['partitions'];flat = [value for part in parts for value in part]
    if len(flat) != len(set(flat)) or set(flat) != set(bound['untouched_case_ids']):
        raise ValueError('Overlapping/nonexhaustive partition')
    if parts != [bound['untouched_case_ids'][rank::3] for rank in range(3)]:
        raise ValueError('Original ordered modulo3 partition changed')
    return bound
