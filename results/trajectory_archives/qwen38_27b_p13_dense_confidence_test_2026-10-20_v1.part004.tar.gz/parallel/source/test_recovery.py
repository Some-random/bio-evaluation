"""Invented recovery metadata plus true fresh private-Python CLI regressions.

No scheduler/model/source-case/reference call is made. Private --help processes
exit through argparse before runtime main; CUDA and credentials are disabled.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('P13_recovery_test_common',HERE/'common.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def env(safe=True):
    result={k:v for k,v in os.environ.items() if not k.startswith('SLURM_')
        and not k.upper().endswith(('API_KEY','API_TOKEN'))
        and k not in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV','HF_TOKEN','HUGGING_FACE_HUB_TOKEN')}
    result.update(CUDA_VISIBLE_DEVICES='',PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    if safe:result['PYTHONSAFEPATH']='1'
    else:result.pop('PYTHONSAFEPATH',None)
    return result


class PrivateFreshEntryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.python=Path(os.environ['P13_PRIVATE_PYTHON'])
        version=subprocess.run([str(cls.python),'-S','-B','-c',
            'import sys;print(sys.version_info[:3]);print("operator" in sys.modules)'],
            env=env(False),capture_output=True,text=True,timeout=20,check=True)
        if version.stdout.strip()!='(3, 12, 15)\nFalse':
            raise AssertionError('Require exact fresh private3.12.15 without preloaded operator')

    def test_previous_real_worker_reproduces_failure_before_entry(self):
        old=HERE.with_name('P13_parallel_20261024_v1')/'runtime.py'
        run=subprocess.run([str(self.python),'-S','-B',str(old),'--help'],
            env=env(False),capture_output=True,text=True,timeout=30)
        self.assertNotEqual(run.returncode,0)
        self.assertIn('partially initialized module \'operator\'',run.stderr)
        self.assertIn('operator.py',run.stderr)

    def test_new_native_pool_style_worker_entry_passes_fresh_help(self):
        # Exact pool launch shape: [private_python, runner, *argv]; safe_path is
        # inherited through the original pool environment, not preloaded imports.
        run=subprocess.run([str(self.python),str(HERE/'runtime.py'),'--help'],
            env=env(),capture_output=True,text=True,timeout=30)
        self.assertEqual(run.returncode,0,run.stderr)
        self.assertIn('--mode {pool,worker,score}',run.stdout)

    def test_new_coordinator_and_publication_have_no_stdlib_shadow(self):
        self.assertFalse((HERE/'operator.py').exists())
        for name in ('coordinator.py','publication.py'):
            with self.subTest(name=name):
                run=subprocess.run([str(self.python),'-S','-P','-B',str(HERE/name),'--help'],
                    env=env(),capture_output=True,text=True,timeout=30)
                self.assertEqual(run.returncode,0,run.stderr)

    def test_unsafe_worker_entry_rejects_before_manifest_or_live_action(self):
        args=['--mode','worker','--manifest','/nonexistent/invented-manifest.json',
            '--manifest-sha256','invented','--source-admission-sha256','invented',
            '--runtime-admission-sha256','invented','--boundary-sha256','invented',
            '--boundary-admission-sha256','invented','--rank','0']
        # v2 has no colliding module; without safe_path it fails its explicit
        # entry guard before c.bind can even attempt reading a manifest.
        run=subprocess.run([str(self.python),'-S','-B',str(HERE/'runtime.py'),*args],
            env=env(False),capture_output=True,text=True,timeout=30)
        self.assertNotEqual(run.returncode,0)
        self.assertIn('Safe fresh interpreter entry is required',run.stderr)
        self.assertNotIn('FileNotFoundError',run.stderr)

    def test_original_pool_environment_preserves_safe_child_flag(self):
        pool=c.module(c.ROOT/'scripts/serve_catalog_20261020.py','P13_invented_pool_env')
        fake=SimpleNamespace(environment=lambda _:dict(PYTHONSAFEPATH='1',OPENAI_API_KEY='invented'))
        result=pool.environment(fake,Path('/invented'))
        self.assertEqual(result['PYTHONSAFEPATH'],'1')
        self.assertNotIn('OPENAI_API_KEY',result)


class RecoveryMetadataTests(unittest.TestCase):
    def test_exact_invented_full_boundary_accepts_without_permission_or_model_action(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);out=root/'canonical';previous=root/'previous';previous.mkdir()
            for category in ('requests','responses','outcomes','errors'):(out/category).mkdir(parents=True)
            files={}
            keys=[hashlib.sha256(('invented-'+str(i)).encode()).hexdigest() for i in range(2664)]
            keys+=sorted(c.HISTORICAL_INVALID_KEYS)
            for i,key in enumerate(keys):
                for category in ('requests','outcomes'):
                    p=out/category/(key+'.json');p.write_text('{"invented":true}')
                    files[category+'/'+p.name]=c.sha(p)
                if i<2664:
                    p=out/'responses'/(key+'.json');p.write_text('{"invented_response":true}')
                    files['responses/'+p.name]=c.sha(p)
            for name in ('run_manifest.json','tokenizer_preflight.json'):
                p=out/name;p.write_text('{}');files[name]=c.sha(p)
            (out/'requests').chmod(0o700)
            ids=['invented-untouched-'+str(i) for i in range(748)]
            parent={'old_saved':2664,'old_requests':2668,'untouched_count':748,
                'historical_invalid_keys':sorted(c.HISTORICAL_INVALID_KEYS),
                'historical_files_sha256':files,'untouched_case_ids':ids,
                'partitions':[ids[i::3] for i in range(3)],'reference_labels_opened':False}
            bp=previous/'boundary.json';bp.write_bytes(c.canonical(parent))
            stop=previous/'STOP_INFERENCE';stop.write_text('Invented technical failure preserved')
            evidence={'benchmark_attempts_after_parent_boundary':0,'benchmark_responses_after_parent_boundary':0,
                'canonical_inventory_and_all_hashes_equal_parent_boundary':True,
                'parent_boundary_sha256':c.sha(bp),'files_sha256':{str(stop):c.sha(stop)}}
            ep=root/'evidence.json';ep.write_bytes(c.canonical(evidence))
            m={'zero_delivery_evidence':str(ep),'zero_delivery_evidence_sha256':c.sha(ep),
                'parent_boundary':str(bp),'parent_boundary_sha256':c.sha(bp),
                'requests_inode':(out/'requests').stat().st_ino}
            with patch.object(c,'OUT',out),patch.object(c,'BASE',root),\
                    patch.object(c,'recovery_predecessors',return_value=evidence),\
                    patch.object(os,'fchmod',side_effect=AssertionError('No permission mutation')),\
                    patch.object(subprocess,'run',side_effect=AssertionError('No scheduler/model process')):
                result=c.zero_delivery_boundary(m,'invented-manifest')
                self.assertEqual(result['partitions'],parent['partitions'])
                self.assertEqual(result['historical_files_sha256'],files)
                self.assertEqual(len(files),8002)
                self.assertEqual(result['new_request_permission_mutations'],0)
                self.assertEqual(stop.read_text(),'Invented technical failure preserved')
                self.assertEqual((out/'requests').stat().st_mode&0o777,0o700)
                extra=out/'requests'/('f'*64+'.json');extra.write_text('{}')
                with self.assertRaisesRegex(ValueError,'New/missing canonical'):
                    c.zero_delivery_boundary(m,'invented-manifest')
                extra.unlink()
                stop.write_text('changed')
                with self.assertRaisesRegex(ValueError,'closure evidence'):
                    c.zero_delivery_boundary(m,'invented-manifest')
                stop.write_text('Invented technical failure preserved')
                ep.write_text('{}')
                with self.assertRaisesRegex(ValueError,'immutable recovery evidence'):
                    c.zero_delivery_boundary(m,'invented-manifest')

    def test_predecessor_nonterminal_and_ambiguous_accounting_fail_closed(self):
        expected={'JobId':'invented','JobName':'invented-job','UserId':'dongweij(26129)',
            'WorkDir':str(c.ROOT),'Command':'/invented/source','JobState':'FAILED','ExitCode':'1:0',
            'StartTime':'2026-10-24T01:00:00','TimeLimit':'3-00:00:00','Requeue':'0','Restarts':'0'}
        with tempfile.TemporaryDirectory() as folder:
            ep=Path(folder)/'evidence.json';ep.write_bytes(c.canonical({'terminal_jobs':{'invented':expected}}))
            m={'zero_delivery_evidence':str(ep)}
            healthy=' '.join(k+'='+v for k,v in expected.items())
            with patch.object(subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout=healthy)):
                self.assertIn('terminal_jobs',c.recovery_predecessors(m))
            bad=healthy.replace('JobState=FAILED','JobState=RUNNING')
            with patch.object(subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout=bad)):
                with self.assertRaisesRegex(ValueError,'terminal state'):
                    c.recovery_predecessors(m)
            with patch.object(subprocess,'run',side_effect=[SimpleNamespace(returncode=1,stdout=''),
                    SimpleNamespace(returncode=0,stdout='')]):
                with self.assertRaisesRegex(ValueError,'absent/ambiguous'):
                    c.recovery_predecessors(m)


class DelegatedAuthorityTests(unittest.TestCase):
    def test_exact_named_delegation_accepts_honest_issuer_and_rejects_owner_selfgrant(self):
        standing={'approved':True,'issuer':'/root','owners':{'P13':'/root/deepfri_p13_completion'},
            'bounded_completion_authority':'Invented fixture: without another user/root permission turn',
            'independent_review_delegation':{'P13_P37_P44_classification':'/root/independent_review'}}
        scope={'approved':True,'issuer':'/root/independent_review','current_job_id':'249544',
            'root_restoration_authorization_sha256':c.STANDING_ROOT_AUTH_SHA,
            'role':'delegated_P13_zero_benchmark_delivery_operational_replacement_release',
            'parent_scope_sha256':'8a769217d95c0a3e51c2bc2c87185f5ad6f2b2c8fa3b15a903b69b2a3a067cc6',
            'parent_boundary_sha256':'abe40c869fe8acb4d431c5c87b28edb71c9f0c40ac1ac4fd96af84d7332b7001',
            'zero_delivery_evidence_sha256':'fca1c98658d20f693fdde77b1424ef748039d81797a6e279ce28b7b4c8808feb',
            'untouched_cases':748,'preserved_historical_invalids':4,'partition_counts':[250,249,249],
            'automatic_further_allocations':False,
            'proposed_replacement_replica_count':3,'maximum_new_GPU_allocations':3,
            'failed_replica_job_ids':['249822','249823','249824'],'zero_benchmark_delivery_required':True}
        c.validate_release_authority(scope,standing)
        for changes in [{'issuer':'/root/deepfri_p13_completion'}, {'approved':False},
                {'maximum_new_GPU_allocations':4},{'zero_benchmark_delivery_required':False},
                {'root_restoration_authorization_sha256':'different'}]:
            with self.subTest(changes=changes),self.assertRaisesRegex(ValueError,'authority absent'):
                c.validate_release_authority(dict(scope,**changes),standing)
        with self.assertRaisesRegex(ValueError,'authority absent'):
            c.validate_release_authority(scope,dict(standing,independent_review_delegation={}))


if __name__=='__main__':unittest.main()
