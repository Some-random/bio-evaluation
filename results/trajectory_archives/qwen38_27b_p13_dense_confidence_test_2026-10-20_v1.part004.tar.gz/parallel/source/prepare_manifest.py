"""Freeze one operational zero-benchmark-delivery replacement; no live effects."""
import importlib.util
from pathlib import Path
import json

ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
BASE=ROOT/'.local/catalog_execution_2026-10-20'
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('P13_recovery_prepare_common',HERE/'common.py')
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def main():
    previous=BASE/'P13_parallel_20261024_v1'
    old_path=previous/'manifest.json'
    if c.sha(old_path)!='2c6bb8607cdc396dd1f05b305f67c1ee17c07927bf064460c714eac47a7403d2':
        raise ValueError('Original independently admitted parallel source changed')
    old=c.read(old_path);pins=dict(old['files_sha256'])
    for path,digest in pins.items():
        c.regular(path)
        if c.sha(path)!=digest:raise ValueError('Original frozen dependency changed')
    root_scope=ROOT/'.local/goal_restore_20261024/P13_zero_benchmark_delivery_delegated_replacement_release.json'
    if c.sha(root_scope)!=c.ROOT_SCOPE_SHA:
        raise ValueError('Exact new zero-delivery replacement authority not frozen')
    evidence_path=HERE/'zero_delivery_recovery_evidence.json'
    if c.sha(evidence_path)!='fca1c98658d20f693fdde77b1424ef748039d81797a6e279ce28b7b4c8808feb':
        raise ValueError('Exact actual zero-delivery evidence changed')
    evidence=c.read(evidence_path)
    boundary=previous/'boundary.json'
    if c.sha(boundary)!='abe40c869fe8acb4d431c5c87b28edb71c9f0c40ac1ac4fd96af84d7332b7001':
        raise ValueError('Original admitted untouched boundary changed')
    # All failed-episode metadata is immutable. Live canonical progress is dated
    # evidence, not a permanent source pin: the full merge must eventually update it.
    standing=ROOT/'.local/goal_restore_20261024/root_authorization.json'
    if c.sha(standing)!=c.STANDING_ROOT_AUTH_SHA:raise ValueError('Standing root delegation changed')
    paths=[old_path,root_scope,standing,evidence_path,boundary,previous/'preserved_old_progress.json',
        previous/'engineering_review.json',previous/'engineering_admission.json',
        previous/'runtime_admission.json',previous/'boundary_admission.json',
        previous/'operator_cpu_execution_review.json']
    for path,digest in c.read(root_scope)['administrative_source_files_sha256'].items():
        if c.sha(path)!=digest:raise ValueError('Delegated authority provenance changed')
        paths.append(Path(path))
    for path,digest in evidence['files_sha256'].items():
        if path==str(c.OUT/'progress.json'):continue
        if c.sha(path)!=digest:raise ValueError('Failed-episode closure changed')
        paths.append(Path(path))
    for name in ['common.py','coordinator.py','runtime.py','publication.py','prepare_manifest.py',
                 'test_parallel.py','test_recovery.py','replica.sbatch','supervisor.sbatch',
                 'pool_plan_rank0.json','pool_plan_rank1.json','pool_plan_rank2.json',
                 'private_python_bootstrap_reproduction.json','source_delta_summary.json',
                 'root_replacement_scope_proposed.json','independent_zero_delivery_support.json']:
        paths.append(HERE/name)
    for path in paths:
        c.regular(path);digest=c.sha(path)
        if str(path) in pins and pins[str(path)]!=digest:raise ValueError('Conflicting source pin')
        pins[str(path)]=digest
    value=dict(old, schema_version=2,root_scope=str(root_scope),root_scope_sha256=c.sha(root_scope),
        standing_root_authorization=str(standing),standing_root_authorization_sha256=c.sha(standing),
        parent_manifest=str(old_path),parent_manifest_sha256=c.sha(old_path),
        parent_boundary=str(boundary),parent_boundary_sha256=c.sha(boundary),
        zero_delivery_evidence=str(evidence_path),zero_delivery_evidence_sha256=c.sha(evidence_path),
        failed_replica_job_ids=['249822','249823','249824'],failed_CPU_supervisor_job_id='249802',
        maximum_new_GPU_allocations=3,extra_net_simultaneous_GPUs=3,
        no_old_STOP_or_request_permission_mutations=True,
        safe_fresh_private_python_required=True,
        files_sha256=dict(sorted(pins.items())))
    c.create(HERE/'manifest.json',value)
    print(json.dumps({'manifest_sha256':c.sha(HERE/'manifest.json'),'static_pins':len(pins)}))


if __name__=='__main__':main()
