"""One reviewed drain, three untouched-only jobs, canonical merge and once-native score.

No operation runs on import. All scheduler/permission mutations require both exact
independent admissions; the actual terminal partition receives a further exact binding.
"""
import argparse
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('P13_parallel_operator_common',HERE/'common.py')
c = importlib.util.module_from_spec(spec);spec.loader.exec_module(c)


def status(stage,**extra):
    c.update(HERE/'operator_status.json',{'at_pacific':c.stamp(),'stage':stage,
        'pid':os.getpid(),'new_model_calls_by_operator':0,**extra})


def owned_directory(path,inode,mode):
    path = Path(path)
    for ancestor in [path,*path.parents]:
        if ancestor.is_symlink():
            raise ValueError('Symlink request directory forbidden')
    observed = path.lstat()
    if (not stat.S_ISDIR(observed.st_mode) or observed.st_uid != os.getuid()
            or observed.st_ino != inode or stat.S_IMODE(observed.st_mode) != mode):
        raise ValueError('Owned exact request directory/inode/mode differs')
    descriptor = os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    opened = os.fstat(descriptor)
    if (opened.st_dev,opened.st_ino) != (observed.st_dev,observed.st_ino):
        os.close(descriptor);raise ValueError('Same-namespace request-directory race')
    return descriptor


def directory_change(m,oldmode,newmode,receipt_path,prerequisite):
    """Persisted inode is portable; st_dev is compared only within this operation."""
    prerequisite()
    target = c.OUT/'requests'
    descriptor = owned_directory(target,m['requests_inode'],oldmode)
    try:
        before = os.fstat(descriptor)
        c.create(receipt_path.with_name(receipt_path.stem+'.claim.json'),{
            'at_pacific':c.stamp(),'target':str(target),'inode':before.st_ino,
            'namespace_device_observed':before.st_dev,'from_mode':oct(oldmode),'to_mode':oct(newmode),
            'old_job_id':'249544','config_sha256':c.CONFIG_SHA,'new_model_calls':0})
        # Check the prerequisite again immediately before the sole mode transition.
        prerequisite()
        fresh = owned_directory(target,m['requests_inode'],oldmode)
        try:
            observed = os.fstat(fresh)
            if (observed.st_dev,observed.st_ino) != (before.st_dev,before.st_ino):
                raise ValueError('Request directory changed before mode transition')
        finally:
            os.close(fresh)
        os.fchmod(descriptor,newmode);os.fsync(descriptor)
        after = os.fstat(descriptor)
        if stat.S_IMODE(after.st_mode) != newmode:
            raise ValueError('Request permission transition not observed')
        c.create(receipt_path,{'at_pacific':c.stamp(),'target':str(target),'inode':after.st_ino,
            'namespace_device_observed':after.st_dev,'from_mode':oct(oldmode),'to_mode':oct(newmode),
            'old_job_id':'249544','config_sha256':c.CONFIG_SHA,
            'active_model_calls_interrupted':False,'historical_file_bytes_changed':False,'new_model_calls':0})
    finally:
        os.close(descriptor)


def stop_old_packager(m):
    old = c.BASE/'continuation_v3/publication_v2'
    receipt = c.read(old/'watcher_launch_receipt.json')
    if c.sha(old/'watcher_launch_receipt.json') != m['old_packager_launch_receipt_sha256']:
        raise ValueError('Original packaging watcher identity differs')
    if (old/'publication_assembly_claim.json').exists() or (old/'stage').exists():
        raise ValueError('Original assembly already claimed; do not replace its lineage')
    process = Path('/proc')/str(receipt['pid'])
    if process.exists():
        if (process.stat().st_uid != os.getuid()
                or (process/'stat').read_text().split()[21] != receipt['proc_start_ticks']
                or (process/'cmdline').read_bytes().rstrip(b'\0').split(b'\0') != [v.encode() for v in receipt['command']]):
            raise ValueError('Original packaging PID was reused')
    c.create(old/'STOP_ASSEMBLY',{'at_pacific':c.stamp(),'role':'reviewed_parallel_lineage_handoff_no_assembly_retry',
        'root_scope_sha256':c.ROOT_SCOPE_SHA,'prior_source_review_preserved':True})
    deadline = time.monotonic()+120
    while process.exists() and time.monotonic()<deadline:
        time.sleep(1)
    if process.exists():
        raise ValueError('Original packaging watcher did not stop; no drain')
    c.create(HERE/'old_packager_retired.json',{'at_pacific':c.stamp(),'original_launch_receipt_sha256':m['old_packager_launch_receipt_sha256'],
        'STOP_ASSEMBLY_sha256':c.sha(old/'STOP_ASSEMBLY'),'actual_assembly_claim_present':False,'new_model_or_score_calls':0})


def drain_prerequisite(m,args):
    c.bind(args.manifest,args.manifest_sha256,args.source_admission_sha256,args.runtime_admission_sha256)
    c.original_terminal(False)
    c.check_no_score_or_seal()
    if c.present(HERE/'STOP_OPERATION') or c.present(HERE/'STOP_INFERENCE'):
        raise ValueError('Owner/condition stop before drain')
    for rank in range(3):
        if (HERE/('submission_rank'+str(rank)+'.json')).exists():
            raise ValueError('Replacement was already submitted')


def wait_old_terminal():
    deadline = time.monotonic()+3600
    while time.monotonic()<deadline:
        try:
            result = c.original_terminal()
            c.create(HERE/'old_terminal_receipt.json',{'at_pacific':c.stamp(),**result,
                'drain_receipt_sha256':c.sha(HERE/'drain_receipt.json')})
            return
        except BlockingIOError as error:
            status('drained_waiting_old_inflight_and_allocation_terminal',observation=str(error))
            time.sleep(15)
    raise TimeoutError('Old allocation did not become cleanly terminal; no successor allocation')


def actual_boundary(m,args):
    c.check_no_score_or_seal()
    native = c.module(c.NATIVE,'P13_frozen_boundary_payload_builder')
    config,cases,_ = native.load_contract(c.CONFIG)
    bound = c.boundary(native,config,cases)
    bound['manifest_sha256'] = args.manifest_sha256
    bound['old_terminal_receipt_sha256'] = c.sha(HERE/'old_terminal_receipt.json')
    bound['drain_receipt_sha256'] = c.sha(HERE/'drain_receipt.json')
    bound['old_cleanup_sha256'] = c.sha(c.OLD/'cleanup.json')
    c.create(HERE/'boundary.json',bound)
    c.create(HERE/'preserved_old_progress.json',(c.OUT/'progress.json').read_bytes(),raw=True)
    return bound,c.sha(HERE/'boundary.json')


def wait_boundary_admission(args,boundary_sha):
    deadline = time.monotonic()+7200
    while time.monotonic()<deadline:
        path = HERE/'boundary_admission.json'
        if path.exists():
            digest = c.sha(path)
            c.bind_boundary(args.manifest_sha256,boundary_sha,digest)
            return digest
        if c.present(HERE/'STOP_OPERATION'):
            raise ValueError('Owner stop while exact terminal partition awaits review')
        status('waiting_exact_independent_terminal_boundary_admission',boundary_sha256=boundary_sha)
        time.sleep(10)
    raise TimeoutError('Exact boundary review not observed; requests stay drained, no jobs submitted')


def restore_prerequisite(m,args,boundary_sha,admission_sha):
    c.bind(args.manifest,args.manifest_sha256,args.source_admission_sha256,args.runtime_admission_sha256)
    c.original_terminal()
    c.recovery_predecessors(m)
    bound = c.bind_boundary(args.manifest_sha256,boundary_sha,admission_sha)
    c.verify_historical(bound)
    c.check_no_score_or_seal()
    if c.present(HERE/'STOP_OPERATION') or c.present(HERE/'STOP_INFERENCE'):
        raise ValueError('Owner/condition stop before request restoration')
    return bound


def command_args(args,boundary_sha,admission_sha,rank):
    return ['--manifest',str(args.manifest),'--manifest-sha256',args.manifest_sha256,
        '--source-admission-sha256',args.source_admission_sha256,
        '--runtime-admission-sha256',args.runtime_admission_sha256,
        '--boundary-sha256',boundary_sha,'--boundary-admission-sha256',admission_sha,
        '--rank',str(rank)]


def submit(m,args,boundary_sha,admission_sha,rank):
    deadline = time.monotonic()+24*3600
    while time.monotonic()<deadline:
        if c.present(HERE/'STOP_OPERATION') or c.present(HERE/'STOP_INFERENCE'):
            raise ValueError('Owner/condition stop before new allocation')
        with c.owned_lock(m['submission_lock']):
            restore_prerequisite(m,args,boundary_sha,admission_sha)
            try:
                audit = c.require_capacity(m,1,False)
            except BlockingIOError:
                status('waiting_fresh_project_GPU_capacity',rank=rank)
            else:
                audit_path = HERE/('preallocation_rank'+str(rank)+'.json')
                c.create(audit_path,audit)
                command = ['sbatch','--parsable','--dependency=afterany:249802:249822:249823:249824',
                    '--job-name=bio-P13-parallel-'+str(rank),str(HERE/'replica.sbatch'),
                    *command_args(args,boundary_sha,admission_sha,rank)]
                claim = HERE/('submission_claim_rank'+str(rank)+'.json')
                # Final stop/release check is adjacent to fsynced sole claim and sbatch.
                restore_prerequisite(m,args,boundary_sha,admission_sha)
                c.create(claim,{'at_pacific':c.stamp(),'rank':rank,'command':command,
                    'manifest_sha256':args.manifest_sha256,'boundary_sha256':boundary_sha,
                    'preallocation_audit_sha256':c.sha(audit_path),'new_GPU_allocations_maximum':1})
                try:
                    result = subprocess.run(command,cwd=c.ROOT,capture_output=True,text=True,timeout=45)
                    raw = result.stdout.strip().split(';',1)[0]
                    if result.returncode or not raw.isdecimal():
                        raise ValueError('Scheduler submission uncertain/denied: '+result.stderr[:1000])
                    registration = {'at_pacific':c.stamp(),'rank':rank,'job_id':raw,
                        'manifest_sha256':args.manifest_sha256,'boundary_sha256':boundary_sha,
                        'boundary_admission_sha256':admission_sha,'claim_sha256':c.sha(claim),
                        'scheduler_stdout':result.stdout.strip(),'no_automatic_further_allocation':True}
                    c.create(HERE/('submission_rank'+str(rank)+'.json'),registration)
                    return raw
                except Exception as error:
                    c.create(HERE/('submission_uncertain_rank'+str(rank)+'.json'),{
                        'at_pacific':c.stamp(),'error':str(error),'claim_consumed_no_retry':True})
                    raise
        time.sleep(30)
    raise TimeoutError('Bounded capacity wait expired; no extra allocation chain')


def merge(bound,args):
    with ExitStack() as locks:
        for rank in range(3):
            locks.enter_context(c.owned_lock(HERE/'replicas'/str(rank)/'output/.runner.lock',nonblocking=True))
        return merge_locked(bound,args)


def merge_locked(bound,args):
    """Copy each byte once under the sole canonical lock; never reparse permissively."""
    c.verify_historical(bound);c.check_no_score_or_seal()
    c.create(HERE/'merge_claim.json',{'at_pacific':c.stamp(),'boundary_sha256':c.sha(HERE/'boundary.json'),
        'manifest_sha256':args.manifest_sha256,'native_scoring_entries':0})
    inherited = bound['historical_files_sha256']
    expected_requests = {name for name in inherited if name.startswith('requests/')}
    for rank,ids in enumerate(bound['partitions']):
        folder = HERE/'replicas'/str(rank)/'output'
        runtime = folder.parent/'runtime'
        terminal = c.read(runtime/'partition_terminal.json')
        lock = c.read(folder/'prediction_lock.json');completion = c.read(folder/'completion.json')
        if any(not c.generation_member(name) for name in lock['files_sha256']):
            raise ValueError('Foreign/traversal partition seal member')
        if (terminal['boundary_sha256'] != c.sha(HERE/'boundary.json')
                or terminal['manifest_sha256'] != args.manifest_sha256
                or terminal['planned'] != len(ids) or terminal['terminal'] != len(ids)
                or terminal['prediction_lock_sha256'] != c.sha(folder/'prediction_lock.json')
                or terminal['completion_sha256'] != c.sha(folder/'completion.json')
                or completion['config_sha256'] != c.CONFIG_SHA
                or lock.get('reference_labels_opened') is not False):
            raise ValueError('Partition seal identity differs')
        allowed = set()
        for case_id in ids:
            key = __import__('hashlib').sha256(case_id.encode()).hexdigest()
            claim = c.read(HERE/'claims'/(key+'.json'))
            if (claim.get('rank') != rank or claim.get('request_sha256') != bound['payload_sha256_by_case_key'][key]
                    or claim.get('grant_sha256') != terminal['grant_sha256']):
                raise ValueError('Shared original request claim differs')
            names = ['requests/'+key+'.json','responses/'+key+'.json','outcomes/'+key+'.json']
            allowed.update(names)
            if any(name not in lock['files_sha256'] for name in names):
                raise ValueError('Partition missing original request/response/outcome')
            for name in names:
                source = folder/name;digest = lock['files_sha256'][name]
                if c.sha(source) != digest:
                    raise ValueError('Changed original partition bytes')
                if name.startswith('requests/'):
                    if digest != bound['payload_sha256_by_case_key'][key] or c.sha(c.OUT/name) != digest:
                        raise ValueError('Local/global original payload bytes differ')
                    expected_requests.add(name)
                else:
                    c.copy_exact(source,c.OUT/name,digest)
        actual = {name for name in lock['files_sha256'] if any(name.startswith(k+'/') for k in ('requests','responses','outcomes','errors'))}
        if actual != allowed:
            raise ValueError('Foreign or failed partition trajectory members')
        for name,digest in lock['files_sha256'].items():
            if c.sha(folder/name) != digest:
                raise ValueError('Partition seal changed during copy')
    if {str(p.relative_to(c.OUT)) for p in (c.OUT/'requests').iterdir()} != expected_requests:
        raise ValueError('Unaccounted canonical global request claim')
    c.verify_historical(bound)
    totals = {key:0 for key in ('terminal','responses_saved','delivery_passed','transport_errors',
        'http_errors','response_errors','ambiguous_attempts','truncations','empty_finals','refusals','reasoning_present')}
    for path in (c.OUT/'outcomes').iterdir():
        row = c.read(path);totals['terminal'] += 1
        totals['responses_saved'] += bool(row.get('response_saved'));totals['delivery_passed'] += bool(row.get('delivery_passed'))
        for key,source in [('transport_errors','transport_error'),('http_errors','http_error'),
            ('response_errors','response_error'),('ambiguous_attempts','ambiguous_attempt_not_retried')]:
            totals[key] += row.get('status') == source
        for key,source in [('truncations','truncated'),('empty_finals','empty_final'),('refusals','refusal'),('reasoning_present','reasoning_present')]:
            totals[key] += bool(row.get(source))
    if (totals['terminal'] != 3416 or totals['ambiguous_attempts'] != 4
            or any(totals[k] for k in ('transport_errors','http_errors','response_errors','refusals'))):
        raise ValueError('Full canonical terminal counts/invalid policy differ')
    files = {str(p.relative_to(c.OUT)):c.sha(p) for category in ('requests','responses','outcomes','errors')
        for p in sorted((c.OUT/category).iterdir()) if p.is_file()}
    files.update({name:c.sha(c.OUT/name) for name in ('run_manifest.json','tokenizer_preflight.json')})
    c.create(c.OUT/'prediction_lock.json',{'sealed_at_pacific':c.stamp(),'files_sha256':files,
        'config_sha256':c.CONFIG_SHA,'reference_labels_opened':False})
    config = c.read(c.CONFIG)
    completion = {'at_pacific':c.stamp(),'task_id':'P13','run_id':config['run_id'],'config_sha256':c.CONFIG_SHA,
        'planned':3416,**totals,'attempted_confirmed':3416,'not_dispatched':0,'phase':'benchmark_generation',
        'transport_or_response_errors':totals['transport_errors']+totals['http_errors']+totals['response_errors'],
        'biological_correctness_assessed':False,'generation':config['generation'],
        'prediction_lock_sha256':c.sha(c.OUT/'prediction_lock.json'),'delivery_passed_all':False,
        'all_passed':False,'status':'terminal_complete_cohort'}
    c.create(c.OUT/'completion.json',completion);c.update(c.OUT/'progress.json',completion)
    c.create(HERE/'merge_receipt.json',{'at_pacific':c.stamp(),'planned':3416,'terminal':3416,
        'historical_invalids':4,'prediction_lock_sha256':c.sha(c.OUT/'prediction_lock.json'),
        'completion_sha256':c.sha(c.OUT/'completion.json'),'old_bytes_unchanged':True,'new_model_or_scoring_calls':0})


def score(m,args,boundary_sha,admission_sha):
    score_path = c.OUT/'scores.json';state_path = c.BASE/'control/P13_scoring_status.json'
    if score_path.exists() or state_path.exists():
        raise ValueError('Original native scoring attempt already exists; never auto-repeat')
    # Native pre-reference verifier is unchanged and is run before the sole score claim.
    native = c.module(m['scorer'],'P13_original_native_pre_reference_verifier')
    native.verify_locked_generation(c.CONFIG,c.OUT)
    registration = c.read(HERE/'submission_rank0.json')
    job_metadata = c.read(HERE/'replicas/0/runtime/job_identity.json')
    observed = subprocess.run(['scontrol','show','job',registration['job_id'],'-o'],
        capture_output=True,text=True,timeout=30,check=True)
    fields = dict(token.split('=',1) for token in observed.stdout.split() if '=' in token)
    if (fields.get('JobId') != registration['job_id'] or fields.get('JobState') != 'RUNNING'
            or fields.get('UserId') != 'dongweij(26129)' or fields.get('WorkDir') != str(c.ROOT)
            or fields.get('Command') != str(HERE/'replica.sbatch')
            or fields.get('EndTime') != job_metadata['end_time']
            or time.time()+2220 >= job_metadata['deadline_epoch']):
        raise ValueError('Full native score/cleanup budget not available; no irreversible scoring claim')
    command = ['srun','--jobid='+registration['job_id'],'--overlap','--nodes=1','--ntasks=1',
        '--gres=none','--cpu-bind=none','/usr/bin/python3','-P',str(HERE/'runtime.py'),'--mode','score',
        *command_args(args,boundary_sha,admission_sha,0)]
    c.bind(args.manifest,args.manifest_sha256,args.source_admission_sha256,args.runtime_admission_sha256)
    if c.present(HERE/'STOP_OPERATION') or c.present(HERE/'STOP_INFERENCE'):
        raise ValueError('Condition/owner stop before sole irreversible native score claim')
    c.create(state_path,{'stage':'one_attempt_started','started_at_pacific':c.stamp(),
        'prediction_lock_sha256':c.sha(c.OUT/'prediction_lock.json'),'parallel_manifest_sha256':args.manifest_sha256,
        'continuation_job_id':registration['job_id'],'command':command})
    with (c.BASE/'control/P13_scoring.log').open('x') as log:
        result = subprocess.run(command,cwd=c.ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=2100)
    c.update(state_path,{'stage':'completed' if result.returncode == 0 and score_path.exists() else 'failed_no_retry',
        'finished_at_pacific':c.stamp(),'exit_code':result.returncode,
        'score_sha256':c.sha(score_path) if score_path.exists() else None})
    if result.returncode or not score_path.exists():
        raise ValueError('Original native scorer failed; no automatic retry')
    c.create(HERE/'FINAL_NATIVE_CLOSED.json',{'at_pacific':c.stamp(),'task_id':'P13','planned':3416,'terminal':3416,
        'score_path':str(score_path),'score_sha256':c.sha(score_path),'prediction_lock_sha256':c.sha(c.OUT/'prediction_lock.json'),
        'scoring_status_sha256':c.sha(state_path),'further_allocation_authorized':False})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--source-admission-sha256',required=True)
    parser.add_argument('--runtime-admission-sha256',required=True)
    args = parser.parse_args()
    if not sys.flags.safe_path or os.environ.get('PYTHONSAFEPATH') != '1':
        raise ValueError('Safe interpreter entry is required before recovery actions')
    m = c.bind(args.manifest,args.manifest_sha256,args.source_admission_sha256,args.runtime_admission_sha256)
    with c.owned_lock(HERE/'operator.lock',create_missing=True,nonblocking=True):
        if c.present(HERE/'operator_claim.json'):
            raise ValueError('One recovery coordinator only; no implicit restart or replay')
        c.original_terminal()
        c.recovery_predecessors(m)
        c.check_no_score_or_seal()
        if c.present(HERE/'STOP_OPERATION') or c.present(HERE/'STOP_INFERENCE'):
            raise ValueError('Owner/condition stop before zero-delivery recovery')
        with ExitStack() as locks:
            previous = Path(m['parent_boundary']).parent
            previous_lock = locks.enter_context(c.owned_lock(previous/'operator.lock',nonblocking=True))
            pool_lock = locks.enter_context(c.owned_lock(c.OLD/'pool.lock',nonblocking=True))
            output_lock = locks.enter_context(c.owned_lock(c.OUT/'.runner.lock',nonblocking=True))
            bound = c.zero_delivery_boundary(m,args.manifest_sha256)
            c.bind(args.manifest,args.manifest_sha256,args.source_admission_sha256,args.runtime_admission_sha256)
            if c.present(HERE/'STOP_OPERATION') or c.present(HERE/'STOP_INFERENCE'):
                raise ValueError('Owner/condition stop immediately before sole recovery claim')
            c.create(HERE/'operator_claim.json',{'at_pacific':c.stamp(),'manifest_sha256':args.manifest_sha256,
                'source_admission_sha256':args.source_admission_sha256,'runtime_admission_sha256':args.runtime_admission_sha256,
                'owner_pid':os.getpid(),'owner_start_ticks':Path('/proc/self/stat').read_text().split()[21],
                'maximum_new_GPU_jobs':3,'automatic_further_allocations':False,'zero_benchmark_delivery_replacement_only':True})
            try:
                c.create(HERE/'zero_delivery_recovery_start.json',{'at_pacific':c.stamp(),
                    'zero_delivery_evidence_sha256':m['zero_delivery_evidence_sha256'],
                    'parent_boundary_sha256':m['parent_boundary_sha256'],
                    'failed_replica_jobs':['249822','249823','249824'],'failed_CPU_supervisor_job':'249802',
                    'previous_benchmark_attempts':0,'historical_invalids':4,'untouched':748,
                    'old_STOPs_preserved':True,'request_directory_mode':'0700','permission_mutations':0})
                c.create(HERE/'old_terminal_receipt.json',{'at_pacific':c.stamp(),**c.original_terminal(),
                    'zero_delivery_evidence_sha256':m['zero_delivery_evidence_sha256']})
                c.create(HERE/'quiescent_lock_handoff_receipt.json',{'at_pacific':c.stamp(),
                    'old_job_terminal_receipt_sha256':c.sha(HERE/'old_terminal_receipt.json'),
                    'owner_pid':os.getpid(),'owner_start_ticks':Path('/proc/self/stat').read_text().split()[21],
                    'all_previous_jobs_terminal':True,'previous_coordinator_lock_acquired':True,
                    'old_pool_lock_acquired_after_terminal':True,'canonical_output_lock_acquired_after_terminal':True,
                    'lock_inode_by_path':{str(previous/'operator.lock'):os.fstat(previous_lock.fileno()).st_ino,
                        str(c.OLD/'pool.lock'):os.fstat(pool_lock.fileno()).st_ino,
                        str(c.OUT/'.runner.lock'):os.fstat(output_lock.fileno()).st_ino}})
                bound['old_terminal_receipt_sha256'] = c.sha(HERE/'old_terminal_receipt.json')
                c.create(HERE/'boundary.json',bound)
                c.create(HERE/'preserved_old_progress.json',(c.OUT/'progress.json').read_bytes(),raw=True)
                boundary_sha = c.sha(HERE/'boundary.json')
                admission_sha = wait_boundary_admission(args,boundary_sha)
                # Requests remain0700 throughout. No old STOP or permission is restored.
                for rank in range(3):
                    job = submit(m,args,boundary_sha,admission_sha,rank)
                    status('replica_submitted_not_dispatch_evidence',rank=rank,job_id=job)
                deadline = time.monotonic()+74*3600
                while time.monotonic()<deadline:
                    if c.present(HERE/'STOP_INFERENCE'):
                        raise ValueError('Condition-wide stop; preserve all claims and partial outputs')
                    if all((HERE/'replicas'/str(rank)/'runtime/partition_terminal.json').exists() for rank in range(3)):
                        break
                    status('waiting_three_real_partition_terminal_seals')
                    time.sleep(30)
                else:
                    raise TimeoutError('Bounded replacement wait expired; no further allocation')
                merge(bound,args)
                score(m,args,boundary_sha,admission_sha)
                status('native_scored_waiting_finite_CPU_publication_assembly',score_sha256=c.sha(c.OUT/'scores.json'))
                publication = subprocess.run(['/usr/bin/python3','-P','-B',str(HERE/'publication.py'),
                    '--manifest',str(args.manifest),'--manifest-sha256',args.manifest_sha256,
                    '--source-admission-sha256',args.source_admission_sha256,
                    '--runtime-admission-sha256',args.runtime_admission_sha256,
                    '--boundary-sha256',boundary_sha,'--boundary-admission-sha256',admission_sha],
                    cwd=c.ROOT,timeout=7200)
                if publication.returncode:
                    raise ValueError('Finite CPU publication assembly failed; no automatic replay')
                status('assembled_for_exact_independent_artifact_review',automatic_publication=False)
            except Exception as error:
                c.stop_condition('Coordinator hold: '+type(error).__name__+': '+str(error))
                status('held_exact_failure_no_retry',error_type=type(error).__name__,error=str(error))
                raise


if __name__=='__main__':
    main()
