"""Read-only additive accounting for exactly three external checkpoint jobs.

Preserves v1-v4; unknown/changed/unavailable identities remain counted.
No scheduler mutations, inference, benchmark reads or model-weight hashing.
"""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import subprocess

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
V4_PATH = ROOT / '.local/resource_accounting_20261022/exact_external_jobs_adapter_v4.py'
V4_SHA256 = '843ab31b4a4c28169c0ae60188cafef67f1cf84f253881f80cbf742aee383664'
PROOF_PATH = ROOT / '.local/resource_accounting_20261022/root_external_checkpoint_jobs_review_20261023.json'
PROOF_SHA256 = 'edfc703f1556b0e0c743798c4b91d7396a2cfe84f4c8563ba9466b719490434d'
EXACT_JOB_IDS = frozenset(('248757', '248758', '248759'))
PIN_PAIRS = (('command', 'command_sha256'), ('launch_path', 'launch_sha256'),
    ('manifest_path', 'manifest_sha256'), ('checkpoint_plan_path', 'checkpoint_plan_sha256'),
    ('checkpoint_ready_path', 'checkpoint_ready_sha256'), ('source_ready_path', 'source_ready_sha256'),
    ('merge_receipt_path', 'merge_receipt_sha256'),
    ('other_project_root_authorization_path', 'other_project_root_authorization_sha256'))


def read(path):
    return json.loads(Path(path).read_text())


def load_v4():
    if (V4_PATH != V4_PATH.resolve() or V4_PATH.is_symlink() or not V4_PATH.is_file()
            or hashlib.sha256(V4_PATH.read_bytes()).hexdigest() != V4_SHA256):
        raise ValueError('Preserved v4 source changed')
    spec = importlib.util.spec_from_file_location('_checkpoint_v5_preserved_v4', V4_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def checkpoint_proof(v1):
    if not v1.regular(PROOF_PATH, PROOF_SHA256):
        raise ValueError('Exact root checkpoint resource proof changed or unavailable')
    proof = read(PROOF_PATH)
    if (proof.get('issuer') != '/root' or proof.get('approved') is not True
            or proof.get('role') != 'resource_only_exact_external_job_classification_and_bounded_adapter_authority'
            or proof.get('evaluation_project_GPU_ceiling') != 8
            or proof.get('unknown_jobs_remain_counted') is not True
            or proof.get('no_blanket_workdir_exclusion') is not True):
        raise ValueError('Exact bounded root resource proof required')
    rows = proof.get('jobs', [])
    if len(rows) != 3 or {r.get('job_id') for r in rows} != EXACT_JOB_IDS:
        raise ValueError('Only the three exact reviewed checkpoint jobs are allowed')
    if {r.get('step') for r in rows} != {200, 300, 313}:
        raise ValueError('Each reviewed checkpoint step must occur once')
    for row in rows:
        if (row.get('belongs_to_bio_evaluation_project') is not False
                or type(row.get('gpus_requested')) is not int or row['gpus_requested'] != 1
                or type(row.get('step')) is not int or type(row.get('UID')) is not int
                or type(row.get('exact_submitline')) is not str or not row['exact_submitline']):
            raise ValueError('Invalid exact checkpoint resource identity')
    return proof


def exact_checkpoint_identity(row, raw, identity, v1):
    """Fresh scheduler identity plus exact launch/manifest/export provenance."""
    try:
        for path_key, hash_key in PIN_PAIRS:
            if not v1.regular(identity[path_key], identity[hash_key]):
                return False, 'checkpoint_current_source_or_metadata_changed'
        expected = {'JobId': identity['job_id'], 'JobName': identity['name'],
            'WorkDir': identity['workdir'], 'Command': identity['command'],
            'UserId': 'dongweij(' + str(identity['UID']) + ')'}
        if any(v1.field(raw, key) != value for key, value in expected.items()):
            return False, 'checkpoint_scheduler_identity_mismatch'
        if v1.field(raw, 'NumNodes') not in {'1', '1-1'}:
            return False, 'checkpoint_single_node_mismatch'
        if (row['job_id'], row['name'], row['workdir'], row['command'], row['gpus']) != (
                identity['job_id'], identity['name'], identity['workdir'], identity['command'], 1):
            return False, 'checkpoint_inventory_identity_mismatch'
        gpu = re.search(r'(?:^|,)gres/gpu=([0-9]+)(?:,|$)', v1.field(raw, 'ReqTRES') or '')
        if gpu is None or int(gpu.group(1)) != 1:
            return False, 'checkpoint_one_GPU_request_mismatch'
        submit = re.search(r'(?:^|\s)SubmitLine=(.*?)\s+WorkDir=', raw)
        if submit is None or submit.group(1) != identity['exact_submitline']:
            return False, 'checkpoint_exact_SubmitLine_mismatch'
        if identity.get('allow_same_job_scheduler_requeue_under_identical_source_and_config') is not True:
            if v1.field(raw, 'StartTime') != identity['original_observed_start']:
                return False, 'checkpoint_start_or_requeue_mismatch'
        launch = Path(identity['launch_path'])
        if Path(identity['manifest_path']) != launch.parent / 'manifest.json':
            return False, 'checkpoint_manifest_location_mismatch'
        source = launch.read_text()
        if not all(s in source for s in ('HERE=Path(__file__).resolve().parent',
                "sha(HERE/'manifest.json')!=args.manifest_sha256", "m=read(HERE/'manifest.json')")):
            return False, 'checkpoint_explicit_HERE_manifest_binding_missing'
        commands = [s.strip() for s in Path(identity['command']).read_text().splitlines() if s.strip().startswith('exec ')]
        wanted = ['exec', '/usr/bin/python3', '-B', '-u', str(launch), '--step',
                  str(identity['step']), '--manifest-sha256', identity['manifest_sha256']]
        if len(commands) != 1 or shlex.split(commands[0]) != wanted:
            return False, 'checkpoint_worker_step_or_manifest_mismatch'
        m = read(identity['manifest_path'])
        selected = [c for c in m['checkpoints'] if c['step'] == identity['step']]
        if len(selected) != 1:
            return False, 'checkpoint_manifest_step_not_unique'
        c = selected[0]; home = Path(c['directory'])
        if (home != home.resolve() or Path(identity['command']) != home / 'worker.sbatch'
                or Path(identity['checkpoint_plan_path']) != home / 'plan.json'
                or Path(identity['checkpoint_ready_path']) != home / 'ready.json'
                or c['plan_sha256'] != identity['checkpoint_plan_sha256']
                or c['ready_sha256'] != identity['checkpoint_ready_sha256']):
            return False, 'checkpoint_selected_plan_or_ready_mismatch'
        auth_path = identity['other_project_root_authorization_path']
        if (m['root_authorization'] != auth_path
                or m['root_authorization_sha256'] != identity['other_project_root_authorization_sha256']):
            return False, 'checkpoint_other_project_authorization_binding_mismatch'
        for path_key, hash_key in PIN_PAIRS[1:]:
            if path_key != 'manifest_path' and m['fixed_files'].get(identity[path_key]) != identity[hash_key]:
                return False, 'checkpoint_manifest_fixed_metadata_pin_mismatch'
        worker = home / 'worker.py'
        if not v1.regular(worker, m['fixed_files'].get(str(worker))):
            return False, 'checkpoint_selected_worker_changed'
        plan = read(identity['checkpoint_plan_path']); ready = read(identity['checkpoint_ready_path'])
        derived = Path(identity['derived_model_path'])
        if (not derived.is_absolute() or derived != derived.resolve() or not derived.is_dir()
                or not (home / 'merged_model').is_symlink() or (home / 'merged_model').resolve() != derived
                or c['reused_model_path'] != str(derived) or plan['reused_model_path'] != str(derived)
                or ready['source_model_path'] != str(derived) or plan['checkpoint_step'] != identity['step']
                or ready['checkpoint_step'] != identity['step'] or ready['status'] != 'reused_verified_cpu_export'
                or ready['final_plan_sha256'] != identity['checkpoint_plan_sha256']):
            return False, 'checkpoint_derived_model_provenance_mismatch'
        sr_path = Path(identity['source_ready_path']); sr = read(sr_path)
        if (sr_path != Path(ready['source_directory']) / 'ready.json'
                or ready['source_ready_sha256'] != identity['source_ready_sha256']
                or derived.parent != sr_path.parent or sr['checkpoint_step'] != identity['step']
                or sr['status'] != 'completed' or sr['CPU_only'] is not True
                or Path(identity['merge_receipt_path']) != sr_path.parent / 'merge_receipt.json'
                or sr['merge_receipt_sha256'] != identity['merge_receipt_sha256']):
            return False, 'checkpoint_source_ready_merge_binding_mismatch'
        merge = read(identity['merge_receipt_path']); authorization = read(auth_path)
        authorized = [c for c in authorization['checkpoints'] if c['step'] == identity['step']]
        if (len(authorized) != 1 or merge['status'] != 'completed' or merge['CPU_only'] is not True
                or merge['source_checkpoint'] != authorized[0]['path']
                or authorization['external_baseline_job_id'] != '248533'
                or authorization['preserve_external_baseline'] is not True
                or authorization['no_more_epochs'] is not True):
            return False, 'checkpoint_separate_scope_authorization_mismatch'
        for filename in ('adapter_config.json', 'adapter_model.safetensors'):
            if merge['source_files'][filename]['sha256'] != authorized[0]['files'][filename]['sha256']:
                return False, 'checkpoint_recorded_adapter_provenance_mismatch'
        return True, 'exact_checkpoint_identity_launch_manifest_step_derived_export_and_separate_scope_verified'
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return False, 'checkpoint_identity_or_provenance_verification_unavailable'


def overlay_checkpoint_inventory(audit, proof, fresh_raw, v1):
    result = copy.deepcopy(audit); identities = {r['job_id']: r for r in proof['jobs']}
    for row in result['jobs']:
        if row['job_id'] not in identities:
            continue
        raw = fresh_raw.get(row['job_id'])
        matched, reason = (exact_checkpoint_identity(row, raw, identities[row['job_id']], v1)
            if isinstance(raw, str) else (False, 'fresh_checkpoint_scheduler_query_unavailable'))
        result['exact_identity_observations'].append(dict(job_id=row['job_id'], verified_unrelated=matched, reason=reason))
        if matched:
            row['counted_toward_evaluation_project'] = False
            row['scope_basis'] = 'exact_root_checkpoint_launch_manifest_and_derived_model_provenance'
            result['verified_new_unrelated_job_ids'].append(row['job_id'])
    count = sum(r['gpus'] for r in result['jobs'] if r['counted_toward_evaluation_project'])
    addition = result['additional_GPUs']
    result.update(resource_adapter_version=5,
        conservative_project_requested_GPUs_before_checkpoint_review=audit['project_requested_GPUs'],
        project_requested_GPUs=count, project_requested_GPUs_with_addition=count + addition,
        capacity_available=count + addition <= 8, root_checkpoint_proof=str(PROOF_PATH),
        root_checkpoint_proof_sha256=PROOF_SHA256, unknown_jobs_remain_counted=True,
        scheduler_mutations=0, model_calls=0, model_weight_files_read=0)
    return result


def overlay_existing_root_single_node_alias(audit, proof, fresh_raw, v1):
    """Literal 1-1 means one node; retain every other original v1 check."""
    result = copy.deepcopy(audit)
    identities = {item['job_id']: item for item in proof['jobs']}
    observations = []
    for row in result['jobs']:
        identity = identities.get(row['job_id'])
        raw = fresh_raw.get(row['job_id'])
        if identity is None or not isinstance(raw, str) or v1.field(raw, 'NumNodes') != '1-1':
            continue
        normalized, count = re.subn(r'(?<!\S)NumNodes=1-1(?=\s|$)', 'NumNodes=1', raw)
        if count != 1:
            matched, reason = False, 'single_node_alias_field_not_unique'
        else:
            matched, reason = v1.exact_external_identity(row, normalized, identity)
        observation = dict(job_id=row['job_id'], verified_unrelated=matched, reason=reason,
            semantic_normalization={'field': 'NumNodes', 'observed': '1-1', 'checked_as': '1'})
        observations.append(observation)
        result['exact_identity_observations'].append(observation)
        if matched:
            row['counted_toward_evaluation_project'] = False
            row['scope_basis'] = 'preserved_v1_exact_root_identity_with_literal_single_node_range_normalization'
            if row['job_id'] not in result['verified_new_unrelated_job_ids']:
                result['verified_new_unrelated_job_ids'].append(row['job_id'])
        else:
            row['counted_toward_evaluation_project'] = True
    count = sum(row['gpus'] for row in result['jobs'] if row['counted_toward_evaluation_project'])
    addition = result['additional_GPUs']
    result.update(project_requested_GPUs=count, project_requested_GPUs_with_addition=count + addition,
        capacity_available=count + addition <= 8, single_node_range_normalization_observations=observations)
    return result


def capacity_audit(additional=1, override=False, runner=None, require_own_job=False,
                   additional_root_proofs=(), additional_proof_binding=None):
    v4 = load_v4(); v1 = v4.load_v2().load_v1(); proof = checkpoint_proof(v1)
    runner = runner or subprocess.run
    audit = v4.capacity_audit(additional=additional, override=override, runner=runner,
        require_own_job=False, additional_root_proofs=additional_root_proofs,
        additional_proof_binding=additional_proof_binding)
    existing_root_proof = v1.root_proof()
    fresh_ids = EXACT_JOB_IDS | {item['job_id'] for item in existing_root_proof['jobs']}
    fresh = {}
    for row in audit['jobs']:
        if row['job_id'] not in fresh_ids:
            continue
        try:
            fresh[row['job_id']] = runner(['scontrol', 'show', 'job', '-o', row['job_id']],
                capture_output=True, text=True, check=True, timeout=30).stdout
        except (OSError, subprocess.SubprocessError):
            fresh[row['job_id']] = None
    normalized = overlay_existing_root_single_node_alias(audit, existing_root_proof, fresh, v1)
    result = overlay_checkpoint_inventory(normalized, proof, fresh, v1)
    if require_own_job:
        own = os.environ.get('SLURM_JOB_ID')
        if not own:
            raise ValueError('Actual own Slurm allocation required')
        helper = v1.load_module('_checkpoint_v5_own_helper', v1.HELPER, v1.HELPER_SHA256)
        verified = helper.evaluate_inventory(result['jobs'], own_job_id=own, additional_gpus=additional)
        result.update(own_job_id=verified['own_job_id'], own_allocation_verified=True)
    return result


def conservative_project_gpu_audit(*, require_own_job=False, additional_gpus=0,
                                   additional_root_proofs=(), additional_proof_binding=None):
    return capacity_audit(additional=additional_gpus, override=False, require_own_job=require_own_job,
        additional_root_proofs=additional_root_proofs, additional_proof_binding=additional_proof_binding)
