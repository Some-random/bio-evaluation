"""One offline P15 scoring entry after the recorded pre-scorer launch failure.

The original continuation wrapper, native scorer, inputs and predictions stay
unchanged. This launcher cannot serve a model or resume generation.
"""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import sys

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
HERE = Path(__file__).resolve().parent


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def create(path, value):
    with Path(path).open('xb') as stream:
        stream.write((json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode())
        stream.flush()
        os.fsync(stream.fileno())


def validate_predecessor(record, job_id):
    if (record.get('original_job_id') != '243179'
            or record.get('original_job_state') != 'TIMEOUT'
            or record.get('successor_job_id') != '243499'
            or record.get('new_inference_calls') != 0
            or job_id != '243499'):
        raise ValueError('Exact recorded terminal predecessor and existing successor required')


def validate_failure(status, log, completion):
    if (status.get('stage') != 'failed_no_retry' or status.get('exit_code') != 1
            or status.get('score_sha256') is not None
            or 'predecessor = predecessor_terminal' not in log
            or not log.rstrip().endswith('ValueError: Cannot verify predecessor terminal state')
            or 'score_deepfri_catalog_20261020.py' in log):
        raise ValueError('Only the exact pre-scorer launch failure is recoverable')
    if (completion.get('task_id') != 'P15' or completion.get('planned') != 3416
            or completion.get('terminal') != 3416 or completion.get('delivery_passed') != 3416
            or completion.get('biological_correctness_assessed') is not False
            or completion.get('all_passed') is not True):
        raise ValueError('Complete unscored sealed P15 condition required')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def execute(plan_path, plan_sha):
    if sha(plan_path) != plan_sha:
        raise ValueError('Recovery plan changed')
    plan = read(plan_path)
    if (plan.get('task_id') != 'P15' or plan.get('new_inference_authorized') is not False
            or plan.get('native_scorer_changed') is not False
            or plan.get('wrapper_sha256') != sha(__file__)):
        raise ValueError('Exact offline-only recovery plan required')
    for name, expected in plan['files_sha256'].items():
        path = Path(name)
        if path.is_symlink() or not path.is_file() or sha(path) != expected:
            raise ValueError('Frozen recovery support changed: ' + name)
    validate_predecessor(read(plan['predecessor_receipt']), os.environ.get('SLURM_JOB_ID'))
    validate_failure(read(plan['failed_status']), Path(plan['failed_log']).read_text(),
                     read(plan['completion']))
    if socket.gethostname() != plan['hostname']:
        raise ValueError('Existing successor node required')
    score = Path(plan['score_output'])
    if score.exists() or score.with_name('scores.per_case.json').exists():
        raise FileExistsError('Existing native score must never be recomputed')
    continuation = load(plan['continuation_wrapper'], 'frozen_P15_continuation')
    manifest = continuation.validate_manifest(plan['continuation_manifest'],
                                              plan['continuation_manifest_sha256'])
    continuation.identity_valid(manifest, read(plan['successor_identity']))
    helper = load(manifest['scoring_helper'], 'frozen_P15_CPU_scoring_helper')
    helper.BASE = Path(manifest['runtime_root']).parent
    helper.validate(manifest['dispatch_plan'], manifest['dispatch_plan_sha256'], 'P15')
    with (HERE / 'recovery.lock').open('a') as repair_lock, \
            (score.parent / '.runner.lock').open('a') as runner_lock:
        fcntl.flock(repair_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(runner_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if score.exists() or score.with_name('scores.per_case.json').exists():
            raise FileExistsError('Score appeared before exclusive native entry')
        create(HERE / 'scorer_entry_claim.json', {
            'at_UTC': datetime.now(timezone.utc).isoformat(), 'plan_sha256': plan_sha,
            'job_id': os.environ['SLURM_JOB_ID'], 'native_scorer_attempt': 1,
            'failed_prior_child_entered_native_scorer': False,
            'prediction_lock_sha256': sha(score.parent / 'prediction_lock.json'),
            'new_inference_calls': 0, 'automatic_retry': False})
        sys.argv = [manifest['scoring_helper'], '--plan', manifest['dispatch_plan'],
                    '--plan-sha256', manifest['dispatch_plan_sha256'], '--task', 'P15']
        code = None
        try:
            helper.main()
            code = 0
        except SystemExit as error:
            code = error.code if isinstance(error.code, int) else 1
        finally:
            create(HERE / 'native_entry_receipt.json', {
                'at_UTC': datetime.now(timezone.utc).isoformat(), 'plan_sha256': plan_sha,
                'exit_code': code, 'score_exists': score.is_file(),
                'score_sha256': sha(score) if score.is_file() else None,
                'automatic_retry': False, 'new_inference_calls': 0})
        if code:
            raise SystemExit(code)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha256', required=True)
    args = parser.parse_args()
    execute(args.plan, args.plan_sha256)
