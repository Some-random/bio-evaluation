"""Stage nine exact P15 result/question/source/trajectory paths; no publication."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tarfile

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
HERE = Path(__file__).resolve().parent
BASE = ROOT / '.local/catalog_execution_2026-10-20'
TASK = BASE / 'tasks/P15'
RUN = 'qwen38_27b_p15_full_test_dense3dp_nonthinking16k_2026-10-20_v1'
STAGE = HERE / 'publication_stage'
CONFIG_SHA = '91fd6f05fae68efc35846c9f718f376c63e5fc77560fb9875f454d6803bea66d'
SCORE_SHA = 'c382b322270d5c4a213d593ff44b050dc15952df1678d6f7b4db4a7810adbd5e'
LOCK_SHA = '5a302c36e8d8d09f0cdefbf792465ca853420a23ed4e7420e0ac53755de3b09c'
PREFIX = 'results/runs/' + RUN + '/'
REPORT = 'reports/P15_CC_DENSE_CONFIDENCE_RESULT_2026-10-22.md'
QUESTION = 'reports/questions/P15.md'
ARCHIVE = 'results/trajectory_archives/' + RUN + '.tar.gz'
MEMBERS = ARCHIVE.replace('.tar.gz', '.manifest.json')
ALLOWED = {PREFIX + n for n in ('result.json', 'scores.json', 'completion.json',
                               'prediction_lock.json', 'README.md')} | {REPORT, QUESTION, ARCHIVE, MEMBERS}


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            value.update(block)
    return value.hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False,
                       allow_nan=False) + '\n').encode()


def create(path, raw):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def main():
    if STAGE.exists():
        raise FileExistsError('Preserve existing staged bytes; no automatic reassembly')
    config_path = TASK / 'full_test_config.json'
    config = read(config_path)
    folder = TASK / 'runtime/benchmark'
    score, done, lock = (read(folder / name) for name in
                         ('scores.json', 'completion.json', 'prediction_lock.json'))
    recovery = read(HERE / 'native_entry_receipt.json')
    approval = read(HERE / 'root_independent_review.json')
    plan = read(HERE / 'plan.json')
    if (sha(config_path) != CONFIG_SHA or sha(folder / 'scores.json') != SCORE_SHA
            or sha(folder / 'prediction_lock.json') != LOCK_SHA
            or score['prediction_lock_sha256'] != LOCK_SHA
            or done['prediction_lock_sha256'] != LOCK_SHA
            or score['planned'] != 3416 or score['parsed'] != 3416
            or score['invalid_or_missing'] != 0 or not score['full_planned_primary_metrics_valid']
            or done['terminal'] != 3416 or done['responses_saved'] != 3416
            or recovery['exit_code'] != 0 or recovery['score_sha256'] != SCORE_SHA
            or approval['issuer'] != '/root' or approval['review_passed'] is not True
            or approval['plan_sha256'] != sha(HERE / 'plan.json')
            or approval['wrapper_sha256'] != sha(HERE / 'recover.py')):
        raise ValueError('Require exact root-reviewed single native score and complete P15 cohort')
    for name, expected in plan['files_sha256'].items():
        if Path(name).is_symlink() or sha(name) != expected:
            raise ValueError('Frozen recovery evidence changed: ' + name)
    spec = importlib.util.spec_from_file_location('P15_publication_scanner', ROOT / 'scripts/daily_backup.py')
    scanner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scanner)
    pairs = {}

    def add(name, path, expected=None):
        path = Path(path)
        if (Path(name).is_absolute() or '..' in Path(name).parts or name in pairs
                or path.is_symlink() or not path.is_file()
                or path.resolve() == Path(config['scorer_reference_file']).resolve()):
            raise ValueError('Unsafe, duplicate or reference-bearing archive member')
        digest = sha(path)
        if expected is not None and digest != expected:
            raise ValueError('Original frozen bytes changed: ' + name)
        scanner.scan_file(path)
        pairs[name] = {'path': path, 'bytes': path.stat().st_size, 'sha256': digest}

    for phase in ('benchmark', 'development'):
        phase_dir = TASK / 'runtime' / phase
        phase_lock = read(phase_dir / 'prediction_lock.json')
        phase_done = read(phase_dir / 'completion.json')
        if (phase_lock['reference_labels_opened'] is not False
                or phase_done['prediction_lock_sha256'] != sha(phase_dir / 'prediction_lock.json')
                or phase_done['planned'] != (3416 if phase == 'benchmark' else 12)
                or phase_done['terminal'] != phase_done['planned']):
            raise ValueError('Original full phase seal differs')
        for category in ('requests', 'responses', 'outcomes', 'errors'):
            actual = {str(p.relative_to(phase_dir)) for p in (phase_dir / category).glob('*') if p.is_file()}
            sealed = {n for n in phase_lock['files_sha256'] if n.startswith(category + '/')}
            if actual != sealed:
                raise ValueError('Unsealed or missing original phase member')
        for name, digest in phase_lock['files_sha256'].items():
            add('runtime/' + phase + '/' + name, phase_dir / name, digest)
        for name in ('prediction_lock.json', 'completion.json'):
            add('runtime/' + phase + '/' + name, phase_dir / name)
    for name in ('scores.json', 'scores.per_case.json'):
        add('runtime/benchmark/' + name, folder / name)
    for phase_config in ('full_test_config.json', 'validation_delivery_config.json'):
        cfg_path = TASK / phase_config
        cfg = read(cfg_path)
        add('task/' + phase_config, cfg_path)
        for key, expected in (('input_file', 'input_sha256'), ('review_file', 'review_sha256'),
                              ('vocabulary_file', 'vocabulary_sha256')):
            p = Path(cfg[key]); name = 'task/' + p.name
            if name not in pairs:
                add(name, p, cfg[expected])
            elif pairs[name]['sha256'] != cfg[expected]:
                raise ValueError('Phase source-name collision')
    add('sources/native_torchdrug_metric.py', Path(config['metric_source_file']), config['metric_source_sha256'])
    for name in ('prepare_p15_catalog_20261020.py', 'run_deepfri_catalog_20261020.py',
                 'score_deepfri_catalog_20261020.py', 'score_catalog_in_runtime_20261020.py',
                 'continue_seven_catalog_20261020.py', 'serve_catalog_20261020.py'):
        add('scripts/' + name, ROOT / 'scripts' / name)
    continuation = BASE / 'continuation_v1'
    for name in ('manifest.json', 'pool_plan.json', 'pool.sbatch', 'submission_receipt.json',
                 'request_permission_drain.json', 'runtime/predecessor_terminal_receipt.json',
                 'runtime/runtime_version_manifest.json', 'runtime/server_identity.json',
                 'runtime/P15_boundary.json', 'runtime/queue/P15_benchmark_continuation1.grant.json',
                 'runtime/queue/P15_benchmark_continuation1.started.json',
                 'runtime/queue/P15_benchmark_continuation1.finished.json'):
        add('continuation/' + name, continuation / name)
    for name in ('P15_scoring_status.json', 'P15_scoring.log', 'seven_dispatch_plan_v3.json'):
        add('control/' + name, BASE / 'control' / name)
    for name in ('recover.py', 'test_recovery.py', 'plan.json', 'planned_command.json',
                 'operational_failure_observation.json', 'root_independent_review.json',
                 'launch_claim.json', 'launch_receipt.json', 'scorer_entry_claim.json',
                 'native_entry_receipt.json', 'native_scoring.log', 'assemble_publication.py'):
        add('offline_scoring_recovery/' + name, HERE / name)
    total = sum(row['bytes'] for row in pairs.values())
    if total > 256 * 1024**2:
        raise ValueError('Archive exceeds scanner uncompressed boundary')
    with Path(config['input_file']).open() as stream:
        first = json.loads(stream.readline())
    request_name = 'requests/' + hashlib.sha256(first['case_id'].encode()).hexdigest() + '.json'
    request_path = folder / request_name
    request = read(request_path)
    if (sha(request_path) != lock['files_sha256'][request_name]
            or request['messages'] != first['messages'] or len(request['messages']) != 1
            or request['messages'][0]['role'] != 'user'):
        raise ValueError('Verbatim saved reference-free first input required')
    prompt = request['messages'][0]['content']
    heading = 'Predict Gene Ontology cellular-component annotation for the protein from its complete amino acid sequence.'
    if not prompt.startswith(heading):
        raise ValueError('Unexpected P15 task question')
    question = ('# DeepFRI / ProtST: cellular component — complete evaluated input\n\n'
                'Verbatim saved user message, including the complete amino-acid sequence and all 320 ordered GO descriptions. '
                'No reference labels or model answer are included.\n\n'
                f"Case: `{first['case_id']}`. Cohort: all 3,416 released test95 full-FASTA sequences.\n\n"
                f"Saved request SHA-256: `{sha(request_path)}`. Prediction lock SHA-256: `{LOCK_SHA}`.\n\n"
                '## User message\n\n```text\n' + prompt + '\n```\n\n'
                '[Result](../P15_CC_DENSE_CONFIDENCE_RESULT_2026-10-22.md) · '
                '[Main results](../RESULTS_AND_REMAINING_WORK.md)\n').encode()
    summary = {'task_id': 'P15', 'run_id': RUN, 'planned': 3416, 'parsed': 3416,
               'invalid_or_missing': 0, 'metrics': score['metrics'],
               'condition': config['variant'], 'model': config['model'],
               'revision': config['model_revision'], 'class_count': 320,
               'native_formula_preserved': True, 'matched_ProtST_replication': False,
               'score_sha256': SCORE_SHA, 'prediction_lock_sha256': LOCK_SHA,
               'new_inference_calls_by_packaging': 0, 'new_scoring_calls_by_packaging': 0,
               'scoring_recovery': 'Expired predecessor Slurm cache blocked launcher before native entry; root-reviewed launch-only repair ran the unchanged scorer once.',
               'comparison_limit': 'Zero-shot full-FASTA text adaptation, not trained DeepFRI/ProtST representations or its PDB-modeled subset.',
               'explanation_support_assessed': False, 'public_pretraining_exposure': 'unknown'}
    report = ('# P15: Gene Ontology cellular-component annotation\n\n'
              '**Qwen3.8-27B BF16: micro AUPRC 0.0370570570230484; Fmax 0.07158192247152328.** '
              'All 3,416 released test95 cases scored; 3,416 valid confidence vectors and zero invalid or missing outputs.\n\n'
              'The model received complete FASTA sequences and 320 fixed, ordered GO descriptions, with one nonthinking '
              'generation per case and a 16,384-token output cap. Native TorchDrug micro AUPRC and Fmax formulas, float32 '
              'scores and native tie order are preserved. No threshold tuning, ontology score propagation or case filtering was applied.\n\n'
              '[Complete saved question, sequence and 320 GO descriptions](questions/P15.md). '
              f'[Exact score](../{PREFIX}scores.json), [source and raw trajectory archive](../{ARCHIVE}) '
              f'and [member manifest](../{MEMBERS}).\n\n'
              'This is a zero-shot full-FASTA text adaptation. It does not reproduce trained DeepFRI/ProtST heads, learned '
              'representations or the native PDB-modeled input subset. The common metric formulas permit a qualified comparison; '
              'the input and training protocols differ. [DeepFRI (2021)](https://doi.org/10.1038/s41467-021-23303-9); '
              '[ProtST (2023)](https://proceedings.mlr.press/v202/xu23t.html). Explanation support is unassessed and prior '
              'pretraining exposure is unknown.\n\n'
              'The original scoring launcher failed before loading the native scorer because its predecessor job had left '
              'Slurm’s live cache. A separately recorded, root-reviewed launch repair used the unchanged scorer once, on CPUs '
              'inside the existing successor allocation. Original failed evidence and all prediction seals are retained. '
              'No additional model calls or output repairs were made.\n').encode()
    create(STAGE / QUESTION, question)
    create(STAGE / REPORT, report)
    create(STAGE / (PREFIX + 'result.json'), encode(summary))
    create(STAGE / (PREFIX + 'README.md'), ('# P15 complete dense-confidence condition\n\n'
           'See [the result report](../../../' + REPORT + '). Complete3416-case full-FASTA adaptation; native metric formulas, '
           'separate original failure and root-reviewed CPU launch recovery. The archive includes exact raw benchmark and '
           '12 development requests/responses/outcomes, input/configuration/code and scoring provenance. Scorer target values, '
           'weights, credentials, environments and caches are excluded. Reproduction requires the pinned reference release '
           'and relocation of recorded source paths.\n').encode())
    for name in ('scores.json', 'completion.json', 'prediction_lock.json'):
        create(STAGE / (PREFIX + name), (folder / name).read_bytes())
    archive = STAGE / ARCHIVE
    archive.parent.mkdir(parents=True, exist_ok=True)
    inventory = {}
    with tarfile.open(archive, 'w:gz') as output:
        for name, record in sorted(pairs.items()):
            if sha(record['path']) != record['sha256']:
                raise ValueError('Source changed before archive capture')
            output.add(record['path'], arcname=name, recursive=False)
            inventory[name] = {'bytes': record['bytes'], 'sha256': record['sha256'],
                               'original_source': str(record['path'])}
    observed = {}
    with tarfile.open(archive) as output:
        for member in output:
            if not member.isfile() or member.name in observed:
                raise ValueError('Archive requires unique regular file members')
            data = output.extractfile(member).read()
            observed[member.name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    if observed != {n: {k: r[k] for k in ('bytes', 'sha256')} for n, r in inventory.items()}:
        raise ValueError('Archive capture differs from original exact source inventory')
    scanner.scan_file(archive)
    manifest = {'schema_version': 1, 'task_id': 'P15', 'run_id': RUN,
                'archive_sha256': sha(archive), 'member_count': len(inventory),
                'uncompressed_member_bytes': total, 'members': inventory,
                'prediction_lock_sha256': LOCK_SHA, 'score_sha256': SCORE_SHA,
                'full_denominator': 3416, 'development_delivery_denominator': 12,
                'scorer_reference_values_included': False, 'weights_or_credentials_included': False,
                'new_model_calls': 0, 'new_scoring_calls': 0}
    create(STAGE / MEMBERS, encode(manifest))
    actual = {str(p.relative_to(STAGE)) for p in STAGE.rglob('*') if p.is_file()}
    if actual != ALLOWED:
        raise ValueError('Exact nine public paths required')
    for name in ALLOWED:
        if (STAGE / name).stat().st_size >= 90 * 1024**2:
            raise ValueError('Public file exceeds Git size boundary')
        scanner.scan_file(STAGE / name)
    capture = {'schema_version': 1, 'at_UTC': datetime.now(timezone.utc).isoformat(),
               'owner': '/root/independent_review', 'repository': 'Some-random/bio-evaluation',
               'visibility': 'public', 'stage': str(STAGE), 'task_id': 'P15', 'run_id': RUN,
               'files_sha256': {name: sha(STAGE / name) for name in sorted(ALLOWED)},
               'member_manifest': MEMBERS, 'scans_passed': True,
               'question': {'case_id': first['case_id'], 'request_source': str(request_path),
                            'request_sha256': sha(request_path), 'verbatim_actual_user_message': True},
               'metrics': score['metrics'], 'planned': 3416, 'parsed': 3416,
               'source_script_sha256': sha(__file__), 'automatic_publication': False,
               'new_model_calls': 0, 'new_scoring_calls': 0, 'aggregate_documents_modified': False}
    create(HERE / 'publication_manifest.json', encode(capture))
    print(json.dumps({'manifest': str(HERE / 'publication_manifest.json'),
                      'sha256': sha(HERE / 'publication_manifest.json'),
                      'archive_sha256': sha(archive), 'members': len(inventory),
                      'uncompressed_bytes': total}))


if __name__ == '__main__':
    main()
