"""Invented metadata tests; no biological inputs, references or model calls."""
import unittest
import recover


class RecoveryTests(unittest.TestCase):
    def test_persisted_terminal_predecessor_can_outlive_slurm_cache(self):
        recover.validate_predecessor({'original_job_id': '243179',
            'original_job_state': 'TIMEOUT', 'successor_job_id': '243499',
            'new_inference_calls': 0}, '243499')

    def test_wrong_or_running_predecessor_and_different_allocation_reject(self):
        good = {'original_job_id': '243179', 'original_job_state': 'TIMEOUT',
                'successor_job_id': '243499', 'new_inference_calls': 0}
        for field, value in [('original_job_id', 'another'),
                             ('original_job_state', 'RUNNING'),
                             ('successor_job_id', 'another'), ('new_inference_calls', 1)]:
            with self.subTest(field=field), self.assertRaises(ValueError):
                recover.validate_predecessor({**good, field: value}, '243499')
        with self.assertRaises(ValueError):
            recover.validate_predecessor(good, None)

    def test_only_known_pre_scorer_failure_and_full_unscored_cohort_pass(self):
        status = {'stage': 'failed_no_retry', 'exit_code': 1, 'score_sha256': None}
        log = 'predecessor = predecessor_terminal\nValueError: Cannot verify predecessor terminal state\n'
        completion = {'task_id': 'P15', 'planned': 3416, 'terminal': 3416,
                      'delivery_passed': 3416, 'biological_correctness_assessed': False,
                      'all_passed': True}
        recover.validate_failure(status, log, completion)
        for changed in ({**status, 'score_sha256': 'already_scored'},
                        {**status, 'exit_code': 0}):
            with self.assertRaises(ValueError):
                recover.validate_failure(changed, log, completion)
        for changed in ({**completion, 'terminal': 3415},
                        {**completion, 'biological_correctness_assessed': True}):
            with self.assertRaises(ValueError):
                recover.validate_failure(status, log, changed)
        with self.assertRaises(ValueError):
            recover.validate_failure(status, 'failure inside score_deepfri_catalog_20261020.py', completion)


if __name__ == '__main__':
    unittest.main()
