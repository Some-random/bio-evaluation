import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from run_visible_extraction import analyze


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        self.plan={'planned':2,'task_id':'P01','run_id':'synthetic','model':'synthetic','model_revision':'synthetic','kind':'binary','original_case_set_verified':True,'source_case_contract_sha256':'synthetic_case_contract','slots':[]}
        for case,text in [('s1','Answer: Yes'),('s2','Yes or no')]:
            p=self.root/(case+'.json');raw={'case_id':case,'task':'P01','model':'synthetic','model_revision':'synthetic','status':'completed','text':text,'finish_reason':'stop','response':{'choices':[{'message':{'content':text,'reasoning':'Answer: No'},'finish_reason':'stop'}]}};p.write_text(json.dumps(raw));self.plan['slots'].append({'case_id':case,'response_path':str(p),'response_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
        self.path=self.root/'plan.json';self.write()
    def write(self):self.path.write_text(json.dumps(self.plan))
    def test_all_slots_kept_and_reasoning_unused(self):
        result=analyze(self.path);self.assertEqual(len(result['rows']),2);self.assertEqual(result['counts']['extracted'],1);self.assertEqual(result['rows'][0]['value'],'yes');self.assertIsNone(result['rows'][1]['value']);self.assertFalse(result['correctness_computed'])
    def test_tampered_output_refused(self):
        Path(self.plan['slots'][0]['response_path']).write_text('{}')
        with self.assertRaisesRegex(ValueError,'changed'):analyze(self.path)
    def test_wrong_count_refused(self):
        self.plan['planned']=3;self.write()
        with self.assertRaisesRegex(ValueError,'every unique'):analyze(self.path)
    def test_no_full_case_proof_refused(self):
        self.plan['original_case_set_verified']=False;self.write()
        with self.assertRaisesRegex(ValueError,'full case-set'):analyze(self.path)
    def test_missing_slot_retained(self):
        Path(self.plan['slots'][1]['response_path']).unlink();self.plan['slots'][1]['response_sha256']=None;self.write();result=analyze(self.path);self.assertEqual(len(result['rows']),2);self.assertEqual(result['counts']['missing_original_slot'],1)
    def test_raw_final_mismatch_refused(self):
        slot=self.plan['slots'][0];path=Path(slot['response_path']);r=json.loads(path.read_text());r['text']='Answer: No';path.write_text(json.dumps(r));slot['response_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();self.write()
        with self.assertRaisesRegex(ValueError,'Raw visible'):analyze(self.path)


if __name__=='__main__':unittest.main()
