"""Apply frozen final extraction to a complete hash-locked historical case set.

Produces delivery diagnostics only; never reads references or computes accuracy.
All original case slots stay in the output. Never overwrites native files.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
from extraction_rules_v1 import VERSION, extract_final


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def analyze(plan_path):
    plan_path = Path(plan_path)
    plan = json.loads(plan_path.read_text())
    freeze = json.loads((Path(__file__).parent / 'extraction_rules_freeze_v1.json').read_text())
    for name, expected in freeze['files_sha256'].items():
        if sha((Path(__file__).parent / name).read_bytes()) != expected:
            raise ValueError('Frozen extraction dependency changed')
    ids = [slot['case_id'] for slot in plan['slots']]
    if len(ids) != plan['planned'] or len(set(ids)) != len(ids) or not ids:
        raise ValueError('Require every unique original planned case slot')
    if plan.get('original_case_set_verified') is not True or not plan.get('source_case_contract_sha256'):
        raise ValueError('Original full case-set proof required')
    counts = Counter(); rows = []
    for slot in plan['slots']:
        path = Path(slot['response_path'])
        expected = slot['response_sha256']
        if expected is None:
            if path.exists():
                raise ValueError('Previously missing response appeared after plan freeze')
            counts['missing_original_slot'] += 1
            rows.append({'case_id': slot['case_id'], 'value': None, 'reason': 'missing_original_slot'})
            continue
        raw = path.read_bytes()
        if sha(raw) != expected:
            raise ValueError('Frozen raw response changed')
        response = json.loads(raw)
        for key, value in [('case_id', slot['case_id']), ('task', plan['task_id']), ('model', plan['model']), ('model_revision', plan['model_revision'])]:
            if response.get(key) != value:
                raise ValueError('Response provenance mismatch: ' + key)
        choices = response.get('response', {}).get('choices', [])
        if response.get('status') == 'completed':
            if len(choices) != 1:
                raise ValueError('Single native response required')
            content = choices[0].get('message', {}).get('content') or ''
            if content != response.get('text') or choices[0].get('finish_reason') != response.get('finish_reason'):
                raise ValueError('Raw visible content does not match saved final')
        else:
            content = ''
        result = extract_final(content, plan['kind'], response.get('status'), response.get('finish_reason'))
        counts[result['reason']] += 1
        counts['extracted'] += result['value'] is not None
        counts['responses_present'] += 1
        rows.append({'case_id': slot['case_id'], **result, 'source_response_sha256': expected})
    return {'version': VERSION, 'task_id': plan['task_id'], 'run_id': plan['run_id'],
            'planned': plan['planned'], 'counts': dict(counts), 'rows': rows,
            'plan_sha256': sha(plan_path.read_bytes()), 'references_read': False,
            'correctness_computed': False, 'native_scores_changed': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.plan)
    with args.output.open('x') as f:
        json.dump(result, f, indent=2)
        f.write('\n')
