import unittest
from extraction_rules_v1 import extract_final


class RuleTests(unittest.TestCase):
    def test_binary_exact_and_wrappers(self):
        for x in ['Yes', 'Yes.', 'no!', '**Yes.**', '`No`', '```text\nYes\n```']:
            self.assertIsNotNone(extract_final(x,'binary')['value'])
    def test_explicit_terminal_binary_after_discussion(self):
        self.assertEqual(extract_final('Discuss yes and no.\nFinal answer: **No.**','binary')['value'],'no')
    def test_unmarked_terminal_is_ambiguous(self):
        self.assertIsNone(extract_final('Discussion.\nYes','binary')['value'])
    def test_both_labels_rejected(self):
        for x in ['Yes or no', 'Answer: Yes, but no', 'No / Yes', 'Answer: Yes No']:
            self.assertIsNone(extract_final(x,'binary')['value'])
    def test_no_substring_matching(self):
        for x in ['yesterday', 'nodule', 'No evidence of a lesion', 'Yes because...']:
            self.assertIsNone(extract_final(x,'binary')['value'])
    def test_mcq_explicit(self):
        for x in ['(D)', 'D.', '**D**','Discuss A and B.\nAnswer: (D)']:
            self.assertEqual(extract_final(x,'mcq_abcd')['value'],'D')
    def test_mcq_nonlabel_rejected(self):
        for x in ['A or D','D because...', 'Answer: B/D', 'Choice D', 'E']:
            self.assertIsNone(extract_final(x,'mcq_abcd')['value'])
    def test_free_text_explicit_only(self):
        self.assertEqual(extract_final('Discussion.\nFinal answer: left kidney','free_text')['value'],'left kidney')
        self.assertIsNone(extract_final('left kidney','free_text')['value'])
    def test_free_text_unmarked_prose_rejected(self):
        self.assertIsNone(extract_final('This looks like an organ.','free_text')['value'])
    def test_nonstop_or_unfinished_never_recovered(self):
        for finish in ['length',None,'tool_calls']:
            self.assertIsNone(extract_final('Answer: Yes','binary',finish_reason=finish)['value'])
        self.assertIsNone(extract_final('Answer: Yes','binary',status='transport_error')['value'])
    def test_empty(self):
        for x in [None,'','  ']:self.assertIsNone(extract_final(x,'binary')['value'])
    def test_no_reference_parameter(self):
        with self.assertRaises(TypeError):extract_final('Answer: Yes','binary',reference='yes')


if __name__=='__main__':unittest.main()
