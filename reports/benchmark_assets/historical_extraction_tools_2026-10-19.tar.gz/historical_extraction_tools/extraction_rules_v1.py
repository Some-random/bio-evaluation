"""Conservative visible-final extraction; frozen before any reference comparison.

No reference argument is accepted. Never inspect hidden reasoning, image labels,
choice semantics or a model's self-assessed correctness.
"""
import re

VERSION = 'HISTORICAL_VISIBLE_FINAL_EXPLICIT_ONLY_V1'


def strip_format(text):
    text = text.strip()
    fence = re.fullmatch(r'```(?:text|plaintext)?\s*\n(.*?)\n```', text, re.S | re.I)
    if fence:
        text = fence[1].strip()
    for wrapper in ('**', '__', '`'):
        if text.startswith(wrapper) and text.endswith(wrapper) and len(text) > 2 * len(wrapper):
            text = text[len(wrapper):-len(wrapper)].strip()
    return text


def explicit_candidate(text):
    if not isinstance(text, str) or not text.strip():
        return None, 'empty_final'
    cleaned = strip_format(text)
    lines = [line.strip() for line in cleaned.splitlines() if line.strip()]
    last = strip_format(lines[-1])
    match = re.fullmatch(r'(?:Final answer|Answer|The answer is)\s*:\s*(.+)', last, re.I)
    if match:
        return strip_format(match[1]), 'explicit_terminal_answer'
    if len(lines) == 1:
        return last, 'whole_single_line'
    return None, 'no_explicit_terminal_answer'


def extract_final(text, kind, status='completed', finish_reason='stop'):
    if status != 'completed':
        return {'value': None, 'reason': 'not_completed'}
    if finish_reason != 'stop':
        return {'value': None, 'reason': 'nonstop_finish_not_recovered'}
    value, reason = explicit_candidate(text)
    if value is None:
        return {'value': None, 'reason': reason}
    if kind == 'binary':
        match = re.fullmatch(r'\(?\s*(Yes|No)\s*\)?[.!]?', value, re.I)
        return {'value': match[1].lower() if match else None,
                'reason': reason if match else 'ambiguous_or_nonbinary_text'}
    if kind == 'mcq_abcd':
        match = re.fullmatch(r'\(?([ABCD])\)?[.:]?', value, re.I)
        return {'value': match[1].upper() if match else None,
                'reason': reason if match else 'ambiguous_or_nonlabel_text'}
    if kind == 'free_text':
        # Prose is recoverable only when explicitly designated as the final
        # answer. An arbitrary one-line narrative is not silently rewritten.
        if reason != 'explicit_terminal_answer':
            return {'value': None, 'reason': 'no_explicit_terminal_answer'}
        if any(token in value for token in ('[ANSWER]', '[/ANSWER]', '```')):
            return {'value': None, 'reason': 'unsupported_markup'}
        return {'value': value, 'reason': reason}
    raise ValueError('Unknown frozen extraction kind')
