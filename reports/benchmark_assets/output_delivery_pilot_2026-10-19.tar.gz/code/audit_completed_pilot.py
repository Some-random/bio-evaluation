"""Offline audit of already-completed synthetic pilot artifacts; no inference."""
import argparse
from collections import Counter
from datetime import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
from zoneinfo import ZoneInfo


def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result


def audit(folder, review):
    folder,review=Path(folder),Path(review)
    plan_raw=(folder/'plan.json').read_bytes();plan=json.loads(plan_raw);completion=load(folder/'completion.json')
    if completion['plan_sha256']!=sha(plan_raw):raise ValueError('Completion plan hash differs')
    if sha((review/'runner_reviewed.py').read_bytes())!=plan['runner_sha256']:raise ValueError('Reviewed runner differs from frozen plan')
    if sha((review/'protein_contract_reviewed.py').read_bytes())!=plan['protein_contract_sha256']:raise ValueError('Reviewed protein contract differs')
    runner=module('reviewed_pilot_runner',review/'runner_reviewed.py');contract=module('reviewed_pilot_contract',review/'protein_contract_reviewed.py')
    cases=plan['cases'];ids=[r['id']for r in cases]
    if len(ids)!=12 or len(set(ids))!=12:raise ValueError('Expected twelve unique frozen cases')
    if {p.stem for p in(folder/'requests').glob('*.json')}!=set(ids):raise ValueError('Request set differs')
    if {p.stem for p in(folder/'responses').glob('*.json')}!=set(ids):raise ValueError('Response set differs')
    progress=load(folder/'progress.json');recorded={r['case_id']:r for r in progress['outcomes']}
    if set(recorded)!=set(ids):raise ValueError('Outcome set differs')
    rows=[];anomalies=[];counts=Counter();hashes={}
    for case in cases:
        name=case['id'];request_path=folder/'requests'/(name+'.json');response_path=folder/'responses'/(name+'.json')
        request=request_path.read_bytes();response=response_path.read_bytes();raw=json.loads(response);outcome=recorded[name]
        if json.loads(request)!=case['payload'] or sha(request)!=outcome['request_sha256'] or sha(response)!=outcome['response_sha256']:raise ValueError('Request/response hash or payload differs')
        if raw.get('model')!=plan['model'] or len(raw.get('choices',[]))!=1:raise ValueError('Wrong response model or completion count')
        choice=raw['choices'][0];message=choice['message'];final=message.get('content');finish=choice.get('finish_reason')
        reasoning=message.get('reasoning',message.get('reasoning_content'))
        present={k:message[k]for k in['reasoning','reasoning_content']if message.get(k)is not None}
        if any(not isinstance(v,str)for v in present.values())or len(set(present.values()))>1:anomalies.append(name+':ambiguous_reasoning_channels')
        if message.get('reasoning')is None and isinstance(message.get('reasoning_content'),str)and 'reasoning'in message:anomalies.append(name+':null_reasoning_shadows_reasoning_content')
        passed=runner.check(case['kind'],final,reasoning,finish,contract)
        if passed!=outcome['passed']:raise ValueError('Independent frozen-validator replay differs')
        actual_prompt=raw.get('usage',{}).get('prompt_tokens')
        if actual_prompt!=case['prompt_tokens']:anomalies.append(name+':server_prompt_count_differs_from_local_count')
        nonempty=isinstance(final,str)and bool(final.strip());extra_protein_keys=None
        if case['kind']=='protein'and nonempty:
            try:
                # Only inspect candidate-bearing final text. Never extract a
                # candidate from the separate reasoning channel.
                candidate=final.split('</think>',1)[-1]
                obj=json.loads(candidate);extra_protein_keys=sorted(set(obj)-{'protein'})if isinstance(obj,dict)else None
                if extra_protein_keys:anomalies.append(name+':native_protein_parser_permits_extra_keys')
            except ValueError:pass
        counts['passed']+=passed;counts['stop_finishes']+=finish=='stop';counts['length_finishes']+=finish=='length';counts['empty_finals']+=not nonempty
        counts['separate_reasoning_present']+=isinstance(reasoning,str)
        rows.append({'case_id':name,'kind':case['kind'],'passed':passed,'prompt_tokens':case['prompt_tokens'],'server_prompt_tokens':actual_prompt,
            'completion_tokens':raw.get('usage',{}).get('completion_tokens'),'finish_reason':finish,'empty_final':not nonempty,
            'reasoning_fields_present':list(present),'elapsed_seconds':outcome.get('elapsed_seconds'),'extra_protein_keys':extra_protein_keys})
        hashes['requests/'+name+'.json']=sha(request);hashes['responses/'+name+'.json']=sha(response)
    if completion.get('completed')!=12 or completion.get('passed')!=counts['passed'] or completion.get('all_passed')!=(counts['passed']==12):raise ValueError('Terminal summary arithmetic differs')
    return {'schema_version':1,'reviewed_at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),'status':'completed_independent_artifact_audit',
        'plan_sha256':sha(plan_raw),'completion_sha256':sha((folder/'completion.json').read_bytes()),'planned':12,'counts':dict(counts),'cases':rows,'anomalies':anomalies,
        'all_passed':counts['passed']==12,'file_sha256':hashes,'acceptance_review':'Final channel required to be nonempty with stop finish and satisfy the frozen toy predicate. Reasoning is never searched for answers. Protein native JSON parser permits extra keys; any observed extra keys are disclosed separately.',
        'limitations':['Synthetic text-delivery checks only; no biological benchmark score or evidence that the full-evaluation configuration is ready.','Toy answers are supplied or straightforward; no substantive biological reasoning is tested.','One sample per interface/length condition; no reliability estimate.','Protein acceptance mirrors the native parser, which is looser than the prompt about additional JSON keys.']}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',type=Path,required=True);parser.add_argument('--review',type=Path,default=Path(__file__).parent);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    result=audit(args.run,args.review)
    with args.output.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({'all_passed':result['all_passed'],'counts':result['counts'],'anomalies':result['anomalies']}))
