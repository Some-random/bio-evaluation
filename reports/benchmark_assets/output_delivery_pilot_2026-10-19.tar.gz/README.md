# Synthetic output-delivery pilot

Twelve fixed toy requests: six output interfaces, each with short and repeated-padding long input. The completed dedicated run passed all twelve frozen predicates. No biological benchmark case or oracle was used.

Reproduce the saved-output audit with Python3, without a model or network:

    python3 code/audit_completed_pilot.py --run pilot --review code --output reproduced_audit.json

The command verifies exact payload/response hashes, single model/completion identity, frozen answer predicates and stored versus API token counts. Compare counts, cases, anomalies and file_sha256 with evidence/completed_audit.json; audit timestamps differ.

Raw final and reasoning fields are retained in pilot/responses. The checker does not extract an answer from reasoning. Protein JSON is passed through the frozen native parser; it permits additional keys, although none appeared.

Evidence also preserves the first attempt: one request entered a shared busy queue, no response was saved, and its outcome remains unknown. That attempt is not one of the twelve completed observations. A separately named dedicated run reused the same twelve payloads. V1 incorrectly counted tokenizer mapping keys as two tokens; independent tokenization fixed the bookkeeping and V2 matches actual API usage.

The repeated neutral padding and prefix cache make these timings unsuitable for benchmark throughput, cost extrapolation or ETA. Passing this toy check does not establish that the full-evaluation configuration is ready. No weights, credentials or runtime caches are included.
