"""Reproduce a separately named, fixed-rule P16 formatting diagnostic offline.

Freeze code/config and synthetic checks before copying/opening reference inputs.
This script never changes a native input, response, parser, score or prediction.
"""
import argparse
from collections import Counter, defaultdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
from zoneinfo import ZoneInfo

ORIGINAL = re.compile(r"\s*(?:Answer\s*:\s*)?(0|[1-9][0-9]{0,2})\.?\s*", re.IGNORECASE)
PLAIN = re.compile(r"(?:Answer\s*:\s*)?(0|[1-9]\d{0,2})\.?", re.IGNORECASE)
BOLD = re.compile(r"\*\*(0|[1-9]\d{0,2})\*\*\.?")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(",", ":")).encode()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write_new(path, value):
    with Path(path).open("x") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def original_parse(text):
    match = ORIGINAL.fullmatch(text or "")
    result = int(match.group(1)) if match else None
    return result if result is not None and result < 384 else None


def choose(text, finish, original_prediction):
    """Fixed before scoring; no target, correctness flag or biological text input."""
    if original_prediction is not None:
        return original_prediction, "retained_original_accepted_prediction"
    if finish != "stop":
        return None, "ineligible_non_stop_finish"
    if not (text or "").strip():
        return None, "ineligible_empty_final"
    last = text.rstrip().splitlines()[-1].strip()
    match = PLAIN.fullmatch(last)
    style = "terminal_bare_or_answer_integer"
    if match is None:
        match = BOLD.fullmatch(last)
        style = "terminal_bold_integer"
    if match is None or int(match.group(1)) >= 384:
        return None, "no_allowed_terminal_class_integer"
    return int(match.group(1)), style


def synthetic_tests():
    checks = [
        ("preserve an accepted prediction", choose("ignored", "length", 8) == (8, "retained_original_accepted_prediction")),
        ("plain terminal class", choose("Explanation\n37", "stop", None)[0] == 37),
        ("Answer terminal class", choose("Explanation\nAnswer: 37.", "stop", None)[0] == 37),
        ("bold terminal class", choose("Explanation\n**37**", "stop", None)[0] == 37),
        ("truncated terminal class stays invalid", choose("Explanation\n37", "length", None)[0] is None),
        ("empty stays invalid", choose(" \n", "stop", None)[0] is None),
        ("class bounds", choose("383", "stop", None)[0] == 383 and choose("384", "stop", None)[0] is None),
        ("ambiguous multiple classes", choose("37 or 38", "stop", None)[0] is None),
        ("number inside prose", choose("The class is 37", "stop", None)[0] is None),
        ("unbalanced Markdown", choose("**37", "stop", None)[0] is None),
        ("no leading zero class", choose("037", "stop", None)[0] is None),
        ("baseline parser", original_parse("Answer: 37.") == 37 and original_parse("Explanation\n37") is None),
    ]
    if not all(ok for _, ok in checks):
        raise ValueError("Synthetic test failure: " + repr(checks))
    return {"passed": True, "count": len(checks), "test_names": [name for name, _ in checks]}


def freeze(base):
    config = base / "protocol.json"
    result = {"schema_version": 1, "diagnostic_variant": read(config)["diagnostic_variant"],
        "frozen_at_pacific": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "code_sha256": sha(__file__), "config_sha256": sha(config),
        "synthetic_tests": synthetic_tests(), "reference_inputs_opened_by_freeze": False,
        "rule_selection": "Exact user-specified normal-stop terminal-number rule; no held-out target feedback."}
    write_new(base / "freeze_receipt.json", result)
    return result


def run(base):
    frozen = read(base / "freeze_receipt.json")
    if sha(__file__) != frozen["code_sha256"] or sha(base / "protocol.json") != frozen["config_sha256"]:
        raise ValueError("Diagnostic code/config changed after freezing")
    cfg = read(base / "protocol.json")
    for binding in cfg["inputs"].values():
        if sha(base / binding["snapshot_path"]) != binding["sha256"]:
            raise ValueError("Frozen input bytes differ: " + binding["snapshot_path"])
    rows = read(base / cfg["inputs"]["per_case_scores"]["snapshot_path"])
    refs = [json.loads(line) for line in (base / cfg["inputs"]["references"]["snapshot_path"]).read_text().splitlines()]
    native = read(base / cfg["inputs"]["native_scores"]["snapshot_path"])
    budgets = read(base / cfg["inputs"]["budget_map"]["snapshot_path"])["budgets_by_raw_filename"]
    expected_ids = ["Reaction:test:" + str(i) for i in range(5651)]
    if [r["case_id"] for r in rows] != expected_ids or [r["case_id"] for r in refs] != expected_ids:
        raise ValueError("Original complete source-order denominator changed")
    counts, budget_counts, decisions, scored = Counter(), defaultdict(Counter), Counter(), []
    for row, ref in zip(rows, refs):
        if row["status"] != "completed" or row["task"] != "P16" or row["target"] != ref["target"]:
            raise ValueError("Frozen row/reference identity or status mismatch")
        original = original_parse(row["raw_text"])
        if original != row["prediction"] or (original is not None) != row["parsed"]:
            raise ValueError("Persisted native parser output differs from frozen parser")
        filename = digest(["P16", cfg["native_protocol_variant"], row["case_id"]]) + ".json"
        budget = budgets[filename]
        predicted, decision = choose(row["raw_text"], row["finish_reason"], original)
        native_correct = original is not None and original == ref["target"]
        diagnostic_correct = predicted is not None and predicted == ref["target"]
        recovered = original is None and predicted is not None
        values = {"planned": 1, "original_accepted": original is not None,
            "original_correct": native_correct, "diagnostic_accepted": predicted is not None,
            "diagnostic_correct": diagnostic_correct, "recovered": recovered,
            "recovered_correct": recovered and diagnostic_correct,
            "length_finishes": row["finish_reason"] == "length",
            "empty_finals": not (row["raw_text"] or "").strip()}
        counts.update(values); budget_counts[str(budget)].update(values); decisions[decision] += 1
        scored.append({"case_id": row["case_id"], "raw_filename": filename, "output_budget": budget,
            "finish_reason": row["finish_reason"], "original_prediction": original,
            "diagnostic_prediction": predicted, "target": ref["target"], "decision": decision,
            "original_correct": native_correct, "diagnostic_correct": diagnostic_correct})
    if counts["original_accepted"] != native["parsed"] or counts["original_correct"] != native["metrics"]["correct"]:
        raise ValueError("Original unchanged results do not reproduce")
    if len(budgets) != 5651 or counts["planned"] != 5651:
        raise ValueError("Case/budget denominator changed")
    write_new(base / "per_case_diagnostic.json", scored)
    result = {"schema_version": 1, "task_id": "P16", "diagnostic_variant": cfg["diagnostic_variant"],
        "generated_at_pacific": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "source_native_run_id": native["run_id"], "source_native_protocol_variant": native["protocol_variant"],
        "generation_budget_condition": native["generation_budget_condition"],
        "full_original_denominator": 5651, "counts": dict(counts),
        "counts_by_output_budget": {k: dict(v) for k, v in budget_counts.items()},
        "decisions": dict(decisions), "native_accuracy_unchanged": counts["original_correct"] / 5651,
        "diagnostic_accuracy": counts["diagnostic_correct"] / 5651,
        "freeze_receipt_sha256": sha(base / "freeze_receipt.json"),
        "code_sha256": sha(__file__), "config_sha256": sha(base / "protocol.json"),
        "per_case_diagnostic_sha256": sha(base / "per_case_diagnostic.json"),
        "source_inputs": cfg["inputs"], "reference_labels_used_to_select_rule": False,
        "inference_or_regeneration": False, "native_artifacts_modified": False,
        "eligible_recovery_policy": cfg["rule"],
        "qualification": "Separate post-run formatting diagnostic requested by the user. Retains every original accepted prediction, all cases and mixed output budgets. Changes only original invalid normal-stop finals with an allowed terminal class line. Does not replace the original strict score, establish biological correctness of rationales, or form a matched paper comparison."}
    write_new(base / "diagnostic_result.json", result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path(__file__).resolve().parent)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--freeze", action="store_true")
    mode.add_argument("--run", action="store_true")
    args = parser.parse_args()
    print(json.dumps(freeze(args.base) if args.freeze else run(args.base), ensure_ascii=False, indent=2))
