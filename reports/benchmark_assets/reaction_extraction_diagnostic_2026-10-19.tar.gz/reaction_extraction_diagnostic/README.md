# P16 normal-stop terminal-class diagnostic

This is a separately named offline formatting diagnostic. It preserves every
original accepted prediction and the full 5,651-case mixed-budget denominator.
Only an originally invalid response that finished normally (`stop`) can gain a
prediction from its final nonempty line. That line must be a standalone integer,
`Answer: integer`, or balanced Markdown `**integer**`, in 0–383. Optional terminal
periods follow the frozen protocol. Empty finals, truncated responses, ambiguous
lines and prose on the last line remain invalid. Separate reasoning is never read.

The exact code and configuration were frozen and passed 12 synthetic checks at
1:04:45 AM PDT on October 19, 2026, before the reference snapshots were opened by
this diagnostic. `freeze_receipt.json` pins both. All six input snapshots preserve
their original bytes and SHA-256 hashes. Native scores and model outputs were not
changed, and no new inference or selective regeneration occurred.

Results: original strict score **9/5,651 (0.1593%)**, 1,120 accepted predictions;
diagnostic **12/5,651 (0.2124%)**, 1,970 accepted predictions. The 850 newly accepted
answers add three correct predictions. This is evidence that formatting materially
affects answer coverage, while the supplied repair makes little difference to
accuracy on this task. It is not a matched model or paper comparison and does not
validate any biological rationale.

To reproduce without replacing the included evidence, create a fresh directory:

```bash
mkdir replay
cp reproduce_diagnostic.py protocol.json freeze_receipt.json replay/
cp -r input_snapshot replay/
python3 replay/reproduce_diagnostic.py --run
```

This requires only Python 3.9+ and its standard library. The script verifies frozen
code/configuration, all input hashes, case identities and ordering, target alignment,
original parser outputs, budgets and the original correct/accepted counts before
writing new outputs in `replay/`. `per_case_diagnostic.json` is deterministic; the
summary also records a fresh generation timestamp. `reproduction_verification.json`
records an independent execution from a clean temporary directory.

`input_snapshot/per_case_scores.json` contains the preserved scored final texts,
original predictions and reference labels. Full raw API trajectories and separately
saved reasoning remain in the original run's published trajectory archives. Never
give a benchmark solver this diagnostic package, its labels, or the evaluation repo.
