import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('p36_diag', Path(__file__).resolve().parents[1] / 'scripts/diagnose_p36_whitespace.py')
d = importlib.util.module_from_spec(spec);spec.loader.exec_module(d)


class WhitespaceTests(unittest.TestCase):
    def test_only_outer_whitespace_is_removed(self):
        text = '\n\t<bop><p>A<p>C<p>D<eop> \r\n'
        value = d.extract(text, 'stop')
        self.assertFalse(value['exact_native_serialization']);self.assertTrue(value['accepted'])
        self.assertEqual(value['residue_count'],3)
        self.assertFalse(d.extract('<bop><p>A <p>C<eop>','stop')['accepted'])
    def test_truncation_absence_and_format_repairs_stay_invalid(self):
        for text, finish in [('<bop><p>A<eop>','length'),(None,'stop'),('', 'stop'),
                ('<bop><p>A</p><eop>','stop'),('<bop><p>A</eop>','stop'),
                ('```<bop><p>A<eop>```','stop'),('<bop><p>X<eop>','stop')]:
            with self.subTest(text=text,finish=finish):self.assertFalse(d.extract(text,finish)['accepted'])


if __name__ == '__main__':unittest.main()
