"""Offline P36 outer-whitespace diagnostic; no inference or reference scoring."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import tarfile

VERSION = 'P36_OUTER_WHITESPACE_ONLY_V1'
NATIVE = re.compile(r'<bop>(?:<p>[A-Z])+<eop>')
STANDARD = frozenset('ACDEFGHIKLMNPQRSTVWY')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(data):
    return json.dumps(data, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()


def extract(final, finish_reason):
    exact = isinstance(final, str) and NATIVE.fullmatch(final) is not None
    stripped = final.strip() if isinstance(final, str) else ''
    match = NATIVE.fullmatch(stripped)
    residues = ''.join(re.findall(r'<p>([A-Z])', stripped)) if match else None
    accepted = finish_reason == 'stop' and residues is not None and set(residues) <= STANDARD
    return {'exact_native_serialization': exact, 'trimmed_serialization': match is not None,
            'accepted': accepted, 'residue_count': len(residues) if accepted else None,
            'outer_whitespace_removed': isinstance(final, str) and stripped != final,
            'sequence_sha256': digest(residues.encode()) if accepted else None}


def analyze(plan_path, freeze_path):
    plan_path, freeze_path = Path(plan_path), Path(freeze_path)
    freeze = json.loads(freeze_path.read_bytes())
    if freeze['version'] != VERSION or freeze['script_sha256'] != digest(Path(__file__).read_bytes()):
        raise ValueError('Frozen diagnostic changed')
    raw = plan_path.read_bytes()
    if digest(raw) != freeze['input_plan_sha256']:
        raise ValueError('Frozen input plan changed')
    plan = json.loads(raw); ids = [c['case_id'] for c in plan['cases']]
    if len(ids) != plan['planned'] or len(set(ids)) != len(ids):
        raise ValueError('Case identity or denominator mismatch')
    counts = Counter(); rows = []; archives = {}
    for case in plan['cases']:
        archive = Path(case['archive_path'])
        if archive not in archives:
            if digest(archive.read_bytes()) != case['archive_sha256']:
                raise ValueError('Archive digest mismatch')
            with tarfile.open(archive) as tar:
                archives[archive] = {name: tar.extractfile(name).read()
                    for name in tar.getnames() if name.startswith(('requests/', 'responses/')) and name.endswith('.json')}
        files = archives[archive]; key = case['file_key']
        pair = []
        for folder in ['requests', 'responses']:
            data = files[folder + '/' + key + '.json']
            if digest(data) != case[folder[:-1] + '_sha256']:
                raise ValueError('Original per-case digest mismatch')
            value = json.loads(data)
            for field, expected in [('task', 'P36'), ('case_id', case['case_id']),
                    ('variant', plan['protocol_variant']), ('model', plan['model']),
                    ('model_revision', plan['model_revision'])]:
                if value.get(field) != expected:raise ValueError('Case provenance mismatch: ' + field)
            pair.append(value)
        request, response = pair
        request_hash = digest(canonical(request['payload']))
        if request['request_sha256'] != request_hash or response['request_sha256'] != request_hash:
            raise ValueError('Request/response association mismatch')
        if response['http_status'] != 200:raise ValueError('Unexpected transport status')
        body = json.loads(response['raw_response_body'])
        if body['model'] != plan['model'] or len(body['choices']) != 1:
            raise ValueError('Raw model/completion mismatch')
        choice = body['choices'][0]; final = choice['message']['content']; finish = choice['finish_reason']
        if response['status'] == 'completed' and (response['text'] != final or response['finish_reason'] != finish):
            raise ValueError('Saved final and raw API response conflict')
        result = extract(final, finish)
        counts['raw_responses'] += 1; counts['http_200'] += 1
        counts['empty_finals'] += not isinstance(final, str) or not final.strip()
        counts['final_strings'] += isinstance(final, str) and bool(final.strip())
        counts['exact_native_valid'] += result['exact_native_serialization']
        counts['trimmed_accepted'] += result['accepted']; counts['finish_' + str(finish)] += 1
        rows.append({'case_id': case['case_id'], 'request_sha256': case['request_sha256'],
            'response_sha256': case['response_sha256'], 'raw_final_sha256': digest(final.encode()) if isinstance(final, str) else None,
            'finish_reason': finish, **result})
    return {'schema_version': 1, 'diagnostic_version': VERSION, 'run_id': plan['run_id'],
        'protocol_variant': plan['protocol_variant'], 'planned': plan['planned'], 'full_source_cases': plan['full_source_cases'],
        'counts': dict(counts), 'rows': rows, 'input_plan_sha256': digest(raw),
        'freeze_sha256': digest(freeze_path.read_bytes()), 'native_score_changed': False,
        'native_artifacts_modified': False, 'reference_answers_used': False,
        'reasoning_used_for_extraction': False, 'inference_performed': False,
        'qualification': 'Serialization recovery only; no biological-function, design-quality or full-benchmark claim.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True); parser.add_argument('--freeze', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True); args = parser.parse_args()
    result = analyze(args.plan, args.freeze)
    with args.output.open('x') as stream:json.dump(result, stream, indent=2);stream.write('\n')
