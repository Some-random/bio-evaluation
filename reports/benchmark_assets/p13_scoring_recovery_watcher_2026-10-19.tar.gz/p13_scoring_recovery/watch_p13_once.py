"""One-shot proposal: wait for original P13 scoring, then recover the known defect.

Never changes original watchers, generation, source files, or an attempted score.
Execution requires an explicit contract hash and the retained CPU allocation.
"""
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
DRIVER_SHA256 = '62e8198d1e5d4d2fa1fd7173b056fb75b29e2120ec691237cd78f79479ad3b1d'


def now():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write_status(value):
    path = HERE / 'status.json'
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps({**value, 'updated_at_pacific': now()}, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def completion_state(path):
    """The original writer can expose a partially written completion marker."""
    path = Path(path)
    if not path.exists():
        return 'pending'
    try:
        marker = read(path)
    except (json.JSONDecodeError, UnicodeDecodeError):
        # Only defer an incomplete/unreadable JSON marker. The existing wait
        # deadline still applies, and complete markers face every v2 guard.
        return 'pending'
    return 'success' if marker.get('scoring_exit_code') == 0 else 'failed'


def one_shot(state, action, emit, sleep, monotonic, poll_seconds=20, max_wait_seconds=43200):
    started = monotonic()
    while True:
        current = state()
        if current == 'success':
            emit({'stage': 'original_success_no_recovery', 'recovery_attempts': 0})
            return 0
        if current == 'failed':
            emit({'stage': 'validating_and_recovering', 'recovery_attempts': 1})
            try:
                result = action()
            except Exception as exc:
                emit({'stage': 'recovery_failed_no_retry', 'recovery_attempts': 1,
                      'error': type(exc).__name__ + ': ' + str(exc)})
                return 1
            emit({'stage': 'completed', 'recovery_attempts': 1, 'result': result})
            return 0
        if current != 'pending':
            emit({'stage': 'unexpected_original_state_no_action', 'recovery_attempts': 0})
            return 1
        if monotonic() - started >= max_wait_seconds:
            emit({'stage': 'wait_expired_no_action', 'recovery_attempts': 0})
            return 1
        emit({'stage': 'waiting_for_original_scoring', 'recovery_attempts': 0})
        sleep(poll_seconds)


def run(contract_path, expected_sha):
    if sha(contract_path) != expected_sha:
        raise ValueError('Reviewed watcher contract changed')
    contract = read(contract_path)
    if (contract.get('version') != 'P13_NULL_EQUIVALENCE_ONE_SHOT_V2'
            or contract.get('task_id') != 'P13' or contract.get('driver_sha256') != DRIVER_SHA256
            or contract.get('cpu_job_id') != 237730 or os.environ.get('SLURM_JOB_ID') != '237730'
            or contract.get('poll_seconds') != 20 or contract.get('max_wait_seconds') != 43200):
        raise ValueError('Watcher scope or retained CPU allocation changed')
    driver_path = BASE / 'recovery_runner_v2.py'
    export_path = BASE / 'export_repair_report.py'
    if sha(driver_path) != DRIVER_SHA256 or sha(export_path) != contract['export_sha256']:
        raise ValueError('Reviewed recovery/export code changed')
    if sha(__file__) != contract['watcher_sha256']:
        raise ValueError('Reviewed watcher code changed')
    spec = importlib.util.spec_from_file_location('p13_once_frozen_recovery', driver_path)
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    watch = driver.checked(driver.REVISION / 'scoring/watch_plan_v1.json', driver.WATCH_PLAN_SHA256)
    source_path = driver.REVISION / 'scoring/p13_mixed_scoring_v1.json'
    binding = next(row for row in watch['spec_files'] if Path(row['path']).resolve() == source_path.resolve())
    original_spec = driver.checked(source_path, binding['sha256'])
    original_folder = Path(original_spec['project_root']) / 'results/runs' / original_spec['output_run_id']
    destination = BASE / 'prepared_v2/p13'
    with (HERE / 'worker.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        activation = HERE / 'activation_receipt.json'
        if activation.exists() or destination.exists():
            raise ValueError('One-shot watcher or P13 recovery was already started; no retry')
        driver.write_new(activation, {'activated_at_pacific': now(), 'pid': os.getpid(),
            'contract_sha256': expected_sha, 'driver_sha256': DRIVER_SHA256,
            'original_folder': str(original_folder), 'destination': str(destination),
            'generation_calls': 0, 'maximum_recovery_attempts': 1})
        def state():
            return completion_state(original_folder / 'completion.json')
        def action():
            # This validates the exact known null/empty failure, original pinned
            # full union, raw hashes and payloads. Any other failure stops here.
            source = driver.production_source('P13')
            prepared_path = driver.prepare_validated(source, destination, runner_path=driver_path)
            prepared_sha = driver.sha(prepared_path)
            driver.write_new(HERE / 'prepared_receipt.json', {'path': str(prepared_path),
                'sha256': prepared_sha, 'prepared_at_pacific': now(), 'driver_sha256': DRIVER_SHA256})
            result = driver.execute_prepared(prepared_path, prepared_sha)
            export = subprocess.run([sys.executable, '-B', str(export_path)], cwd=driver.REPOSITORY)
            return {'prepared_manifest': str(prepared_path), 'prepared_manifest_sha256': prepared_sha,
                    'completion': result, 'exports_refreshed': export.returncode == 0,
                    'export_exit_code': export.returncode}
        try:
            return one_shot(state, action, write_status, time.sleep, time.monotonic,
                            contract['poll_seconds'], contract['max_wait_seconds'])
        except Exception as exc:
            write_status({'stage': 'controller_failed_no_retry',
                          'error': type(exc).__name__ + ': ' + str(exc)})
            raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--contract', type=Path, required=True)
    parser.add_argument('--expected-sha256', required=True)
    args = parser.parse_args()
    raise SystemExit(run(args.contract, args.expected_sha256))
