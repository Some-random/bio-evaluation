"""Artificial one-shot orchestration states only; no real scores or outputs."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

path = Path(__file__).with_name('watch_p13_once.py')
spec = importlib.util.spec_from_file_location('synthetic_p13_once', path)
watcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(watcher)


class WatcherTests(unittest.TestCase):
    def simulate(self, states, action=None, maximum=40):
        events, calls, clock = [], [], [0]
        iterator = iter(states)
        def state():
            return next(iterator)
        def perform():
            calls.append('recovery')
            if action:
                return action()
            return {'completed': True}
        def sleep(n):
            clock[0] += n
        code = watcher.one_shot(state, perform, events.append, sleep, lambda: clock[0], 20, maximum)
        return code, calls, events

    def test_pending_then_failure_exactly_one_recovery(self):
        code, calls, events = self.simulate(['pending', 'pending', 'failed'])
        self.assertEqual(code, 0)
        self.assertEqual(calls, ['recovery'])
        self.assertEqual(events[-1]['stage'], 'completed')

    def test_original_success_never_recovered(self):
        code, calls, events = self.simulate(['pending', 'success'])
        self.assertEqual(code, 0)
        self.assertEqual(calls, [])
        self.assertEqual(events[-1]['stage'], 'original_success_no_recovery')

    def test_validation_or_scoring_failure_not_retried(self):
        def fail():
            raise ValueError('Synthetic other failure')
        code, calls, events = self.simulate(['failed'], fail)
        self.assertEqual(code, 1)
        self.assertEqual(calls, ['recovery'])
        self.assertEqual(events[-1]['stage'], 'recovery_failed_no_retry')

    def test_wait_expiry_never_scores(self):
        code, calls, events = self.simulate(['pending', 'pending', 'pending'])
        self.assertEqual(code, 1)
        self.assertEqual(calls, [])
        self.assertEqual(events[-1]['stage'], 'wait_expired_no_action')

    def test_unknown_original_state_never_scores(self):
        code, calls, events = self.simulate(['bad_state'])
        self.assertEqual(code, 1)
        self.assertEqual(calls, [])
        self.assertEqual(events[-1]['stage'], 'unexpected_original_state_no_action')

    def test_partial_json_and_utf8_then_complete_marker_recovers_once(self):
        with tempfile.TemporaryDirectory(prefix='p13-partial-marker-') as folder:
            marker = Path(folder) / 'completion.json'
            marker.write_bytes(b'{"scoring_exit_code":')
            events, calls, clock = [], [], [0]
            def sleep(seconds):
                clock[0] += seconds
                if clock[0] == 20:
                    marker.write_bytes(b'{"partial":"\xe2')
                else:
                    marker.write_text(json.dumps({'scoring_exit_code': 1}))
            def action():
                calls.append('one recovery')
                return {'completed': True}
            code = watcher.one_shot(lambda: watcher.completion_state(marker), action,
                events.append, sleep, lambda: clock[0], 20, 40)
            self.assertEqual(code, 0)
            self.assertEqual(calls, ['one recovery'])
            self.assertEqual([event['stage'] for event in events],
                ['waiting_for_original_scoring', 'waiting_for_original_scoring',
                 'validating_and_recovering', 'completed'])

    def test_partial_marker_still_obeys_wait_bound(self):
        with tempfile.TemporaryDirectory(prefix='p13-partial-bound-') as folder:
            marker = Path(folder) / 'completion.json'
            marker.write_text('{')
            clock, calls, events = [0], [], []
            def sleep(seconds):
                clock[0] += seconds
            code = watcher.one_shot(lambda: watcher.completion_state(marker),
                lambda: calls.append('not allowed'), events.append, sleep,
                lambda: clock[0], 20, 40)
            self.assertEqual(code, 1)
            self.assertEqual(calls, [])
            self.assertEqual(clock[0], 40)
            self.assertEqual(events[-1]['stage'], 'wait_expired_no_action')

    def test_complete_success_marker_is_not_recovered(self):
        with tempfile.TemporaryDirectory(prefix='p13-success-marker-') as folder:
            marker = Path(folder) / 'completion.json'
            self.assertEqual(watcher.completion_state(marker), 'pending')
            marker.write_text(json.dumps({'scoring_exit_code': 0}))
            self.assertEqual(watcher.completion_state(marker), 'success')


if __name__ == '__main__':
    unittest.main(verbosity=2)
