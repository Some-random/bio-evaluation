"""Synthetic-only mixed-budget provenance and unchanged native accuracy tests."""
import copy
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import mixed_budget_scoring as scoring
import watch_mixed_budget_scoring as watcher


def save(path, value, lines=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(''.join(json.dumps(row) + '\n' for row in value) if lines else json.dumps(value) + '\n')


class MixedFixture:
    def __init__(self, root):
        self.root = root
        scripts = root / 'scripts'
        scripts.mkdir()
        native = scoring.REPOSITORY / 'scripts'
        for name in ('score_local_reaction.py', 'prepare_catalog_reaction.py'):
            shutil.copyfile(native / name, scripts / name)
        self.helper_path = scripts / 'synthetic_native_helper.py'
        self.helper_path.write_text('''import hashlib,json
def request_record(case,cfg):
 payload={"model":cfg["model"],"messages":case["messages"],**cfg["generation"]}
 return {**{k:case[k] for k in ("task","case_id","variant","split")},"payload":payload,"request_sha256":hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()).hexdigest()}
''')
        self.cases = [{'task': 'P16', 'case_id': 'artificial-' + str(i), 'variant': 'SYNTHETIC',
            'split': 'synthetic', 'messages': [{'role': 'user', 'content': 'Artificial sequence input ' + str(i)}]}
            for i in range(3)]
        save(root / 'inputs.jsonl', self.cases, True)
        save(root / 'review.json', {'approved_case_ids': [c['case_id'] for c in self.cases], 'held_cases': []})
        save(root / 'refs.jsonl', [{'task': 'P16', 'case_id': c['case_id'], 'target': i} for i,c in enumerate(self.cases)], True)
        self.cfg = {'run_id': 'artificial-source', 'approved_task_ids': ['P16'],
            'model': 'synthetic-model', 'model_revision': 'synthetic-revision', 'variant': 'SYNTHETIC',
            'checkpoint_precision': 'BF16', 'runner': 'scripts/synthetic_native_helper.py',
            'input_file': 'inputs.jsonl', 'review_file': 'review.json', 'scorer_reference_file': 'refs.jsonl',
            'scorer_reference_sha256': scoring.file_sha(root / 'refs.jsonl'), 'full_test_case_count': 3,
            'generation': {'max_tokens': 4096, 'temperature': 1.0, 'top_p': .95, 'seed': 42, 'n': 1},
            'frozen_files_sha256': {name: scoring.file_sha(root / name) for name in
                ('scripts/synthetic_native_helper.py', 'scripts/score_local_reaction.py',
                 'scripts/prepare_catalog_reaction.py', 'inputs.jsonl', 'review.json')}}
        save(root / 'config.json', self.cfg)
        self.old = root / 'results/runs/artificial-source'
        self.new = root / 'revised/artificial-source_output16384_v1'
        self.helper = scoring.base.load_frozen_runner(root, self.cfg)
        for i in (0,1):
            self.raw(self.old, self.cases[i], self.cfg, 'invalid artificial response' if i == 0 else '1', old=True)
        self.proof = {'all_saved_responses_verified': True, 'ambiguous_files': [], 'synthetic': True}
        self.cp = {'schema_version': 1, 'condition': scoring.CONDITION, 'parent_run_directory': str(self.old),
            'original_source_run_id': self.cfg['run_id'],
            'source_case_contract_sha256': scoring.digest(self.cases), 'ordered_pending_case_ids': ['artificial-2'],
            'ambiguous_files': [], 'parent_proof': self.proof, 'selection_uses_correctness_or_finish_reason': False,
            'retained_files_sha256': {str(p.relative_to(self.old)): scoring.file_sha(p) for p in self.old.rglob('*.json')}}
        self.checkpoint_path = root / 'checkpoint.json'
        save(self.checkpoint_path, self.cp)
        self.entry = {'project_root': str(root), 'run_id': self.cfg['run_id'], 'task_id': 'P16',
            'config_sha256': scoring.file_sha(root / 'config.json')}
        self.item = {'entry': self.entry, 'selected_case_ids': ['artificial-2'],
            'ordered_case_ids_sha256': scoring.digest(['artificial-2']),
            'case_scope': 'all_never_dispatched_at_clean_pause',
            'parent_checkpoint': {'path': str(self.checkpoint_path), 'sha256': scoring.file_sha(self.checkpoint_path)},
            'output_directory': str(self.new)}
        self.producer = root / 'synthetic_producer.py'
        self.producer.write_text('# Synthetic producer marker only\n')
        self.plan = {'schema_version': 1, 'condition': scoring.CONDITION, 'execution_authorized': True,
            'output_budget': 16384, 'original_output_budget': 4096,
            'retries_or_resampling_of_previously_executed_cases': False,
            'whole_task_metrics_require_original4k_and_new16k_union': True,
            'code_sha256': scoring.file_sha(self.producer), 'runs': [self.item],
            'endpoints': [{'endpoint_id': 'synthetic-server', 'server_identity_sha256': 'synthetic-identity'}]}
        self.plan_path = root / 'plan.json'
        save(self.plan_path, self.plan)
        self.binding = {'path': str(self.plan_path), 'sha256': scoring.file_sha(self.plan_path)}
        revised = copy.deepcopy(self.cfg)
        revised['generation']['max_tokens'] = 16384
        self.raw(self.new, self.cases[2], revised, '2')
        name = scoring.case_name(self.cases[2])
        req = scoring.read(self.new / 'requests' / name)
        save(self.new / 'dispatch' / name, {'condition': scoring.CONDITION, 'plan_sha256': self.binding['sha256'],
            'case_id': 'artificial-2', 'output_budget': 16384, 'request_sha256': req['request_sha256'],
            'response_sha256': scoring.file_sha(self.new / 'responses' / name),
            'endpoint_id': 'synthetic-server', 'server_identity_sha256': 'synthetic-identity'})
        save(self.new / 'run_manifest.json', {'condition': scoring.CONDITION,
            'plan_sha256': self.binding['sha256'], 'source_entry': self.entry, 'configuration': revised,
            'original_configuration': self.cfg, 'planned_cases': 1,
            'ordered_cases_sha256': scoring.digest([self.cases[2]]), 'parent_checkpoint': self.item['parent_checkpoint'],
            'parent_run_directory': str(self.old), 'original_artifacts_modified': False,
            'model_outcome_based_selection': False})
        save(self.new / 'generation_completion.json', {'condition': scoring.CONDITION,
            'plan_sha256': self.binding['sha256'], 'planned': 1, 'statuses': {'completed': 1},
            'retry_or_resampling': False, 'generation_exit_code': 0})
        self.spec = {'project_root': str(root), 'task_id': 'P16', 'full_config_file': 'config.json',
            'full_config_sha256': scoring.file_sha(root / 'config.json'),
            'scorer_file': 'scripts/score_local_reaction.py',
            'scorer_sha256': scoring.file_sha(root / 'scripts/score_local_reaction.py'),
            'sources': [{'config_file': 'config.json', 'config_sha256': scoring.file_sha(root / 'config.json')}],
            'revision_plans': [self.binding], 'revision_runner_file': str(self.producer),
            'revision_runner_sha256': scoring.file_sha(self.producer), 'output_run_id': 'artificial-mixed',
            'python': sys.executable}

    def raw(self, folder, case, cfg, text, old=False):
        name = scoring.case_name(case)
        req = self.helper.request_record(case, cfg)
        response = {**{k:case[k] for k in ('task','case_id','variant','split')},
            'model': cfg['model'], 'model_revision': cfg['model_revision'],
            'request_sha256': req['request_sha256'], 'status': 'completed', 'http_status': 200,
            'text': text, 'finish_reason': 'length' if old and case['case_id'] == 'artificial-0' else 'stop'}
        response['response'] = {'model': cfg['model'], 'choices': [{'message': {'content': text},
            'finish_reason': response['finish_reason']}]}
        if not old:
            response['condition'] = scoring.CONDITION
        save(folder / 'requests' / name, req)
        save(folder / 'responses' / name, response)

    def validator(self, *args, **kwargs):
        return self.proof


class MixedBudgetTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.fx = MixedFixture(Path(self.temp.name))

    def test_exact_union_selects_frozen_budgets_without_reading_labels(self):
        original_open = Path.open
        reference = self.fx.root / 'refs.jsonl'
        def no_labels(path, *args, **kwargs):
            if path.resolve() == reference.resolve():
                raise AssertionError('Validation must not open scorer references')
            return original_open(path, *args, **kwargs)
        with mock.patch.object(Path, 'open', new=no_labels):
            r = scoring.validate_sources(self.fx.spec, self.fx.validator)
        self.assertEqual(r[-1]['expected_test_case_count'], 3)
        self.assertEqual(Counter(r[-2].values()), {4096: 2, 16384: 1})
        self.assertTrue(all(slot['sha256'] for slot in r[-3].values()))

    def test_previously_claimed_case_cannot_be_rerun(self):
        self.fx.raw(self.fx.old, self.fx.cases[2], self.fx.cfg, '2', old=True)
        with self.assertRaisesRegex(scoring.ScoringError, 'previously claimed'):
            scoring.validate_sources(self.fx.spec, self.fx.validator)

    def test_mutated_historical_response_rejected(self):
        p = next((self.fx.old / 'responses').glob('*.json'))
        p.write_text(p.read_text() + ' ')
        with self.assertRaisesRegex(scoring.ScoringError, 'historical 4k artifact changed'):
            scoring.validate_sources(self.fx.spec, self.fx.validator)

    def test_wrong_new_budget_and_wrong_server_rejected(self):
        name = scoring.case_name(self.fx.cases[2])
        p = self.fx.new / 'dispatch' / name
        value = scoring.read(p)
        value['output_budget'] = 4096
        save(p, value)
        with self.assertRaisesRegex(scoring.ScoringError, 'budget/server/dispatch'):
            scoring.validate_sources(self.fx.spec, self.fx.validator)

    def test_request_with_extra_model_facing_change_rejected(self):
        name = scoring.case_name(self.fx.cases[2])
        p = self.fx.new / 'requests' / name
        value = scoring.read(p)
        value['payload']['temperature'] = .2
        value['request_sha256'] = scoring.digest(value['payload'])
        save(p, value)
        with self.assertRaisesRegex(scoring.ScoringError, 'Raw request differs'):
            scoring.validate_sources(self.fx.spec, self.fx.validator)

    def test_duplicate_source_not_averaged_or_silently_deduplicated(self):
        self.fx.spec['sources'].append(copy.deepcopy(self.fx.spec['sources'][0]))
        with self.assertRaisesRegex(scoring.ScoringError, 'overlaps'):
            scoring.validate_sources(self.fx.spec, self.fx.validator)

    def test_incomplete_cohort_not_scored(self):
        (self.fx.new / 'generation_completion.json').unlink()
        self.assertEqual(watcher.ready(self.fx.spec)[0], False)
        with self.assertRaises(scoring.Pending):
            scoring.validate_sources(self.fx.spec, self.fx.validator)

    def test_native_accuracy_preserves_invalid_4k_denominator_and_bytes(self):
        before = {str(p): scoring.file_sha(p) for p in self.fx.old.rglob('*.json')}
        result = scoring.score_spec(self.fx.spec, validator=self.fx.validator)
        self.assertEqual(result['state'], 'completed')
        out = self.fx.root / 'results/runs/artificial-mixed'
        scores = scoring.read(out / 'scores.json')
        self.assertEqual(scores['planned'], 3)
        self.assertEqual(scores['parsed'], 2)
        self.assertEqual(scores['metrics']['accuracy'], 2/3)
        self.assertEqual(scores['invalid_outputs'], 1)
        self.assertEqual(scores['generation']['output_budget_counts'], {'4096': 2, '16384': 1})
        self.assertEqual(scores['generation_budget_condition'], scoring.CONDITION)
        native = scoring.read(out / 'native_scores_unmodified.json')
        self.assertEqual(native['metrics'], scores['metrics'])
        self.assertEqual(before, {str(p): scoring.file_sha(p) for p in self.fx.old.rglob('*.json')})
        self.assertEqual(scoring.score_spec(self.fx.spec)['state'], 'existing_completed_unchanged')

    def test_task_finished_during_4k_drain_keeps_truthful_single_budget_condition(self):
        self.fx.raw(self.fx.old, self.fx.cases[2], self.fx.cfg, '2', old=True)
        save(self.fx.old / 'shared_vllm_amendment.json', {})
        self.fx.plan['runs'] = []
        save(self.fx.plan_path, self.fx.plan)
        self.fx.binding['sha256'] = scoring.file_sha(self.fx.plan_path)
        result = scoring.score_spec(self.fx.spec, validator=self.fx.validator)
        self.assertEqual(result['state'], 'completed')
        scores = scoring.read(self.fx.root / 'results/runs/artificial-mixed/scores.json')
        self.assertEqual(scores['generation_budget_condition'], 'RETAINED_4K_COMPLETE_UNDER_BUDGET_REVISION')
        self.assertEqual(scores['generation']['max_tokens'], 4096)
        self.assertEqual(scores['generation']['output_budget_counts'], {'4096': 3})
        self.assertEqual(scores['metrics']['accuracy'], 2/3)

    def test_existing_complete_original_4k_native_score_is_reused_without_call(self):
        save(self.fx.old / 'scores.json', {'planned': 3, 'completed': 3, 'metrics': {'accuracy': 0.0}})
        save(self.fx.old / 'run_manifest.json', {'configuration': self.fx.cfg,
            'case_contract_sha256': scoring.digest(self.fx.cases), 'planned_cases': 3})
        save(self.fx.old / 'completion.json', {'scoring_exit_code': 0,
            'configuration_sha256': self.fx.spec['full_config_sha256'],
            'scores_sha256': scoring.file_sha(self.fx.old / 'scores.json'),
            'run_manifest_sha256': scoring.file_sha(self.fx.old / 'run_manifest.json')})
        def forbidden(*args, **kwargs):
            raise AssertionError('Existing native score must not be recomputed')
        result = scoring.score_spec(self.fx.spec, run_command=forbidden)
        self.assertEqual(result['state'], 'existing_native4k_completed_unchanged')
        self.assertFalse((self.fx.root / 'results/runs/artificial-mixed').exists())

    def test_closed_full_4k_checkpoint_suffices_without_old_terminal_marker(self):
        self.fx.raw(self.fx.old, self.fx.cases[2], self.fx.cfg, '2', old=True)
        self.fx.cp['ordered_pending_case_ids'] = []
        self.fx.cp['retained_files_sha256'] = {str(p.relative_to(self.fx.old)): scoring.file_sha(p)
            for p in self.fx.old.rglob('*.json')}
        save(self.fx.checkpoint_path, self.fx.cp)
        self.fx.spec['closed_4k_checkpoints'] = [{'run_id': self.fx.cfg['run_id'],
            'path': str(self.fx.checkpoint_path), 'sha256': scoring.file_sha(self.fx.checkpoint_path)}]
        self.fx.plan['runs'] = []
        save(self.fx.plan_path, self.fx.plan)
        self.fx.binding['sha256'] = scoring.file_sha(self.fx.plan_path)
        self.assertTrue(watcher.ready(self.fx.spec)[0])
        union = scoring.validate_sources(self.fx.spec, self.fx.validator)
        self.assertEqual(scoring.actual_budget_condition(union[-2]), 'RETAINED_4K_COMPLETE_UNDER_BUDGET_REVISION')
        self.assertEqual(union[-1]['expected_test_case_count'], 3)


from collections import Counter

if __name__ == '__main__':
    unittest.main()
