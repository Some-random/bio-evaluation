"""Synthetic metadata/state tests only; no native scorer or model is invoked."""
from contextlib import redirect_stdout
import copy
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import watch_serial_sealed as serial


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


class SerialWatcherTests(unittest.TestCase):
    def setUp(self):
        scratch = HERE / 'test_scratch'
        scratch.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=scratch)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.contract_path = self.root / 'contract.json'
        self.contract = serial.read(HERE / 'contract_v1.json')
        save(self.contract_path, self.contract)
        self.runtime = serial.SerialWatcher(self.contract_path, serial.sha(self.contract_path))
        self.runtime.contract = {**self.runtime.contract, 'original_plan': {
            **self.runtime.contract['original_plan'],
            'path': str(self.root / 'artificial_watch_plan.json')}}
        self.tasks = self.contract['task_ids']
        self.specs = [(str(self.root / (task + '.json')),
                       {'task_id': task, 'output_run_id': 'artificial-' + task})
                      for task in self.tasks]
        self.state_path = self.root / 'state.json'
        self.plan = {'schema_version': 1, 'condition': 'MIXED_BUDGET_4K16K_CONTINUATION',
                     'state_file': str(self.state_path), 'poll_seconds': 20}
        self.state = {'schema_version': 1,
            'plan_sha256': self.contract['original_plan']['sha256'],
            'condition': self.plan['condition'], 'tasks': {
                task: {'stage': 'pending', 'reason': 'artificial waiting task'} for task in self.tasks},
            'inference_dispatched': False, 'native_parsers_and_metrics_unchanged': True,
            'retained_audit_field': {'preserve': True}}
        self.state['tasks']['P07'] = {'stage': 'completed', 'result': {'run_id': 'artificial-P07'},
                                      'retained_p07_receipt': 'unchanged'}
        save(self.state_path, self.state)
        # All patches are private in-memory module attributes for artificial
        # state paths. Original production files and live state are untouched.
        self.runtime.verify = lambda: (self.plan, self.specs)
        self.runtime.watcher.frozen = lambda *args: (self.plan, self.specs)
        self.runtime.watcher.ready = lambda spec: (True, 'artificial_ready')

    def test_same_plan_state_and_terminal_records_preserved(self):
        self.state['tasks']['P08'] = {'stage': 'failed', 'error': 'artificial prior attempt',
                                      'automatic_retry': False, 'retained': [1, 2, 3]}
        save(self.state_path, self.state)
        calls = []
        self.runtime.adapter.score = lambda spec: calls.append(spec['task_id']) or {'state': 'artificial_completed'}
        original_terminals = copy.deepcopy({task: self.state['tasks'][task] for task in ('P07', 'P08')})
        with redirect_stdout(io.StringIO()):
            self.assertEqual(self.runtime.run(once=True), 1)  # prior failure retained
        result = serial.read(self.state_path)
        self.assertEqual(calls, self.tasks[2:])
        self.assertEqual(result['plan_sha256'], self.state['plan_sha256'])
        self.assertEqual(result['retained_audit_field'], self.state['retained_audit_field'])
        self.assertEqual({task: result['tasks'][task] for task in ('P07', 'P08')}, original_terminals)
        self.assertTrue(result['all_terminal'])
        self.assertFalse(result['all_completed'])
        # Restarting cannot score any terminal task again.
        with redirect_stdout(io.StringIO()):
            self.runtime.run(once=True)
        self.assertEqual(calls, self.tasks[2:])

    def test_original_ready_logic_defers_unfinished_task(self):
        self.runtime.watcher.ready = lambda spec: (False, 'prospective16k_pending:artificial')
        self.runtime.adapter.score = mock.Mock(side_effect=AssertionError('No task is ready'))
        self.runtime.cycle()
        self.runtime.adapter.score.assert_not_called()
        self.assertEqual(serial.read(self.state_path)['tasks']['P16']['stage'], 'pending')

    def test_foreign_or_missing_state_and_nonterminal_p07_rejected(self):
        for change in ({'plan_sha256': 'foreign-plan'}, {'tasks': {}},
                       {'tasks': {**self.state['tasks'], 'P07': {'stage': 'pending'}}}):
            save(self.state_path, {**self.state, **change})
            with self.subTest(change=change), self.assertRaises(serial.ContractError):
                self.runtime.run(once=True)
        self.state_path.unlink()
        with self.assertRaisesRegex(serial.ContractError, 'Existing original watcher state'):
            self.runtime.run(once=True)

    def test_original_and_new_watchers_share_exclusive_ownership(self):
        # Same actual lock-path expression as v1, but an artificial plan path.
        plan_path = self.root / 'artificial_watch_plan.json'
        contract = {**self.runtime.contract,
                    'original_plan': {'path': str(plan_path), 'sha256': self.state['plan_sha256']}}
        self.runtime.contract = contract
        before = self.state_path.read_bytes()
        self.runtime.adapter.score = mock.Mock(side_effect=AssertionError('Duplicate owner scored'))
        with serial.watcher_ownership(plan_path):
            with self.assertRaises(BlockingIOError):
                self.runtime.run(once=True)
        self.assertEqual(before, self.state_path.read_bytes())
        self.runtime.adapter.score.assert_not_called()

    def test_one_task_at_a_time_in_original_spec_order(self):
        active, observed = [], []
        def artificial_score(spec):
            self.assertEqual(active, [])
            active.append(spec['task_id'])
            observed.append(spec['task_id'])
            self.assertEqual(serial.read(self.state_path)['tasks'][spec['task_id']]['stage'],
                             'validating_or_scoring')
            active.pop()
            return {'state': 'artificial_completed'}
        self.runtime.adapter.score = artificial_score
        with redirect_stdout(io.StringIO()):
            self.assertEqual(self.runtime.run(once=True), 0)
        self.assertEqual(observed, self.tasks[1:])
        self.assertEqual(active, [])

    def test_private_pending_and_output_lock_contention_stay_pending(self):
        calls = []
        def waiting(spec):
            calls.append(spec['task_id'])
            if spec['task_id'] == 'P08':
                raise self.runtime.adapter.v1.Pending('Unsealed historical source remains active')
            raise BlockingIOError('Artificial competing derived output lock')
        self.runtime.adapter.score = waiting
        self.runtime.cycle()
        state = serial.read(self.state_path)
        self.assertEqual(calls, self.tasks[1:])
        for task in self.tasks[1:]:
            self.assertEqual(state['tasks'][task]['stage'], 'pending')
            self.assertNotIn('automatic_retry', state['tasks'][task])

    def test_existing_native_attempt_is_terminal_without_native_invocation(self):
        fixture_path = serial.SCORING / 'test_mixed_budget_scoring.py'
        fixture_module = serial.load_module(fixture_path, 'serial_synthetic_mixed_fixtures')
        project = self.root / 'artificial_native_project'
        project.mkdir()
        fixture = fixture_module.MixedFixture(project)
        for task in self.tasks:
            if task != 'P16':
                self.state['tasks'][task] = {'stage': 'completed', 'retained': task}
        self.state['tasks']['P16'] = {'stage': 'validating_or_scoring'}
        save(self.state_path, self.state)
        self.specs = [(path, fixture.spec if spec['task_id'] == 'P16' else spec)
                      for path, spec in self.specs]
        output = project / 'results/runs/artificial-mixed'
        journal = output / 'native_scorer_invocation.json'
        save(journal, {'native_calls_planned': 1, 'synthetic_interrupted_attempt': True})
        before = journal.read_bytes()
        # Real adapter's existing no-repeat guard runs; native invocation and
        # source validation must never be reached for an existing journal.
        self.runtime.adapter.v1.validate_sources = mock.Mock(side_effect=AssertionError('Retry reached sources'))
        self.runtime.cycle()
        state = serial.read(self.state_path)
        self.assertEqual(state['tasks']['P16']['stage'], 'failed')
        self.assertIn('already attempted; no repeat', state['tasks']['P16']['error'])
        self.assertEqual(before, journal.read_bytes())
        self.assertFalse((output / 'native_scorer.log').exists())
        self.runtime.cycle()
        self.runtime.adapter.v1.validate_sources.assert_not_called()

    def test_frozen_code_mutation_rejected_before_cycle_or_score(self):
        artificial_dependency = self.root / 'artificial_dependency.py'
        artificial_dependency.write_text('# synthetic code pin\n')
        contract = copy.deepcopy(self.contract)
        contract['code_files_sha256'][str(artificial_dependency)] = serial.sha(artificial_dependency)
        save(self.contract_path, contract)
        expected = serial.sha(self.contract_path)
        serial.checked_contract(self.contract_path, expected)
        artificial_dependency.write_text('# mutated synthetic code pin\n')
        with self.assertRaisesRegex(serial.ContractError, 'dependency changed'):
            serial.checked_contract(self.contract_path, expected)

    def test_contract_mutation_rejected_and_all_runtime_pins_required(self):
        expected = serial.sha(self.contract_path)
        altered = copy.deepcopy(self.contract)
        altered['native_attempts_retried'] = True
        save(self.contract_path, altered)
        with self.assertRaisesRegex(serial.ContractError, 'contract changed'):
            serial.checked_contract(self.contract_path, expected)
        for missing in (str(serial.SEALED), str(serial.WATCHER), str(Path(serial.__file__).resolve())):
            altered = copy.deepcopy(self.contract)
            del altered['code_files_sha256'][missing]
            save(self.contract_path, altered)
            with self.subTest(missing=missing), self.assertRaisesRegex(serial.ContractError, 'must all be pinned'):
                serial.checked_contract(self.contract_path, serial.sha(self.contract_path))


if __name__ == '__main__':
    unittest.main()
