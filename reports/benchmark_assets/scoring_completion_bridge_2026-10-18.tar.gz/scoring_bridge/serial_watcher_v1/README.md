# Serial sealed-source watcher — prepared, not deployed

Prepared October 18, 2026, Pacific time. This is an additive local review
package. Preparation did not invoke native benchmark scoring or model
inference, change any running process, modify an original source/spec/output,
or publish anything.

## Change

`watch_serial_sealed.py` imports the unchanged original
`watch_mixed_budget_scoring.py` and reuses its readiness checks, serial cycle,
state transitions and terminal-state preservation. Its score callback uses the
already-reviewed `sealed_completion_scoring.py` rather than the original
source-lock-only bridge. Thus complete P16/P12/etc. sources can be physically
sealed and natively scored while their GPU host pools continue other work.

The original seven task specs, plan, ordering, state file, condition, output
IDs, native scorer/parser/formulas, full denominators and per-case budgets stay
unchanged. In particular, each result remains in its existing
`_mixed_4k16k_scoring_v1` directory. This introduces no new inference condition
or native scoring identity.

The new `contract_v1.json` pins the original plan and all its code dependencies,
the original watcher, the reviewed sealing wrapper and this new wrapper.
Hashes are checked before import, before each cycle and immediately before each
score callback. The original watcher independently validates its seven frozen
specs each cycle. The contract's SHA-256 must be passed explicitly at startup.

## Ownership and continuity

The wrapper takes **the same** original plan's `.worker.lock`, nonblocking,
before reading/writing live state. An old watcher or another new watcher that
still owns that lock prevents activation without changing any task record.
It never stops, resumes or terminates another process.

An existing same-plan state containing all seven original task keys is
mandatory. P07 must already be terminal (`completed` or `failed`) before the
wrapper may run; failure remains failure and is never retried. All original
`completed`/`failed` records are preserved by the original cycle. Missing or
foreign state is refused rather than reset. A prior native invocation journal
continues to prevent any second native invocation, including after an
interrupted `validating_or_scoring` record.

The reviewed sealed scorer imports a private v1 adapter with its own exception
classes. Its `Pending` is translated into the exact `Pending` class caught by
the original watcher's cycle. `BlockingIOError` from a competing scoring lock
also stays `pending`, never a native scoring failure. This does not bypass or
clear a native invocation journal. Once contention ends, an incomplete prior
native attempt is reported terminal without retry.

Everything runs serially. Only the original watcher state gets the original
worker metadata updates. Existing hourly checks still read
`scoring/watcher_status_v1.json`; publishers and aggregate collectors keep the
same derived IDs and completion contracts. As with the original watcher, its
state timestamp can age during a long blocking sealing/native-scoring call;
an hourly report should describe that phase rather than invent a heartbeat or
claim a failure from age alone.

## Validation performed

```sh
python3 -B -m unittest discover \
  -s .local/evaluation_revision_2026-10-18/scoring/sealed_completion_v2/serial_watcher_v1 \
  -p test_watch_serial_sealed.py -v
```

Nine synthetic safety tests pass. They cover same-plan continuity, exact
completed/failed record preservation across restarts, missing/foreign-state
and unfinished-P07 rejection, shared old/new watcher ownership, serial task
ordering, readiness deferral, private Pending translation, output-lock
contention, native-attempt no-repeat after interruption and code/contract pin
mutation rejection. All test writes stay in temporary directories under this
package. No native scorer or model is invoked, including in the test that
checks a synthetic preexisting invocation journal.

The original plan/specs are read for hash validation only. The live watcher
state, locks and actual benchmark outputs are not touched by tests.

## Later activation — requires separate operational review

1. Wait for the current one-off P07 controller to finish and for its exact
   original CPU watcher to resume. Verify the P07 native completion or preserved
   failed attempt, and the original watcher's terminal P07 record. Do not kill
   a healthy native scoring call to accelerate this handoff.
2. Preserve the live original watcher state and process identity. Cleanly
   retire only that **idle CPU scoring watcher** using an identity-checked
   handoff; verify it has no active scorer child and that its original plan
   lock is released. Do not change GPU workers, held serving owners, uploads
   or reporting. The wrapper itself performs no retirement operation.
3. Verify this package manifest and contract hash. A read-only preflight is:

   ```text
   <pinned-python> -B <this-directory>/watch_serial_sealed.py
     --contract <this-directory>/contract_v1.json
     --contract-sha256 <reviewed-contract-sha256>
     --validate-only
   ```

   This checks continuity/hashes without a scoring invocation, state write or
   ownership change; it does not prove the old worker lock is free.
4. On existing CPU allocation **237730**, use the unchanged pinned Python
   `/tmp/bio-cpu-supervisor-237730-6G6tNR/python/bin/python3.10`, with explicit
   **4 CPUs and 24 GiB**, and the same command without `--validate-only`.
   Keep an execution log and receipt. A duplicate owner is rejected before
   task state changes. No GPU allocation is needed.
5. Verify fresh original-state updates and exact preservation of prior
   terminal records. When another whole task becomes ready, verify its sealed
   receipt and native completion, then existing automatic trajectory/report
   publication. Physical copies and native materialization can take substantial
   shared-storage time; check disk capacity first.

There is no elapsed-time kill timer, alternate output ID, native retry path,
parser repair, label-guided selection or inference capability in this wrapper.
If a native scorer fails, the original terminal/no-repeat policy remains in
effect. If startup validation fails, preserve the state and resolve the
operational problem without altering a frozen contract or native attempt.
