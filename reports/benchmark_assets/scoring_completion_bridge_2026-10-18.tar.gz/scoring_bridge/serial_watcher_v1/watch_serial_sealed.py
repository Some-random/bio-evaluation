"""Prepared additive serial watcher; CLI activation is a separate reviewed action.

Reuse the frozen v1 watcher, state, plan, specs and output identities. Substitute
only the reviewed sealed-source scorer. No inference or native retry mechanism.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
SCORING = HERE.parents[1]
WATCHER = SCORING / 'watch_mixed_budget_scoring.py'
SEALED = HERE.parent / 'sealed_completion_scoring.py'
TASKS = {'P07', 'P08', 'P12', 'P13', 'P14', 'P15', 'P16'}


class ContractError(RuntimeError):
    pass


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_module(path, name):
    module_spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(result)
    return result


def checked_contract(path, expected):
    """Check code bytes before import and on every later cycle/native entry."""
    if sha(path) != expected:
        raise ContractError('Frozen serial-watcher contract changed')
    value = read(path)
    if (value.get('schema_version') != 1
            or value.get('kind') != 'serial_sealed_native_scoring_watcher'
            or set(value.get('task_ids', [])) != TASKS
            or len(value.get('task_ids', [])) != len(TASKS)
            or value.get('original_state_and_output_ids_preserved') is not True
            or value.get('native_attempts_retried') is not False):
        raise ContractError('Serial watcher contract changed scope or no-retry policy')
    binding = value['original_plan']
    if sha(binding['path']) != binding['sha256']:
        raise ContractError('Original watcher plan changed')
    plan = read(binding['path'])
    pins = value['code_files_sha256']
    required = {str(Path(__file__).resolve()), str(WATCHER.resolve()),
                str(SEALED.resolve()), *plan['code_files_sha256']}
    if not required <= set(pins):
        raise ContractError('Original watcher, adapters and new wrapper must all be pinned')
    if (value.get('state_file') != plan['state_file']
            or value.get('python') != plan['python']
            or value.get('native_cpu_job_id') != plan['native_cpu_job_id']
            or any(pins.get(name) != expected_sha
                   for name, expected_sha in plan['code_files_sha256'].items())):
        raise ContractError('Original state, runtime or dependency pins changed')
    for name, expected_sha in pins.items():
        if sha(name) != expected_sha:
            raise ContractError('Frozen serial/native scoring dependency changed: ' + name)
    return value


def check_state_continuity(plan, specs):
    """Refuse a new/reset/foreign state; carry all prior terminal records intact."""
    path = Path(plan['state_file'])
    if not path.is_file():
        raise ContractError('Existing original watcher state is required; do not reset it')
    state = read(path)
    tasks = [spec['task_id'] for _, spec in specs]
    if (state.get('plan_sha256') != plan['_expected_sha256']
            or state.get('schema_version') != 1
            or state.get('condition') != plan['condition']
            or set(state.get('tasks', {})) != set(tasks)):
        raise ContractError('Existing watcher state does not cover the same original plan')
    if state['tasks']['P07'].get('stage') not in {'completed', 'failed'}:
        raise ContractError('Wait for one-off P07 completion and original watcher restoration')
    return state


@contextmanager
def watcher_ownership(plan_path):
    """Exactly the lock used by v1: duplicate old/new watchers cannot coexist."""
    path = Path(plan_path).with_suffix('.worker.lock')
    with path.open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


class SerialWatcher:
    def __init__(self, contract_path, contract_sha256):
        self.contract_path = Path(contract_path).resolve()
        self.contract_sha256 = contract_sha256
        self.contract = checked_contract(self.contract_path, self.contract_sha256)
        # The unchanged watcher imports its sibling v1 module by its native name.
        sys.path.insert(0, str(SCORING))
        self.watcher = load_module(WATCHER, 'private_serial_original_watcher')
        self.sealed = load_module(SEALED, 'private_serial_reviewed_sealed_scorer')
        self.adapter = self.sealed.SealedScoring()

    def verify(self):
        value = checked_contract(self.contract_path, self.contract_sha256)
        if value != self.contract:
            raise ContractError('Serial watcher contract changed in memory')
        pin = value['original_plan']
        plan, specs = self.watcher.frozen(pin['path'], pin['sha256'])
        if {spec['task_id'] for _, spec in specs} != TASKS:
            raise ContractError('Require exactly the seven original native task specs')
        if [spec['task_id'] for _, spec in specs] != value['task_ids']:
            raise ContractError('Original task/spec order changed')
        return plan, specs

    def score(self, spec):
        # Check every frozen dependency immediately before one native entry.
        self.verify()
        try:
            return self.adapter.score(spec)
        except self.adapter.v1.Pending as error:
            # The sealed bridge has a private v1 module: translate its distinct
            # Pending class to the exact class caught by the original cycle.
            raise self.watcher.scoring.Pending(str(error)) from error
        except BlockingIOError as error:
            # A competing output lock is waiting, never a scientific failure.
            # V1's invocation journal remains unchanged: if native execution
            # had already been attempted, a later call cannot invoke it again.
            raise self.watcher.scoring.Pending(
                'Scoring lock is held; preserve existing attempt and wait: '
                + spec['output_run_id']) from error

    def cycle(self):
        self.verify()
        pin = self.contract['original_plan']
        return self.watcher.cycle(pin['path'], pin['sha256'], score_function=self.score)

    def run(self, once=False):
        pin = self.contract['original_plan']
        with watcher_ownership(pin['path']):
            plan, specs = self.verify()
            check_state_continuity({**plan, '_expected_sha256': pin['sha256']}, specs)
            # Unchanged v1 cycle owns state transitions, terminal preservation,
            # readiness and one-at-a-time ordering for every remaining task.
            while True:
                state, pause = self.cycle()
                print(json.dumps({'updated_at_pacific': state['updated_at_pacific'],
                    'all_terminal': state['all_terminal'],
                    'tasks': {key: row['stage'] for key, row in state['tasks'].items()}}), flush=True)
                if once or state['all_terminal']:
                    return 0 if state['all_completed'] or not state['all_terminal'] else 1
                time.sleep(pause)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--contract', type=Path, required=True)
    parser.add_argument('--contract-sha256', required=True)
    parser.add_argument('--validate-only', action='store_true')
    parser.add_argument('--once', action='store_true')
    args = parser.parse_args()
    runtime = SerialWatcher(args.contract, args.contract_sha256)
    if args.validate_only:
        plan, specs = runtime.verify()
        check_state_continuity({**plan, '_expected_sha256': runtime.contract['original_plan']['sha256']}, specs)
        print(json.dumps({'stage': 'validated', 'inference_dispatched': False,
                          'native_scorers_invoked': 0, 'state_changed': False}))
        return 0
    if (sys.executable != runtime.contract['python']
            or os.environ.get('SLURM_JOB_ID') != str(runtime.contract['native_cpu_job_id'])):
        raise ContractError('Use the unchanged pinned CPU allocation/interpreter')
    return runtime.run(once=args.once)


if __name__ == '__main__':
    raise SystemExit(main())
