# Completed-source scoring bridge — prepared, not activated

Prepared October 18, 2026, Pacific time. This directory is an additive review
package. No real benchmark scorer, inference call, publication, process change,
or plan amendment was performed while preparing it.

## The delay

`run_budget_revision.py` takes all per-run locks when a host pool starts and
releases them only when that whole pool exits. Its per-run
`generation_completion.json` can already record a complete, successful run.
The existing v1 scoring bridge nevertheless waits for every source lock.
Both remaining P07 shards finished, but their locks remain held by the active
host dispatchers. Releasing those locks from another process is not appropriate.

## The additive change

`sealed_completion_scoring.py` imports a private instance of the hash-pinned,
unchanged v1 bridge. The v1 derived-output lock, immutable spec identity,
one-attempt invocation journal, denominator, parser, budget selection and native
scoring call all remain in use. The only substituted operations are source
locking and physical sealing of validated raw input slots.

1. A held source lock is bypassed only for a revised run and its historical
   parent when the exact frozen plan has a complete valid run marker. Other
   held historical locks remain blockers.
2. Source JSON inventories are hashed before validation. Every JSON sidecar,
   request, response and dispatch receipt is included; only `progress.json`,
   which the producer can rewrite after completion, is excluded. JSON symlinks
   are rejected. Original labels/reference files are never inventoried or read.
3. All original v1 full-source-order, native-input, historical-checkpoint,
   per-case-budget and endpoint/dispatch provenance checks run unchanged.
4. The exact final union's request/response slots are physically copied to a
   separate namespace. They are not hard-linked to producer files. Every copied
   byte must match the hash established by v1; missing slots remain missing.
5. Completion markers are revalidated and the full source JSON inventory must
   match its initial hash inventory. The snapshot is atomically installed only
   after these checks. A changed/incomplete source prevents native invocation.
6. V1 assembles the same raw union from the snapshot and invokes its unchanged
   native scorer once. All metric formulas, invalid-answer accounting and
   original case denominators remain unchanged. The snapshot receipt and
   wrapper hashes are added to union provenance metadata.

After sealing, a later producer-file change cannot change native input bytes.
The result describes the byte-identical captured source snapshot. Its receipt
retains original source paths and SHA-256 hashes for independent auditing.

## Validation

Run from the repository root:

```sh
python3 -B -m unittest discover \
  -s .local/evaluation_revision_2026-10-18/scoring/sealed_completion_v2 \
  -p 'test_sealed_completion_scoring.py' -v
```

All fixtures are artificial. The unchanged P16 scorer is exercised on three
artificial rows, retaining one invalid/truncated historical answer: accuracy
stays `2/3`, parsed coverage `2/3`, original denominator `3`, and output budgets
`{4096: 2, 16384: 1}`. Source bytes remain unchanged. Other tests cover held
locks, missing/partial/wrong completion, incomplete receipts, extra raw cases,
mutations during copying, label isolation, snapshot tampering, one-attempt
failure/completion, and isolation from a source mutation after sealing.

See `synthetic_tests.log` for the final captured result. Tests write temporary
fixtures only inside this new directory and remove them after each test.

## Review and activation steps (not executed)

1. Review this source, test log and `package_manifest.json`. Pin this wrapper's
   SHA-256 and preserve the existing v1 adapter, producer, task specs and plans.
2. Confirm the intended task has every required completion marker, no prior
   native invocation/failure, and sufficient disk space for a **physical** copy
   of the full retained4K/prospective16K request/response union. This can be much
   larger than the new16K cohort alone. Hashing/copying also adds shared-disk I/O.
3. Preserve the current scoring watcher status and worker identity. Cleanly
   retire **only the idle CPU scoring watcher** before running this bridge;
   leave GPU dispatchers/servers/held owners, uploads and reporting intact.
   The old watcher's nonblocking derived-output lock treats contention as a
   permanent failure, so concurrent v1/v2 scoring would create misleading state.
   If worker retirement is not authorized, leave this package unactivated.
4. On the existing CPU allocation and pinned interpreter, invoke the wrapper
   with the **unchanged frozen task spec**, its exact SHA-256, and this wrapper's
   exact SHA-256. Use `--validate-only` first if desired. That option creates the
   sealed snapshot and returns validation only; it never opens reference labels.

   ```text
   <pinned-native-python> -u <this-directory>/sealed_completion_scoring.py
     --spec <unchanged-v1-task-spec.json>
     --spec-sha256 <exact-existing-spec-sha256>
     --wrapper-sha256 <reviewed-wrapper-sha256>
   ```

   CLI arguments are intentionally mandatory pins. The bridge does not poll or
   launch workers itself. Do not edit running code or regenerate protocol plans.
5. Verify `completion.json`, `native_scores_unmodified.json`, `scores.json`,
   original denominator and snapshot receipt in the same existing derived run
   namespace. V1's identical spec/output identity means its unchanged worker
   recognizes and reuses a successful bridge-produced result without scoring
   again. Failed attempts remain terminal and are not automatically retried.
6. Resume the unchanged v1 watcher after the one-off bridge call, or prepare a
   separately reviewed serial watcher using this wrapper for future completed
   tasks. Preserve/merge prior worker state; never overwrite a failed attempt or
   use a second output identity to obtain another score. Existing trajectory
   and report publishers already discover the original derived run namespace.

## Limits and smaller alternatives

The smallest no-change option is to wait until each full host pool ends; this
preserves correctness but delays P07 scoring. Altering live producer code,
unlocking its held descriptors, trusting a completion marker without validating
raw bytes, or scoring directly from hard links into live producer files is less
safe. This bridge avoids all four.

The completeness claim depends on the pinned producer's atomic, exclusive
completion marker and no-post-completion-write contract, reinforced by two
source-inventory checks and independent physical copies. It is not a defense
against a malicious same-user process modifying files adversarially between
filesystem calls. Ordinary concurrent additions/changes and incomplete marker
claims fail validation. No parser repair, label-guided logic or favorable
subset is introduced.
