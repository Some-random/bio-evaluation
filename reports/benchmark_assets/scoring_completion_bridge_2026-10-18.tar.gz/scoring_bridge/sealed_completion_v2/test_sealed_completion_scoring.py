"""Synthetic-only tests; all writes remain beneath this new review directory."""
from contextlib import ExitStack, redirect_stdout
import fcntl
import importlib.util
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import sealed_completion_scoring as sealed

fixture_spec = importlib.util.spec_from_file_location(
    'unchanged_mixed_v1_synthetic_fixtures', HERE.parent / 'test_mixed_budget_scoring.py')
fixtures = importlib.util.module_from_spec(fixture_spec)
sys.path.insert(0, str(HERE.parent))
fixture_spec.loader.exec_module(fixtures)


class SealedCompletionTests(unittest.TestCase):
    def setUp(self):
        scratch = HERE / 'test_scratch'
        scratch.mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=scratch)
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.fx = fixtures.MixedFixture(root)
        marker = self.fx.new / 'generation_completion.json'
        value = json.loads(marker.read_text())
        value['scoring_performed'] = False
        fixtures.save(marker, value)
        self.adapter = sealed.SealedScoring(root / 'sealed')
        self.v1 = self.adapter.v1

    def held_producer_locks(self):
        stack = ExitStack()
        for folder in (self.fx.old, self.fx.new):
            handle = stack.enter_context((folder / 'worker.lock').open('a'))
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return stack

    def score(self, **kwargs):
        return self.adapter.score(self.fx.spec, validator=self.fx.validator, **kwargs)

    def test_complete_source_seals_while_producer_locks_remain_held(self):
        with self.held_producer_locks():
            unchanged = sealed.load_v1()
            with self.assertRaises(unchanged.Pending):
                with unchanged.source_locks(self.fx.spec):
                    pass
            result = self.score(validate_only=True)
        self.assertEqual(result['planned'], 3)
        self.assertEqual(result['output_budget_counts'], {'4096': 2, '16384': 1})
        receipt = self.v1.read(next((self.fx.root / 'sealed').glob('*/seal_receipt.json')))
        self.assertFalse(receipt['labels_read'])
        for name, slot in receipt['slots'].items():
            copied = self.fx.root / 'sealed' / self.v1.digest(self.fx.spec) / name
            original = Path(slot['original_source'])
            self.assertEqual(copied.read_bytes(), original.read_bytes())
            self.assertNotEqual(copied.stat().st_ino, original.stat().st_ino)

    def test_missing_completion_blocks_without_scorer_attempt(self):
        (self.fx.new / 'generation_completion.json').unlink()
        with self.assertRaises(self.v1.Pending):
            self.score()
        self.assertFalse((self.fx.root / 'results/runs/artificial-mixed/native_scorer_invocation.json').exists())

    def test_partial_or_wrong_plan_completion_rejected(self):
        marker = self.fx.new / 'generation_completion.json'
        original = self.v1.read(marker)
        for change in ({'statuses': {'completed': 0}}, {'plan_sha256': 'different'},
                       {'retry_or_resampling': True}, {'scoring_performed': True}):
            fixtures.save(marker, {**original, **change})
            with self.subTest(change=change), self.assertRaises(self.v1.ScoringError):
                self.score(validate_only=True)

    def test_partial_dispatch_and_extra_raw_case_rejected(self):
        receipt = next((self.fx.new / 'dispatch').glob('*.json'))
        original = self.v1.read(receipt)
        fixtures.save(receipt, {**original, 'response_sha256': None})
        with self.assertRaisesRegex(self.v1.ScoringError, 'provenance'):
            self.score(validate_only=True)
        fixtures.save(receipt, original)
        fixtures.save(self.fx.new / 'responses/extra.json', {})
        with self.assertRaisesRegex(self.v1.ScoringError, 'Extra raw case'):
            self.score(validate_only=True)

    def test_completion_mutation_during_copy_rejects_snapshot(self):
        marker = self.fx.new / 'generation_completion.json'
        called = False
        def copy_and_change(source, target):
            nonlocal called
            shutil.copyfile(source, target)
            if not called:
                called = True
                value = self.v1.read(marker)
                fixtures.save(marker, {**value, 'finished_at_utc': 'synthetic mutation'})
        self.adapter.copy_file = copy_and_change
        with self.assertRaisesRegex(self.v1.ScoringError, 'inventory changed'):
            self.score(validate_only=True)
        self.assertFalse((self.fx.root / 'sealed' / self.v1.digest(self.fx.spec)).exists())

    def test_raw_mutation_during_copy_rejects_snapshot(self):
        def copy_and_change(source, target):
            shutil.copyfile(source, target)
            target.write_bytes(target.read_bytes() + b' ')
        self.adapter.copy_file = copy_and_change
        with self.assertRaisesRegex(self.v1.ScoringError, 'copied raw slot changed'):
            self.score(validate_only=True)

    def test_protected_labels_not_read_during_validation_and_sealing(self):
        original_open = Path.open
        reference = (self.fx.root / 'refs.jsonl').resolve()
        def no_labels(path, *args, **kwargs):
            if path.resolve() == reference:
                raise AssertionError('Protected labels read before output sealing')
            return original_open(path, *args, **kwargs)
        with mock.patch.object(Path, 'open', new=no_labels), self.held_producer_locks():
            self.assertEqual(self.score(validate_only=True)['state'], 'validated')

    def test_native_accuracy_denominator_preserved_and_no_repeat(self):
        before = {str(p): self.v1.file_sha(p) for folder in (self.fx.old, self.fx.new)
                  for p in folder.rglob('*.json')}
        calls = []
        def native(command, **kwargs):
            calls.append(command)
            # The unchanged native P16 scorer runs only on artificial fixtures.
            with redirect_stdout(io.StringIO()):
                self.v1.invoke_native(self.fx.spec, Path(command[-3]), Path(command[-1]))
            return type('Result', (), {'returncode': 0})()
        with self.held_producer_locks():
            self.assertEqual(self.score(run_command=native)['state'], 'completed')
        output = self.fx.root / 'results/runs/artificial-mixed'
        scores = self.v1.read(output / 'scores.json')
        native_scores = self.v1.read(output / 'native_scores_unmodified.json')
        self.assertEqual(scores['planned'], 3)
        self.assertEqual(scores['parsed'], 2)
        self.assertEqual(scores['invalid_outputs'], 1)
        self.assertEqual(scores['metrics']['accuracy'], 2 / 3)
        self.assertEqual(native_scores['metrics'], scores['metrics'])
        self.assertEqual(scores['generation']['output_budget_counts'], {'4096': 2, '16384': 1})
        self.assertEqual(before, {str(p): self.v1.file_sha(p) for folder in (self.fx.old, self.fx.new)
                                 for p in folder.rglob('*.json')})
        self.assertEqual(self.score(run_command=native)['state'], 'existing_completed_unchanged')
        self.assertEqual(len(calls), 1)
        # An independent unchanged v1 worker also reuses this exact result/spec.
        self.assertEqual(sealed.load_v1().score_spec(self.fx.spec)['state'], 'existing_completed_unchanged')

    def test_source_changes_after_seal_cannot_change_native_input(self):
        def native(command, **kwargs):
            original = next((self.fx.new / 'responses').glob('*.json'))
            original.write_text('{"synthetic": "changed after the sealed transaction"}\n')
            with redirect_stdout(io.StringIO()):
                self.v1.invoke_native(self.fx.spec, Path(command[-3]), Path(command[-1]))
            return type('Result', (), {'returncode': 0})()
        self.score(run_command=native)
        scores = self.v1.read(self.fx.root / 'results/runs/artificial-mixed/scores.json')
        self.assertEqual(scores['metrics']['accuracy'], 2 / 3)

    def test_native_failed_attempt_is_never_repeated(self):
        calls = []
        def failed(command, **kwargs):
            calls.append(command)
            return type('Result', (), {'returncode': 1})()
        with self.assertRaisesRegex(self.v1.ScoringError, 'failed; attempt preserved'):
            self.score(run_command=failed)
        with self.assertRaisesRegex(self.v1.ScoringError, 'failed or changed; no retry'):
            self.score(run_command=failed)
        self.assertEqual(len(calls), 1)

    def test_reuse_validates_snapshot_bytes_and_contract(self):
        self.score(validate_only=True)
        self.assertEqual(self.score(validate_only=True)['state'], 'validated')
        snapshot = self.fx.root / 'sealed' / self.v1.digest(self.fx.spec)
        raw = next((snapshot / 'responses').glob('*.json'))
        raw.chmod(0o644)
        raw.write_bytes(raw.read_bytes() + b' ')
        with self.assertRaisesRegex(self.v1.ScoringError, 'snapshot bytes changed'):
            self.score(validate_only=True)


if __name__ == '__main__':
    unittest.main()
