"""Review-only additive bridge: seal completed sources before unchanged v1 scoring.

No inference, parser change, score repair, producer mutation, or worker restart.
Calling this module does not execute anything. Activation requires an explicit
CLI invocation against an already frozen v1 spec and this wrapper's SHA-256.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

HERE = Path(__file__).resolve().parent
V1_PATH = HERE.parent / 'mixed_budget_scoring.py'
V1_SHA256 = '2fa228b6518e8148e628604d56c180058e7df513efd86a161d88064260cd735f'


def load_v1():
    if hashlib.sha256(V1_PATH.read_bytes()).hexdigest() != V1_SHA256:
        raise RuntimeError('The frozen v1 adapter changed')
    spec = importlib.util.spec_from_file_location('private_sealed_v2_v1', V1_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class SealedScoring:
    """One serial caller, private v1 module, shared v1 output lock/no-repeat guard."""
    def __init__(self, snapshot_root=None, copy_file=shutil.copyfile):
        self.v1 = load_v1()
        self.original_validation = self.v1.validate_sources
        self.snapshot_root = Path(snapshot_root or HERE / 'sealed_sources').resolve()
        self.copy_file = copy_file
        self.before = None
        self.folders = None
        self.v1.source_locks = self.source_guard
        self.v1.validate_sources = self.validate_and_seal

    def completed_sources(self, spec):
        """Only revised source pairs with complete exact markers may bypass locks."""
        v1 = self.v1
        root = Path(spec['project_root']).resolve()
        revisions = v1.revision_index(spec)
        folders, bypass = set(), set()
        for source in spec['sources']:
            cfg = v1.base.checked_config(root, source['config_file'], source['config_sha256'])
            historical = v1.base.generation_folder(root, cfg, source)
            folders.add(historical)
            revision = revisions.get((str(root), cfg['run_id']))
            if revision:
                plan, binding, item = revision
                output = Path(item['output_directory']).resolve()
                marker = output / 'generation_completion.json'
                if not marker.is_file():
                    raise v1.Pending('Revised source lacks its completion marker: ' + str(output))
                value = v1.read(marker)
                planned = len(item['selected_case_ids'])
                statuses = value.get('statuses', {})
                if (value.get('condition') != v1.CONDITION
                        or value.get('plan_sha256') != binding['sha256']
                        or value.get('planned') != planned or not planned
                        or not isinstance(statuses, dict) or not statuses
                        or any(type(n) is not int or n < 0 for n in statuses.values())
                        or sum(statuses.values()) != planned
                        or set(statuses) - {'completed', 'transport_error', 'server_error'}
                        or value.get('generation_exit_code') != (0 if statuses.get('completed', 0) == planned else 1)
                        or value.get('retry_or_resampling') is not False
                        or value.get('scoring_performed') is not False):
                    raise v1.ScoringError('Invalid or partial revised completion marker')
                folders.add(output)
                # Both parent and child are held by this same pinned producer.
                # V1 subsequently checks exact parent checkpoint and all raw bytes.
                bypass.update((historical / 'worker.lock', output / 'worker.lock'))
        return folders, bypass

    def inventory(self, folders):
        """Fingerprint all source JSON except producer progress, never labels.

        Only progress.json is mutable after a completed run. Every raw file,
        dispatch receipt, execution marker and provenance sidecar is included.
        Missing/extra JSON files change this inventory as well as file hashes.
        """
        result = {}
        for folder in sorted(folders):
            if not folder.is_dir():
                raise self.v1.Pending('Source directory is unavailable: ' + str(folder))
            for path in sorted(folder.rglob('*.json')):
                if path == folder / 'progress.json':
                    continue
                if path.is_symlink():
                    raise self.v1.ScoringError('Source JSON symlink is not a sealed regular file: ' + str(path))
                result[str(path)] = self.v1.file_sha(path)
        return result

    @contextmanager
    def source_guard(self, spec):
        folders, bypass = self.completed_sources(spec)
        handles = []
        try:
            for folder in sorted(folders):
                path = folder / 'worker.lock'
                if not folder.is_dir():
                    raise self.v1.Pending('Source has not started: ' + str(folder))
                handle = path.open('a')
                try:
                    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    handle.close()
                    if path not in bypass:
                        raise self.v1.Pending('Unsealed historical source remains active: ' + str(folder))
                else:
                    handles.append(handle)
            # Resample markers after lock checks, then freeze all consumed bytes.
            if self.completed_sources(spec)[0] != folders:
                raise self.v1.ScoringError('Completed source set changed')
            self.folders = folders
            self.before = self.inventory(folders)
            yield
        finally:
            self.before = self.folders = None
            for handle in handles:
                handle.close()

    def validate_and_seal(self, spec, validator=None):
        if self.before is None:
            raise self.v1.ScoringError('Sealing requires the guarded v1 output-lock transaction')
        # Reuse every v1 native-union/provenance/budget check unchanged.
        result = self.original_validation(spec, validator)
        slots = result[4]
        self.snapshot_root.mkdir(parents=True, exist_ok=True)
        destination = self.snapshot_root / self.v1.digest(spec)
        with tempfile.TemporaryDirectory(prefix='.building-', dir=self.snapshot_root) as temporary:
            building = Path(temporary)
            copied = {}
            for name, slot in sorted(slots.items()):
                target = building / name
                expected = slot['sha256']
                if expected is not None:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    # A physical copy, never a hard link to live producer files.
                    self.copy_file(Path(slot['source']), target)
                    if self.v1.file_sha(target) != expected:
                        raise self.v1.ScoringError('A copied raw slot changed after v1 validation')
                    target.chmod(0o444)
                elif Path(slot['source']).exists():
                    raise self.v1.ScoringError('A frozen missing raw slot appeared')
                copied[name] = {**slot, 'source': str(destination / name)}
            self.completed_sources(spec)
            if self.inventory(self.folders) != self.before:
                raise self.v1.ScoringError('Source metadata or raw inventory changed while sealing')
            receipt = {'schema_version': 2, 'spec_sha256': self.v1.digest(spec),
                'v1_adapter_sha256': V1_SHA256,
                'wrapper_sha256': self.v1.file_sha(__file__),
                'source_files_sha256': self.before,
                'slots': {name: {'original_source': slot['source'], 'sha256': slot['sha256']}
                          for name, slot in sorted(slots.items())},
                'source_inventory_sha256': self.v1.digest(self.before),
                'physical_copies': True, 'labels_read': False,
                'native_metrics_and_denominator_unchanged': True}
            self.v1.base.immutable_json(building / 'seal_receipt.json', receipt)
            if destination.exists():
                # A prior validation/preparation may have sealed identical bytes.
                existing = self.v1.read(destination / 'seal_receipt.json')
                if existing != receipt:
                    raise self.v1.ScoringError('Existing sealed snapshot contract changed')
                for name, slot in slots.items():
                    path = destination / name
                    if (self.v1.file_sha(path) if path.exists() else None) != slot['sha256']:
                        raise self.v1.ScoringError('Existing sealed snapshot bytes changed')
            else:
                # rename is atomic on this snapshot filesystem; all callers of a
                # spec already hold the original shared v1 derived-output lock.
                os.rename(building, destination)
                building.mkdir()  # TemporaryDirectory owns this now-empty path.
        # Add provenance only; the original union counts and all native fields
        # are unchanged. V1 carries this receipt pin into its derived manifest,
        # config, completion and score summary before invoking the native scorer.
        union = {**result[6], 'sealed_completion_snapshot': {
            'path': str(destination),
            'receipt_sha256': self.v1.file_sha(destination / 'seal_receipt.json'),
            'wrapper_path': str(Path(__file__).resolve()),
            'wrapper_sha256': self.v1.file_sha(__file__),
            'native_input_bytes_match_frozen_raw_slots': True}}
        return (*result[:4], copied, result[5], union)

    def score(self, spec, **kwargs):
        # V1 takes exactly the existing derived-output lock before entering our
        # guard, and preserves completion/no-repeat/failed-attempt semantics.
        return self.v1.score_spec(spec, **kwargs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec', type=Path, required=True)
    parser.add_argument('--spec-sha256', required=True)
    parser.add_argument('--wrapper-sha256', required=True)
    parser.add_argument('--snapshot-root', type=Path)
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    adapter = SealedScoring(args.snapshot_root)
    if adapter.v1.file_sha(__file__) != args.wrapper_sha256:
        raise adapter.v1.ScoringError('Frozen v2 wrapper changed')
    spec = adapter.v1.pinned(args.spec, args.spec_sha256)
    print(json.dumps(adapter.score(spec, validate_only=args.validate_only), ensure_ascii=False))


if __name__ == '__main__':
    main()
