#!/usr/bin/env python3
"""Freeze the exact prospective16k cohort only after a verified clean pause.

Run separately on each serving host. This script acquires original dispatcher
endpoint/run locks and requires idle servers before reading the cohort. It never
submits inference or edits any original artifact.
"""
from __future__ import annotations

import argparse
from collections import Counter
import fcntl
import json
from pathlib import Path

import run_budget_revision as revision
from shared_vllm_resume import (SEGMENTS, RECEIPTS, Run, atomic_write, digest,
                               file_sha, raw_inventory, read, stamp,
                               validate_resume_provenance)
from run_shared_vllm_evaluations import load_amendment, require_idle_endpoint

ROOT = revision.ROOT
OUT = Path(__file__).resolve().parent
RETAINED = {'P07', 'P08', 'P12', 'P13', 'P14', 'P15', 'P16'}
AUTHORIZATION = ("so like why the fuck don't you increate the context limit? "
                 "for the parsing issues, maybe we can try some simple fix? or maybe we can jsut ignore them? "
                 "i'm ok with both and if some evals are too problem matic, like bio resaon, "
                 "let's just remove them or ignore them, right?")


def freeze(group, source, source_sha):
    amendment, endpoints, entries = load_amendment(ROOT, source, source_sha, live=True)
    selected = [e for e in entries if e['task_id'] in RETAINED]
    states = [Run(e, ROOT, amendment, source, source_sha) for e in selected]
    endpoint_locks = []
    try:
        for endpoint in sorted(endpoints, key=lambda e: e['server_identity_sha256']):
            p = ROOT / '.local/shared_vllm_endpoint_locks' / (endpoint['server_identity_sha256'] + '.lock')
            h = p.open('a')
            try:
                fcntl.flock(h, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except Exception:
                h.close()
                raise revision.ResumeError('Original dispatcher is not yet drained')
            endpoint_locks.append(h)
        for state in states:
            state.acquire()
        for endpoint in endpoints:
            require_idle_endpoint(endpoint)
        items, summary = [], []
        for state in states:
            # This verifies all generations of retained raw output and their
            # request hashes, dispatch journals and original frozen contracts.
            proof = validate_resume_provenance(state.run, state.settings, state.cases)
            segments = [read(p) for p in (state.run / SEGMENTS).glob('*.json')]
            if proof['ambiguous_files'] or any(s['stage'] not in {'paused', 'terminal'} for s in segments):
                raise revision.ResumeError('Original producer is not cleanly paused')
            pending = list(state.pending())
            pending_ids = [c['case_id'] for c, _ in pending]
            files = raw_inventory(state.run)
            for name in ('shared_vllm_amendment.json', 'shared_vllm_saturation_amendment.json',
                         'shared_vllm_saturation_parent_checkpoint.json', 'shared_vllm_fork_manifest.json',
                         'shared_vllm_generation_completion.json', 'shared_vllm_saturation_generation_completion.json',
                         'shared_vllm_saturation_progress.json'):
                p = state.run / name
                if p.is_file():
                    files[name] = file_sha(p)
            for kind in ('shared_vllm_segments', 'shared_vllm_dispatch', 'shared_vllm_saturation_segments',
                         'shared_vllm_saturation_dispatch', 'shared_vllm_saturation_pauses'):
                for p in (state.run / kind).glob('*.json'):
                    files[kind + '/' + p.name] = file_sha(p)
            checkpoint = {
                'schema_version': 1, 'condition': revision.CONDITION,
                'parent_run_directory': str(state.run), 'original_source_run_id': state.entry['run_id'],
                'source_case_contract_sha256': digest(state.cases), 'ordered_pending_case_ids': pending_ids,
                'parent_source_amendment': {'path': str(source), 'sha256': source_sha},
                'ambiguous_files': proof['ambiguous_files'], 'parent_proof': proof,
                'retained_files_sha256': files,
                'selection_rule': 'all cases without any prior request/response/dispatch receipt at clean pause',
                'selection_uses_correctness_or_finish_reason': False,
            }
            cp = OUT / 'checkpoints' / (state.entry['run_id'] + '.json')
            if cp.exists():
                if read(cp) != checkpoint:
                    raise revision.ResumeError('Previously frozen cohort or original artifacts changed')
            else:
                atomic_write(cp, checkpoint, exclusive=True)
            summary.append({'run_id': state.entry['run_id'], 'task_id': state.entry['task_id'],
                            'original_source_cases': len(state.cases), 'pending16k_cases': len(pending),
                            'retained4k_statuses': proof['status_counts'], 'parent_checkpoint_sha256': file_sha(cp)})
            if not pending:
                continue
            items.append({
                'entry': state.entry,
                'case_scope': 'all_never_dispatched_at_clean_pause',
                'selected_case_ids': pending_ids, 'ordered_case_ids_sha256': digest(pending_ids),
                'parent_checkpoint': {'path': str(cp), 'sha256': file_sha(cp)},
                'context_check': amendment['run_context_checks'][state.entry['run_id']],
                'output_directory': str(OUT / 'results/runs' / (state.entry['run_id'] + '_output16384_v1')),
            })
        plan = {
            'schema_version': 1, 'kind': 'explicit_output_budget_revision',
            'execution_authorized': True, 'condition': revision.CONDITION, 'group': group,
            'authorization_quote': AUTHORIZATION, 'authorization_interpretation':
                'Increase output budget prospectively; preserve every already executed case and full native denominator. '
                'Exclude problematic BioReason/P28 and Bio-posttrain/P29 from further dispatch. '
                'This is explicitly a mixed4k/16k continuation, not a uniform16k rerun.',
            'model': revision.MODEL, 'model_revision': revision.REVISION,
            'output_budget': revision.BUDGET, 'original_output_budget': 4096,
            'code_sha256': file_sha(revision.__file__), 'excluded_task_ids': sorted(revision.EXCLUDED),
            'retained_task_ids': sorted(RETAINED), 'source_amendment': {'path': str(source), 'sha256': source_sha},
            'endpoints': endpoints, 'runs': items,
            'original_model_inputs_and_sampling_preserved_except_max_tokens': True,
            'retries_or_resampling_of_previously_executed_cases': False,
            'whole_task_metrics_require_original4k_and_new16k_union': True,
            'whole_task_metric_label': revision.CONDITION,
        }
        plan_path = OUT / ('plan_' + group + '.json')
        if plan_path.exists():
            if read(plan_path) != plan:
                raise revision.ResumeError('Previously frozen revision plan changed')
        else:
            atomic_write(plan_path, plan, exclusive=True)
        result = {'stage': 'frozen_not_dispatched', 'group': group, 'condition': revision.CONDITION,
                  'created_at_utc': stamp(), 'plan_path': str(plan_path), 'plan_sha256': file_sha(plan_path),
                  'new16k_cases': sum(len(x['selected_case_ids']) for x in items),
                  'run_count': len(items), 'source_runs': summary,
                  'servers_idle_and_original_run_locks_verified': True,
                  'all_parent_saved_responses_and_provenance_verified': True}
        atomic_write(OUT / ('preparation_' + group + '.json'), result)
        return result
    finally:
        for state in states:
            state.close()
        for h in endpoint_locks:
            h.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--group', required=True, choices=['existing_pool', 'new_pool'])
    parser.add_argument('--source-amendment', required=True, type=Path)
    parser.add_argument('--source-amendment-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(freeze(args.group, args.source_amendment, args.source_amendment_sha256), indent=2), flush=True)
