#!/usr/bin/env python3
"""Wait for root's drain receipt, freeze/check the prospective cohort, dispatch.

This launcher never signals a serving owner or API process. Root retains their
lifetime controls; signals to this launcher are forwarded to its dispatcher only
so already submitted calls can finish before this Slurm step exits.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from zoneinfo import ZoneInfo

import prepare_budget_revision as prep
import run_budget_revision as revision


def proc(pid):
    data = Path('/proc') / str(pid)
    raw = (data / 'stat').read_text()
    fields = raw[raw.rfind(')') + 2:].split()
    return {'pid': pid, 'state': fields[0], 'ppid': int(fields[1]), 'start_ticks': fields[19],
            'argv': (data / 'cmdline').read_bytes().decode().rstrip('\0').split('\0')}


def launch(group, source, source_sha):
    out = prep.OUT
    status_path = out / ('launcher_' + group + '.json')
    receipt_path = out.parent / 'control' / ('drain_' + group + '.json')
    child = None
    stopping = False
    common = {'group': group, 'condition': revision.CONDITION, 'launcher': proc(os.getpid()),
              'python': sys.executable, 'slurm_job_id': os.environ.get('SLURM_JOB_ID'),
              'slurm_step_id': os.environ.get('SLURM_STEP_ID'),
              'runner_sha256': revision.file_sha(revision.__file__)}

    def status(stage, **fields):
        revision.atomic_write(status_path, {**common, 'stage': stage, **fields,
            'updated_at_pacific': dt.datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()})

    def stop(signum, frame):
        nonlocal stopping
        stopping = True
        if child is not None and child.poll() is None:
            os.kill(child.pid, signal.SIGTERM)

    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, stop)
    try:
        status('awaiting_verified_root_drain')
        while True:
            if stopping:
                status('stopped_before_dispatch')
                return 0
            if receipt_path.is_file():
                receipt = revision.read(receipt_path)
                if receipt.get('stage') == 'drained_servers_retained':
                    common['root_drain_receipt_sha256'] = revision.file_sha(receipt_path)
                    break
            time.sleep(5)
        status('freezing_clean_pending_cohort')
        frozen = prep.freeze(group, source, source_sha)
        common.update(plan_path=frozen['plan_path'], plan_sha256=frozen['plan_sha256'],
                      new16k_cases=frozen['new16k_cases'], run_count=frozen['run_count'])
        status('checking_frozen_cohort')
        checked = revision.run(Path(frozen['plan_path']), frozen['plan_sha256'], check_only=True)
        revision.atomic_write(out / ('preflight_' + group + '.json'), checked, exclusive=True)
        if stopping:
            status('stopped_before_dispatch')
            return 0
        command = [sys.executable, '-u', str(Path(revision.__file__).resolve()),
                   '--plan', frozen['plan_path'], '--plan-sha256', frozen['plan_sha256']]
        log = out / ('dispatcher_' + group + '.log')
        with log.open('x') as stream:
            child = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            common['dispatcher'] = proc(child.pid)
            status('evaluating', log_path=str(log))
            code = child.wait()
        status('dispatcher_returned', dispatcher_exit_code=code, log_path=str(log),
               serving_owners_remain_root_controlled=True)
        return code
    except Exception as e:
        status('refused', error_type=type(e).__name__, error_message=str(e))
        if child is not None and child.poll() is None:
            os.kill(child.pid, signal.SIGTERM)
            child.wait()
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--group', required=True, choices=['existing_pool', 'new_pool'])
    parser.add_argument('--source-amendment', required=True, type=Path)
    parser.add_argument('--source-amendment-sha256', required=True)
    args = parser.parse_args()
    raise SystemExit(launch(args.group, args.source_amendment, args.source_amendment_sha256))
