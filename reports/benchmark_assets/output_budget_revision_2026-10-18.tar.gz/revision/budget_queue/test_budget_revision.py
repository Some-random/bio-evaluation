import copy
from pathlib import Path
import tempfile
import threading
import types
import unittest

import run_budget_revision as r


class Helper:
    @staticmethod
    def request_record(case, settings):
        payload = {'model': settings['model'], 'messages': copy.deepcopy(case['messages']),
                   **copy.deepcopy(settings['generation'])}
        return {'task': case['task'], 'case_id': case['case_id'], 'variant': case['variant'],
                'split': case['split'], 'payload': payload, 'request_sha256': r.digest(payload),
                'supplied_fields': ['messages']}


class BudgetRevisionTests(unittest.TestCase):
    def test_only_authorized_budget_changes_and_original_is_immutable(self):
        original = {'model': r.MODEL, 'generation': {'max_tokens': 4096, 'temperature': 1.0,
                    'top_p': .95, 'top_k': 20, 'seed': 42, 'n': 1,
                    'chat_template_kwargs': {'enable_thinking': True}}}
        case = {'task': 'P12', 'case_id': 'artificial-1', 'variant': 'synthetic', 'split': 'synthetic',
                'messages': [{'role': 'user', 'content': 'Artificial fixture only'}]}
        snapshot = copy.deepcopy(original)
        before = Helper.request_record(case, original)
        after = r.revised_request(Helper, case, original)
        self.assertEqual(original, snapshot)
        self.assertEqual(after['payload']['max_tokens'], 16384)
        normalized = copy.deepcopy(after)
        normalized['payload']['max_tokens'] = 4096
        normalized['request_sha256'] = r.digest(normalized['payload'])
        self.assertEqual(normalized, before)

    def test_helper_cannot_change_other_payload_fields(self):
        class BadHelper(Helper):
            @staticmethod
            def request_record(case, settings):
                value = Helper.request_record(case, settings)
                if settings['generation']['max_tokens'] == 16384:
                    value['payload']['seed'] = 7
                    value['request_sha256'] = r.digest(value['payload'])
                return value
        settings = {'model': r.MODEL, 'generation': {'max_tokens': 4096, 'seed': 42}}
        case = {'task': 'P12', 'case_id': 'artificial', 'variant': 'synthetic', 'split': 'synthetic', 'messages': []}
        with self.assertRaises(r.ResumeError):
            r.revised_request(BadHelper, case, settings)

    def state(self, prompt):
        case = {'case_id': 'artificial'}
        return types.SimpleNamespace(entry={'task_id': 'P16', 'run_id': 'synthetic', 'minimum_context_tokens': 65536},
                    settings={'generation': {'max_tokens': 16384}}, prompt_tokens={'artificial': prompt},
                    pending=lambda: iter([(case, 'fixture.json')]))

    def endpoint(self):
        return {'endpoint_id': 'synthetic', 'max_model_len': 65536, 'queue_limit': 64,
                'max_inflight': 64, 'scheduler_policy': 'vllm_native_bounded_queue'}

    def test_longest_observed_prompt_fits16k_without_context_restart(self):
        state = self.state(45219)
        q = r.RevisionTaskQueue([state], [self.endpoint()])
        self.assertIs(q.take(self.endpoint(), threading.Event())[0], state)

    def test_context_overflow_is_rejected_instead_of_truncating_input(self):
        with self.assertRaises(r.ResumeError):
            r.RevisionTaskQueue([self.state(49153)], [self.endpoint()])

    def test_original4096_budget_not_mislabeled_as_new16k(self):
        state = self.state(10)
        state.settings['generation']['max_tokens'] = 4096
        with self.assertRaises(r.ResumeError):
            r.RevisionTaskQueue([state], [self.endpoint()])

    def test_previously_claimed_parent_case_refused_before_dispatch(self):
        with tempfile.TemporaryDirectory() as folder:
            state = object.__new__(r.RevisionRun)
            state.parent_run = Path(folder)
            (state.parent_run / 'requests').mkdir()
            (state.parent_run / 'requests' / 'fixture.json').write_text('{}')
            with self.assertRaises(r.ResumeError):
                state.dispatch({}, 'fixture.json', {}, threading.Event())


if __name__ == '__main__':
    unittest.main()
