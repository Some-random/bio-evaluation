"""Read-only DeepFRI formatting snapshot with original schema validation."""
from __future__ import annotations
import ast
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
import math
from pathlib import Path

from diagnose_final_format import BASE, ROOT, digest, save, sha
from json_fence_only_v1 import unwrap_json_fence


def diagnose(task):
    freeze = json.loads((BASE / "json_fence_rules_freeze.json").read_text())
    if any(sha((BASE / name).read_bytes()) != expected
           for name, expected in freeze["source_sha256"].items()):
        raise ValueError("Frozen JSON fence rules changed")
    project = ROOT / ".local/remaining_evaluations/deepfri"
    run_id = "qwen38_27b_" + task.lower() + "_restored_replay_2026-10-16"
    folder = ROOT / "results/runs" / run_id
    raw_manifest = (folder / "run_manifest.json").read_bytes()
    cfg = json.loads(raw_manifest)["configuration"]
    review_raw = (project / cfg["review_file"]).read_bytes()
    vocab_raw = (project / cfg["class_vocabulary_file"]).read_bytes()
    source_raw = (project / "scripts/prepare_local_deepfri_proposals.py").read_bytes()
    for name, raw in [(cfg["review_file"], review_raw),
                      (cfg["class_vocabulary_file"], vocab_raw),
                      ("scripts/prepare_local_deepfri_proposals.py", source_raw)]:
        if sha(raw) != cfg["frozen_files_sha256"][name]:
            raise ValueError("Original native input/parser changed: " + name)
    ids = json.loads(review_raw)["approved_case_ids"]
    if len(ids) != cfg["planned"] or len(ids) != len(set(ids)):
        raise ValueError("Incomplete planned input review")
    allowed = [row["class_id"] for row in json.loads(vocab_raw)["classes"]]
    parsed_ast = ast.parse(source_raw)
    native_def = next(node for node in parsed_ast.body if isinstance(node, ast.FunctionDef)
                      and node.name == "parse_sparse_confidence")
    namespace = {"json": json, "math": math}
    exec(compile(ast.Module(body=[native_def], type_ignores=[]), "frozen_native_parser", "exec"), namespace)
    native = namespace["parse_sparse_confidence"]
    originals = []
    for case_id in ids:
        name = digest([task, cfg["variant"], case_id]) + ".json"
        path = folder / "responses" / name
        originals.append((case_id, name, path.read_bytes() if path.exists() else None))
    out = BASE / "diagnostics" / (task.lower() + "_json_fence")
    out.mkdir(parents=True, exist_ok=False)
    lock = {"run_id": run_id, "run_manifest_sha256": sha(raw_manifest),
            "review_sha256": sha(review_raw), "vocabulary_sha256": sha(vocab_raw),
            "native_parser_source_sha256": sha(source_raw),
            "fence_rules_freeze_sha256": sha((BASE / "json_fence_rules_freeze.json").read_bytes()),
            "files_sha256": {name: sha(raw) if raw else None for _, name, raw in originals}}
    save(out / "input_output_lock.json", lock)
    counts, errors, rows = Counter(), Counter(), []
    for case_id, name, raw in originals:
        record = json.loads(raw) if raw else None
        if record and (record.get("case_id") != case_id or record.get("task") != task or record.get("variant") != cfg["variant"]):
            raise ValueError("Raw response identity changed")
        complete = bool(record and record.get("status") == "completed")
        final = record.get("text") if complete else None
        finish = record.get("finish_reason") if record else None
        if complete and final != (record["response"]["choices"][0]["message"].get("content") or ""):
            raise ValueError("Final content differs from raw API content")
        values, parse_errors = [], []
        for candidate in [final, unwrap_json_fence(final)]:
            try:
                values.append(native(candidate, allowed, finish))
                parse_errors.append(None)
            except (ValueError, TypeError) as exc:
                values.append(None)
                parse_errors.append(str(exc))
        old, formatted = values
        if old is not None and old != formatted:
            raise ValueError("Fencing changed original valid vector")
        counts["planned"] += 1
        counts["completed"] += int(complete)
        counts["missing_or_failed"] += int(not complete)
        counts["blank_final"] += int(complete and not (final or "").strip())
        counts["token_limit_finish"] += int(complete and finish == "length")
        counts["native_parsed"] += int(old is not None)
        counts["fence_only_parsed"] += int(formatted is not None)
        counts["recovered_parses"] += int(old is None and formatted is not None)
        counts["native_vectors_preserved"] += int(old is not None and old == formatted)
        if complete and parse_errors[1]:
            errors[parse_errors[1]] += 1
        rows.append({"case_id": case_id, "status": record.get("status") if record else "missing_at_snapshot",
                     "finish_reason": finish, "response_sha256": sha(raw) if raw else None,
                     "native_parsed": old is not None, "fence_only_parsed": formatted is not None,
                     "native_error": parse_errors[0], "fence_only_error": parse_errors[1],
                     "recovered_sparse_scores": formatted if old is None and formatted is not None else None})
    result = {"task": task, "run_id": run_id,
              "snapshot_at_pacific": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
              "counts": dict(counts), "errors": dict(errors),
              "reference_labels_opened": False, "reasoning_fields_used": False,
              "native_schema_and_finish_checks_unchanged": True,
              "original_native_scores_unchanged": True,
              "accuracy_or_auc_computed": False,
              "all_original_planned_slots_retained": True,
              "input_output_lock_sha256": sha((out / "input_output_lock.json").read_bytes())}
    save(out / "per_case_diagnostic.json", rows)
    save(out / "summary.json", result)
    print(json.dumps(result), flush=True)
    return result


if __name__ == "__main__":
    summaries = [diagnose(task) for task in ["P12", "P13", "P14", "P15"]]
    save(BASE / "deepfri_json_fence_summaries.json", summaries)
