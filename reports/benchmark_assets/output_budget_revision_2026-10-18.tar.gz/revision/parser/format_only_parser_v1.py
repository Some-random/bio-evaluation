"""Independent formatting-only diagnostics; no label or reasoning access.

The returned value is a candidate, never an imputed answer. The caller retains
all planned slots and original native scores. Rules are frozen before output
inspection; only synthetic fixtures may be used to develop this version.
"""
from __future__ import annotations

import math
import re

VERSION = "FORMAT_ONLY_FINAL_V1"
NUMBER = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?"


def strip_formatting(text):
    """Remove presentation delimiters, without deleting prose or value units."""
    value = text.replace("\r\n", "\n").strip()
    fence = re.fullmatch(r"```(?:text|plaintext|markdown|md)?\s*\n(.*?)\n```", value,
                         flags=re.DOTALL | re.IGNORECASE)
    if fence:
        value = fence.group(1).strip()
    # Inline Markdown decoration is harmless for these scalar/label outputs.
    value = value.replace("**", "").replace("__", "")
    if value.startswith("`") and value.endswith("`") and value.count("`") == 2:
        value = value[1:-1].strip()
    return value


def value_for(text, kind, allowed_choices=None):
    value = strip_formatting(text)
    if kind == "binary":
        match = re.fullmatch(r"(yes|no)[.]?", value, re.IGNORECASE)
        return int(match.group(1).lower() == "yes") if match else None
    if kind == "number":
        if not re.fullmatch(NUMBER, value):
            return None
        number = float(value)
        return number if math.isfinite(number) else None
    if kind == "choice":
        match = re.fullmatch(r"(?:\(([A-Z])\)|([A-Z]))[.]?", value)
        if not match:
            return None
        letter = match.group(1) or match.group(2)
        return letter if allowed_choices and letter in allowed_choices else None
    if kind == "short_text":
        # Only an explicit answer line is eligible; free-text meaning is not
        # simplified, rewritten, truncated to keywords, or reference-matched.
        return value if value and "\n" not in value else None
    raise ValueError("Unknown kind: " + kind)


def parse_final(text, kind, allowed_choices=None):
    if not isinstance(text, str) or not text.strip():
        return {"value": None, "rule": None, "reason": "blank_final"}
    cleaned = strip_formatting(text)
    if kind != "short_text":
        value = value_for(cleaned, kind, allowed_choices)
        if value is not None:
            return {"value": value, "rule": "whole_final_scalar", "reason": None}
    lines = [line.strip() for line in cleaned.splitlines() if line.strip()]
    labelled = []
    for index, line in enumerate(lines):
        match = re.fullmatch(r"(?:final\s+)?answer\s*:\s*(.*)", line,
                             re.IGNORECASE)
        if match:
            labelled.append((index, match.group(1)))
    if len(labelled) != 1:
        return {"value": None, "rule": None,
                "reason": "no_unique_explicit_answer_line"}
    index, answer = labelled[0]
    if answer:
        terminal = index == len(lines) - 1
    else:
        terminal = index == len(lines) - 2
        answer = lines[index + 1] if terminal else ""
    if not terminal:
        return {"value": None, "rule": None,
                "reason": "answer_label_not_terminal"}
    value = value_for(answer, kind, allowed_choices)
    return {"value": value,
            "rule": "explicit_terminal_answer" if value is not None else None,
            "reason": None if value is not None else "answer_value_not_scalar"}
