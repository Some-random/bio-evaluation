"""Synthetic strings only, with no biological class vocabulary or labels."""
import unittest
from json_fence_only_v1 import unwrap_json_fence


class SyntheticJsonFences(unittest.TestCase):
    def test_fence(self):
        for tag in ["json", "", "JSON"]:
            self.assertEqual(unwrap_json_fence("```" + tag + '\n{"scores":{"fake":0.2}}\n```'),
                             '{"scores":{"fake":0.2}}')

    def test_prose_not_deleted(self):
        for text in ['Reasoning.\n```json\n{"scores":{}}\n```',
                     '```json\n{"scores":{}}\n```\nMore words.',
                     '```json\n{"scores":{}', '{"scores":{}}']:
            self.assertEqual(unwrap_json_fence(text), text)


if __name__ == "__main__":
    unittest.main()
