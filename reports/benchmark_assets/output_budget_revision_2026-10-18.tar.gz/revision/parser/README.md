# Formatting-only parser review

Prepared October 18, 2026, 12:19 PM PDT. All artifacts stay in this new diagnostic namespace; original run outputs, prompts, native parsers, scorers, and scores are unchanged.

Two small parsers were frozen before inspecting their respective benchmark outputs. They remove presentation formatting only: Markdown around a whole scalar or an explicit terminal answer line, and an entire JSON code fence. Nine synthetic tests pass. No scorer reference, target label, or reasoning field is used. Missing and invalid cases stay in the original planned denominators.

| Dataset | Planned cases retained | Completed responses checked | Native valid outputs | Additional formatting recoveries |
|---|---:|---:|---:|---:|
| P08 TAPE protein stability, 13 disjoint source shards | 12,851 | 7,251 | 7,130 | 0 |
| P12 DeepFRI enzyme classification | 1,919 | 415 | 192 | 0 |
| P13 DeepFRI biological process | 3,416 | 419 | 305 | 0 |
| P14 DeepFRI molecular function | 3,416 | 457 | 356 | 0 |
| P15 DeepFRI cellular component | 3,416 | 463 | 436 | 0 |

These are generation snapshots taken between 12:16 and 12:18 PM PDT, not full-dataset accuracy results. The stability union uses the three existing continuation folders in place of their parent folders and verifies all 12,851 case IDs are unique. Every original valid scalar and confidence vector was preserved exactly.

The small formatting fixes do not help these saved outputs. DeepFRI has 465 invalid completed responses: 407 fail the original missing/truncated/unfinished-final check, 52 contain an unknown class or nonnumeric confidence, and six contain duplicate JSON keys. The native schema, class vocabulary, probability bounds, duplicate-key rejection and finish checks remain enforced. Its 403 token-limit finishes and 374 blank final fields overlap; they must not be summed. Stability has 121 invalid completed responses, including ten blank final fields; eight responses finished at the token limit.

Keep these failures explicit. An absent final answer cannot be recovered by removing Markdown. Removing unsupported classes, guessing probabilities, selecting a number from prose, or searching reasoning would alter answer content. No such repair was attempted. Longer-output inference is a separate protocol revision managed by the main agent.

The older completed P01 DeepSol, P06 Meltome, B07 SeqQA, B08 Cloning, V04 ImageCLEF and V05 PMC-VQA raw run folders were not available in this shared checkout or on the retained CPU node. Their raw artifacts were not recovered during the bounded lookup, so this review claims no parser recovery result for those runs. Existing historical aggregate counts remain unchanged.

Machine-readable counts are in `diagnostic_summary.json`. `diagnostics/` contains per-case candidates and source-output hash locks without answer keys. `parser_rules_freeze.json` and `json_fence_rules_freeze.json` record the prospective rule hashes and freeze times. `artifact_manifest.json` hashes every review artifact except Python caches and itself.
