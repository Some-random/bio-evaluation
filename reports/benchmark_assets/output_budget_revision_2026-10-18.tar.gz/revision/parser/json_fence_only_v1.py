"""Remove an entire JSON presentation fence; retain native schema validation.

No JSON repair, brace searching, duplicate-key acceptance, new classes, invented
probabilities, reasoning fallback or truncated-response acceptance is allowed.
"""
import re


def unwrap_json_fence(final):
    if not isinstance(final, str):
        return final
    match = re.fullmatch(r"\s*```(?:json)?[ \t]*\r?\n(.*?)\r?\n```\s*",
                         final, re.DOTALL | re.IGNORECASE)
    return match.group(1).strip() if match else final
