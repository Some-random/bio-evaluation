"""Read-only, label-blind snapshot of a full frozen run's final formatting.

Nothing is written to original run folders. This intentionally does not compute
accuracy/correlation, open scorer-reference files, or inspect reasoning fields.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import importlib.util
import json
from pathlib import Path

from format_only_parser_v1 import parse_final

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(",", ":")).encode())


def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def diagnose(folder, out):
    freeze = json.loads((BASE / "parser_rules_freeze.json").read_text())
    if any(sha((BASE / name).read_bytes()) != expected
           for name, expected in freeze["source_sha256"].items()):
        raise ValueError("Frozen parser or synthetic tests changed")
    folder = folder.resolve()
    raw_manifest = (folder / "run_manifest.json").read_bytes()
    manifest = json.loads(raw_manifest)
    cfg = manifest["configuration"]
    task = cfg["approved_task_ids"][0]
    if task not in {"P01", "P02", "P06", "P07", "P08", "P10", "P11", "B07", "B08", "V04", "V05"}:
        raise ValueError("No predeclared diagnostic adapter for this task")
    kind = "binary" if task in {"P01", "P02", "P10", "P11"} else (
        "number" if task in {"P06", "P07", "P08"} else (
            "short_text" if task == "V04" else "choice"))
    review_path = ROOT / cfg["review_file"]
    review_raw = review_path.read_bytes()
    review = json.loads(review_raw)
    ids = review["approved_case_ids"]
    if len(ids) != len(set(ids)) or len(ids) != manifest["planned_cases"]:
        raise ValueError("Expected every unique planned case in original order")
    expected_review_sha = cfg.get("frozen_files_sha256", {}).get(cfg["review_file"])
    if expected_review_sha and sha(review_raw) != expected_review_sha:
        raise ValueError("Original input review changed")
    native_spec = importlib.util.spec_from_file_location("native_catalog", ROOT / "scripts/catalog_metric_helpers.py")
    native = importlib.util.module_from_spec(native_spec)
    native_spec.loader.exec_module(native)
    originals = []
    # Snapshot original hashes before parsing any final; missing slots are kept.
    for case_id in ids:
        name = digest([task, cfg["variant"], case_id]) + ".json"
        path = folder / "responses" / name
        raw = path.read_bytes() if path.exists() else None
        originals.append((case_id, name, raw))
    out.mkdir(parents=True, exist_ok=False)
    lock = {"run_id": cfg["run_id"], "task": task,
            "run_manifest_sha256": sha(raw_manifest), "review_sha256": sha(review_raw),
            "parser_freeze_sha256": sha((BASE / "parser_rules_freeze.json").read_bytes()),
            "files_sha256": {name: sha(raw) if raw is not None else None for _, name, raw in originals}}
    save(out / "input_output_lock.json", lock)
    rows, counts, reasons = [], Counter(), Counter()
    for case_id, name, raw in originals:
        record = json.loads(raw) if raw is not None else None
        if record and (record.get("case_id") != case_id or record.get("task") != task or record.get("variant") != cfg["variant"]):
            raise ValueError("Original response identity differs")
        completed = bool(record and record.get("status") == "completed")
        final = record.get("text") if completed else None
        if completed:
            message = record.get("response", {}).get("choices", [{}])[0].get("message", {})
            if final != (message.get("content") or ""):
                raise ValueError("Saved final differs from original API content")
        choices = None
        if kind == "choice" and completed:
            # Only original input choice labels can set the valid label range.
            import re
            request_path = folder / "requests" / name
            request = json.loads(request_path.read_text())
            pieces = request["payload"]["messages"]
            prompt = "\n".join(m["content"] if isinstance(m["content"], str) else "\n".join(x.get("text", "") for x in m["content"]) for m in pieces)
            choices = set(re.findall(r"^\s*\(?([A-Z])[).:]\s+", prompt, re.MULTILINE))
        parsed = parse_final(final, kind, choices)
        old = (native.parse_binary_answer(final) if kind == "binary" else
               native.parse_numeric_answer(final) if kind == "number" else None)
        counts["planned"] += 1
        counts["completed"] += int(completed)
        counts["missing_or_failed"] += int(not completed)
        counts["blank_final"] += int(completed and not (final or "").strip())
        counts["token_limit_finish"] += int(completed and record.get("finish_reason") == "length")
        counts["native_scalar_parsed"] += int(old is not None)
        counts["format_parser_parsed"] += int(parsed["value"] is not None)
        counts["recovered_scalar_parses"] += int(kind in {"binary", "number"} and old is None and parsed["value"] is not None)
        counts["native_values_preserved"] += int(old is not None and parsed["value"] == old)
        reasons[parsed["reason"] or parsed["rule"]] += 1
        rows.append({"case_id": case_id, "status": record.get("status") if record else "missing_at_snapshot",
                     "response_sha256": sha(raw) if raw else None,
                     "finish_reason": record.get("finish_reason") if record else None,
                     "native_scalar_value": old, "format_only_candidate": parsed})
    if counts["native_scalar_parsed"] != counts["native_values_preserved"]:
        raise ValueError("Formatter changed or lost an original scalar parse")
    result = {"run_id": cfg["run_id"], "task": task, "kind": kind,
              "snapshot_at_pacific": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
              "counts": dict(counts), "parse_reasons": dict(reasons),
              "original_native_scores_unchanged": True, "reference_labels_opened": False,
              "reasoning_fields_used": False, "accuracy_or_correlation_computed": False,
              "input_output_lock_sha256": sha((out / "input_output_lock.json").read_bytes()),
              "native_scalar_parser_source_sha256": sha((ROOT / "scripts/catalog_metric_helpers.py").read_bytes()),
              "failure_accounting": "Every original planned case retained; missing/failed/blank/unparsed slots never removed. Numeric missing values not invented.",
              "qualification": "Formatting adaptation diagnostic. Choice/short-text counts are extraction counts, not a comparison to native parser or correctness."}
    save(out / "per_case_diagnostic.json", rows)
    save(out / "summary.json", result)
    print(json.dumps(result), flush=True)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    diagnose(Path(args.run), Path(args.output))
