"""Synthetic fixtures only; no benchmark cases, outputs or reference labels."""
import unittest
from format_only_parser_v1 import parse_final


class SyntheticFormattingCases(unittest.TestCase):
    def check(self, text, kind, expected, choices=None):
        self.assertEqual(parse_final(text, kind, choices)["value"], expected)

    def test_binary_wrappers(self):
        for value in ["yes", "**Yes.**", "```text\nNo\n```", "Final answer: **Yes**"]:
            self.check(value, "binary", 0 if "No" in value else 1)

    def test_terminal_label(self):
        self.check("Explanation about an artificial case.\n\nAnswer: (C)", "choice", "C", "ABCD")
        self.check("Explanation.\n**Final answer:**\n**(D)**", "choice", "D", "ABCD")

    def test_numbers(self):
        for value in ["**-1.25e2**", "```\n-125\n```", "Final answer: -125"]:
            self.check(value, "number", -125.0)

    def test_no_reasoning_search(self):
        for value in ["Maybe Yes, maybe No.", "I calculated 12 and 19.",
                      "Answer: Yes\nLater: No", "Answer: Yes\nAnswer: No"]:
            self.check(value, "binary", None)

    def test_no_implicit_prose_or_units(self):
        self.check("The answer is yes.", "binary", None)
        self.check("Final answer: 21 Celsius", "number", None)
        self.check("Answer: D because of evidence.", "choice", None, "ABCD")

    def test_blank_and_illegal_choice(self):
        self.check("", "choice", None, "ABCD")
        self.check("(Z)", "choice", None, "ABCD")
        self.check("Final answer: inf", "number", None)

    def test_short_text_label_only(self):
        self.check("Discussion.\nFinal answer: artificial organ", "short_text", "artificial organ")
        self.check("A prose paragraph without a final answer label.", "short_text", None)


if __name__ == "__main__":
    unittest.main()
