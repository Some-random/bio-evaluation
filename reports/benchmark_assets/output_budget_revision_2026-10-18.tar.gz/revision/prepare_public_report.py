"""Package the reviewed revision after both hosts are processing its new cohort."""
from collections import Counter
from datetime import datetime
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tarfile
from zoneinfo import ZoneInfo

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
REV = ROOT / '.local/evaluation_revision_2026-10-18'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    groups, count = [], Counter()
    for group in ['existing_pool', 'new_pool']:
        status = read(REV / 'budget_queue' / ('launcher_' + group + '.json'))
        if status['stage'] not in ['evaluating', 'dispatcher_returned'] or status.get('dispatcher_exit_code', 0):
            raise ValueError('Both revised dispatchers must have started successfully')
        plan_path = Path(status['plan_path'])
        if sha(plan_path) != status['plan_sha256']:
            raise ValueError('Frozen revision plan changed')
        plan = read(plan_path)
        health = read(REV / 'control' / ('health_' + group + '.json'))
        if (health.get('plan_sha256') != status['plan_sha256']
                or not health.get('endpoints')
                or not all(e['healthy'] for e in health['endpoints'])
                or health.get('totals', {}).get('responses_saved', 0) < 1):
            raise ValueError('Require successful live revised health checks')
        for item in plan['runs']:
            count[item['entry']['task_id']] += len(item['selected_case_ids'])
        groups.append({'group': group, 'launcher': status, 'plan_path': str(plan_path),
                       'plan_sha256': status['plan_sha256'], 'health': health,
                       'future16k_cases': sum(len(x['selected_case_ids']) for x in plan['runs'])})
    parser = read(REV / 'parser/diagnostic_summary.json')
    selected = {Path(__file__), ROOT / 'AGENTS.md', ROOT / 'configs/main_evaluation_scope.json'}
    for part in ['budget_queue', 'control', 'scoring', 'publication', 'parser']:
        selected.update((REV / part).glob('*.py'))
    parser_manifest = read(REV / 'parser/artifact_manifest.json')
    selected.add(REV / 'parser/artifact_manifest.json')
    for name, expected in parser_manifest['files_sha256'].items():
        path = REV / 'parser' / name
        if sha(path) != expected:
            raise ValueError('Frozen parser evidence changed')
        selected.add(path)
    selected.update((REV / 'budget_queue/checkpoints').glob('*.json'))
    selected.update((REV / 'scoring').glob('*_v1.json'))
    for group in ['existing_pool', 'new_pool']:
        for name in ['plan_', 'preparation_', 'preflight_']:
            selected.add(REV / 'budget_queue' / (name + group + '.json'))
        selected.add(REV / 'control' / ('drain_' + group + '.json'))
    module = importlib.util.spec_from_file_location('revision_public_scan', ROOT / 'scripts/daily_backup.py')
    scanner = importlib.util.module_from_spec(module)
    module.loader.exec_module(scanner)
    members = {}
    for path in sorted(selected):
        if not path.is_file() or not path.resolve().is_relative_to(ROOT):
            raise ValueError('Missing or out-of-root frozen package member')
        scanner.scan_file(path)
        name = ('revision/' + str(path.relative_to(REV))
                if path.is_relative_to(REV) else str(path.relative_to(ROOT)))
        members[name] = path.read_bytes()
    index = {name: hashlib.sha256(raw).hexdigest() for name, raw in members.items()}
    members['revision_package_manifest.json'] = (json.dumps({'files_sha256': index}, indent=2) + '\n').encode()
    archive = ROOT / 'reports/benchmark_assets/output_budget_revision_2026-10-18.tar.gz'
    archive.parent.mkdir(exist_ok=True)
    with archive.open('wb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as tar:
                for name, raw in sorted(members.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(raw), 0o644, 0
                    tar.addfile(info, io.BytesIO(raw))
    # Apply the normal recursive public-export guard to the completed archive,
    # including its member names, before copying any report to a Git checkout.
    scanner.scan_file(archive)
    now = datetime.now(ZoneInfo('America/Los_Angeles'))
    data = {'prepared_at_pacific': now.isoformat(), 'condition': 'MIXED_BUDGET_4K16K_CONTINUATION',
            'old_output_budget': 4096, 'future_output_budget': 16384, 'server_context': 65536,
            'maximum_reviewed_input_tokens': 45219, 'maximum_input_plus_new_budget': 61603,
            'project_gpus': 8, 'vllm_version': '0.32.0', 'queue_limit_per_gpu': 64,
            'main_settings': 57, 'main_task_families': 31, 'categories': 8,
            'archived_task_ids': ['N01', 'N02', 'N03', 'N04', 'N05', 'P28', 'P29'],
            'retained_future16k_case_counts': dict(sorted(count.items())),
            'future16k_total': sum(count.values()), 'groups': groups,
            'parser_diagnostic': parser, 'old_outputs_resampled': False,
            'model_facing_delta': {'max_tokens': {'before': 4096, 'after': 16384}},
            'old_eta_superseded': True,
            'archive': {'path': str(archive.relative_to(ROOT)), 'sha256': sha(archive), 'members': len(members),
                        'content_policy': 'Frozen source, tests, cohorts and evidence only; no live trajectory directories, weights, environments, caches or credentials.'}}
    report_json = ROOT / 'reports/OUTPUT_BUDGET_REVISION_2026-10-18.json'
    report_md = report_json.with_suffix('.md')
    report_json.write_text(json.dumps(data, indent=2) + '\n')
    rows = '\n'.join(f'| {task} | {n:,} |' for task, n in sorted(count.items()))
    checked = parser['p08_counts']['completed'] + sum(x['counts']['completed'] for x in parser['deepfri_summaries'])
    report_md.write_text(f'''# Output budget and evaluation scope revision

Prepared {now.strftime('%B %d, %Y, %I:%M %p %Z')}. Human-readable times use Pacific time.

The remaining retained evaluations now use **16,384 output tokens**, increased from 4,096. The eight existing A100 80GB replicas continue on vLLM 0.32.0, with 64 queued requests per GPU and 95% GPU memory. Both new dispatchers started successfully, and both hosts passed their revised live health checks. The servers were retained through a clean producer handoff; no weight reload or vLLM restart was needed.

The truncation limit was the output budget. The server context remains 65,536 tokens: the largest reviewed input is 45,219 tokens, and input plus the new output allowance is 61,603. Increasing input context would not address those earlier output-limit finishes.

The prospective cohort contains **{sum(count.values()):,} never-dispatched cases**. Only `max_tokens` changes; the original complete inputs, checkpoint, BF16 precision, sampling, seed and native metric formulas remain fixed. Every old response remains immutable, including truncated or invalid answers. No completed or ambiguous case is rerun.

| Retained task | Future cases at 16,384 output tokens |
|---|---:|
{rows}

Whole-task scoring joins the complete original case order across the older 4K calls and the new 16K cohort. Results are explicitly labeled **mixed 4K/16K budget**; a task with no future 16K calls retains an all-4K label. The original invalid/missing cases stay in the full denominator. Parsed-only correlations or confidence diagnostics remain separately labeled, and an undefined full primary metric is not promoted to a complete benchmark score.

BioReason, BioReason-Pro and Bio-posttrain settings **N01–N05, P28 and P29** are set aside from the main comparison. P28/P29 received no further new admissions after the old queues were paused; their already-submitted calls drained and were preserved. The main presentation now contains **57 settings, 31 task families and 8 categories**. The original 64-setting catalog, raw outputs and scores remain in the [archive](ARCHIVED_EVALUATIONS.md).

Simple parser repair was tried independently of reference labels. Frozen formatting-only rules covered whitespace, Markdown/code fences and explicit terminal answer labels while preserving native valid predictions. Across **{checked:,} completed responses**, cleanup recovered **zero additional answers**. P08 had 7,130 valid scalars out of 7,251 completed responses. DeepFRI had 1,289 valid vectors out of 1,754; its 465 invalid responses comprised 407 missing/truncated/unfinished finals, 52 unknown classes or nonnumeric confidences, and 6 duplicate JSON keys. These are retained as invalid outputs. Reasoning is not mined for guessed answers.

The revised pipeline keeps per-minute endpoint, token-progress, response-integrity and output-format checks. Separate CPU scoring waits for complete original case unions and validates each case against its actual frozen output budget. Returned infrastructure errors stop new dispatch and preserve in-flight work. The revised trajectory publisher uses its own state and archives the new raw requests, responses, reasoning and serving provenance incrementally.

The previous completion estimate applied to the earlier 4K, BioReason-inclusive plan. Dropping tasks and raising output allowances both change the workload, so that estimate is superseded; a new estimate requires sustained progress under this revised plan.

[Live deployment snapshot, cohort counts and assumptions](OUTPUT_BUDGET_REVISION_2026-10-18.json) · [Frozen source, tests, cohort and parser evidence](benchmark_assets/output_budget_revision_2026-10-18.tar.gz) · [Main overview](EVALUATION_OVERVIEW.md).
''')
    paths = [str(p.relative_to(ROOT)) for p in [report_md, report_json, archive]]
    manifest = {'files': paths, 'ready': True,
                'baseline_commit': 'd007f780aab1495cd3fa3f9df8038dbbd93570e7',
                'message': 'Document prospective16k output budget and archived evaluation scope',
                'sha256': {name: sha(ROOT / name) for name in paths}}
    (REV / 'technical_publication_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'stage': 'prepared', 'future16k_cases': sum(count.values()), 'members': len(members), 'files': paths, 'sha256': manifest['sha256']}))


if __name__ == '__main__':
    main()
