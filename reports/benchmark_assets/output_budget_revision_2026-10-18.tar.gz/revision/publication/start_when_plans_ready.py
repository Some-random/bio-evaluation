#!/usr/bin/env python3
"""Start this authorized publisher after frozen plans and live preflight pass.

No inference or serving lifecycle control. Only the dedicated publisher child
receives shutdown signals. Existing publisher/compute processes are untouched.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from zoneinfo import ZoneInfo


def stamp():
    return datetime.now(ZoneInfo("America/Los_Angeles")).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def identity(pid):
    path = Path("/proc") / str(pid)
    raw = (path / "stat").read_text()
    fields = raw[raw.rfind(")") + 2:].split()
    return {"pid": pid, "state": fields[0], "ppid": int(fields[1]), "start_ticks": fields[19],
            "argv": (path / "cmdline").read_bytes().decode().rstrip("\0").split("\0")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    state = root / ".local/evaluation_revision_2026-10-18/publication"
    budget = state.parent / "budget_queue"
    script = state / "publish_budget_revision.py"
    receipt = json.loads((state / "preparation_receipt.json").read_text())
    expected_code = receipt["source_files_sha256"]["publish_budget_revision.py"]
    plans = [budget / ("plan_" + group + ".json") for group in ["existing_pool", "new_pool"]]
    common = {"condition": "MIXED_BUDGET_4K16K_CONTINUATION", "launcher": identity(os.getpid()),
              "python": sys.executable, "slurm_job_id": os.environ.get("SLURM_JOB_ID"),
              "slurm_step_id": os.environ.get("SLURM_STEP_ID"), "publisher_code_sha256": expected_code,
              "authorized_continuous_publication": True, "gpu_allocation": 0,
              "original_publishers_untouched": True}
    child, stopping = None, False
    def status(stage, **values):
        save(state / "launch_status.json", {**common, "stage": stage, **values, "updated_at_pacific": stamp()})
    def stop(signum, frame):
        nonlocal stopping
        stopping = True
        if child is not None and child.poll() is None:
            child.send_signal(signal.SIGTERM)
    for sig in [signal.SIGTERM, signal.SIGINT]:
        signal.signal(sig, stop)
    status("waiting_for_frozen_source_plans")
    while not all(path.is_file() for path in plans):
        if stopping:
            status("stopped_before_publication")
            return 0
        time.sleep(5)
    pins = [{"path": str(path), "sha256": sha(path)} for path in plans]
    save(state / "activated_source_plans.json", {"condition": common["condition"], "plans": pins,
         "frozen_at_pacific": stamp(), "publisher_code_sha256": expected_code})
    command = [sys.executable, "-u", str(script), "--root", str(root)]
    for pin in pins:
        command += ["--plan", pin["path"], "--plan-sha256", pin["sha256"]]
    while not stopping:
        if sha(script) != expected_code:
            status("refused_publisher_code_changed")
            return 1
        status("checking_actual_records", plans=pins)
        with (state / "preflight.log").open("a") as log:
            child = subprocess.Popen(command + ["--check-only", "--prepare-checkout", "--once"],
                                     cwd=root, stdout=log, stderr=subprocess.STDOUT)
            code = child.wait()
        child = None
        if code == 0:
            observed = json.loads((state / "status.json").read_text())
            save(state / "live_preflight_receipt.json", {**observed,
                 "verified_at_pacific": stamp(), "plans": pins, "publisher_code_sha256": expected_code})
            break
        status("preflight_retry_pending", exit_code=code, plans=pins)
        for _ in range(60):
            if stopping:
                break
            time.sleep(1)
    if stopping:
        status("stopped_before_publication")
        return 0
    if sha(script) != expected_code:
        status("refused_publisher_code_changed")
        return 1
    with (state / "publisher.log").open("a") as log:
        child = subprocess.Popen(command + ["--interval", "60"], cwd=root,
                                 stdout=log, stderr=subprocess.STDOUT)
        status("continuous_publisher_running", publisher=identity(child.pid), plans=pins,
               live_preflight_sha256=sha(state / "live_preflight_receipt.json"))
        code = child.wait()
    status("publisher_returned", publisher_exit_code=code, plans=pins)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
