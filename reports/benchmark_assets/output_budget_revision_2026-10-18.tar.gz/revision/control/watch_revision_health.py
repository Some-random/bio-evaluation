"""Observe the explicitly amended output budget without judging predictions."""
import argparse
from collections import Counter, defaultdict
from datetime import datetime
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import signal
import time
from urllib.request import ProxyHandler, build_opener
from zoneinfo import ZoneInfo

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
REV = ROOT / '.local/evaluation_revision_2026-10-18'
BASE = ROOT / '.local/shared_vllm_saturation_2026-10-18'
CONDITION = 'MIXED_BUDGET_4K16K_CONTINUATION'
HEALTH = BASE / 'watch_shared_vllm_health.py'
HEALTH_SHA = 'c2783f3c87e2ccd1ed97ed004aaf53c0420e6cea37d84c78b4c0dfb12e02c19f'
STOP = False


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':')).encode()).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.replace(path)


def now():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def metadata(case_id, record, request):
    if (record.get('case_id') != case_id or record.get('condition') != CONDITION
            or request['payload'].get('max_tokens') != 16384
            or digest(request['payload']) != request['request_sha256']
            or record.get('request_sha256') != request['request_sha256']):
        raise ValueError('Budget/case/request identity mismatch')
    response = record.get('response') or {}
    choices = response.get('choices') or []
    choice = choices[0] if choices else {}
    final = (choice.get('message') or {}).get('content')
    return {'case_id': case_id, 'status': record.get('status'),
            'http_status': record.get('http_status'),
            'finish_reason': record.get('finish_reason') or choice.get('finish_reason'),
            'empty_final': not final.strip() if isinstance(final, str) else not bool(final),
            'completion_tokens': (response.get('usage') or {}).get('completion_tokens'),
            'saved_at_utc': record.get('saved_at_utc')}


def cycle(group, health):
    control = REV / 'control'
    launcher = read(REV / 'budget_queue' / ('launcher_' + group + '.json'))
    report = {'updated_at_pacific': now(), 'group': group, 'condition': CONDITION,
              'launcher_stage': launcher['stage'], 'automatic_actions': [],
              'biological_correctness_checked': False}
    if not launcher.get('plan_path'):
        report['stage'] = 'awaiting_clean_transition'
        write(control / ('health_' + group + '.json'), report)
        return report
    plan_path = Path(launcher['plan_path'])
    if sha(plan_path) != launcher['plan_sha256']:
        raise ValueError('Frozen revision plan changed')
    plan = read(plan_path)
    if plan['condition'] != CONDITION or plan['output_budget'] != 16384:
        raise ValueError('Unexpected output-budget condition')
    state_path = control / ('health_state_' + group + '.json')
    state = read(state_path) if state_path.exists() else {'plan_sha256': launcher['plan_sha256'], 'cache': {}, 'endpoints': {}}
    if state['plan_sha256'] != launcher['plan_sha256']:
        raise ValueError('Health state belongs to another frozen cohort')
    server_plan = read(BASE / ('existing_upgrade/' if group == 'existing_pool' else '') / 'saturation_serving_plan.json')
    endpoints, flags = [], []
    opener = build_opener(ProxyHandler({}))
    for endpoint in plan['endpoints']:
        try:
            row = health.observe_endpoint(endpoint, server_plan, opener)
            metrics = row['metrics']
            previous = state['endpoints'].get(row['endpoint_id'], {})
            old = previous.get('metrics', {})
            progressing = any(metrics.get(key, 0) > old.get(key, 0) for key in ['generation_tokens', 'prompt_tokens'])
            busy = metrics['running'] + metrics['waiting'] > 0
            activity = time.time() if progressing or not previous or not busy else previous['last_activity_epoch']
            row['seconds_without_token_progress'] = max(0, time.time() - activity)
            if busy and row['seconds_without_token_progress'] >= 600:
                flags.append({'type': 'busy_without_observed_token_progress', 'endpoint_id': row['endpoint_id']})
            if metrics['kv_fraction'] >= .95:
                flags.append({'type': 'high_kv_usage', 'endpoint_id': row['endpoint_id']})
            if metrics.get('preemptions', 0) > old.get('preemptions', 0):
                flags.append({'type': 'preemptions_increased', 'endpoint_id': row['endpoint_id']})
            state['endpoints'][row['endpoint_id']] = {'metrics': metrics, 'last_activity_epoch': activity}
        except Exception as error:
            row = {'endpoint_id': endpoint['endpoint_id'], 'healthy': False, 'error': type(error).__name__ + ': ' + str(error)}
            flags.append({'type': 'endpoint_failure', 'endpoint_id': endpoint['endpoint_id']})
        endpoints.append(row)
    uuids = [u for e in endpoints for u in e.get('gpu_uuids', [])]
    if len(uuids) != 4 or len(set(uuids)) != 4:
        flags.append({'type': 'missing_or_duplicate_physical_gpu'})
    runs, by_task = [], defaultdict(Counter)
    for item in plan['runs']:
        folder = Path(item['output_directory'])
        cfg = read((ROOT / item['entry']['project_root']).resolve() / item['entry']['config_path'])
        expected = {digest([item['entry']['task_id'], cfg['variant'], case_id]) + '.json': case_id
                    for case_id in item['selected_case_ids']}
        responses = {p.name: p for p in (folder / 'responses').glob('*.json')}
        if not set(responses) <= set(expected):
            raise ValueError('Unexpected case in revision response namespace')
        records = []
        for name, path in responses.items():
            key = folder.name + '/' + name
            stat = path.stat()
            signature = [stat.st_size, stat.st_mtime_ns]
            cached = state['cache'].get(key)
            if cached is None or cached['signature'] != signature:
                raw = path.read_bytes()
                checksum = hashlib.sha256(raw).hexdigest()
                if cached and cached['sha256'] != checksum:
                    raise ValueError('Immutable saved response changed')
                value = metadata(expected[name], json.loads(raw), read(folder / 'requests' / name))
                cached = {'signature': signature, 'sha256': checksum, 'metadata': value}
                state['cache'][key] = cached
            records.append(cached['metadata'])
        counters = Counter(planned=len(expected), responses_saved=len(records),
                           length_finishes=sum(x['finish_reason'] == 'length' for x in records),
                           empty_final_fields=sum(x['empty_final'] for x in records),
                           transport_or_server_errors=sum(x['http_status'] != 200 or x['status'] != 'completed' for x in records))
        counters['remaining'] = counters['planned'] - counters['responses_saved']
        by_task[item['entry']['task_id']].update(counters)
        runs.append({'run_id': folder.name, 'task_id': item['entry']['task_id'], **counters,
                     'generation_terminal': (folder / 'generation_completion.json').is_file()})
    totals = Counter()
    for counts in by_task.values():
        totals.update(counts)
    if totals['transport_or_server_errors']:
        flags.append({'type': 'saved_transport_or_server_error'})
    if launcher['stage'] == 'refused' or launcher.get('dispatcher_exit_code', 0):
        flags.append({'type': 'dispatcher_failed'})
    report.update(stage='observing_revision', plan_sha256=launcher['plan_sha256'],
                  output_budget=16384, endpoints=endpoints, runs=runs,
                  by_task=dict(by_task), totals=dict(totals), flags=flags,
                  interpretation='Only the frozen future16k cohort is counted here; old4k calls remain in original archives and full mixed-budget metrics. Empty final is distinct from separately saved reasoning.')
    write(state_path, state)
    write(control / ('health_' + group + '.json'), report)
    history = {key: report[key] for key in ['updated_at_pacific', 'group', 'condition', 'launcher_stage', 'totals', 'by_task']}
    with (control / ('health_history_' + group + '.jsonl')).open('a') as stream:
        stream.write(json.dumps(history) + '\n')
    return report


def main():
    global STOP
    parser = argparse.ArgumentParser()
    parser.add_argument('--group', choices=['existing_pool', 'new_pool'], required=True)
    args = parser.parse_args()
    if sha(HEALTH) != HEALTH_SHA:
        raise ValueError('Pinned endpoint observer changed')
    spec = importlib.util.spec_from_file_location('revision_endpoint_health', HEALTH)
    health = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(health)
    def stop(signum, frame):
        global STOP
        STOP = True
    for sig in [signal.SIGTERM, signal.SIGINT]:
        signal.signal(sig, stop)
    with (REV / 'control' / ('health_' + args.group + '.lock')).open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        while not STOP:
            try:
                report = cycle(args.group, health)
                print(json.dumps({k: report.get(k) for k in ['updated_at_pacific', 'group', 'stage', 'launcher_stage', 'totals', 'flags']}), flush=True)
            except Exception as error:
                write(REV / 'control' / ('health_error_' + args.group + '.json'), {'updated_at_pacific': now(), 'error': type(error).__name__ + ': ' + str(error), 'last_successful_report_retained': True})
            for _ in range(60):
                if STOP:
                    break
                time.sleep(1)


if __name__ == '__main__':
    main()
