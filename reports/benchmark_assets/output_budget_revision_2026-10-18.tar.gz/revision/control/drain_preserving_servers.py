"""Drain one current producer while retaining its already verified vLLM servers."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import time
from datetime import datetime
from urllib.request import ProxyHandler, build_opener
from zoneinfo import ZoneInfo


def now():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def proc(pid):
    base = Path('/proc') / str(pid)
    fields = (base / 'stat').read_text().rsplit(')', 1)[1].split()
    return {'pid': pid, 'state': fields[0], 'ppid': int(fields[1]),
            'start_ticks': fields[19],
            'argv': (base / 'cmdline').read_bytes().decode().split('\0')[:-1]}


def save(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.replace(path)


def queue(endpoint):
    opener = build_opener(ProxyHandler({}))
    with opener.open(endpoint.removesuffix('/v1') + '/metrics', timeout=15) as res:
        raw = res.read().decode()
    counts = {'running': [], 'waiting': []}
    for line in raw.splitlines():
        if line.startswith('#'):
            continue
        fields = line.rsplit(None, 1)
        if len(fields) != 2:
            continue
        key = fields[0].split('{')[0]
        for state in counts:
            if key == 'vllm:num_requests_' + state:
                counts[state].append(float(fields[1]))
    if any(not rows for rows in counts.values()):
        raise ValueError('Required queue metrics missing')
    return {key: sum(values) for key, values in counts.items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pool', type=Path, required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    args = parser.parse_args()
    if args.receipt.exists():
        raise ValueError('One-use control receipt already exists')
    pool = args.pool.resolve()
    status = json.loads((pool / 'serving_status.json').read_text())
    if status['hostname'] not in {socket.gethostname(), socket.getfqdn()}:
        raise ValueError('Wrong pool host')
    if os.environ.get('SLURM_JOB_ID') != status['slurm_job_id']:
        raise ValueError('Wrong Slurm allocation')
    child = proc(status['dispatch_pid'])
    owner = proc(child['ppid'])
    expected = str(pool.parent / 'serve_saturation_pool.py') if pool.name == 'existing_upgrade' else str(pool / 'serve_saturation_pool.py')
    if (not any(arg.endswith('/run_shared_vllm_evaluations.py') for arg in child['argv'])
            or str(pool / 'amendment_existing_pool.json') in child['argv']):
        # The old host's amendment is in the common parent, checked below.
        raise ValueError('Unexpected dispatcher process')
    if expected not in owner['argv'] or str(pool) not in owner['argv']:
        raise ValueError('Unexpected serving owner')
    if owner['state'] in {'T', 't', 'Z'} or child['state'] in {'T', 't', 'Z'}:
        raise ValueError('Producer/owner was already stopped or dead')
    endpoints = json.loads((pool / 'saturation_endpoints.json').read_text())
    servers = []
    for endpoint in endpoints:
        raw = Path(endpoint['server_identity_file']).read_bytes()
        if hashlib.sha256(raw).hexdigest() != endpoint['server_identity_sha256']:
            raise ValueError('Server identity changed')
        identity = json.loads(raw)
        live = proc(identity['pid'])
        if live['start_ticks'] != str(identity['proc_start_ticks']):
            raise ValueError('Server PID identity changed')
        servers.append({'identity': identity, 'process': live,
                        'queue_before': queue(endpoint['endpoint'])})
    receipt = {'stage': 'validated_before_drain', 'requested_at_pacific': now(),
               'pool': str(pool), 'slurm_job_id': status['slurm_job_id'],
               'owner': owner, 'dispatcher': child, 'servers': servers,
               'owner_must_remain_stopped_to_preserve_servers': True,
               'automatic_resume_or_retry': False}
    save(args.receipt, receipt)
    os.kill(owner['pid'], signal.SIGSTOP)
    for _ in range(100):
        if proc(owner['pid'])['state'] in {'T', 't'}:
            break
        time.sleep(.01)
    else:
        raise RuntimeError('Serving owner did not stop')
    if proc(child['pid'])['start_ticks'] != child['start_ticks']:
        raise RuntimeError('Dispatcher PID identity changed before signal')
    os.kill(child['pid'], signal.SIGTERM)
    receipt.update(stage='draining_http_calls', drain_started_at_pacific=now())
    save(args.receipt, receipt)
    print(json.dumps({'stage': receipt['stage'], 'pool': str(pool),
                      'owner_pid': owner['pid'], 'dispatcher_pid': child['pid']}), flush=True)
    while True:
        try:
            current = proc(child['pid'])
        except FileNotFoundError:
            break
        if current['start_ticks'] != child['start_ticks']:
            raise RuntimeError('Dispatcher PID reused during drain')
        if current['state'] == 'Z':
            break
        time.sleep(2)
    raw = (pool / 'saturation_dispatch.log').read_text()
    offset = raw.rfind('{\n  "stage":')
    if offset < 0:
        raise ValueError('No final dispatcher receipt in log')
    result = json.loads(raw[offset:])
    if (result.get('stage') not in {'generation_paused', 'generation_terminal'}
            or result.get('generation_exit_code') != 0
            or not result.get('operator_pause')):
        raise ValueError('Dispatcher did not close with a clean operator pause')
    queues = [queue(e['endpoint']) for e in endpoints]
    if any(q['running'] or q['waiting'] for q in queues):
        raise ValueError('Requests remain after dispatcher closure')
    if proc(owner['pid'])['state'] not in {'T', 't'}:
        raise ValueError('Serving owner is no longer held')
    receipt.update(stage='drained_servers_retained', finished_at_pacific=now(),
                   all_http_calls_finished=True, queues_after=queues,
                   dispatcher_result=result)
    save(args.receipt, receipt)
    print(json.dumps({'stage': receipt['stage'], 'receipt': str(args.receipt)}), flush=True)


if __name__ == '__main__':
    main()
