"""Release a held serving owner only after its new cohort finishes successfully."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import signal
import time

from drain_preserving_servers import now, proc, queue, save
import hashlib

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
REV = ROOT / '.local/evaluation_revision_2026-10-18'


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--group', choices=['existing_pool', 'new_pool'], required=True)
    args = parser.parse_args()
    control = REV / 'control'
    result_path = control / ('release_' + args.group + '.json')
    with (control / ('release_' + args.group + '.lock')).open('a') as guard:
        fcntl.flock(guard, fcntl.LOCK_EX | fcntl.LOCK_NB)
        while True:
            launcher_path = REV / 'budget_queue' / ('launcher_' + args.group + '.json')
            launcher = read(launcher_path) if launcher_path.exists() else {}
            if launcher.get('stage') == 'dispatcher_returned' and launcher.get('dispatcher_exit_code') == 0:
                break
            if launcher.get('stage') == 'refused' or launcher.get('dispatcher_exit_code', 0):
                save(result_path, {'stage': 'held_after_failure', 'updated_at_pacific': now(),
                                   'automatic_retry': False, 'owner_resumed': False})
                return
            time.sleep(5)
        plan_path = Path(launcher['plan_path'])
        if hashlib.sha256(plan_path.read_bytes()).hexdigest() != launcher['plan_sha256']:
            raise ValueError('Frozen revision plan changed')
        plan = read(plan_path)
        for item in plan['runs']:
            completion = Path(item['output_directory']) / 'generation_completion.json'
            if not completion.exists():
                save(result_path, {'stage': 'held_after_operator_pause', 'updated_at_pacific': now(),
                                   'owner_resumed': False})
                return
            done = read(completion)
            if (done['plan_sha256'] != launcher['plan_sha256']
                    or done['generation_exit_code'] != 0
                    or done['statuses'] != {'completed': len(item['selected_case_ids'])}):
                raise ValueError('A revised source is not completely successful')
        drain_path = control / ('drain_' + args.group + '.json')
        if hashlib.sha256(drain_path.read_bytes()).hexdigest() != launcher['root_drain_receipt_sha256']:
            raise ValueError('Original drain/owner receipt changed')
        drain = read(drain_path)
        if drain.get('stage') != 'drained_servers_retained':
            raise ValueError('Missing verified retained-server owner')
        owner = proc(drain['owner']['pid'])
        if owner['start_ticks'] != drain['owner']['start_ticks'] or owner['state'] not in {'T', 't'}:
            raise ValueError('Serving-owner identity/state changed')
        locks = []
        try:
            for endpoint in sorted(plan['endpoints'], key=lambda e: e['server_identity_sha256']):
                path = ROOT / '.local/shared_vllm_endpoint_locks' / (endpoint['server_identity_sha256'] + '.lock')
                handle = path.open('a')
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                locks.append(handle)
            queues = [queue(e['endpoint']) for e in plan['endpoints']]
            if any(q['running'] or q['waiting'] for q in queues):
                raise ValueError('An endpoint still has outstanding work')
            save(result_path, {'stage': 'resuming_original_owner_for_normal_cleanup',
                               'updated_at_pacific': now(), 'owner': owner,
                               'all_revised_generations_completed': True,
                               'all_http_calls_finished': True,
                               'plan_sha256': launcher['plan_sha256'], 'owner_resumed': True})
            os.kill(owner['pid'], signal.SIGCONT)
        finally:
            for handle in reversed(locks):
                handle.close()


if __name__ == '__main__':
    main()
