"""Synthetic-only provenance/metric invariants; never opens real predictions or labels."""
import ast
import copy
import hashlib
import json
import math
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
RECEIPT = json.loads((HERE / 'derivation_receipt.json').read_text())
ORIGINAL = Path(RECEIPT['original_scorer_path'])
DERIVED = Path(RECEIPT['derived_scorer_path'])
ROOT = ORIGINAL.parents[1]


def guard_node(tree):
    matches = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.If):
            continue
        if any(isinstance(child, ast.Constant) and child.value == 'Saved final/finish fields conflict'
               for statement in node.body if isinstance(statement, ast.Raise)
               for child in ast.walk(statement)):
            matches.append(node)
    if len(matches) != 1:
        raise AssertionError('Require exactly one native final-provenance guard')
    return matches[0]


def compiled_guard(tree):
    guard = copy.deepcopy(guard_node(tree))
    function = ast.parse('def check(response):\n choice=response["response"]["choices"][0]\n final=choice["message"].get("content")\n return True\n').body[0]
    function.body.insert(-1, guard)
    namespace = {}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[])), '<native-guard>', 'exec'), namespace)
    return namespace['check']


def envelope(raw=None, saved='', raw_finish='stop', saved_finish='stop'):
    return {'response': {'choices': [{'message': {'content': raw}, 'finish_reason': raw_finish}]},
            'text': saved, 'finish_reason': saved_finish}


def top_functions(path, names, namespace=None):
    functions = [copy.deepcopy(node) for node in ast.parse(path.read_text()).body
                 if isinstance(node, ast.FunctionDef) and node.name in names]
    if {node.name for node in functions} != set(names):
        raise AssertionError('Missing native function')
    for node in functions:
        node.decorator_list = []
    namespace = dict(namespace or {})
    exec(compile(ast.fix_missing_locations(ast.Module(body=functions, type_ignores=[])), str(path), 'exec'), namespace)
    return namespace


class NullEquivalence(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original_tree = ast.parse(ORIGINAL.read_text())
        cls.derived_tree = ast.parse(DERIVED.read_text())
        cls.old_guard = staticmethod(compiled_guard(cls.original_tree))
        cls.new_guard = staticmethod(compiled_guard(cls.derived_tree))

    def test_frozen_hashes(self):
        self.assertEqual(hashlib.sha256(ORIGINAL.read_bytes()).hexdigest(), RECEIPT['original_scorer_sha256'])
        self.assertEqual(hashlib.sha256(DERIVED.read_bytes()).hexdigest(), RECEIPT['derived_scorer_sha256'])
        self.assertEqual(hashlib.sha256((HERE / 'native_guard_only.diff').read_bytes()).hexdigest(), RECEIPT['diff_sha256'])

    def test_only_one_guard_changed_in_entire_native_module(self):
        derived = copy.deepcopy(self.derived_tree)
        original_guard = guard_node(self.original_tree)
        derived_guard = guard_node(derived)
        derived_guard.test = copy.deepcopy(original_guard.test)
        self.assertEqual(ast.dump(derived, include_attributes=False), ast.dump(self.original_tree, include_attributes=False))

    def test_explicit_null_normalized_empty_is_only_new_equivalence(self):
        value = envelope()
        with self.assertRaises(ValueError):
            self.old_guard(value)
        self.assertTrue(self.new_guard(value))
        value['response']['choices'][0]['finish_reason'] = 'length'
        value['finish_reason'] = 'length'
        self.assertTrue(self.new_guard(value))

    def test_equal_nonempty_and_empty_answers_remain_accepted(self):
        for text in ['', '{"scores":{}}', 'word', '  ', '0']:
            self.assertTrue(self.new_guard(envelope(text, text)))
            self.assertTrue(self.old_guard(envelope(text, text)))

    def test_missing_raw_content_is_not_explicit_null(self):
        value = envelope()
        del value['response']['choices'][0]['message']['content']
        with self.assertRaises(ValueError):
            self.new_guard(value)

    def test_nonempty_or_whitespace_saved_against_null_rejected(self):
        for text in [' ', '\n', '0', 'null', '{"scores":{}}']:
            with self.subTest(text=text), self.assertRaises(ValueError):
                self.new_guard(envelope(None, text))

    def test_all_other_divergent_scalar_fields_rejected(self):
        values = [None, '', ' ', 'answer', '0', 0, False, [], {}]
        for raw in values:
            for saved in values:
                if raw == saved or raw is None and saved == '':
                    continue
                with self.subTest(raw=raw, saved=saved), self.assertRaises(ValueError):
                    self.new_guard(envelope(raw, saved))

    def test_all_finish_mismatches_rejected_including_null_equivalence(self):
        for a in ['stop', 'length', None]:
            for b in ['stop', 'length', None]:
                if a == b:
                    continue
                for raw, saved in [(None, ''), ('{}', '{}')]:
                    with self.subTest(raw=raw, saved=saved, a=a, b=b), self.assertRaises(ValueError):
                        self.new_guard(envelope(raw, saved, a, b))

    def test_null_and_empty_stay_invalid_predictions(self):
        parser_source = ROOT / 'scripts/prepare_local_deepfri_proposals.py'
        parse = top_functions(parser_source, ['parse_sparse_confidence'], {'json': json, 'math': math})['parse_sparse_confidence']
        for text in [None, '']:
            for finish in ['stop', 'length']:
                with self.subTest(text=text, finish=finish), self.assertRaises(ValueError):
                    parse(text, ['GO:0000001'], finish)
        with self.assertRaises(ValueError):
            parse('{"scores":{}}', ['GO:0000001'], 'length')
        self.assertEqual(parse('{"scores":{}}', ['GO:0000001'], 'stop'), {})

    def test_full_denominator_and_primary_null_gate_retained(self):
        import torch
        calls = []
        def stub_metrics(scores, targets, functions):
            calls.append((tuple(scores.shape), tuple(targets.shape)))
            return {'auprc@micro': 0.123, 'f1_max': 0.234, 'TIE_GROUPED_AP_DIAGNOSTIC': {'sklearn_micro_average_precision': 0.345}}
        matrix = top_functions(DERIVED, ['matrix_metrics'], {'metrics_for': stub_metrics})['matrix_metrics']
        result, diagnostics = matrix([{'A': 0.8}, None, {}], [[0], [1], [0]], ['A', 'B'], {})
        self.assertIsNone(result['auprc@micro'])
        self.assertIsNone(result['f1_max'])
        self.assertEqual(diagnostics['planned_vectors'], 3)
        self.assertEqual(diagnostics['valid_vectors'], 2)
        self.assertEqual(result['PARSED_ONLY_DIAGNOSTIC']['valid_cases'], 2)
        self.assertEqual(result['PARSED_ONLY_DIAGNOSTIC']['planned_cases'], 3)
        self.assertEqual(result['OFFLINE_ALL_ZERO_REFERENCE']['case_count'], 3)
        self.assertEqual(calls, [((2, 2), (2, 2)), ((3, 2), (3, 2))])

    def test_native_metric_formulas_run_only_on_artificial_tensor(self):
        import torch
        source = ROOT / 'sources/deepfri_contract_audit_2026-10-15/torchdrug__torchdrug__metrics__metric.py'
        functions = top_functions(source, ['area_under_prc', 'f1_max'], {'torch': torch})
        scores = torch.tensor([[0.9, 0.1], [0.2, 0.8]], dtype=torch.float32)
        targets = torch.tensor([[1, 0], [0, 1]], dtype=torch.int64)
        self.assertAlmostEqual(float(functions['area_under_prc'](scores.flatten(), targets.flatten())), 1.0)
        self.assertAlmostEqual(float(functions['f1_max'](scores, targets)), 1.0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
