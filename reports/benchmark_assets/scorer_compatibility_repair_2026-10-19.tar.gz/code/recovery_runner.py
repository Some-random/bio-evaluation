"""Versioned offline recovery for the exact DeepFRI null/empty provenance bug.

Preparation reads and seals existing records. Execution is separate and requires
the caller's pinned prepared manifest. No inference client, generation queue,
original run, failed attempt, or original scorer is modified.
"""
from __future__ import annotations

import argparse
from collections import Counter
import copy
from datetime import datetime
import fcntl
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
REPOSITORY = HERE.parents[3]
REVISION = REPOSITORY / '.local/evaluation_revision_2026-10-18'
VERSION = 'NULL_EQUIVALENCE_SCORING_RECOVERY_V1'
ORIGINAL_SCORER_SHA256 = 'b943895878c02edb98b65d537f778c899d1ba4386b7765bebcc76d75eb2fb0a7'
DERIVED_SCORER_SHA256 = '8e9f16fcac02afbfee88fcf271a62bd974d559c803aa78dabf7dbac8999ebb91'
SCORER_NAME = 'scripts/score_local_deepfri_confidence.py'
KNOWN_ERROR = 'ValueError: Saved final/finish fields conflict'
WATCH_PLAN_SHA256 = 'ceb34bc44187152171200e7561ee3d039b177d3763d2a63d406e8b02ba3cc871'
DERIVED_NAME = 'score_local_deepfri_confidence_null_equivalence_v1.py'
TASKS = {'P12', 'P13', 'P14', 'P15'}


class RecoveryError(RuntimeError):
    pass


class Pending(RecoveryError):
    pass


def now():
    return datetime.now(ZoneInfo('America/Los_Angeles')).isoformat()


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')


def checked(path, expected):
    path = Path(path)
    if sha(path) != expected:
        raise RecoveryError('Pinned file changed: ' + str(path))
    return read(path)


def relative_file(root, name):
    path = Path(name)
    if path.is_absolute() or '..' in path.parts:
        raise RecoveryError('Expected a contained relative path: ' + name)
    return Path(root) / path


def inventory(folder):
    """All original attempt artifacts, excluding advisory OS lock files."""
    folder = Path(folder)
    return {str(p.relative_to(folder)): sha(p) for p in sorted(folder.rglob('*'))
            if p.is_file() and not p.name.endswith('.lock')}


def case_name(case):
    return digest([case['task'], case['variant'], case['case_id']]) + '.json'


def public_metric_values(value, path='metrics'):
    """JSON-only representation of undefined native metrics, never recompute."""
    if isinstance(value, float) and not math.isfinite(value):
        representation = 'NaN' if math.isnan(value) else 'Infinity' if value > 0 else '-Infinity'
        return None, [{'path': path, 'native_representation': representation}]
    if isinstance(value, dict):
        output, records = {}, []
        for key, child in value.items():
            output[key], found = public_metric_values(child, path + '.' + str(key))
            records.extend(found)
        return output, records
    if isinstance(value, list):
        output, records = [], []
        for index, child in enumerate(value):
            normalized, found = public_metric_values(child, path + '[' + str(index) + ']')
            output.append(normalized)
            records.extend(found)
        return output, records
    return value, []


def expected_payload(case, configuration, budget):
    if set(case) != {'task', 'case_id', 'variant', 'split', 'messages'}:
        raise RecoveryError('Unexpected model input fields')
    if case['task'] not in configuration['approved_task_ids'] or case['variant'] != configuration['variant']:
        raise RecoveryError('Model input outside original task/variant')
    if (len(case['messages']) != 1 or set(case['messages'][0]) != {'role', 'content'}
            or case['messages'][0]['role'] != 'user' or not isinstance(case['messages'][0]['content'], str)):
        raise RecoveryError('Model input modality changed')
    generation = copy.deepcopy(configuration['generation'])
    if generation.get('n') != 1 or configuration.get('tool_access', []) or 'tools' in configuration:
        raise RecoveryError('Only original single completions without tools are supported')
    if budget not in (4096, 16384):
        raise RecoveryError('Unexpected per-case generation budget')
    generation['max_tokens'] = budget
    return {'model': configuration['model'], 'messages': case['messages'], **generation}


def classify_envelope(record):
    """Inspect provenance only. Does not parse biological predictions or labels."""
    if record.get('status') != 'completed' or record.get('http_status') != 200:
        raise RecoveryError('Recovery requires original completed API responses')
    response = record.get('response', {})
    choices = response.get('choices', [])
    if len(choices) != 1 or not isinstance(choices[0].get('message'), dict):
        raise RecoveryError('Expected one original assistant message')
    choice = choices[0]
    message = choice['message']
    if message.get('role') != 'assistant' or message.get('tool_calls') or message.get('function_call'):
        raise RecoveryError('Unexpected assistant role or tool output')
    if choice.get('finish_reason') != record.get('finish_reason'):
        raise RecoveryError('Divergent finish fields are outside this repair')
    raw, saved = message.get('content'), record.get('text')
    if raw == saved:
        return 'equal'
    if 'content' in message and raw is None and saved == '':
        return 'explicit_null_to_empty'
    raise RecoveryError('Divergent content fields are outside this repair')


def validate_failed_attempt(root, spec, spec_file=None):
    """Label-blind exact-scope validation of one terminal original attempt."""
    root = Path(root).resolve()
    task = spec.get('task_id')
    if task not in TASKS:
        raise RecoveryError('Only P12-P15 are authorized for this repair')
    if Path(spec['project_root']).resolve() != root:
        raise RecoveryError('Original project root changed')
    folder = root / 'results/runs' / spec['output_run_id']
    if not folder.name.endswith('_mixed_4k16k_scoring_v1'):
        raise RecoveryError('Expected the original mixed-budget attempt ID')
    completion_path = folder / 'completion.json'
    if not completion_path.is_file():
        raise Pending('Original scoring attempt is not terminal: ' + task)
    before = inventory(folder)
    done = read(completion_path)
    if done.get('scoring_exit_code') == 0:
        raise RecoveryError('Original successful score must not be recomputed')
    if done.get('scoring_exit_code') != 1 or done.get('generation_exit_code') != 0:
        raise RecoveryError('Original attempt did not end with the known scoring failure')
    log = (folder / 'native_scorer.log').read_text()
    if (not log.rstrip().endswith(KNOWN_ERROR) or log.count(KNOWN_ERROR) != 1
            or 'line 184, in score' not in log):
        raise RecoveryError('Original failure is not the exact reviewed null guard')
    if (folder / 'scores.json').exists() or (folder / 'per_case_scores.json').exists():
        raise RecoveryError('Original failed attempt unexpectedly contains scores')
    attempt_spec = read(folder / 'mixed_scoring_spec.json')
    if attempt_spec != spec or done.get('spec_sha256') != digest(spec):
        raise RecoveryError('Original completion/spec identity mismatch')
    manifest = read(folder / 'run_manifest.json')
    cfg = manifest['configuration']
    if done.get('run_manifest_sha256') != sha(folder / 'run_manifest.json'):
        raise RecoveryError('Original manifest changed after terminal completion')
    config_path = root / 'configs' / (folder.name + '.json')
    if (checked(config_path, manifest['configuration_sha256']) != cfg
            or done.get('configuration_sha256') != manifest['configuration_sha256']):
        raise RecoveryError('Original failed configuration changed')
    invocation = read(folder / 'native_scorer_invocation.json')
    if (spec['scorer_sha256'] != ORIGINAL_SCORER_SHA256
            or invocation.get('native_scorer_sha256') != ORIGINAL_SCORER_SHA256
            or sha(root / SCORER_NAME) != ORIGINAL_SCORER_SHA256
            or invocation.get('spec_sha256') != digest(spec)
            or invocation.get('native_calls_planned') != 1):
        raise RecoveryError('Original scorer/attempt differs from reviewed source')
    for name, value in cfg['frozen_files_sha256'].items():
        if sha(root / name) != value:
            raise RecoveryError('An original frozen dependency changed: ' + name)
    full_cfg = checked(root / spec['full_config_file'], spec['full_config_sha256'])
    if full_cfg['approved_task_ids'] != [task] or cfg['approved_task_ids'] != [task]:
        raise RecoveryError('Original full task identity changed')
    cases = [json.loads(line) for line in (root / full_cfg['input_file']).read_text().splitlines() if line]
    review = read(root / full_cfg['review_file'])
    if ([case['case_id'] for case in cases] != review['approved_case_ids']
            or len({case['case_id'] for case in cases}) != len(cases)
            or digest(cases) != manifest['case_contract_sha256']
            or len(cases) != manifest['planned_cases']
            or len(cases) != full_cfg['planned']):
        raise RecoveryError('Original full ordered case contract changed')
    union = done['full_test_id_union_validation']
    if (union.get('complete') is not True or union.get('union_matches_full_test_ids') is not True
            or union.get('expected_test_case_count') != len(cases)
            or union.get('unique_observed_case_count') != len(cases)
            or any(union.get(k) != 0 for k in ['missing_case_count', 'extra_case_count', 'duplicate_case_count'])):
        raise RecoveryError('Original exact full union was not validated')
    budget_pin = cfg['mixed_budget_scoring']['per_case_budget_map']
    budget_record = checked(budget_pin['path'], budget_pin['sha256'])
    budgets = budget_record['budgets_by_raw_filename']
    mixed_lock = read(folder / 'mixed_budget_output_lock.json')
    native_lock = read(folder / 'scoring_output_lock.json')
    if (invocation.get('output_lock_sha256') != sha(folder / 'mixed_budget_output_lock.json')
            or mixed_lock.get('spec_sha256') != digest(spec)
            or mixed_lock.get('per_case_budget_map_sha256') != budget_pin['sha256']
            or mixed_lock.get('native_denominator') != len(cases)
            or mixed_lock.get('all_original_invalid_and_missing_slots_retained') is not True
            or native_lock.get('contract_sha256') != digest(native_lock['files_sha256'])):
        raise RecoveryError('Original pre-label output lock changed')
    names = {case_name(case) for case in cases}
    if set(budgets) != names:
        raise RecoveryError('Per-case budgets differ from exact full union')
    counts = Counter()
    raw_files = {}
    for kind in ('requests', 'responses'):
        if {p.name for p in (folder / kind).glob('*.json')} != names:
            raise RecoveryError('Original raw union has missing/extra files')
    for case in cases:
        name = case_name(case)
        records = {}
        for kind in ('requests', 'responses'):
            key = kind + '/' + name
            path = folder / key
            value = sha(path)
            if value != mixed_lock['files_sha256'].get(key) or value != native_lock['files_sha256'].get(key):
                raise RecoveryError('Original locked raw bytes changed')
            raw_files[key] = value
            records[kind] = read(path)
        req, resp = records['requests'], records['responses']
        payload = expected_payload(case, full_cfg, budgets[name])
        if req.get('payload') != payload or req.get('request_sha256') != digest(payload):
            raise RecoveryError('Archived request differs from original prompt/budget')
        for key in ('task', 'case_id', 'variant', 'split'):
            if req.get(key) != case[key] or resp.get(key) != case[key]:
                raise RecoveryError('Raw case provenance mismatch')
        if (resp.get('request_sha256') != req['request_sha256']
                or resp.get('model') != full_cfg['model']
                or resp.get('model_revision') != full_cfg['model_revision']
                or resp.get('response', {}).get('model') != full_cfg['model']):
            raise RecoveryError('Raw model/request provenance mismatch')
        counts[classify_envelope(resp)] += 1
    if not counts['explicit_null_to_empty']:
        raise RecoveryError('Known null normalization defect was not present')
    if inventory(folder) != before:
        raise RecoveryError('Original attempt changed while being audited')
    return {'task_id': task, 'root': root, 'folder': folder, 'spec': spec,
            'manifest': manifest, 'configuration': cfg, 'full_configuration': full_cfg,
            'cases': cases, 'budgets': budget_record, 'raw_files_sha256': raw_files,
            'original_inventory_sha256': before, 'normalization_counts': dict(counts),
            'original_config_path': config_path, 'spec_file': spec_file}


def production_source(task):
    if task not in TASKS:
        raise RecoveryError('Unsupported task')
    watch = checked(REVISION / 'scoring/watch_plan_v1.json', WATCH_PLAN_SHA256)
    path = REVISION / 'scoring' / (task.lower() + '_mixed_scoring_v1.json')
    binding = next((item for item in watch['spec_files'] if Path(item['path']).resolve() == path.resolve()), None)
    if binding is None:
        raise RecoveryError('Task absent from frozen original watcher')
    spec = checked(path, binding['sha256'])
    return validate_failed_attempt(spec['project_root'], spec, path)


def copy_exact(source, target, expected):
    source, target = Path(source), Path(target)
    if sha(source) != expected:
        raise RecoveryError('Source changed before copy: ' + str(source))
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open('rb') as stream, target.open('xb') as out:
        shutil.copyfileobj(stream, out)
    shutil.copymode(source, target)
    if sha(target) != expected or sha(source) != expected:
        raise RecoveryError('Copy differs from sealed source')


def prepare_validated(source, destination, derived_path=HERE / DERIVED_NAME, runner_path=Path(__file__)):
    """Only a new directory may be prepared; original files remain immutable."""
    destination = Path(destination).resolve()
    if destination.exists():
        raise RecoveryError('Recovery destination exists; no overwrite or retry')
    if sha(derived_path) != DERIVED_SCORER_SHA256:
        raise RecoveryError('Reviewed derived scorer changed')
    source_root, original = source['root'], source['configuration']
    if inventory(source['folder']) != source['original_inventory_sha256']:
        raise RecoveryError('Original failed attempt changed before preparation')
    destination.mkdir(parents=True, exist_ok=False)
    project = destination / 'project'
    run_id = source['folder'].name.removesuffix('_mixed_4k16k_scoring_v1') + '_mixed_4k16k_scoring_null_equivalence_v1'
    folder = project / 'results/runs' / run_id
    folder.mkdir(parents=True)
    cfg = copy.deepcopy(original)
    cfg['run_id'] = run_id
    cfg['runner'] = 'recovery_driver.py'
    cfg['scorer_sha256'] = DERIVED_SCORER_SHA256
    frozen = {}
    copies = {}
    for name, value in original['frozen_files_sha256'].items():
        if name == original['runner']:
            target_name = 'frozen_original_adapter/mixed_budget_scoring.py'
        else:
            relative_file(project, name)
            target_name = name
        src = source_root / name
        expected = value
        if name == SCORER_NAME:
            src, expected = Path(derived_path), DERIVED_SCORER_SHA256
        copy_exact(src, relative_file(project, target_name), expected)
        frozen[target_name] = expected
        copies[target_name] = {'source_path': str(src.resolve()), 'sha256': expected}
    dependency = 'scripts/prepare_deepfri_sequence_contract.py'
    if dependency not in frozen:
        expected = sha(source_root / dependency)
        copy_exact(source_root / dependency, project / dependency, expected)
        frozen[dependency] = expected
        copies[dependency] = {'source_path': str((source_root / dependency).resolve()), 'sha256': expected}
    copy_exact(runner_path, project / cfg['runner'], sha(runner_path))
    frozen[cfg['runner']] = sha(runner_path)
    cfg['frozen_files_sha256'] = frozen
    budget_path = folder / 'per_case_budget_map.json'
    write_new(budget_path, source['budgets'])
    cfg['mixed_budget_scoring']['per_case_budget_map'] = {'path': str(budget_path), 'sha256': sha(budget_path)}
    cfg['null_equivalence_recovery'] = {
        'version': VERSION, 'original_failed_run_id': source['folder'].name,
        'original_scorer_sha256': ORIGINAL_SCORER_SHA256,
        'derived_scorer_sha256': DERIVED_SCORER_SHA256,
        'normalization_counts': source['normalization_counts'],
        'native_parser_and_metric_formulas_unchanged': True,
        'scorer_provenance_guard_changed': True, 'raw_outputs_modified': False,
        'generation_or_selective_reruns': False}
    config_path = project / 'configs' / (run_id + '.json')
    write_new(config_path, cfg)
    manifest = copy.deepcopy(source['manifest'])
    manifest.update(configuration=cfg, configuration_sha256=sha(config_path),
                    runner_sha256=sha(runner_path), runner_role='offline_null_equivalence_recovery')
    write_new(folder / 'run_manifest.json', manifest)
    for name, expected in source['raw_files_sha256'].items():
        copy_exact(source['folder'] / name, folder / name, expected)
    provenance = {'version': VERSION, 'prepared_at_pacific': now(), 'task_id': source['task_id'],
        'project_root': str(project), 'output_directory': str(folder), 'output_run_id': run_id,
        'config_path': str(config_path), 'config_sha256': sha(config_path),
        'manifest_sha256': sha(folder / 'run_manifest.json'),
        'original_project_root': str(source_root), 'original_failed_directory': str(source['folder']),
        'original_configuration_path': str(source['original_config_path']),
        'original_configuration_sha256': sha(source['original_config_path']),
        'original_full_configuration': source['full_configuration'],
        'original_spec': source['spec'],
        'original_inventory_sha256': source['original_inventory_sha256'],
        'normalization_counts': source['normalization_counts'],
        'raw_files_sha256': source['raw_files_sha256'], 'copied_dependencies': copies,
        'per_case_budget_map_sha256': sha(budget_path),
        'runner_source_path': str(Path(runner_path).resolve()), 'runner_sha256': sha(runner_path),
        'original_scorer_sha256': ORIGINAL_SCORER_SHA256, 'derived_scorer_sha256': DERIVED_SCORER_SHA256,
        'planned_cases': len(source['cases']), 'references_opened_for_scoring': False,
        'no_model_generation': True, 'native_labels_denominator_formulas_unchanged': True,
        'scoring_attempt_started': False}
    if inventory(source['folder']) != source['original_inventory_sha256']:
        raise RecoveryError('Original attempt changed during preparation; refuse scoring')
    write_new(destination / 'prepared_manifest.json', provenance)
    return destination / 'prepared_manifest.json'


def validate_prepared(path, expected_sha):
    prepared = checked(path, expected_sha)
    if prepared.get('version') != VERSION or not prepared.get('no_model_generation'):
        raise RecoveryError('Unexpected prepared recovery contract')
    if prepared['runner_sha256'] != sha(prepared['runner_source_path']):
        raise RecoveryError('Prepared recovery driver changed')
    project, folder = Path(prepared['project_root']), Path(prepared['output_directory'])
    if folder != project / 'results/runs' / prepared['output_run_id']:
        raise RecoveryError('Prepared output directory changed')
    cfg = checked(prepared['config_path'], prepared['config_sha256'])
    manifest = checked(folder / 'run_manifest.json', prepared['manifest_sha256'])
    if manifest['configuration'] != cfg or manifest['runner_sha256'] != prepared['runner_sha256']:
        raise RecoveryError('Prepared manifest/config mismatch')
    if sha(project / SCORER_NAME) != DERIVED_SCORER_SHA256:
        raise RecoveryError('Derived scorer changed after preparation')
    for name, expected in cfg['frozen_files_sha256'].items():
        if sha(relative_file(project, name)) != expected:
            raise RecoveryError('Prepared frozen dependency changed: ' + name)
    for kind in ('requests', 'responses'):
        expected_names = {Path(name).name for name in prepared['raw_files_sha256'] if name.startswith(kind + '/')}
        if {p.name for p in (folder / kind).glob('*.json')} != expected_names:
            raise RecoveryError('Prepared raw union changed')
    for name, expected in prepared['raw_files_sha256'].items():
        if sha(folder / name) != expected:
            raise RecoveryError('Prepared raw bytes changed')
    if inventory(prepared['original_failed_directory']) != prepared['original_inventory_sha256']:
        raise RecoveryError('Original failed attempt was changed')
    checked(prepared['original_configuration_path'], prepared['original_configuration_sha256'])
    checked(folder / 'per_case_budget_map.json', prepared['per_case_budget_map_sha256'])
    return prepared


def native_score_prepared(path, expected_sha):
    """Run only inside the new isolated project in the native CPU environment."""
    prepared = validate_prepared(path, expected_sha)
    project, folder = Path(prepared['project_root']), Path(prepared['output_directory'])
    invocation_path = folder / 'recovery_invocation.json'
    if not invocation_path.is_file():
        raise RecoveryError('Native child requires its recorded parent invocation')
    invocation = read(invocation_path)
    if invocation.get('prepared_manifest_sha256') != expected_sha:
        raise RecoveryError('Native child invocation belongs to another manifest')
    if (folder / 'completion.json').exists() or (folder / 'scores.json').exists():
        raise RecoveryError('Native child cannot repeat an existing score or completion')
    write_new(folder / 'native_execution_started.json', {'started_at_pacific': now(),
        'prepared_manifest_sha256': expected_sha, 'native_scoring_attempts': 1})
    cfg = read(prepared['config_path'])
    budget = read(folder / 'per_case_budget_map.json')['budgets_by_raw_filename']
    original = prepared['original_full_configuration']
    sys.path.insert(0, str(project / 'scripts'))
    spec = importlib.util.spec_from_file_location('isolated_null_equivalence_scorer', project / SCORER_NAME)
    native = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    def payload(case, settings):
        return expected_payload(case, original, budget[case_name(case)])
    native.expected_payload = payload
    result = native.score(folder, root=project, config_path=prepared['config_path'])
    # The original native writer permits NaN (notably a tied all-zero Fmax
    # diagnostic). Preserve its bytes. Only the public JSON representation
    # maps nonfinite values to null, with exact paths/representations recorded.
    copy_exact(folder / 'scores.json', folder / 'derived_scores_before_annotation.json', sha(folder / 'scores.json'))
    if (result.get('planned') != prepared['planned_cases'] or result.get('completed') != prepared['planned_cases']
            or result.get('scorer_sha256') != DERIVED_SCORER_SHA256):
        raise RecoveryError('Derived native summary lost scope/provenance')
    if result.get('parsed') != result['planned'] and any(result['metrics'].get(k) is not None for k in ('auprc@micro', 'f1_max')):
        raise RecoveryError('Native full-primary invalid-output gate changed')
    result.update(protocol_variant=original['variant'] + '__MIXED_BUDGET_4K16K_CONTINUATION__' + VERSION,
        original_protocol_variant=original['variant'], generation_budget_condition='MIXED_BUDGET_4K16K_CONTINUATION',
        generation={'max_tokens': None, 'output_budget_counts': dict(Counter(str(v) for v in budget.values()))},
        full_test_id_union_validation=cfg['mixed_budget_scoring']['full_test_id_union_validation'],
        scorer_recovery=cfg['null_equivalence_recovery'],
        original_case_denominator_unchanged=True, prior_outputs_rerun=False,
        native_parser_and_metric_formulas_unchanged=True, scorer_provenance_guard_changed=True)
    result['metrics'], nonfinite = public_metric_values(result['metrics'])
    result['nonfinite_native_metric_paths'] = [item['path'] for item in nonfinite]
    result['nonfinite_native_metric_representations'] = nonfinite
    result['native_unmodified_scores_artifact'] = {'path': 'derived_scores_before_annotation.json',
        'sha256': sha(folder / 'derived_scores_before_annotation.json')}
    result['native_nonfinite_policy'] = 'Exact native score bytes retained in the pinned artifact; nonfinite values are null only in public JSON, with paths and original representations recorded. Finite values and metric formulas are unchanged.'
    result['comparison_to_paper'] += (' Mixed historical4096/prospective16384 budgets; the separately versioned scorer '
        'accepts only explicit raw null versus normalized empty final text for provenance. Missing finals remain invalid. '
        'Original failed scoring attempt and all raw bytes are preserved; no generation was repeated.')
    temporary = folder / 'scores.annotated.tmp'
    with temporary.open('x') as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')
    temporary.replace(folder / 'scores.json')
    validate_prepared(path, expected_sha)
    return {'run_id': prepared['output_run_id'], 'planned': result['planned'], 'parsed': result['parsed'],
            'nonfinite_native_metric_paths': result['nonfinite_native_metric_paths'], 'native_scores_preserved': True}


def execute_prepared(path, expected_sha, run_command=subprocess.run, enforce_cpu_job=True):
    prepared = validate_prepared(path, expected_sha)
    if enforce_cpu_job and os.environ.get('SLURM_JOB_ID') != '237730':
        raise RecoveryError('Execute only in the retained authorized CPU allocation237730')
    folder = Path(prepared['output_directory'])
    with (folder / 'recovery_worker.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if (folder / 'recovery_invocation.json').exists() or (folder / 'completion.json').exists():
            raise RecoveryError('Recovery already attempted; no overwrite or automatic retry')
        python = prepared['original_spec']['python']
        command = [python, '-B', prepared['runner_source_path'], '--native-prepared', str(Path(path).resolve()), '--expected-sha256', expected_sha]
        write_new(folder / 'recovery_invocation.json', {'started_at_pacific': now(), 'argv': command,
            'prepared_manifest_sha256': expected_sha, 'runner_sha256': prepared['runner_sha256'],
            'original_scorer_sha256': ORIGINAL_SCORER_SHA256, 'derived_scorer_sha256': DERIVED_SCORER_SHA256,
            'native_scoring_attempts': 1, 'generation_attempts': 0})
        environment = os.environ.copy()
        for key in ('PYTHONPATH', 'PYTHONHOME', 'VIRTUAL_ENV'):
            environment.pop(key, None)
        environment.update(PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
        with (folder / 'native_scorer.log').open('x') as output:
            result = run_command(command, cwd=prepared['project_root'], env=environment, stdout=output, stderr=subprocess.STDOUT)
        completion = {'finished_at_pacific': now(), 'scoring_exit_code': result.returncode,
            'generation_exit_code': 0, 'generation_attempts': 0, 'version': VERSION,
            'prepared_manifest_sha256': expected_sha, 'planned': prepared['planned_cases'],
            'original_case_denominator_unchanged': True, 'original_outputs_modified': False,
            'automatic_retry': False, 'normalization_counts': prepared['normalization_counts']}
        validate_prepared(path, expected_sha)
        if result.returncode == 0:
            scores = read(folder / 'scores.json')
            if scores.get('planned') != prepared['planned_cases'] or scores.get('completed') != prepared['planned_cases']:
                raise RecoveryError('Recovery native score changed denominator')
            completion['scores_sha256'] = sha(folder / 'scores.json')
            completion['protocol_variant'] = scores['protocol_variant']
            completion['full_test_id_union_validation'] = scores['full_test_id_union_validation']
        write_new(folder / 'completion.json', completion)
        if result.returncode:
            raise RecoveryError('Recovery native scorer failed; attempt preserved, no automatic retry')
        return completion


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--prepare', choices=sorted(TASKS))
    mode.add_argument('--execute-prepared', type=Path)
    mode.add_argument('--native-prepared', type=Path)
    parser.add_argument('--expected-sha256')
    args = parser.parse_args()
    if args.prepare:
        source = production_source(args.prepare)
        path = prepare_validated(source, HERE / 'prepared' / args.prepare.lower())
        result = {'prepared_manifest': str(path), 'prepared_manifest_sha256': sha(path), 'scoring_executed': False}
    else:
        if not args.expected_sha256:
            parser.error('Execution requires the externally reviewed prepared-manifest SHA-256')
        if args.native_prepared:
            result = native_score_prepared(args.native_prepared, args.expected_sha256)
        else:
            result = execute_prepared(args.execute_prepared, args.expected_sha256)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))


if __name__ == '__main__':
    main()
