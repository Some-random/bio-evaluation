"""Export completed offline repairs and portable provenance; never run scoring."""
import hashlib
import io
import json
from pathlib import Path
import tarfile
from datetime import datetime
from zoneinfo import ZoneInfo

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
NAMES = {'P12': 'Enzyme annotation', 'P13': 'Biological-process annotation',
         'P14': 'Molecular-function annotation', 'P15': 'Cellular-component annotation'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def export():
    snapshots, corrections, members = [], [], {}
    for task in NAMES:
        source = HERE / 'prepared_v2' / task.lower() / 'prepared_manifest.json'
        if not source.exists():
            continue
        prepared = read(source)
        folder = Path(prepared['output_directory'])
        if not (folder / 'completion.json').is_file():
            continue
        done, score = read(folder / 'completion.json'), read(folder / 'scores.json')
        if done.get('scoring_exit_code') != 0 or done['scores_sha256'] != sha(folder / 'scores.json'):
            raise ValueError('Only verified completed repair scores can be exported')
        native = score['native_unmodified_scores_artifact']
        if sha(folder / native['path']) != native['sha256']:
            raise ValueError('Exact native score artifact changed')
        run_id = score['run_id']
        metadata = ROOT / 'results/scoring_corrections' / run_id
        metadata.mkdir(parents=True, exist_ok=True)
        for name in ('scores.json', 'completion.json', 'run_manifest.json'):
            target = metadata / name
            payload = (folder / name).read_bytes()
            if target.exists() and target.read_bytes() != payload:
                raise ValueError('Published correction metadata changed: ' + str(target))
            target.write_bytes(payload)
        correction = {'task_id': task, 'original_failed_run_id': prepared['original_spec']['output_run_id'],
            'new_run_id': run_id, 'protocol_variant': score['protocol_variant'],
            'scores_file': str((metadata / 'scores.json').relative_to(ROOT)),
            'scores_sha256': done['scores_sha256'], 'completed_at_pacific': done['finished_at_pacific'],
            'correction': 'null-versus-empty provenance compatibility; original failed attempt retained',
            'no_new_model_generation': True, 'original_raw_outputs_unchanged': True}
        (metadata / 'scoring_correction.json').write_text(json.dumps(correction, indent=2) + '\n')
        corrections.append(correction)
        snapshots.append({'task_id': task, 'task_name': NAMES[task], 'run_id': run_id,
            'planned': score['planned'], 'completed': score['completed'], 'parsed': score['parsed'],
            'invalid_outputs': score['invalid_outputs'], 'finish_reasons': score['finish_reasons'],
            'parse_error_counts': score['parse_error_counts'], 'metrics': score['metrics'],
            'output_budget_counts': score['generation']['output_budget_counts'],
            'normalization_counts': prepared['normalization_counts'],
            'nonfinite_native_metric_paths': score['nonfinite_native_metric_paths'],
            'native_score_artifact_sha256': native['sha256']})
        for name in ('scores.json', 'completion.json', 'run_manifest.json', 'per_case_scores.json',
                     'derived_scores_before_annotation.json', 'scoring_output_lock.json',
                     'recovery_invocation.json', 'native_execution_started.json'):
            members[task + '/' + name] = (folder / name).read_bytes()
        members[task + '/prepared_manifest.json'] = source.read_bytes()
        old = Path(prepared['original_failed_directory'])
        for name in ('completion.json', 'native_scorer.log', 'native_scorer_invocation.json'):
            if sha(old / name) != prepared['original_inventory_sha256'][name]:
                raise ValueError('Original failed attempt was changed')
            members[task + '/original_failed_attempt/' + name] = (old / name).read_bytes()
    if not snapshots:
        raise ValueError('No completed repairs to export')
    document = {'version': 'SCORER_COMPATIBILITY_REPAIR_2026_10_19',
        'updated_at_pacific': datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
        'repair': 'Only explicit API content=null versus normalized saved text="" is equivalent for provenance.',
        'original_scorer_sha256': 'b943895878c02edb98b65d537f778c899d1ba4386b7765bebcc76d75eb2fb0a7',
        'derived_scorer_sha256': '8e9f16fcac02afbfee88fcf271a62bd974d559c803aa78dabf7dbac8999ebb91',
        'new_model_generations': 0, 'invalid_predictions_repaired_or_dropped': 0,
        'native_metric_formulas_and_original_denominators_unchanged': True,
        'completed_repairs': snapshots, 'corrections': corrections,
        'pending_tasks': [task for task in NAMES if task not in {s['task_id'] for s in snapshots}]}
    reports = ROOT / 'reports'
    json_path = reports / 'SCORER_COMPATIBILITY_REPAIR_2026-10-19.json'
    json_path.write_text(json.dumps(document, indent=2, allow_nan=False) + '\n')
    lines = ['# Scoring compatibility repair', '',
        f"Updated {document['updated_at_pacific']} (America/Los_Angeles).", '',
        'The original scorer stopped when an API response contained `content: null` but the saved text field contained `""`. '
        'Those fields both represent an absent final answer. The repaired provenance check accepts that exact equivalence; '
        'the answer still counts as invalid. No model response was regenerated, filled in, or removed.', '',
        '| Dataset task | Saved cases | Valid final vectors | Invalid vectors | Full AP / Fmax |',
        '| --- | ---: | ---: | ---: | --- |']
    for row in snapshots:
        primary = row['metrics']
        display = 'Undefined' if primary['auprc@micro'] is None or primary['f1_max'] is None else f"{primary['auprc@micro']:.4f} / {primary['f1_max']:.4f}"
        lines.append(f"| {row['task_name']} ({row['task_id']}; DeepFRI-derived released test) | {row['completed']:,} / {row['planned']:,} | {row['parsed']:,} | {row['invalid_outputs']:,} | {display} |")
    lines += ['', 'Full-set AP/Fmax remain undefined because the frozen protocol requires a valid confidence vector for every case. '
        'The JSON record retains separately labeled parsed-only diagnostics, which are not full-test benchmark scores.', '',
        'The original failed attempts, complete case sets, original 4K/16K output budgets, native metric formulas, '
        'and saved reasoning/final responses remain unchanged. New score IDs end in `scoring_null_equivalence_v1`. '
        'This remains a zero-shot sequence/confidence adaptation, not a matched specialist-model paper replication.', '',
        'Exact native score files are preserved in the provenance archive. Where the native all-zero reference produces '
        'a nonfinite Fmax, public JSON uses `null` and records the original representation and metric path. '
        'All finite metric values are unchanged.', '',
        f"Pending original task/recovery: {', '.join(document['pending_tasks']) or 'none'}.", '',
        '[Structured results and correction records](SCORER_COMPATIBILITY_REPAIR_2026-10-19.json) · '
        '[Portable code and provenance](benchmark_assets/scorer_compatibility_repair_2026-10-19.tar.gz)', '']
    md_path = reports / 'SCORER_COMPATIBILITY_REPAIR_2026-10-19.md'
    md_path.write_text('\n'.join(lines))
    for name in ('recovery_runner.py', 'recovery_runner_v2.py', 'score_local_deepfri_confidence_null_equivalence_v1.py',
                 'native_guard_only.diff', 'concurrent_preparer_v2.diff', 'test_null_equivalence_recovery.py',
                 'test_recovery_runner.py', 'test_recovery_runner_v2.py', 'derivation_receipt.json',
                 'runner_validation_receipt_v1.json', 'runner_validation_receipt_v2.json',
                 'preparation_v1_stop_receipt.json', 'REVIEW_PLAN.md', 'export_repair_report.py'):
        members['code/' + name] = (HERE / name).read_bytes()
    members['reports/' + json_path.name] = json_path.read_bytes()
    members['reports/' + md_path.name] = md_path.read_bytes()
    manifest = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(members.items())}
    members['MANIFEST.sha256.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    archive_path = reports / 'benchmark_assets/scorer_compatibility_repair_2026-10-19.tar.gz'
    archive_path.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive_path, 'w:gz') as archive:
        for name, data in sorted(members.items()):
            item = tarfile.TarInfo(name)
            item.size, item.mtime, item.mode = len(data), 0, 0o644
            archive.addfile(item, io.BytesIO(data))
    receipt = {'exported_at_pacific': document['updated_at_pacific'],
        'report_markdown': str(md_path), 'report_json': str(json_path),
        'archive_path': str(archive_path), 'archive_sha256': sha(archive_path),
        'archive_members': len(members), 'completed_tasks': [s['task_id'] for s in snapshots],
        'new_score_metadata_root': str(ROOT / 'results/scoring_corrections'),
        'raw_trajectories_duplicated_in_bundle': False, 'credentials_environments_weights_included': False}
    (HERE / 'public_export_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    export()
