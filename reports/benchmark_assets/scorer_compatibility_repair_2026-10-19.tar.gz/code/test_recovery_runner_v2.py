"""Synthetic integration tests. All fixture cases and labels are artificial."""
import copy
import importlib.util
import json
import math
from pathlib import Path
import shutil
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('tested_null_recovery', HERE / 'recovery_runner_v2.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
SOURCE = driver.REPOSITORY / '.local/remaining_evaluations/deepfri'


class Fixture:
    def __init__(self, base):
        self.root = Path(base) / 'original'
        self.root.mkdir()
        self.native_name = 'synthetic_original_mixed_4k16k_scoring_v1'
        self.folder = self.root / 'results/runs' / self.native_name
        self.folder.mkdir(parents=True)
        self.case_ids = ['synthetic_a', 'synthetic_b', 'synthetic_c']
        variant = 'ARTIFICIAL_TEST_ONLY'
        self.cases = [{'task': 'P14', 'case_id': key, 'variant': variant, 'split': 'artificial',
                       'messages': [{'role': 'user', 'content': 'Synthetic sequence AAAA. Return artificial test scores.'}]}
                      for key in self.case_ids]
        self.full = {'task_id': 'P14', 'approved_task_ids': ['P14'], 'run_id': 'synthetic_full',
            'variant': variant, 'model': 'SYNTHETIC_NO_INFERENCE', 'model_revision': 'synthetic',
            'generation': {'max_tokens': 4096, 'temperature': 1.0, 'top_p': 0.95, 'top_k': 20,
                'seed': 42, 'n': 1, 'chat_template_kwargs': {'enable_thinking': True, 'reasoning_effort': 'medium'}},
            'input_file': 'data/inputs.jsonl', 'review_file': 'configs/review.json',
            'class_vocabulary_file': 'data/vocabulary.json', 'scorer_reference_file': 'data/references.jsonl',
            'scoring_runtime_file': 'configs/runtime.json', 'planned': 3, 'tool_access': [],
            'runner': 'scripts/artificial_runner.py', 'input_modalities': ['synthetic_text'],
            'case_scope': 'SYNTHETIC_TEST_ONLY', 'paper_comparison': 'No scientific comparison.'}
        for name in ['scripts/score_local_deepfri_confidence.py', 'scripts/score_local_genomics.py',
                'scripts/prepare_local_deepfri_proposals.py', 'scripts/prepare_deepfri_sequence_contract.py',
                'scripts/score_local_deepfri_tie_grouped.py', '.venv/bin/python',
                'configs/deepfri_cpu_runtime_assets.json', 'configs/deepfri_cpu_commands.json',
                'sources/deepfri_contract_audit_2026-10-15/torchdrug__torchdrug__metrics__metric.py']:
            target = self.root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOURCE / name, target)
            shutil.copymode(SOURCE / name, target)
        original_runtime = json.loads((SOURCE / 'configs/local_deepfri_scoring_runtime_proposed.json').read_text())
        self.put('configs/runtime.json', original_runtime)
        self.lines('data/inputs.jsonl', self.cases)
        self.put('configs/review.json', {'input_review_only': True, 'approved_case_ids': self.case_ids, 'held_cases': []})
        self.put('data/vocabulary.json', {'classes': [{'index': i, 'class_id': 'C' + str(i)} for i in range(489)]})
        self.lines('data/references.jsonl', [{'task_id': 'P14', 'case_id': key, 'scorer_only': True,
            'positive_class_indices': [0], 'positive_class_ids': ['C0']} for key in self.case_ids])
        path = self.root / 'scripts/artificial_runner.py'
        path.write_text('# Synthetic fixture: no inference exists here.\n')
        frozen = [self.full[k] for k in ['input_file', 'review_file', 'class_vocabulary_file',
            'scorer_reference_file', 'scoring_runtime_file']]
        frozen += ['scripts/score_local_deepfri_confidence.py', 'scripts/score_local_genomics.py',
            'scripts/prepare_local_deepfri_proposals.py', 'scripts/score_local_deepfri_tie_grouped.py',
            'scripts/artificial_runner.py', '.venv/bin/python', 'configs/deepfri_cpu_runtime_assets.json',
            'configs/deepfri_cpu_commands.json',
            'sources/deepfri_contract_audit_2026-10-15/torchdrug__torchdrug__metrics__metric.py']
        self.full['frozen_files_sha256'] = {name: driver.sha(self.root / name) for name in frozen}
        self.full['scorer_reference_sha256'] = driver.sha(self.root / self.full['scorer_reference_file'])
        self.put('configs/full.json', self.full)
        self.budgets = {driver.case_name(case): budget for case, budget in zip(self.cases, [4096, 16384, 16384])}
        self.put(self.folder / 'per_case_budget_map.json', {'condition': 'MIXED_BUDGET_4K16K_CONTINUATION',
            'budgets_by_raw_filename': self.budgets, 'selection': 'Synthetic test only'})
        self.cfg = copy.deepcopy(self.full)
        self.cfg['run_id'] = self.native_name
        self.cfg['generation']['max_tokens'] = None
        self.cfg['mixed_budget_scoring'] = {'per_case_budget_map': {
            'path': str(self.folder / 'per_case_budget_map.json'),
            'sha256': driver.sha(self.folder / 'per_case_budget_map.json')},
            'full_test_id_union_validation': self.union()}
        self.put('configs/' + self.native_name + '.json', self.cfg)
        self.put(self.folder / 'run_manifest.json', {'configuration': self.cfg,
            'configuration_sha256': driver.sha(self.root / 'configs' / (self.native_name + '.json')),
            'runner_sha256': self.cfg['frozen_files_sha256'][self.cfg['runner']],
            'case_contract_sha256': driver.digest(self.cases), 'planned_cases': 3})
        self.original_spec = {'task_id': 'P14', 'project_root': str(self.root), 'output_run_id': self.native_name,
            'full_config_file': 'configs/full.json', 'full_config_sha256': driver.sha(self.root / 'configs/full.json'),
            'scorer_sha256': driver.ORIGINAL_SCORER_SHA256, 'python': sys.executable}
        self.put(self.folder / 'mixed_scoring_spec.json', self.original_spec)
        texts = ['{"scores":{"C0":0.9}}', None, '{"scores":{}}']
        for case, text in zip(self.cases, texts):
            name = driver.case_name(case)
            payload = driver.expected_payload(case, self.full, self.budgets[name])
            metadata = {key: case[key] for key in ['task', 'case_id', 'variant', 'split']}
            self.put(self.folder / 'requests' / name, {**metadata, 'payload': payload, 'request_sha256': driver.digest(payload)})
            self.put(self.folder / 'responses' / name, {**metadata, 'status': 'completed', 'http_status': 200,
                'model': self.full['model'], 'model_revision': self.full['model_revision'],
                'request_sha256': driver.digest(payload), 'finish_reason': 'stop', 'text': text or '',
                'response': {'model': self.full['model'], 'choices': [{'message': {'role': 'assistant',
                    'content': text, 'reasoning_content': 'Artificial reasoning; never selected as final.'}, 'finish_reason': 'stop'}]}})
        raw = {kind + '/' + driver.case_name(case): driver.sha(self.folder / kind / driver.case_name(case))
               for kind in ['requests', 'responses'] for case in self.cases}
        self.put(self.folder / 'mixed_budget_output_lock.json', {'spec_sha256': driver.digest(self.original_spec),
            'per_case_budget_map_sha256': self.cfg['mixed_budget_scoring']['per_case_budget_map']['sha256'],
            'native_denominator': 3, 'all_original_invalid_and_missing_slots_retained': True, 'files_sha256': raw})
        self.put(self.folder / 'scoring_output_lock.json', {'files_sha256': raw, 'contract_sha256': driver.digest(raw)})
        self.put(self.folder / 'native_scorer_invocation.json', {'native_scorer_sha256': driver.ORIGINAL_SCORER_SHA256,
            'spec_sha256': driver.digest(self.original_spec), 'native_calls_planned': 1,
            'output_lock_sha256': driver.sha(self.folder / 'mixed_budget_output_lock.json')})
        (self.folder / 'native_scorer.log').write_text('Synthetic fixture traceback\n  line 184, in score\n' + driver.KNOWN_ERROR + '\n')
        self.put(self.folder / 'completion.json', {'scoring_exit_code': 1, 'generation_exit_code': 0,
            'spec_sha256': driver.digest(self.original_spec),
            'run_manifest_sha256': driver.sha(self.folder / 'run_manifest.json'),
            'configuration_sha256': driver.sha(self.root / 'configs' / (self.native_name + '.json')),
            'full_test_id_union_validation': self.union()})

    def union(self):
        return {'complete': True, 'union_matches_full_test_ids': True, 'expected_test_case_count': 3,
            'unique_observed_case_count': 3, 'missing_case_count': 0, 'extra_case_count': 0, 'duplicate_case_count': 0}

    def put(self, name, value):
        path = Path(name)
        if not path.is_absolute():
            path = self.root / path
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, indent=2) + '\n')

    def lines(self, name, values):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(''.join(json.dumps(value) + '\n' for value in values))

    def validate(self):
        return driver.validate_failed_attempt(self.root, self.original_spec)


class RecoveryRunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='null-recovery-synthetic-')
        self.base = Path(self.temp.name)
        self.fixture = Fixture(self.base)

    def tearDown(self):
        self.temp.cleanup()

    def test_label_blind_validation_counts_exact_nulls(self):
        source = self.fixture.validate()
        self.assertEqual(source['normalization_counts'], {'equal': 2, 'explicit_null_to_empty': 1})
        self.assertEqual(len(source['cases']), 3)

    def test_pending_or_successful_original_is_not_recovered(self):
        p = self.fixture.folder / 'completion.json'
        p.unlink()
        with self.assertRaises(driver.Pending):
            self.fixture.validate()
        self.fixture.put(p, {'scoring_exit_code': 0})
        with self.assertRaisesRegex(driver.RecoveryError, 'successful'):
            self.fixture.validate()

    def test_unknown_original_failure_is_not_recovered(self):
        (self.fixture.folder / 'native_scorer.log').write_text('ValueError: unrelated\n')
        with self.assertRaisesRegex(driver.RecoveryError, 'exact reviewed'):
            self.fixture.validate()

    def test_raw_byte_tampering_rejected(self):
        p = next((self.fixture.folder / 'responses').glob('*.json'))
        p.write_text(p.read_text() + ' ')
        with self.assertRaisesRegex(driver.RecoveryError, 'locked raw bytes'):
            self.fixture.validate()

    def test_reference_file_hash_tampering_rejected(self):
        p = self.fixture.root / 'data/references.jsonl'
        p.write_text(p.read_text() + ' ')
        with self.assertRaisesRegex(driver.RecoveryError, 'frozen dependency'):
            self.fixture.validate()

    def test_prepare_new_id_and_preserve_all_original_bytes(self):
        before = driver.inventory(self.fixture.folder)
        source = self.fixture.validate()
        path = driver.prepare_validated(source, self.base / 'recovery')
        prepared = driver.validate_prepared(path, driver.sha(path))
        self.assertTrue(prepared['output_run_id'].endswith('_mixed_4k16k_scoring_null_equivalence_v1'))
        self.assertEqual(driver.inventory(self.fixture.folder), before)
        self.assertEqual(driver.sha(Path(prepared['project_root']) / driver.SCORER_NAME), driver.DERIVED_SCORER_SHA256)
        with self.assertRaisesRegex(driver.RecoveryError, 'destination exists'):
            driver.prepare_validated(source, self.base / 'recovery')

    def test_prepared_manifest_and_raw_tampering_rejected(self):
        path = driver.prepare_validated(self.fixture.validate(), self.base / 'recovery')
        pin = driver.sha(path)
        value = driver.read(path)
        raw = Path(value['output_directory']) / next(iter(value['raw_files_sha256']))
        raw.write_text(raw.read_text() + ' ')
        with self.assertRaisesRegex(driver.RecoveryError, 'Prepared raw bytes'):
            driver.validate_prepared(path, pin)
        with self.assertRaisesRegex(driver.RecoveryError, 'Pinned file changed'):
            driver.validate_prepared(path, '0' * 64)

    def test_synthetic_end_to_end_native_scoring_preserves_denominator(self):
        before = driver.inventory(self.fixture.folder)
        path = driver.prepare_validated(self.fixture.validate(), self.base / 'recovery')
        pin = driver.sha(path)
        prepared = driver.read(path)
        folder = Path(prepared['output_directory'])
        try:
            result = driver.execute_prepared(path, pin)
        except driver.RecoveryError as exc:
            self.fail(str(exc) + '\n' + (folder / 'native_scorer.log').read_text())
        if result['scoring_exit_code']:
            self.fail((folder / 'native_scorer.log').read_text())
        scores = driver.read(folder / 'scores.json')
        self.assertEqual(scores['planned'], 3)
        self.assertEqual(scores['completed'], 3)
        self.assertEqual(scores['parsed'], 2)
        self.assertEqual(scores['invalid_outputs'], 1)
        self.assertIsNone(scores['metrics']['auprc@micro'])
        self.assertIsNone(scores['metrics']['f1_max'])
        self.assertEqual(scores['metrics']['PARSED_ONLY_DIAGNOSTIC']['planned_cases'], 3)
        self.assertEqual(scores['metrics']['PARSED_ONLY_DIAGNOSTIC']['valid_cases'], 2)
        self.assertEqual(scores['generation']['output_budget_counts'], {'4096': 1, '16384': 2})
        self.assertEqual(scores['scorer_sha256'], driver.DERIVED_SCORER_SHA256)
        self.assertEqual(scores['scorer_recovery']['original_scorer_sha256'], driver.ORIGINAL_SCORER_SHA256)
        json.loads((folder / 'scores.json').read_text(), parse_constant=lambda value: self.fail('Nonfinite public JSON: ' + value))
        raw = folder / scores['native_unmodified_scores_artifact']['path']
        self.assertEqual(driver.sha(raw), scores['native_unmodified_scores_artifact']['sha256'])
        native = driver.read(raw)
        self.assertEqual(native['metrics']['PARSED_ONLY_DIAGNOSTIC']['auprc@micro'], scores['metrics']['PARSED_ONLY_DIAGNOSTIC']['auprc@micro'])
        self.assertEqual(driver.inventory(self.fixture.folder), before)
        with self.assertRaisesRegex(driver.RecoveryError, 'already attempted'):
            driver.execute_prepared(path, pin)

    def test_exact_other_field_conflicts_never_normalized(self):
        for raw, saved in [(None, ' '), ('a', 'b'), ('', None)]:
            record = {'status': 'completed', 'http_status': 200, 'finish_reason': 'stop', 'text': saved,
                'response': {'choices': [{'message': {'role': 'assistant', 'content': raw}, 'finish_reason': 'stop'}]}}
            with self.subTest(raw=raw, saved=saved), self.assertRaises(driver.RecoveryError):
                driver.classify_envelope(record)

    def test_nonfinite_public_representation_retains_all_finite_values(self):
        native = {'finite': [0.5, 0.0, -1.25, None], 'nan': float('nan'),
                  'inf': float('inf'), 'nested': {'negative': -float('inf')}}
        clean, records = driver.public_metric_values(native)
        self.assertEqual(clean, {'finite': [0.5, 0.0, -1.25, None], 'nan': None,
                                 'inf': None, 'nested': {'negative': None}})
        self.assertEqual(records, [{'path': 'metrics.nan', 'native_representation': 'NaN'},
            {'path': 'metrics.inf', 'native_representation': 'Infinity'},
            {'path': 'metrics.nested.negative', 'native_representation': '-Infinity'}])
        self.assertTrue(math.isnan(native['nan']))
        json.dumps(clean, allow_nan=False)

    def test_concurrent_raw_copy_hashes_and_join_are_exact(self):
        original_copy = driver.copy_exact
        mutex = threading.Lock()
        state = {'active': 0, 'maximum': 0}
        def observed_copy(source, target, expected):
            if Path(target).parent.name not in {'requests', 'responses'}:
                return original_copy(source, target, expected)
            with mutex:
                state['active'] += 1
                state['maximum'] = max(state['maximum'], state['active'])
            try:
                time.sleep(0.02)
                return original_copy(source, target, expected)
            finally:
                with mutex:
                    state['active'] -= 1
        with mock.patch.object(driver, 'copy_exact', observed_copy):
            path = driver.prepare_validated(self.fixture.validate(), self.base / 'parallel')
        prepared = driver.read(path)
        self.assertGreater(state['maximum'], 1)
        self.assertLessEqual(state['maximum'], driver.IO_WORKERS)
        self.assertEqual(state['active'], 0)
        self.assertEqual(prepared['preparation_io']['copies_joined'], 6)
        folder = Path(prepared['output_directory'])
        for name, expected in prepared['raw_files_sha256'].items():
            self.assertEqual(driver.sha(folder / name), expected)
            self.assertEqual((folder / name).read_bytes(), (self.fixture.folder / name).read_bytes())

    def test_incomplete_parallel_copy_never_creates_ready_manifest(self):
        original_copy = driver.copy_exact
        def incomplete(source, target, expected):
            if Path(target).parent.name == 'responses':
                return
            return original_copy(source, target, expected)
        destination = self.base / 'incomplete'
        with mock.patch.object(driver, 'copy_exact', incomplete):
            with self.assertRaisesRegex(driver.RecoveryError, 'incomplete'):
                driver.prepare_validated(self.fixture.validate(), destination)
        self.assertFalse((destination / 'prepared_manifest.json').exists())

    def test_tampered_parallel_copy_never_creates_ready_manifest(self):
        original_copy = driver.copy_exact
        def tamper(source, target, expected):
            original_copy(source, target, expected)
            if Path(target).parent.name == 'responses':
                with Path(target).open('ab') as handle:
                    handle.write(b' ')
        destination = self.base / 'tampered'
        with mock.patch.object(driver, 'copy_exact', tamper):
            with self.assertRaisesRegex(driver.RecoveryError, 'bytes changed'):
                driver.prepare_validated(self.fixture.validate(), destination)
        self.assertFalse((destination / 'prepared_manifest.json').exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
