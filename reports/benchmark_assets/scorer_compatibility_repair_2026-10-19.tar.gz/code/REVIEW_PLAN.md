# DeepFRI null-equivalence recovery: prepared for review, not executed

The original API client saves `text = message.content or ""`. The frozen
DeepFRI scorer requires literal equality between raw API `content` and saved
`text`. A reasoning-only completion therefore has raw `null` and saved `""`
and aborts scoring before being counted as an invalid prediction.

The derived scorer changes only that one equality guard. Explicit raw
`content: null` and saved `text: ""` are equivalent for provenance validation.
Every nonempty mismatch and every finish-reason mismatch still aborts. Missing
or truncated final answers remain invalid, and reasoning is never substituted
for a final prediction. Original scorer bytes, raw files and failed-attempt
journals remain unchanged. The exact unified diff and both SHA-256 hashes are
recorded beside this plan.

## Proposed application after independent review

1. Apply to all four tasks P12–P15 under the same declared rule. Wait for each
   original mixed-budget scoring attempt to reach a terminal state. Do not
   preempt pending scoring or restart its watcher. A successful original task
   remains successful and needs no duplicate computation.
2. Require an original failed-attempt completion, exact original native scorer
   hash and a log identifying the known final-field conflict. Validate every
   raw envelope label-blind; accept only explicit null/empty disagreements.
   Abort on any other divergent answer or finish field. Pin all raw hashes and
   the exact original full-case union before references are opened.
3. Create a separate recovery project root below this versioned directory.
   Preserve original scripts/data/source/runtime paths through read-only
   provenance bindings. Install a physical copy of the derived scorer under
   its expected `scripts/score_local_deepfri_confidence.py` path in that root.
   Pin its derived hash in the new recovery config; keep all other source
   hashes unchanged. This avoids bypassing or spoofing the native scorer's
   `__file__`, frozen-file and runtime checks.
4. Use new output IDs ending `_mixed_4k16k_scoring_null_equivalence_v1`.
   Copy already sealed raw requests/responses byte-for-byte to the new
   derived scoring view, retaining exact original per-case 4K/16K budgets and
   source-order case IDs. Never modify the failed output directory, its
   completion, invocation, output lock or raw envelopes.
5. Reuse the frozen mixed-budget payload selector and full-case union checks,
   with a separate reviewed recovery invocation. Record original and derived
   scorer hashes plus the normalization count. Keep the native final parser,
   confidence matrix construction, AP/Fmax formulas and all-invalid-case
   accounting unchanged. This is a new versioned offline scoring attempt,
   never a new model generation or an undocumented retry of an old output ID.
6. Label result metadata `NULL_EQUIVALENCE_SCORING_RECOVERY_V1`, explicitly
   state that the scorer provenance guard changed, and preserve the native
   original versus derived code hashes. Do not assert the complete scorer is
   byte-unchanged. With any invalid vector, primary full-set AP/Fmax remain
   null; parsed-only diagnostics stay separately named and counted.

`recovery_runner.py` implements this workflow. `--prepare P12` (or P13/P14/P15)
only creates a sealed recovery project and a manifest/hash. A separate
`--execute-prepared PATH --expected-sha256 HASH` runs one recorded offline
scoring attempt in the existing CPU allocation. No generation or queue change
is part of either mode. Original attempts and prepared recovery attempts cannot
be overwritten or automatically retried.

The source-native writer can emit NaN for a tied all-zero Fmax diagnostic.
Recovery retains the exact native score bytes and their hash. Annotated public
JSON represents only nonfinite values as null and records each original
representation/path. All finite values and native metric formulas remain
unchanged.

## Known original attempts

P14 and P15 original mixed-budget attempts failed at the provenance guard
after validating exact 3,416-case unions. All observed conflicts are raw null
versus saved empty string (P14: 91 cases; P15: 18 cases). P12 subsequently
failed at the same guard after validating 1,919 cases, with 234 null/empty
conflicts. P13's original attempt must reach a terminal state before recovery.

The normalization does not make these empty final answers valid predictions.
The completed P14/P15 coverage audit already finds invalid vectors, so the
frozen all-valid rule will still withhold full-set primary AP/Fmax.
