"""Synthetic provenance attacks and per-case extraction; no benchmark data."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from run_visible_extraction import analyze, canonical


def sha(raw):return hashlib.sha256(raw).hexdigest()


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        self.identity={'task_id':'V01','run_id':'synthetic-original','protocol_variant':'SYNTHETIC','model':'synthetic-model','model_revision':'synthetic-revision'}
        self.contract={'schema_version':2,**self.identity,'planned':2,'cases':[]}
        self.plan={**self.identity,'planned':2,'original_contract_path':'contract.json','run_manifest_path':'run_manifest.json','slots':[]}
        for cid,kind,text in [('s1','CLOSED','Answer: Yes'),('s2','OPEN','Answer: liver')]:
            payload={'model':self.identity['model'],'messages':[{'role':'user','content':'synthetic question '+cid}],'choices':['A','B']}
            ph=sha(canonical(payload));common={'task':self.identity['task_id'],'run_id':self.identity['run_id'],'variant':self.identity['protocol_variant'],'model':self.identity['model'],'model_revision':self.identity['model_revision'],'case_id':cid,'request_sha256':ph}
            request={**common,'payload':payload};body={'model':self.identity['model'],'choices':[{'message':{'content':text,'reasoning':'Answer: DO NOT USE'},'finish_reason':'stop'}]}
            body_raw=json.dumps(body);response={**common,'raw_response_body':body_raw,'response':body,'text':text,'finish_reason':'stop','status':'completed'}
            rp=self.root/(cid+'-request.json');sp=self.root/(cid+'-response.json');rp.write_text(json.dumps(request));sp.write_text(json.dumps(response))
            self.contract['cases'].append({'case_id':cid,'answer_type':kind,'request_sha256':sha(rp.read_bytes()),'request_payload_sha256':ph,'response_sha256':sha(sp.read_bytes()),'raw_response_sha256':sha(body_raw.encode()),'visible_final_sha256':sha(text.encode())})
            self.plan['slots'].append({'case_id':cid,'request_path':rp.name,'response_path':sp.name})
        self.path=self.root/'plan.json';self.bind_contract()

    def bind_contract(self):
        path=self.root/'contract.json';path.write_text(json.dumps(self.contract));ch=sha(path.read_bytes())
        self.plan['original_contract_sha256']=ch
        manifest={**self.identity,'planned':2,'original_case_contract_sha256':ch}
        mp=self.root/'run_manifest.json';mp.write_text(json.dumps(manifest));self.plan['run_manifest_sha256']=sha(mp.read_bytes());self.write()

    def write(self):self.path.write_text(json.dumps(self.plan))

    def test_mixed_open_closed_rules_and_complete_denominator(self):
        r=analyze(self.path);self.assertEqual(r['planned'],2);self.assertEqual(r['counts']['extracted'],2)
        self.assertEqual([x['value'] for x in r['rows']],['yes','liver']);self.assertEqual([x['kind'] for x in r['rows']],['binary','free_text']);self.assertFalse(r['references_read']);self.assertFalse(r['correctness_computed'])

    def test_wrong_run_and_bogus_contract_hash(self):
        self.plan['run_id']='foreign';self.write()
        with self.assertRaises(ValueError):analyze(self.path)
        self.plan['run_id']=self.identity['run_id'];self.plan['original_contract_sha256']='0'*64;self.write()
        with self.assertRaises(ValueError):analyze(self.path)

    def test_wrong_case_order_and_omitted_case(self):
        self.plan['slots'].reverse();self.write()
        with self.assertRaises(ValueError):analyze(self.path)
        self.plan['slots']=self.plan['slots'][:1];self.plan['planned']=1;self.write()
        with self.assertRaises(ValueError):analyze(self.path)

    def test_request_swap_and_choice_permutation_refused(self):
        a,b=self.plan['slots'];a['request_path'],b['request_path']=b['request_path'],a['request_path'];self.write()
        with self.assertRaises(ValueError):analyze(self.path)
        a['request_path'],b['request_path']=b['request_path'],a['request_path'];self.write()
        path=self.root/a['request_path'];request=json.loads(path.read_text());request['payload']['choices'].reverse();path.write_text(json.dumps(request))
        with self.assertRaises(ValueError):analyze(self.path)

    def test_tampered_output_and_wrong_response_request_binding_refused(self):
        path=self.root/self.plan['slots'][0]['response_path'];r=json.loads(path.read_text());r['request_sha256']='f'*64;path.write_text(json.dumps(r));self.contract['cases'][0]['response_sha256']=sha(path.read_bytes());self.bind_contract()
        with self.assertRaisesRegex(ValueError,'association'):analyze(self.path)

    def test_raw_saved_content_conflict_even_if_record_hash_rebound(self):
        path=self.root/self.plan['slots'][0]['response_path'];r=json.loads(path.read_text());r['text']='Answer: No';path.write_text(json.dumps(r));self.contract['cases'][0]['response_sha256']=sha(path.read_bytes());self.bind_contract()
        with self.assertRaisesRegex(ValueError,'visible'):analyze(self.path)

    def test_missing_record_preserved_only_if_original_contract_says_missing(self):
        path=self.root/self.plan['slots'][1]['response_path'];path.unlink()
        self.contract['cases'][1].update(response_sha256=None,raw_response_sha256=None,visible_final_sha256=None);self.bind_contract()
        r=analyze(self.path);self.assertEqual(r['planned'],2);self.assertEqual(r['counts']['missing_original_slot'],1);self.assertIsNone(r['rows'][1]['value'])
        path.write_text('{}')
        with self.assertRaises(ValueError):analyze(self.path)

    def test_original_manifest_must_bind_contract_and_model(self):
        path=self.root/'run_manifest.json';r=json.loads(path.read_text());r['original_case_contract_sha256']='a'*64;path.write_text(json.dumps(r));self.plan['run_manifest_sha256']=sha(path.read_bytes());self.write()
        with self.assertRaisesRegex(ValueError,'bind'):analyze(self.path)

    def test_boolean_proof_is_not_an_original_contract(self):
        del self.plan['original_contract_path']
        self.plan.update(original_case_set_verified=True,source_case_contract_sha256='a'*64)
        self.write()
        with self.assertRaisesRegex(ValueError,'Actual original'):analyze(self.path)

    def test_raw_null_with_saved_empty_stays_invalid(self):
        path=self.root/self.plan['slots'][0]['response_path'];r=json.loads(path.read_text())
        body=r['response'];body['choices'][0]['message']['content']=None
        raw=json.dumps(body);r.update(raw_response_body=raw,text='');path.write_text(json.dumps(r))
        self.contract['cases'][0].update(response_sha256=sha(path.read_bytes()),raw_response_sha256=sha(raw.encode()),visible_final_sha256=sha(b''))
        self.bind_contract();result=analyze(self.path)
        self.assertIsNone(result['rows'][0]['value']);self.assertEqual(result['rows'][0]['reason'],'empty_final')

    def test_model_mismatch_refused_after_output_rebinding(self):
        path=self.root/self.plan['slots'][0]['response_path'];r=json.loads(path.read_text());r['model_revision']='foreign';path.write_text(json.dumps(r));self.contract['cases'][0]['response_sha256']=sha(path.read_bytes());self.bind_contract()
        with self.assertRaisesRegex(ValueError,'identity'):analyze(self.path)


if __name__=='__main__':unittest.main()
