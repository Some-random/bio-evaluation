# Historical extraction tools: provenance v2

Offline delivery diagnostics only. No references, inference or correctness scoring.
The original visible-final rules remain unchanged. The runner now requires actual
files and associations instead of an `original_case_set_verified` boolean.

Run `python -m unittest discover -s . -p 'test_*.py' -v` (23 synthetic tests).
Run a restored real input only after its original source identity is verified:
`python run_visible_extraction.py --plan restored_plan.json --output new_diagnostic.json`.
Existing output files are never overwritten.

The plan names `task_id`, `run_id`, `protocol_variant`, `model`, `model_revision`,
`planned`, `original_contract_path`, `original_contract_sha256`,
`run_manifest_path`, `run_manifest_sha256`, and ordered `slots`. Each slot names
`case_id`, `request_path`, and `response_path`. Paths resolve relative to the plan.

The actual contract must expose the same identities, its full original `planned`
count and ordered `cases`. Every case binds `case_id`, original `answer_type`
(OPEN/CLOSED/MCQ), `request_sha256`, `request_payload_sha256`, `response_sha256`,
`raw_response_sha256`, and `visible_final_sha256`. The opened original run
manifest must bind `original_case_contract_sha256` and matching identities/count.
The request/response records are also checked for task, protocol, model/revision,
case ID, request payload and raw/saved output equivalence. OPEN uses explicit
terminal free text, CLOSED uses exact Yes/No, MCQ uses exact A/B/C/D. The type must
come from the original input contract; no reference answer selects a rule.

Hash encodings: file hashes use exact bytes; request payload hash uses sorted
compact UTF-8 JSON with ensure_ascii=False. Raw response hash uses exact UTF-8
`raw_response_body` when available, otherwise canonical JSON of `response`.
Visible-final hash uses the saved final string's UTF-8 bytes. A raw null final may
match a saved empty string, but remains invalid. Missing response slots require
null hashes in the original contract and an absent file; they remain in the full
denominator. A filename or an asserted boolean alone is never evidence.

This is a strict input contract, not an adapter that fabricates old manifests.
If restored originals use a different schema, their field mapping and original
hash linkage need independent validation before this runner can accept them.
The unavailable P01 and V01–V05 runs remain blocked; no new historical benchmark
correctness or extraction rates have been computed.
