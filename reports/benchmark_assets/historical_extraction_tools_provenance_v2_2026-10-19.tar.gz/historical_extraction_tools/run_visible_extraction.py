"""Offline extraction from an opened, hash-bound original case contract.

Schema 2 rejects boolean-only provenance. The actual run manifest binds the
actual contract digest; that contract binds every request, raw response, saved
final and per-case answer type. No references are opened or scored.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
from extraction_rules_v1 import VERSION, extract_final

PROVENANCE_VERSION = 'HISTORICAL_ORIGINAL_CONTRACT_BINDING_V2'
KINDS = {'OPEN': 'free_text', 'CLOSED': 'binary', 'MCQ': 'mcq_abcd'}
IDENTITY = ('task_id', 'run_id', 'protocol_variant', 'model', 'model_revision')


def sha(raw):return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()


def resolve(base, value):
    path = Path(value)
    return path if path.is_absolute() else base / path


def verified(path, expected):
    if not isinstance(expected, str) or len(expected) != 64:
        raise ValueError('Missing original artifact SHA-256')
    raw = path.read_bytes()
    if sha(raw) != expected:raise ValueError('Original artifact hash changed: ' + path.name)
    value = json.loads(raw)
    if not isinstance(value, dict):raise ValueError('Original artifact must be an object')
    return value


def identity(record, owner, required=True):
    aliases = {'task_id': 'task', 'protocol_variant': 'variant'}
    for key in IDENTITY:
        actual = record.get(key, record.get(aliases.get(key, key)))
        if key == 'run_id' and not required and actual is None:continue
        if actual != owner[key]:raise ValueError('Original run identity mismatch: ' + key)


def analyze(plan_path):
    plan_path = Path(plan_path);base = plan_path.parent
    plan_raw = plan_path.read_bytes();plan = json.loads(plan_raw)
    required = {*IDENTITY,'planned','slots','original_contract_path','original_contract_sha256','run_manifest_path','run_manifest_sha256'}
    if not required <= set(plan) or plan.get('task_id') not in {'P01','V01','V02','V03','V04','V05'}:
        raise ValueError('Actual original contract and run-manifest files are required')
    freeze = json.loads((Path(__file__).parent / 'extraction_rules_freeze_v1.json').read_text())
    for name, expected in freeze['files_sha256'].items():
        if sha((Path(__file__).parent / name).read_bytes()) != expected:
            raise ValueError('Frozen extraction dependency changed')
    provenance = json.loads((Path(__file__).parent / 'extraction_provenance_freeze_v2.json').read_text())
    for name, expected in provenance['files_sha256'].items():
        if sha((Path(__file__).parent / name).read_bytes()) != expected:
            raise ValueError('Frozen provenance dependency changed')
    contract = verified(resolve(base, plan['original_contract_path']), plan['original_contract_sha256'])
    manifest = verified(resolve(base, plan['run_manifest_path']), plan['run_manifest_sha256'])
    if contract.get('schema_version') != 2:raise ValueError('Require schema-2 original contract')
    for owner in [contract, manifest]:identity(owner, plan)
    if manifest.get('original_case_contract_sha256') != plan['original_contract_sha256']:
        raise ValueError('Original run manifest does not bind this case contract')
    cases = contract['cases'];slots = plan['slots']
    expected_ids = [case['case_id'] for case in cases];ids = [slot['case_id'] for slot in slots]
    if (not ids or ids != expected_ids or len(set(ids)) != len(ids)
            or len(ids) != plan['planned'] or len(ids) != contract.get('planned')
            or len(ids) != manifest.get('planned')):
        raise ValueError('Exact original case IDs/order/denominator required')
    counts = Counter();rows = []
    for slot, case in zip(slots, cases):
        kind = KINDS.get(case.get('answer_type'))
        if (kind is None or (plan['task_id'] == 'P01' and kind != 'binary')
                or (plan['task_id'] == 'V05' and kind != 'mcq_abcd')
                or (plan['task_id'] in {'V01','V02','V03','V04'} and kind == 'mcq_abcd')):
            raise ValueError('Invalid original per-case answer type')
        request = verified(resolve(base, slot['request_path']), case['request_sha256'])
        identity(request, plan, required=False)
        if request.get('case_id') != case['case_id']:raise ValueError('Request case mismatch')
        payload_hash = sha(canonical(request['payload']))
        if (payload_hash != case['request_payload_sha256']
                or request.get('request_sha256') != payload_hash
                or request['payload'].get('model') != plan['model']):
            raise ValueError('Original request payload mismatch')
        path = resolve(base, slot['response_path']);expected = case['response_sha256']
        if expected is None:
            if path.exists():raise ValueError('Previously missing response appeared')
            if case.get('visible_final_sha256') is not None or case.get('raw_response_sha256') is not None:
                raise ValueError('Missing response has contradictory output hashes')
            counts['missing_original_slot'] += 1
            rows.append({'case_id':case['case_id'],'kind':kind,'value':None,'reason':'missing_original_slot'})
            continue
        response = verified(path, expected);identity(response, plan, required=False)
        if response.get('case_id') != case['case_id'] or response.get('request_sha256') != payload_hash:
            raise ValueError('Response/request/case association mismatch')
        raw_body = response.get('raw_response_body')
        if raw_body is not None:
            if not isinstance(raw_body,str):raise ValueError('Malformed raw response body')
            body = json.loads(raw_body);body_hash = sha(raw_body.encode())
            if response.get('response') is not None and response['response'] != body:
                raise ValueError('Raw response and saved response conflict')
        else:
            body = response.get('response');body_hash = sha(canonical(body))
        if body_hash != case['raw_response_sha256']:raise ValueError('Raw output hash mismatch')
        if not isinstance(body,dict) or (body.get('model') is not None and body['model'] != plan['model']):
            raise ValueError('Raw model identity mismatch')
        choices = body.get('choices')
        if response.get('status') == 'completed' and (body.get('model') != plan['model'] or not isinstance(choices,list) or len(choices)!=1):
            raise ValueError('Single native response required')
        choice = choices[0] if isinstance(choices,list) and len(choices)==1 else {}
        raw_final = choice.get('message',{}).get('content')
        if raw_final is not None and not isinstance(raw_final,str):raise ValueError('Invalid visible final type')
        content = raw_final if raw_final is not None else '';saved = response.get('text')
        if (not isinstance(saved,str) or content != saved
                or choice.get('finish_reason') != response.get('finish_reason')
                or sha(saved.encode()) != case['visible_final_sha256']):
            raise ValueError('Raw visible content or output hash does not match saved final')
        result = extract_final(content, kind, response.get('status'), response.get('finish_reason'))
        counts[result['reason']] += 1;counts['extracted'] += result['value'] is not None;counts['responses_present'] += 1
        rows.append({'case_id':case['case_id'],'kind':kind,**result,
            'source_request_sha256':case['request_sha256'],'source_response_sha256':expected})
    return {'version':VERSION,'provenance_version':PROVENANCE_VERSION,
        **{key:plan[key] for key in IDENTITY},'planned':plan['planned'],'counts':dict(counts),'rows':rows,
        'plan_sha256':sha(plan_raw),'original_contract_sha256':plan['original_contract_sha256'],
        'run_manifest_sha256':plan['run_manifest_sha256'],'references_read':False,
        'correctness_computed':False,'native_scores_changed':False}


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();result=analyze(args.plan)
    with args.output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
