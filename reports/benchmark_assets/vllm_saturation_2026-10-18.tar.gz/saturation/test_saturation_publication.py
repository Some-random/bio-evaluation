"""Synthetic publication tests; no serving, scorers, or remote mutation."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
from types import SimpleNamespace
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
spec = importlib.util.spec_from_file_location('saturation_publication_tested', HERE / 'publish_saturation_artifacts.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
scanner = m.module('saturation_test_scanner', ROOT / 'scripts/daily_backup.py')
old_spec = importlib.util.spec_from_file_location('original_shared_publication_tests', ROOT / 'tests/test_publish_shared_vllm_artifacts.py')
old_tests = importlib.util.module_from_spec(old_spec)
old_spec.loader.exec_module(old_tests)
old_tests.PUBLICATION = m


class SaturationPublicationTests(unittest.TestCase):
    def test_two_host_runtime_overviews_are_separate_and_serving_status_takes_precedence(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            pool, published = root / '.local/pool', root / 'published'
            upgraded = pool / 'existing_upgrade'
            for directory, job in ((pool, 'new-four'), (upgraded, 'original-four-upgraded')):
                m.write(directory / 'serving_status.json', {'stage': 'evaluating', 'slurm_job_id': job, 'updated_at': m.stamp()})
                m.write(directory / 'status.json', {'stage': 'obsolete_old_state', 'slurm_job_id': 'wrong'})
                m.write(directory / 'saturation_endpoints.json', [{'endpoint_id': job}])
                m.write(directory / 'saturation_replica_0/server_identity.json', {'job': job})
                code = root / (job + '.py')
                code.write_text('# synthetic runtime helper\n')
                m.write(directory / 'saturation_serving_plan.json', {'code_sha256': {str(code): m.sha(code)}})
            self.assertTrue(m.publish_runtime_overviews(root, pool, published, scanner))
            for directory, relative in ((pool, Path('.')), (upgraded, Path('existing_upgrade'))):
                for name in ('serving_status.json', 'saturation_endpoints.json', 'saturation_replica_0/server_identity.json'):
                    self.assertEqual((directory / name).read_bytes(), (published / relative / name).read_bytes())
            self.assertFalse(m.publish_runtime_overviews(root, pool, published, scanner))
            self.assertEqual(m.pool_health(pool)['slurm_job_id'], 'new-four')
            self.assertEqual(m.pool_health(pool)['additional_pools'][0]['slurm_job_id'], 'original-four-upgraded')
            self.assertFalse((published / 'status.json').exists())
            (root / 'original-four-upgraded.py').write_text('# changed frozen helper\n')
            with self.assertRaisesRegex(ValueError, 'Pinned publication dependency changed'):
                m.publish_runtime_overviews(root, pool, published, scanner)

    def test_nested_overview_symlink_cannot_escape_or_import_unrelated_content(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            pool, outside = root / 'pool', root / 'unrelated'
            pool.mkdir()
            outside.mkdir()
            (pool / 'existing_upgrade').symlink_to(outside, target_is_directory=True)
            with self.assertRaisesRegex(ValueError, 'regular owned'):
                m.publish_runtime_overviews(root, pool, root / 'published', scanner)

    def test_saturation_sidecar_shadows_old_terminal_and_pause_is_not_completion(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            spec = {'folder': folder, 'run_id': 'original', 'planned': 2}
            m.write(folder / 'shared_vllm_amendment.json', {'amendment_sha256': 'old'})
            m.write(folder / 'shared_vllm_generation_completion.json', {'run_id': 'original', 'planned': 2, 'amendment_sha256': 'old', 'generation_exit_code': 1, 'statuses': {'completed': 1, 'not_dispatched': 1}})
            m.write(folder / 'shared_vllm_saturation_amendment.json', {'amendment_sha256': 'new'})
            m.write(folder / 'shared_vllm_saturation_pause.json', {'remaining': 1})
            native = SimpleNamespace(outcome_status=lambda _: self.fail('Cannot fall back to old outcome'))
            outcome = m.generation_outcome(native, spec)
            self.assertFalse(outcome['terminal'])
            self.assertTrue(outcome['generation_paused'])
            m.write(folder / 'shared_vllm_saturation_generation_completion.json', {'run_id': 'original', 'planned': 2, 'amendment_sha256': 'new', 'generation_exit_code': 0, 'statuses': {'completed': 2}})
            outcome = m.generation_outcome(native, spec)
            self.assertTrue(outcome['terminal'])
            self.assertTrue(outcome['execution_success'])
            self.assertIsNone(outcome['native_metrics_valid'])
            self.assertEqual(outcome['actual_serving'], 'shared_vllm_saturation')

    def test_completion_denominator_cannot_be_forged_by_marker(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            m.write(folder / 'shared_vllm_saturation_amendment.json', {'amendment_sha256': 'new'})
            m.write(folder / 'shared_vllm_saturation_generation_completion.json', {'run_id': 'run', 'planned': 2, 'amendment_sha256': 'new', 'generation_exit_code': 0, 'statuses': {'completed': 1}})
            with self.assertRaisesRegex(ValueError, 'frozen run'):
                m.generation_outcome(SimpleNamespace(), {'folder': folder, 'run_id': 'run', 'planned': 2})

    def test_new_receipt_archives_preserve_previously_published_proof(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source, destination = root / 'source', root / 'published'
            old = source / 'shared_vllm_dispatch/a.json'
            old.parent.mkdir(parents=True)
            old.write_bytes(b'{"filename":"a.json", "status":"response_saved"}\n')
            new = source / 'shared_vllm_saturation_dispatch/b.json'
            new.parent.mkdir()
            new.write_bytes(b'{"filename":"b.json", "status":"response_saved", "generation":"new"}\n')
            index = [{'filename': 'a.json', 'archive_sha256': 'archive-a'}, {'filename': 'b.json', 'archive_sha256': 'archive-b'}]
            m.publish_dispatch(source, destination, index, scanner)
            original_index = (destination / 'shared_vllm_dispatch_index.json').read_bytes()
            original_archives = {p.name: p.read_bytes() for p in (destination / 'shared_vllm_metadata_batches').glob('*')}
            self.assertTrue(m.publish_dispatch(source, destination, index, scanner, 'shared_vllm_saturation'))
            self.assertEqual((destination / 'shared_vllm_dispatch_index.json').read_bytes(), original_index)
            self.assertEqual({p.name: p.read_bytes() for p in (destination / 'shared_vllm_metadata_batches').glob('*')}, original_archives)
            entry = m.read(destination / 'shared_vllm_saturation_dispatch_index.json')[0]
            with tarfile.open(destination / entry['archive'], 'r:gz') as archive:
                self.assertEqual(archive.extractfile(entry['member']).read(), new.read_bytes())
            self.assertFalse(m.publish_dispatch(source, destination, index, scanner, 'shared_vllm_saturation'))

    def test_two_phase_infrastructure_manifests_and_parent_chain_are_preserved(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            folder, destination = root / 'run', root / 'published'
            old_amendment = root / 'old_amendment.json'
            m.write(old_amendment, {})
            old_sidecar = {'run_id': 'run', 'amendment_path': str(old_amendment), 'amendment_sha256': m.sha(old_amendment)}
            m.write(folder / 'shared_vllm_amendment.json', old_sidecar)
            m.publish_pins(root, old_sidecar, destination, scanner)
            old_manifest_bytes = (destination / 'shared_infrastructure_manifest.json').read_bytes()
            new_amendment = root / 'new_amendment.json'
            m.write(new_amendment, {'parent_amendment': {'path': str(old_amendment), 'sha256': m.sha(old_amendment)}})
            checkpoint = folder / 'shared_vllm_saturation_parent_checkpoint.json'
            m.write(checkpoint, {'run_id': 'run', 'parent_amendment_sha256': m.sha(old_amendment), 'parent_sidecar_sha256': m.sha(folder / 'shared_vllm_amendment.json'), 'files_sha256': {}})
            sidecar = {'run_id': 'run', 'amendment_path': str(new_amendment), 'amendment_sha256': m.sha(new_amendment), 'parent_amendment_sha256': m.sha(old_amendment), 'parent_sidecar_sha256': m.sha(folder / 'shared_vllm_amendment.json'), 'parent_checkpoint_sha256': m.sha(checkpoint)}
            m.write(folder / 'shared_vllm_saturation_amendment.json', sidecar)
            self.assertTrue(m.publish_provenance(root, {'folder': folder, 'run_id': 'run'}, destination, scanner))
            self.assertEqual((destination / 'shared_infrastructure_manifest.json').read_bytes(), old_manifest_bytes)
            new_manifest = m.read(destination / 'shared_vllm_saturation_infrastructure_manifest.json')
            self.assertIn('parent_infrastructure_amendment', {row['kind'] for row in new_manifest})
            m.write(checkpoint, {'changed': True})
            with self.assertRaisesRegex(ValueError, 'parent checkpoint/sidecar differs'):
                m.publish_provenance(root, {'folder': folder, 'run_id': 'run'}, destination, scanner)

    def test_checkout_fast_forwards_before_new_work_and_never_discards_dirty_work(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            upstream, checkout = root / 'upstream', root / 'state/upload_checkout'
            upstream.mkdir()
            def run(where, *args, allow_failure=False, cwd=None):
                result = subprocess.run(['git', *args], cwd=cwd or where, text=True, capture_output=True)
                if result.returncode and not allow_failure:
                    raise RuntimeError(result.stderr)
                return result
            run(upstream, 'init', '-q', '-b', 'main')
            run(upstream, 'config', 'user.name', 'Synthetic')
            run(upstream, 'config', 'user.email', 'synthetic@example.invalid')
            report = upstream / 'results/runs/run/report.json'
            report.parent.mkdir(parents=True)
            report.write_text('{"version":1}\n')
            run(upstream, 'add', '.')
            run(upstream, 'commit', '-qm', 'original synthetic artifact')
            native = SimpleNamespace(CHECKOUT=checkout, ROOT=upstream, helpers=SimpleNamespace(URL=str(upstream)), git=lambda *args, **kwargs: run(checkout, *args, **kwargs))
            m.initialize_checkout(native, root / 'state', {'run': {}})
            report.write_text('{"version":2}\n')
            run(upstream, 'add', '.')
            run(upstream, 'commit', '-qm', 'remote advance')
            m.initialize_checkout(native, root / 'state', {'run': {}})
            local = checkout / 'results/runs/run/report.json'
            self.assertEqual(local.read_bytes(), report.read_bytes())
            local.write_text('retained unfinished publication\n')
            with self.assertRaisesRegex(ValueError, 'retained uncommitted'):
                m.initialize_checkout(native, root / 'state', {'run': {}})
            self.assertEqual(local.read_text(), 'retained unfinished publication\n')


def load_tests(loader, standard, pattern):
    standard.addTests(loader.loadTestsFromTestCase(old_tests.PublicationTests))
    return standard


if __name__ == '__main__':
    unittest.main()
