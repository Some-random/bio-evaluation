"""Freeze two node-local monitors and one CPU-only combined observer.

This helper creates plans only; it never launches a process or queries an API.
"""
import argparse
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
PARENT = ROOT / '.local/shared_vllm_migration_2026-10-17/amendment_v2.json'

def read(path): return json.loads(Path(path).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(path): return {'path': str(path), 'sha256': sha(path)}
def save(path, value):
    if path.exists():
        if read(path) != value: raise ValueError('Existing frozen health plan differs: ' + str(path))
        return
    with path.open('x') as f: json.dump(value, f, ensure_ascii=False, indent=2); f.write('\n')

def prepare(*, check_only=False):
    rows = [('existing_pool', BASE / 'existing_upgrade', BASE / 'amendment_existing_pool.json'),
            ('new_pool', BASE, BASE / 'amendment_new_pool.json')]
    required = [BASE / 'handoff_manifest.json', BASE / 'drain_receipt.json', PARENT,
                BASE / 'watch_shared_vllm_health.py', BASE / 'watch_combined_health.py']
    for _, pool, amendment in rows: required += [amendment, pool / 'saturation_serving_plan.json', pool / 'saturation_endpoints.json']
    missing = [str(p) for p in required if not p.is_file()]
    if missing: return {'ready': False, 'missing': missing, 'processes_launched': False}
    manifest = read(BASE / 'handoff_manifest.json'); drain = read(BASE / 'drain_receipt.json'); parent = read(PARENT)
    if not drain.get('all_original_http_calls_finished') or drain['parent_amendment_sha256'] != sha(PARENT): raise ValueError('A pinned clean parent drain is required')
    prior = {r['run_id']: r for r in drain['runs']}
    if len(prior) != len(drain['runs']) or set(prior) != set(parent['run_ids']): raise ValueError('Drain scopes overlap or omit original runs')
    if sum(r['statuses'].get('completed', 0) for r in prior.values()) != drain['saved_responses'] or drain['saved_responses'] != 15749: raise ValueError('Clean-pause saved baseline changed')
    expected = {rid for rid, r in prior.items() if r['statuses'].get('completed', 0) < r['planned']}
    host_manifest = {g['name']: g for g in manifest['groups']}; seen = set(); groups = []; health_plans = []
    for name, pool, amendment_path in rows:
        amendment = read(amendment_path); selected = set(amendment['run_ids'])
        if selected & seen or selected != {r['run_id'] for r in host_manifest[name]['runs']}: raise ValueError('Host generation scopes overlap or differ from the handoff')
        if host_manifest[name]['amendment_sha256'] != sha(amendment_path): raise ValueError('The exact host amendment changed')
        seen |= selected
        health = {'schema_version': 1, 'root': str(ROOT), 'pool_directory': str(pool),
                  'pool_plan_filename': 'saturation_serving_plan.json', 'pool_plan_sha256': sha(pool / 'saturation_serving_plan.json'),
                  'pool_status_filename': 'serving_status.json', 'endpoints_file': str(pool / 'saturation_endpoints.json'),
                  'endpoints_sha256': sha(pool / 'saturation_endpoints.json'), 'amendment_path': str(amendment_path), 'amendment_sha256': sha(amendment_path),
                  'code_files_sha256': {str(BASE / 'watch_shared_vllm_health.py'): sha(BASE / 'watch_shared_vllm_health.py')},
                  'state_file': str(pool / 'health_state.json'), 'public_output_file': str(pool / 'health_public.json'),
                  'interval_seconds': 60, 'thresholds': {'high_kv_fraction': .95, 'stall_seconds': 600,
                   'minimum_responses_for_format_warning': 20, 'high_truncation_fraction': .5}}
        path = pool / 'health_plan.json'; health_plans.append((path, health))
        scopes = []
        for r in host_manifest[name]['runs']:
            d = prior[r['run_id']]; initial = d['planned'] - r['remaining_cases']
            if initial != d['statuses'].get('completed', 0): raise ValueError('Manifest initial saved count differs from the exact clean-drain case count')
            scopes.append({'run_id': r['run_id'], 'task_id': r['task_id'], 'planned': d['planned'], 'initial_saved': initial})
        groups.append({'name': name, 'replicas': 4, 'report_file': health['public_output_file'], 'health_plan_file': str(path),
                       'health_plan_sha256': hashlib.sha256((json.dumps(health, ensure_ascii=False, indent=2) + '\n').encode()).hexdigest(), 'runs': scopes})
    if seen != expected or len(seen) != 37: raise ValueError('Only the37 unfinished logical runs may contribute new responses')
    remaining = sum(s['planned'] - s['initial_saved'] for g in groups for s in g['runs'])
    baseline = {'global_planned': 83690, 'global_saved_at_clean_pause': 53869, 'remaining_at_clean_pause': 29821,
                'pre_original_pool_saved': 41580, 'original_pool_new_responses': 12289, 'original_scope_retained_baseline': 3460,
                'original_scope_saved_including_retained': 15749, 'already_completed_scope_case_count': 593,
                'clean_pause_at_utc': drain['created_at_utc'], 'counts_are_saved_responses_not_completed_benchmark_metrics': True}
    if (remaining != baseline['remaining_at_clean_pause']
            or baseline['pre_original_pool_saved'] + drain['saved_responses'] - baseline['original_scope_retained_baseline'] != baseline['global_saved_at_clean_pause']):
        raise ValueError('Global and selected clean-pause arithmetic differ')
    sources = [BASE / 'handoff_manifest.json', BASE / 'drain_receipt.json', PARENT, BASE / 'watch_combined_health.py']
    plan = {'schema_version': 1, 'interval_seconds': 60, 'maximum_report_age_seconds': 180, 'project_gpu_count': 8,
            'baseline': baseline, 'groups': groups, 'pinned_sources': [pin(p) for p in sources],
            'output_file': str(BASE / 'combined_health.json'), 'history_file': str(BASE / 'combined_health_history.jsonl')}
    output = BASE / 'combined_health_plan.json'
    if not check_only:
        for p, health in health_plans: save(p, health)
        for g in groups:
            if sha(g['health_plan_file']) != g['health_plan_sha256']: raise ValueError('Generated health-plan byte pin differs')
        save(output, plan)
    return {'ready': True, 'check_only': check_only, 'health_plans': [str(p) for p, _ in health_plans],
            'combined_plan': str(output), 'selected_runs': len(seen), 'selected_initial_saved': sum(s['initial_saved'] for g in groups for s in g['runs']),
            'remaining': remaining, 'processes_launched': False}

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('--check-only', action='store_true')
    print(json.dumps(prepare(check_only=p.parse_args().check_only), indent=2))
