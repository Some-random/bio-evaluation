"""Filesystem/mock tests only; no operating-system signal is sent."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('startup_cpu_recovery', Path(__file__).with_name('recover_existing_pool_cpu.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class RecoveryTests(unittest.TestCase):
    def test_dead_api_live_engine_is_pinned_by_owned_group_step_and_ticks(self):
        with tempfile.TemporaryDirectory() as temporary:
            proc_root = Path(temporary)
            worker = proc_root / '88'
            worker.mkdir()
            fields = ['S', '1', '77', '77'] + ['0'] * 15 + ['123456']
            (worker / 'stat').write_text('88 (synthetic orphan EngineCore) ' + ' '.join(fields))
            (worker / 'cgroup').write_text('job_240418/step_28')
            captured = []
            helper = SimpleNamespace(PinnedProcess=lambda record: captured.append(record) or SimpleNamespace(close=lambda: None))
            handles = m.startup_group_members(helper, {77}, set(), 'job_240418/step_28', proc_root)
            self.assertEqual(captured, [{'pid': 88, 'ticks': '123456'}])
            self.assertEqual(len(handles), 1)
            (worker / 'cgroup').write_text('unrelated_job/step_1')
            with self.assertRaisesRegex(RuntimeError, 'outside its pinned Slurm'):
                m.startup_group_members(helper, {77}, set(), 'job_240418/step_28', proc_root)

    def helper(self):
        def sha(path):
            return hashlib.sha256(path.read_bytes()).hexdigest()
        def write(path, value):
            path.write_text(json.dumps(value))
        return SimpleNamespace(sha=sha, write=write)

    def test_retirement_preserves_runtime_plan_and_exact_startup_evidence(self):
        with tempfile.TemporaryDirectory() as temporary:
            d = Path(temporary)
            for name in ('runtime_ready.json', 'saturation_serving_plan.json', 'serving_status.json', 'saturation_gpu_telemetry.csv'):
                (d / name).write_text('exact original ' + name)
            replica = d / 'saturation_replica_0'
            replica.mkdir()
            (replica / 'server.log').write_text('exact original startup log\n')
            before = {str(p.relative_to(d)): self.helper().sha(p) for p in d.rglob('*') if p.is_file()}
            retired = m.retire_startup(d, self.helper())
            for name, digest in before.items():
                target = d / name if name in ('runtime_ready.json', 'saturation_serving_plan.json') else retired / name
                self.assertEqual(self.helper().sha(target), digest)
            self.assertFalse((d / 'serving_status.json').exists())
            self.assertTrue((retired / 'retirement_receipt.json').exists())

    def test_any_dispatch_gate_prevents_startup_retirement(self):
        with tempfile.TemporaryDirectory() as temporary:
            d = Path(temporary)
            (d / 'saturation_dispatch.json').write_text('{}')
            with self.assertRaisesRegex(RuntimeError, 'before dispatch'):
                m.retire_startup(d, self.helper())
            self.assertFalse((d / 'retired_startup_one_cpu').exists())

    def test_existing_retired_attempt_cannot_be_overwritten(self):
        with tempfile.TemporaryDirectory() as temporary:
            d = Path(temporary)
            (d / 'retired_startup_one_cpu').mkdir()
            with self.assertRaisesRegex(RuntimeError, 'already retired'):
                m.retire_startup(d, self.helper())

    def test_gpu_quiescence_ignores_other_allocations(self):
        with patch.object(m.subprocess, 'check_output', return_value='11, GPU-owned\n12, GPU-other\n'):
            self.assertEqual(m.gpu_contexts({'GPU-owned'}), ['11, GPU-owned'])


if __name__ == '__main__':
    unittest.main()
