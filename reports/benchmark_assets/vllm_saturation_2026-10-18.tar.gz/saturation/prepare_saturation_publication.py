"""Prepare closed synthetic evidence and an explicit report manifest; never push."""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
from zoneinfo import ZoneInfo

PACIFIC = ZoneInfo("America/Los_Angeles")
EXPECTED_PROFILES = {(192, 1024), (7000, 1024), (45056, 1024), (1536, 4096)}
ROOT_METADATA = (
    "saturation_serving_plan.json", "saturation_execution_environment.json", "saturation_endpoints.json",
    "saturation_benchmark_summary.json", "queue_policy.json", "drain_receipt.json",
    "handoff_assignment.json", "amendment_new_pool.json", "amendment_existing_pool.json", "handoff_manifest.json",
    "benchmarks_passed.json", "saturation_dispatch.json", "launch_request.json", "runtime_ready.json",
    "existing_pool_handoff.json", "cpu_startup_force_stop_receipt.json", "cpu_startup_recovery.json",
    "resource_startup_recovery_v2.json", "resource_startup_force_stop_v2_receipt.json",
    "resource_startup_recovery_ready_v2.json", "resource_startup_runtime_verification_v2.json",
    "deployment_status.json", "health_plan.json", "combined_health_plan.json", "preflight_execution_note.json",
)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


def read(path):
    return json.loads(Path(path).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return digest(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def write(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".pending")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def at(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def pacific(value):
    return at(value).astimezone(PACIFIC).strftime("%Y-%m-%d %H:%M:%S %Z")


def counter(stage, side, name):
    values = [value for key, value in stage[side]["selected"].items() if key.split("{", 1)[0] == name]
    if not values:
        raise ValueError("Missing measurement counter: " + name)
    return sum(values)


def collect(pool):
    summary = read(pool / "saturation_benchmark_summary.json")
    if summary.get("success") is not True or len(summary.get("results", [])) != 4:
        raise ValueError("All four synthetic sweeps must close successfully")
    rows, attempts = [], []
    for result in summary["results"]:
        directory = Path(result["results_file"]).resolve().parent
        if not directory.is_relative_to(pool) or result["returncode"] != 0:
            raise ValueError("Unexpected synthetic result scope or exit code")
        progress, measured = read(directory / "progress.json"), read(directory / "results.json")
        config = measured["config"]
        if progress.get("state") != "completed" or measured["config"] != read(directory / "config.json"):
            raise ValueError("Synthetic evidence is still open or its configuration differs")
        if (config.get("synthetic_only") is not True or config.get("prefix_cache_policy") != "reset-between-levels"
                or {s["concurrency"] for s in measured["stages"]} != set(config["concurrency_levels"])):
            raise ValueError("Incomplete or changed fixed synthetic workload")
        attempts.append({"directory": directory.relative_to(pool).as_posix(), "state": "completed",
                         "endpoint_id": result["endpoint_id"], "finished_at_pacific": pacific(measured["finished_at"]),
                         "config": config})
        for stage in measured["stages"]:
            if (stage["completed_requests"] != config["requests"] or stage["failed_requests"] != 0
                    or stage["fixed_workload_mismatch_requests"] != 0 or stage["comparable_fixed_workload"] is not True):
                raise ValueError("A measured point has incomplete, failed or unequal token work")
            prompt = config["requests"] * config["input_tokens"]
            completion = config["requests"] * config["output_tokens"]
            if stage["actual_prompt_tokens"] != prompt or stage["actual_completion_tokens"] != completion:
                raise ValueError("Actual usage does not equal the prescribed synthetic work")
            for name, expected in (("vllm:prompt_tokens_total", prompt), ("vllm:generation_tokens_total", completion)):
                if counter(stage, "metrics_after", name) - counter(stage, "metrics_before", name) != expected:
                    raise ValueError("Server token counters include missing or unrelated work")
            for side in ("metrics_before", "metrics_after"):
                for name in ("vllm:num_requests_running", "vllm:num_requests_waiting"):
                    if counter(stage, side, name) != 0:
                        raise ValueError("Synthetic timing boundaries are not idle")
            stage_dir = directory / stage["stage"]
            requests, responses = sorted(stage_dir.glob("request_*.json")), sorted(stage_dir.glob("response_*.json"))
            if len(requests) != config["requests"] or len(responses) != config["requests"]:
                raise ValueError("Saved synthetic request/response count differs from the summary")
            for index in range(config["requests"]):
                request = read(stage_dir / f"request_{index:05d}.json")
                response = read(stage_dir / f"response_{index:05d}.json")
                if (response.get("request_sha256") != canonical(request) or response.get("success") is not True
                        or response.get("prompt_tokens") != config["input_tokens"]
                        or response.get("completion_tokens") != config["output_tokens"]
                        or request.get("max_tokens") != config["output_tokens"] or request.get("ignore_eos") is not True
                        or len(request.get("prompt", [])) != config["input_tokens"]
                        or response.get("response", {}).get("model") != config["model"]):
                    raise ValueError("Saved synthetic raw data violates the exact request/token contract")
            rows.append({"directory": directory.relative_to(pool).as_posix(), "endpoint_id": result["endpoint_id"],
                         "stage": stage["stage"], "input_tokens": config["input_tokens"], "output_tokens": config["output_tokens"],
                         "requests": config["requests"], "concurrency": stage["concurrency"],
                         "output_tokens_per_second": stage["output_tokens_per_second"],
                         "elapsed_seconds": stage["elapsed_seconds"], "latency_seconds": stage["latency_seconds"],
                         "failures": 0, "token_mismatches": 0, "preemption_delta":
                         counter(stage, "metrics_after", "vllm:num_preemptions_total") - counter(stage, "metrics_before", "vllm:num_preemptions_total"),
                         "actual_prompt_tokens": prompt, "actual_completion_tokens": completion,
                         "measurement_started_at_pacific": pacific(stage["metrics_before"]["captured_at"]),
                         "finished_at_pacific": pacific(stage["finished_at"]),
                         "metrics_window": {"start": stage["metrics_before"]["captured_at"],
                                            "end": stage["metrics_after"]["captured_at"]},
                         "sampling": config["sampling"], "all_raw_and_server_token_counts_verified": True})
    if {(r["input_tokens"], r["output_tokens"]) for r in rows} != EXPECTED_PROFILES:
        raise ValueError("The closed sweeps do not cover the four reviewed synthetic profiles")
    return attempts, rows


def metrics_snapshot(pool, rows):
    """Copy only fully closed timing windows from the append-only observer."""
    source = pool / "benchmark_metrics.jsonl"
    records = []
    for line in source.read_bytes().splitlines(keepends=True):
        if not line.endswith(b"\n"):
            continue
        value = json.loads(line); observed = at(value["at_utc"])
        if any(at(r["metrics_window"]["start"]) <= observed <= at(r["metrics_window"]["end"]) for r in rows):
            records.append((line, value))
    for row in rows:
        samples = [e["metrics"] for unused, record in records
                   if at(row["metrics_window"]["start"]) <= at(record["at_utc"]) <= at(row["metrics_window"]["end"])
                   for e in record["endpoints"] if e["endpoint_id"] == row["endpoint_id"]]
        row["sampled_peak_kv_fraction"] = max((s["vllm:kv_cache_usage_perc"] for s in samples), default=None)
        row["queue_samples"] = len(samples)
        if any(s["vllm:num_requests_running"] + s["vllm:num_requests_waiting"] > row["concurrency"] for s in samples):
            raise ValueError("Observed queues exceed the measured client's bounded work")
    return b"".join(line for line, unused in records)


def archive_sources(root, pool, attempts, rows):
    files, source_pins = {}, {}
    def add(path, member=None, expected=None):
        source = Path(path)
        if source.is_symlink() or not source.resolve().is_relative_to(root) or not source.is_file():
            raise ValueError("Archive sources must be regular owned files")
        before = source.stat(); data = source.read_bytes(); after = source.stat()
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise ValueError("An evidence source changed while it was read")
        observed = digest(data)
        if expected is not None and expected != observed:
            raise ValueError("A frozen archive source changed: " + source.name)
        relative = source.relative_to(pool).as_posix() if source.is_relative_to(pool) else None
        name = member or ("saturation/" + relative)
        if name in files and files[name] != data:
            raise ValueError("Two different archive sources share one member path")
        files[name] = data; source_pins[str(source.relative_to(root))] = observed
    for source in sorted(pool.glob("*.py")) + sorted(pool.glob("*.sbatch")):
        add(source)
    for name in ROOT_METADATA:
        if (pool / name).is_file():add(pool / name)
    for source in sorted((pool / "release_evidence").glob("*.json")):
        add(source)
    for base in (pool, pool / "existing_upgrade"):
        for name in ("saturation_serving_plan.json", "saturation_execution_environment.json", "saturation_endpoints.json",
                     "benchmarks_passed.json", "saturation_dispatch.json", "prepare_runtime.py", "runtime_ready.json", "health_plan.json"):
            if (base / name).is_file():add(base / name)
        plan = base / "saturation_serving_plan.json"
        if plan.is_file():
            for path, expected in read(plan)["code_sha256"].items():
                source = Path(path)
                add(source, None if source.is_relative_to(pool) else "dependencies/runtime_common.py", expected)
        inventory = base / "saturation_endpoints.json"
        if inventory.is_file():
            for endpoint in read(inventory):
                add(endpoint["server_identity_file"], expected=endpoint["server_identity_sha256"])
                checks = Path(endpoint["server_identity_file"]).with_name("synthetic_serving_checks.json")
                if checks.is_file():add(checks)
    for source in (root / "scripts/benchmark_vllm_concurrency.py", root / "scripts/shared_vllm_resume.py",
                   root / "scripts/shared_vllm_scoring.py", root / "scripts/daily_backup.py",
                   root / "tests/test_shared_vllm_resume.py", root / "scripts/prepare_shared_vllm_publication.py"):
        add(source, "dependencies/" + source.relative_to(root).as_posix())
    for attempt in attempts:
        directory = pool / attempt["directory"]; before = digest((directory / "progress.json").read_bytes())
        if read(directory / "progress.json").get("state") != "completed":raise ValueError("A benchmark reopened")
        for source in sorted(directory.rglob("*")):
            if source.is_symlink():raise ValueError("Synthetic evidence contains a symlink")
            if source.is_file():
                if source.suffix not in {".json", ".jsonl", ".prom"}:raise ValueError("Unexpected synthetic evidence file")
                add(source)
        if digest((directory / "progress.json").read_bytes()) != before:raise ValueError("A closed benchmark changed")
    for retired in sorted((pool / "existing_upgrade").glob("retired_startup_*")):
        if not retired.is_dir():continue
        receipt = read(retired / "retirement_receipt.json"); add(retired / "retirement_receipt.json")
        for name, expected in receipt["files_sha256"].items():add(retired / name, expected=expected)
    if (pool / "slurm-240931.log").is_file():add(pool / "slurm-240931.log")
    snapshot = metrics_snapshot(pool, rows)
    files["saturation/closed_benchmark_metrics_snapshot.jsonl"] = snapshot
    files["saturation/closed_benchmark_metrics_snapshot_provenance.json"] = (
        json.dumps({"source": "benchmark_metrics.jsonl", "scope": "Only fully closed synthetic measurement windows",
                    "snapshot_sha256": digest(snapshot), "live_append_log_included": False}, indent=2) + "\n").encode()
    return files, source_pins


def markdown(report):
    policy = report.get("queue_policy")
    status = report["deployment_status"]
    rows = report["measurements"]["rows"]
    by = {(r["input_tokens"], r["output_tokens"], r["concurrency"]): r for r in rows}
    short_gain = by[(192, 1024, 64)]["output_tokens_per_second"] / by[(192, 1024, 32)]["output_tokens_per_second"] - 1
    long_change = by[(1536, 4096, 64)]["output_tokens_per_second"] / by[(1536, 4096, 32)]["output_tokens_per_second"] - 1
    description = status["description"]
    if status.get("native_generation_started"):
        observed = pacific(status["snapshot_at_pacific"])
        description = (f"At {observed}, all {status['active_native_replicas']} replicas were processing unchanged native evaluation requests. "
                       "Each GPU had 64 bounded HTTP requests feeding its 128-sequence engine. Per-host health, combined progress and native CPU scoring watches were active.")
        progress = status.get("combined_progress", {})
        if progress.get("current_counts_verified"):
            description += (f" The snapshot recorded {progress['global_saved_responses']:,} saved responses and {progress['global_remaining_cases']:,} remaining task-cases across the original 83,690-case scope. "
                            "Saved responses are generation progress, not completed benchmark metrics.")
    lines = ["# Eight-GPU vLLM throughput upgrade", "", "Prepared " + report["prepared_at_pacific"] + ". All human-readable times use Pacific time.", "",
             f"On the 192-input/1,024-output synthetic workload, concurrency 64 reached **1,026.2 output tokens/s per GPU**, {short_gain:.1%} above concurrency 32. Concurrency 128 was slower. On the 1,536-input/**4,096-output** workload, concurrency 32 reached **605.8 tokens/s**, while concurrency 64 was {abs(long_change):.1%} slower. More concurrency did not improve every workload.", "",
             "Deployment snapshot: " + description, "",
             "The target pool has eight NVIDIA A100-SXM4-80GB GPUs across ampere3 and ampere5, with one complete model replica per GPU. The model remains **Qwen3.8-27B, original BF16**, revision `" + report["revision"] + "`, with tensor parallel size 1. Serving changes preserve the frozen prompts, sampling settings, native scorers and **4,096-token evaluation output budget**.", "",
             "| Setting | Original four-GPU pool | Upgraded profile |", "|---|---|---|",
             "| vLLM | 0.31.0 | 0.32.0 |", "| Engine sequence capacity/GPU | 32 | 128 |",
             "| GPU memory budget | 90% | 95% |", "| Batched token budget | Original resolved configuration | 8,192 |",
             "| Context capacity | 65,536 tokens | 65,536 tokens |",
             "| Admission | Static length-weighted fractions | Bounded native vLLM queue |",
             "| Task choice | A long selected request could block short admissions | Round robin across tasks, then runs |", "",
             ((f"The reviewed HTTP queue cap is **{policy['queue_limit']} per replica**, pinned separately from the engine's 128-sequence capacity. This selects the measured short-input peak while keeping the complete-output tradeoff above visible. A deep mixed-work queue lets vLLM admit requests according to actual cache capacity; its rescheduling cost is included in the measured throughput.")
              if policy else "The final HTTP queue cap is awaiting the reviewed policy file; the engine capacity 128 is distinct from that client limit."), "",
             "## Closed synthetic measurements", "",
             "Each profile ran on one dedicated replica. Request totals and exact token-ID prompts stayed fixed across that profile's ascending concurrency sweep. Every timed request generated the prescribed output length, with temperature 1, top_p 0.95, top_k 20, seed 42 and ignore_eos. Prefix caches were reset between levels; separate warmup used 64 output tokens.", "",
             "| Input / output tokens | Requests/level | Concurrency | Output tokens/s | p50 / p95 latency (s) | Preemptions | Sampled peak KV |",
             "|---:|---:|---:|---:|---:|---:|---:|"]
    for row in sorted(rows, key=lambda r: (r["input_tokens"], r["output_tokens"], r["concurrency"])):
        latency = row["latency_seconds"]; peak = row.get("sampled_peak_kv_fraction")
        lines.append(f"| {row['input_tokens']:,} / {row['output_tokens']:,} | {row['requests']} | {row['concurrency']} | {row['output_tokens_per_second']:.1f} | {latency['p50']:.1f} / {latency['p95']:.1f} | {row['preemption_delta']:.0f} | {peak:.1%} |" if peak is not None else
                     f"| {row['input_tokens']:,} / {row['output_tokens']:,} | {row['requests']} | {row['concurrency']} | {row['output_tokens_per_second']:.1f} | {latency['p50']:.1f} / {latency['p95']:.1f} | {row['preemption_delta']:.0f} | unavailable |")
    lines += ["", f"All {sum(r['requests'] for r in rows):,} timed requests across {len(rows)} points closed with zero failed requests and zero prompt/output token mismatches. Saved request hashes, raw usage and server token-counter deltas agree; engine queues were idle at timing boundaries. Preemptions are cache-driven rescheduling/recomputation events, and are reported even when every request succeeds. KV peaks are sampled and may miss brief peaks.", "",
              "The 7,000-token input profile was nearly flat: 230.0, 232.2 and 230.8 output tokens/s at concurrency 16, 32 and 64. The 45,056-token profile reached 43.5, 47.1 and 47.1 at concurrency 4, 8 and 16. Its larger two queues produced essentially equal throughput with different latency.", "",
              "These are custom stdlib harness measurements using the completions API and forced decode lengths. They do not reproduce native chat/thinking prompts, biological answer lengths or shared-prefix patterns. One ascending sweep does not establish a robust optimum. The previous runtime, memory fraction, scheduling and batch settings changed together, so these results do not isolate a vLLM-version speedup or establish a full-suite speedup/ETA. [Earlier measurements](SHARED_VLLM_EXECUTION_2026-10-17.md).", "",
              "## Runtime and handoff record", "",
              "vLLM 0.32.0 was released on October 17 at 11:50 PM PDT. Its Qwen M-RoPE change reduces memory used by positional caches. The release also changes context/output-limit handling, while this adapter retains the original requirement that prompt plus the full 4,096-token budget fits 65,536. [Official release](https://github.com/vllm-project/vllm/releases/tag/v0.32.0), [Qwen cache change](https://github.com/vllm-project/vllm/pull/59853), [context-limit change](https://github.com/vllm-project/vllm/pull/57035).", "",
              "The installed stack reports Python 3.12.15, PyTorch 2.13.0/CUDA 13.0, Transformers 5.17.0, Triton 3.7.1 and FlashInfer 0.7.0.post1. Release/package metadata and actual serving identities are archived. [PyPI metadata](https://pypi.org/pypi/vllm/0.32.0/json).", "",
              "The original dispatcher drained all active HTTP calls and saved their responses before retiring its servers. Closed parent markers, raw files and previous partial score history remain immutable. One staged assignment gives the hosts disjoint whole-run scopes, so a ready host can resume while the other starts. Four independent run preparations validate concurrently under all original run and endpoint locks; any failed preparation blocks every new model request.", "",
              "New sidecars, segments, dispatch receipts and completion markers pin the parent checkpoint, exact adapter and serving identity. A clean pause writes a pause record without a full terminal generation marker. Native scoring retains the full benchmark denominator and waits for the new terminal proof; health monitoring reads metrics/response metadata without generating or scoring. The uploader preserves old and new namespaces, including the three immutable P08 partial-score forks.", "",
              "An earlier bootstrap failed before serving. The original host's first upgrade startup inherited one physical CPU, and its next 32-CPU startup still inherited an 8 GiB RAM limit. Both were startup failures before biological inference and remain preserved separately. The replacement requests 32 CPUs and 320 GiB RAM explicitly. Recovery receipts and closed failed-startup evidence remain in the archive. The generation cap stays 4,096; answer truncation remains a quality limitation rather than an infrastructure setting silently changed here.", "",
              "[Machine-readable report](VLLM_SATURATION_UPGRADE_2026-10-18.json) · [Code, plans and raw synthetic evidence](benchmark_assets/vllm_saturation_2026-10-18.tar.gz). The archive contains a SHA256 inventory and passed the existing recursive credential scanner. Runtime environments, caches, weights, live append logs and credentials are excluded.", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--pool-directory", type=Path, required=True)
    parser.add_argument("--baseline-commit", required=True)
    parser.add_argument("--deployment-status", type=Path)
    parser.add_argument("--publication-manifest", type=Path, required=True)
    args = parser.parse_args()
    root, pool = args.root.resolve(), args.pool_directory.resolve()
    if not pool.is_relative_to(root) or len(args.baseline_commit) != 40 or any(c not in "0123456789abcdef" for c in args.baseline_commit):
        raise ValueError("Owned pool and reviewed latest-remote commit required")
    helper = load_module("old_public_evidence_helper", root / "scripts/prepare_shared_vllm_publication.py")
    scanner = load_module("saturation_credential_scanner", root / "scripts/daily_backup.py")
    attempts, rows = collect(pool)
    files, pins = archive_sources(root, pool, attempts, rows)
    archive_path = root / "reports/benchmark_assets/vllm_saturation_2026-10-18.tar.gz"
    archive = helper.build_archive(archive_path, files, scanner)
    status = {"phase": "synthetic_complete_original_host_upgrade_in_progress", "native_generation_started": False,
              "active_native_replicas": 0,
              "description": "All four new replicas completed synthetic checks. The original four are restarting with 32 CPUs and 320 GiB RAM; biological dispatch has not yet been confirmed for this report."}
    if args.deployment_status:
        status = read(args.deployment_status)
        if (type(status.get("native_generation_started")) is not bool
                or type(status.get("active_native_replicas")) is not int
                or not 0 <= status["active_native_replicas"] <= 8 or not status.get("description")):
            raise ValueError("Final deployment status must state observed native activation and active replica count")
        status["source_file_sha256"] = digest(args.deployment_status.read_bytes())
    policy = read(pool / "queue_policy.json") if (pool / "queue_policy.json").is_file() else None
    report = {"schema_version": 1, "prepared_at_pacific": datetime.now(PACIFIC).strftime("%Y-%m-%d %H:%M:%S %Z"),
              "time_zone": "America/Los_Angeles", "deployment_status": status,
              "model": "Qwen/Qwen3.8-27B", "revision": "1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0",
              "checkpoint_precision": "original BF16", "allocated_gpu_count": 8, "gpu_type": "NVIDIA A100-SXM4-80GB",
              "allocation_layout": [{"job_id": "240418", "hostname": "ampere3", "gpu_count": 4},
                                    {"job_id": "240936", "hostname": "ampere5", "gpu_count": 4}],
              "serving_profile": {"vllm": "0.32.0", "tensor_parallel_size": 1, "max_num_seqs": 128,
                                  "gpu_memory_utilization": .95, "max_num_batched_tokens": 8192, "max_model_len": 65536},
              "native_max_output_tokens": 4096, "scientific_protocol_changes": [], "queue_policy": policy,
              "measurements": {"stage": "all_four_sweeps_closed_and_verified", "attempts": attempts, "rows": rows,
                               "timed_requests": sum(r["requests"] for r in rows),
                               "single_ascending_sweep": True, "within_profile_fixed_work": True,
                               "biological_accuracy_measured": False, "version_isolated_speedup": None,
                               "full_suite_speedup_or_eta": None},
              "archive": {"path": str(archive_path.relative_to(root)), **{k: v for k, v in archive.items() if k != "members"}},
              "frozen_source_files_sha256": pins,
              "ready_for_publication": status["native_generation_started"],
              "publication_excludes": ["runtime environments", "caches", "model weights", "live append logs", "credentials"],
              "inference_scoring_or_publication_performed_by_preparation": False}
    prefix = root / "reports/VLLM_SATURATION_UPGRADE_2026-10-18"
    write(prefix.with_suffix(".json"), report); prefix.with_suffix(".md").write_text(markdown(report))
    paths = [str(prefix.with_suffix(ext).relative_to(root)) for ext in (".md", ".json")] + [str(archive_path.relative_to(root))]
    for path in paths:scanner.scan_file(root / path)
    write(args.publication_manifest, {"baseline_commit": args.baseline_commit, "files": sorted(paths),
          "message": "Record vLLM 0.32 saturation measurements and provenance-preserving eight-GPU upgrade",
          "source_sha256": {path: digest((root / path).read_bytes()) for path in paths},
          "ready_for_publication": report["ready_for_publication"], "prepared_at_pacific": report["prepared_at_pacific"],
          "publication_method": "Existing scoped publisher under the shared publication lock; fetch/fast-forward before staging, explicit paths, upstream baseline protection; root confirms final deployment status and publishes.",
          "code_location": "All new versioned sources/tests/plans and original dependencies are inventoried inside the evidence archive."})
    print(json.dumps({"report": str(prefix.with_suffix(".md")), "archive": str(archive_path),
                      "archive_sha256": report["archive"]["sha256"], "archive_members": report["archive"]["member_count"],
                      "measured_points": len(rows), "ready_for_publication": report["ready_for_publication"]}))


if __name__ == "__main__":
    main()
