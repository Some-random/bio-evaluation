"""Report acceptance requires closed, equal-work, independently matched counters."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('saturation_report_under_test',HERE/'prepare_saturation_publication.py')
r=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(r)


def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value))


class ReportTests(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        self.pool=Path(temp.name);results=[]
        for i,(inputs,outputs) in enumerate(sorted(r.EXPECTED_PROFILES)):
            directory=self.pool/str(i);stage='repeat_01_concurrency_001'
            config={'synthetic_only':True,'prefix_cache_policy':'reset-between-levels','concurrency_levels':[1],
                    'requests':1,'input_tokens':inputs,'output_tokens':outputs,'model':'synthetic-model','sampling':{}}
            before={'selected':{'vllm:prompt_tokens_total':0,'vllm:generation_tokens_total':0,
                               'vllm:num_preemptions_total':0,'vllm:num_requests_running':0,'vllm:num_requests_waiting':0},
                    'captured_at':'2026-10-18T11:00:00-07:00'}
            after=json.loads(json.dumps(before));after['selected'].update({'vllm:prompt_tokens_total':inputs,
                    'vllm:generation_tokens_total':outputs,'vllm:num_preemptions_total':i})
            after['captured_at']='2026-10-18T11:00:10-07:00'
            row={'stage':stage,'concurrency':1,'completed_requests':1,'failed_requests':0,
                 'fixed_workload_mismatch_requests':0,'comparable_fixed_workload':True,
                 'actual_prompt_tokens':inputs,'actual_completion_tokens':outputs,'metrics_before':before,'metrics_after':after,
                 'output_tokens_per_second':outputs/10,'elapsed_seconds':10,'latency_seconds':{'p50':10,'p95':10},
                 'finished_at':'2026-10-18T11:00:10-07:00'}
            write(directory/'config.json',config);write(directory/'progress.json',{'state':'completed'})
            write(directory/'results.json',{'config':config,'finished_at':row['finished_at'],'stages':[row]})
            request={'prompt':[1]*inputs,'max_tokens':outputs,'ignore_eos':True}
            write(directory/stage/'request_00000.json',request)
            write(directory/stage/'response_00000.json',{'request_sha256':r.canonical(request),'success':True,
                  'prompt_tokens':inputs,'completion_tokens':outputs,'response':{'model':'synthetic-model'}})
            results.append({'results_file':str(directory/'results.json'),'returncode':0,'endpoint_id':str(i)})
        write(self.pool/'saturation_benchmark_summary.json',{'success':True,'results':results})

    def test_preemption_is_reported_without_hiding_successful_measured_work(self):
        attempts,rows=r.collect(self.pool)
        self.assertEqual(len(attempts),4)
        self.assertEqual([v['preemption_delta'] for v in rows],[0,1,2,3])
        self.assertTrue(all(v['all_raw_and_server_token_counts_verified'] for v in rows))

    def test_results_file_does_not_make_an_open_sweep_terminal(self):
        write(self.pool/'0/progress.json',{'state':'running'})
        with self.assertRaisesRegex(ValueError,'still open'):r.collect(self.pool)

    def test_unrelated_server_tokens_invalidate_an_otherwise_successful_batch(self):
        path=self.pool/'0/results.json';value=r.read(path)
        value['stages'][0]['metrics_after']['selected']['vllm:generation_tokens_total']+=1
        write(path,value)
        with self.assertRaisesRegex(ValueError,'unrelated work'):r.collect(self.pool)


if __name__=='__main__':unittest.main()
