"""Prepare a fresh CPU-only runtime inside existing Slurm allocation 240418."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import time

ROOT = Path('/dfs/scratch0/dongweij/bio-evaluation')
HERE = Path(__file__).resolve().parent
COMMON = ROOT / '.local/shared_vllm_pool_2026-10-17_v3/runtime_common.py'
COMMON_SHA = '93611c2b597857222f6400bcf9151ce70ae7f8053c7871600bc49106e67370f4'
BASE = ROOT / '.local/litqa2_replay/runtime.tar'
BASE_SHA = '732def4d7a95da921b67dbfcc8bbf1e602218868b7ee40e3cc9990e059f92893'
OLD_RUNTIME = Path('/tmp/bio-shared-240418-2hqsuN')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''): h.update(b)
    return h.hexdigest()

def write(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n'); tmp.chmod(0o600); tmp.replace(path)

def main():
    if os.environ.get('SLURM_JOB_ID') != '240418' or not socket.gethostname().startswith('ampere3'):
        raise RuntimeError('Preparation is confined to the authorized existing ampere3 allocation')
    if HERE.joinpath('runtime_ready.json').exists(): raise RuntimeError('A ready runtime already exists; refusing another extraction')
    if sha(COMMON) != COMMON_SHA: raise RuntimeError('Frozen overlay helper changed')
    space = shutil.disk_usage('/tmp')
    if space.free < 40 * 1024**3: raise RuntimeError('Less than 40GiB free node-local space')
    runtime = Path(tempfile.mkdtemp(prefix='bio-saturation-240418-', dir='/tmp')).resolve()
    if runtime == OLD_RUNTIME or not OLD_RUNTIME.is_dir(): raise RuntimeError('The original serving runtime must remain distinct and present')
    state = {'stage': 'verifying_base_archive', 'runtime_directory': str(runtime), 'job_id': '240418',
             'hostname': socket.gethostname(), 'cpu_limit': 2, 'gpu_access_enabled': False,
             'old_runtime_untouched': str(OLD_RUNTIME), 'base_archive_sha256': BASE_SHA,
             'initial_free_bytes': space.free, 'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    write(HERE / 'runtime_setup.json', state)
    try:
        if sha(BASE) != BASE_SHA: raise RuntimeError('Pinned base archive checksum mismatch')
        state['stage'] = 'extracting_fresh_base'; write(HERE / 'runtime_setup.json', state)
        subprocess.run(['tar', '-xf', str(BASE), '-C', str(runtime)], check=True)
        spec = importlib.util.spec_from_file_location('existing_upgrade_frozen_common', COMMON)
        common = importlib.util.module_from_spec(spec); spec.loader.exec_module(common)
        overlay = common.apply_overlay(runtime)
        env = common.environment(runtime)
        env.update(CUDA_VISIBLE_DEVICES='', OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2',
                   MAX_JOBS='2', PIP_NO_CACHE_DIR='1', PIP_PROGRESS_BAR='off')
        python = runtime / 'python/bin/python3.12'
        state.update(stage='installing_vllm_0.32.0', overlay_receipts=overlay); write(HERE / 'runtime_setup.json', state)
        with (HERE / 'install_vllm_0.32.0_240418.log').open('x') as log:
            subprocess.run([str(python), '-m', 'pip', 'install', '--index-url', 'https://pypi.org/simple', '--only-binary=:all:',
                            '--break-system-packages', '--upgrade', 'vllm==0.32.0', '--report', str(HERE / 'pip_install_report_240418.json')],
                           env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        state['stage'] = 'checking_dependencies'; write(HERE / 'runtime_setup.json', state)
        with (HERE / 'pip_check_240418.log').open('x') as log:
            subprocess.run([str(python), '-m', 'pip', 'check'], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        code = "import importlib.metadata as m,json,os,sys;print(json.dumps({'python':sys.version,'packages':{n:m.version(n) for n in ['vllm','torch','transformers','triton','flashinfer-python']},'cuda_visible_devices':os.environ.get('CUDA_VISIBLE_DEVICES')}))"
        versions = json.loads(subprocess.check_output([str(python), '-c', code], env=env, text=True))
        if versions['packages']['vllm'] != '0.32.0' or versions['cuda_visible_devices'] != '': raise RuntimeError('Incorrect runtime version or CPU-only preparation environment')
        state.update(stage='ready_for_reviewed_launcher', python=str(python), python_sha256=sha(python), packages=versions['packages'],
                     overlay_receipts=overlay, common_sha256=COMMON_SHA, pip_check_passed=True,
                     pip_install_report_sha256=sha(HERE / 'pip_install_report_240418.json'),
                     no_gpu_processes_or_inference_started=True, cleanup_scope=str(runtime / 'cache'),
                     cache_downloads_disabled=True, finished_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
        write(HERE / 'runtime_setup.json', state); write(HERE / 'runtime_ready.json', state)
        print(json.dumps({'stage': state['stage'], 'runtime_directory': str(runtime), 'python': str(python), 'vllm_version': '0.32.0'}, indent=2), flush=True)
    except BaseException as e:
        state.update(stage='preparation_failed_preserved', error_type=type(e).__name__)
        write(HERE / 'runtime_setup.json', state)
        raise

if __name__ == '__main__': main()
