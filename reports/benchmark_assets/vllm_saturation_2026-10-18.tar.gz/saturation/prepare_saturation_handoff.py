"""Freeze one immutable assignment, then each ready host's disjoint amendment."""
import argparse
import copy
from datetime import datetime
import hashlib
import json
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT=Path('/dfs/scratch0/dongweij/bio-evaluation')
DIRECTORY=ROOT/'.local/shared_vllm_saturation_2026-10-18'
PARENT=ROOT/'.local/shared_vllm_migration_2026-10-17/amendment_v2.json'
def read(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open('x') as f:json.dump(value,f,indent=2);f.write('\n')


def assignment(parent):
    """The second host must use the exact first host's frozen allocation."""
    path=DIRECTORY/'handoff_assignment.json'
    parent_pin={'path':str(PARENT),'sha256':sha(PARENT)}
    drain_pin={'path':str(DIRECTORY/'drain_receipt.json'),'sha256':sha(DIRECTORY/'drain_receipt.json')}
    if path.exists():
        value=read(path)
        if (value.get('schema_version')!=1 or value.get('kind')!='shared_vllm_handoff_assignment'
                or value.get('parent_amendment')!=parent_pin or value.get('drain_receipt')!=drain_pin):
            raise RuntimeError('The immutable assignment does not match the closed parent/drain')
        for name,expected in value['closed_source_files_sha256'].items():
            if sha(name)!=expected:raise RuntimeError('A closed assignment source changed')
        return value
    scopes={}
    source_pins={}
    for source in parent['source_plans']:
        if sha(source['path'])!=source['sha256']:raise RuntimeError('Frozen source plan changed')
        source_pins[source['path']]=source['sha256']
        plan=read(source['path'])
        for worker in plan['workers']:
            for entry in worker['entries']:
                if entry['run_id'] in parent['run_ids']:
                    if entry['run_id'] in scopes:raise RuntimeError('A parent run appears in two source plans')
                    scopes[entry['run_id']]=entry
    if set(scopes)!=set(parent['run_ids']):raise RuntimeError('Parent source plans omit selected runs')
    work=[]
    for run_id,entry in scopes.items():
        folder=Path(parent.get('continuation_run_directories',{}).get(run_id,(ROOT/entry['project_root']).resolve()/'results/runs'/run_id))
        completion=folder/'shared_vllm_generation_completion.json'
        done=read(completion);source_pins[str(completion)]=sha(completion)
        if done['planned']!=entry['case_count']:raise RuntimeError('Parent denominator changed')
        if (any(type(v) is not int or v<0 for v in done['statuses'].values())
                or sum(done['statuses'].values())!=entry['case_count']):
            raise RuntimeError('Parent terminal statuses do not cover its exact denominator')
        if done.get('statuses',{}).get('completed',0)==entry['case_count']:
            continue
        if any(k!='not_dispatched_after_error' and k!='completed' and v for k,v in done['statuses'].items()):
            raise RuntimeError('Ambiguous or failed parent calls must never be retried')
        count=entry['case_count']-done['statuses'].get('completed',0)
        context_pin=parent['run_context_checks'][run_id]
        if sha(context_pin['path'])!=context_pin['sha256']:raise RuntimeError('Frozen context report changed')
        source_pins[context_pin['path']]=context_pin['sha256']
        context=read(context_pin['path'])
        mean=sum(x['prompt_tokens'] for x in context['per_case'])/len(context['per_case'])
        work.append({'run_id':run_id,'task_id':entry['task_id'],'remaining_cases':count,
                     'input_only_cost_estimate':count*(4096+mean*.1)})
    groups=[[],[]];loads=[0.,0.];weights=[1.,1.]
    for item in sorted(work,key=lambda x:(-x['input_only_cost_estimate'],x['run_id'])):
        group=min(range(2),key=lambda i:loads[i]/weights[i])
        groups[group].append(item);loads[group]+=item['input_only_cost_estimate']
    if not all(groups):raise RuntimeError('Both allocated hosts require unfinished work')
    scope_sets=[{x['run_id'] for x in g} for g in groups]
    if scope_sets[0]&scope_sets[1] or set.union(*scope_sets)!={x['run_id'] for x in work}:
        raise RuntimeError('The two producer scopes overlap or omit remaining runs')
    value={'schema_version':1,'kind':'shared_vllm_handoff_assignment','parent_amendment':parent_pin,
           'drain_receipt':drain_pin,'closed_source_files_sha256':source_pins,
           'created_at_pacific':datetime.now(ZoneInfo('America/Los_Angeles')).isoformat(),
           'project_gpu_count':8,'groups':[],'scientific_protocol_changes':[],
           'balance_estimate_is_not_a_measured_throughput_claim':True}
    for index,name in enumerate(('existing_pool','new_pool')):
        value['groups'].append({'name':name,'run_ids':sorted(scope_sets[index]),'runs':groups[index],
                                'remaining_cases':sum(x['remaining_cases'] for x in groups[index])})
    save(path,value)
    return value


def endpoints_for(source,parent,policy,gpu_uuids):
    endpoints=[]
    for e in read(source):
        identity=read(e['server_identity_file'])
        if (sha(e['server_identity_file'])!=e['server_identity_sha256']
                or identity.get('vllm_version')!='0.32.0' or identity.get('max_num_seqs')!=policy['server_max_num_seqs']
                or identity.get('model')!=parent['model'] or identity.get('revision')!=parent['model_revision']
                or identity.get('dtype') not in {'bfloat16','bf16'} or identity.get('tensor_parallel_size')!=1):
            raise RuntimeError('Each upgraded endpoint must pin its actual vLLM0.32 BF16 TP1 identity')
        uuids=identity.get('gpu_uuids',[])
        if len(uuids)!=1 or uuids[0] in gpu_uuids:raise RuntimeError('The eight GPU identities must be disjoint')
        gpu_uuids.update(uuids)
        endpoints.append({**e,'max_num_seqs':identity['max_num_seqs'],'max_model_len':identity['max_model_len'],
                          'tensor_parallel_size':1,'queue_limit':policy['queue_limit'],'max_inflight':policy['queue_limit'],
                          'scheduler_policy':'vllm_native_bounded_queue'})
    if len(endpoints)!=4:raise RuntimeError('Each allocated host requires four upgraded endpoints')
    return endpoints


def main(host=None):
    parent=read(PARENT)
    drain=read(DIRECTORY/'drain_receipt.json')
    if not drain.get('all_original_http_calls_finished'):
        raise RuntimeError('A clean original producer drain is required')
    results=read(DIRECTORY/'saturation_benchmark_summary.json')
    if not results.get('success'):raise RuntimeError('Synthetic saturation sweeps have not passed')
    policy_path=DIRECTORY/'queue_policy.json'
    policy=read(policy_path)
    if (policy.get('schema_version')!=1 or policy.get('kind')!='shared_vllm_reviewed_queue_policy'
            or policy.get('reviewed') is not True or policy.get('scheduler_policy')!='vllm_native_bounded_queue'
            or type(policy.get('queue_limit')) is not int or not 1<=policy['queue_limit']<=512
            or policy.get('server_max_num_seqs')!=128
            or policy.get('benchmark_summary_sha256')!=sha(DIRECTORY/'saturation_benchmark_summary.json')
            or policy.get('scientific_protocol_changes')!=[] or not str(policy.get('rationale','')).strip()):
        raise RuntimeError('A reviewed queue policy must pin the completed synthetic sweep and unchanged protocols')
    policy_pin={'path':str(policy_path),'sha256':sha(policy_path)}
    frozen_assignment=assignment(parent)
    assignment_path=DIRECTORY/'handoff_assignment.json'
    assignment_pin={'path':str(assignment_path),'sha256':sha(assignment_path)}
    sources={'existing_pool':DIRECTORY/'existing_upgrade/saturation_endpoints.json',
             'new_pool':DIRECTORY/'saturation_endpoints.json'}
    requested=[host] if host is not None else list(sources)
    if any(name not in sources for name in requested):raise RuntimeError('Unknown handoff host')
    pins={str(DIRECTORY/name):sha(DIRECTORY/name) for name in (
        'shared_vllm_resume.py','run_shared_vllm_evaluations.py','native_queue_scheduler.py')}
    evidence=[{'path':str((DIRECTORY/'saturation_benchmark_summary.json').relative_to(ROOT)),
               'sha256':sha(DIRECTORY/'saturation_benchmark_summary.json')},
              {'path':str((DIRECTORY/'drain_receipt.json').relative_to(ROOT)),
               'sha256':sha(DIRECTORY/'drain_receipt.json')},
              {'path':str(policy_path.relative_to(ROOT)),'sha256':policy_pin['sha256']}]
    evidence.append({'path':str(assignment_path.relative_to(ROOT)),'sha256':assignment_pin['sha256']})
    for result in results['results']:
        p=Path(result['results_file']);evidence.append({'path':str(p.relative_to(ROOT)),'sha256':sha(p)})
    manifest={'created_at_pacific':frozen_assignment['created_at_pacific'],
              'project_gpu_count':8,'groups':[],'scientific_protocol_changes':[],
              'queue_policy':policy_pin,'queue_limit':policy['queue_limit'],'handoff_assignment':assignment_pin,
              'balance_estimate_is_not_a_measured_throughput_claim':True}
    proposed={};gpu_uuids=set()
    # Existing amendments are immutable and participate in cross-host identity
    # validation; the other host's not-yet-created endpoint inventory is unused.
    for group in frozen_assignment['groups']:
        name=group['name'];path=DIRECTORY/('amendment_'+name+'.json')
        if name not in requested and path.exists():
            previous=read(path)
            if (previous.get('handoff_assignment')!=assignment_pin or previous.get('queue_policy')!=policy_pin
                    or previous.get('adapter_files_sha256')!=pins or previous.get('run_ids')!=group['run_ids']
                    or previous.get('parent_amendment')!=frozen_assignment['parent_amendment']):
                raise RuntimeError('An existing immutable host amendment differs from the frozen assignment')
            # Recheck its exact pinned identity files without contacting servers.
            for e in previous['endpoints']:
                identity=read(e['server_identity_file'])
                if sha(e['server_identity_file'])!=e['server_identity_sha256']:
                    raise RuntimeError('An existing host identity changed')
                uuids=identity.get('gpu_uuids',[])
                if len(uuids)!=1 or uuids[0] in gpu_uuids:raise RuntimeError('The eight GPU identities must be disjoint')
                gpu_uuids.update(uuids)
    for group in frozen_assignment['groups']:
        name=group['name']
        if name not in requested:continue
        amendment=copy.deepcopy(parent)
        amendment.update(execution_variant='saturation_native_queue_v1',scheduler_policy='vllm_native_bounded_queue',
                         fairness='task_round_robin_then_run_round_robin',
                         transport_timeout_seconds=14400,parent_amendment={'path':str(PARENT),'sha256':sha(PARENT)},
                         run_ids=group['run_ids'],adapter_files_sha256=pins,
                         capacity_evidence_files=evidence,queue_policy=policy_pin,
                         handoff_assignment=assignment_pin,
                         created_at_pacific=manifest['created_at_pacific'])
        amendment['endpoints']=endpoints_for(sources[name],parent,policy,gpu_uuids)
        path=DIRECTORY/('amendment_'+name+'.json')
        if path.exists() and read(path)!=amendment:raise RuntimeError('An immutable host amendment already differs')
        proposed[path]=amendment
    for path,amendment in proposed.items():
        if not path.exists():save(path,amendment)
    for group in frozen_assignment['groups']:
        name=group['name'];path=DIRECTORY/('amendment_'+name+'.json')
        if path.exists():
            manifest['groups'].append({**group,'amendment_path':str(path),'amendment_sha256':sha(path),
                                      'vllm_version':'0.32.0'})
    if len(manifest['groups'])==2:
        path=DIRECTORY/'handoff_manifest.json'
        if path.exists():
            if read(path)!=manifest:raise RuntimeError('The final immutable handoff manifest differs')
        else:save(path,manifest)
    print(json.dumps({'stage':'handoff_complete' if len(manifest['groups'])==2 else 'host_amendment_ready',
                      'prepared_hosts':[g['name'] for g in manifest['groups']],
                      'assignment':assignment_pin,
                      'remaining_cases':{g['name']:g['remaining_cases'] for g in frozen_assignment['groups']}}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host',choices=('new_pool','existing_pool'))
    main(parser.parse_args().host)
