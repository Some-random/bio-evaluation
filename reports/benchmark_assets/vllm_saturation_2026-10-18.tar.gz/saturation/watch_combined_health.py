"""Combine two dated operational reports; no model, parser or scorer calls."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import fcntl
import hashlib
import json
from pathlib import Path
import signal
import time
from zoneinfo import ZoneInfo

PACIFIC = ZoneInfo('America/Los_Angeles')
STOP = False

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text())
def write(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp'); tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n'); tmp.chmod(0o600); tmp.replace(path)

def heartbeat(value, now, maximum_age):
    try:
        dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if dt.tzinfo is None: raise ValueError('A dated heartbeat must have a timezone')
        age = (now - dt.astimezone(timezone.utc)).total_seconds()
        return {'fresh': -30 <= age <= maximum_age, 'age_seconds': max(0, age), 'timestamp': value}
    except (AttributeError, TypeError, ValueError):
        return {'fresh': False, 'age_seconds': None, 'timestamp': value}

def combine(plan, reports, *, at=None):
    """Count unique logical cases beyond the pinned clean-pause baseline."""
    at = at or datetime.now(timezone.utc)
    if at.tzinfo is None: raise ValueError('An aware observation time is required')
    baseline = plan['baseline']; scopes = {}; expected_groups = {}; initial_total = 0
    for group in plan['groups']:
        expected = {}
        for scope in group['runs']:
            rid = scope['run_id']
            if rid in scopes: raise ValueError('A logical run belongs to two host reports')
            if not 0 <= scope['initial_saved'] <= scope['planned']: raise ValueError('Invalid selected-run baseline')
            expected[rid] = scope; scopes[rid] = scope; initial_total += scope['initial_saved']
        expected_groups[group['name']] = expected
    if sum(s['planned'] - s['initial_saved'] for s in scopes.values()) != baseline['remaining_at_clean_pause']:
        raise ValueError('Selected runs do not preserve the global remaining denominator')
    if baseline['global_planned'] - baseline['global_saved_at_clean_pause'] != baseline['remaining_at_clean_pause']:
        raise ValueError('Global clean-pause arithmetic differs')
    flags = []; groups = []; task_counts = defaultdict(Counter); observed = {}; gpu_uuids = []; all_fresh = True; lower_bound_delta = 0
    formats = Counter()
    for group in plan['groups']:
        name = group['name']; report = reports.get(name); valid = True
        row = {'name': name, 'report_file': group['report_file'], 'expected_runs': len(expected_groups[name])}
        if not isinstance(report, dict):
            row.update(fresh=False, valid_scope=False, state='missing_report'); flags.append({'type': 'missing_health_report', 'group': name}); all_fresh = False; groups.append(row); continue
        freshness = heartbeat(report.get('updated_at_pacific'), at, plan.get('maximum_report_age_seconds', 180)); row.update(freshness)
        if not freshness['fresh']: flags.append({'type': 'stale_or_invalid_health_heartbeat', 'group': name}); all_fresh = False
        if report.get('plan_sha256') != group['health_plan_sha256']:
            valid = False; flags.append({'type': 'health_plan_mismatch', 'group': name})
        entries = report.get('runs', []); ids = [r.get('logical_run_id') for r in entries]
        if len(set(ids)) != len(ids) or set(ids) != set(expected_groups[name]):
            valid = False; flags.append({'type': 'health_run_scope_mismatch', 'group': name})
        current = 0; initial = sum(s['initial_saved'] for s in expected_groups[name].values()); terminals = 0
        if valid:
            for r in entries:
                scope = expected_groups[name][r['logical_run_id']]; count = r.get('responses_saved')
                if (r.get('planned') != scope['planned'] or r.get('task_id') != scope['task_id']
                        or type(count) is not int or not scope['initial_saved'] <= count <= scope['planned']):
                    valid = False; flags.append({'type': 'generation_count_regression_or_scope_error', 'group': name, 'run_id': scope['run_id']}); break
                current += count
            if valid:
                lower_bound_delta += current - initial
                for r in entries:
                    scope = expected_groups[name][r['logical_run_id']]; observed[scope['run_id']] = r['responses_saved']
                    t = task_counts[scope['task_id']]; t['planned_selected_cases'] += scope['planned']; t['initial_selected_saved'] += scope['initial_saved']; t['last_observed_selected_saved'] += r['responses_saved']
                    t['selected_runs'] += 1; terminal = bool(r.get('generation_terminal'))
                    if terminal and r.get('generation_exit_code') != 0: flags.append({'type': 'nonzero_generation_exit', 'group': name, 'run_id': scope['run_id']})
                    t['terminal_generation_runs'] += terminal; terminals += terminal
        if not valid: all_fresh = False
        row.update(valid_scope=valid, initial_selected_saved=initial, last_observed_selected_saved=current if valid else None, terminal_generation_runs=terminals)
        endpoints = report.get('endpoints', []); row['healthy_endpoints'] = sum(e.get('healthy') is True for e in endpoints)
        if len(endpoints) != group.get('replicas', 4) or row['healthy_endpoints'] != group.get('replicas', 4): flags.append({'type': 'endpoint_unhealthy_or_missing', 'group': name})
        row['endpoints'] = endpoints
        gpu_uuids += [u for e in endpoints for u in e.get('gpu_uuids', [])]
        row['flags'] = report.get('flags', []); flags += [{**f, 'group': name} for f in report.get('flags', [])]
        for k in ['shared_response_metadata_scanned', 'length_finish_count', 'empty_final_count', 'transport_or_server_error_count']:
            formats[k] += report.get('response_format', {}).get(k, 0)
        groups.append(row)
    if len(gpu_uuids) != len(set(gpu_uuids)) or len(gpu_uuids) != plan.get('project_gpu_count', 8): flags.append({'type': 'combined_gpu_overlap_or_missing_replica'})
    coverage = set(observed) == set(scopes); verified = all_fresh and coverage
    last_observed = baseline['global_saved_at_clean_pause'] + lower_bound_delta
    if last_observed > baseline['global_planned']: raise ValueError('Combined responses exceed the global planned denominator')
    for v in task_counts.values():
        v['new_responses_since_clean_pause'] = v['last_observed_selected_saved'] - v['initial_selected_saved']; v['remaining_selected_cases'] = v['planned_selected_cases'] - v['last_observed_selected_saved']
    return {'schema_version': 1, 'updated_at_pacific': at.astimezone(PACIFIC).isoformat(),
            'baseline': baseline, 'selected_run_count': len(scopes), 'selected_initial_saved': initial_total,
            'selected_current_saved': sum(observed.values()) if coverage else None,
            'current_counts_verified': verified, 'global_saved_responses': last_observed if verified else None,
            'last_observed_global_saved_responses': last_observed if coverage else None,
            'minimum_observed_global_saved_responses': last_observed,
            'new_responses_since_clean_pause': lower_bound_delta if coverage else None,
            'global_remaining_cases': baseline['global_planned'] - last_observed if verified else None,
            'groups': groups, 'by_task': {k: dict(v) for k, v in sorted(task_counts.items())},
            'response_format_across_selected_disjoint_runs': dict(formats), 'flags': flags,
            'automatic_actions': [], 'inference_or_scoring_performed': False,
            'interpretation': 'Saved responses are generation progress, not validated benchmark scores. Stale or missing health reports make current counts unverified. Selected runs are disjoint; historical responses are counted once.'}

def cycle(plan_path, expected_sha):
    if sha(plan_path) != expected_sha: raise ValueError('Combined health plan changed')
    plan = read(plan_path)
    for pin in plan['pinned_sources']:
        if sha(pin['path']) != pin['sha256']: raise ValueError('A pinned clean-handoff source changed')
    reports = {}
    for group in plan['groups']:
        try: reports[group['name']] = read(group['report_file'])
        except (OSError, ValueError): reports[group['name']] = None
    report = combine(plan, reports); report['plan_sha256'] = expected_sha
    write(plan['output_file'], report)
    history = {'updated_at_pacific': report['updated_at_pacific'], 'plan_sha256': expected_sha,
               'current_counts_verified': report['current_counts_verified'], 'global_saved_responses': report['global_saved_responses'],
               'last_observed_global_saved_responses': report['last_observed_global_saved_responses'], 'global_remaining_cases': report['global_remaining_cases'],
               'by_task': report['by_task'], 'flag_types': sorted({f['type'] for f in report['flags']})}
    with Path(plan['history_file']).open('a') as f: f.write(json.dumps(history, sort_keys=True) + '\n'); f.flush()
    return report, plan.get('interval_seconds', 60)

def main():
    global STOP
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('--plan', type=Path, required=True); p.add_argument('--plan-sha256', required=True); p.add_argument('--once', action='store_true'); args = p.parse_args()
    def stop(signum, frame):
        global STOP; STOP = True
    signal.signal(signal.SIGTERM, stop); signal.signal(signal.SIGINT, stop)
    with args.plan.with_suffix('.worker.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        while not STOP:
            try:
                report, interval = cycle(args.plan, args.plan_sha256)
                print(json.dumps({k: report[k] for k in ['updated_at_pacific', 'current_counts_verified', 'global_saved_responses', 'global_remaining_cases']}), flush=True)
            except Exception as e:
                write(args.plan.with_suffix('.error.json'), {'updated_at_pacific': datetime.now(PACIFIC).isoformat(), 'error_type': type(e).__name__, 'last_successful_report_preserved': True})
                if args.once: return 1
                interval = 60
            if args.once: return 0
            for _ in range(interval):
                if STOP: break
                time.sleep(1)
    return 0

if __name__ == '__main__': raise SystemExit(main())
