"""CPU mocks only: these tests send no operating-system signals."""
import importlib.util
import json
import os
from pathlib import Path
import signal
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('reviewed_existing_pool_controller', Path(__file__).with_name('manage_existing_pool.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class ControllerSafetyTests(unittest.TestCase):
    def test_signals_bind_pidfd_after_ticks_are_rechecked(self):
        info = {'state': 'S', 'parent_pid': 1, 'pgrp': 12, 'session': 12}
        with patch.object(m, 'process', return_value=info) as read_process, patch.object(m.os, 'pidfd_open', return_value=99), patch.object(m.select, 'select', return_value=([], [], [])), patch.object(m.signal, 'pidfd_send_signal') as send, patch.object(m.os, 'close'):
            pinned = m.PinnedProcess({'pid': 12, 'ticks': '345'})
            pinned.send(signal.SIGSTOP)
            self.assertEqual(read_process.call_count, 2)
            send.assert_called_once_with(99, signal.SIGSTOP, None, 0)
            pinned.close()

    def test_owner_is_not_resumed_until_old_producer_ends_and_queues_are_known_idle(self):
        events = []
        producer_states = iter([True, True, False])
        producer = SimpleNamespace(alive=lambda: next(producer_states, False), send=lambda s: events.append(('producer_signal', s)))
        owner = SimpleNamespace(alive=lambda: True, send=lambda s: events.append(('owner_signal', s)))
        observations = iter([OSError('unreachable'), False, True])
        def idle():
            value = next(observations)
            events.append(('observed', type(value).__name__ if isinstance(value, Exception) else value))
            if isinstance(value, Exception):
                raise value
            return value
        m.release_owner_when_safe(owner, producer, None, idle, lambda *a, **k: None, sleep=lambda s: None)
        self.assertEqual(events[-1], ('owner_signal', signal.SIGCONT))
        self.assertIn(('observed', False), events)
        self.assertEqual(events[0], ('producer_signal', signal.SIGTERM))

    def test_own_continuation_is_allowed_to_finish_before_owner_cleanup(self):
        events = []
        polls = iter([None, None, 0])
        child = SimpleNamespace(pid=123, poll=lambda: next(polls, 0))
        owner = SimpleNamespace(alive=lambda: True, send=lambda s: events.append('resume'))
        producer = SimpleNamespace(alive=lambda: False)
        with patch.object(m.os, 'killpg', side_effect=lambda *a: events.append('stop_new_admissions')):
            m.release_owner_when_safe(owner, producer, child, lambda: events.append('idle') or True, lambda *a, **k: None, sleep=lambda s: events.append('wait'))
        self.assertEqual(events, ['stop_new_admissions', 'wait', 'idle', 'resume'])

    def test_nonidle_server_cannot_be_stopped(self):
        with patch.object(m.os, 'killpg') as kill:
            with self.assertRaisesRegex(RuntimeError, 'every engine'):
                m.stop_idle_server_groups([], SimpleNamespace(), lambda: False, lambda *a, **k: None)
            kill.assert_not_called()

    def test_foreign_process_group_cannot_be_stopped(self):
        owner = SimpleNamespace(pid=5, alive=lambda: True, info=lambda: {'state': 'T'})
        server = SimpleNamespace(pid=6, info=lambda: {'parent_pid': 5, 'pgrp': 7, 'session': 6})
        with patch.object(m.os, 'killpg') as kill:
            with self.assertRaisesRegex(RuntimeError, 'exclusively owned'):
                m.stop_idle_server_groups([(server, {})], owner, lambda: True, lambda *a, **k: None)
            kill.assert_not_called()

    def test_fresh_runtime_gate_uses_reviewed_private_python_and_cannot_change(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            runtime = root / 'bio-saturation-synthetic-unique'
            python = runtime / 'python/bin/python3.12'
            python.parent.mkdir(parents=True)
            python.write_text('synthetic interpreter bytes; never executed')
            receipt = root / '.local/existing_upgrade/runtime_ready.json'
            receipt.parent.mkdir(parents=True)
            receipt.write_text(json.dumps({'stage': 'ready_for_reviewed_launcher', 'runtime_directory': str(runtime), 'python': str(python), 'python_sha256': m.sha(python), 'job_id': 'synthetic', 'packages': {'vllm': '0.32.0'}, 'pip_check_passed': True}))
            launcher = root / 'launcher.py'
            launcher.write_text('synthetic launcher; never executed')
            gate = {'replace_servers': True, 'runtime_receipt_file': str(receipt), 'runtime_receipt_sha256': m.sha(receipt), 'python_sha256': m.sha(python), 'files_sha256': {str(launcher): m.sha(launcher)}, 'command': ['{python}', str(launcher), '--runtime-dir', '{runtime}']}
            common = SimpleNamespace(environment=lambda r: {'PINNED_RUNTIME': str(r)})
            with patch.dict(os.environ, {'SLURM_JOB_ID': 'synthetic'}):
                command, env = m.checked_gate(gate, '/old/python/bin/python3.12', common, root)
                self.assertEqual(command[0], str(python))
                self.assertEqual(command[-1], str(runtime))
                self.assertEqual(env['PINNED_RUNTIME'], str(runtime))
                python.write_text('changed interpreter')
                with self.assertRaisesRegex(RuntimeError, 'runtime identity'):
                    m.checked_gate(gate, '/old/python/bin/python3.12', common, root)


if __name__ == '__main__':
    unittest.main()
