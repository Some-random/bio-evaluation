"""Synthetic handoff scopes cannot overlap or reuse legacy server identities."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("handoff_under_test", HERE / "prepare_saturation_handoff.py")
h = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(h)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))


class HandoffTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(); self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name); self.directory = self.root / "saturation"; self.directory.mkdir()
        self.parent_path = self.root / "parent.json"
        for name in ("shared_vllm_resume.py", "run_shared_vllm_evaluations.py", "native_queue_scheduler.py"):
            (self.directory / name).write_text("# Synthetic non-executed source\n")
        entries, contexts = [], {}
        for i in range(9):
            name = "synthetic-run-" + str(i); project = self.root / ("project-" + str(i))
            entries.append({"run_id": name, "task_id": "SYNTHETIC", "project_root": str(project), "case_count": 10})
            done = {"planned": 10, "statuses": {"completed": 10 if i == 8 else 2}}
            if i != 8: done["statuses"]["not_dispatched_after_error"] = 8
            write(project / "results/runs" / name / "shared_vllm_generation_completion.json", done)
            path = project / "context.json"; write(path, {"per_case": [{"prompt_tokens": 192} for _ in range(10)]})
            contexts[name] = {"path": str(path), "sha256": h.sha(path)}
        source = self.root / "source_plan.json"; write(source, {"workers": [{"entries": entries}]})
        self.parent = {"model": "synthetic-model", "model_revision": "synthetic-revision", "run_ids": [e["run_id"] for e in entries],
                       "source_plans": [{"path": str(source), "sha256": h.sha(source)}], "run_context_checks": contexts,
                       "negative_execution_receipts": [{"path": "immutable-parent-proof.json", "sha256": "unchanged-synthetic-pin"}]}
        write(self.parent_path, self.parent)
        for group, relative in enumerate(("existing_upgrade/saturation_endpoints.json", "saturation_endpoints.json")):
            endpoints = []
            for slot in range(4):
                identity = self.directory / f"identity-{group}-{slot}.json"
                write(identity, {"model": self.parent["model"], "revision": self.parent["model_revision"], "dtype": "bfloat16",
                                 "tensor_parallel_size": 1, "max_model_len": 65536, "max_num_seqs": 128, "vllm_version": "0.32.0",
                                 "gpu_uuids": [f"GPU-synthetic-{group}-{slot}"]})
                endpoints.append({"endpoint_id": f"{group}-{slot}", "server_identity_file": str(identity), "server_identity_sha256": h.sha(identity)})
            write(self.directory / relative, endpoints)
        write(self.directory / "drain_receipt.json", {"all_original_http_calls_finished": True})
        benchmark = self.directory / "synthetic_benchmark.json"; write(benchmark, {"synthetic_only": True})
        write(self.directory / "saturation_benchmark_summary.json", {"success": True, "results": [{"results_file": str(benchmark)}]})
        write(self.directory / "queue_policy.json", {
            "schema_version": 1, "kind": "shared_vllm_reviewed_queue_policy", "reviewed": True,
            "scheduler_policy": "vllm_native_bounded_queue", "queue_limit": 64, "server_max_num_seqs": 128,
            "benchmark_summary_sha256": h.sha(self.directory / "saturation_benchmark_summary.json"),
            "scientific_protocol_changes": [], "rationale": "Synthetic fixture measured queue selection"})

    def run_builder(self, host=None):
        with mock.patch.multiple(h, ROOT=self.root, DIRECTORY=self.directory, PARENT=self.parent_path), contextlib.redirect_stdout(io.StringIO()):
            h.main(host)

    def test_both_upgraded_hosts_get_disjoint_balanced_remaining_scopes(self):
        self.run_builder()
        manifest = h.read(self.directory / "handoff_manifest.json")
        groups = [h.read(g["amendment_path"]) for g in manifest["groups"]]
        scopes = [set(g["run_ids"]) for g in groups]
        self.assertFalse(scopes[0] & scopes[1])
        self.assertEqual(set.union(*scopes), set(self.parent["run_ids"][:-1]))
        self.assertEqual([len(s) for s in scopes], [4, 4])
        self.assertTrue(all(g["vllm_version"] == "0.32.0" for g in manifest["groups"]))
        for group in groups:
            self.assertEqual(group["fairness"], "task_round_robin_then_run_round_robin")
            self.assertEqual(group["transport_timeout_seconds"], 14400)
            self.assertEqual(group["negative_execution_receipts"], self.parent["negative_execution_receipts"])
            self.assertEqual(len(group["adapter_files_sha256"]), 3)
            self.assertEqual(len(group["endpoints"]), 4)
            self.assertTrue(all(e["queue_limit"] == e["max_inflight"] == 64 and e["max_num_seqs"] == 128
                                for e in group["endpoints"]))
            self.assertEqual(group["queue_policy"], {"path": str(self.directory / "queue_policy.json"),
                                                   "sha256": h.sha(self.directory / "queue_policy.json")})
            self.assertIn({"path": "saturation/queue_policy.json", "sha256": h.sha(self.directory / "queue_policy.json")},
                          group["capacity_evidence_files"])

    def test_one_host_starts_without_other_inventory_then_reuses_exact_assignment(self):
        old_source = self.directory / "existing_upgrade/saturation_endpoints.json"
        old_bytes = old_source.read_bytes(); old_source.unlink()
        self.run_builder("new_pool")
        assignment = self.directory / "handoff_assignment.json"
        assignment_bytes = assignment.read_bytes()
        new_amendment = self.directory / "amendment_new_pool.json"
        new_bytes = new_amendment.read_bytes()
        self.assertFalse((self.directory / "amendment_existing_pool.json").exists())
        self.assertFalse((self.directory / "handoff_manifest.json").exists())
        frozen = h.read(assignment)
        self.assertEqual({g["name"] for g in frozen["groups"]}, {"existing_pool", "new_pool"})
        self.assertEqual(sum(g["remaining_cases"] for g in frozen["groups"]), 64)
        old_source.write_bytes(old_bytes)
        self.run_builder("existing_pool")
        self.assertEqual(assignment.read_bytes(), assignment_bytes)
        self.assertEqual(new_amendment.read_bytes(), new_bytes)
        manifest = h.read(self.directory / "handoff_manifest.json")
        self.assertEqual(len(manifest["groups"]), 2)
        scopes = [set(h.read(g["amendment_path"])["run_ids"]) for g in manifest["groups"]]
        self.assertFalse(scopes[0] & scopes[1])
        self.assertEqual(set.union(*scopes), set(self.parent["run_ids"][:-1]))
        self.run_builder("new_pool")  # Idempotent validation, no immutable overwrite.
        self.assertEqual(new_amendment.read_bytes(), new_bytes)

    def test_second_host_gpu_collision_preserves_first_amendment(self):
        self.run_builder("new_pool")
        new_amendment = self.directory / "amendment_new_pool.json"
        new_bytes = new_amendment.read_bytes()
        source = self.directory / "existing_upgrade/saturation_endpoints.json"
        endpoints = h.read(source)
        identity_path = Path(endpoints[0]["server_identity_file"])
        identity = h.read(identity_path); identity["gpu_uuids"] = ["GPU-synthetic-1-0"]
        write(identity_path, identity); endpoints[0]["server_identity_sha256"] = h.sha(identity_path)
        write(source, endpoints)
        with self.assertRaisesRegex(RuntimeError, "GPU identities must be disjoint"):
            self.run_builder("existing_pool")
        self.assertEqual(new_amendment.read_bytes(), new_bytes)
        self.assertFalse((self.directory / "amendment_existing_pool.json").exists())
        self.assertFalse((self.directory / "handoff_manifest.json").exists())

    def test_failed_benchmark_gate_writes_no_amendment(self):
        write(self.directory / "saturation_benchmark_summary.json", {"success": False})
        with self.assertRaisesRegex(RuntimeError, "sweeps have not passed"):
            self.run_builder()
        self.assertFalse(list(self.directory.glob("amendment_*.json")))

    def test_changed_actual_identity_fails_before_any_amendment_is_frozen(self):
        (self.directory / "identity-1-3.json").write_text("{}")
        with self.assertRaisesRegex(RuntimeError, "pin its actual"):
            self.run_builder()
        self.assertFalse(list(self.directory.glob("amendment_*.json")))

    def test_queue_policy_must_bind_the_exact_closed_benchmark_summary(self):
        policy = h.read(self.directory / "queue_policy.json")
        policy["benchmark_summary_sha256"] = "stale-synthetic-summary-pin"
        write(self.directory / "queue_policy.json", policy)
        with self.assertRaisesRegex(RuntimeError, "reviewed queue policy"):
            self.run_builder()
        self.assertFalse(list(self.directory.glob("amendment_*.json")))


if __name__ == "__main__":
    unittest.main()
