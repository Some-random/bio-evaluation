"""Synthetic full-denominator and mixed-producer attribution checks."""
import copy
import importlib.util
from pathlib import Path
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); sys.modules[name] = value; spec.loader.exec_module(value); return value

m = load("saturation_scoring_review_adapter", HERE / "shared_vllm_scoring.py")
base = load("saturation_scoring_review_fixture", ROOT / "tests/test_shared_vllm_scoring.py")

class ScoringReviewTests(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory(); self.addCleanup(self.t.cleanup)
        self.root = Path(self.t.name); self.f = base.Fixture(self.root)

    def test_native_full_denominator_keeps_invalid_and_missing_outputs(self):
        folder = self.root / "results/runs/artificial-source-1"
        base.save(folder / "shared_vllm_saturation_amendment.json", {"synthetic": True})
        base.save(folder / "shared_vllm_saturation_generation_completion.json", {"synthetic": True})
        before = {p: p.read_bytes() for p in self.root.rglob("*.json")}
        result = m.score_spec(self.f.spec, validator=self.f.validator)
        self.assertEqual(result["state"], "completed")
        scores = m.read(self.root / "results/runs/artificial-full/scores.json")
        self.assertEqual(scores["planned"], 4); self.assertEqual(scores["completed"], 3)
        self.assertEqual(scores["invalid_outputs"], 1)
        self.assertEqual(scores["statuses"]["interrupted_unknown_completion"], 1)
        self.assertEqual(scores["metrics"]["accuracy"], .5)
        for p, b in before.items(): self.assertEqual(p.read_bytes(), b)

    def deepfri_inputs(self):
        actual = self.root / "new_producer.py"; actual.write_text("# synthetic second producer\n")
        source_folder = self.root / "results/runs/artificial-source-1"
        manifest = m.read(source_folder / "run_manifest.json"); old = manifest["runner_sha256"]
        spec = {**self.f.spec, "execution_runner_file": str(actual), "execution_runner_sha256": m.file_sha(actual), "historical_execution_runner_sha256": old}
        source = {"run_id": "artificial-source-1", "generation_folder": str(source_folder),
                  "provenance": {"parent_checkpoint_sha256": "synthetic-pinned-parent", "all_saved_responses_verified": True}}
        return spec, source, source_folder

    def test_mixed_deepfri_view_identifies_both_producers_and_preserves_recipe(self):
        spec, source, folder = self.deepfri_inputs(); before = (folder / "run_manifest.json").read_bytes()
        cfg, path = m.deepfri_view(self.root, self.f.full, spec, [source])
        self.assertEqual((folder / "run_manifest.json").read_bytes(), before)
        note = cfg["shared_vllm_scoring_view"]
        self.assertEqual(note["actual_execution_runner_sha256"], spec["execution_runner_sha256"])
        self.assertEqual(note["historical_execution_runner_sha256"], spec["historical_execution_runner_sha256"])
        for key in set(self.f.full) - {"run_id", "runner", "frozen_files_sha256"}:
            self.assertEqual(cfg[key], self.f.full[key])
        self.assertEqual(m.file_sha(self.root / cfg["runner"]), spec["execution_runner_sha256"])

    def test_mixed_deepfri_requires_verified_parent_checkpoint(self):
        spec, source, _ = self.deepfri_inputs(); source["provenance"].pop("parent_checkpoint_sha256")
        with self.assertRaisesRegex(m.ScoringError, "immutable parent checkpoint"):
            m.deepfri_view(self.root, self.f.full, spec, [source])

if __name__ == "__main__": unittest.main()
