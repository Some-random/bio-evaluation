"""Synthetic checks for complete-case scoring after an infrastructure handoff."""
import importlib.util
from pathlib import Path
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def module(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value
    spec.loader.exec_module(value)
    return value


scoring=module('saturation_scoring_tests_adapter',HERE/'shared_vllm_scoring.py')
base=module('saturation_scoring_tests_fixture',ROOT/'tests/test_shared_vllm_scoring.py')
base.mod=scoring
sys.modules['shared_vllm_scoring']=scoring
watcher=module('saturation_scoring_tests_watcher',HERE/'watch_shared_vllm_scoring.py')
watcher.scoring=scoring


class SaturationScoringTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.fixture=base.Fixture(Path(self.temporary.name))
        self.folder=self.fixture.root/'results/runs/artificial-source-1'

    def test_parent_pause_never_triggers_full_scoring(self):
        base.save(self.folder/'shared_vllm_saturation_amendment.json',{'synthetic':True})
        ready,reason=watcher.generation_ready(self.fixture.spec)
        self.assertFalse(ready)
        self.assertTrue(reason.startswith('saturation_generation_pending:'))
        with self.assertRaises(scoring.Pending):
            scoring.validate_sources(self.fixture.spec,validator=self.fixture.validator)
        self.assertEqual(self.fixture.validator_calls,[])

    def test_unapproved_amendment_cannot_be_scored(self):
        self.fixture.spec['execution_amendment_sha256']='old-frozen-amendment'
        self.fixture.spec['additional_execution_amendment_sha256']=['reviewed-new-amendment']
        def unexpected(*args,**kwargs):
            return {'amendment_sha256':'unexpected','all_saved_responses_verified':True}
        with self.assertRaises(scoring.ScoringError):
            scoring.validate_sources(self.fixture.spec,validator=unexpected)

    def test_planned_continuation_blocks_parent_only_transition_window(self):
        self.fixture.spec['sources'][-1]['requires_saturation']=True
        ready,reason=watcher.generation_ready(self.fixture.spec)
        self.assertFalse(ready)
        self.assertTrue(reason.startswith('planned_saturation_pending:'))
        with self.assertRaises(scoring.Pending):
            scoring.validate_sources(self.fixture.spec,validator=self.fixture.validator)

    def test_new_terminal_marker_keeps_original_case_denominator(self):
        base.save(self.folder/'shared_vllm_saturation_amendment.json',{'synthetic':True})
        base.save(self.folder/'shared_vllm_saturation_generation_completion.json',{'synthetic':True})
        *_,sources,union=scoring.validate_sources(self.fixture.spec,validator=self.fixture.validator)
        self.assertEqual(union['expected_test_case_count'],4)
        self.assertEqual(union['missing_case_count'],0)
        self.assertEqual(sources[-1]['statuses']['interrupted_unknown_completion'],1)


if __name__=='__main__':
    unittest.main()
