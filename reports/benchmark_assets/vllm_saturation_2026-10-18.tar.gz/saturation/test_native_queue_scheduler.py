"""Synthetic CPU checks: fairness, bounded outstanding calls and drain safety."""
import importlib.util
import os
from pathlib import Path
import signal
import sys
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from native_queue_scheduler import NativeTaskQueue, QueueError, drive_bounded_queue


def endpoint(name, limit=2, context=65536):
    return {"endpoint_id": name, "queue_limit": limit, "max_inflight": limit,
            "scheduler_policy": "vllm_native_bounded_queue", "max_model_len": context}


def state(task, run, n, tokens=192, minimum=8192):
    cases = [{"case_id": run + ":" + str(i)} for i in range(n)]
    return SimpleNamespace(entry={"task_id": task, "run_id": run, "minimum_context_tokens": minimum},
        settings={"generation": {"max_tokens": 4096}}, prompt_tokens={c["case_id"]: tokens for c in cases},
        pending=lambda: iter((case, case["case_id"] + ".json") for case in cases))


class NativeQueueTests(unittest.TestCase):
    def test_fair_across_tasks_then_runs_without_shard_count_bias(self):
        runs = [state("A", "a1", 10), state("A", "a2", 10), state("B", "b1", 10)]
        ep, stop = endpoint("e"), threading.Event()
        queue = NativeTaskQueue(runs, [ep])
        selected = [queue.take(ep, stop)[0].entry for _ in range(8)]
        self.assertEqual([x["task_id"] for x in selected], ["A", "B"] * 4)
        self.assertEqual([x["run_id"] for x in selected if x["task_id"] == "A"], ["a1", "a2"] * 2)

    def test_no_length_ticket_blocks_a_compatible_task(self):
        small, large = endpoint("small", context=8192), endpoint("large")
        queue = NativeTaskQueue([state("long", "long", 2, tokens=45056, minimum=65536), state("short", "short", 2)], [small, large])
        stop = threading.Event()
        self.assertEqual(queue.take(small, stop)[0].entry["task_id"], "short")
        self.assertEqual(queue.take(large, stop)[0].entry["task_id"], "long")
        with self.assertRaisesRegex(QueueError, "complete frozen context"):
            NativeTaskQueue([state("long", "long", 2, tokens=45056, minimum=65536)], [small])

    def exercise_workers(self, pause):
        endpoints = [endpoint("e1", 3), endpoint("e2", 2)]
        queue = NativeTaskQueue([state("A", "a", 60), state("B", "b", 60)], endpoints)
        stop, ready, release = threading.Event(), threading.Event(), threading.Event()
        self.addCleanup(release.set)
        mutex, active, seen, saved, outcome = threading.Lock(), {}, [], [], {}
        def dispatch(unused_state, case, name, ep, unused_stop):
            with mutex:
                active[ep["endpoint_id"]] = active.get(ep["endpoint_id"], 0) + 1
                seen.append(case["case_id"])
                if sum(active.values()) == 5: ready.set()
            if not release.wait(3): raise RuntimeError("Synthetic gate timed out")
            with mutex:
                active[ep["endpoint_id"]] -= 1
                saved.append(name)
        def run():
            outcome.update(drive_bounded_queue(queue, endpoints, stop, dispatch, lambda unused: None))
        producer = threading.Thread(target=run)
        producer.start()
        self.assertTrue(ready.wait(3), "Every declared HTTP queue should fill")
        if pause: stop.set()
        release.set(); producer.join(5)
        self.assertFalse(producer.is_alive())
        self.assertEqual(outcome["peak_outstanding_requests"], {"e1": 3, "e2": 2})
        self.assertEqual(sum(outcome["active_calls_at_return"].values()), 0)
        self.assertFalse(outcome["infrastructure_error_types"])
        self.assertEqual(len(seen), len(set(seen)))
        self.assertEqual(len(saved), len(seen))
        return seen, outcome

    def test_parallel_calls_are_bounded_and_each_case_is_selected_once(self):
        seen, unused = self.exercise_workers(False)
        self.assertEqual(len(seen), 120)

    def test_pause_finishes_active_calls_without_claiming_more(self):
        seen, unused = self.exercise_workers(True)
        self.assertEqual(len(seen), 5)

    def test_four_parallel_preparations_join_all_failures_before_any_dispatch(self):
        spec = importlib.util.spec_from_file_location("prepare_dispatcher_under_test", HERE / "run_shared_vllm_evaluations.py")
        dispatcher = importlib.util.module_from_spec(spec); spec.loader.exec_module(dispatcher)
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            entries = [{"run_id": str(i), "task_id": "synthetic", "project_root": ".",
                        "minimum_context_tokens": 8192} for i in range(8)]
            ep = {**endpoint("synthetic"), "server_identity_sha256": "synthetic-only",
                  "endpoint": "http://127.0.0.1:1/v1"}
            created, completed, idle = [], [], []
            barrier, mutex = threading.Barrier(4), threading.Lock()
            active, peak = [0], [0]
            class FakeRun:
                def __init__(self, entry, *unused):
                    self.entry = entry; self.acquired = False; self.closed = False
                    self.cases = [{"task": "synthetic", "variant": "test", "case_id": entry["run_id"]}]
                    self.helper = SimpleNamespace(call=lambda *args, **kwargs: (200, {"data": [{"id": dispatcher.MODEL}]}))
                    created.append(self)
                def acquire(self): self.acquired = True
                def inventory(self): raise AssertionError("Execution inventory must stay inside locked preparation")
                def prepare(self, unused):
                    if len(created) != 8 or not all(s.acquired for s in created) or not idle:
                        raise AssertionError("All helpers, locks and idle checks must precede preparation")
                    with mutex:
                        active[0] += 1; peak[0] = max(peak[0], active[0])
                    try:
                        barrier.wait(3)
                        if self.entry["run_id"] == "0": raise ValueError("synthetic invalid checkpoint")
                    finally:
                        with mutex: active[0] -= 1; completed.append(self.entry["run_id"])
                def finish_if_complete(self): pass
                def close(self): self.closed = True
            with mock.patch.object(dispatcher, "load_amendment", return_value=({}, [ep], entries)), \
                 mock.patch.object(dispatcher, "Run", FakeRun), \
                 mock.patch.object(dispatcher, "require_idle_endpoint", side_effect=lambda unused: idle.append(True)), \
                 mock.patch.object(dispatcher, "drive_bounded_queue") as drive:
                with self.assertRaisesRegex(dispatcher.ResumeError, "before any dispatch.*synthetic invalid checkpoint"):
                    dispatcher.run(root, root / "synthetic-amendment.json", "synthetic-only")
            drive.assert_not_called()
            self.assertEqual(peak[0], 4)
            self.assertEqual(active[0], 0)
            self.assertEqual(set(completed), {str(i) for i in range(8)})
            self.assertTrue(all(s.closed for s in created))

    def test_actual_versioned_core_keeps_parent_bytes_and_native_payloads(self):
        # The existing synthetic fixture's frozen helper returns hardcoded JSON;
        # there is no real HTTP endpoint or model call in this integration test.
        spec = importlib.util.spec_from_file_location("queue_chain_fixture", HERE / "test_saturation_resume.py")
        fixture_module = importlib.util.module_from_spec(spec); spec.loader.exec_module(fixture_module)
        fixture = fixture_module.ChainTests(methodName="test_mixed_raw_history_full_score_provenance_and_timeout")
        fixture.setUp(); self.addCleanup(fixture.doCleanups)
        run = fixture.state(); run.prepare([fixture.endpoint])
        queue = NativeTaskQueue([run], [fixture.endpoint])
        result = drive_bounded_queue(queue, [fixture.endpoint], threading.Event(),
            lambda current, case, name, ep, stop: current.dispatch(case, name, ep, stop),
            lambda current: current.finish_if_complete())
        self.assertFalse(result["infrastructure_error_types"])
        run.finish(); fixture.check_old()
        proof = fixture_module.s.validate_resume_provenance(run.run, fixture.f.settings, fixture.f.cases, require_terminal=True)
        self.assertEqual(proof["status_counts"], {"completed": 3})
        self.assertEqual(len(proof["dispatched_files"]), 2)
        self.assertFalse(proof["ambiguous_files"])

    def test_full_dispatcher_sigterm_drains_and_pauses_without_terminal_marker(self):
        spec = importlib.util.spec_from_file_location("pause_chain_fixture", HERE / "test_saturation_resume.py")
        fixture_module = importlib.util.module_from_spec(spec); spec.loader.exec_module(fixture_module)
        fixture = fixture_module.ChainTests(methodName="test_pause_is_not_terminal_and_resume_preserves_parent")
        fixture.setUp(); self.addCleanup(fixture.doCleanups)
        fixture.endpoint.update(queue_limit=1, max_inflight=1)
        fixture.a["endpoints"] = [{k: v for k, v in fixture.endpoint.items() if k != "server_identity"}]
        fixture_module.s.atomic_write(fixture.ap, fixture.a); fixture.ah = fixture_module.s.file_sha(fixture.ap)
        spec = importlib.util.spec_from_file_location("pause_dispatcher_under_test", HERE / "run_shared_vllm_evaluations.py")
        dispatcher = importlib.util.module_from_spec(spec)
        with mock.patch.dict(sys.modules, {"shared_vllm_resume": fixture_module.s}): spec.loader.exec_module(dispatcher)
        original_run, original_drive, runtime = dispatcher.Run, dispatcher.drive_bounded_queue, {}
        def make_run(*args):
            current = original_run(*args)
            native_call = current.helper.call
            def call(url, payload=None, timeout=900):
                if payload is not None:
                    os.kill(os.getpid(), signal.SIGTERM)
                    if not runtime["stop"].wait(2): raise RuntimeError("Synthetic pause signal was not handled")
                return native_call(url, payload, timeout=timeout)
            current.helper.call = call
            return current
        def drive(queue, endpoints, stopped, dispatch, after_case):
            runtime["stop"] = stopped
            return original_drive(queue, endpoints, stopped, dispatch, after_case)
        with mock.patch.object(dispatcher, "load_amendment", return_value=(fixture.a, [fixture.endpoint], [fixture.f.entry])), \
             mock.patch.object(dispatcher, "require_idle_endpoint"), \
             mock.patch.object(dispatcher, "Run", side_effect=make_run), \
             mock.patch.object(dispatcher, "drive_bounded_queue", side_effect=drive):
            result = dispatcher.run(fixture.f.root, fixture.ap, fixture.ah)
        self.assertEqual(result["stage"], "generation_paused")
        self.assertEqual(result["generation_exit_code"], 0)
        self.assertTrue(result["operator_pause"])
        self.assertFalse((fixture.f.run_dir / fixture_module.s.COMPLETION).exists())
        self.assertEqual(len(list((fixture.f.run_dir / "responses").glob("*.json"))), 2)
        self.assertEqual(result["runs"][0]["statuses"], {"completed": 2, "undispatched": 1})
        fixture.check_old()


if __name__ == "__main__":
    unittest.main()
