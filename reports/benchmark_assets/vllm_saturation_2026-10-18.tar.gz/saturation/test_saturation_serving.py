import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('saturation_serving', Path(__file__).with_name('serve_saturation_pool.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class ServingContractTests(unittest.TestCase):
    def plan(self):
        return dict(replicas=4, existing_project_gpu_count=4, model='Qwen/Qwen3.8-27B',
                    revision='1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0',
                    max_model_len=65536, max_num_seqs=128,
                    max_num_batched_tokens=8192, gpu_memory_utilization=0.95)

    def test_same_checkpoint_precision_and_context(self):
        p = self.plan()
        m.validate_plan(p)
        cmd = m.server_command('/private/python', '/verified/checkpoint', p, 8150)
        for flag, expected in [('--dtype', 'bfloat16'), ('--tensor-parallel-size', '1'),
                               ('--max-model-len', '65536'), ('--max-num-seqs', '128'),
                               ('--max-num-batched-tokens', '8192'),
                               ('--gpu-memory-utilization', '0.95'), ('--host', '127.0.0.1')]:
            self.assertEqual(cmd[cmd.index(flag) + 1], expected)
        self.assertIn('--enable-prefix-caching', cmd)

    def test_project_gpu_ceiling(self):
        p = self.plan()
        p['existing_project_gpu_count'] = 5
        with self.assertRaises(ValueError):
            m.validate_plan(p)

    def test_scientific_model_change_is_rejected(self):
        p = self.plan()
        p['revision'] = 'different'
        with self.assertRaises(ValueError):
            m.validate_plan(p)

    def test_metrics_all_engines_must_idle(self):
        self.assertEqual(m.parse_queue_metrics('vllm:num_requests_running{engine="0"} 0\nvllm:num_requests_running{engine="1"} 2\nvllm:num_requests_waiting{engine="0"} 3'), {'running': 2, 'waiting': 3})

    def test_missing_metrics_are_not_idle(self):
        with self.assertRaises(ValueError):
            m.parse_queue_metrics('vllm:num_requests_running 0')

    def test_gate_dependency_cannot_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'script.py'
            path.write_text('original')
            gate = {'files_sha256': {str(path): m.sha(path)}, 'command': ['{python}', str(path)]}
            self.assertEqual(m.checked_command(gate, Path('/private/python')), ['/private/python', str(path)])
            path.write_text('changed')
            with self.assertRaises(ValueError):
                m.checked_command(gate, Path('/private/python'))

    def test_gate_requires_private_interpreter(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'script.py'
            path.write_text('code')
            gate = {'files_sha256': {str(path): m.sha(path)}, 'command': ['/usr/bin/python3', str(path)]}
            with self.assertRaises(ValueError):
                m.checked_command(gate, Path('/private/python'))


if __name__ == '__main__':
    unittest.main()
