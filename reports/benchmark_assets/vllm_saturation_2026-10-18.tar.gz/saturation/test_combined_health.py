"""Synthetic count and freshness checks; never contact a model/API."""
import copy
from datetime import datetime, timedelta, timezone
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value); return value
m = load('combined_health_tests_module', HERE / 'watch_combined_health.py')
h = load('combined_health_node_tests_module', HERE / 'watch_shared_vllm_health.py')

class CombinedTests(unittest.TestCase):
    def setUp(self):
        self.at = datetime(2026, 10, 18, 18, 0, tzinfo=timezone.utc)
        self.plan = {'baseline': {'global_planned': 100, 'global_saved_at_clean_pause': 60, 'remaining_at_clean_pause': 40},
                     'maximum_report_age_seconds': 180, 'project_gpu_count': 8, 'groups': []}
        self.reports = {}
        for i, (name, planned, initial, current) in enumerate([('old_host', 30, 10, 18), ('new_host', 50, 30, 35)]):
            rid = 'synthetic-' + name
            self.plan['groups'].append({'name': name, 'replicas': 4, 'report_file': 'synthetic/' + name,
                 'health_plan_sha256': name, 'runs': [{'run_id': rid, 'task_id': 'SYNTHETIC', 'planned': planned, 'initial_saved': initial}]})
            self.reports[name] = {'updated_at_pacific': self.at.isoformat(), 'plan_sha256': name, 'runs': [
                {'logical_run_id': rid, 'task_id': 'SYNTHETIC', 'planned': planned, 'responses_saved': current, 'generation_terminal': False}],
                'endpoints': [{'endpoint_id': str(j), 'healthy': True, 'gpu_uuids': ['GPU-synthetic-' + str(i * 4 + j)]} for j in range(4)],
                'flags': [], 'response_format': {}}

    def test_only_new_responses_are_added_to_global_baseline(self):
        r = m.combine(self.plan, self.reports, at=self.at)
        self.assertEqual(r['selected_initial_saved'], 40); self.assertEqual(r['selected_current_saved'], 53)
        self.assertEqual(r['new_responses_since_clean_pause'], 13)
        self.assertEqual(r['global_saved_responses'], 73); self.assertEqual(r['global_remaining_cases'], 27)
        self.assertTrue(r['current_counts_verified']); self.assertFalse(r['inference_or_scoring_performed'])

    def test_duplicate_logical_scope_is_rejected(self):
        self.plan['groups'][1]['runs'][0]['run_id'] = self.plan['groups'][0]['runs'][0]['run_id']
        with self.assertRaisesRegex(ValueError, 'two host reports'): m.combine(self.plan, self.reports, at=self.at)

    def test_stale_report_preserves_dated_counts_without_claiming_current(self):
        self.reports['old_host']['updated_at_pacific'] = (self.at - timedelta(minutes=20)).isoformat()
        r = m.combine(self.plan, self.reports, at=self.at)
        self.assertFalse(r['current_counts_verified']); self.assertIsNone(r['global_saved_responses'])
        self.assertEqual(r['last_observed_global_saved_responses'], 73)
        self.assertIn('stale_or_invalid_health_heartbeat', [f['type'] for f in r['flags']])

    def test_missing_report_keeps_baseline_and_only_observed_increment(self):
        self.reports['new_host'] = None
        r = m.combine(self.plan, self.reports, at=self.at)
        self.assertIsNone(r['global_saved_responses']); self.assertIsNone(r['last_observed_global_saved_responses'])
        self.assertEqual(r['minimum_observed_global_saved_responses'], 68)

    def test_count_regression_never_produces_negative_progress(self):
        self.reports['old_host']['runs'][0]['responses_saved'] = 5
        r = m.combine(self.plan, self.reports, at=self.at)
        self.assertFalse(r['current_counts_verified']); self.assertIsNone(r['global_saved_responses'])
        self.assertEqual(r['minimum_observed_global_saved_responses'], 65)
        self.assertIn('generation_count_regression_or_scope_error', [f['type'] for f in r['flags']])

    def test_missing_timezone_or_future_heartbeat_is_unverified(self):
        self.assertFalse(m.heartbeat('2026-10-18T18:00:00', self.at, 180)['fresh'])
        self.assertFalse(m.heartbeat((self.at + timedelta(minutes=5)).isoformat(), self.at, 180)['fresh'])

    def test_original_pause_marker_is_not_saturation_completion(self):
        with tempfile.TemporaryDirectory() as t:
            d = Path(t)
            (d / 'shared_vllm_generation_completion.json').write_text(json.dumps({'run_id': 'synthetic', 'planned': 10, 'generation_exit_code': 1}))
            scope = {'logical_run_id': 'synthetic', 'storage_run_id': 'synthetic', 'task_id': 'SYNTHETIC', 'planned': 10,
                     'run_directory': str(d), 'requires_saturation': True}
            runs, _, _ = h.scan_response_metadata([scope], {})
            self.assertFalse(runs[0]['generation_terminal'])

if __name__ == '__main__': unittest.main()
