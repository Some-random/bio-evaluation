"""Pre-inference recovery from a one-CPU startup; run in a fresh 32-CPU step.

Default mode only checks. --execute pauses the old controller, retires only
startup outputs and owns the corrected launcher until it drains and exits.
No scored generation may have started in the directory being recovered.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
HELPER_SHA = '2310508d9fd50d727b36d5e7af87603e3eb4dc097822d0c82286b1991aade611'
LAUNCHER_SHA = '07458c2d7829e522f4b8f95464184f7e212b5ba8cbc5060c7bf65305cbf9b465'


def load_helper():
    import hashlib
    path = HERE / 'manage_existing_pool.py'
    if hashlib.sha256(path.read_bytes()).hexdigest() != HELPER_SHA:
        raise RuntimeError('Reviewed recovery helper changed')
    spec = importlib.util.spec_from_file_location('cpu_recovery_helpers', path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def startup_only(directory):
    prohibited = ('saturation_dispatch.json', 'saturation_dispatch.log', 'benchmarks_passed.json')
    if any((directory / name).exists() for name in prohibited):
        raise RuntimeError('Recovery is permitted only before dispatch or benchmark acceptance')


def retirement_names(directory):
    names = ['serving_status.json', 'saturation_execution_environment.json', 'saturation_gpu_telemetry.csv',
             'saturation_endpoints.json', 'stop_dispatch.json']
    names.extend(path.name for path in directory.glob('saturation_replica_*'))
    return sorted(name for name in names if (directory / name).exists())


def retire_startup(directory, helper):
    startup_only(directory)
    target = directory / 'retired_startup_one_cpu'
    if target.exists():
        raise RuntimeError('Startup attempt is already retired; no overwrite')
    names = retirement_names(directory)
    inventory = {}
    for name in names:
        source = directory / name
        if source.is_symlink():
            raise RuntimeError('Startup output must not be a symlink')
        files = source.rglob('*') if source.is_dir() else [source]
        for path in files:
            if path.is_symlink():
                raise RuntimeError('Startup tree must not contain symlinks')
            if path.is_file():
                inventory[str(path.relative_to(directory))] = helper.sha(path)
    target.mkdir()
    for name in names:
        (directory / name).rename(target / name)
    helper.write(target / 'retirement_receipt.json', {'reason': 'Startup inherited one physical CPU from Slurm step_28; no scored dispatch began', 'files_sha256': inventory, 'runtime_and_serving_plan_preserved': True})
    return target


def gpu_contexts(uuids):
    raw = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid', '--format=csv,noheader,nounits'], text=True)
    return [line for line in raw.splitlines() if line.strip() and line.split(',')[-1].strip() in uuids]


def startup_group_members(helper, known_groups, live_api_pids, cgroup, proc_root=Path('/proc')):
    handles = []
    try:
        for proc in proc_root.iterdir():
            if not proc.name.isdigit() or int(proc.name) in live_api_pids:
                continue
            try:
                fields = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
                if fields[0] == 'Z' or int(fields[2]) not in known_groups:
                    continue
                if int(fields[3]) != int(fields[2]) or proc.stat().st_uid != os.getuid() or (proc / 'cgroup').read_text() != cgroup:
                    raise RuntimeError('Startup group contains a process outside its pinned Slurm step/session')
                handles.append(helper.PinnedProcess({'pid': int(proc.name), 'ticks': fields[19]}))
            except FileNotFoundError:
                continue
        return handles
    except BaseException:
        for handle in handles:
            handle.close()
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--controller-pid', type=int, default=1471924)
    parser.add_argument('--controller-ticks', default='921738287')
    parser.add_argument('--launcher-pid', type=int, default=1474020)
    parser.add_argument('--launcher-ticks', default='921761780')
    parser.add_argument('--owner-pid', type=int, default=1069284)
    parser.add_argument('--owner-ticks', default='917249780')
    args = parser.parse_args()
    helper = load_helper()
    directory = HERE / 'existing_upgrade'
    startup_only(directory)
    if (os.environ.get('SLURM_JOB_ID') != '240418' or not socket.gethostname().startswith('ampere3')
            or int(os.environ.get('SLURM_CPUS_PER_TASK', '0')) < 32 or len(os.sched_getaffinity(0)) < 32):
        raise RuntimeError('Recovery requires original allocation on ampere3 in a fresh >=32-CPU step')
    receipt = helper.read(directory / 'runtime_ready.json')
    runtime = Path(receipt['runtime_directory'])
    python = runtime / 'python/bin/python3.12'
    if (receipt.get('packages', {}).get('vllm') != '0.32.0' or receipt.get('pip_check_passed') is not True
            or helper.sha(python) != receipt['python_sha256'] or Path(sys.executable) != python):
        raise RuntimeError('Fresh reviewed vLLM runtime must run the recovery wrapper')
    plan_path = directory / 'saturation_serving_plan.json'
    plan = helper.read(plan_path)
    launcher_file = HERE / 'serve_saturation_pool.py'
    if helper.sha(launcher_file) != LAUNCHER_SHA:
        raise RuntimeError('Reviewed serving launcher changed')
    for name, expected in plan['code_sha256'].items():
        if helper.sha(name) != expected:
            raise RuntimeError('Serving source changed')
    common_spec = importlib.util.spec_from_file_location('cpu_recovery_common', plan['runtime_common'])
    common = importlib.util.module_from_spec(common_spec)
    common_spec.loader.exec_module(common)
    old_endpoints = helper.read(HERE.parent / 'shared_vllm_pool_2026-10-17_v3/endpoints.json')
    uuids = set()
    for endpoint in old_endpoints:
        if helper.sha(endpoint['server_identity_file']) != endpoint['server_identity_sha256']:
            raise RuntimeError('Original allocation GPU identity changed')
        uuids.update(helper.read(endpoint['server_identity_file'])['gpu_uuids'])
    if len(uuids) != 4:
        raise RuntimeError('Exactly four original GPUs must be identified')
    controller = helper.PinnedProcess({'pid': args.controller_pid, 'ticks': args.controller_ticks})
    owner = helper.PinnedProcess({'pid': args.owner_pid, 'ticks': args.owner_ticks})
    old_launcher = helper.PinnedProcess({'pid': args.launcher_pid, 'ticks': args.launcher_ticks})
    server_handles, orphan_handles, child, stopping = [], [], None, False
    try:
        if owner.info()['state'] not in {'T', 't'} or old_launcher.info()['parent_pid'] != controller.pid:
            raise RuntimeError('Original owner must stay stopped and failed launcher must belong to the pinned controller')
        for pinned, fragment in ((controller, 'manage_existing_pool.py'), (old_launcher, 'serve_saturation_pool.py')):
            command = (Path('/proc') / str(pinned.pid) / 'cmdline').read_bytes()
            if fragment.encode() not in command:
                raise RuntimeError('Pinned process command does not match its recovery role')
        records = []
        known_groups = set()
        for path in sorted(directory.glob('saturation_replica_*/launch.json')):
            launch = helper.read(path)
            known_groups.add(launch['pid'])
            proc = Path('/proc') / str(launch['pid'])
            try:
                fields = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
            except FileNotFoundError:
                records.append({'pid': launch['pid'], 'state': 'already_exited'})
                continue
            if fields[0] == 'Z':
                records.append({'pid': launch['pid'], 'ticks': fields[19], 'state': 'already_exited_zombie'})
                continue
            server = helper.PinnedProcess({'pid': launch['pid'], 'ticks': fields[19]})
            info = server.info()
            if (info['parent_pid'] != old_launcher.pid or info['pgrp'] != server.pid or info['session'] != server.pid
                    or (proc / 'cmdline').read_bytes().split(b'\0')[:-1] != [arg.encode() for arg in launch['command']]):
                server.close()
                raise RuntimeError('Startup API process/group/command identity differs')
            server_handles.append(server)
            records.append({'pid': server.pid, 'ticks': server.ticks, **info})
        # An API that already exited can leave a startup EngineCore behind.
        # Bind those exact same-session, same-step members individually rather
        # than sending a signal to a possibly recycled absent leader PID.
        cgroup = (Path('/proc') / str(old_launcher.pid) / 'cgroup').read_text()
        live_api_pids = {server.pid for server in server_handles}
        orphan_handles = startup_group_members(helper, known_groups, live_api_pids, cgroup)
        print(json.dumps({'checked': True, 'execute': args.execute, 'cpu_affinity': sorted(os.sched_getaffinity(0)), 'server_processes': records}), flush=True)
        if not args.execute:
            return 0
        controller.send(signal.SIGSTOP)
        while controller.alive() and controller.info()['state'] not in {'T', 't'}:
            time.sleep(.05)
        if not controller.alive():
            raise RuntimeError('Controller exited before it could be held')
        # Hold the launcher as well so its API children cannot be reaped/reused
        # between the group identity checks and startup-only group termination.
        old_launcher.send(signal.SIGSTOP)
        while old_launcher.alive() and old_launcher.info()['state'] not in {'T', 't'}:
            time.sleep(.05)
        startup_only(directory)
        old_launcher.send(signal.SIGTERM)
        for server in server_handles:
            if server.alive():
                info = server.info()
                if info['parent_pid'] != old_launcher.pid or info['pgrp'] != server.pid:
                    raise RuntimeError('Startup server ownership changed while launcher held')
                os.killpg(server.pid, signal.SIGTERM)
        for member in orphan_handles:
            if member.alive():
                member.send(signal.SIGTERM)
        old_launcher.send(signal.SIGCONT)
        while old_launcher.alive():
            time.sleep(2)
        while gpu_contexts(uuids):
            time.sleep(2)
        retired = retire_startup(directory, helper)
        helper.write(HERE / 'cpu_startup_recovery.json', {'stage': 'restarting_with_32_cpus', 'retired_directory': str(retired), 'controller_pid': controller.pid, 'controller_ticks': controller.ticks, 'old_owner_pid': owner.pid, 'old_owner_stays_stopped': True, 'cpu_affinity': sorted(os.sched_getaffinity(0)), 'no_scored_calls_in_retired_startup': True})
        def stop(signum, frame):
            nonlocal stopping
            stopping = True
        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGUSR1):
            signal.signal(sig, stop)
        command = [str(python), '-u', str(launcher_file), '--directory', str(directory), '--plan-sha256', helper.sha(plan_path), '--runtime-dir', str(runtime)]
        with (HERE / 'existing_pool_recovered_launcher.log').open('x') as log:
            child = subprocess.Popen(command, cwd=plan['root'], env=common.environment(runtime), stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        signalled = False
        while child.poll() is None:
            if stopping and not signalled:
                os.killpg(child.pid, signal.SIGTERM)
                signalled = True
            time.sleep(2)
        if child.returncode < 0:
            raise RuntimeError('Recovered launcher was killed; controller stays held for manual inspection')
        while gpu_contexts(uuids):
            time.sleep(2)
        helper.write(HERE / 'cpu_startup_recovery_completion.json', {'stage': 'recovered_launcher_drained', 'launcher_exit_code': child.returncode, 'controller_released': True})
        controller.send(signal.SIGCONT)
        return child.returncode
    finally:
        # Failure intentionally retains both old control layers. No rollback
        # resumes their automatic cleanup over an uncertain new process tree.
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            child.wait()
        for handle in server_handles:
            handle.close()
        for handle in orphan_handles:
            handle.close()
        old_launcher.close()
        owner.close()
        controller.close()


if __name__ == '__main__':
    raise SystemExit(main())
