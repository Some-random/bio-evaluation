"""Synthetic-only tests for a second, append-only execution producer."""
import importlib.util
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tests"))
import test_shared_vllm_resume as fixtures
spec = importlib.util.spec_from_file_location("saturation_resume_under_test", Path(__file__).with_name("shared_vllm_resume.py"))
s = importlib.util.module_from_spec(spec); spec.loader.exec_module(s)


class ChainTests(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory(); self.addCleanup(self.t.cleanup)
        self.f = fixtures.Fixture(self.t.name)
        self.f.old_manifest(); self.f.save_request(0); self.f.save_response(0, finish="length", text="")
        old = self.f.state(); old.acquire(); old.prepare([self.f.endpoint]); old.finish(); old.close()
        self.old_bytes = {str(p.relative_to(self.f.run_dir)): p.read_bytes() for p in self.f.run_dir.rglob("*.json")}
        endpoint = {**self.f.amendment["endpoints"][0], "scheduler_policy": s.POLICY, "queue_limit": 128, "max_inflight": 128, "max_num_seqs": 32}
        endpoint.pop("length_limits")
        self.endpoint = s.validate_endpoint(endpoint, live=False)
        self.ap = Path(self.t.name) / "saturation.json"
        self.a = {**self.f.amendment, "execution_variant": "saturation_native_queue_v1", "scheduler_policy": s.POLICY,
                  "scientific_protocol_changes": [], "transport_timeout_seconds": 14400,
                  "parent_amendment": {"path": str(self.f.amendment_path), "sha256": self.f.amendment_sha},
                  "endpoints": [endpoint], "adapter_files_sha256": {str(Path(s.__file__)): s.file_sha(s.__file__)}}
        s.atomic_write(self.ap, self.a); self.ah = s.file_sha(self.ap)

    def state(self):
        x = s.Run(self.f.entry, self.f.root, self.a, self.ap, self.ah)
        x.acquire(); self.addCleanup(x.close); return x

    def check_old(self):
        for n, b in self.old_bytes.items(): self.assertEqual((self.f.run_dir / n).read_bytes(), b, n)

    def test_mixed_raw_history_full_score_provenance_and_timeout(self):
        x = self.state(); x.prepare([self.endpoint]); self.assertEqual(len(list(x.pending())), 2)
        native_call = x.helper.call
        with mock.patch.object(x.helper, "call", wraps=native_call) as call:
            for c, n in list(x.pending()): x.dispatch(c, n, self.endpoint, threading.Event())
            self.assertEqual(call.call_count, 2)
            self.assertTrue(all(c.kwargs["timeout"] == 14400 for c in call.call_args_list))
        x.finish(); self.check_old()
        proof = s.validate_resume_provenance(x.run, self.f.settings, self.f.cases, require_terminal=True)
        self.assertEqual(proof["status_counts"], {"completed": 3})
        self.assertEqual(proof["parent_amendment_sha256"], self.f.amendment_sha)
        self.assertEqual(len(proof["dispatched_files"]), 2)
        self.assertFalse(proof["ambiguous_files"])
        self.assertTrue(proof["all_saved_responses_verified"])

    def test_pause_is_not_terminal_and_resume_preserves_parent(self):
        x = self.state(); x.prepare([self.endpoint]); c, n = next(x.pending()); x.dispatch(c, n, self.endpoint, threading.Event())
        self.assertEqual(x.pause()["stage"], "paused"); x.close()
        self.assertFalse((x.run / s.COMPLETION).exists()); self.check_old()
        with self.assertRaises(s.ResumeError): s.validate_resume_provenance(x.run, self.f.settings, self.f.cases, require_terminal=True)
        y = self.state(); y.prepare([self.endpoint]); self.assertEqual(len(list(y.pending())), 1)
        c, n = next(y.pending()); y.dispatch(c, n, self.endpoint, threading.Event()); y.finish()
        s.validate_resume_provenance(y.run, self.f.settings, self.f.cases, require_terminal=True); self.check_old()

    def test_old_provenance_mutation_is_detected(self):
        x = self.state(); x.prepare([self.endpoint])
        p = x.run / "progress.json"; p.write_text("{}")
        with self.assertRaisesRegex(s.ResumeError, "original execution artifact changed"):
            s.validate_resume_provenance(x.run, self.f.settings, self.f.cases)

    def test_saved_truncated_response_cannot_be_redispatched(self):
        x = self.state(); x.prepare([self.endpoint])
        with self.assertRaisesRegex(s.ResumeError, "regenerated"):
            x.dispatch(self.f.cases[0], self.f.name(0), self.endpoint, threading.Event())
        self.check_old()

    def test_queue_can_exceed_server_sequences_but_identity_must_match(self):
        self.assertEqual(self.endpoint["queue_limit"], 128)
        self.assertEqual(self.endpoint["server_identity"]["max_num_seqs"], 32)
        with self.assertRaises(s.ResumeError): s.validate_endpoint({**self.endpoint, "max_num_seqs": 64}, live=False)

    def test_untouched_v2_source_uses_original_validator(self):
        proof = s.validate_resume_provenance(self.f.run_dir, self.f.settings, self.f.cases, require_terminal=True)
        self.assertEqual(proof["amendment_sha256"], self.f.amendment_sha)
        self.assertNotIn("parent_amendment_sha256", proof)

    def test_unused_parent_no_execution_exception_fails_closed(self):
        proof = s.v2.validate_resume_provenance(self.f.run_dir, self.f.settings, self.f.cases, require_terminal=True)
        proof["status_counts"]["not_dispatched_proven_never_executed"] = 1
        x = self.state()
        with mock.patch.object(s.v2, "validate_resume_provenance", return_value=proof):
            with self.assertRaisesRegex(s.ResumeError, "Unused original no-execution"):
                x.prepare([self.endpoint])
        self.assertFalse((x.run / s.SIDECAR).exists())
        self.check_old()

    def test_transport_timeout_must_be_explicit_and_unchanged(self):
        self.a["transport_timeout_seconds"] = 900
        s.atomic_write(self.ap, self.a); self.ah = s.file_sha(self.ap)
        with self.assertRaisesRegex(s.ResumeError, "exact infrastructure-only"):
            self.state()

    def test_new_payload_mutation_is_detected(self):
        x = self.state(); x.prepare([self.endpoint]); c, n = next(x.pending()); x.dispatch(c, n, self.endpoint, threading.Event())
        p = x.run / "requests" / n; v = s.read(p); v["payload"]["max_tokens"] = 8192; s.atomic_write(p, v)
        with self.assertRaisesRegex(s.ResumeError, "unchanged original payload"):
            s.validate_resume_provenance(x.run, self.f.settings, self.f.cases)

    def test_claim_without_request_remains_ambiguous_and_is_never_repeated(self):
        x = self.state(); x.prepare([self.endpoint]); c, n = next(x.pending())
        with mock.patch.object(x.helper, "call", side_effect=RuntimeError("synthetic transport ambiguity")):
            with self.assertRaises(RuntimeError): x.dispatch(c, n, self.endpoint, threading.Event())
        self.assertNotIn(n, [name for _, name in x.pending()])
        proof = s.validate_resume_provenance(x.run, self.f.settings, self.f.cases)
        self.assertIn(n, proof["ambiguous_files"])

if __name__ == "__main__": unittest.main()
