"""Preserve existing engines while transferring or upgrading a native queue.

The owner resumes only after both producers finish and all surviving engines
are demonstrably idle, including on error. Signals bind to original PID/ticks
identities. There is no local timeout that kills a scored HTTP call.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import select
import signal
import socket
import subprocess
import sys
import time
import urllib.parse
import urllib.request


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.chmod(0o600)
    temporary.replace(path)


def process(pid, ticks):
    try:
        fields = (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()
    except FileNotFoundError:
        return None
    if fields[19] != str(ticks):
        raise RuntimeError('PID identity changed')
    return {'state': fields[0], 'parent_pid': int(fields[1]), 'pgrp': int(fields[2]), 'session': int(fields[3])}


class PinnedProcess:
    """A pidfd closes the check-ticks/kill PID-reuse race on Linux."""
    def __init__(self, record):
        self.pid, self.ticks = int(record['pid']), str(record['ticks'])
        before = process(self.pid, self.ticks)
        if before is None or before['state'] == 'Z':
            raise RuntimeError('Pinned process is not alive')
        self.fd = os.pidfd_open(self.pid)
        try:
            after = process(self.pid, self.ticks)
            if after is None or after['state'] == 'Z' or not self.alive():
                raise RuntimeError('Pinned process exited while opening its pidfd')
        except BaseException:
            os.close(self.fd)
            raise

    def alive(self):
        return not select.select([self.fd], [], [], 0)[0]

    def info(self):
        return process(self.pid, self.ticks) if self.alive() else None

    def send(self, signum):
        try:
            signal.pidfd_send_signal(self.fd, signum, None, 0)
        except ProcessLookupError:
            return False
        return True

    def close(self):
        os.close(self.fd)


def release_owner_when_safe(owner, producer, child, engines_idle, status, sleep=time.sleep):
    """Do not resume automatic engine cleanup under any active HTTP work."""
    if child is not None and child.poll() is None:
        os.killpg(child.pid, signal.SIGTERM)  # Our own unreaped child group.
        while child.poll() is None:
            sleep(2)
    if producer.alive():
        producer.send(signal.SIGTERM)
    while producer.alive():
        sleep(2)
    while True:
        try:
            if engines_idle():
                break
            status('waiting_for_engine_idle_before_owner_release')
        except (OSError, ValueError, RuntimeError) as error:
            status('owner_retained_until_engine_state_known', error_type=type(error).__name__)
        sleep(2)
    if owner.alive():
        owner.send(signal.SIGCONT)
        status('original_owner_released_after_idle')


def checked_gate(gate, original_python, common, root):
    if not gate['files_sha256']:
        raise RuntimeError('Continuation dependencies must be pinned')
    for name, expected in gate['files_sha256'].items():
        if sha(name) != expected:
            raise RuntimeError('Continuation dependency changed')
    python = Path(original_python)
    runtime = python.parents[2]
    if gate.get('replace_servers') is True:
        receipt_path = Path(gate['runtime_receipt_file']).resolve()
        if (not receipt_path.is_relative_to(root / '.local')
                or sha(receipt_path) != gate['runtime_receipt_sha256']):
            raise RuntimeError('Fresh serving runtime receipt changed')
        receipt = read(receipt_path)
        runtime = Path(receipt['runtime_directory']).resolve()
        python = runtime / 'python/bin/python3.12'
        observed_version = receipt.get('vllm_version', receipt.get('packages', {}).get('vllm'))
        if (receipt.get('stage') not in {'ready_for_launcher', 'ready_for_reviewed_launcher'} or observed_version != '0.32.0'
                or not runtime.name.startswith('bio-saturation-' + os.environ['SLURM_JOB_ID'] + '-')
                or str(python) != receipt.get('python')
                or str(receipt.get('job_id')) != os.environ['SLURM_JOB_ID']
                or sha(python) != gate['python_sha256']
                or (receipt.get('python_sha256') and receipt['python_sha256'] != gate['python_sha256'])
                or receipt.get('pip_check_passed') is False):
            raise RuntimeError('Fresh serving runtime identity differs')
    command = [str(python) if arg == '{python}' else str(runtime) if arg == '{runtime}' else arg for arg in gate['command']]
    if not command or command[0] != str(python):
        raise RuntimeError('Continuation must use its pinned private Python')
    return command, common.environment(runtime)


def stop_idle_server_groups(servers, owner, engines_idle, status, sleep=time.sleep):
    """Only the stopped owner's unreaped, session-leading children are stopped."""
    if not engines_idle():
        raise RuntimeError('Server replacement requires every engine to be idle')
    if not owner.alive() or owner.info()['state'] not in {'T', 't'}:
        raise RuntimeError('Original owner must remain stopped while replacing its servers')
    for server, identity in servers:
        info = server.info()
        if info is None:
            raise RuntimeError('An original server disappeared before replacement')
        if info['parent_pid'] != owner.pid or info['pgrp'] != server.pid or info['session'] != server.pid:
            raise RuntimeError('Server process group/session is not exclusively owned by the pinned owner')
    # The stopped parent cannot reap these child PIDs. Their PIDs/PGIDs therefore
    # cannot be recycled between this identity check and group termination.
    for server, identity in servers:
        os.killpg(server.pid, signal.SIGTERM)
    while any(server.alive() for server, identity in servers):
        sleep(2)
    # API exit alone does not prove that a GPU-owning descendant has exited.
    while True:
        live_groups = False
        for server, identity in servers:
            try:
                os.killpg(server.pid, 0)
            except ProcessLookupError:
                continue
            # Zombies cannot use GPUs and may wait for the stopped owner to
            # reap them; all non-zombie members must have disappeared.
            for entry in Path('/proc').iterdir():
                if not entry.name.isdigit():
                    continue
                try:
                    fields = (entry / 'stat').read_text().rsplit(')', 1)[1].split()
                except (FileNotFoundError, ProcessLookupError):
                    continue
                if int(fields[2]) == server.pid and fields[0] != 'Z':
                    live_groups = True
        if not live_groups:
            break
        sleep(2)
    owned_gpus = {uuid for server, identity in servers for uuid in identity['gpu_uuids']}
    while True:
        raw = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid', '--format=csv,noheader,nounits'], text=True)
        if not any(line.split(',')[-1].strip() in owned_gpus for line in raw.splitlines() if line.strip()):
            break
        status('waiting_for_original_gpu_contexts_to_exit')
        sleep(2)
    status('original_servers_stopped_after_idle', stopped_server_pids=[s.pid for s, _ in servers])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--handoff', type=Path, required=True)
    parser.add_argument('--handoff-sha256', required=True)
    args = parser.parse_args()
    directory = args.directory.resolve()
    if sha(args.handoff) != args.handoff_sha256:
        raise RuntimeError('Handoff plan changed')
    plan = read(args.handoff)
    root, old = Path(plan['root']).resolve(), Path(plan['old_pool_directory']).resolve()
    if not directory.is_relative_to(root / '.local') or not old.is_relative_to(root / '.local'):
        raise RuntimeError('Handoff paths leave this evaluation workspace')
    if str(os.environ.get('SLURM_JOB_ID')) != str(plan['slurm_job_id']):
        raise RuntimeError('Controller must run in the original GPU allocation')
    if plan['hostname'] not in {socket.gethostname(), socket.getfqdn()}:
        raise RuntimeError('Controller is on a different host')
    python, runtime = Path(sys.executable).absolute(), Path(plan['runtime_directory']).resolve()
    if (python != runtime / 'python/bin/python3.12'
            or not runtime.name.startswith('bio-shared-' + str(plan['slurm_job_id']) + '-')
            or sha(python) != plan['python_sha256']):
        raise RuntimeError('Controller must use the pinned retained serving runtime')
    common_path, health_path = old / 'runtime_common.py', root / 'scripts/watch_shared_vllm_health.py'
    if sha(common_path) != plan['runtime_common_sha256'] or sha(health_path) != plan['health_script_sha256']:
        raise RuntimeError('Serving/health helper changed')
    if sha(old / 'plan.json') != (old / 'plan.sha256').read_text().strip():
        raise RuntimeError('Original serving plan changed')
    if sha(old / 'endpoints.json') != plan['old_endpoints_sha256']:
        raise RuntimeError('Original endpoint inventory changed')
    pool_plan, endpoints = read(old / 'plan.json'), read(old / 'endpoints.json')
    for entry in endpoints:
        url = urllib.parse.urlsplit(entry['endpoint'])
        if (url.scheme != 'http' or url.hostname != '127.0.0.1' or url.path != '/v1'
                or url.username or url.password or url.query or url.fragment
                or sha(entry['server_identity_file']) != entry['server_identity_sha256']):
            raise RuntimeError('Original server endpoint identity changed')
    common_spec = importlib.util.spec_from_file_location('saturation_handoff_common', common_path)
    common = importlib.util.module_from_spec(common_spec)
    common_spec.loader.exec_module(common)
    health_spec = importlib.util.spec_from_file_location('saturation_handoff_health', health_path)
    health = importlib.util.module_from_spec(health_spec)
    health_spec.loader.exec_module(health)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    stopping, child, owner_stopped = False, None, False

    def stop(signum, frame):
        nonlocal stopping
        stopping = True

    for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGUSR1):
        signal.signal(signum, stop)

    def status(stage, **extra):
        write(old / 'saturation_handoff_status.json', {'stage': stage,
            'updated_at': dt.datetime.now(dt.timezone.utc).isoformat(),
            'handoff_sha256': args.handoff_sha256, **extra})

    def engines_idle():
        if sha(old / 'endpoints.json') != plan['old_endpoints_sha256']:
            raise RuntimeError('Endpoint inventory changed during drain')
        idle = True
        for entry in endpoints:
            if sha(entry['server_identity_file']) != entry['server_identity_sha256']:
                raise RuntimeError('Endpoint identity changed during drain')
            identity = read(entry['server_identity_file'])
            observed = process(identity['pid'], identity['proc_start_ticks'])
            if observed is None or observed['state'] == 'Z':
                continue  # Dead engines cannot hold work; producer must still end.
            if observed['state'] in {'T', 't'}:
                raise RuntimeError('A serving engine is stopped')
            with opener.open(entry['endpoint'].removesuffix('/v1') + '/metrics', timeout=15) as response:
                metrics = health.metric_values(response.read().decode())
            if not {'running', 'waiting'} <= set(metrics):
                raise RuntimeError('Engine queue counters are missing')
            idle = idle and metrics['running'] == 0 and metrics['waiting'] == 0
        return idle

    owner, producer, servers = None, None, []
    try:
        owner, producer = PinnedProcess(plan['old_owner']), PinnedProcess(plan['old_producer'])
        if owner.pid == producer.pid or producer.info()['parent_pid'] != owner.pid:
            raise RuntimeError('Pinned producer is not the pinned owner\'s direct child')
        if owner.info()['state'] in {'T', 't'}:
            raise RuntimeError('Original owner was already stopped by another controller')
        for entry in endpoints:
            health.observe_endpoint(entry, pool_plan, opener)
            identity = read(entry['server_identity_file'])
            servers.append((PinnedProcess({'pid': identity['pid'], 'ticks': identity['proc_start_ticks']}), identity))
        owner.send(signal.SIGSTOP)
        owner_stopped = True
        while owner.alive() and owner.info()['state'] not in {'T', 't'}:
            time.sleep(.05)
        if not owner.alive():
            raise RuntimeError('Original owner exited before suspension')
        producer.send(signal.SIGTERM)
        status('draining_original_dispatcher', owner=plan['old_owner'], producer=plan['old_producer'])
        while producer.alive():
            time.sleep(2)
        while not engines_idle():
            status('waiting_for_original_engines_idle')
            time.sleep(2)
        status('old_dispatcher_drained_servers_preserved', owner=plan['old_owner'], producer=plan['old_producer'])
        gate_path, deadline = directory / 'existing_pool_dispatch.json', time.monotonic() + 1800
        while not gate_path.is_file():
            if stopping:
                return 0
            if time.monotonic() > deadline:
                raise TimeoutError('No continuation gate supplied in thirty minutes')
            time.sleep(2)
        gate = read(gate_path)
        command, child_env = checked_gate(gate, python, common, root)
        if stopping:
            return 0
        if not engines_idle():
            raise RuntimeError('Continuation gate found unexpected serving work')
        if gate.get('replace_servers') is True:
            stop_idle_server_groups(servers, owner, engines_idle, status)
        with (directory / 'existing_pool_dispatch.log').open('x') as log:
            child = subprocess.Popen(command, cwd=root, env=child_env,
                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        status('evaluating', dispatch_pid=child.pid, replaced_original_servers=gate.get('replace_servers') is True)
        signalled = False
        while child.poll() is None:
            if gate.get('replace_servers') is not True:
                try:
                    for entry in endpoints:
                        health.observe_endpoint(entry, pool_plan, opener)
                except (OSError, ValueError, RuntimeError):
                    stopping = True
            if stopping and not signalled:
                os.killpg(child.pid, signal.SIGTERM)
                signalled = True
                status('draining_native_queue')
            time.sleep(2)
        while not engines_idle():
            status('waiting_for_continuation_engines_idle')
            time.sleep(2)
        status('completed_or_paused', dispatcher_exit_code=child.returncode)
        return child.returncode
    finally:
        try:
            if owner_stopped:
                release_owner_when_safe(owner, producer, child, engines_idle, status)
        finally:
            for server, identity in servers:
                server.close()
            if producer is not None:
                producer.close()
            if owner is not None:
                owner.close()


if __name__ == '__main__':
    raise SystemExit(main())
