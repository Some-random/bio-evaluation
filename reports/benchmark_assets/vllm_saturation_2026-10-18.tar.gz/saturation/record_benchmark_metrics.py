"""Observe active synthetic sweeps using GET metrics only; never dispatch."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
from pathlib import Path
import time
import urllib.request

D=Path(__file__).resolve().parent
ENDPOINTS=json.loads((D/'saturation_endpoints.json').read_text())


def observe(e):
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(e['endpoint'].removesuffix('/v1')+'/metrics',timeout=10) as f:
        lines=f.read().decode().splitlines()
    names={'vllm:num_requests_running','vllm:num_requests_waiting','vllm:kv_cache_usage_perc',
           'vllm:num_preemptions_total','vllm:generation_tokens_total','vllm:prompt_tokens_total'}
    values={}
    for line in lines:
        if not line or line.startswith('#'):continue
        field,value=line.rsplit(None,1);name=field.split('{',1)[0]
        if name in names:values[name]=values.get(name,0)+float(value)
    progress=D/('saturation_benchmark_'+e['endpoint_id'])/'progress.json'
    stage=json.loads(progress.read_text()).get('stage') if progress.exists() else None
    return {'endpoint_id':e['endpoint_id'],'stage':stage,'metrics':values}


with (D/'benchmark_metrics.jsonl').open('x') as out, ThreadPoolExecutor(max_workers=4) as pool:
    while True:
        records=list(pool.map(observe,ENDPOINTS))
        out.write(json.dumps({'at_utc':datetime.now(timezone.utc).isoformat(),'endpoints':records})+'\n')
        out.flush()
        if (D/'saturation_benchmark_summary.json').exists():break
        time.sleep(1)
