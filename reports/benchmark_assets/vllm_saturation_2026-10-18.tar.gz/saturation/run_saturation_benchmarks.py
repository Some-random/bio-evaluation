"""Run fixed-work synthetic saturation sweeps on four otherwise idle replicas."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory', required=True, type=Path)
    args = p.parse_args()
    d = args.directory.resolve()
    client = d.parent / 'shared_vllm_pool_2026-10-17_v3/benchmark_vllm_concurrency.py'
    if sha(client) != 'd08a6b2a1739c99ec07a66f0e619ce5f94fd2d9816142b6bcc72c34069bab58b':
        raise RuntimeError('Frozen synthetic benchmark client changed')
    deadline = time.monotonic()+1800
    while not (d/'saturation_endpoints.json').is_file():
        if time.monotonic()>deadline:
            raise TimeoutError('Four-replica startup did not finish in30 minutes')
        status = d/'serving_status.json'
        if status.is_file() and json.loads(status.read_text()).get('stage')=='failed':
            raise RuntimeError('Serving startup failed before saturation benchmark')
        time.sleep(2)
    endpoints = json.loads((d/'saturation_endpoints.json').read_text())
    profiles = [
        # Same request count and payloads at every level in each sweep.
        {'input_tokens':192,'output_tokens':1024,'requests':128,'levels':'32,64,128'},
        {'input_tokens':7000,'output_tokens':1024,'requests':64,'levels':'16,32,64'},
        {'input_tokens':45056,'output_tokens':1024,'requests':16,'levels':'4,8,16'},
        {'input_tokens':1536,'output_tokens':4096,'requests':64,'levels':'32,64'},
    ]
    def run(item):
        endpoint, profile = item
        out = d/('saturation_benchmark_'+endpoint['endpoint_id'])
        command = [sys.executable,str(client),'--base-url',endpoint['endpoint'],
                   '--model','Qwen/Qwen3.8-27B','--output-dir',str(out),
                   '--concurrencies',profile['levels'],'--requests',str(profile['requests']),
                   '--input-tokens',str(profile['input_tokens']),
                   '--output-tokens',str(profile['output_tokens']),
                   '--temperature','1','--top-p','0.95','--top-k','20',
                   '--generation-seed','42','--seed','20261018','--request-timeout','14400']
        with (d/('benchmark_'+endpoint['endpoint_id']+'.log')).open('x') as log:
            result = subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
        return {'endpoint_id':endpoint['endpoint_id'],'profile':profile,
                'returncode':result.returncode,'results_file':str(out/'results.json')}
    started=time.time()
    with ThreadPoolExecutor(max_workers=4) as pool:
        results=list(pool.map(run,zip(endpoints,profiles)))
    report={'synthetic_only':True,'biological_inputs_read':False,
            'elapsed_seconds':time.time()-started,'results':results,
            'success':all(x['returncode']==0 for x in results)}
    with (d/'saturation_benchmark_summary.json').open('x') as f:
        json.dump(report,f,indent=2);f.write('\n')
    print(json.dumps(report),flush=True)
    return 0 if report['success'] else 1


if __name__=='__main__':
    raise SystemExit(main())
